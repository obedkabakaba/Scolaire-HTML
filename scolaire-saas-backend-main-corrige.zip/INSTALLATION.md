# Où placer chaque fichier

## Dépôt backend — `scolaire-saas-backend-main/`

### Nouveaux
```
migrations/028-catalogue-commercial.sql
migrations/029-grille-tarifaire-harmonisee.sql
utils/catalogue.utils.js
middleware/offre.middleware.js
controllers/catalogue.controller.js
controllers/services.controller.js
routes/catalogue.routes.js
routes/services.routes.js
scripts/generer-tarifs-statiques.js
test/catalogue.test.js
test/offre-middleware.test.js
```

### Remplacent l'existant (versions déjà modifiées, à copier telles quelles)
```
server.js
utils/ia.utils.js
controllers/abonnements.controller.js
routes/eleves.routes.js
routes/utilisateurs.routes.js
routes/super-admin.routes.js
```

## Dépôt frontend — `Scolaire-HTML-main/`

À la racine, à côté de `connexion.html` :
```
site.css          (nouveau)
catalogue.js      (nouveau)
index.html        (REMPLACE l'ancien — en garder une copie)
tarifs.html       (nouveau)
services.html     (nouveau)
robots.txt        (nouveau)
sitemap.xml       (nouveau)
```

## Ordre d'application

1. Migrations SQL, dans l'ordre : 028 puis 029
2. Fichiers backend, puis redéploiement
3. Vérifier `GET /catalogue/offres`
4. Fichiers frontend
5. `node scripts/generer-tarifs-statiques.js ../Scolaire-HTML-main --verifier`

Aucune suppression n'est nécessaire. La migration est idempotente : la rejouer
ne duplique rien.
