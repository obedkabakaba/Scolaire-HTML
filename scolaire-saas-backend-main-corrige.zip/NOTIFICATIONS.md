# Notifications — guide de mise en service

Ce document décrit le service de notifications : ce qui part, à qui, quand, et
ce qu'il faut faire pour le mettre en route.

---

## 1. Mise en service — trois étapes

### a. Appliquer la migration

```bash
psql "$DATABASE_URL" -f migrations/025-notifications-file-envoi.sql
```

Elle ajoute huit colonnes à `notifications` et quatre index. Elle est
idempotente (`IF NOT EXISTS` partout) : la relancer ne casse rien.

> **Sans cette migration, rien ne fonctionne.** Le code écrit dans des colonnes
> qui n'existent pas encore, et l'index sur `cle_unicite` est requis par les
> clauses `ON CONFLICT` — sans lui, PostgreSQL ne dégrade pas, il **échoue**
> (erreur 42P10).

### b. Variables d'environnement

| Variable | Rôle | Défaut |
|---|---|---|
| `RESEND_API_KEY` | **Requis** pour tout envoi d'e-mail | — |
| `RESEND_FROM_EMAIL` | Adresse expéditrice (domaine vérifié chez Resend) | `onboarding@resend.dev` |
| `FRONTEND_URL` | Base des liens dans les e-mails | `https://myardoise.com` |
| `CRON_SECRET` | **Requis** — protège les routes `/jobs/*` | — |
| `NOTIFICATIONS_MAX_ESSAIS` | Réessais avant abandon | `5` |
| `NOTIFICATIONS_PAUSE_MS` | Pause entre deux envois | `600` |
| `NOTIFICATIONS_TAILLE_LOT` | E-mails par vidage | `40` |

Sans `RESEND_API_KEY`, la plateforme continue de fonctionner : les
notifications s'affichent normalement dans l'interface, seuls les e-mails ne
partent pas (statut `abandonne`, motif `cle_api_absente`).

`NOTIFICATIONS_PAUSE_MS` mérite attention : **Resend limite à 2 requêtes par
seconde** sur les formules d'entrée. Descendre sous 500 ms fait rejeter les
envois en 429 et consomme le quota de réessais pour rien.

### c. Programmer les tâches

À déclarer chez cron-job.org (ou équivalent), en `POST`, avec l'en-tête
`x-cron-secret: <CRON_SECRET>` :

| Route | Fréquence | Rôle |
|---|---|---|
| `/jobs/notifications` | **toutes les 5 min** | Filet de sécurité de la file d'e-mails |
| `/jobs/evenements` | 1×/jour, 06 h | Rappels J‑7 / J‑1 / jour même |
| `/jobs/calendrier` | 1×/jour, 06 h | Fins de période, notes non soumises |
| `/jobs/abonnements` | 1×/jour, 03 h | Expirations, suspensions |

Les tâches quotidiennes sont **idempotentes** : les relancer après un timeout
ne crée aucun doublon (déduplication par `cle_unicite`).

`/jobs/notifications` est le seul indispensable au fonctionnement normal. Sans
lui, un e-mail raté est un e-mail perdu : personne ne le saurait.

---

## 2. Comment ça marche

### Deux moitiés qui ne se touchent jamais

```
CONTRÔLEUR (dans la transaction)          FILE (après le commit)
──────────────────────────────            ──────────────────────
notifierEvenement()                       planifierVidage()
  └─ INSERT dans notifications              └─ viderFile()
     statut = 'en_attente'                     ├─ réclame un lot
     quelques millisecondes                    ├─ appelle Resend
                                               └─ écrit le résultat
```

**Pourquoi cette séparation.** Tout le code passe par `runWithTenant`, qui
ouvre une transaction. Un `await envoyerEmail()` à l'intérieur casse trois
choses :

1. **L'e-mail part avant le COMMIT.** Si la transaction échoue trois lignes
   plus bas, la base revient en arrière — pas l'e-mail. Un parent reçoit
   « paiement enregistré » pour un paiement qui n'existe pas.
2. **Un appel réseau de 2 s = 2 s de verrous tenus.** `payerSalaire`
   verrouille explicitement la ligne de paie (`FOR UPDATE OF s`) : la file
   d'attente se forme derrière une requête HTTP.
3. **300 bulletins signés = 300 appels HTTP dans une transaction.** Elle expire
   avant la fin, et tout est annulé — y compris les signatures.

### Une ligne = un destinataire

`canal` dit comment la notification est délivrée, pas où elle s'affiche :

- `'interne'` → visible dans la plateforme uniquement ;
- `'email'` → visible dans la plateforme **et** envoyée par e-mail.

C'est la convention qui existait déjà ; elle est conservée. Le frontend
(cloche dans `ui.js`, écran `messages.html`) n'a besoin d'aucune modification.

### Le HTML n'est pas stocké

La file garde `evenement` + `donnees` (JSON), et le rendu a lieu **à l'envoi**.
Une ligne pèse ~200 octets au lieu de ~15 Ko, et un gabarit corrigé s'applique
aussi aux e-mails encore en attente.

### Réessais

Un échec est réessayé avec un délai croissant (5, 10, 15… minutes) jusqu'à
`MAX_ESSAIS`, puis passe en `abandonne` — visible en base, donc diagnosticable,
plutôt que réessayé indéfiniment contre une adresse qui n'existe pas.

Une ligne bloquée en `en_cours` depuis plus de 15 minutes (processus mort en
plein envoi) est automatiquement remise en file.

---

## 3. Ce qui part aujourd'hui

### Comptes

| Événement | Destinataire | Canal |
|---|---|---|
| `compte.cree` | Le nouvel utilisateur | E‑mail |
| `compte.mot_de_passe_reinitialise` | L'utilisateur concerné | E‑mail |

Les identifiants ne s'affichent plus seulement dans la réponse HTTP : ils
partent à l'intéressé. Un mot de passe transmis par WhatsApp ou sur un bout de
papier n'est plus un mot de passe.

**Le mot de passe provisoire est effacé de la base** dès l'envoi réussi
(`donnees` remis à `{}`). Il n'a aucune raison de dormir dans une colonne
`jsonb` que toute personne ayant accès à la base peut lire.

### Paie

| Événement | Destinataire | Canal |
|---|---|---|
| `paie.salaire_paye` | L'employé payé | E‑mail |
| `paie.preparee` | Direction, comptable | Interne |

**Le bulletin de paie *est* l'e-mail** : base, primes, retenues, net, date,
mode de paiement, en tableau. Il s'imprime et se conserve.

Pas de PDF, délibérément : cela supposerait de lancer Chromium (~300 Mo) et de
stocker un fichier par employé et par mois, pour un contenu qui tient dans un
tableau lisible sur un téléphone bas de gamme.

*Préparer* la paie ne déclenche aucun e-mail — cela ferait croire aux employés
que l'argent est parti.

### Notes et bulletins

| Événement | Destinataire | Canal |
|---|---|---|
| `notes.soumises` | Titulaire, direction | Interne |
| `bulletin.disponible` | Famille | E‑mail |

**Les familles sont prévenues à la signature, pas à la saisie.** Une note
soumise reste dévalidable et recalculable ; un bulletin signé est définitif.
Écrire plus tôt ferait venir les parents réclamer sur des chiffres qui vont
changer.

`notes.soumises` reste interne : un e-mail par cours et par classe, c'est 240
messages par période pour une école de 20 classes × 12 cours.

### Frais

| Événement | Destinataire | Canal |
|---|---|---|
| `frais.paiement_recu` | Famille | E‑mail |
| `frais.rappel_impaye` | Famille | E‑mail *(gabarit prêt, pas encore déclenché)* |

Reçu horodaté avec référence, objet, montant et **solde restant de l'année en
cours**. Dans une école où l'on paie en espèces au guichet, une trace écrite
règle la moitié des litiges de fin d'année avant qu'ils n'existent.

### Vie scolaire

| Événement | Destinataire | Canal |
|---|---|---|
| `presence.absence` | Famille | E‑mail |
| `discipline.incident` | Famille | E‑mail |
| `discipline.conduite_critique` | Direction | Interne |

**L'absence part le jour même.** Signalée au bulletin trois mois plus tard,
elle n'informe plus personne. Le jour même, la journée peut encore s'expliquer
— et c'est la seule fenêtre où l'école apprend qu'un enfant parti de chez lui
n'est jamais arrivé.

Seuls les **absents** déclenchent un message : ni les retards ni les absences
excusées. Corriger l'appel trois fois dans l'après-midi n'envoie qu'un e-mail.

Côté discipline, seuls les faits **négatifs à points non nuls** partent : écrire
pour chaque bon point transformerait le message en bruit. L'alerte à la
direction se déclenche sous 50 % du capital de conduite — le seuil où
l'appréciation bascule en « Mauvaise ».

### Calendrier

| Événement | Destinataire | Canal |
|---|---|---|
| `calendrier.evenement_ajoute` | Personnel | Interne |
| `calendrier.rappel` J‑7 | Personnel concerné | Interne |
| `calendrier.rappel` J‑1 | Personnel concerné | E‑mail |
| `calendrier.rappel` jour même | Personnel concerné | E‑mail |

**Trois échéances, pas plus.** Un rappel quotidien pendant deux semaines n'est
pas trois fois plus efficace : il est ignoré. Chacune répond à une question
différente — J‑7 « ai-je le temps de m'organiser ? », J‑1 « est-ce que
j'oublie ? », J‑0 « c'est aujourd'hui ».

Les destinataires **dépendent du type d'événement** : un examen ne concerne pas
les mêmes personnes qu'une réunion. Chaque type porte aussi une consigne, qui
transforme le rappel en action — « Dépôt des résultats dans 7 jours » n'appelle
rien, « saisissez et soumettez vos cotes » si.

Ces profils se règlent dans `PROFIL_EVENEMENT` (`controllers/jobs.controller.js`).

---

## 4. Le piège évité : la boîte du directeur

`notifications.controller.js` affiche à la direction **toute ligne dont
`utilisateur_id` est NULL**. Or les messages aux familles ont précisément
`utilisateur_id` NULL — un parent n'a pas de compte.

Sans correctif, signer une classe de 300 élèves aurait déversé 300 messages
destinés à des tiers dans la boîte du directeur : bruit massif, et exposition
de données familiales sur un écran qui n'a pas à les présenter ainsi.

D'où la colonne **`visible_interface`**, mise à `false` pour tous les envois
externes, et filtrée dans les trois requêtes du contrôleur (`lister`,
`marquerLue`, `toutMarquerLu`).

---

## 5. Ajouter un événement

1. Décrire l'événement dans `utils/notifications-catalogue.js` ;
2. L'appeler depuis le contrôleur, **dans** la transaction ;
3. Appeler `planifierVidage()` **après** `runWithTenant`.

```js
const { notifierEvenement, destinatairesParRole, planifierVidage }
  = require('../utils/notifications.service');

await runWithTenant(tenantContextFromReq(req), async (client) => {
  // ... le travail métier ...

  await notifierEvenement(client, {
    evenement: 'mon.evenement',
    destinataires: await destinatairesParRole(client, ['directeur']),
    expediteurId: req.auth.userId,
    donnees: { ... },
    cleUnicite: `mon_evenement:${id}`   // facultatif, contre les doublons
  });
});

planifierVidage();   // hors transaction — c'est tout l'intérêt
```

Pour écrire à une famille, ajouter `visibleInterface: false` et passer
l'adresse : `destinataires: [{ email, nom }]`.

**Les gabarits ne doivent jamais lever d'exception.** Le rendu a lieu à
l'envoi, en arrière-plan : une erreur y est rattrapée silencieusement et
dégrade l'e-mail sans que personne ne le sache. Traiter chaque champ de
`donnees` comme potentiellement absent, et lancer `node test/notifications.test.js`.

---

## 6. Surveillance

`POST /jobs/notifications` renvoie l'état de la file sur 7 jours :

```json
{
  "envoyes": 12, "echecs": 0, "traites": 12,
  "file_restante": { "en_attente": 3, "abandonne": 1 }
}
```

`abandonne` compte les e-mails **définitivement perdus** — adresse invalide,
clé d'API absente. Ce chiffre doit rester à zéro ; s'il monte, la cause est
dans `derniere_erreur` :

```sql
SELECT evenement, destinataire_email, essais, derniere_erreur, created_at
  FROM notifications
 WHERE statut = 'abandonne' AND created_at > now() - interval '7 days'
 ORDER BY created_at DESC;
```

---

## 7. Entretien

`notifications` grossit sans fin : une école de 500 élèves génère environ
3 000 lignes par mois. Purge conseillée, mensuelle :

```sql
DELETE FROM notifications
 WHERE created_at < now() - interval '12 months'
   AND (lu = true OR statut IN ('envoye', 'abandonne'));
```

Douze mois : la durée d'une année scolaire complète, donc la fenêtre pendant
laquelle une école peut avoir besoin de prouver qu'un parent a bien été
prévenu.

---

## 8. Pistes non implémentées

Les gabarits existent, le déclencheur reste à écrire :

- **`frais.rappel_impaye`** — relance périodique des soldes. À brancher sur un
  job hebdomadaire plutôt que quotidien, et **jamais** sans une tolérance
  configurable : relancer une famille qui a payé la veille détruit la confiance
  dans tous les autres messages.
- **`inscription.resultat`** — résultats d'admission aux familles des candidats,
  à la publication d'une session (`inscriptions.controller.js`).
- **`periode.cloturee`** — à brancher dans `cloture.controller.js`.

Deux extensions qui demanderaient une décision produit :

- **Préférences par utilisateur** (quels e-mails recevoir). Aujourd'hui les
  canaux sont fixés au catalogue. Une table `preferences_notifications` serait
  le bon endroit — mais attention à ne pas rendre désactivables les messages
  qui protègent l'école (absences, discipline).
- **WhatsApp**. La table `conversations_whatsapp` existe déjà. Le canal serait
  plus efficace que l'e-mail auprès des familles en RDC ; le service est prêt à
  l'accueillir (il suffirait d'une valeur `canal = 'whatsapp'` et d'une branche
  dans `viderFile`).
