# Ardoise — Restructuration commerciale

Rapport de mission · 9 août 2026

---

## A. Architecture commerciale

Ardoise vend désormais deux choses qui n'ont ni le même rythme, ni la même
nature, ni la même logique de prix.

```
        ┌──────────────────────────────────────────────┐
        │  ÉTAGE 1 — L'ABONNEMENT                      │
        │  « Je paie pour utiliser Ardoise. »          │
        │                                              │
        │  Ascension → Prime → Pilote → Infinite       │
        │  Mensuel · Semestriel · Annuel               │
        │  Récurrent · donne accès à la plateforme     │
        └──────────────────────────────────────────────┘
                            +   (facultatif, à tout moment)
        ┌──────────────────────────────────────────────┐
        │  ÉTAGE 2 — LES SERVICES COMPLÉMENTAIRES      │
        │  « Je paie pour qu'Ardoise m'accompagne. »   │
        │                                              │
        │  Installation · Formation · Campagne capture │
        │  Ponctuel · n'ouvre AUCUNE fonctionnalité    │
        │  Disponible avec les QUATRE offres           │
        └──────────────────────────────────────────────┘
```

**La règle qui tient tout l'édifice :** un service ne se débloque pas, il
s'achète. Une école abonnée à Ascension à 35 $/mois commande la formation
personnalisée à 100 $ exactement comme une école en Infinite, au même prix et
par le même chemin.

Cette séparation n'est pas un discours : elle est **structurelle**.

| | Abonnement | Service |
|---|---|---|
| Table | `plans_abonnement` / `abonnements` | `services_complementaires` / `commandes_services` |
| Route API | `/catalogue/offres`, `/abonnements` | `/catalogue/services`, `/services` |
| Contrôle de droits | `exigeFonctionnalite()` | **aucun** — délibérément |
| Page publique | `tarifs.html` | `services.html` |
| Rythme | récurrent | ponctuel |

Le jour où une ligne de `services.controller.js` lira `plan_id`, la séparation
sera perdue. Un test la protège explicitement (§ K).

---

## B. Les quatre offres

### Ardoise Ascension — *Digitaliser l'essentiel*

- **Cible** — écoles jusqu'à 250 élèves qui tiennent encore leurs registres sur
  papier ou sur Excel.
- **Prix** — 35 $/mois · 193 $/6 mois (32,17 $/mois) · 350 $/an (29,17 $/mois)
- **Limites** — 250 élèves · 15 comptes · 12 classes · 1 année archivée · 500 Mo · 500 e-mails/mois
- **IA** — assistant d'aide contextuelle + génération des appréciations · **100 générations/mois**
- **Contenu** — le cœur métier COMPLET : élèves, classes, sections, options, cours,
  années scolaires, périodes, notes, travaux, moyennes, classements, mentions,
  bulletins officiels RDC (primaire, secondaire, terminale) et bulletin annuel,
  présences, frais scolaires en FC et USD, reçus, clôture de période,
  reconduction annuelle, journal d'activité, didacticiel, travail hors ligne.

> **Pourquoi ce contenu.** Une offre d'entrée qui ne génère pas de bulletin
> officiel n'est pas un logiciel scolaire : c'est une démonstration. Ascension
> doit être professionnellement utilisable, sinon la première expérience d'une
> école avec Ardoise est celle d'un produit incomplet.

### Ardoise Prime — *Automatiser et communiquer*

- **Cible** — 250 à 600 élèves, administration qui commence à saturer.
- **Prix** — 59 $/mois · 325 $/6 mois (54,17) · 590 $/an (49,17)
- **Limites** — 600 élèves · 40 comptes · 40 classes · 3 années · 2 Go · 3 000 e-mails/mois
- **IA** — + lecture du règlement intérieur · **400 générations/mois**
- **Ajoute** — emploi du temps, créneaux et exceptions, jours fériés, discipline
  et capital conduite, règlement intérieur avec barème, messages groupés aux
  parents, site public de l'école, consultation des résultats en ligne, éditeur
  de modèles de bulletins.

> **Le fil conducteur.** Tout ce qui entre à ce palier fait la même chose :
> supprimer un travail manuel récurrent, ou ouvrir un canal vers l'extérieur.
> Ce n'est pas « Ascension + 9 fonctionnalités », c'est le moment où l'école
> cesse de tout faire à la main.

### Ardoise Pilote — *Piloter l'établissement*

- **Cible** — 600 à 1 500 élèves, direction structurée, comptabilité, admissions.
- **Prix** — 99 $/mois · 545 $/6 mois (90,83) · 990 $/an (82,50)
- **Limites** — 1 500 élèves · 120 comptes · classes illimitées · 5 années · 10 Go · 15 000 e-mails
- **IA** — + questions sur vos données en langage naturel · **1 500 générations/mois**
- **Ajoute** — comptabilité (caisse, catégories, dépenses), paie (contrats,
  salaires), concours d'admission (sessions, épreuves, candidats, classement),
  orientation au mérite, session de repêchage, rapports avancés et tableaux de bord.

> **Le fil conducteur.** Tout ce palier sert à *décider* : où va l'argent, qui
> entre, qui passe, qui redouble. Les cinq modules ajoutés sont ceux qu'utilise
> une direction, pas un enseignant.

### Ardoise Infinite — *Exploiter Ardoise sans limite*

- **Prix** — 159 $/mois · 875 $/6 mois (145,83) · 1 590 $/an (132,50)
- **Cible** — grands établissements et structures multi-vacations de plus de 1 500 élèves.
- **Limites** — élèves, comptes, classes et archives **sans limite** · 50 Go · e-mails illimités
- **IA** — + assistant WhatsApp · **5 000 générations/mois**
- **Ajoute** — assistant WhatsApp parents et personnel, archives et historique
  illimités, support prioritaire.

> ⚠️ **Trois arguments ont été retirés d'Infinite.** La première version de
> l'argumentaire annonçait *traitements IA de masse*, *sauvegardes à la
> demande* et *réseau de plusieurs établissements*. Aucun des trois n'existe
> dans le produit : pas de route de traitement de masse, sauvegardes réservées
> au Super Admin, et un utilisateur appartient à une école et une seule partout
> dans le code. Ils ont été retirés du catalogue, du semis SQL et des trois
> pages. Les remettre le jour où ils existent tient en trois lignes — un test
> échoue désormais si un drapeau est déclaré vendable sans être appliqué nulle
> part (§ K).

> **Pourquoi WhatsApp seulement ici.** C'est la seule fonctionnalité du produit
> qui coûte de l'argent à chaque message envoyé (API Meta). La réserver au
> palier qui absorbe ce coût n'est pas un artifice commercial : c'est la seule
> répartition qui ne fasse pas payer aux petites écoles le trafic des grandes.

---

## C. Matrice comparative

**✓ = compris · — = non compris**

### Le cœur du métier — identique dans les quatre offres

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Élèves, dossiers, historique scolaire | ✓ | ✓ | ✓ | ✓ |
| Classes, sections, options, cours | ✓ | ✓ | ✓ | ✓ |
| Années scolaires, trimestres/semestres | ✓ | ✓ | ✓ | ✓ |
| Notes, travaux, moyennes, classements | ✓ | ✓ | ✓ | ✓ |
| Bulletins officiels RDC + bulletin annuel | ✓ | ✓ | ✓ | ✓ |
| Présences | ✓ | ✓ | ✓ | ✓ |
| Frais scolaires, encaissements, reçus | ✓ | ✓ | ✓ | ✓ |
| Double devise FC / USD | ✓ | ✓ | ✓ | ✓ |
| Clôture de période, reconduction annuelle | ✓ | ✓ | ✓ | ✓ |
| Journal d'activité | ✓ | ✓ | ✓ | ✓ |
| Didacticiel + assistant d'aide | ✓ | ✓ | ✓ | ✓ |
| Hors ligne, application installable | ✓ | ✓ | ✓ | ✓ |

### Organisation et vie scolaire

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Emploi du temps et créneaux | — | ✓ | ✓ | ✓ |
| Discipline et capital conduite | — | ✓ | ✓ | ✓ |
| Messages groupés aux parents | — | ✓ | ✓ | ✓ |
| Site public + résultats en ligne | — | ✓ | ✓ | ✓ |
| Éditeur de modèles de bulletins | — | ✓ | ✓ | ✓ |

### Pilotage

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Comptabilité (caisse, dépenses) | — | — | ✓ | ✓ |
| Paie (contrats, salaires) | — | — | ✓ | ✓ |
| Concours d'admission | — | — | ✓ | ✓ |
| Orientation au mérite | — | — | ✓ | ✓ |
| Repêchage | — | — | ✓ | ✓ |
| Rapports avancés | — | — | ✓ | ✓ |

### Intelligence artificielle

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Assistant d'aide contextuelle | ✓ | ✓ | ✓ | ✓ |
| Appréciations et observations générées | ✓ | ✓ | ✓ | ✓ |
| Lecture du règlement intérieur | — | ✓ | ✓ | ✓ |
| Données en langage naturel | — | — | ✓ | ✓ |
| Assistant WhatsApp | — | — | — | ✓ |
| **Générations / mois** | **100** | **400** | **1 500** | **5 000** |

### Volumes

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Élèves actifs | 250 | 600 | 1 500 | ∞ |
| Comptes utilisateurs | 15 | 40 | 120 | ∞ |
| Classes | 12 | 40 | ∞ | ∞ |
| Années archivées | 1 | 3 | 5 | ∞ |
| Stockage | 500 Mo | 2 Go | 10 Go | 50 Go |
| E-mails / mois | 500 | 3 000 | 15 000 | ∞ |

### Accompagnement

| | Ascension | Prime | Pilote | Infinite |
|---|:---:|:---:|:---:|:---:|
| Support prioritaire | — | — | — | ✓ |
| Installation · Formation · Capture | \<— services complémentaires, mêmes prix pour les quatre —\> | | | |

### Justification de chaque différence

| Fonctionnalité | Palier | Pourquoi là et pas ailleurs |
|---|---|---|
| Emploi du temps | Prime | Inutile à une école de 6 classes qui connaît son horaire par cœur ; indispensable dès qu'il y a des vacations et des professeurs partagés. |
| Discipline | Prime | Demande un règlement écrit et un capital conduite tenu — pratique d'établissement structuré, pas de petite école. |
| Messages groupés | Prime | Coût réel (e-mails sortants) et valeur qui croît avec le nombre de parents. Le plafond d'e-mails par offre en est le corollaire honnête. |
| Site public | Prime | Une école qui publie ses résultats en ligne a franchi une étape de maturité ; c'est aussi le module le plus visible de l'extérieur, donc un vrai motif de montée en gamme. |
| Éditeur de modèles | Prime | Les modèles officiels RDC sont dans Ascension. Ce qui est en Prime, c'est la maquette **sur mesure** — un confort, pas une nécessité. |
| Comptabilité et paie | Pilote | Une école qui tient une caisse et paie des salaires a un comptable ; celle qui n'en a pas ne s'en servira jamais. Segmentation par usage réel, pas par restriction. |
| Concours, orientation, repêchage | Pilote | Trois procédures des établissements structurés, absentes du quotidien d'une école de 200 élèves. |
| Rapports avancés | Pilote | Le tableau de bord de base est dans les quatre offres. Ce qui monte ici, c'est l'analyse croisée. |
| WhatsApp | Infinite | Seule fonctionnalité à coût marginal par message. |

---

## D. Les services complémentaires

### 1. Installation & configuration — **60 $, forfait unique**

- **Objectif** — livrer une plateforme déjà conforme à l'organisation de l'école,
  plutôt qu'un formulaire vide.
- **Compris** — création de l'école et du compte Directeur ; année scolaire et
  périodes ; sections, options, classes, cours et coefficients ; système de
  notation, mentions, seuils de promotion et de redoublement ; grille des frais
  et devise de référence ; création des comptes du personnel ; vérification
  finale avec la direction.
- **Non compris** — la saisie des élèves (campagne de capture) et la formation.
- **Prérequis** — un abonnement actif, quel qu'il soit, et vos documents d'organisation.
- **Cible** — toute école qui démarre et préfère ne pas paramétrer elle-même.
- **Logique commerciale** — un revenu ponctuel adossé à chaque nouvelle école,
  sans dépendre du palier souscrit. Il abaisse la friction d'entrée : le
  directeur qui hésite parce qu'il « ne s'y connaît pas » a une réponse chiffrée.

> ⚠️ **Contradiction du cahier des charges à trancher.** Le § 5 indique
> « montant fixe de 60 $ » ; les § 16 et § 21 indiquent « à partir de 50 $ ».
> **J'ai retenu 60 $**, seule valeur donnée comme ferme, et je l'affiche sans
> « à partir de » puisque le forfait est unique. Le corriger ne demande aucun
> déploiement : c'est un champ modifiable depuis l'espace Super Admin.

### 2. Formation du personnel — **30 / 60 / 100 $**

| Formule | Prix | Durée | Ce qui la distingue |
|---|---|---|---|
| Express | 30 $ | ≈ 1 h 30 | Les gestes quotidiens seulement : connexion, notes, appel, un bulletin de bout en bout. |
| Complète | 60 $ | Une demi-journée | Tous les modules + les cas particuliers réels (élève arrivé en cours d'année, note contestée, période clôturée, bulletin bloqué pour impayé) + support écrit. |
| Personnalisée | 100 $ | Une journée | Étude préalable des circuits internes, sessions séparées par profil, exercices sur vos données, fiches de procédure à vos noms de rôles, séance de suivi. |

- **Cible** — équipes nombreuses, peu familières de l'informatique, ou
  établissements dont les procédures internes sont écrites.
- **Point commercial capital** — la formation **n'est pas** une fonctionnalité
  premium. Le didacticiel intégré, lui, est inclus dans les quatre offres. Ce
  qui se vend ici, ce sont des heures d'un formateur humain. Une école en
  Ascension achète la formation personnalisée à 100 $ : c'est écrit dans la
  FAQ, répété sur `services.html`, et vrai dans le code (aucun contrôle d'offre
  sur `/services`).

### 3. Campagne de capture — **0,50 $ par élève**

| Élèves | 100 | 300 | 500 | 1 000 | 2 000 |
|---|---|---|---|---|---|
| Coût | 50 $ | 150 $ | 250 $ | 500 $ | 1 000 $ |

Le terme « capture » ne dit rien à un directeur. Il est donc **défini** sur la
page, en six points explicites :

- **Ce qui est capturé** — nom, postnom, prénom, sexe, date et lieu de naissance,
  responsable et coordonnées, classe d'affectation, puis matricule et code
  d'accès attribués par la plateforme.
- **Comment ça marche** — récupération des registres → saisie → contrôle des
  doublons et incohérences → chargement dans Ardoise → liste de vérification
  remise à l'école.
- **Ce qu'Ardoise prend en charge** — les quatre étapes ci-dessus.
- **Ce qui reste à l'école** — fournir des registres lisibles, avoir un
  abonnement actif et des classes créées, relire et valider la liste.
- **Comment le nombre est compté** — sur les élèves **réellement saisis et
  chargés** à la fin, pas sur l'estimation de départ. Les doublons écartés ne
  sont pas facturés.
- **Quand c'est facturé** — après validation de la liste de vérification par
  l'école, donc après constat du travail fait.
- **Explicitement exclu** — photographie des élèves, numérisation des pièces
  d'état civil, reprise des notes antérieures.

> **Aucune promesse opérationnelle inventée.** Les délais sont donnés comme
> *indicatifs* (« comptez une semaine pour 500 élèves »), il n'y a ni garantie
> de résultat, ni engagement de déplacement, ni SLA chiffré.

### Rentabilité des quatre sources de revenu

| Source | Nature | Rythme | Effet |
|---|---|---|---|
| Abonnements | Récurrent | Mensuel/semestriel/annuel | MRR, base de valorisation |
| Installation | Ponctuel | À l'entrée | Amortit le coût d'acquisition dès le premier mois |
| Formation | Ponctuel | À l'entrée + rentrées | Réduit le churn : une équipe formée reste |
| Campagne de capture | Au volume | À l'entrée surtout | Le plus gros ticket unitaire — une capture de 1 000 élèves rapporte 500 $, soit près de 8 mois d'Ascension |

**Illustration.** Une école de 500 élèves qui souscrit Prime en annuel et
commande installation + formation complète + capture :
590 + 60 + 60 + 250 = **960 $ la première année**, contre 590 $ sans services.
Le revenu de première année est multiplié par 1,6 — **sans qu'aucune
fonctionnalité ait été retirée de l'abonnement pour y arriver.**

**Garde-fou explicite.** Aucun service n'est présenté comme obligatoire, et la
page le dit trois fois. Le formulaire de contact propose de dire à l'école
*quels services lui seraient inutiles*. Un service vendu à une école qui n'en a
pas besoin coûte plus cher en réputation qu'il ne rapporte.

---

## E. Architecture technique

### Source de vérité unique

```
                    plans_abonnement            services_complementaires
                    (prix, limites, drapeaux)   (prix, mode de tarification)
                              │                            │
                              └────────────┬───────────────┘
                                           ▼
                            utils/catalogue.utils.js
                            « la seule chose qui sait »
                                           │
        ┌──────────────┬───────────────────┼──────────────┬────────────────┐
        ▼              ▼                   ▼              ▼                ▼
  /catalogue/*   middleware/offre    abonnements.ctrl  services.ctrl   ia.utils
  (site public)  (droits+plafonds)   (durée, /courant) (commandes)     (quota)
```

**Aucun prix, aucune limite, aucun nom d'offre n'est écrit dans le code.**
`catalogue.utils.js` contient le *vocabulaire* (quels codes de fonctionnalités
et de limites existent), jamais les *valeurs*.

### Modèle de données

**Abonnement** — table `plans_abonnement` étendue :

| Colonne | Rôle |
|---|---|
| `code` | identifiant stable (`ascension`…), désormais **UNIQUE** |
| `prix` | prix mensuel |
| `prix_semestriel` | **nouveau** — prix six mois |
| `prix_annuel` | prix douze mois (existait) |
| `limites` jsonb | **nouveau** — toutes les limites au même endroit |
| `fonctionnalites` jsonb | drapeaux booléens par code |
| `positionnement`, `cible` | **nouveaux** — argumentaire, éditable sans déploiement |

Table `abonnements` : la contrainte `periodicite` accepte maintenant
`semestriel` (elle le **refusait**, cf. § J).

**Service** — deux tables neuves :

- `services_complementaires` — le catalogue : `code`, `categorie`
  (`installation` / `formation` / `capture`), `mode_tarification`
  (`forfait` / `par_eleve`), `prix_unitaire`, `inclus`, `exclus`, `prerequis`.
- `commandes_services` — ce qu'une école a commandé : quantité, **prix figé à la
  commande**, statut (`demandee` → `confirmee` → `planifiee` → `en_cours` →
  `realisee`, ou `annulee`), dates, facture éventuelle.
- `demandes_accompagnement` — les demandes du site public, quand l'école
  n'existe pas encore en base.

RLS posée sur les trois : catalogue lisible par tout compte authentifié et
modifiable par le seul Super Admin ; commandes cloisonnées par école ; demandes
publiques réservées au Super Admin.

### Contrôle des droits

Deux gardes, séparés de `requireRole` :

```js
exigeFonctionnalite('comptabilite')      // → 402 { code: 'offre_insuffisante' }
verifierPlafond('max_eleves')            // → 402 { code: 'plafond_atteint' }
```

- **402 et non 403.** Le directeur *a* le droit ; il n'a pas souscrit le
  niveau. 403 dit le contraire, et le frontend ne peut pas les distinguer.
- **Jamais bloquant en cas de doute.** Aucun abonnement actif trouvé → on laisse
  passer avec des plafonds prudents. Suspendre une école est une décision
  commerciale explicite, pas l'effet de bord d'une requête vide.
- **Uniquement sur les ajouts.** Un plafond dépassé ne gèle jamais l'existant :
  les élèves déjà saisis restent modifiables, les bulletins générables.

### Où les verrous sont réellement posés

Un middleware écrit mais non branché ne protège rien. Voici la carte complète
de ce qui est verrouillé, et par quoi.

| Route | Verrou | Portée |
|---|---|---|
| `/comptabilite/*` (caisse) | `comptabilite` | routes de caisse et trésorerie |
| `/comptabilite/paie`, `/contrats` | `paie` | drapeau distinct, même palier |
| `/emploi-du-temps/*` | `emploi_du_temps` | routeur entier |
| `/discipline/*` | `discipline` | routeur entier |
| `/discipline/reglement/importer`, `/generer` | `ia_reglement_discipline` | en plus du précédent |
| `/inscriptions/*` | `concours_admission` | routeur entier |
| `/orientation/*` | `orientation` | routeur entier |
| `/repechage/*` | `repechage` | routeur entier |
| `/rapports/*` | `rapports_avances` | routeur entier |
| `/site-public/*` | `site_public` | **administration seulement** |
| `/whatsapp/journal` | `whatsapp` | **pas le webhook** |
| `/ia/decrochage`, `/ia/archives/recherche` | `ia_analyse_donnees` | deux routes, pas le routeur |
| `/modeles-bulletins` (POST, zones) | `modeles_personnalises` | **pas la lecture ni l'aperçu** |
| `/communication/envoyer` | `communication_masse` | **conditionnel** — voir ci-dessous |
| `/eleves` (POST, import) | plafond `max_eleves` | créations seulement |
| `/utilisateurs` (POST, import) | plafond `max_utilisateurs` | créations seulement |

**Trois verrous sont volontairement partiels**, parce qu'un `router.use()`
aurait retiré une fonctionnalité essentielle :

- **Communication.** `/envoyer` sert deux usages que l'URL ne distingue pas :
  le message interne entre membres du personnel — compris dans les quatre
  offres — et la diffusion aux parents. Un verrou global aurait coupé la
  messagerie interne d'une école en Ascension. Le garde lit donc la requête :
  cible `parents_classe`/`parents_ecole` ou canal `email` → verrou ; message
  interne → passe.
- **Modèles de bulletins.** Seules la création et la modification de maquettes
  sont verrouillées. Les modèles officiels RDC restent dans les quatre offres :
  les bloquer reviendrait à vendre un logiciel scolaire congolais qui n'imprime
  pas de bulletin congolais. Une école qui redescend d'offre continue d'imprimer
  avec sa maquette ; elle ne peut plus en créer.
- **WhatsApp.** Le webhook Meta reste ouvert — il n'a pas de jeton, vérifie sa
  propre signature HMAC, et un verrou d'offre y serait sans effet tout en
  cassant la validation de l'abonnement côté Meta.

**Et deux principes qui ne se voient pas dans le tableau :**

- Les plafonds portent sur les **ajouts**, jamais sur l'existant. Une école qui
  a dépassé son quota — reprise de données, changement d'offre en cours — garde
  l'usage complet de ce qu'elle a saisi.
- L'**IA d'assistance n'est verrouillée nulle part**. `/ia/quota`,
  `/ia/appreciations`, `/ia/question-eleve`, `/ia/conseil-classe`,
  `/ia/redaction`, `/ia/import/analyser` et `/ia/assistant/question` sont
  ouverts aux quatre offres. Ce qui monte en gamme, c'est le volume mensuel et
  deux capacités analytiques.

### Côté écran : ce que voit une école qui n'a pas souscrit

Le verrou serveur suffit à la sécurité, pas à l'expérience. Sans travail côté
interface, le directeur d'une école en Ascension voyait « Comptabilité » dans
son menu, cliquait, et recevait une erreur — dont il concluait que le logiciel
est cassé, pas que son offre ne comprend pas ce module.

Un module ajouté à la fin de `ui.js` fait deux choses :

1. il retire du menu les entrées que l'offre ne comprend pas — pas grisées,
   pas barrées : absentes ;
2. il intercepte les 402 restants (lien direct, favori, redirection) et affiche
   un message qui nomme ce qui manque, avec un chemin vers
   `parametres.html#details-abonnement`.

Placé dans `ui.js` et non dans un fichier séparé parce que les trente écrans de
l'application le chargent déjà : un trente-et-unième fichier aurait demandé
d'ajouter une balise `<script>` à trente pages, avec la certitude d'en oublier
une — et c'est sur celle-là que l'entrée morte serait restée.

**Limite assumée.** Les droits arrivent par le réseau, donc après la
construction du menu. Ils sont mis en cache dans `sessionStorage` et appliqués
immédiatement au chargement suivant : le menu est juste dès la deuxième page.
Après un changement d'offre, la première page affichée peut encore montrer
l'ancien menu. Le serveur, lui, est à jour immédiatement.

### Espace Super Admin

Les nouvelles données sont pilotables depuis l'interface, sans SQL :

| Champ | Où |
|---|---|
| Prix mensuel, **semestriel**, annuel | bouton « Changer le prix », avec motif et historique |
| Positionnement, cible | formulaire « Modifier » |
| Six plafonds (élèves, comptes, classes, quota IA, archives, stockage, e-mails) | formulaire « Modifier » |
| Drapeaux de fonctionnalités | API `PATCH /super-admin/offres/:id`, champ `fonctionnalites` |

Deux garde-fous côté serveur : une clé de limite inconnue est **refusée** (sans
quoi saisir `max_classe` sans « s » donnerait une offre qui paraît configurée
et ne l'est pas), et un code de fonctionnalité absent de `catalogue.utils.js`
est refusé avec le message « une fonctionnalité doit d'abord exister dans le
code pour pouvoir être vendue ».

### Le cache, et pourquoi il fallait l'invalider à cinq endroits

L'offre d'une école est mise en cache 60 secondes — sans quoi chaque requête de
chaque page interrogerait `plans_abonnement`. Cinq écritures doivent donc le
vider, et trois l'oubliaient :

| Écriture | État |
|---|---|
| Confirmation de paiement (Super Admin) | ajoutée dès la première version |
| Modification d'offre / de prix | ajoutée dès la première version |
| **Changement de plan d'une école** | **oubliée** — une école passée en Pilote se voyait refuser la comptabilité pendant une minute |
| **Paiement Mobile Money confirmé** | **oubliée** — même effet sur le chemin le plus emprunté |
| **Job d'expiration nocturne** | **oubliée** — droits d'un abonnement expiré maintenus une minute |

### Ce qui n'a **pas** été reconstruit

Factures, paiements, PawaPay, promotions, offres spéciales, tarifs négociés,
historique des prix, centre Finance du Super Admin : **intacts**. La migration
028 n'ajoute que des colonnes et des tables, ne renomme rien, ne supprime rien,
et est idempotente.

---

## F. Landing page — sections

### `index.html` (refonte complète)

| # | Section | Rôle |
|---|---|---|
| 1 | Hero | Quoi / pour qui / pourquoi + **schéma des deux étages** |
| 2 | Bandeau de repères | 4 faits vérifiables (rôles, double devise, hors ligne, bulletins RDC) |
| 3 | Problèmes → réponses | 6 cartes partant du problème vécu, pas de la fonctionnalité |
| 4 | Intelligence artificielle | 4 paliers d'IA + note de pseudonymisation |
| 5 | Mise en route | 4 étapes, avec le service correspondant nommé à chaque fois |
| 6 | **Étage 1 — les offres** | Sélecteur Mensuel/Semestriel/Annuel + 4 cartes |
| 7 | **Étage 2 — les services** | Rappel de séparation *avant* les prix + 3 cartes |
| 8 | Simulateur de campagne | Curseur + champ, résultat confirmé par le serveur |
| 9 | Sécurité | Cloisonnement, rôles, traçabilité, hors ligne |
| 10 | FAQ | 11 questions, groupées Abonnements / Services / IA |
| 11 | Formulaire d'accompagnement | Écrit dans `demandes_accompagnement` |
| 12 | CTA final + pied de page | |

### `tarifs.html` (nouvelle page)

Sélecteur de périodicité, 4 cartes détaillées ancrées (`#ascension`…),
rappel de séparation, **comparatif de 40 lignes en 6 groupes** dont le premier
ne contient que des ✓, FAQ tarifaire de 6 questions.

### `services.html` (nouvelle page)

Une section par service, avec pour chacun : ce qui est compris / ce qui reste à
l'école / ce qui n'est pas compris. Trois formules de formation comparées.
Simulateur + table d'exemples. FAQ de 6 questions.

### Design

Palette existante conservée (ardoise, craie, ocre, encre) — c'est l'identité du
produit, pas un exercice de style. **Signature visuelle :** le papier réglé du
cahier d'écolier en mode clair, le tableau noir en mode sombre. **Prix composés
en IBM Plex Mono :** un tarif est une écriture de registre, pas un titre.

Mobile-first, 9 points de rupture, mode clair/sombre (préférence système +
bascule mémorisée), focus visible, `prefers-reduced-motion` respecté, tableau
comparatif défilable avec en-têtes figées.

---

## G. SEO

### Balises

| Page | Title | Longueur |
|---|---|---|
| `/` | Logiciel de gestion scolaire pour les écoles de la RDC — Ardoise | 63 |
| `/tarifs.html` | Tarifs — Ardoise Ascension, Prime, Pilote et Infinite | 52 |
| `/services.html` | Accompagnement — installation, formation et capture — Ardoise | 60 |

**Meta descriptions** (110–175 caractères, toutes vérifiées) :

- `/` — « Élèves, notes, bulletins officiels, présences et frais scolaires en une
  seule plateforme, conçue pour les écoles de la RDC. À partir de 35 $ par mois. »
- `/tarifs.html` — « Les quatre offres d'Ardoise, de 35 à 159 $ par mois. Deux
  mois offerts au paiement annuel. Comparatif ligne par ligne des fonctionnalités
  et des limites. »
- `/services.html` — « Installation et configuration de votre école (60 $),
  formation du personnel (30 à 100 $), campagne de capture des données élèves
  (0,50 $ par élève). Optionnels. »

### Hiérarchie

**H1 unique par page**, vérifié automatiquement :

- `/` → « Le logiciel qui fait tourner **votre école**, du registre au bulletin. »
- `/tarifs.html` → « Le niveau qui correspond à votre école, pas celui qu'on vous impose »
- `/services.html` → « Nous pouvons faire le travail d'installation à votre place »

H2 de la page d'accueil : *Les six choses qui coûtent le plus de temps dans une
école* · *Présente dès la première offre, pas réservée à la dernière* · *De
l'inscription à la première proclamation* · *Quatre offres, un seul produit* ·
*Besoin d'un accompagnement supplémentaire ?* · *Les données d'une école ne
sortent pas de l'école* · *Ce que les directeurs demandent avant de signer* ·
*Demander un accompagnement*.

H3 : les noms de fonctionnalités et de services. **Aucun saut de niveau** dans
les trois pages (vérifié).

### Données structurées

- `SoftwareApplication` + 4 `Offer` (35 / 59 / 99 / 199 USD) — page d'accueil
- `Organization` avec `areaServed: RDC`
- `FAQPage` — 6 questions sur `/`, 3 sur `/services.html`
- `BreadcrumbList` — `/tarifs.html` et `/services.html`
- `ItemList` de 4 `Product` avec `AggregateOffer` (prix bas = tarif annuel mensualisé) — `/tarifs.html`
- 3 × `Service` avec `Offer` — `/services.html`

Tous les blocs JSON-LD sont **syntaxiquement validés**. Volontairement absents :
`AggregateRating` et `reviewCount` — un balisage qu'aucune page ne justifie
invite au déclassement.

### Technique

- `canonical` sur les trois pages · Open Graph + Twitter Card complets
- `robots.txt` : autorise les 4 pages publiques, **interdit les 37 écrans
  applicatifs** (ils ne rendent rien à un robot et pollueraient l'index)
- `sitemap.xml` : 4 URL, `lastmod` réels
- `preconnect` vers Google Fonts et l'API · `defer` sur le JS · CSS partagé et
  mis en cache · `Cache-Control: max-age=300, stale-while-revalidate=3600` sur
  les routes de catalogue

### Stratégie de mots-clés

Travaillés **dans des phrases**, jamais en liste : *logiciel de gestion
scolaire*, *plateforme de gestion scolaire*, *gestion scolaire RDC*, *bulletins
officiels RDC*, *logiciel scolaire Afrique francophone*, et pour les services
*configuration logiciel scolaire*, *formation du personnel scolaire*,
*digitalisation des données scolaires*, *saisie des registres scolaires*.

Aucune répétition mécanique : « logiciel de gestion scolaire » apparaît **3
fois** sur la page d'accueil (title, description, pied de page), pas trente.

---

## H. Fichiers

### Créés — backend (9)

| Fichier | Rôle |
|---|---|
| `migrations/028-catalogue-commercial.sql` | Périodicité semestrielle, `prix_semestriel`, `limites`, tables services, RLS, semis des 4 offres et 5 prestations |
| `utils/catalogue.utils.js` | **Source de vérité unique** |
| `middleware/offre.middleware.js` | `exigeFonctionnalite`, `verifierPlafond`, `chargerOffre` |
| `controllers/catalogue.controller.js` | Catalogue public sans jeton |
| `routes/catalogue.routes.js` | `/catalogue/*` avec limiteurs dédiés |
| `controllers/services.controller.js` | Commandes de services (école + Super Admin) |
| `routes/services.routes.js` | `/services/*` |
| `scripts/generer-tarifs-statiques.js` | Réécrit les prix du HTML depuis la base, mode `--verifier` pour la CI |
| `test/catalogue.test.js` | 13 tests sur les calculs |
| `test/offre-middleware.test.js` | 15 tests sur les décisions de verrou |

### Modifiés — backend (6)

| Fichier | Modification |
|---|---|
| `server.js` | Monte `/catalogue` **avant** le verrou d'authentification, `/services` après |
| `utils/ia.utils.js` | Quota IA lu dans `limites`, **repli sur l'ancienne clé** (2 requêtes) |
| `controllers/abonnements.controller.js` | Durée par périodicité (correctif majeur, § J) ; `/courant` renvoie limites, droits et consommation ; invalidation du cache |
| `routes/eleves.routes.js` | `verifierPlafond('max_eleves')` sur création et import |
| `routes/utilisateurs.routes.js` | `verifierPlafond('max_utilisateurs')` idem |
| `routes/super-admin.routes.js` | `/super-admin/services/commandes` |
| `controllers/super-admin-offres.controller.js` | Prix semestriel, limites, positionnement et cible modifiables ; invalidation du cache catalogue |
| `controllers/paiements.controller.js` | Durée Mobile Money par périodicité et depuis l'échéance en cours ; invalidation |
| `controllers/ecoles.controller.js` | Invalidation après changement de plan |
| `controllers/jobs.controller.js` | Invalidation après expiration ou suspension |
| `routes/comptabilite.routes.js` | Verrous `comptabilite` et `paie` |
| `routes/inscriptions.routes.js` | Verrou `concours_admission` |
| `routes/orientation.routes.js` | Verrou `orientation` |
| `routes/repechage.routes.js` | Verrou `repechage` |
| `routes/emploi-du-temps.routes.js` | Verrou `emploi_du_temps` |
| `routes/discipline.routes.js` | Verrous `discipline` et `ia_reglement_discipline` |
| `routes/rapports.routes.js` | Verrou `rapports_avances` |
| `routes/site-public.routes.js` | Verrou `site_public` (administration seulement) |
| `routes/communication.routes.js` | Verrou **conditionnel** `communication_masse` |
| `routes/whatsapp.routes.js` | Verrou `whatsapp` sur le journal, webhook préservé |
| `routes/ia.routes.js` | Verrou `ia_analyse_donnees` sur deux routes |
| `routes/modeles-bulletins.routes.js` | Verrou `modeles_personnalises` sur la personnalisation |

### Créés — frontend (7)

`site.css` · `catalogue.js` · `index.html` (remplace l'ancien) · `tarifs.html` ·
`services.html` · `robots.txt` · `sitemap.xml`

### Modifiés — frontend (2)

| Fichier | Modification |
|---|---|
| `ui.js` | Module d'accès selon l'offre ajouté **à la fin** — les 1 567 lignes d'origine sont intactes |
| `super-admin-vues-offres.js` | Champs prix semestriel, positionnement, cible et six plafonds ; regroupement dans `limites` avant envoi ; trois prix et quota IA sur la carte d'offre |

---

## I. Fonctionnalités ajoutées

1. **Périodicité semestrielle** — annoncée commercialement, **refusée par la
   base** jusqu'ici (contrainte `CHECK`).
2. **Catalogue de services complémentaires** — n'existait sous aucune forme.
3. **Commandes de services** avec cycle de vie, prix figé, journalisation, et
   suivi Super Admin avec revenu par catégorie.
4. **Demandes d'accompagnement publiques** — formulaire du site, plafonné à 5/h/IP,
   codes de services et d'offres validés contre le catalogue.
5. **Application effective des plafonds** — `max_eleves`, `max_utilisateurs`,
   `max_classes` étaient stockés et **jamais vérifiés nulle part**.
5 bis. **Application effective des droits par offre** — treize routeurs portent
   désormais le verrou. Dans la première livraison, `exigeFonctionnalite()` était
   écrit, testé et documenté, mais branché sur **zéro route** : une école en
   Ascension pouvait ouvrir la comptabilité, les concours et l'orientation.
6. **API publique de catalogue** — 4 routes, sans jeton, limitées en débit.
7. **Simulateur de campagne de capture** — calcul serveur, repli local.
8. **Limites et droits dans `/abonnements/courant`** — le directeur voit ses
   plafonds et sa consommation *avant* de les heurter.
9. **Page tarifs et page services dédiées** — inexistantes.
10. **Mode clair/sombre** sur le site public.
11. **`robots.txt` et `sitemap.xml`** — absents du dépôt.
12. **Générateur de tarifs statiques** avec mode vérification pour la CI.
13. **Menu adapté à l'offre et refus lisibles** dans l'application (`ui.js`).
14. **Pilotage des limites et du prix semestriel** depuis l'espace Super Admin.

---

## J. Ce qui a été déplacé ou corrigé

### Déplacements conceptuels

| Élément | Avant | Après | Pourquoi |
|---|---|---|---|
| Quota IA | `fonctionnalites.ia_quota_mensuel` | `limites.ia_quota_mensuel` | Une limite parmi les limites. Ancienne clé lue en repli : rien ne casse. |
| Installation, formation, capture | Nulle part / implicitement « fonctionnalités premium » | Table dédiée, étage séparé | Ce sont des heures humaines, pas du logiciel. |
| Prix des offres | `plans_abonnement` + rien côté public | `plans_abonnement` → API → HTML régénérable | Une seule vérité, vérifiable en CI. |
| Limites | Colonnes ignorées par le code | `limites` jsonb, appliquées | Une limite qui n'est jamais vérifiée n'est pas une limite. |

### Trois défauts réels rencontrés en chemin

**1. Un abonnement annuel n'était prolongé que de 30 jours. (grave)**

`confirmerPaiement()` calculait la nouvelle échéance à partir de
`plans_abonnement.duree_jours`, qui vaut 30 pour toutes les offres. Une école
réglant l'année d'avance voyait sa plateforme expirer un mois plus tard. Le
défaut était invisible tant qu'une seule périodicité existait ; l'ajout du
semestriel le rendait certain.
→ La durée suit désormais `abonnements.periodicite` (30 / 91 / 182 / 365 jours),
avec repli sur `duree_jours`.

**2. La base refusait la périodicité semestrielle.**

La contrainte `CHECK` de `abonnements.periodicite` n'acceptait que
`mensuel`, `annuel`, `trimestriel`, `personnalise`. Toute la grille semestrielle
aurait échoué en erreur 23514.
→ Contrainte remplacée (et la même sur `tarifs_personnalises`).

**3. Aucun plafond n'était appliqué.**

`max_eleves` et `max_utilisateurs` existaient depuis l'origine et n'étaient
lus par aucun contrôleur. Une école en Ascension pouvait saisir 4 000 élèves.
→ `verifierPlafond` posé sur les créations et les imports, uniquement.

**4. Le paiement Mobile Money avait les deux mêmes défauts. (grave)**

`paiements.controller.js` — le chemin de paiement le PLUS emprunté, puisque
c'est celui que le directeur déclenche lui-même — calculait sa nouvelle
échéance avec `Date.now() + duree_jours`. Deux conséquences cumulées : un
règlement annuel ne prolongeait que de 30 jours, et un renouvellement anticipé
effaçait le temps déjà payé. Corrigé de la même manière que le chemin manuel.

**5. Trois écritures oubliaient d'invalider le cache du catalogue.**

Une école passée en Pilote se voyait refuser la comptabilité pendant une
minute — exactement le moment où le directeur appelle le support. Détail
trouvé en écrivant les tests de comportement : le premier scénario « école en
Pilote » échouait, et ce n'était pas le test qui avait tort.

**6. Trois fonctionnalités annoncées n'existaient pas.**

Voir l'encadré d'Ardoise Infinite en § B. Détectées par le test de cohérence
qui vérifie que tout drapeau vendable est appliqué quelque part.

**7. Une ancre inexistante dans le lien de secours.**

Le message de refus renvoyait vers `parametres.html#abonnement`, qui n'existe
pas : la page se serait ouverte en haut et le directeur aurait cherché son
abonnement au milieu de dix autres réglages. L'identifiant réel est
`#details-abonnement`.

### Décisions commerciales appliquées

Les deux recommandations R1 et R9 du premier rapport ont été validées et sont
désormais en production. **Migration `029-grille-tarifaire-harmonisee.sql`.**

#### 1. Une règle de remise unique pour les quatre offres

L'ancienne grille accordait des remises qui variaient de 7,4 % à 16,7 % selon
l'offre — et c'était la MOINS chère qui accordait la plus forte :

| Offre | Remise semestrielle | Remise annuelle |
|---|---|---|
| Ascension | 9,5 % | **16,7 %** |
| Prime | 5,4 % | 9,6 % |
| Pilote | **4,0 %** | **7,4 %** |
| Infinite | 7,0 % | 12,1 % |

Un directeur qui compare voyait donc que passer d'Ascension à Pilote lui faisait
perdre plus de la moitié de son avantage annuel : on pénalisait exactement la
montée en gamme qu'on cherche à encourager. Et aucune phrase simple ne pouvait
décrire cette grille — le signe le plus fiable qu'une grille est fausse.

**Nouvelle règle, identique pour les quatre offres :**

> **le semestriel vaut 5,5 mensualités — un demi-mois offert.**
> **l'annuel vaut 10 mensualités — deux mois offerts.**

Le demi-dollar est arrondi au supérieur (192,50 → 193). Sans cet arrondi,
Ascension afficherait 9 % et les trois autres 8 % : l'incohérence rentrerait par
la porte de derrière.

L'argumentaire tient maintenant en une phrase — *« deux mois offerts si vous
payez l'année »* — et se vérifie à la calculatrice, ce qui compte davantage
qu'un pourcentage devant un directeur d'école.

#### 2. Ardoise Infinite passe de 199 à 159 $/mois

L'échelle de montée en gamme était régulière jusqu'à Pilote, puis doublait :

| Marche | Avant | Après |
|---|---|---|
| Ascension → Prime | ×1,69 | ×1,69 |
| Prime → Pilote | ×1,68 | ×1,68 |
| **Pilote → Infinite** | **×2,01** | **×1,61** |

Concrètement, un établissement de 1 600 élèves payait 100 $ de plus par mois
pour 100 élèves au-delà du plafond de Pilote. L'écart s'était encore creusé
quand trois arguments d'Infinite ont dû être retirés faute d'exister réellement
(§ B). Le surcoût du dépassement de plafond passe de 100 à 60 $ par mois.

#### La grille en vigueur

| Offre | Mensuel | Semestriel | par mois | Annuel | par mois |
|---|---|---|---|---|---|
| Ascension | 35 $ | **193 $** | 32,17 $ | **350 $** | 29,17 $ |
| Prime | 59 $ | **325 $** | 54,17 $ | **590 $** | 49,17 $ |
| Pilote | 99 $ | **545 $** | 90,83 $ | **990 $** | 82,50 $ |
| Infinite | **159 $** | **875 $** | 145,83 $ | **1 590 $** | 132,50 $ |

Remise affichée : **8 % au semestre et 17 % à l'année, sur les quatre offres.**

#### Ce que cela change pour les écoles déjà abonnées

| Offre | Mensuel | Semestriel | Annuel |
|---|---|---|---|
| Ascension | inchangé | 190 → 193 (+3) | inchangé |
| Prime | inchangé | 335 → 325 (−10) | 640 → 590 (−50) |
| Pilote | inchangé | 570 → 545 (−25) | 1 100 → 990 (−110) |
| Infinite | 199 → 159 (−40) | 1 110 → 875 (−235) | 2 100 → 1 590 (−510) |

Toutes les variations vont dans le sens de la baisse, **sauf le semestriel
d'Ascension (+3 $)** — périodicité qu'aucune école ne peut avoir souscrite,
puisque la contrainte de base la refusait avant la migration 028 (§ J.2).

Les écoles dont l'abonnement porte un `prix_applique` figé, ou qui bénéficient
d'un tarif négocié, ne sont pas touchées : elles gardent leur prix jusqu'à leur
prochain renouvellement.

#### Traçabilité

La migration **n'écrase pas les anciens prix en silence**. Elle inscrit chaque
changement dans `plan_prix_historique` — l'ancienne et la nouvelle valeur pour
les trois périodicités, le nombre d'écoles concernées et l'impact MRR estimé —
exactement comme le fait le bouton « Changer le prix » du Super Admin. Deux
colonnes manquaient à cette table (`ancien_prix_semestriel`,
`nouveau_prix_semestriel`) : sans elles, la trace aurait dit « Infinite :
199 → 159 » sans mentionner que le semestriel passait de 1 110 à 875, soit la
plus grosse variation de la journée en valeur absolue.

Le semis de la migration 028 pose désormais directement les valeurs
définitives : une installation neuve ne doit pas afficher un prix qu'on corrige
à la migration suivante.

#### Une remarque sur l'impact

Le manque à gagner porte presque entièrement sur les paliers hauts et sur
l'annuel. Sur une école Infinite payant à l'année, il atteint 510 $ — soit 24 %.
C'est un vrai coût, et il n'est justifié que si deux choses se produisent :
davantage d'écoles choisissent l'annuel (la trésorerie encaissée à la rentrée
compense largement la remise), et l'écart Pilote → Infinite cesse de bloquer les
établissements de 1 500 à 2 000 élèves. **Ces deux effets se mesurent** :
R11 propose l'instrumentation qui permettra de vérifier, dans six mois, si la
décision était la bonne — plutôt que d'en débattre.

## K. Tests

### Automatisés — **28/28 ✓**

```
node --test test/catalogue.test.js test/offre-middleware.test.js
```

#### `catalogue.test.js` — les calculs (13 tests)

| Test | Vérifie |
|---|---|
| Grille de capture | 100→50, 300→150, 500→250, 1 000→500, 2 000→1 000 $ |
| Décimales | 250,7 élèves → 125 $ (tronqué, au bénéfice de l'école) |
| Quantités invalides | 0, négatif, texte, `null` → refusés, jamais facturés |
| Forfait | quantité envoyée par le client **ignorée** (sinon `quantite=0` → 0 $) |
| Quantité minimum | facturée sans fausser la quantité déclarée |
| Durées | 30 / 182 / 365 jours selon la périodicité |
| Durée inconnue | repli sur le plan, jamais zéro |
| Économies | les 8 valeurs de la grille recalculées |
| Prix incohérent | annuel > 12 × mensuel → remise affichée **0**, jamais négative |
| **Fonctionnalités essentielles** | `notes`, `bulletins`, `eleves`, `presences`, `frais`… **absentes** de la liste des fonctionnalités verrouillables — le test échoue si quelqu'un tente de les y ajouter |
| Limites | chaque limite a un libellé et un repli chiffré strictement positif |
| Repli sans offre | permissif sur les droits, prudent sur les volumes |
| Périodicités | les trois, dans l'ordre |

#### `offre-middleware.test.js` — les décisions (15 tests)

| Test | Vérifie |
|---|---|
| Module non souscrit | 402 + `code: 'offre_insuffisante'` + nom de la fonctionnalité exploitable par le frontend |
| Module souscrit | les 8 modules de Pilote passent |
| Au-dessus de Pilote | WhatsApp reste fermé |
| **IA d'assistance en Ascension** | `assistant_aide` et `ia_appreciations` passent dans l'offre la plus modeste |
| Sans abonnement actif | **laisse passer** — une panne de facturation ne coupe pas les modules la veille des bulletins |
| Super Admin sans école | jamais arrêté |
| Code inconnu | échoue au **démarrage**, pas à la requête — une faute de frappe doit casser le déploiement, pas s'installer en « toujours refusé » silencieux |
| Sous le plafond | 241ᵉ élève sur 250 : passe |
| Import qui déborde | refusé **avant** d'écrire, avec plafond, effectif et restant chiffrés |
| Comptage au lot | un fichier de 400 élèves est refusé sur un plafond de 250 |
| Plafond `null` | = sans limite, testé à 50 000 élèves |
| Repli sans abonnement | plafonne à 250 sans fermer |
| Cohérence comptages | chaque plafond a sa requête ; une limite sans comptage est refusée explicitement |
| **Verrous branchés** | au moins 10 `exigeFonctionnalite()` dans les routes, tous avec un code existant — ce test aurait échoué sur la première livraison |
| **Aucune promesse creuse** | tout drapeau vendable est appliqué quelque part, sauf trois exceptions listées avec leur raison |

Les deux derniers sont les plus utiles : ce sont eux qui ont détecté que les
verrous n'étaient branchés nulle part, puis que `ia_traitements_masse` était
vendu sans exister.

### Vérifications automatisées sur les livrables

| Contrôle | Résultat |
|---|---|
| Syntaxe JS (30 fichiers backend + 4 frontend) | ✓ |
| Chargement des **41 routeurs** du serveur | ✓ |
| Résolution des `require` en conditions réelles | ✓ |
| JSON-LD des 3 pages | ✓ valide |
| H1 unique par page | ✓ |
| Aucun saut de niveau de titres | ✓ |
| Longueurs title (30–70) et description (110–175) | ✓ |
| Balises ouvertes/fermées (`section`, `article`, `div`, `table`, `details`, `form`, `header`, `footer`, `main`) | ✓ |
| `sitemap.xml` bien formé | ✓ |
| CSS : 190 accolades ouvrantes / 190 fermantes | ✓ |
| Classes HTML sans définition CSS | **aucune** |
| Prix HTML ↔ grille officielle (4 offres × 3 périodicités × 2 pages) | ✓ 24/24 |
| Économies et prix mensualisés recalculés depuis le HTML | ✓ |
| Semis SQL ↔ grille officielle | ✓ |
| Les 5 services présents dans le semis | ✓ |
| Ressources référencées existantes | ✓ |

### Non testable dans cet environnement (réseau désactivé)

Les points suivants demandent la base de données et un navigateur, et doivent
être vérifiés à la mise en service :

1. Exécution réelle de la migration 028 (elle est idempotente et transactionnelle).
2. Souscription mensuelle / semestrielle / annuelle de bout en bout, avec
   contrôle de la date d'expiration (+30 / +182 / +365 jours).
3. Changement d'offre dans les deux sens, sans perte de données.
4. Franchissement du plafond d'élèves → 402 `plafond_atteint`. *(comportement
   déjà vérifié sur base simulée, reste à confirmer sur la vraie base)*
5. Accès à `/comptabilite` en Prime → 402 `offre_insuffisante`. *(idem)*
5 bis. Messagerie interne du personnel en Ascension → doit **passer** ; diffusion
   aux parents depuis la même école → doit être refusée. C'est le verrou
   conditionnel, le plus délicat des treize.
5 ter. Impression d'un bulletin officiel RDC en Ascension → doit **passer**.
6. Consommation du quota IA jusqu'à 429.
7. Commande d'un service depuis une école en Ascension → doit **réussir**.
8. Rendu sur mobile / tablette / bureau, en clair et en sombre.
9. Google Rich Results Test sur les trois pages.
10. Onboarding d'une école neuve — le didacticiel existant n'a **pas été touché**.
11. Menu d'une école en Ascension : « Comptabilité », « Concours », « Orientation »,
    « Repêchage », « Rapports », « Emploi du temps », « Discipline » et
    « Générateur de modèles » doivent être absents.
12. Modification d'un plafond depuis l'espace Super Admin, puis vérification que
    le serveur l'applique réellement à la création suivante.

---

## L. Recommandations commerciales

**R1 et R9 — appliquées.** *(migration 029, voir § J)*
L'échelle des remises est harmonisée — deux mois offerts à l'année, un demi-mois
au semestre, pour les quatre offres — et Ardoise Infinite passe de 199 à
159 $/mois. Ce qui reste à surveiller figure en R1 bis ci-dessous.

**R1 bis — Vérifier dans six mois que la baisse a produit son effet.**
*(priorité haute)*
La nouvelle grille coûte jusqu'à 510 $ par an et par école Infinite. Elle n'est
justifiée que si deux choses se produisent : une part significative d'écoles
bascule vers l'annuel, et des établissements de 1 500 à 2 000 élèves cessent de
rester bloqués sur Pilote. Deux chiffres à relever :

- répartition mensuel / semestriel / annuel des nouvelles souscriptions ;
- nombre d'écoles Pilote à plus de 90 % de leur plafond d'élèves, et combien
  sont passées à Infinite.

Si aucun des deux ne bouge après deux trimestres, la baisse aura simplement
réduit la marge et il faudra la reprendre — ce qui est bien plus facile à
défendre avec des chiffres qu'avec une intuition.

**R2 — L'écart Pilote → Infinite reste à surveiller, même réduit.**
Le surcoût du dépassement de plafond passe de 100 à 60 $ par mois, ce qui rend
la marche défendable pour un établissement de 2 000 élèves. Elle l'est moins à
1 600. Si R1 bis montre que le blocage persiste, deux pistes : un dépassement
facturé à l'élève au-delà de 1 500 sur Pilote, ou un relèvement du plafond de
Pilote à 2 000 avec un ajustement de prix correspondant.

**R2 bis — Infinite reste un peu court en arguments.**
Après le retrait des trois fonctionnalités inexistantes, il repose sur les
volumes illimités, WhatsApp, les archives illimitées, 5 000 générations IA et le
support prioritaire. Les sauvegardes déclenchées par l'école sont le complément
le moins coûteux à construire : la table `sauvegardes` et le mécanisme existent
déjà côté Super Admin, il n'y manque qu'une route et un bouton. Le réseau
d'établissements est le plus vendeur et le plus lourd — il touche au
cloisonnement multi-tenant, donc à la partie la plus sensible du code.

**R3 — Le prix d'installation à 60 $ est probablement sous-évalué.**
Le paramétrage complet d'une école représente plusieurs heures de travail
qualifié. 60 $ le rend attractif mais peu rentable en direct ; sa vraie valeur
est d'écarter l'objection « je ne saurai pas le configurer ». Le garder comme
produit d'appel est défendable — mais l'assumer comme tel, pas le croire rentable.

**R4 — Vendre un forfait de démarrage.**
Installation + formation complète + capture est l'enchaînement naturel. Un
« Démarrage clé en main » à 110 $ au lieu de 120 $ (installation + formation
complète) augmenterait le panier moyen sans créer de nouvelle prestation.

**R5 — Le plafond de 12 classes en Ascension mérite un réexamen.**
Une école primaire de 250 élèves peut avoir 12 classes de 20 ou 6 de 40. Le
plafond risque de se déclencher avant celui des élèves, sur un critère que le
directeur ne comprendra pas. Passer à 20 classes réduirait ce frottement sans
rien coûter.

**R6 — Mesurer le taux de refus par plafond.**
Chaque 402 `plafond_atteint` est un signal de vente qualifié : une école qui
bute sur son plafond est prête à monter. Compteur suggéré dans le centre
Finance : *écoles à plus de 80 % de leur plafond d'élèves*.

**R7 — Publier la disponibilité et le journal des versions.**
Les écoles congolaises ont été échaudées par des logiciels abandonnés. Une page
de statut et un journal des mises à jour valent plus qu'un argumentaire.

**R8 — Ajouter les témoignages quand ils existeront.**
Le site ne contient aucun chiffre de clients ni de satisfaction, volontairement.
Dès qu'une école accepte d'être citée, un témoignage nommé vaut plus que dix
arguments — et le balisage `Review` devient alors légitime.

**R9 — Brancher `generer-tarifs-statiques.js --verifier` sur la CI.**
Une modification de prix en base non répercutée sur le site fera échouer le
déploiement, au lieu de tromper les visiteurs pendant six mois.

**R10 — Faire tourner `test/offre-middleware.test.js` à chaque déploiement.**
Ses deux derniers tests sont des garde-fous de conception, pas des tests
fonctionnels : l'un vérifie que les verrous sont effectivement branchés, l'autre
qu'aucune fonctionnalité n'est vendue sans exister. Les deux ont détecté un
défaut réel pendant cette mission. Sans eux dans la CI, ces défauts reviendront
à la première refonte de routes.

**R11 — Instrumenter les refus.**
Chaque 402 est un signal commercial : `offre_insuffisante` dit quel module une
école a essayé d'ouvrir sans l'avoir, `plafond_atteint` dit qu'elle est prête à
monter. Les compter par école et par code donnerait la première liste d'appels
vraiment qualifiée — et dirait aussi, en creux, quels verrous frustrent des
écoles sans jamais rien déclencher. Un verrou qui produit beaucoup de refus et
aucune montée en gamme est un verrou mal placé.

---

## Mise en service

```bash
# 1. Migrations, dans cet ordre (idempotentes, transactionnelles, ne suppriment rien)
psql "$DATABASE_URL" -f migrations/028-catalogue-commercial.sql
psql "$DATABASE_URL" -f migrations/029-grille-tarifaire-harmonisee.sql

# 2. Vérification de la grille — attendu : 8 et 17 sur les quatre lignes
psql "$DATABASE_URL" -c "SELECT code, prix, prix_semestriel, prix_annuel,
     round((prix*6  - prix_semestriel)/(prix*6) *100) AS remise_sem_pct,
     round((prix*12 - prix_annuel)    /(prix*12)*100) AS remise_ann_pct,
     limites->>'max_eleves' AS eleves
     FROM plans_abonnement WHERE statut='actif' ORDER BY ordre_affichage;"

# 2 bis. Trace du changement de prix
psql "$DATABASE_URL" -c "SELECT p.code, h.ancien_prix, h.nouveau_prix,
     h.ancien_prix_semestriel, h.nouveau_prix_semestriel,
     h.ecoles_impactees, h.impact_mrr_estime
     FROM plan_prix_historique h JOIN plans_abonnement p ON p.id=h.plan_id
     WHERE h.date_application = CURRENT_DATE ORDER BY p.ordre_affichage;"

# 3. Tests — 30 doivent passer
node --test test/catalogue.test.js test/offre-middleware.test.js

# 4. Déploiement backend, puis contrôle des routes publiques
curl https://scolaire-saas-backend.onrender.com/catalogue/offres
curl "https://scolaire-saas-backend.onrender.com/catalogue/estimation?service=campagne_capture&quantite=500"

# 5. Frontend : copier site.css, catalogue.js, index.html, tarifs.html,
#    services.html, robots.txt, sitemap.xml, ui.js et
#    super-admin-vues-offres.js à la racine du dépôt

# 6. Aligner les prix du HTML sur la base
node scripts/generer-tarifs-statiques.js ../Scolaire-HTML-main --verifier
```

**Rien n'a été supprimé.** Trois fichiers sont remplacés — `index.html`,
`ui.js`, `super-admin-vues-offres.js` — conservez-en une copie si vous souhaitez
pouvoir revenir en arrière. `ui.js` est identique à l'original jusqu'à sa ligne
1 567 ; tout l'ajout est en fin de fichier.

### Vérification rapide après déploiement

```bash
# Le verrou répond bien 402 et non 403 ni 500
curl -i -H "Authorization: Bearer <jeton d'une école en Ascension>" \
     https://scolaire-saas-backend.onrender.com/comptabilite/tresorerie
# attendu : HTTP/1.1 402  {"code":"offre_insuffisante", ...}

# Le cœur du métier reste ouvert dans la même école
curl -i -H "Authorization: Bearer <même jeton>" \
     https://scolaire-saas-backend.onrender.com/eleves
# attendu : HTTP/1.1 200
```

Le second appel est le plus important des deux : c'est celui qui prouve qu'on
n'a rien cassé en verrouillant.
