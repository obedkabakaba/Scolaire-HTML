# Ardoise — Extension Super Admin : Finance, Offres, Coûts & Gestion commerciale

**Rapport de livraison** · 12 fichiers · 8 100 lignes · aucune fonctionnalité existante retirée ou modifiée.

---

## 1. Ce qui a été ajouté

Un centre financier complet, greffé sur l'espace Super Admin existant, organisé en trois branches :

| Branche | Contenu |
|---|---|
| **💰 Finance** | Tableau de bord financier · rentabilité par offre et par école · seuil de rentabilité simulable · prévisions à 3/6/12/24 mois · alertes · coût des fonctionnalités · journal financier · exports · permissions |
| **💳 Offres & tarification** | Grille d'offres configurable · changement de prix tracé avec impact calculé · historique des prix · promotions · offres spéciales · tarifs négociés par école · abonnements clients (prix catalogue vs prix payé) |
| **🧾 Services & coûts** | Catalogue des services externes · consommations variables mensuelles · dépenses avec justificatifs · budgets prévu/réel · taux de change · calendrier de facturation |

**Trois principes ont gouverné l'écriture :**

1. **Aucun nom d'offre, aucun fournisseur en dur.** « Ascension », « Prime », « Pilote », « Infinite », « Supabase », « Render », « OpenAI » n'apparaissent nulle part dans le code ni dans la migration. Ce sont des lignes de tables, créées depuis l'interface. Renommer une offre ou changer d'hébergeur ne demande aucun déploiement.
2. **Aucune donnée inventée.** Quand une valeur n'existe pas, elle vaut `null`, l'écran affiche « à renseigner », et un bloc `donnees_manquantes` explique quoi saisir et où. Un tableau de bord financier garni de chiffres plausibles mais faux est plus dangereux qu'un tableau de bord vide : on prend des décisions dessus.
3. **On archive, on ne supprime pas.** Il n'existe **aucune route DELETE** dans cette extension. Offres, promotions, dépenses, tarifs : tout se désactive, s'archive ou se termine, avec motif et traçabilité.

---

## 2. Fichiers créés

### Backend (7 fichiers)

| Fichier | Lignes | Rôle |
|---|---|---|
| `migrations/027-finance-offres-couts.sql` | 669 | Schéma : extensions + 11 tables + RLS + droits + configuration |
| `utils/finance.utils.js` | 293 | Conversion de devises, mensualisation, journalisation, validation |
| `middleware/finance.middleware.js` | 144 | Niveau d'accès financier, garde d'écriture, confirmation |
| `controllers/super-admin-offres.controller.js` | 1 154 | Offres, prix, promotions, offres spéciales, tarifs négociés, abonnements |
| `controllers/super-admin-couts.controller.js` | 971 | Services, consommations, dépenses, budgets, taux, calendrier |
| `controllers/super-admin-finance.controller.js` | 1 453 | Tableau de bord, rentabilité, seuil, prévisions, alertes, journal, exports |
| `routes/super-admin-finance.routes.js` | 122 | 42 routes, montées sous `/super-admin` |

### Frontend (4 fichiers)

| Fichier | Lignes | Rôle |
|---|---|---|
| `super-admin-vues-finance.js` | 789 | 9 vues du centre Finance |
| `super-admin-vues-offres.js` | 876 | 6 vues Offres + fabrique de formulaires partagée |
| `super-admin-vues-couts.js` | 716 | 5 vues Services & coûts |
| `super-admin-styles-finance.css` | 216 | Classes additives (aucune redéfinition) |

**Tous les fichiers frontend vont à la racine du dépôt**, à côté de `super-admin.html` — c'est la convention du projet, et le contrôle d'installation intégré à la page la vérifie.

---

## 3. Fichiers modifiés

Deux fichiers seulement, en ajout pur.

**`routes/super-admin.routes.js`** — 12 lignes ajoutées avant `module.exports` :

```js
router.use('/', require('./super-admin-finance.routes'));
```

Monté **en dernier**, pour deux raisons : le routeur hérite du `router.use(authMiddleware, superAdminSeul)` posé en tête du fichier (une seule porte d'entrée, comme pour le reste), et aucune de ses routes ne peut masquer une route existante puisqu'elles sont toutes déclarées avant lui. Aucune ligne existante n'a été touchée.

**`super-admin.html`** — quatre insertions, aucune suppression :
- le `<link>` vers `super-admin-styles-finance.css`, après la feuille principale ;
- trois groupes de menu repliables, insérés entre « Explorer » et « Analyses » ;
- trois `<script>` après les vues existantes — l'ordre compte : `super-admin-vues-finance.js` définit `SA.finance`, dont les deux autres se servent pour le formatage monétaire ;
- les trois nouveaux fichiers ajoutés à `SCRIPTS_REQUIS`, pour que le diagnostic d'installation existant les couvre aussi.

---

## 4. Base de données

### Tables existantes étendues (aucune recréée)

**`plans_abonnement`** — les offres existaient déjà ; on leur a ajouté ce qui manquait, en `ADD COLUMN IF NOT EXISTS` :
`code`, `description`, `prix_annuel`, `max_eleves`, `max_utilisateurs`, `fonctionnalites_incluses`, `fonctionnalites_exclues`, `statut`, `ordre_affichage`, `badge`, `couleur`, `texte_marketing`, `visible_public`, `archive_at`, `archive_par`, `created_at`, `updated_at`, `updated_by`.

**`abonnements`** — `prix_applique`, `devise_appliquee`, `periodicite`, `promotion_id`, `tarif_personnalise_id`.
Sans ces colonnes, le MRR ne pouvait être calculé qu'au prix catalogue : une école à qui l'on avait accordé 30 % de remise comptait pour son prix plein.

### Tables créées (11)

| Table | Rôle |
|---|---|
| `plan_prix_historique` | Chaque prix qu'une offre a porté, avec motif, écoles impactées et impact MRR. Jamais purgé. |
| `promotions_commerciales` | Codes promo et réductions. **Nommée ainsi et non `promotions`** : dans Ardoise, « promotion » désigne déjà le passage de classe d'un élève (`promotion.controller.js`). Deux sens dans un même schéma, c'est un contresens garanti à la première requête écrite par quelqu'un d'autre. |
| `offres_speciales` | Gestes commerciaux ponctuels, partenariats, lancements. |
| `tarifs_personnalises` | Prix négociés par école. Index unique partiel : **un seul tarif actif par école** — sinon le calcul du MRR devrait choisir arbitrairement lequel facturer. |
| `services_externes` | Catalogue des services (aucun n'est semé). |
| `services_consommations` | Une ligne par service et par mois. Unique `(service_id, periode)` : ressaisir corrige, cela n'empile pas. |
| `depenses` | Sorties d'argent + justificatifs. Colonnes d'archivage, jamais de DELETE. |
| `budgets` | Prévu par période et par catégorie. |
| `finance_taux_change` | Taux datés vers la devise de référence. |
| `journal_financier` | Audit avec ancienne valeur, nouvelle valeur, montant et motif. |
| `finance_acces` | Niveau d'accès financier par Super Admin. |

**Sécurité au niveau base :** les 11 tables ont `ENABLE` + `FORCE ROW LEVEL SECURITY` et une policy `super_admin_seul` (`current_setting('app.is_superadmin') = 'true'`). Les droits sont accordés à `ardoise_svc` si le rôle existe (migration 024), et **explicitement révoqués pour `ia_lecture`** — l'assistant IA ne doit jamais pouvoir raconter à une école la marge qu'elle rapporte ni la remise obtenue par sa voisine.

**Configuration :** 7 clés semées dans `configuration_plateforme` (catégorie `finance`) plutôt que dans une nouvelle table de réglages — l'écran d'édition existe déjà : devise de référence, seuil de marge faible, seuil de hausse des coûts API, préavis de renouvellement, seuil d'alerte budget, churn et croissance par défaut.

La migration est **idempotente** (tout en `IF NOT EXISTS` / `ON CONFLICT DO NOTHING`), tient dans **une seule transaction**, et ne contient **aucun DROP**.

---

## 5. Routes API — 42 routes sous `/super-admin`

**Finance (11)** — `GET /finance/tableau-de-bord` · `/finance/rentabilite` · `/finance/seuil-rentabilite` · `/finance/previsions` · `/finance/alertes` · `/finance/cout-fonctionnalites` · `/finance/journal` · `/finance/permissions` · `/finance/exports` · `/finance/exports/:rapport` · `PUT /finance/permissions/:utilisateurId`

**Offres & tarification (17)** — `GET|POST /offres` · `PATCH /offres/:id` · `POST /offres/:id/impact-prix` · `POST /offres/:id/prix` · `GET /offres/:id/historique-prix` · `POST /offres/:id/statut` · `GET|POST /promotions` · `PATCH /promotions/:id` · `GET|POST /offres-speciales` · `PATCH /offres-speciales/:id` · `GET|POST /tarifs-personnalises` · `POST /tarifs-personnalises/:id/terminer` · `GET /abonnements-detail`

**Services & coûts (14)** — `GET|POST /services` · `GET|PATCH /services/:id` · `PUT /services/:id/consommations` · `GET|POST /depenses` · `PATCH /depenses/:id` · `POST /depenses/:id/archiver` · `GET /budgets` · `PUT /budgets` · `GET|POST /taux-change` · `GET /calendrier-facturation`

La route historique `GET /super-admin/abonnements` reste en place, inchangée, et continue d'alimenter l'écran existant. `abonnements-detail` la complète sans la remplacer.

---

## 6. Permissions

La mission demande deux profils. Ils sont implémentés **sans toucher au middleware d'authentification ni à l'ENUM `role_utilisateur`**.

| Profil | Ce qu'il peut faire |
|---|---|
| **Super Admin** (défaut) | Tout : lecture et écriture sur la gestion commerciale et financière |
| **Super Admin Support** | Lecture seule. Toute méthode d'écriture est refusée avec le code `FINANCE_LECTURE_SEULE` |

**Pourquoi une table (`finance_acces`) et pas un rôle ?** Trois raisons, dans l'ordre :

1. `superAdminSeul` filtre sur `req.auth.isSuperAdmin`. Un rôle `super_admin_support` n'entrerait même pas dans l'espace : il faudrait modifier le verrou le plus sensible de l'application pour une question de finances.
2. Ajouter une valeur à un ENUM PostgreSQL est **irréversible**. Le HANDOVER raconte déjà l'épisode de la migration 008, où deux valeurs ont dû être ajoutées d'un coup pour cette raison.
3. Un niveau d'accès se révoque en une ligne, sans migration.

**Absence de ligne = accès complet**, soit exactement le comportement d'avant l'extension : le Super Admin en place ne perd rien du jour au lendemain. La restriction est un acte explicite, posé depuis l'écran Permissions et journalisé.

Deux garde-fous complémentaires :
- **`financeEcriture` filtre sur la méthode HTTP, pas sur une liste de chemins.** Une route ajoutée demain sera protégée sans qu'on y pense — c'est précisément la propriété qu'on veut d'un garde-fou.
- **`exigerConfirmation`** est posé uniquement sur les 7 actions que la mission désigne comme sensibles (changement de prix, statut d'offre, création de promotion, tarif négocié, archivage de dépense, permissions). Le poser partout en ferait une formalité qu'on remplit sans lire, ce qui la viderait de son sens là où elle compte.
- Un Super Admin **ne peut pas se restreindre lui-même** : refus explicite plutôt que verrouillage silencieux hors de son propre outil.

---

## 7. Fonctionnalités terminées et opérationnelles

✅ Tableau de bord financier (CA mensuel/annuel/cumulé, MRR, ARR, coûts, bénéfice, marge, ARPU, courbes 12 mois)
✅ Création, modification, activation, désactivation et archivage des offres
✅ Changement de prix en deux temps : **simulation d'impact calculée en base** (écoles concernées, variation MRR/ARR, écoles protégées par un tarif négocié), puis confirmation avec motif obligatoire
✅ Historique des prix, jamais purgé
✅ Promotions et offres spéciales : création, modification, archivage
✅ Tarifs négociés : accord, calcul automatique de la remise sur le prix catalogue relu en base, terminaison avec retour au catalogue
✅ Abonnements clients avec prix catalogue vs prix payé et taux de remise
✅ Catalogue de services, fiche détaillée, consommations mensuelles (estimé vs réel facturé)
✅ Dépenses avec justificatifs, filtres, totaux sur l'ensemble du filtre (pas seulement la page)
✅ Budgets prévu/réel avec jauges et détection des catégories dépensées hors budget
✅ Rentabilité par offre et par école, avec coûts API attribués nominativement via `ia_utilisations`
✅ Seuil de rentabilité, simulable par paramètres
✅ Prévisions à 3 scénarios × 4 horizons, hypothèses affichées
✅ Alertes financières sur seuils configurables
✅ Journal financier avec avant/après/motif
✅ Exports : 8 rapports × 4 formats (XLSX, CSV, PDF imprimable, JSON), chaque export journalisé
✅ Calendrier de facturation : sorties et entrées dans un seul écran
✅ Taux de change avec détection des devises utilisées sans taux
✅ Permissions financières

---

## 8. Fonctionnalités nécessitant une configuration

Rien de tout cela n'est un défaut : ce sont des données que seul l'exploitant possède. L'interface les réclame explicitement plutôt que de les inventer.

| À faire | Où | Conséquence si omis |
|---|---|---|
| **Exécuter la migration 027** | `psql -f migrations/027-finance-offres-couts.sql` | Les écrans finance renvoient des erreurs 500 |
| **Saisir les services externes** | Services & infrastructure | Coûts à zéro → marge affichée à 100 % |
| **Saisir les consommations variables** chaque mois | Fiche service → « Consommation » | Coûts sous-estimés, marge surestimée. Un bandeau le signale |
| **Saisir les taux de change** si multidevise | Taux de change | Montants USD et FC additionnés sans conversion. Signalé partout où c'est le cas |
| **Définir les budgets** | Budget | Aucune alerte de dépassement |
| **Saisir les dépenses marketing** | Dépenses, catégorie `marketing` | CAC et ratio LTV/CAC indisponibles |
| **Ajuster les seuils** | Configuration → catégorie `finance` | Les valeurs par défaut (marge 20 %, API +50 %, préavis 14 j, budget 90 %) s'appliquent |
| **Créer les offres** | Offres & tarification | Aucune offre n'est semée par la migration, volontairement |
| **Renseigner `date_renouvellement`** sur les services | Fiche service | Le service n'apparaît jamais dans le calendrier ni dans les alertes. Un encart liste ceux qui manquent |

---

## 9. Problèmes détectés dans l'existant

**Le MRR historique ne peut pas être mesuré, seulement reconstitué.** Ardoise ne prend pas d'instantané mensuel du MRR. La courbe est donc recalculée à partir des abonnements et des **prix actuels** : un changement de prix passé se répercute rétroactivement sur toute la courbe. C'est signalé sur l'écran plutôt que présenté comme une mesure. *Correctif recommandé : une table `mrr_mensuel` alimentée par une tâche planifiée le 1ᵉʳ de chaque mois.*

**Les devises ne sont pas consolidées dans l'existant.** `paiements.montant` et `plans_abonnement.prix` portent une devise, mais rien ne les rapprochait : additionner des USD et des FC produisait un chiffre d'affaires faux et d'apparence correcte. La table `finance_taux_change` répond au besoin, mais avec un taux **courant** et non un taux historique par transaction — Ardoise ne tient pas de comptabilité multidevise, et un taux « au jour de l'encaissement » supposerait une saisie quotidienne qui n'existe pas.

**Le statut d'abonnement et l'échéance peuvent diverger.** Des abonnements restent `actif` alors que `date_expiration` est passée. L'alerte « Abonnements échus non réglés » les remonte, mais la cause reste : aucune tâche planifiée ne bascule les statuts.

**Les remboursements ne sont pas modélisés.** La table `paiements` n'a pas de statut de remboursement. L'indicateur est renvoyé à `null` et documenté comme tel, plutôt que d'afficher zéro — qui se lirait « aucun remboursement » au lieu de « information indisponible ».

**Le volume de stockage n'est pas suivi.** Ardoise compte les documents, pas leur taille cumulée. Le coût de stockage par école ne peut donc pas être ventilé finement.

**Le coût de génération des bulletins n'est pas répartissable.** Il est porté par le serveur applicatif, qui est un coût fixe. Le répartir par bulletin demanderait une instrumentation dédiée. Le volume est affiché, le coût unitaire reste `null` avec l'explication.

**Le schéma réel de la base n'est pas certain** (HANDOVER §3). Toutes les extensions de colonnes sont donc écrites en `ADD COLUMN IF NOT EXISTS`, et les contraintes posées via des blocs `DO` qui vérifient d'abord leur absence.

---

## 10. Améliorations recommandées, par ordre de valeur

1. **Instantané mensuel du MRR** (`mrr_mensuel`, tâche du 1ᵉʳ du mois). C'est le seul moyen d'avoir une courbe historique vraie, et la fondation de tout le reste.
2. **Tâche planifiée de mise à jour des statuts d'abonnement** : basculer `actif` → `expire` à l'échéance, et alimenter automatiquement le churn.
3. **Application automatique des promotions au moment de la souscription.** Les promotions sont aujourd'hui enregistrées et consultables, mais leur application passe par la création manuelle d'un tarif négocié. Brancher `promotions_commerciales` sur le tunnel de paiement fermerait la boucle.
4. **Récupération automatique des consommations** via les API de facturation des fournisseurs (OpenAI, Resend…), avec repli sur la saisie manuelle. La saisie mensuelle est le point de friction le plus probable de tout ce module.
5. **Statut de remboursement dans `paiements`**, pour que le CA net soit exact.
6. **Suivi du volume de stockage en octets**, pour ventiler le coût d'infrastructure autrement qu'au prorata des élèves.
7. **Mise en cache plus agressive du tableau de bord.** Il exécute une trentaine d'agrégations (dont 12 calculs de coûts mensuels) ; le cache de 60 secondes suffit aujourd'hui, mais deviendra insuffisant vers quelques centaines d'écoles.
8. **Export comptable normalisé** (format compatible avec un logiciel de comptabilité congolais), une fois le modèle stabilisé.

---

## 11. Vérification après installation

```sql
-- Chaque ligne doit afficher policies = 1
SELECT tablename,
       (SELECT count(*) FROM pg_policies p
         WHERE p.schemaname='public' AND p.tablename=t.tablename) AS policies
  FROM (VALUES
    ('plan_prix_historique'),('promotions_commerciales'),('offres_speciales'),
    ('tarifs_personnalises'),('services_externes'),('services_consommations'),
    ('depenses'),('budgets'),('finance_taux_change'),('journal_financier'),
    ('finance_acces')) AS t(tablename);
```

Puis, dans l'interface : `#/finance` doit s'ouvrir avec des cartes à zéro et un bloc « Données à compléter » qui liste ce qu'il reste à saisir. **C'est le comportement attendu sur une base neuve** — pas un défaut d'installation.

---

*Langue de travail : français, y compris dans le code, les commentaires, les messages d'erreur et l'interface.*
