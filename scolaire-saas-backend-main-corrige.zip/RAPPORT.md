# Rapport — Transformation du didacticiel en guide intelligent d'Ardoise

---

## 1. Comment fonctionnait le didacticiel avant

**Un fichier partagé, 37 pages.** `didacticiel.js` (246 lignes) était chargé par chaque page via `<script src="didacticiel.js" data-ecran="…">`, posé par `installer-didacticiel.py`. Il affichait un bouton flottant `?`, une pastille ocre s'il restait une étape bloquante, et un panneau modal.

**La détection venait déjà de la base.** `GET /assistant/etat-installation` exécutait **une seule requête** à 15 sous-`SELECT` et renvoyait `{ etapes, prochaine_etape, alertes, progression, termine }`. Aucune étape n'était « cochée » par un clic — c'était, et cela reste, le principe le plus juste du système.

**Le fond venait de `utils/connaissance.utils.js`** : `ORDRE_CONFIGURATION` (14 étapes), `PROCEDURES` (7 procédures), `LEXIQUE`. La même source alimentait le prompt de l'IA et le manuel `GET /assistant/manuel`.

**L'IA était branchée, mais en aveugle.** Le panneau renvoyait vers `messages.html?assistant=1&ecran=…`. Le prompt recevait le rôle et l'écran — jamais l'état réel de l'école.

### Ce qui lui manquait

| Manque | Conséquence |
|---|---|
| Aucune persistance | Ni « bienvenue vue », ni « passé », ni « tutoriel déjà lu ». Impossible de reprendre. |
| Aucune première connexion | Pas d'accueil, pas de personnalisation. |
| `requireRole('directeur','prefet','super_admin')` | Professeur, secrétaire, comptable, titulaire : panneau générique de 4 lignes. |
| Parcours linéaire | 14 étapes dans un ordre fixe, pas un graphe de dépendances. |
| Texte seul | Un lien « aller à l'écran », pas de guidage dans l'interface. |
| Pas d'étapes de découverte | Une école configurée recevait « c'est complet » et plus rien. |
| Pas de tutoriels contextuels | Rien à la première ouverture de Notes, Bulletins, Paiements. |
| Détection grossière | `nb_utilisateurs > 1` validait « enseignants » : un comptable seul suffisait. Sections, options, `enseignant_cours`, titulaires : non observés. |

---

## 2. Ce qui a été conservé — et pourquoi

C'était la contrainte principale, et elle a été tenue :

- **`GET /assistant/etat-installation` répond exactement comme avant.** Même forme, mêmes noms de champs, même numérotation. Les 37 pages ne sont pas déployées à la même seconde qu'un cache navigateur ne se vide ; un ancien `didacticiel.js` en cache continue de fonctionner.
- **`connaissance.utils.js` n'a pas été touché.** Aucun texte n'a été recopié : le catalogue d'étapes pointe vers les numéros d'`ORDRE_CONFIGURATION` par un champ `etape_config`, et le `quoi` / `pourquoi` / `piège` est lu là-bas au moment de répondre.
- **Le principe « la base fait foi »** est non seulement conservé, mais protégé : **aucune action d'API ne permet de déclarer une étape de configuration terminée.** On peut l'*ignorer* — c'est une décision de la personne, pas un fait sur l'école.
- **Les alertes avant la progression.** Un réglage à moitié fait passe avant l'avancement. C'était juste, c'est resté.
- **Une seule prochaine étape affichée**, pas quatorze.
- **La dégradation propre** : IA absente → manuel ; API absente → silence, jamais de panneau vide.
- **Le nom du fichier et le mode d'installation.** Aucune des 37 pages HTML n'a été modifiée.

---

## 3. Ce qui a été amélioré

| Avant | Après |
|---|---|
| 15 signaux, direction uniquement | ~30 signaux, tous les rôles |
| `nb_utilisateurs > 1` = « enseignants faits » | comptage réel des comptes `professeur`/`titulaire` |
| `classe_cours` confondu avec l'attribution aux enseignants | `enseignant_cours` distingué — c'est lui qui décide si un professeur voit un écran vide |
| Sections/options ignorées | détectées, et retirées du parcours d'une école primaire |
| Étape 5 « faite d'office » | facultative au primaire, obligatoire au secondaire |
| 2 alertes | 5 alertes (périodes sans dates, élèves sans classe, enseignants sans cours en plus) |
| Un seul pourcentage | deux : parcours global et configuration seule |
| Manuel atteignable depuis un onglet de la messagerie | table des matières « Apprendre Ardoise », filtrée par rôle, ouvrable partout |
| CSS en tableau de chaînes JS | `didacticiel.css`, thématisé par variables |

---

## 4. Ce qui a été ajouté

**Écran de bienvenue** — personnalisé avec ce qui est disponible et *seulement* avec cela (« Bonjour Obed 👋 », sinon « Bienvenue à l'école X 👋 », sinon « Bienvenue »). Deux boutons : **Commencer**, **Passer pour l'instant**. Le Super Admin est exclu, côté navigateur *et* côté serveur.

**Parcours dynamique par rôle** — 39 étapes au catalogue, réparties en trois types (`profil`, `configuration`, `decouverte`), chacune avec ses dépendances. Le parcours est *calculé*, jamais écrit en dur.

**Ordre par dépendances réelles** — `eleves` dépend de `classes` ; `classe_cours` dépend de `cours` **et** `classes` ; `emploi_du_temps` dépend de `creneaux` **et** `attribution_cours`. Une dépendance absente du parcours d'un rôle est réputée satisfaite : un préfet n'est pas bloqué parce que le directeur n'a pas rempli l'identité de l'école.

**Guidage dans l'interface** — projecteur (quatre panneaux opaques, pas un `box-shadow` : le trou reste **cliquable**), halo pulsant, bulle avec flèche orientée, `MutationObserver` pour attendre les données chargées en réseau. Le guidage traverse une navigation via `sessionStorage` et reprend seul à l'arrivée.

**Détection réelle de l'action** — relecture de la base au retour sur l'onglet et toutes les 20 secondes pendant un guidage actif. Si l'étape guidée passe de « non faite » à « faite » entre deux lectures, la félicitation s'affiche. Aucun accrochage aux formulaires des 37 pages : cela raterait les créations faites par import ou depuis un autre appareil.

**Mini-tutoriels contextuels** — 9 écrans couverts, affichés une seule fois, mémorisés dès la fermeture quelle qu'en soit la façon.

**IA contextuelle** — `POST /assistant/aide-contextuelle`. Le prompt reçoit prénom, rôle, école, cycle, avancement, étapes terminées, étapes restantes, étape en cours (avec son piège), et des **comptes** — jamais un nom d'élève, jamais un montant. La confidentialité entre rôles tient parce qu'aucune donnée nominative ne franchit cette frontière.

**Entrée « Aide & Tutoriels »** dans le menu, injectée par `didacticiel.js` sur chaque page — donc sans modifier 37 menus.

---

## 5. Les parcours par rôle

| Rôle | Étapes | Contenu |
|---|---|---|
| **Directeur** | 22 (21 au primaire) | profil → identité → année → périodes → sections/options → cours → classes → cours de classe → personnel → attributions → titulaires → élèves → modèles → créneaux → emploi du temps → discipline → frais → 5 découvertes |
| **Préfet** | 17 | pédagogie et structure, sans identité de l'école ni frais ni personnel |
| **Secrétaire** | 9 | secrétariat → élèves → inscriptions → paiements → bulletins → archives |
| **Comptable** | 7 | frais → encaissement → impayés → caisse → rapports |
| **Professeur** | 6 | profil → mes cours → cotes → appel → emploi du temps → messagerie |
| **Titulaire** | 8 | ma classe → cours de la classe → cotes → appel → bulletins → discipline |
| **Chargé des présences** | 3 | profil → appel → messagerie |
| **Directeur de discipline** | 4 | profil → discipline → présences → messagerie |
| **Parent / Élève** | 2 | profil → messagerie |

Un compte **cumulant plusieurs rôles** reçoit le parcours du rôle le plus large, complété par les seules *découvertes* des autres. Additionner les parcours donnerait trente étapes, ce qui décourage.

Les parcours parent et élève sont volontairement minimaux : **aucun espace dédié n'existe dans le code**. Le jour où ces pages existeront, il suffira d'ajouter deux codes dans `PARCOURS_ROLE`.

---

## 6. Comment fonctionne la détection

**Deux requêtes, une seule jouée dans le cas normal.**

- Le **socle** reprend les 15 signaux d'origine plus le profil de la personne. Chacun tourne en production depuis que le didacticiel existe.
- L'**extension** ajoute les signaux nouveaux, et l'appel normal exécute `socle + extension` d'un coup.
- Si l'extension échoue, on **retombe sur le socle** et le guide fonctionne en mode réduit. Un avertissement est journalisé **une seule fois**.

Cette précaution n'est pas théorique : `HANDOVER.md` avertit que plusieurs migrations n'ont jamais été jouées contre une vraie base. La table `sections` en particulier n'est **jamais** interrogée par `ecole_id` dans tout le dépôt — elle n'apparaît que jointe depuis `classes.section_id`. Le compte de sections passe donc par `classes.section_id IS NOT NULL` et par `options`, deux chemins dont l'existence est prouvée par le code existant. `enseignant_cours` est atteinte par jointure sur `classe_cours`, pour la même raison.

En mode réduit, un signal inconnu est réputé **vrai** plutôt que faux : mieux vaut ne pas proposer une étape que la proposer à quelqu'un qui l'a déjà terminée.

**Les découvertes** n'ont aucune trace en base — ouvrir « Rapports » ne crée aucune ligne. Elles se valident par la visite, enregistrée dans la progression. C'est le seul cas où l'action de la personne fait foi, et c'est parce qu'il n'y a rien d'autre à observer.

---

## 7. L'architecture de progression — une seule source

```
Onboarding Engine  (utils/onboarding.utils.js)
├── Configuration Progress  ← base de données, recalculée à chaque appel
├── Tutorial Progress       ← utilisateurs.onboarding (JSONB)
├── Contextual Tutorials    ← utilisateurs.onboarding.tutoriels_vus
├── Role-Based Guidance     ← PARCOURS_ROLE × faits × dépendances
└── AI Assistance           ← consigneOnboarding(), nourrie par les mêmes faits
```

`construireParcours()` est le seul endroit où l'on décide de quoi que ce soit. `etat-installation`, `onboarding` et `aide-contextuelle` appellent tous `collecterFaits()` : ils ne peuvent structurellement pas diverger.

---

## 8. Fichiers

### Créés

| Fichier | Lignes | Rôle |
|---|---|---|
| `backend/utils/onboarding.utils.js` | 1 138 | Catalogue des 39 étapes, parcours par rôle, tutoriels contextuels, centre d'apprentissage, moteur de calcul |
| `backend/migrations/026-onboarding-progression.sql` | 80 | Colonne `utilisateurs.onboarding` |
| `frontend/didacticiel.css` | 475 | Projecteur, bulle, bienvenue, checklist, tutoriels, accessibilité |

### Modifiés

| Fichier | Nature |
|---|---|
| `backend/controllers/assistant.controller.js` | `collecterFaits()` partagée ; `etatInstallation()` réécrite **à contrat identique** ; ajout de `etatOnboarding`, `majOnboarding`, `aideContextuelle`, `consigneOnboarding` ; `manuel()` enrichi d'un champ `centre` |
| `backend/routes/assistant.routes.js` | 3 routes ajoutées, les 3 existantes inchangées |
| `frontend/didacticiel.js` | Réécrit — même nom, même mode d'installation, repli sur l'ancienne route inclus |
| `frontend/sw.js` | `VERSION` → `ardoise-v36`, `didacticiel.css` ajouté à la coquille |
| `frontend/installer-didacticiel.py` | Vérifie aussi `didacticiel.css` ; deux pages sans session ajoutées |

**Aucune des 37 pages HTML n'a été modifiée.**

### Base de données

| Objet | Nature |
|---|---|
| `utilisateurs.onboarding` | Colonne `jsonb NOT NULL DEFAULT '{}'` |
| `utilisateurs_onboarding_objet` | `CHECK (jsonb_typeof(onboarding) = 'object')` |
| `utilisateurs_onboarding_idx` | Index GIN `jsonb_path_ops` |

**Aucune table créée.** Presque tout ce qu'on voudrait mémoriser est déjà dans la base, et de façon plus fiable qu'un enregistrement de progression : une table `onboarding_etapes` dupliquerait cette vérité et divergerait au premier import massif fait hors du parcours guidé. Ne reste à conserver que ce que la base ne peut pas déduire.

### Routes API

| Route | État |
|---|---|
| `POST /assistant/question` | inchangée |
| `GET /assistant/manuel` | **enrichie** (champ `centre` ajouté, rien retiré) |
| `GET /assistant/etat-installation` | **contrat identique**, source des faits partagée |
| `GET /assistant/onboarding` | **nouvelle** — tous rôles |
| `PATCH /assistant/onboarding` | **nouvelle** — tous rôles |
| `POST /assistant/aide-contextuelle` | **nouvelle** — tous rôles |

Les trois nouvelles routes sont ouvertes à tous les rôles, contrairement à `etat-installation`. La différence est délibérée : `etat-installation` liste les 14 étapes de configuration de l'établissement, ce qui révèle indirectement sa maturité. `GET /onboarding` renvoie le parcours **de la personne** — le contrôleur retire alertes et compteurs pour qui n'est ni directeur ni préfet. Poser un `requireRole` là priverait d'accompagnement exactement les rôles qui en ont le plus besoin.

---

## 9. Tests exécutés

89 assertions, aucun échec.

**Moteur (12 scénarios de parcours)** — directeur école vide / partielle / complète ; école primaire (sections retirées) ; professeur ; secrétaire ; comptable ; titulaire ; directeur+titulaire cumulés ; utilisateur revenu ; étape ignorée ; parent.

**Backend (62 assertions)** — forme de la réponse, cloisonnement par rôle, exclusion du Super Admin, primaire sans sections, bascule configuration → découverte, **contrat d'`etat-installation` préservé**, conservation intégrale de la progression après report/reprise, refus des actions inventées et des codes d'étape inconnus, **impossibilité de cocher une configuration à la main**, contenu du contexte transmis à l'IA, repli hors quota, repli sur panne, manuel enrichi, routage, **mode réduit quand une colonne manque**.

**Frontend (15 assertions, DOM minimal maison)** — ouverture automatique de la bienvenue, personnalisation, message adapté à une école déjà configurée, message adapté au professeur, libellé « Continuer » après un report, écran de fin, bandeau de tutoriel et sa mémorisation, IA avec et sans quota, **repli sur l'ancienne route en cas de 404**.

Le script d'installation a été rejoué en simulation sur le dépôt réel : 34 pages déjà équipées, 5 volontairement ignorées, 0 modification.

---

## 10. Problèmes rencontrés et corrigés

1. **Le professeur recevait « votre établissement est déjà bien configuré ».** Un professeur est *toujours* en mode découverte, puisqu'il ne configure rien. Le message est désormais réservé aux rôles qui ont des étapes de configuration. — *Détecté par le test frontend n° 3.*

2. **Le directeur d'une école complète était envoyé sur les bulletins avant son tableau de bord.** La règle « obligatoire d'abord » s'appliquait aussi entre découvertes. Corrigé : une configuration obligatoire passe toujours avant une découverte, mais entre découvertes c'est l'ordre de la liste qui décide.

3. **Un seul pourcentage mélangeait configuration et découverte**, faisant reculer l'avancement d'une école pourtant entièrement installée. Deux compteurs distincts.

4. **`sections` n'est jamais interrogée par `ecole_id` dans le dépôt.** Risque de 500 sur une colonne absente — qui aurait cassé `etat-installation`, fonctionnalité qui marche aujourd'hui. D'où l'architecture socle/extension.

5. **Le projecteur en `box-shadow` capturait les clics.** La zone éclairée aurait été inatteignable : on dit « cliquez ici » et le clic ne passe pas. Remplacé par quatre panneaux opaques laissant un trou réellement cliquable.

6. **Accents graves dans les commentaires SQL** à l'intérieur d'un littéral gabarit JavaScript — erreur de syntaxe au chargement du module.

---

## 11. Ce qu'il reste à faire

### Avant la mise en ligne — obligatoire

1. **Jouer la migration 026** et vérifier qu'elle passe. Elle est idempotente.
2. **Copier `didacticiel.css` à côté de `didacticiel.js`.** Sans elle, le guide s'affiche en texte brut par-dessus la page — un défaut long à diagnostiquer parce qu'il ne produit aucune erreur.
3. **Vérifier les logs au premier déploiement.** Si `[didacticiel] La collecte étendue a échoué` apparaît, une colonne manque : le message nomme laquelle. Le guide fonctionne quand même, en mode réduit.
4. **Le service worker est en `v36`** : les navigateurs récupéreront les nouveaux fichiers.

### Sélecteurs de projecteur à vérifier

Le catalogue référence des identifiants de boutons page par page. La plupart sont confirmés dans le dépôt (`#bouton-ajouter-classe`, `#bouton-ajouter`, `#bouton-importer`, `#bouton-ajouter-config`, `#bouton-enregistrer-ecole`, `#bouton-enregistrer-notes`, `#bouton-afficher-dettes`…). Quelques-uns sont supposés : `#bouton-ajouter-annee`, `#bouton-ajouter-periode`, `#bouton-ajouter-creneau`, `#bouton-ajouter-cours`, `#bouton-ajouter-section`, `#bouton-ajouter-modele`, `#bouton-importer-reglement`, `#champ-titulaire`, `#champ-nom`.

Ce n'est pas bloquant : le repli sur l'entrée de menu est automatique et silencieux. Mais chaque sélecteur corrigé rend le guidage plus précis. Ils sont tous regroupés dans le champ `selecteurs` du catalogue — un seul fichier à ouvrir.

### Améliorations recommandées

- **Espaces parent et élève.** Les parcours existent, réduits à deux étapes faute de pages. À compléter le jour où ces espaces seront construits.
- **Relevé d'adoption côté Super Admin.** L'index GIN est déjà posé pour cela : combien de directeurs terminent leur parcours, où ils s'arrêtent, quelles étapes sont le plus souvent ignorées. C'est la donnée qui dira quelles étapes sont mal expliquées.
- **Suggestion proactive de l'IA.** Aujourd'hui elle répond quand on l'appelle. Une personne bloquée trois minutes sur la même étape pourrait se voir proposer « Vous ne savez pas comment créer vos classes ? » sans avoir à le demander.
- **Traduction.** Tous les libellés sont en français dans deux fichiers seulement — le catalogue côté serveur et les messages d'accueil côté navigateur. Le jour où le lingala ou le swahili se posera, l'extraction sera courte.

---

## 12. Ce qui n'a pas pu être vérifié

Cet environnement n'a **aucun accès réseau ni base PostgreSQL**. Les requêtes SQL ont été écrites en s'appuyant sur les colonnes dont l'existence est prouvée par du code déjà en production, et testées contre un client factice — jamais contre une vraie base. Le même avertissement figure dans `HANDOVER.md` pour les migrations précédentes, et il a déjà valu au moins une erreur de type découverte après coup. L'architecture socle/extension est la réponse à ce risque : une colonne manquante dégrade le guide, elle ne fait tomber ni le didacticiel ni la fonctionnalité existante.

Le rendu visuel n'a pas été observé dans un navigateur : le DOM minimal utilisé pour les tests exécute la logique mais n'évalue pas la mise en page. Le positionnement de la bulle et du projecteur mérite un contrôle sur écran réel, en particulier sur mobile et en thème « nuit ».
