# Backend — Plateforme SaaS Gestion Scolaire (Phase 0)

Ce que contient ce squelette :
- Connexion Supabase (PostgreSQL) avec isolation multi-tenant par Row-Level Security.
- Authentification JWT (access token 15 min + refresh token 30 jours, révocable).
- Middleware de rôles (`requireRole`).
- Création d'école par le Super Admin (avec abonnement + compte Directeur créés automatiquement).

## Étapes de déploiement (aucun CLI requis)

### 1. Base de données (Supabase)
1. Ouvre ton projet Supabase (nouveau projet dédié, comme pour JusStock).
2. Va dans **SQL Editor**.
3. Colle tout le contenu de `schema.sql` et exécute (`Run`).
4. Récupère ta chaîne de connexion : **Settings > Database > Connection string > URI**.

### 2. Backend (GitHub + Render)
1. Crée un nouveau repo GitHub, ex. `scolaire-saas-backend`.
2. Glisse-dépose tout le contenu du dossier `backend/` sur la page GitHub.com du repo (comme d'habitude).
3. Sur Render : **New > Web Service**, connecte le repo.
   - Build command : `npm install`
   - Start command : `npm start`
4. Dans Render > Environment, ajoute les variables listées dans `.env.example` (avec tes vraies valeurs : `DATABASE_URL` de Supabase, secrets JWT, identifiants du Super Admin).
5. Une fois déployé, ouvre le **Shell** de Render et lance une seule fois :
   ```
   node scripts/seed-superadmin.js
   ```
   Cela crée ton compte Super Admin.

### 3. Tester
- `GET https://ton-backend.onrender.com/` → doit répondre `{ "status": "ok" }`.
- `POST /auth/login` avec `{ "email": "<SUPERADMIN_EMAIL>", "password": "<SUPERADMIN_PASSWORD>" }` (pas de `code_ecole`) → renvoie `access_token` + `refresh_token`.
- Avec ce token (`Authorization: Bearer <access_token>`), `POST /admin/ecoles` pour créer ta première école pilote.

## Prochaine étape suggérée
Modules Élèves, Classes, Cours, Notes (Phase 1) — même pattern : controller + routes + middleware de rôle, isolation automatique via `runWithTenant`.
