const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false } // requis pour Supabase
});

/**
 * Exécute une série de requêtes dans une transaction où les policies RLS
 * sont actives grâce à SET LOCAL (portée = la transaction en cours).
 *
 * @param {object} tenantContext - { ecoleId: string|null, isSuperAdmin: boolean }
 * @param {(client: import('pg').PoolClient) => Promise<any>} callback
 */
async function runWithTenant(tenantContext, callback) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    if (tenantContext.isSuperAdmin) {
      await client.query("SET LOCAL app.is_superadmin = 'true'");
    } else {
      await client.query("SET LOCAL app.is_superadmin = 'false'");
    }

    if (tenantContext.ecoleId) {
      await client.query("SELECT set_config('app.current_ecole_id', $1, true)", [tenantContext.ecoleId]);
    }

    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Exécute UNE requête de lecture produite par l'assistant, dans un harnais
 * où la base elle-même empêche les dégâts — indépendamment de ce que le
 * modèle a écrit et de ce que la validation applicative aurait laissé passer.
 *
 * Quatre verrous, tous posés par PostgreSQL :
 *   1. SET TRANSACTION READ ONLY  → aucune écriture possible, même en cas
 *      d'injection réussie ;
 *   2. SET LOCAL ROLE ia_lecture  → rôle sans droit d'écriture, sans DDL, et
 *      dont les colonnes sensibles ne sont même pas lisibles ;
 *   3. RLS active pour ce rôle    → les lignes des autres écoles n'existent
 *      pas de son point de vue ;
 *   4. statement_timeout          → une requête coûteuse ne peut pas bloquer
 *      la base pour les autres écoles.
 *
 * L'ordre des instructions est contraint : SET TRANSACTION READ ONLY doit
 * précéder toute requête, et SET ROLE doit venir après les set_config, sinon
 * le rôle restreint n'a pas le droit de les poser.
 */
async function executerRequeteLectureIA({ ecoleId, sql, delaiMs = 5000 }) {
  if (!ecoleId) throw new Error('Contexte école manquant.');

  const client = await pool.connect();
  const debut = Date.now();
  try {
    await client.query('BEGIN');
    await client.query('SET TRANSACTION READ ONLY');

    // Jamais super-admin ici : l'assistant ne doit voir qu'une seule école.
    await client.query("SET LOCAL app.is_superadmin = 'false'");
    await client.query("SELECT set_config('app.current_ecole_id', $1, true)", [ecoleId]);
    await client.query(`SET LOCAL statement_timeout = ${Number(delaiMs)}`);

    await client.query('SET LOCAL ROLE ia_lecture');

    const resultat = await client.query(sql);
    await client.query('COMMIT');

    return { lignes: resultat.rows, duree: Date.now() - debut };
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (e) { /* connexion déjà perdue */ }
    err.dureeIA = Date.now() - debut;
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, runWithTenant, executerRequeteLectureIA };
