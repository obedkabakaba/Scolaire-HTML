const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const catalogue = require('../utils/catalogue.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /abonnements/courant
 * Vue "mon abonnement" pour l'école connectée (Directeur, etc.)
 */
async function courant(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const result = await client.query(`
        SELECT a.*, p.nom AS plan_nom, p.code AS plan_code, p.prix, p.devise
        FROM abonnements a
        JOIN plans_abonnement p ON p.id = a.plan_id
        WHERE a.ecole_id = ${CURRENT_ECOLE}
        ORDER BY a.created_at DESC
        LIMIT 1
      `);
      if (result.rows.length === 0) return null;

      // Les limites et les droits accompagnent désormais l'abonnement.
      //
      // Sans eux, la page « Mon abonnement » n'avait qu'un nom d'offre à
      // afficher, et le directeur découvrait ses plafonds au moment où il les
      // heurtait. Ils viennent du catalogue — donc de la même source que le
      // contrôle serveur qui refusera la création du 251ᵉ élève.
      const offre = await catalogue.offreDeLEcole(client, req.auth.ecoleId);
      const consommation = await client.query(`
        SELECT (SELECT count(*) FROM eleves
                 WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif')       AS eleves,
               (SELECT count(*) FROM utilisateurs
                 WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif')       AS utilisateurs`);

      return {
        ...result.rows[0],
        offre: offre ? {
          code: offre.code, nom: offre.nom, positionnement: offre.positionnement,
          tarifs: offre.tarifs, limites: offre.limites,
          fonctionnalites: offre.fonctionnalites, points_forts: offre.points_forts
        } : null,
        consommation: consommation.rows[0] || null
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur abonnement courant:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Méthodes de paiement acceptées pour un abonnement.
 *
 * Les trois premières sont initiables en ligne par le Directeur via PawaPay.
 * Les trois suivantes sont des règlements MANUELS : l'argent a déjà changé de
 * main, le Super Admin ne fait qu'en prendre acte. C'est le cas le plus
 * fréquent en pratique — beaucoup d'écoles paient en espèces.
 *
 * Cette liste est fermée et vérifiée ici plutôt que laissée à PostgreSQL :
 * l'énumération renverrait une erreur 500 illisible (« invalid input value
 * for enum »), alors qu'un 400 nomme le problème et liste les choix valides.
 */
const METHODES_PAIEMENT = [
  'orange_money', 'airtel_money', 'mpesa',
  'especes', 'virement_bancaire', 'cheque'
];

/** Méthodes qui n'ont pas de trace électronique et exigent une référence. */
const METHODES_MANUELLES = ['especes', 'virement_bancaire', 'cheque'];

/**
 * POST /abonnements/:abonnementId/confirmer-paiement  (Super Admin uniquement)
 *
 * Enregistre un paiement d'abonnement encaissé hors ligne et en tire toutes
 * les conséquences, en une seule transaction :
 *   · facture émise et marquée payée
 *   · paiement confirmé
 *   · abonnement repassé en « actif », avec une nouvelle date d'expiration
 *   · école repassée en « actif » si elle avait été suspendue faute de paiement
 *
 * body: { montant, methode, reference?, devise?, note? }
 */
async function confirmerPaiement(req, res) {
  const { abonnementId } = req.params;
  const { montant, methode, reference, devise, note } = req.body || {};

  if (montant === undefined || montant === null || !methode) {
    return res.status(400).json({ message: 'montant et methode sont requis.' });
  }

  const montantNumerique = Number(montant);
  if (!Number.isFinite(montantNumerique) || montantNumerique <= 0) {
    return res.status(400).json({ message: 'Le montant doit être un nombre supérieur à zéro.' });
  }

  if (!METHODES_PAIEMENT.includes(methode)) {
    return res.status(400).json({
      message: `Méthode de paiement inconnue. Valeurs acceptées : ${METHODES_PAIEMENT.join(', ')}.`
    });
  }

  // Un paiement en espèces ne laisse aucune trace ailleurs que dans Ardoise.
  // Exiger une référence (numéro de reçu, bordereau) est la seule façon de
  // pouvoir le rapprocher plus tard d'une pièce comptable en cas de litige.
  if (METHODES_MANUELLES.includes(methode) && !String(reference || '').trim()) {
    return res.status(400).json({
      message: "Une référence est requise pour un règlement manuel (numéro de reçu, de bordereau ou de chèque)."
    });
  }

  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const abonnementResult = await client.query(
        `SELECT a.id, a.ecole_id, a.plan_id, a.statut, a.date_expiration, a.periodicite,
                p.duree_jours, p.prix, p.prix_semestriel, p.prix_annuel,
                p.devise, p.nom AS plan_nom,
                e.nom AS ecole_nom, e.statut AS ecole_statut
         FROM abonnements a
         JOIN plans_abonnement p ON p.id = a.plan_id
         JOIN ecoles e ON e.id = a.ecole_id
         WHERE a.id = $1
         FOR UPDATE OF a`,
        [abonnementId]
      );
      if (abonnementResult.rows.length === 0) {
        throw Object.assign(new Error('Abonnement introuvable.'), { statusCode: 404 });
      }
      const abonnement = abonnementResult.rows[0];

      // Le verrou `FOR UPDATE OF a` ci-dessus sérialise les encaissements
      // concurrents sur le MÊME abonnement. Sans lui, un double-clic du Super
      // Admin émettait deux factures, enregistrait deux paiements, et
      // prolongeait l'abonnement DEUX FOIS — puisque la nouvelle échéance se
      // calcule à partir de l'échéance courante. L'école recevait des mois
      // qu'elle n'avait pas payés, et la caisse deux entrées pour un seul
      // règlement.
      //
      // `FOR UPDATE` ne verrouille QUE la ligne : deux écoles différentes
      // peuvent toujours être encaissées en parallèle.

      const numeroFacture = `FAC-${Date.now()}`;
      const factureResult = await client.query(
        `INSERT INTO factures (ecole_id, abonnement_id, numero, montant, devise, statut, date_echeance)
         VALUES ($1,$2,$3,$4,$5,'payee', now())
         RETURNING id`,
        [abonnement.ecole_id, abonnement.id, numeroFacture,
         montantNumerique, devise || abonnement.devise]
      );

      await client.query(
        `INSERT INTO paiements (ecole_id, facture_id, montant, methode, reference_externe, statut)
         VALUES ($1,$2,$3,$4,$5,'confirme')`,
        [abonnement.ecole_id, factureResult.rows[0].id,
         montantNumerique, methode, String(reference || '').trim() || null]
      );

      // La nouvelle période part de la date d'expiration en cours si celle-ci
      // n'est pas encore atteinte, et de maintenant sinon.
      //
      // Le calcul précédent repartait systématiquement de `now()`. Une école
      // qui renouvelait deux semaines avant l'échéance perdait donc ces deux
      // semaines déjà payées — sanctionnée pour avoir payé en avance.
      const maintenant = new Date();
      const expirationActuelle = abonnement.date_expiration
        ? new Date(abonnement.date_expiration) : null;
      const pointDeDepart = (expirationActuelle && expirationActuelle > maintenant)
        ? expirationActuelle : maintenant;
      // La durée ajoutée suit la PÉRIODICITÉ de l'abonnement, et non le
      // `duree_jours` du plan.
      //
      // `duree_jours` vaut 30 pour les quatre offres : c'est l'unité de
      // facturation, pas l'engagement. Le calcul précédent prolongeait donc
      // de trente jours un abonnement réglé pour un an — l'école payait
      // 2 100 $ et voyait sa plateforme expirer un mois plus tard. Le défaut
      // était invisible tant qu'une seule périodicité existait ; l'ajout du
      // semestriel le rendait certain.
      const joursAjoutes = catalogue.joursDePeriodicite(
        abonnement.periodicite, abonnement.duree_jours);
      const nouvelleExpiration =
        new Date(pointDeDepart.getTime() + joursAjoutes * 24 * 60 * 60 * 1000);

      await client.query(
        `UPDATE abonnements
         SET statut = 'actif',
             date_debut = COALESCE(date_debut, now()),
             date_expiration = $1,
             en_periode_essai = false,
             updated_at = now()
         WHERE id = $2`,
        [nouvelleExpiration, abonnement.id]
      );

      // Réactivation de l'école. On ne touche qu'aux écoles qui ne sont pas
      // déjà actives, et on conserve l'état précédent dans le journal : si la
      // suspension avait une autre cause que l'impayé, la trace permet de
      // revenir en arrière en connaissance de cause.
      let ecoleReactivee = false;
      if (abonnement.ecole_statut !== 'actif') {
        await client.query(`UPDATE ecoles SET statut = 'actif', updated_at = now() WHERE id = $1`,
          [abonnement.ecole_id]);
        ecoleReactivee = true;
      }

      // `utilisateur_id` est renseigné : un encaissement en espèces doit nommer
      // la personne qui l'a saisi. L'ancienne version laissait ce champ vide,
      // ce qui rendait l'écriture intraçable — précisément sur le mode de
      // paiement où la traçabilité compte le plus.
      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES ($1, $2, 'abonnement.paiement_confirme', 'abonnement', $3, $4::jsonb)`,
        [abonnement.ecole_id, req.auth ? req.auth.userId : null, abonnement.id,
         JSON.stringify({
           montant: montantNumerique,
           devise: devise || abonnement.devise,
           methode,
           reference: String(reference || '').trim() || null,
           note: note ? String(note).slice(0, 500) : null,
           facture: numeroFacture,
           plan: abonnement.plan_nom,
           periodicite: abonnement.periodicite,
           jours_ajoutes: joursAjoutes,
           statut_ecole_precedent: abonnement.ecole_statut,
           ecole_reactivee: ecoleReactivee,
           statut_abonnement_precedent: abonnement.statut,
           nouvelle_expiration: nouvelleExpiration.toISOString(),
           source: 'super_admin'
         })]
      );

      return {
        facture: numeroFacture,
        montant: montantNumerique,
        devise: devise || abonnement.devise,
        methode,
        reference: String(reference || '').trim() || null,
        ecole_nom: abonnement.ecole_nom,
        plan_nom: abonnement.plan_nom,
        periodicite: abonnement.periodicite,
        jours_ajoutes: joursAjoutes,
        statut_abonnement_precedent: abonnement.statut,
        statut_ecole_precedent: abonnement.ecole_statut,
        ecole_reactivee: ecoleReactivee,
        nouvelleExpiration
      };
    });

    // L'offre de cette école vient de changer d'état : le cache du catalogue
    // ne doit pas continuer à répondre « pas d'abonnement actif » pendant une
    // minute après un encaissement.
    catalogue.invaliderCache();

    return res.json({
      message: resultat.ecole_reactivee
        ? 'Paiement enregistré. Abonnement réactivé et école remise en service.'
        : 'Paiement enregistré. Abonnement prolongé.',
      ...resultat
    });
  } catch (err) {
    console.error('Erreur confirmation paiement:', err);

    // Le cas le plus probable après une mise à jour : la migration 021 n'a pas
    // été passée, l'énumération ne connaît pas 'especes'. On le dit clairement
    // plutôt que de renvoyer une erreur serveur opaque.
    if (err.code === '22P02' || /invalid input value for enum/i.test(err.message || '')) {
      return res.status(500).json({
        message: "Cette méthode de paiement n'est pas encore reconnue par la base. "
               + "Exécutez la migration 021-methodes-paiement.sql, puis réessayez."
      });
    }
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

module.exports = { courant, confirmerPaiement, METHODES_PAIEMENT, METHODES_MANUELLES };
