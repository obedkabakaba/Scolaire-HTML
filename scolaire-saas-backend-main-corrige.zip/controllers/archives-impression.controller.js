const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { construireHtmlBulletins } = require('../utils/bulletin-template');
const { construireHtmlBulletinPersonnalise, slugifier } = require('../utils/bulletin-personnalise-template');
const { construireHtmlBulletinAnnuel } = require('../utils/bulletin-annuel-template');
const { resoudreSignatures } = require('../utils/signatures.utils');
const { grouperParDomaine } = require('../utils/bulletin-assemblage-officiel');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Impression des bulletins archivés — duplicatas d'années scolaires clôturées.
 *
 * Pourquoi un contrôleur séparé plutôt qu'un paramètre de plus sur
 * bulletins.controller.js : les deux contextes n'ont presque rien en commun.
 *
 *  - La SOURCE des élèves diffère. Les écrans courants lisent `eleves.classe_id`,
 *    qui pointe vers la classe ACTUELLE. Sur une année révolue, cette colonne a
 *    changé (l'élève a été promu, ou a quitté l'école) : imprimer les bulletins
 *    de 5ème A de 2023-2024 en filtrant sur `classe_id` ne renverrait que les
 *    élèves encore inscrits dans cette même classe aujourd'hui — c'est-à-dire
 *    presque personne. On lit donc `eleve_classe_historique`, seule trace fiable
 *    de qui était où, et quand.
 *  - Le filtre `statut = 'actif'` doit sauter : un élève diplômé ou transféré a
 *    parfaitement le droit à un duplicata de son bulletin.
 *  - Aucun recalcul. Les écrans courants recalculent avant d'imprimer pour
 *    refléter les dernières notes saisies ; ici ce serait réécrire une archive.
 *    On restitue exactement ce qui a été figé à la clôture.
 *
 * Tout est en LECTURE SEULE : aucune requête de ce fichier n'écrit en base.
 */

/** Mention portée sur chaque duplicata, avec la date de réédition. */
function mentionDuplicata() {
  const date = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric'
  });
  return `Duplicata — réédité le ${date}`;
}

/**
 * Vérifie que l'année demandée est bien une année CLÔTURÉE de l'école, et que la
 * classe lui appartient. Sans ce contrôle, la route deviendrait un contournement
 * du cantonnement à l'année active : on pourrait imprimer l'année en cours en
 * passant par les archives, sans le contrôle financier ni les droits titulaire.
 */
async function chargerContexteArchive(client, anneeId, classeId) {
  const annee = await client.query(
    `SELECT id, libelle, cloturee FROM annees_scolaires
      WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
    [anneeId]
  );
  if (annee.rows.length === 0) {
    throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
  }
  if (!annee.rows[0].cloturee) {
    throw Object.assign(
      new Error("Cette année n'est pas clôturée : ses bulletins s'impriment depuis l'écran Bulletins, pas depuis les archives."),
      { statusCode: 400 }
    );
  }

  const classe = await client.query(
    `SELECT c.id, c.nom, c.cycle::text AS cycle, o.nom AS option_nom, s.nom AS section_nom
       FROM classes c
       LEFT JOIN options o ON o.id = c.option_id
       LEFT JOIN sections s ON s.id = c.section_id
      WHERE c.id = $1 AND c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $2`,
    [classeId, anneeId]
  );
  if (classe.rows.length === 0) {
    throw Object.assign(
      new Error("Cette classe n'appartient pas à l'année scolaire demandée."),
      { statusCode: 404 }
    );
  }

  const ecole = await client.query(
    `SELECT nom, ville, logo_url FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );

  return { annee: annee.rows[0], classe: classe.rows[0], ecole: ecole.rows[0] };
}

/**
 * Élèves d'une classe pour une année archivée, lus depuis l'historique.
 * `eleveId` restreint à un seul élève : c'est le cas du duplicata individuel,
 * de loin le plus fréquent au guichet.
 */
async function elevesArchives(client, anneeId, classeId, eleveId) {
  const conditions = [`h.annee_scolaire_id = $1`, `h.classe_id = $2`, `h.ecole_id = ${CURRENT_ECOLE}`];
  const params = [anneeId, classeId];
  if (eleveId) { params.push(eleveId); conditions.push(`h.eleve_id = $${params.length}`); }

  const r = await client.query(
    `SELECT DISTINCT e.id, e.nom, e.postnom, e.prenom, e.matricule
       FROM eleve_classe_historique h
       JOIN eleves e ON e.id = h.eleve_id
      WHERE ${conditions.join(' AND ')}
      ORDER BY e.nom, e.postnom`,
    params
  );
  if (r.rows.length === 0) {
    throw Object.assign(
      new Error("Aucun élève archivé pour cette classe et cette année."),
      { statusCode: 404 }
    );
  }
  return r.rows;
}

/**
 * Signatures et cachet, comme sur le bulletin d'origine.
 *
 * Délègue à utils/signatures.utils.js : ce module portait sa propre copie de la
 * règle « signature du titulaire, sinon celle de l'école », et une copie finit
 * toujours par diverger de l'original. Elle renvoie en plus de quoi nommer
 * correctement le signataire, ce que le duplicata n'imprimait pas.
 */
async function signatureEtCachet(client, classeId) {
  return resoudreSignatures(client, { classeId });
}

/** Fabrique le PDF à partir du HTML et le renvoie au client. */
async function rendrePdf(res, html, { nomFichier, paysage }) {
  let browser;
  try {
    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdf = await page.pdf({ format: 'A4', landscape: paysage === true, printBackground: true });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${nomFichier}"`);
    return res.send(pdf);
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

/**
 * GET /archives/annees/:anneeId/classes/:classeId/bulletins/imprimer?periodeId=&eleveId=
 * Duplicata du bulletin d'une période archivée : toute la classe, ou un élève.
 */
async function imprimerBulletinsPeriode(req, res) {
  const { anneeId, classeId } = req.params;
  const { periodeId, eleveId } = req.query;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { annee, classe, ecole } = await chargerContexteArchive(client, anneeId, classeId);

      const periode = await client.query(
        `SELECT libelle, type, numero FROM periodes
          WHERE id = $1 AND annee_scolaire_id = $2 AND ecole_id = ${CURRENT_ECOLE}`,
        [periodeId, anneeId]
      );
      if (periode.rows.length === 0) {
        throw Object.assign(
          new Error("Cette période n'appartient pas à l'année scolaire demandée."),
          { statusCode: 404 }
        );
      }
      const p = periode.rows[0];
      const periodeLibelle = p.libelle || `${p.type || ''} ${p.numero || ''}`.trim();

      const eleves = await elevesArchives(client, anneeId, classeId, eleveId);

      const cours = (await client.query(
        `SELECT cc.id AS classe_cours_id, c.nom, c.domaine, c.groupe_domaine,
                COALESCE(cc.maximum_points_override, c.maximum_points) AS maximum
           FROM classe_cours cc
           JOIN cours c ON c.id = cc.cours_id
          WHERE cc.classe_id = $1
          ORDER BY c.nom`,
        [classeId]
      )).rows;

      // Un duplicata doit ressembler à l'original : si les branches sont rangées
      // par domaine sur le bulletin délivré à l'époque, elles doivent l'être ici
      // aussi. Sans cela, le parent compare deux documents qui n'ont pas la même
      // tête et doute de celui qu'on vient de lui remettre.
      let domainesArchive = null;
      if (cours.some((c) => c.domaine)) {
        const groupement = grouperParDomaine(cours);
        domainesArchive = groupement.domaines;
        if (groupement.sansDomaine.length > 0) {
          domainesArchive = domainesArchive.concat([{ nom: 'AUTRES BRANCHES', cours: groupement.sansDomaine }]);
        }
      }
      const totalMaximum = cours.reduce((somme, c) => somme + Number(c.maximum || 0), 0);

      // Effectif complet de la classe à l'époque : le classement affiché est
      // "n / effectif", et cet effectif ne doit pas se réduire à 1 parce qu'on
      // imprime le duplicata d'un seul élève.
      const effectif = Number((await client.query(
        `SELECT count(DISTINCT h.eleve_id) AS n FROM eleve_classe_historique h
          WHERE h.annee_scolaire_id = $1 AND h.classe_id = $2 AND h.ecole_id = ${CURRENT_ECOLE}`,
        [anneeId, classeId]
      )).rows[0].n);

      for (const eleve of eleves) {
        const bulletin = await client.query(
          `SELECT total, pourcentage, classement, mention, conduite, application, observation
             FROM bulletins
            WHERE eleve_id = $1 AND periode_id = $2 AND ecole_id = ${CURRENT_ECOLE}`,
          [eleve.id, periodeId]
        );
        Object.assign(eleve, bulletin.rows[0] || {});
        eleve.total_maximum = totalMaximum;

        const notes = await client.query(
          `SELECT n.classe_cours_id, n.points_obtenus, c.nom AS cours_nom, c.code AS cours_code
             FROM notes n
             JOIN classe_cours cc ON cc.id = n.classe_cours_id
             JOIN cours c ON c.id = cc.cours_id
            WHERE n.eleve_id = $1 AND n.periode_id = $2 AND cc.classe_id = $3`,
          [eleve.id, periodeId, classeId]
        );
        eleve.notes = notes.rows;

        eleve.notesParSlug = {};
        for (const n of notes.rows) {
          if (n.points_obtenus === null) continue;
          if (n.cours_nom) eleve.notesParSlug[slugifier(n.cours_nom)] = n.points_obtenus;
          if (n.cours_code) eleve.notesParSlug[slugifier(n.cours_code)] = n.points_obtenus;
        }
      }

      // Même sélection de modèle que pour un bulletin courant : le duplicata doit
      // ressembler à l'original, pas à un document générique.
      const modele = await client.query(
        `SELECT * FROM modeles_bulletins
          WHERE type = 'periode' AND actif = true
            AND (ecole_id = ${CURRENT_ECOLE} OR ecole_id IS NULL)
            AND (cycle IS NULL OR cycle::text = $1)
          ORDER BY (cycle IS NULL), ecole_id NULLS LAST
          LIMIT 1`,
        [classe.cycle]
      );
      const modeleActif = modele.rows[0] || null;
      const zones = modeleActif
        ? (await client.query(`SELECT * FROM zones_modele WHERE modele_id = $1`, [modeleActif.id])).rows
        : [];

      // Seuil de réussite de l'école : il décide des cotes grisées sur le
      // bulletin. On lit le même paramètre que la promotion et les rapports,
      // pour qu'une branche en échec ici le soit aussi partout ailleurs.
      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuilReussite = Number(seuilResult.rows[0]?.seuil ?? 50);

      const signatures = await signatureEtCachet(client, classeId);

      return {
        ecole, classe, eleves, cours, periodeLibelle, effectif,
        anneeLibelle: annee.libelle, modeleActif, zones, signatures,
        domaines: domainesArchive, seuilReussite,
        signatureUrl: signatures.signatureUrl, cachetUrl: signatures.cachetUrl
      };
    });

    const personnalise = !!donnees.modeleActif;
    const html = personnalise
      ? construireHtmlBulletinPersonnalise({
          modele: donnees.modeleActif, zones: donnees.zones, eleves: donnees.eleves,
          classe: donnees.classe, periodeLibelle: donnees.periodeLibelle,
          anneeLibelle: donnees.anneeLibelle, ecole: donnees.ecole,
          signatureUrl: donnees.signatureUrl, cachetUrl: donnees.cachetUrl,
          mentionDuplicata: mentionDuplicata()
        })
      : construireHtmlBulletins({
          ecole: donnees.ecole, anneeLibelle: donnees.anneeLibelle,
          periodeLibelle: donnees.periodeLibelle, classe: donnees.classe,
          cours: donnees.cours, eleves: donnees.eleves,
          // Effectif de la classe à l'époque : sur un duplicata individuel, le
          // rang se lit sur la classe entière, pas sur le seul élève imprimé.
          effectif: donnees.effectif,
          domaines: donnees.domaines, seuilReussite: donnees.seuilReussite,
          signatureUrl: donnees.signatureUrl, cachetUrl: donnees.cachetUrl,
          // Sans ces trois-là, le duplicata écrivait « Signature autorisée »
          // même quand il imprimait bien celle du titulaire de la classe.
          signatureEstTitulaire: donnees.signatures.signatureEstTitulaire,
          signatureEstDirecteur: donnees.signatures.signatureEstDirecteur,
          signatureNom: donnees.signatures.signatureNom,
          mentionDuplicata: mentionDuplicata()
        });

    return rendrePdf(res, html, {
      nomFichier: `duplicata-bulletins-${donnees.anneeLibelle}-${donnees.classe.nom}.pdf`.replace(/\s+/g, '-'),
      paysage: !personnalise
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur impression bulletin archivé:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/annees/:anneeId/classes/:classeId/bulletin-annuel/imprimer?eleveId=
 * Duplicata du bulletin annuel d'une année archivée.
 *
 * Contrairement à l'écran courant, AUCUN recalcul n'est déclenché : on restitue
 * les bulletins annuels tels qu'ils ont été arrêtés. Si un bulletin annuel n'a
 * jamais été généré avant la clôture, il n'apparaîtra pas — on ne fabrique pas
 * après coup une pièce qui n'a jamais existé.
 */
async function imprimerBulletinAnnuel(req, res) {
  const { anneeId, classeId } = req.params;
  const { eleveId } = req.query;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { annee, classe, ecole } = await chargerContexteArchive(client, anneeId, classeId);
      const eleves = await elevesArchives(client, anneeId, classeId, eleveId);

      let auMoinsUnBulletin = false;
      for (const eleve of eleves) {
        const annuel = await client.query(
          `SELECT pourcentage AS moyenne_annuelle, classement AS classement_annuel,
                  mention AS mention_annuelle
             FROM bulletins
            WHERE eleve_id = $1 AND annee_scolaire_id = $2 AND periode_id IS NULL
              AND ecole_id = ${CURRENT_ECOLE}`,
          [eleve.id, anneeId]
        );
        Object.assign(eleve, annuel.rows[0] || {});
        if (annuel.rows.length > 0) auMoinsUnBulletin = true;

        const periodes = await client.query(
          `SELECT p.libelle, p.type, p.numero, b.total, b.pourcentage, b.classement, b.mention
             FROM periodes p
             LEFT JOIN bulletins b ON b.periode_id = p.id AND b.eleve_id = $2
            WHERE p.annee_scolaire_id = $1 AND p.type = 'semestre'
            ORDER BY p.numero`,
          [anneeId, eleve.id]
        );
        eleve.periodes = periodes.rows.map((p) => ({
          libelle: p.libelle || `${p.type} ${p.numero}`,
          total: p.total, pourcentage: p.pourcentage,
          classement: p.classement, mention: p.mention
        }));
      }

      if (!auMoinsUnBulletin) {
        throw Object.assign(
          new Error("Aucun bulletin annuel n'a été généré pour cette classe avant la clôture : il n'y a rien à rééditer."),
          { statusCode: 404 }
        );
      }

      // Le duplicata annuel n'imprimait aucune signature : ses deux cases
      // n'étaient que des traits, alors que l'original en porte.
      const signatures = await resoudreSignatures(client, { classeId });

      return {
        ecole, classe, anneeLibelle: annee.libelle, eleves,
        signatureTitulaireUrl: signatures.signatureTitulaireUrl,
        titulaireNom: signatures.titulaireNom,
        signatureChefUrl: signatures.signatureChefUrl,
        chefNom: signatures.chefNom,
        cachetUrl: signatures.cachetUrl
      };
    });

    const html = construireHtmlBulletinAnnuel({
      ...donnees, mentionDuplicata: mentionDuplicata()
    });

    return rendrePdf(res, html, {
      nomFichier: `duplicata-bulletin-annuel-${donnees.anneeLibelle}-${donnees.classe.nom}.pdf`.replace(/\s+/g, '-'),
      paysage: false
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur impression bulletin annuel archivé:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { imprimerBulletinsPeriode, imprimerBulletinAnnuel };
