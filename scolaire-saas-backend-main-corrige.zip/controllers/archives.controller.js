const XLSX = require('xlsx');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Les archives ne dupliquent aucune donnée : elles relisent les tables
 * existantes en se plaçant du point de vue d'une année révolue.
 *
 * Règle absolue de ce contrôleur : l'appartenance d'un élève à une classe
 * se lit dans eleve_classe_historique, JAMAIS dans eleves.classe_id.
 * Après une promotion, eleves.classe_id désigne la classe actuelle — s'en
 * servir afficherait les élèves de cette année dans l'archive de l'an dernier.
 */

function nomComplet(e) {
  return [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ');
}

function enveloppeExcel(res, feuilles, nomFichier) {
  const classeur = XLSX.utils.book_new();
  for (const [nom, lignes] of Object.entries(feuilles)) {
    XLSX.utils.book_append_sheet(
      classeur,
      XLSX.utils.json_to_sheet(lignes.length ? lignes : [{ Information: 'Aucune donnée' }]),
      nom.slice(0, 31)   // Excel refuse les noms d'onglet au-delà de 31 caractères
    );
  }
  const tampon = XLSX.write(classeur, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${nomFichier}"`);
  return res.send(tampon);
}

/** Nom de fichier sûr : sans accent, sans espace, sans caractère interdit. */
function nomSur(texte) {
  return String(texte || 'export')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'export';
}

/**
 * GET /archives/annees
 * Premier niveau : un dossier par année scolaire clôturée.
 */
async function listerAnnees(req, res) {
  try {
    const lignes = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT a.id, a.libelle, a.date_debut, a.date_fin,
                (SELECT count(*) FROM classes c WHERE c.annee_scolaire_id = a.id) AS nb_classes,
                (SELECT count(DISTINCT h.eleve_id) FROM eleve_classe_historique h
                  WHERE h.annee_scolaire_id = a.id) AS nb_eleves,
                (SELECT count(*) FROM bulletins b
                   JOIN periodes p ON p.id = b.periode_id
                  WHERE p.annee_scolaire_id = a.id) AS nb_bulletins
         FROM annees_scolaires a
         WHERE a.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true
         ORDER BY a.date_debut DESC NULLS LAST, a.libelle DESC`
      )
    );
    return res.json(lignes.rows.map((a) => ({
      ...a,
      nb_classes: Number(a.nb_classes),
      nb_eleves: Number(a.nb_eleves),
      nb_bulletins: Number(a.nb_bulletins)
    })));
  } catch (err) {
    console.error('Erreur liste années archivées:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/annees/:anneeId/classes
 * Deuxième niveau : les classes de cette année-là.
 */
async function listerClasses(req, res) {
  const { anneeId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await client.query(
        `SELECT id, libelle FROM annees_scolaires
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND cloturee = true`,
        [anneeId]
      );
      if (annee.rows.length === 0) {
        throw Object.assign(new Error('Année archivée introuvable.'), { statusCode: 404 });
      }

      const classes = await client.query(
        `SELECT c.id, c.nom, c.cycle::text AS cycle,
                o.nom AS option_nom,
                v.nom AS vacation_nom,
                trim(concat(u.prenom, ' ', u.nom)) AS titulaire_nom,
                (SELECT count(*) FROM eleve_classe_historique h
                  WHERE h.classe_id = c.id AND h.annee_scolaire_id = $1) AS nb_eleves
         FROM classes c
         LEFT JOIN options o ON o.id = c.option_id
         LEFT JOIN utilisateurs u ON u.id = c.titulaire_id
         LEFT JOIN vacations v ON v.id = c.vacation_id
         WHERE c.annee_scolaire_id = $1 AND c.ecole_id = ${CURRENT_ECOLE}
         ORDER BY c.nom`,
        [anneeId]
      );

      return {
        annee: annee.rows[0],
        classes: classes.rows.map((c) => ({ ...c, nb_eleves: Number(c.nb_eleves) }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur classes archivées:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/annees/:anneeId/classes/:classeId/periodes
 * Troisième niveau : les périodes, avec l'état des bulletins de la classe.
 */
async function listerPeriodes(req, res) {
  const { anneeId, classeId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classe = await client.query(
        `SELECT c.id, c.nom, c.cycle::text AS cycle, a.libelle AS annee_libelle
         FROM classes c JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
         WHERE c.id = $1 AND c.annee_scolaire_id = $2 AND c.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true`,
        [classeId, anneeId]
      );
      if (classe.rows.length === 0) {
        throw Object.assign(new Error('Classe archivée introuvable.'), { statusCode: 404 });
      }

      // Sans ce filtre, une classe de primaire archivée voyait remonter les
      // semestres du secondaire de la même année scolaire (et vice versa) dès
      // que l'école avait les deux cycles : les deux arbres de périodes
      // partagent le même annee_scolaire_id, seul le cycle les distingue.
      // `p.cycle IS NULL` couvre les périodes créées avant la migration 003
      // dans une école qui n'avait alors qu'un seul cycle.
      const periodes = await client.query(
        `SELECT p.id, p.libelle, p.type, p.numero, p.date_debut, p.date_fin,
                (SELECT count(*) FROM bulletins b
                   JOIN eleve_classe_historique h
                     ON h.eleve_id = b.eleve_id AND h.annee_scolaire_id = $2
                  WHERE b.periode_id = p.id AND h.classe_id = $1) AS nb_bulletins,
                (SELECT count(*) FROM bulletins b
                   JOIN eleve_classe_historique h
                     ON h.eleve_id = b.eleve_id AND h.annee_scolaire_id = $2
                  WHERE b.periode_id = p.id AND h.classe_id = $1 AND b.signe_at IS NOT NULL) AS nb_signes
         FROM periodes p
         WHERE p.annee_scolaire_id = $2 AND p.ecole_id = ${CURRENT_ECOLE}
           AND (p.cycle IS NULL OR p.cycle::text = $3)
         ORDER BY p.numero, p.libelle`,
        [classeId, anneeId, classe.rows[0].cycle]
      );

      return {
        classe: classe.rows[0],
        periodes: periodes.rows.map((p) => ({
          ...p,
          nb_bulletins: Number(p.nb_bulletins),
          nb_signes: Number(p.nb_signes)
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur périodes archivées:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/annees/:anneeId/classes/:classeId/eleves?periodeId=
 * Quatrième niveau : les élèves tels qu'ils étaient inscrits cette année-là.
 */
async function listerEleves(req, res) {
  const { anneeId, classeId } = req.params;
  const { periodeId } = req.query;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const contexte = await client.query(
        `SELECT c.nom AS classe_nom, a.libelle AS annee_libelle
         FROM classes c JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
         WHERE c.id = $1 AND c.annee_scolaire_id = $2 AND c.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true`,
        [classeId, anneeId]
      );
      if (contexte.rows.length === 0) {
        throw Object.assign(new Error('Classe archivée introuvable.'), { statusCode: 404 });
      }

      let periode = null;
      if (periodeId) {
        const p = await client.query(
          `SELECT id, libelle, type, numero FROM periodes
           WHERE id = $1 AND annee_scolaire_id = $2`, [periodeId, anneeId]
        );
        periode = p.rows[0] || null;
      }

      const eleves = await client.query(
        `SELECT e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom, e.sexe,
                h.resultat_final,
                b.total, b.pourcentage, b.classement, b.mention,
                b.conduite, b.application, b.signe_at
         FROM eleve_classe_historique h
         JOIN eleves e ON e.id = h.eleve_id
         LEFT JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $3::uuid
         WHERE h.classe_id = $1 AND h.annee_scolaire_id = $2
         ORDER BY COALESCE(b.classement, 999999), e.nom, e.postnom, e.prenom`,
        [classeId, anneeId, periodeId || null]
      );

      return {
        annee_libelle: contexte.rows[0].annee_libelle,
        classe_nom: contexte.rows[0].classe_nom,
        periode,
        eleves: eleves.rows
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur élèves archivés:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/annees/:anneeId/eleves/:eleveId
 * Dossier complet d'un élève pour une année révolue : identité, classe,
 * bulletins de chaque période, détail des cours, assiduité et discipline.
 */
async function dossierEleve(req, res) {
  const { anneeId, eleveId } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const inscription = await client.query(
        `SELECT e.id, e.matricule, e.nom, e.postnom, e.prenom, e.sexe, e.date_naissance,
                e.responsable_nom, e.responsable_telephone,
                h.resultat_final, c.id AS classe_id, c.nom AS classe_nom,
                a.libelle AS annee_libelle
         FROM eleve_classe_historique h
         JOIN eleves e ON e.id = h.eleve_id
         JOIN classes c ON c.id = h.classe_id
         JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
         WHERE h.eleve_id = $1 AND h.annee_scolaire_id = $2
           AND h.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true`,
        [eleveId, anneeId]
      );
      if (inscription.rows.length === 0) {
        throw Object.assign(
          new Error("Cet élève n'a pas d'inscription archivée pour cette année."),
          { statusCode: 404 }
        );
      }
      const dossier = inscription.rows[0];

      const bulletins = await client.query(
        `SELECT p.id AS periode_id, p.libelle AS periode, p.type, p.numero,
                b.total, b.pourcentage, b.classement, b.mention,
                b.conduite, b.application, b.observation, b.signe_at
         FROM periodes p
         LEFT JOIN bulletins b ON b.periode_id = p.id AND b.eleve_id = $1
         WHERE p.annee_scolaire_id = $2
         ORDER BY p.numero, p.libelle`,
        [eleveId, anneeId]
      );

      const notes = await client.query(
        `SELECT co.nom AS cours, p.libelle AS periode, p.numero,
                n.points_obtenus,
                COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum
         FROM notes n
         JOIN classe_cours cc ON cc.id = n.classe_cours_id
         JOIN cours co ON co.id = cc.cours_id
         JOIN periodes p ON p.id = n.periode_id
         WHERE n.eleve_id = $1 AND p.annee_scolaire_id = $2 AND cc.classe_id = $3
         ORDER BY p.numero, co.nom`,
        [eleveId, anneeId, dossier.classe_id]
      );

      // Assiduité et discipline peuvent ne pas exister sur les années
      // antérieures à la mise en service de ces modules : l'absence de
      // ligne est normale et ne doit pas être présentée comme une anomalie.
      const presences = await client.query(
        `SELECT count(*) FILTER (WHERE statut = 'present') AS present,
                count(*) FILTER (WHERE statut = 'absent')  AS absent,
                count(*) FILTER (WHERE statut = 'retard')  AS retard,
                count(*) FILTER (WHERE statut = 'excuse')  AS excuse,
                count(*) AS total
         FROM presences pr
         JOIN periodes p ON p.annee_scolaire_id = $2
          AND pr.date_jour BETWEEN COALESCE(p.date_debut, '1900-01-01') AND COALESCE(p.date_fin, '2999-12-31')
         WHERE pr.eleve_id = $1`,
        [eleveId, anneeId]
      );

      const discipline = await client.query(
        `SELECT i.date_incident, i.type, i.points, i.description, i.mesure
         FROM incidents_discipline i
         WHERE i.eleve_id = $1 AND i.annee_scolaire_id = $2
         ORDER BY i.date_incident DESC`,
        [eleveId, anneeId]
      );

      // Orientation : le vœu exprimé et l'option obtenue expliquent la
      // trajectoire de l'élève. Sans cette trace, on ne saurait plus, des
      // années après, pourquoi il est passé en Scientifique plutôt qu'en
      // Commerciale — ni si c'était son choix.
      const orientation = await client.query(
        `SELECT ov.nom AS voeu, orep.nom AS repli, oacc.nom AS obtenue,
                ca.nom AS classe_affectee, o.statut::text, o.attribue_au_merite, o.motif,
                trim(concat(u.prenom, ' ', u.nom)) AS decide_par_nom
         FROM orientations o
         LEFT JOIN options ov ON ov.id = o.option_voeu_id
         LEFT JOIN options orep ON orep.id = o.option_repli_id
         LEFT JOIN options oacc ON oacc.id = o.option_accordee_id
         LEFT JOIN classes ca ON ca.id = o.classe_affectee_id
         LEFT JOIN utilisateurs u ON u.id = o.decide_par
         WHERE o.eleve_id = $1 AND o.annee_scolaire_id = $2`,
        [eleveId, anneeId]
      );

      // Origine : un élève entré par concours garde le lien vers sa session
      // et son rang. C'est ce qui permet de justifier une admission plusieurs
      // années plus tard, notamment en cas de contestation.
      const origine = await client.query(
        `SELECT s.libelle AS session, s.date_test, s.places,
                k.numero_candidat, k.total, k.rang, k.recommande, k.motif_recommandation
         FROM candidats k
         JOIN sessions_inscription s ON s.id = k.session_id
         WHERE k.eleve_id = $1`,
        [eleveId]
      );

      const p = presences.rows[0];
      return {
        eleve: dossier,
        orientation: orientation.rows[0]
          ? { ...orientation.rows[0], attribue_au_merite: orientation.rows[0].attribue_au_merite === true }
          : null,
        origine: origine.rows[0]
          ? {
              ...origine.rows[0],
              total: origine.rows[0].total === null ? null : Number(origine.rows[0].total),
              places: Number(origine.rows[0].places),
              recommande: origine.rows[0].recommande === true
            }
          : null,
        bulletins: bulletins.rows,
        notes: notes.rows,
        assiduite: Number(p.total) > 0 ? {
          present: Number(p.present), absent: Number(p.absent),
          retard: Number(p.retard), excuse: Number(p.excuse), total: Number(p.total)
        } : null,
        discipline: discipline.rows.map((d) => ({ ...d, points: Number(d.points) }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur dossier archivé:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/export/classe/:anneeId/:classeId
 * Classeur Excel : une feuille par période, plus une feuille de synthèse.
 */
async function exporterClasse(req, res) {
  const { anneeId, classeId } = req.params;

  try {
    const { feuilles, nomFichier } = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const contexte = await client.query(
        `SELECT c.nom AS classe_nom, a.libelle AS annee_libelle
         FROM classes c JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
         WHERE c.id = $1 AND c.annee_scolaire_id = $2 AND c.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true`,
        [classeId, anneeId]
      );
      if (contexte.rows.length === 0) {
        throw Object.assign(new Error('Classe archivée introuvable.'), { statusCode: 404 });
      }
      const { classe_nom, annee_libelle } = contexte.rows[0];

      const periodes = await client.query(
        `SELECT id, libelle, type, numero FROM periodes
         WHERE annee_scolaire_id = $1 ORDER BY numero, libelle`,
        [anneeId]
      );

      const feuilles = {};

      const synthese = await client.query(
        `SELECT e.matricule, e.nom, e.postnom, e.prenom, e.sexe, h.resultat_final
         FROM eleve_classe_historique h
         JOIN eleves e ON e.id = h.eleve_id
         WHERE h.classe_id = $1 AND h.annee_scolaire_id = $2
         ORDER BY e.nom, e.postnom`,
        [classeId, anneeId]
      );
      feuilles['Eleves'] = synthese.rows.map((e) => ({
        Matricule: e.matricule, Nom: e.nom, Postnom: e.postnom || '',
        Prenom: e.prenom || '', Sexe: e.sexe || '',
        Resultat: e.resultat_final || ''
      }));

      for (const periode of periodes.rows) {
        const r = await client.query(
          `SELECT e.matricule, e.nom, e.postnom, e.prenom,
                  b.total, b.pourcentage, b.classement, b.mention, b.conduite, b.application
           FROM eleve_classe_historique h
           JOIN eleves e ON e.id = h.eleve_id
           LEFT JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $3
           WHERE h.classe_id = $1 AND h.annee_scolaire_id = $2
           ORDER BY COALESCE(b.classement, 999999), e.nom`,
          [classeId, anneeId, periode.id]
        );
        const nomFeuille = periode.libelle || `${periode.type} ${periode.numero}`;
        feuilles[nomFeuille] = r.rows.map((l) => ({
          Matricule: l.matricule,
          Eleve: nomComplet(l),
          Total: l.total ?? '',
          Pourcentage: l.pourcentage ?? '',
          Place: l.classement ?? '',
          Mention: l.mention || '',
          Conduite: l.conduite || '',
          Application: l.application || ''
        }));
      }

      return {
        feuilles,
        nomFichier: `archive-${nomSur(annee_libelle)}-${nomSur(classe_nom)}.xlsx`
      };
    });

    return enveloppeExcel(res, feuilles, nomFichier);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur export classe archivée:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /archives/export/annee/:anneeId
 * Classeur Excel de toute l'année : une feuille par classe.
 */
async function exporterAnnee(req, res) {
  const { anneeId } = req.params;

  try {
    const { feuilles, nomFichier } = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await client.query(
        `SELECT libelle FROM annees_scolaires
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND cloturee = true`,
        [anneeId]
      );
      if (annee.rows.length === 0) {
        throw Object.assign(new Error('Année archivée introuvable.'), { statusCode: 404 });
      }

      const classes = await client.query(
        `SELECT id, nom FROM classes WHERE annee_scolaire_id = $1 ORDER BY nom`, [anneeId]
      );

      const feuilles = {};
      for (const classe of classes.rows) {
        const r = await client.query(
          `SELECT e.matricule, e.nom, e.postnom, e.prenom, e.sexe, h.resultat_final
           FROM eleve_classe_historique h
           JOIN eleves e ON e.id = h.eleve_id
           WHERE h.classe_id = $1 AND h.annee_scolaire_id = $2
           ORDER BY e.nom, e.postnom`,
          [classe.id, anneeId]
        );
        feuilles[classe.nom] = r.rows.map((e) => ({
          Matricule: e.matricule, Eleve: nomComplet(e),
          Sexe: e.sexe || '', Resultat: e.resultat_final || ''
        }));
      }

      return {
        feuilles,
        nomFichier: `archive-complete-${nomSur(annee.rows[0].libelle)}.xlsx`
      };
    });

    return enveloppeExcel(res, feuilles, nomFichier);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur export année archivée:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /archives/purger-candidats
 * body : { anneeId }
 *
 * Efface les données personnelles des candidats NON admis d'une année
 * archivée. Ce sont des mineurs qui ne sont jamais devenus élèves : rien ne
 * justifie de conserver leur identité indéfiniment, et notre politique de
 * confidentialité s'y engage. Les statistiques de la session sont préservées :
 * on garde le nombre de candidats et les notes, on retire les identités.
 */
async function purgerCandidats(req, res) {
  const { anneeId } = req.body;
  if (!anneeId) return res.status(400).json({ message: 'anneeId est requis.' });

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await client.query(
        `SELECT libelle FROM annees_scolaires
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND cloturee = true`,
        [anneeId]
      );
      if (annee.rows.length === 0) {
        throw Object.assign(
          new Error('Seule une année clôturée peut être purgée.'),
          { statusCode: 409 }
        );
      }

      // Anonymisation plutôt que suppression : effacer les lignes fausserait
      // le nombre de candidats de la session, donc la lecture du concours.
      const r = await client.query(
        `UPDATE candidats k
         SET nom = 'Candidat anonymisé', postnom = NULL, prenom = NULL,
             date_naissance = NULL, responsable_nom = NULL,
             responsable_telephone = NULL, responsable_email = NULL,
             ecole_provenance = NULL
         FROM sessions_inscription s
         WHERE s.id = k.session_id AND s.annee_scolaire_id = $1
           AND k.ecole_id = ${CURRENT_ECOLE}
           AND k.eleve_id IS NULL
           AND k.nom <> 'Candidat anonymisé'`,
        [anneeId]
      );

      return { anonymises: r.rowCount, annee: annee.rows[0].libelle };
    });

    return res.json({
      message: bilan.anonymises === 0
        ? "Aucune donnée à anonymiser : c'est déjà fait, ou tous les candidats sont devenus élèves."
        : `${bilan.anonymises} candidat(s) non admis de ${bilan.annee} anonymisé(s). Les statistiques du concours sont conservées.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur purge candidats:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  purgerCandidats,
  listerAnnees,
  listerClasses,
  listerPeriodes,
  listerEleves,
  dossierEleve,
  exporterClasse,
  exporterAnnee
};
