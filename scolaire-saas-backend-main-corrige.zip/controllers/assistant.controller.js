const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { appelerIA, consommerQuota } = require('../utils/ia.utils');
const {
  ORDRE_CONFIGURATION, PROCEDURES, LEXIQUE,
  MANUELS_ROLE, LIBELLES_ROLE, PERIMETRE_ROLE
} = require('../utils/connaissance.utils');
const onboarding = require('../utils/onboarding.utils');
const catalogue = require('../utils/catalogue.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  ASSISTANT D'AIDE À L'UTILISATION
 * ===========================================================================
 *
 * OUVERT À TOUS, MAIS PAS À TOUT
 * ------------------------------
 * Contrairement à l'assistant d'analyse du journal, celui-ci est accessible à
 * TOUS les rôles — un professeur, un comptable, un secrétaire doivent pouvoir
 * demander « comment je fais pour… » sans passer par le directeur.
 *
 * Ce qui rend cette ouverture possible, c'est qu'il ne voit AUCUNE donnée de
 * l'école. Ni élèves, ni notes, ni paiements, ni journal. Il ne connaît que le
 * fonctionnement de la plateforme. Un professeur peut donc lui demander
 * comment saisir ses cotes sans qu'il puisse lui révéler celles d'un collègue.
 *
 * LES RESTRICTIONS, ET CE QU'ELLES PROTÈGENT
 * ------------------------------------------
 *   · Aucun accès aux données          → protège la confidentialité entre rôles
 *   · Réponse cadrée par le RÔLE       → on n'explique pas à un professeur une
 *                                        manœuvre qu'il n'a pas le droit de faire
 *   · Quota d'école partagé            → l'IA est une option payante ; sans
 *                                        quota, l'écran renvoie vers le manuel
 *   · Limite de fréquence par personne → évite qu'un seul utilisateur épuise
 *                                        le quota de toute l'école
 *   · Question bornée à 400 caractères → c'est une question, pas un document
 *
 * ET QUAND L'IA N'EST PAS DISPONIBLE
 * ----------------------------------
 * Le manuel de procédure du rôle couvre les mêmes gestes, et l'endpoint
 * `GET /assistant/manuel` le renvoie en texte structuré. L'écran doit toujours
 * proposer cette porte de sortie : une école sans l'offre IA n'est pas une
 * école sans aide.
 */

// Fréquence par utilisateur. Volontairement généreuse — il s'agit d'empêcher
// une boucle ou un abus, pas de rationner quelqu'un qui apprend.
const FENETRE_MS = 10 * 60 * 1000;
const MAX_PAR_FENETRE = 15;
const compteurs = new Map();

function limiteAtteinte(userId) {
  const maintenant = Date.now();
  const entree = compteurs.get(userId);
  if (!entree || maintenant - entree.debut > FENETRE_MS) {
    compteurs.set(userId, { debut: maintenant, nb: 1 });
    return false;
  }
  entree.nb++;
  return entree.nb > MAX_PAR_FENETRE;
}

// Purge périodique : sans elle, la table grossirait indéfiniment sur un
// serveur qui ne redémarre pas.
setInterval(() => {
  const maintenant = Date.now();
  for (const [cle, v] of compteurs) {
    if (maintenant - v.debut > FENETRE_MS) compteurs.delete(cle);
  }
}, FENETRE_MS).unref();

/*
 *  LES LIBELLÉS ET LES PÉRIMÈTRES ONT DÉMÉNAGÉ
 *  -------------------------------------------
 *  Ils étaient écrits ici, en dur. Deux tables de huit lignes, alors que la
 *  base compte dix rôles : « charge_presences » n'y figurait dans aucune des
 *  deux. Conséquence directe, et invisible tant qu'on ne se connecte pas avec
 *  ce rôle : `GET /assistant/manuel` lui renvoyait le code brut
 *  « charge_presences » en guise de libellé, un périmètre `null`, une liste
 *  d'étapes vide et une liste de procédures vide — un manuel qui n'existait
 *  pas. L'assistant, de son côté, ne recevait aucun cadrage pour ce rôle et
 *  répondait donc comme à un utilisateur sans droits connus.
 *
 *  Les deux tables sont maintenant dérivées de `MANUELS_ROLE`, dans
 *  `connaissance.utils.js` : ajouter un rôle là-bas suffit désormais à lui
 *  donner un libellé, un périmètre ET un manuel, sans qu'on puisse en oublier
 *  un des trois.
 */

function consigne(roles, page) {
  const roleLisible = roles.map((r) => LIBELLES_ROLE[r] || r).join(', ') || 'Utilisateur';
  const perimetre = roles.map((r) => PERIMETRE_ROLE[r]).filter(Boolean).join(' ');

  // Le détail CHAMP PAR CHAMP est transmis. Sans lui, l'assistant savait dire
  // « allez dans Classes » et rien de plus — or la question réellement posée
  // est « qu'est-ce que je mets dans ce champ ? ». Le coût en jetons est réel
  // mais borné : c'est un texte fixe, mis en cache par le fournisseur.
  const etapes = ORDRE_CONFIGURATION.map((e) =>
    `${e.etape}. ${e.titre} — écran « ${e.ecran} ». ${e.quoi}\n`
    + `   Contenu de l'écran :\n${(e.champs || []).map((c) => `     - ${c}`).join('\n')}\n`
    + `   Pourquoi : ${e.pourquoi}\n   Piège : ${e.piege}`
  ).join('\n\n');

  const procedures = Object.values(PROCEDURES).map((p) =>
    `${p.titre} — écran « ${p.ecran || '?'} » (${p.roles.join(', ')}) :\n`
    + p.etapes.map((x, i) => `   ${i + 1}. ${x}`).join('\n')
    + `\n   À savoir : ${p.remarque}`
  ).join('\n\n');

  // Ce que le rôle NE PEUT PAS faire. L'assistant expliquait volontiers une
  // manœuvre hors périmètre parce qu'il ne connaissait que les droits, jamais
  // les limites — et la personne s'épuisait à chercher un bouton absent.
  const limites = roles
    .map((r) => (MANUELS_ROLE[r] ? `${MANUELS_ROLE[r].libelle} : ${MANUELS_ROLE[r].ne_peut_pas}` : null))
    .filter(Boolean).join('\n');

  const ecrans = roles
    .map((r) => (MANUELS_ROLE[r] ? MANUELS_ROLE[r].ecrans : []))
    .reduce((a, b) => a.concat(b), [])
    .filter((v, i, t) => t.indexOf(v) === i)
    .join(' · ');

  const lexique = Object.entries(LEXIQUE).map(([mot, def]) => `${mot} : ${def}`).join('\n');

  return `Tu es l'assistant d'aide d'Ardoise, une plateforme de gestion scolaire utilisée en République Démocratique du Congo. Tu expliques COMMENT UTILISER le logiciel.

PERSONNE À QUI TU RÉPONDS
Rôle : ${roleLisible}.
Ce qu'elle peut faire : ${perimetre}
Ce qu'elle NE PEUT PAS faire : ${limites || 'non précisé'}
Les écrans auxquels elle a accès : ${ecrans || 'non précisé'}
${page ? `Elle se trouve actuellement sur l'écran : ${page}.` : ''}

TU N'AS AUCUN ACCÈS AUX DONNÉES DE L'ÉCOLE.
Tu ne connais aucun élève, aucune note, aucun paiement, aucun montant. Si on te
demande une information réelle (« quelle est la moyenne de Kabila ? », « combien
a payé cette famille ? »), tu réponds que tu n'as pas accès aux données et tu
indiques l'écran où la personne trouvera elle-même la réponse.

RÈGLES DE RÉPONSE
- Dès qu'on te demande COMMENT faire quelque chose, réponds par la procédure numérotée EXACTE, reprise telle quelle des procédures ci-dessous : le nom de l'écran, l'onglet, puis chaque clic et chaque champ dans l'ordre. Ne résume pas une procédure en une phrase.
- Nomme les écrans, les onglets, les champs et les boutons tels qu'ils apparaissent dans la plateforme, entre guillemets.
- Quand un champ prête à confusion, dis ce qu'il faut y mettre, pas seulement qu'il existe.
- Si l'écran demandé n'est pas dans la liste des écrans accessibles à cette personne, dis-le avant d'expliquer quoi que ce soit.
- Pour tout le reste, réponds en français simple, en 2 à 6 phrases.
- Si la manœuvre demandée dépasse le périmètre du rôle, dis-le et indique qui peut la faire — sans reproche.
- Si tu n'es pas certain, dis-le et renvoie vers le directeur ou le manuel de procédure. N'invente jamais un écran, un bouton ou un réglage.
- Ne donne aucun conseil juridique, médical ou disciplinaire sur un cas particulier : tu expliques l'outil, pas les décisions de l'école.
- Pas de salutation ni de formule de politesse d'ouverture : va droit à la réponse.

ORDRE DE CONFIGURATION DE LA PLATEFORME
${etapes}

PROCÉDURES COURANTES
${procedures}

VOCABULAIRE
${lexique}`;
}

/**
 * POST /assistant/question
 * body : { question, page? }
 */
async function question(req, res) {
  const texte = String(req.body.question || '').trim();
  const page = req.body.page ? String(req.body.page).slice(0, 60) : null;

  if (texte.length < 5) {
    return res.status(400).json({ message: 'Posez une question un peu plus précise.' });
  }
  if (texte.length > 400) {
    return res.status(400).json({ message: 'Question trop longue (400 caractères maximum).' });
  }
  if (limiteAtteinte(req.auth.userId)) {
    return res.status(429).json({
      message: "Vous avez posé beaucoup de questions d'affilée. Reprenez dans quelques minutes, "
        + "ou consultez le manuel de votre rôle en attendant.",
      manuel_disponible: true
    });
  }

  try {
    const reponse = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await consommerQuota(client, req.auth.ecoleId, 1);
      return appelerIA({
        systeme: consigne(req.auth.roles || [], page),
        message: texte,
        maxTokens: 700
      });
    });

    return res.json({ question: texte, reponse: String(reponse).trim() });
  } catch (err) {
    // Quota épuisé : l'école n'a pas (ou plus) l'offre incluant l'IA. Ce n'est
    // pas une panne, et l'utilisateur ne doit pas rester sans réponse.
    if (err.statusCode === 429 || /quota/i.test(err.message || '')) {
      return res.status(429).json({
        message: "L'assistant n'est pas disponible pour votre école. Le manuel de votre rôle "
          + "couvre les mêmes procédures.",
        manuel_disponible: true
      });
    }
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur assistant:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /assistant/manuel
 *
 * Le manuel du rôle, en données structurées. C'est la porte de sortie quand
 * l'IA n'est pas disponible — et elle doit rester ouverte en permanence, pas
 * seulement en cas d'échec : certaines personnes préfèrent lire une procédure
 * plutôt que de dialoguer.
 */
async function manuel(req, res) {
  const roles = (req.auth.roles || []).filter(Boolean);

  /* Les droits d'offre servent UNIQUEMENT à la table des matières du centre
     d'apprentissage. Le manuel de procédure, lui, reste entier : expliquer ce
     que fait un rôle n'a jamais dépendu de ce que l'école a souscrit, et
     amputer le manuel priverait de repères une personne qui cherche à
     comprendre pourquoi un écran lui est fermé.

     Lecture protégée : si elle échoue, le centre n'est simplement pas filtré. */
  let droits = null;
  try {
    droits = await runWithTenant(tenantContextFromReq(req),
      (client) => chargerDroits(client, req.auth.ecoleId));
  } catch (err) {
    droits = null;
  }

  /* ------------------------------------------------------------------
     LE MANUEL NE PEUT PLUS ÊTRE VIDE

     Il se construisait uniquement par filtrage : on gardait les étapes et
     les procédures dont la liste `roles` mentionnait le rôle demandé. Un
     rôle qu'aucune procédure ne mentionnait recevait donc, sans le moindre
     signal, un document vide — c'était le cas du Chargé des présences.

     Désormais le manuel part de `MANUELS_ROLE`, qui garantit à chaque rôle
     un socle propre (périmètre, limites, écrans, premiers pas), et le
     filtrage ne fait plus qu'AJOUTER. Un rôle inconnu du catalogue reçoit
     un manuel générique honnête plutôt qu'une page blanche.
     ------------------------------------------------------------------ */

  const fiches = roles.map((r) => {
    const m = MANUELS_ROLE[r];
    if (!m) {
      return {
        code: r, libelle: r,
        perimetre: null, ne_peut_pas: null, ecrans: [], premiers_pas: [],
        note: "Ce rôle n'a pas encore de manuel détaillé. Les procédures ci-dessous restent valables."
      };
    }
    return {
      code: r,
      libelle: m.libelle,
      perimetre: m.perimetre,
      ne_peut_pas: m.ne_peut_pas,
      ecrans: m.ecrans,
      premiers_pas: m.premiers_pas
    };
  });

  // Les procédures mises en avant par le manuel du rôle, dans l'ordre où
  // elles y sont citées : c'est un ordre d'usage, pas alphabétique.
  const codesEnAvant = [];
  roles.forEach((r) => {
    const m = MANUELS_ROLE[r];
    if (!m) return;
    (m.procedures || []).forEach((c) => {
      if (PROCEDURES[c] && !codesEnAvant.includes(c)) codesEnAvant.push(c);
    });
  });

  // Puis toutes les autres procédures ouvertes à ces rôles.
  const codesRestants = Object.keys(PROCEDURES).filter((code) =>
    !codesEnAvant.includes(code) && PROCEDURES[code].roles.some((r) => roles.includes(r)));

  const enProcedure = (code) => ({ code, ...PROCEDURES[code] });

  const etapes = ORDRE_CONFIGURATION
    .filter((e) => e.roles.some((r) => roles.includes(r)))
    .map((e) => ({ ...e }));

  return res.json({
    // Champ conservé à l'identique : l'onglet Assistant de la messagerie le
    // lit déjà sous cette forme.
    roles: fiches.map((f) => ({ code: f.code, libelle: f.libelle, perimetre: f.perimetre })),
    // Le manuel proprement dit, plus riche : limites, écrans, premiers pas.
    fiches,
    // La configuration ne concerne que la direction : un professeur reçoit un
    // manuel vide de ce côté, et c'est normal — on ne lui montre pas des
    // écrans auxquels il n'a pas accès. Chaque étape porte désormais son
    // champ `champs` : le contenu réel de la fenêtre, et non son seul nom.
    configuration: etapes,
    // L'essentiel d'abord, le reste ensuite. Un professeur qui cherche
    // « comment j'encode une cote » trouvait sa procédure en huitième
    // position, derrière celles de rôles qu'il ne partageait qu'en partie.
    procedures: codesEnAvant.map(enProcedure).concat(codesRestants.map(enProcedure)),
    lexique: LEXIQUE,
    // Table des matières « Apprendre Ardoise », filtrée par rôle.
    centre: onboarding.centreApprentissage(roles, droits ? droits.fonctionnalites : null)
  });
}

/*
 *  UN SOCLE ET UNE EXTENSION, PLUTÔT QU'UNE SEULE REQUÊTE
 *  ------------------------------------------------------
 *  Le SOCLE reprend exactement les signaux de la version précédente. Chacun
 *  d'eux tourne en production depuis que le didacticiel existe : on sait qu'ils
 *  passent.
 *
 *  L'EXTENSION ajoute les signaux nouveaux. Deux d'entre eux touchent des
 *  tables qu'aucune requête du dépôt n'interroge aujourd'hui par `ecole_id` —
 *  `sections` en particulier n'apparaît que jointe depuis `classes`. Le manuel
 *  de reprise du projet est explicite sur ce point : plusieurs migrations n'ont
 *  jamais été jouées contre une vraie base, et une colonne peut manquer sans
 *  que personne l'ait remarqué.
 *
 *  Si l'extension échoue, on retombe sur le socle et le didacticiel continue de
 *  fonctionner en mode réduit. C'est la seule disposition acceptable : ces deux
 *  requêtes alimentent AUSSI `/assistant/etat-installation`, une fonctionnalité
 *  qui marche aujourd'hui. Une colonne absente ne doit pas la faire tomber.
 *
 *  Le coût du cas normal reste d'un aller-retour : l'extension contient le
 *  socle, et la seconde requête n'est jouée que si la première a échoué.
 */
const CHAMPS_SOCLE = `
       (SELECT type_enseignement::text FROM ecoles WHERE id = ${CURRENT_ECOLE}) AS type_enseignement,
       (SELECT nom FROM ecoles WHERE id = ${CURRENT_ECOLE}) AS nom_ecole,
       (SELECT devise_principale::text FROM ecoles WHERE id = ${CURRENT_ECOLE}) AS devise,
       (SELECT count(*) FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true) AS annees_actives,
       (SELECT count(*) FROM periodes WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_periodes,
       (SELECT count(*) FROM creneaux WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_creneaux,
       (SELECT count(*) FROM cours WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_cours,
       (SELECT count(*) FROM classes WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_classes,
       (SELECT count(*) FROM classes WHERE ecole_id = ${CURRENT_ECOLE} AND niveau IS NULL) AS classes_sans_niveau,
       (SELECT count(*) FROM classe_cours WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_classe_cours,
       (SELECT count(*) FROM utilisateurs WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_utilisateurs,
       (SELECT count(*) FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif') AS nb_eleves,
       (SELECT count(*) FROM modeles_bulletins WHERE ecole_id = ${CURRENT_ECOLE} AND actif = true) AS nb_modeles,
       -- Gabarits OFFICIELS : ecole_id IS NULL. Ils appartiennent à la
       -- plateforme, pas à l'école, et suffisent à imprimer un bulletin
       -- conforme. Sans ce compteur, l'étape « modèles » ne pouvait être
       -- satisfaite que par une création — ce qu'aucune école n'a à faire.
       (SELECT count(*) FROM modeles_bulletins WHERE ecole_id IS NULL AND actif = true) AS nb_modeles_officiels,
       (SELECT count(*) FROM regles_discipline WHERE ecole_id = ${CURRENT_ECOLE} AND actif = true) AS nb_regles_discipline,
       (SELECT count(*) FROM frais_scolaires WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_frais,
       (SELECT count(*) FROM emploi_du_temps WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_seances,
       (SELECT count(*) FROM cours WHERE ecole_id = ${CURRENT_ECOLE} AND maximum_examen IS NULL) AS cours_sans_max_examen,
       (SELECT nom FROM utilisateurs WHERE id = $1) AS mon_nom,
       (SELECT prenom FROM utilisateurs WHERE id = $1) AS mon_prenom,
       (SELECT telephone FROM utilisateurs WHERE id = $1) AS mon_telephone,
       (SELECT onboarding FROM utilisateurs WHERE id = $1) AS ma_progression`;

const CHAMPS_EXTENSION = `
       (SELECT commune FROM ecoles WHERE id = ${CURRENT_ECOLE}) AS commune,
       (SELECT count(*) FROM periodes WHERE ecole_id = ${CURRENT_ECOLE}
          AND (date_debut IS NULL OR date_fin IS NULL)) AS periodes_sans_dates,
       -- Les sections sont comptées à travers les classes, et non directement.
       -- C'est le seul chemin dont l'existence est prouvée par le reste du
       -- dépôt : partout ailleurs, « sections » n'apparaît que jointe depuis
       -- « classes.section_id ».
       (SELECT count(*) FROM options WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_options,
       (SELECT count(*) FROM classes WHERE ecole_id = ${CURRENT_ECOLE} AND section_id IS NOT NULL) AS classes_avec_section,
       (SELECT count(*) FROM classes WHERE ecole_id = ${CURRENT_ECOLE} AND titulaire_id IS NOT NULL) AS classes_avec_titulaire,
       (SELECT count(DISTINCT ur.utilisateur_id)
          FROM utilisateur_roles ur
          JOIN utilisateurs u ON u.id = ur.utilisateur_id
         WHERE u.ecole_id = ${CURRENT_ECOLE}
           AND ur.role::text IN ('professeur', 'titulaire')) AS nb_enseignants,
       -- « enseignant_cours » est atteinte par jointure sur « classe_cours », qui
       -- porte l'ecole_id de façon certaine.
       (SELECT count(*) FROM enseignant_cours ec
          JOIN classe_cours cc ON cc.id = ec.classe_cours_id
         WHERE cc.ecole_id = ${CURRENT_ECOLE}) AS nb_attributions,
       (SELECT count(*) FROM eleves WHERE ecole_id = ${CURRENT_ECOLE}
          AND statut = 'actif' AND classe_id IS NULL) AS eleves_sans_classe,
       -- Signaux d'usage : ne valident aucune étape, servent à savoir si
       -- l'école tourne déjà. Bornés par LIMIT 1 — compter un million de notes
       -- pour répondre « oui il y en a » serait absurde.
       (SELECT count(*) FROM (SELECT 1 FROM notes WHERE ecole_id = ${CURRENT_ECOLE} LIMIT 1) x) AS a_des_notes,
       (SELECT count(*) FROM (SELECT 1 FROM presences WHERE ecole_id = ${CURRENT_ECOLE} LIMIT 1) x) AS a_des_presences,
       (SELECT count(*) FROM (SELECT 1 FROM bulletins WHERE ecole_id = ${CURRENT_ECOLE} LIMIT 1) x) AS a_des_bulletins,
       (SELECT count(*) FROM (SELECT 1 FROM paiements_frais WHERE ecole_id = ${CURRENT_ECOLE} LIMIT 1) x) AS a_des_paiements`;

/* Les gabarits officiels de la RDC sont livrés AVEC le serveur :
   utils/bulletin-primaire-rdc.template.js, bulletin-secondaire-rdc.template.js
   et bulletin-examen-etat.template.js. `bulletins.controller.js` s'en sert dès
   que la sélection de modèle actif ne renvoie rien. Une école n'a donc jamais
   besoin de créer un modèle pour imprimer.

   Constante et non requête : ces fichiers font partie du dépôt, leur présence
   ne dépend d'aucune migration. La passer à `false` reviendrait à dire que le
   produit ne sait plus imprimer de bulletin — ce qui se verrait ailleurs. */
const MODELES_OFFICIELS_INTEGRES = true;

// Journalisé une seule fois : si une colonne manque, l'avertissement se
// répéterait à chaque chargement de page de chaque utilisateur.
let extensionSignalee = false;

async function collecterFaits(client, userId) {
  let c, degrade = false;
  try {
    const r = await client.query(
      `SELECT ${CHAMPS_SOCLE}, ${CHAMPS_EXTENSION}`, [userId]
    );
    c = r.rows[0] || {};
  } catch (err) {
    degrade = true;
    if (!extensionSignalee) {
      extensionSignalee = true;
      console.warn(
        '[didacticiel] La collecte étendue a échoué — le guide fonctionne en mode réduit. '
        + 'Cause probable : une colonne attendue par la migration 026 ou par le schéma '
        + "d'origine est absente. Détail : " + err.message
      );
    }
    const r = await client.query(`SELECT ${CHAMPS_SOCLE}`, [userId]);
    c = r.rows[0] || {};
  }

  const n = (v) => Number(v || 0);
  const rempli = (v) => typeof v === 'string' && v.trim().length > 0;
  // En mode réduit, un signal inconnu est réputé VRAI plutôt que faux. Une
  // étape qu'on ne sait pas vérifier ne doit pas rester éternellement « à
  // faire » : mieux vaut ne pas la proposer que de la proposer à tort à
  // quelqu'un qui l'a déjà terminée.
  const opt = (valeur, siDegrade) => (degrade ? siDegrade : valeur);

  const faits = {
    /* --- étapes --- */
    profil_complet: rempli(c.mon_nom) && rempli(c.mon_prenom) && rempli(c.mon_telephone),
    identite_ecole: rempli(c.type_enseignement) && rempli(c.nom_ecole) && rempli(c.devise),
    annee_active: n(c.annees_actives) > 0,
    periodes: n(c.nb_periodes) > 0,
    creneaux: n(c.nb_creneaux) > 0,
    sections_options: opt(n(c.nb_options) > 0 || n(c.classes_avec_section) > 0, true),
    cours: n(c.nb_cours) > 0,
    classes: n(c.nb_classes) > 0,
    classe_cours: n(c.nb_classe_cours) > 0,
    // En mode réduit on retombe sur l'ancien signal (`nb_utilisateurs > 1`),
    // imprécis mais éprouvé.
    enseignants: opt(n(c.nb_enseignants) > 0, n(c.nb_utilisateurs) > 1),
    attribution_cours: opt(n(c.nb_attributions) > 0, n(c.nb_classe_cours) > 0),
    titulaires: opt(n(c.classes_avec_titulaire) > 0, true),
    eleves: n(c.nb_eleves) > 0,
    /* MODÈLES DE BULLETINS — ce que « fait » veut dire ici.
       L'étape est satisfaite dès qu'un modèle UTILISABLE existe. Trois
       sources, par ordre de spécificité :
         · un modèle propre à l'école, activé ;
         · un gabarit officiel RDC seedé en base ;
         · les gabarits officiels INTÉGRÉS AU CODE, qui servent de repli à
           `bulletins.controller.js` quand aucun modèle actif n'est trouvé.
       La troisième est toujours vraie, et c'est exact : Ardoise imprime un
       bulletin conforme dès le premier jour. La détection reste néanmoins
       branchée sur la base pour les deux premières, afin que le didacticiel
       décrive l'établissement et non une constante. */
    modeles_bulletins: n(c.nb_modeles) > 0 || n(c.nb_modeles_officiels) > 0
      || MODELES_OFFICIELS_INTEGRES,
    // La création d'un modèle PERSONNALISÉ, elle, se constate vraiment.
    modele_personnalise: n(c.nb_modeles) > 0,
    discipline_bareme: n(c.nb_regles_discipline) > 0,
    frais: n(c.nb_frais) > 0,
    emploi_du_temps: n(c.nb_seances) > 0,

    /* --- alertes : un travail COMMENCÉ mais laissé incomplet ---
       C'est la catégorie la plus utile du didacticiel d'origine, et elle est
       conservée telle quelle. Un réglage à moitié fait ne se voit nulle part
       et casse quelque chose trois écrans plus loin. */
    alerte_cours: n(c.nb_cours) > 0 && n(c.cours_sans_max_examen) > 0
      ? `${n(c.cours_sans_max_examen)} cours sans maximum d'examen : ils compteront pour zéro sur les périodes d'examen.`
      : null,
    alerte_classes: n(c.classes_sans_niveau) > 0
      ? `${n(c.classes_sans_niveau)} classe(s) sans niveau : la promotion de fin d'année ne pourra pas s'exécuter.`
      : null,
    alerte_periodes: !degrade && n(c.nb_periodes) > 0 && n(c.periodes_sans_dates) > 0
      ? `${n(c.periodes_sans_dates)} période(s) sans dates : la plateforme ne saura pas laquelle est en cours.`
      : null,
    alerte_eleves: !degrade && n(c.eleves_sans_classe) > 0
      ? `${n(c.eleves_sans_classe)} élève(s) sans classe : ils n'apparaîtront ni dans les listes, ni dans les bulletins.`
      : null,
    alerte_personnel: !degrade && n(c.nb_enseignants) > 0 && n(c.nb_attributions) === 0
      ? "Des enseignants existent mais aucun cours ne leur est attribué : ils ouvriront un écran vide."
      : null,

    /* --- contexte --- */
    _degrade: degrade,
    _cycle: c.type_enseignement || null,
    _nom_ecole: c.nom_ecole || null,
    _mon_nom: c.mon_nom || null,
    _mon_prenom: c.mon_prenom || null,
    _progression_brute: c.ma_progression || {},
    _ecole_active: n(c.a_des_notes) > 0 || n(c.a_des_presences) > 0
      || n(c.a_des_bulletins) > 0 || n(c.a_des_paiements) > 0,
    _compteurs: {
      classes: n(c.nb_classes), eleves: n(c.nb_eleves), cours: n(c.nb_cours),
      enseignants: opt(n(c.nb_enseignants), n(c.nb_utilisateurs)), periodes: n(c.nb_periodes)
    }
  };

  return faits;
}


/**
 * Les droits d'offre de l'école, sous la forme attendue par le moteur.
 *
 * POURQUOI CETTE FONCTION EXISTE PLUTÔT QU'UN APPEL DIRECT
 * -------------------------------------------------------
 * Les trois points d'entrée du didacticiel (`etat-installation`, `onboarding`
 * et `aide-contextuelle`) doivent voir EXACTEMENT la même offre. Un seul
 * chemin de lecture, donc, et une seule politique de repli.
 *
 * LE REPLI EST « NE RIEN RETIRER », ET C'EST DÉLIBÉRÉ
 * --------------------------------------------------
 * Si la lecture du catalogue échoue, on renvoie `null`, et le moteur
 * n'écarte alors AUCUNE étape pour raison d'offre. Le raisonnement est le
 * même que dans `offre.middleware.js` : une panne de facturation ne doit pas
 * amputer le parcours d'une école qui a payé. Le pire cas devient « on
 * propose une étape de trop », que la route refusera proprement en 402 —
 * et non « on ampute une école de ce qu'elle a souscrit ».
 */
async function chargerDroits(client, ecoleId) {
  if (!ecoleId) return null;
  try {
    return await catalogue.droitsDeLEcole(client, ecoleId);
  } catch (err) {
    console.warn('[didacticiel] Offre illisible, aucune étape écartée :', err.message);
    return null;
  }
}

/**
 * GET /assistant/etat-installation
 *
 * CONSERVÉ À L'IDENTIQUE, contrat de réponse compris.
 *
 * Les trente-sept pages chargent `didacticiel.js`, et rien ne garantit que
 * toutes tournent sur la même version au même moment : un navigateur qui a
 * gardé l'ancien fichier en cache continue d'appeler cette route et d'attendre
 * exactement `{ etapes, prochaine_etape, alertes, progression, termine }`.
 * Changer sa forme ferait tomber leur panneau d'aide en marche.
 *
 * Seule la SOURCE des faits a changé : la collecte est désormais partagée avec
 * l'onboarding, ce qui garantit que les deux ne peuvent pas diverger.
 */
async function etatInstallation(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const f = await collecterFaits(client, req.auth.userId);
      const droits = await chargerDroits(client, req.auth.ecoleId);
      const progression = onboarding.lireProgression(f._progression_brute);

      /* LA MÊME SOURCE DE VÉRITÉ, PAS UNE SECONDE.

         Cette route décidait seule de ce qui était fait, facultatif et
         bloquant, à partir d'une table de correspondance écrite à la main et
         d'une fonction `facultative(etape)` qui listait des numéros. Deux
         moteurs pour une seule question : ils ont divergé, et rien ne les
         obligeait à converger. Une école sans emploi du temps dans son offre
         restait bloquée à 93 % ICI alors que le didacticiel la donnait à
         100 %, et personne ne pouvait dire laquelle des deux vues était la
         bonne.

         La route interroge désormais `construireParcours()` comme tout le
         reste, puis TRADUIT sa réponse dans le contrat historique. Le
         parcours du DIRECTEUR sert de référence, parce que c'est lui qui
         porte les quatorze étapes de `ORDRE_CONFIGURATION`. */
      const parcours = onboarding.construireParcours(
        ['directeur'], f, progression,
        { cycle: f._cycle, droits: droits ? droits.fonctionnalites : null });

      // Index des étapes du moteur par numéro d'ORDRE_CONFIGURATION.
      const parNumero = new Map();
      parcours.etapes.forEach((e) => {
        if (e.etape_config && !parNumero.has(e.etape_config)) parNumero.set(e.etape_config, e);
      });
      const ecarteesParNumero = new Set();
      parcours.etapes_ecartees.forEach((e) => {
        const def = onboarding.PAR_CODE[e.code];
        if (def && def.etape_config && !parNumero.has(def.etape_config)) {
          ecarteesParNumero.add(def.etape_config);
        }
      });

      /* LE CONTRAT DE RÉPONSE NE CHANGE PAS.

         Les trente-sept pages chargent `didacticiel.js`, et rien ne garantit
         qu'elles tournent toutes sur la même version : un navigateur qui a
         gardé l'ancien fichier en cache continue d'attendre exactement
         `{ etapes, prochaine_etape, alertes, progression, termine }`. Les
         champs sont donc conservés à l'identique, y compris `facultatif`.

         Une étape ÉCARTÉE (hors offre, hors cycle) est simplement absente de
         la liste, comme elle l'est du didacticiel. C'est le seul changement
         visible, et c'est la correction : une école Ascension ne verra plus
         « Emploi du temps » dans un état d'installation qu'elle ne peut pas
         faire progresser. */
      const etapes = ORDRE_CONFIGURATION
        .filter((e) => !ecarteesParNumero.has(e.etape))
        .map((e) => {
          const suivi = parNumero.get(e.etape) || null;
          return {
            ...e,
            fait: suivi ? suivi.fait === true : false,
            // « Facultatif » au sens historique = n'empêche pas de terminer.
            // C'est exactement `!obligatoire` dans le moteur.
            facultatif: suivi ? suivi.obligatoire !== true : true,
            categorie: suivi ? suivi.categorie : null,
            alerte: suivi ? (suivi.alerte || null) : null
          };
        });

      const bloquantes = etapes.filter((e) => !e.fait && !e.facultatif);

      return {
        etapes,
        prochaine_etape: bloquantes[0] || null,
        alertes: etapes.filter((e) => e.alerte)
          .map((e) => ({ etape: e.etape, titre: e.titre, alerte: e.alerte })),
        progression: etapes.length === 0
          ? 100
          : Math.round((etapes.filter((e) => e.fait).length / etapes.length) * 100),
        termine: bloquantes.length === 0,
        // Deux champs AJOUTÉS, jamais retirés : un client ancien les ignore,
        // un client récent sait dire « comprise dans une offre supérieure »
        // au lieu de laisser croire à un oubli de configuration.
        etapes_ecartees: parcours.etapes_ecartees,
        offre: droits ? { code: droits.offre_code, signature: droits.signature } : null
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur état installation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ===========================================================================
 *  ONBOARDING
 * ========================================================================= */

/**
 * GET /assistant/onboarding?ecran=classes.html
 *
 * Le point d'entrée unique du didacticiel. Un seul appel renvoie tout ce dont
 * l'interface a besoin : à qui elle parle, où en est l'école, quelle est la
 * prochaine action, et s'il y a un mini-tutoriel à montrer sur cet écran.
 *
 * OUVERT À TOUS LES RÔLES, contrairement à `etat-installation`.
 * La restriction d'origine se justifiait : la liste des étapes de
 * configuration révèle la maturité de l'école. Ici, chacun ne reçoit que SON
 * parcours — un professeur voit ses cinq étapes de découverte et rien d'autre.
 * Aucun compteur d'élèves, aucune information sur l'installation ne descend
 * vers un rôle qui n'en a pas la charge : `nettoyerPourRole()` s'en assure.
 */
async function etatOnboarding(req, res) {
  const roles = (req.auth.roles || []).filter(Boolean);
  const ecran = req.query.ecran ? String(req.query.ecran).slice(0, 60) : null;

  // Le Super Admin est explicitement exclu : il n'appartient à aucune école et
  // n'a rien à configurer. Lui proposer un parcours l'enverrait installer un
  // établissement qui n'est pas le sien.
  if (req.auth.isSuperAdmin || roles.includes('super_admin')) {
    return res.json({ actif: false, raison: 'super_admin' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const f = await collecterFaits(client, req.auth.userId);
      const droits = await chargerDroits(client, req.auth.ecoleId);
      const progression = onboarding.lireProgression(f._progression_brute);
      const parcours = onboarding.construireParcours(roles, f, progression, {
        cycle: f._cycle,
        droits: droits ? droits.fonctionnalites : null
      });

      const direction = roles.some((r) => ['directeur', 'prefet'].includes(r));

      // Les alertes ne concernent que ceux qui peuvent y remédier. Dire à un
      // professeur que « 3 classes sont sans niveau » ne l'aide pas : il ne
      // peut rien y faire, et le message le laisse croire à une panne.
      const alertes = direction
        ? parcours.etapes.filter((e) => e.alerte && !e.ignoree)
            .map((e) => ({ code: e.code, titre: e.titre, alerte: e.alerte, ecran: e.ecran }))
        : [];

      return {
        actif: true,
        utilisateur: {
          prenom: f._mon_prenom, nom: f._mon_nom,
          roles, role_dominant: parcours.role_dominant
        },
        ecole: { nom: f._nom_ecole, cycle: f._cycle },
        // L'OFFRE, ET SURTOUT SA SIGNATURE.
        //
        // La signature est une empreinte du code d'offre et des drapeaux
        // actifs. Le didacticiel la compare à celle qu'il a en cache : dès
        // qu'elle change, il vide `sessionStorage` et recharge. C'est ce qui
        // évite qu'une école montée en Prime le matin continue de voir le
        // parcours d'Ascension jusqu'à la fermeture de l'onglet.
        //
        // Elle ne porte AUCUNE donnée d'école : deux écoles en Prime ont la
        // même signature, et elle ne se déchiffre pas.
        offre: droits ? {
          code: droits.offre_code,
          nom: droits.offre_nom,
          signature: droits.signature,
          sans_offre: droits.sans_offre,
          fonctionnalites: droits.fonctionnalites
        } : null,
        progression: {
          statut: progression.statut,
          vu_bienvenue: progression.vu_bienvenue,
          pourcentage: parcours.progression_pct,
          // Deux compteurs, parce qu'ils répondent à deux questions
          // différentes : « où en est mon parcours » (tout compris) et « où en
          // est mon établissement » (configuration seule). Le second n'existe
          // que pour les rôles qui ont des étapes de configuration.
          pourcentage_configuration: parcours.progression_config_pct,
          termine: parcours.termine,
          demarre_at: progression.demarre_at,
          termine_at: progression.termine_at
        },
        // Le mode décide du ton de l'accueil : on ne dit pas la même chose à
        // une école vide et à une école qui tourne depuis trois ans.
        mode: parcours.mode,
        ecole_deja_active: f._ecole_active,
        etapes: parcours.etapes.map((e) => ({
          code: e.code, type: e.type, titre: e.titre, resume: e.resume,
          ecran: e.ecran, ancre: e.ancre, selecteurs: e.selecteurs,
          // Les gestes à faire DANS l'écran. La bulle de guidage ne dispose
          // que de cette liste : `prochaine` porte le détail complet, mais
          // le guidage peut viser n'importe quelle étape, pas seulement la
          // suivante. Sans ce champ, la bulle nommait l'écran et s'arrêtait.
          details: e.details || [],
          obligatoire: e.obligatoire, categorie: e.categorie,
          // `passable` dit à l'interface s'il faut afficher « Passer pour
          // l'instant » et « Nous n'utilisons pas cette fonctionnalité ».
          // Un prérequis ne les affiche pas : une école sans année scolaire
          // active ne fonctionne pas, et lui proposer de s'en passer serait
          // lui mentir.
          passable: e.passable, fonctionnalite: e.fonctionnalite,
          fait: e.fait, ignoree: e.ignoree, non_utilisee: e.non_utilisee,
          bloquee: e.bloquee, bloquee_par: e.bloquee_par
        })),
        // Ce qui a été ÉCARTÉ, et pourquoi. Séparé des étapes : l'interface
        // en fait un encart d'information, jamais une ligne de checklist.
        // Une école ne doit pas lire « à faire » en face de quelque chose
        // qu'elle n'a pas souscrit.
        etapes_ecartees: parcours.etapes_ecartees,
        prochaine: parcours.prochaine ? onboarding.detailEtape(parcours.prochaine.code) : null,
        alertes,
        // Le mini-tutoriel de l'écran courant, s'il y en a un et s'il n'a pas
        // déjà été vu.
        tutoriel: ecran
          ? onboarding.tutorielContextuel(ecran, roles, progression, parcours.termine)
          : null,
        centre: onboarding.centreApprentissage(roles, droits ? droits.fonctionnalites : null),
        // Utile au directeur seulement : de quoi écrire « 12 classes, 340 élèves ».
        compteurs: direction ? f._compteurs : null
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur onboarding:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /assistant/onboarding
 * body : { action, valeur? }
 *
 * CE QU'ON PEUT ÉCRIRE, ET CE QU'ON NE PEUT PAS
 * ---------------------------------------------
 * Aucune action ne permet de déclarer une étape de CONFIGURATION « terminée ».
 * C'était le défaut du didacticiel d'origine qu'il fallait absolument ne pas
 * réintroduire : si l'interface pouvait cocher elle-même « classes créées »,
 * la progression cesserait de décrire l'école et se mettrait à décrire les
 * clics. On peut seulement IGNORER une étape — ce qui est une décision de la
 * personne, pas un fait sur l'établissement.
 *
 * Les actions acceptées :
 *   bienvenue_vue      l'écran d'accueil a été affiché
 *   demarrer           « Commencer » — horodate le début
 *   reporter           « Passer pour l'instant » — la progression est CONSERVÉE
 *   reprendre          retour au parcours après un report
 *   ignorer_etape      { valeur: code }
 *   reprendre_etape    { valeur: code } — annule l'ignorance
 *   ecran_visite       { valeur: 'rapports.html' } — valide une découverte
 *   tutoriel_vu        { valeur: 'notes.html' }
 *   terminer           fin du parcours
 *   reinitialiser      tout remettre à zéro (« Refaire la visite »)
 */
const ACTIONS = new Set([
  'bienvenue_vue', 'demarrer', 'reporter', 'reprendre', 'ignorer_etape',
  'reprendre_etape', 'ecran_visite', 'tutoriel_vu', 'terminer', 'reinitialiser',
  // AJOUTÉES : « Nous n'utilisons pas cette fonctionnalité », et son annulation.
  // Distinctes de `ignorer_etape` parce que les deux phrases n'engagent pas la
  // même chose — l'une remet à plus tard, l'autre renonce — et parce que seule
  // la seconde propage l'écartement aux étapes qui en dépendent.
  'non_utilisee', 'reactiver_etape'
]);

/* Les étapes dont on ne peut NI se passer NI déclarer qu'on ne les utilise pas.
   Sans ce contrôle, un client mal réglé — ou un utilisateur pressé — pouvait
   déclarer « je n'utilise pas les classes » et se retrouver avec un parcours à
   100 % sur une école incapable de produire un bulletin. La règle est portée
   par le catalogue (`categorie: 'prerequis'`), pas recopiée ici. */
function estPrerequis(code) {
  const e = onboarding.PAR_CODE[code];
  if (!e) return false;
  const categorie = e.categorie
    || (e.type === 'decouverte' ? 'decouverte' : (e.obligatoire === false ? 'facultatif' : 'prerequis'));
  return categorie === 'prerequis';
}

async function majOnboarding(req, res) {
  const action = String((req.body && req.body.action) || '');
  const valeur = req.body && req.body.valeur ? String(req.body.valeur).slice(0, 80) : null;

  if (!ACTIONS.has(action)) {
    return res.status(400).json({ message: 'Action inconnue.' });
  }
  if (['ignorer_etape', 'reprendre_etape', 'ecran_visite', 'tutoriel_vu'].includes(action) && !valeur) {
    return res.status(400).json({ message: 'Valeur requise pour cette action.' });
  }
  // Un code d'étape doit exister dans le catalogue. Sans ce contrôle, la
  // colonne se remplirait de codes inventés par un client mal réglé, et la
  // progression deviendrait illisible sans jamais lever d'erreur.
  const surEtape = ['ignorer_etape', 'reprendre_etape', 'non_utilisee', 'reactiver_etape'];
  if (surEtape.includes(action) && !valeur) {
    return res.status(400).json({ message: 'Valeur requise pour cette action.' });
  }
  if (surEtape.includes(action) && !onboarding.PAR_CODE[valeur]) {
    return res.status(400).json({ message: 'Étape inconnue.' });
  }
  // Un prérequis ne se passe pas. Le refus est explicite plutôt que silencieux :
  // une interface qui propose le bouton par erreur doit s'en apercevoir.
  if (['ignorer_etape', 'non_utilisee'].includes(action) && estPrerequis(valeur)) {
    return res.status(400).json({
      code: 'etape_indispensable',
      message: "Cette étape est indispensable au fonctionnement de l'école : elle ne peut pas être passée."
    });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const lu = await client.query(
        'SELECT onboarding FROM utilisateurs WHERE id = $1', [req.auth.userId]
      );
      if (lu.rows.length === 0) {
        throw Object.assign(new Error('Compte introuvable.'), { statusCode: 404 });
      }

      const p = onboarding.lireProgression(lu.rows[0].onboarding);
      const maintenant = new Date().toISOString();
      const ajouter = (liste, v) => (liste.includes(v) ? liste : liste.concat([v]));

      switch (action) {
        case 'bienvenue_vue':
          p.vu_bienvenue = true;
          break;
        case 'demarrer':
          p.vu_bienvenue = true;
          p.statut = 'en_cours';
          if (!p.demarre_at) p.demarre_at = maintenant;
          break;
        case 'reporter':
          // « Passer pour l'instant » ne supprime RIEN. C'est tout l'intérêt :
          // la personne retrouve son parcours intact en revenant.
          p.vu_bienvenue = true;
          p.statut = 'reporte';
          if (!p.demarre_at) p.demarre_at = maintenant;
          break;
        case 'reprendre':
          p.statut = 'en_cours';
          break;
        case 'ignorer_etape':
          // « Passer pour l'instant ». Ne propage rien, ne supprime rien.
          p.etapes_ignorees = ajouter(p.etapes_ignorees, valeur);
          break;
        case 'reprendre_etape':
          p.etapes_ignorees = p.etapes_ignorees.filter((c) => c !== valeur);
          break;
        case 'non_utilisee':
          // « Nous n'utilisons pas cette fonctionnalité ». L'étape sort du
          // parcours, et les étapes qui en dépendent DUREMENT en sortent
          // aussi — c'est le moteur qui le fait, pas cette écriture.
          p.etapes_non_utilisees = ajouter(p.etapes_non_utilisees, valeur);
          p.etapes_ignorees = p.etapes_ignorees.filter((c) => c !== valeur);
          break;
        case 'reactiver_etape':
          // Réactivation : l'étape revient, ses enfants aussi. Aucune donnée
          // n'a été détruite entre-temps — seule une liste de codes change.
          p.etapes_non_utilisees = p.etapes_non_utilisees.filter((c) => c !== valeur);
          p.etapes_ignorees = p.etapes_ignorees.filter((c) => c !== valeur);
          break;
        case 'ecran_visite':
          p.ecrans_visites = ajouter(p.ecrans_visites, valeur);
          break;
        case 'tutoriel_vu':
          p.tutoriels_vus = ajouter(p.tutoriels_vus, valeur);
          break;
        case 'terminer':
          p.statut = 'termine';
          p.termine_at = maintenant;
          break;
        case 'reinitialiser':
          // Remise à zéro complète : la personne redemande la visite. On ne
          // garde pas `demarre_at`, sinon la date de début d'un parcours
          // refait resterait celle du premier, ce qui n'a pas de sens.
          p.vu_bienvenue = false;
          p.statut = 'en_cours';
          p.etapes_ignorees = [];
          p.etapes_non_utilisees = [];
          p.tutoriels_vus = [];
          p.ecrans_visites = [];
          p.demarre_at = null;
          p.termine_at = null;
          break;
      }

      p.maj_at = maintenant;

      await client.query(
        'UPDATE utilisateurs SET onboarding = $1::jsonb, updated_at = now() WHERE id = $2',
        [JSON.stringify(p), req.auth.userId]
      );
      return p;
    });

    return res.json({ progression: resultat });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur mise à jour onboarding:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ===========================================================================
 *  L'IA, EN COPILOTE
 * ========================================================================= */

/**
 * Consigne de l'assistant d'onboarding.
 *
 * POURQUOI UNE CONSIGNE DISTINCTE DE `consigne()`
 * -----------------------------------------------
 * L'assistant général répond à « comment fait-on X ? » sans rien savoir de
 * l'école — c'est ce qui permet de l'ouvrir à tous les rôles sans risque de
 * fuite entre eux. Ici, la personne est DÉJÀ dans son parcours, sur une étape
 * précise, et la question porte sur cette étape. Répondre « je n'ai pas accès
 * aux données » à quelqu'un qu'on vient d'inviter à créer ses classes serait
 * absurde.
 *
 * On lui transmet donc l'état d'installation — et RIEN d'autre. Des comptes,
 * pas des contenus : « 12 classes », jamais leurs noms ; « 340 élèves »,
 * jamais un patronyme. La règle de confidentialité entre rôles tient toujours,
 * parce qu'aucune donnée nominative ne franchit cette frontière.
 */
function consigneOnboarding({ roles, etape, faits, parcours, nomEcole, prenom }) {
  const roleLisible = roles.map((r) => LIBELLES_ROLE[r] || r).join(', ') || 'Utilisateur';
  const perimetre = roles.map((r) => PERIMETRE_ROLE[r]).filter(Boolean).join(' ');

  const faites = parcours.etapes.filter((e) => e.fait).map((e) => e.titre);
  const restantes = parcours.etapes.filter((e) => !e.fait && !e.ignoree).map((e) => e.titre);

  const detail = etape ? onboarding.detailEtape(etape.code) : null;

  return `Tu es l'assistant de PRISE EN MAIN d'Ardoise, une plateforme de gestion scolaire utilisée en République Démocratique du Congo.

Tu n'es pas une IA généraliste. Tu accompagnes une personne précise, à un moment précis de son installation. Tu réponds à sa question sur l'étape en cours, et à rien d'autre.

QUI TU ACCOMPAGNES
Prénom : ${prenom || 'non renseigné'}.
Rôle : ${roleLisible}.
Ce qu'elle peut faire : ${perimetre}
Établissement : ${nomEcole || 'non renseigné'}.
Type d'enseignement : ${faits._cycle || 'non renseigné'}.

OÙ ELLE EN EST
Avancement : ${parcours.progression_pct} % du parcours.
Étapes déjà terminées : ${faites.length ? faites.join(', ') : 'aucune'}.
Étapes restantes : ${restantes.length ? restantes.join(', ') : 'aucune'}.

${detail ? `ÉTAPE EN COURS
Titre : ${detail.titre}
Écran : ${detail.ecran_officiel || detail.ancre}
Ce qu'il faut faire : ${detail.quoi || detail.resume}
Pourquoi : ${detail.pourquoi || ''}
Piège à éviter : ${detail.piege || ''}` : 'Aucune étape en cours : le parcours est terminé.'}

CE QUE TU CONNAIS DE L'ÉCOLE
Des COMPTES, et uniquement des comptes : ${faits._compteurs.classes} classe(s), ${faits._compteurs.eleves} élève(s), ${faits._compteurs.cours} cours, ${faits._compteurs.enseignants} enseignant(s), ${faits._compteurs.periodes} période(s).
Tu ne connais AUCUN nom d'élève, AUCUNE note, AUCUN montant. Si on t'en demande, dis-le et indique l'écran où la personne trouvera elle-même la réponse.

RÈGLES DE RÉPONSE
- Français simple, 2 à 5 phrases, ou étapes numérotées pour une manipulation.
- Nomme les écrans et les boutons tels qu'ils apparaissent dans la plateforme.
- Parle de l'étape en cours en priorité. Ne déroule pas tout le parcours.
- Si la manœuvre dépasse le périmètre du rôle, dis-le et indique qui peut la faire, sans reproche.
- N'invente jamais un écran, un bouton ou un réglage. Dans le doute, renvoie au manuel ou à la direction.
- Pas de salutation ni de formule d'ouverture : va droit à la réponse.
- Termine par une phrase courte qui ramène à l'action concrète à faire maintenant.`;
}

/**
 * POST /assistant/aide-contextuelle
 * body : { etape?, question?, ecran? }
 *
 * Le bouton « Besoin d'aide ? Demander à Ardoise IA » du didacticiel.
 *
 * SANS QUOTA, L'ÉCRAN N'EST PAS VIDE
 * ----------------------------------
 * Toutes les écoles n'ont pas l'offre incluant l'IA, et le quota s'épuise. Le
 * repli n'est pas un message d'erreur : c'est l'explication écrite de l'étape,
 * tirée de la base de connaissance. La personne reçoit une réponse dans tous
 * les cas — moins conversationnelle, mais complète.
 */
async function aideContextuelle(req, res) {
  const codeEtape = req.body && req.body.etape ? String(req.body.etape).slice(0, 60) : null;
  const question = req.body && req.body.question ? String(req.body.question).trim().slice(0, 400) : null;

  if (codeEtape && !onboarding.PAR_CODE[codeEtape]) {
    return res.status(400).json({ message: 'Étape inconnue.' });
  }
  if (limiteAtteinte(req.auth.userId)) {
    return res.status(429).json({
      message: "Vous avez posé beaucoup de questions d'affilée. Reprenez dans quelques minutes.",
      repli: codeEtape ? onboarding.detailEtape(codeEtape) : null
    });
  }

  const roles = (req.auth.roles || []).filter(Boolean);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const f = await collecterFaits(client, req.auth.userId);
      const droits = await chargerDroits(client, req.auth.ecoleId);
      const progression = onboarding.lireProgression(f._progression_brute);
      const parcours = onboarding.construireParcours(roles, f, progression, {
        cycle: f._cycle,
        droits: droits ? droits.fonctionnalites : null
      });

      /* UNE ÉTAPE ÉCARTÉE NE S'EXPLIQUE PAS.

         L'aide contextuelle acceptait n'importe quel code du catalogue, y
         compris celui d'une étape que l'offre de l'école ne comprend pas.
         L'IA détaillait alors consciencieusement comment ouvrir un écran qui
         répond 402 — le plus sûr moyen de faire passer une limite commerciale
         pour une panne. On répond ici ce qui est vrai : la fonctionnalité
         n'est pas comprise dans l'offre, et voici laquelle l'ouvre. */
      const ecartee = codeEtape
        ? parcours.etapes_ecartees.find((e) => e.code === codeEtape)
        : null;
      if (ecartee) {
        return {
          source: 'offre',
          etape: codeEtape,
          code: 'etape_hors_offre',
          fonctionnalite: ecartee.fonctionnalite,
          message: ecartee.message,
          repli: null
        };
      }

      const etape = codeEtape
        ? parcours.etapes.find((e) => e.code === codeEtape) || { code: codeEtape }
        : parcours.prochaine;

      // Le repli est préparé AVANT l'appel à l'IA, pas dans le `catch` : ainsi
      // il est identique que l'IA soit absente, en panne ou hors quota, et il
      // n'y a qu'un seul chemin à vérifier.
      const repli = etape ? onboarding.detailEtape(etape.code) : null;

      const demande = question || (etape
        ? `Explique-moi l'étape « ${onboarding.PAR_CODE[etape.code] ? onboarding.PAR_CODE[etape.code].titre : etape.code} » : pourquoi elle est nécessaire, comment la faire, et ce qu'il faut renseigner.`
        : "Que puis-je faire maintenant sur Ardoise ?");

      try {
        await consommerQuota(client, req.auth.ecoleId, 1);
        const reponse = await appelerIA({
          systeme: consigneOnboarding({
            roles,
            etape,
            faits: f,
            parcours,
            nomEcole: f._nom_ecole,
            prenom: f._mon_prenom
          }),
          message: demande,
          maxTokens: 600
        });
        return {
          source: 'ia',
          etape: etape ? etape.code : null,
          question: demande,
          reponse: String(reponse).trim(),
          repli
        };
      } catch (err) {
        // Quota épuisé, offre sans IA, ou service indisponible : le parcours
        // ne s'arrête pas pour autant.
        const horsQuota = err.statusCode === 429 || /quota/i.test(err.message || '');
        return {
          source: 'manuel',
          etape: etape ? etape.code : null,
          message: horsQuota
            ? "L'assistant IA n'est pas disponible pour votre école. Voici l'explication écrite de cette étape."
            : "L'assistant IA n'a pas pu répondre. Voici l'explication écrite de cette étape.",
          repli
        };
      }
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur aide contextuelle:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  question, manuel, etatInstallation,
  etatOnboarding, majOnboarding, aideContextuelle
};
