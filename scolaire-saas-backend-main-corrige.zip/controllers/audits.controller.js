/**
 * ARDOISE — EXÉCUTIONS D'AUDIT STATIQUE
 * ===========================================================================
 *
 * LE CHAÎNON QUI MANQUAIT
 * -----------------------
 * Les scripts d'audit (`audit-frontend.py`, `audit-sql.py`, `audit-mobile.py`…)
 * sont des outils de terminal. Ils impriment leurs résultats et s'arrêtent là.
 * Rien ne les reliait au Super Admin : leurs constats vivaient dans le
 * défilement d'un terminal, puis nulle part.
 *
 * Ce contrôleur ajoute le seul mécanisme qui manquait — un point d'entrée
 * d'ingestion — et rien de plus. Les audits restent des outils indépendants,
 * exécutables hors ligne, et publier est facultatif.
 *
 * L'AUTHENTIFICATION EST UN SECRET TECHNIQUE, PAS UN JETON SUPER ADMIN
 * -------------------------------------------------------------------
 * La CI n'a pas de compte humain, et coder un jeton Super Admin dans un script
 * ou dans un workflow GitHub reviendrait à donner à ce script tous les droits
 * de l'espace d'administration — lecture des écoles comprise — pour lui
 * permettre d'écrire deux tables techniques.
 *
 * `AUDIT_INGEST_SECRET` ne donne accès qu'à ces deux tables et à rien d'autre.
 * Il ne peut ni lire une école, ni modifier une note, ni toucher aux données
 * métier. Compromis, il permet de déposer de faux résultats d'audit — un
 * désagrément, pas une fuite.
 *
 * LE REFUS D'UN RAPPORT VIDE
 * --------------------------
 * Un audit qui annonce « 0 fichier analysé, aucun problème » est REJETÉ, et
 * enregistré comme échec technique. C'est le cœur du dispositif : sans cette
 * règle, un outil mal installé se présente comme une plateforme saine, et
 * c'est très exactement ce qui se produisait avec `generateur/audit.py` et
 * `audit-sql.py`.
 */

const crypto = require('crypto');
const { runWithTenant } = require('../config/db');

const SUPER = { isSuperAdmin: true };

const TYPES_CONNUS = [
  'frontend', 'responsive', 'mobile', 'sql', 'contrat_api', 'generateur',
  'imports', 'tests', 'global'
];

const GRAVITES = ['info', 'faible', 'moyenne', 'importante', 'critique'];

/* =========================================================================
   AUTHENTIFICATION DE L'INGESTION
   ========================================================================= */

/**
 * Vérifie le secret d'ingestion, en temps constant.
 *
 * `timingSafeEqual` plutôt que `===` : une comparaison de chaînes s'arrête au
 * premier caractère différent, et la durée de la réponse laisse alors deviner
 * le secret octet par octet. L'attaque est lente mais réelle sur un point
 * d'entrée public, et la parade coûte trois lignes.
 */
function secretValide(fourni) {
  const attendu = process.env.AUDIT_INGEST_SECRET || '';
  // Un secret non configuré FERME le point d'entrée. Le laisser ouvert « en
  // attendant la configuration » offrirait à n'importe qui le droit d'écrire
  // dans le centre de supervision.
  if (!attendu || attendu.length < 16) return false;
  if (typeof fourni !== 'string' || !fourni) return false;

  const a = Buffer.from(fourni);
  const b = Buffer.from(attendu);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function refusIngestion(res) {
  // Message volontairement identique pour un secret absent, faux ou mal formé :
  // distinguer les cas renseignerait un appelant illégitime.
  return res.status(401).json({ code: 'ingestion_refusee', message: 'Secret d\'ingestion invalide.' });
}

/* =========================================================================
   EMPREINTE D'ANOMALIE
   ========================================================================= */

/**
 * Empreinte SANS le numéro de ligne.
 *
 * Ajouter trois lignes en tête d'un fichier décale tout ce qui suit. Si la
 * ligne entrait dans l'empreinte, chaque commit rouvrirait l'intégralité des
 * anomalies du dépôt comme si elles étaient neuves, et le compteur
 * d'occurrences comme la réouverture automatique perdraient tout sens.
 *
 * La ligne reste STOCKÉE — c'est ce que le Super Admin doit lire pour aller
 * voir — mais elle ne participe pas à l'identité de l'anomalie.
 */
function empreinteAnomalie({ type_audit, fichier, code, message }) {
  const normalise = String(message || '')
    .replace(/\d+/g, ':n')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
    .slice(0, 200);
  return crypto.createHash('sha256')
    .update(`${type_audit}|${fichier}|${code}|${normalise}`)
    .digest('hex')
    .slice(0, 40);
}

/* =========================================================================
   INGESTION
   ========================================================================= */

/**
 * POST /audits/executions
 * En-tête : X-Audit-Secret
 *
 * body : {
 *   type_audit, depot?, commit_sha?, branche?, statut,
 *   nb_fichiers, nb_anomalies?, message?, declenche_par?,
 *   demarre_at?, termine_at?,
 *   resultats: [ { fichier, ligne?, gravite, code, message } ]
 * }
 */
async function publierExecution(req, res) {
  if (!secretValide(req.headers['x-audit-secret'])) return refusIngestion(res);

  const b = req.body || {};

  const typeAudit = String(b.type_audit || '').trim().slice(0, 40);
  if (!typeAudit) {
    return res.status(400).json({ message: 'type_audit est requis.' });
  }
  if (!TYPES_CONNUS.includes(typeAudit)) {
    // Averti, mais accepté : ajouter un audit ne doit pas exiger un
    // déploiement du backend, sans quoi personne n'en ajoutera.
    console.warn(`[audits] Type inconnu « ${typeAudit} » — accepté, à déclarer dans TYPES_CONNUS.`);
  }

  const nbFichiers = Number.isFinite(Number(b.nb_fichiers)) ? Math.max(0, Number(b.nb_fichiers)) : 0;
  const resultats = Array.isArray(b.resultats) ? b.resultats : [];

  /* -----------------------------------------------------------------------
     LA RÈGLE CENTRALE : ZÉRO FICHIER N'EST PAS UN SUCCÈS

     Un audit qui n'a rien examiné n'a pas prouvé que tout va bien : il n'a
     rien prouvé du tout. Le requalifier ici — et non faire confiance au
     script — garantit que la règle tient même pour un outil futur écrit par
     quelqu'un qui n'aurait pas lu cette consigne.
     ----------------------------------------------------------------------- */
  let statut = ['reussi', 'anomalies', 'echec_technique'].includes(b.statut)
    ? b.statut : 'reussi';
  let message = b.message ? String(b.message).slice(0, 1000) : null;

  if (nbFichiers === 0 && statut !== 'echec_technique') {
    statut = 'echec_technique';
    message = (message ? message + ' — ' : '')
      + "Aucun fichier examiné : l'audit n'a pas réellement tourné (outil absent, "
      + 'chemin invalide ou dossier de sortie vide). Requalifié en échec technique.';
  }
  // Cohérence inverse : des anomalies remontées avec un statut « réussi ».
  if (statut === 'reussi' && resultats.length > 0) statut = 'anomalies';
  if (statut === 'anomalies' && resultats.length === 0 && Number(b.nb_anomalies) === 0) {
    statut = 'reussi';
  }

  const nbAnomalies = resultats.length || Math.max(0, Number(b.nb_anomalies) || 0);

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const run = await client.query(`
        INSERT INTO audit_runs
          (type_audit, depot, commit_sha, branche, demarre_at, termine_at,
           statut, nb_fichiers, nb_anomalies, message, declenche_par, metadata)
        VALUES ($1,$2,$3,$4,COALESCE($5::timestamptz, now()),COALESCE($6::timestamptz, now()),
                $7,$8,$9,$10,$11,$12::jsonb)
        RETURNING id, statut, nb_fichiers, nb_anomalies`,
        [
          typeAudit,
          b.depot ? String(b.depot).slice(0, 120) : null,
          b.commit_sha ? String(b.commit_sha).slice(0, 60) : null,
          b.branche ? String(b.branche).slice(0, 120) : null,
          b.demarre_at || null,
          b.termine_at || null,
          statut,
          nbFichiers,
          nbAnomalies,
          message,
          b.declenche_par === 'manuel' ? 'manuel' : 'ci',
          JSON.stringify({ outil: b.outil || null, duree_ms: b.duree_ms || null })
        ]);

      const runId = run.rows[0].id;

      /* Les anomalies, une par une, avec regroupement par empreinte.
         Bornées à 500 : au-delà, ce n'est plus un rapport d'audit mais un
         changement de configuration de l'outil, et l'insérer intégralement
         ferait de l'ingestion une opération longue et bloquante. */
      const retenues = resultats.slice(0, 500);
      for (const r of retenues) {
        const fichier = String(r.fichier || 'inconnu').slice(0, 400);
        const code = String(r.code || 'anomalie').slice(0, 80);
        const msg = String(r.message || '').slice(0, 1000);
        const gravite = GRAVITES.includes(r.gravite) ? r.gravite : 'moyenne';
        const ligne = Number.isFinite(Number(r.ligne)) ? Math.max(0, Number(r.ligne)) : null;

        await client.query(`
          INSERT INTO audit_findings
            (run_id, type_audit, fichier, ligne, gravite, code, message, empreinte, metadata)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb)
          ON CONFLICT (empreinte) DO UPDATE SET
            run_id       = EXCLUDED.run_id,
            ligne        = EXCLUDED.ligne,
            gravite      = EXCLUDED.gravite,
            message      = EXCLUDED.message,
            occurrences  = audit_findings.occurrences + 1,
            derniere_vue = now(),
            -- Réouverture : une anomalie corrigée qui réapparaît redevient
            -- ouverte. Le motif d'ignorance est effacé — il portait sur un
            -- état qui n'est plus le bon.
            statut       = CASE WHEN audit_findings.statut IN ('corrigee','ignoree')
                                THEN 'ouverte' ELSE audit_findings.statut END,
            motif_ignore = CASE WHEN audit_findings.statut IN ('corrigee','ignoree')
                                THEN NULL ELSE audit_findings.motif_ignore END`,
          [runId, typeAudit, fichier, ligne, gravite, code, msg,
           empreinteAnomalie({ type_audit: typeAudit, fichier, code, message: msg }),
           JSON.stringify(r.contexte || {})]);
      }

      /* Ce qui N'A PAS reparu dans cette exécution est réputé CORRIGÉ.
         Sans cette clôture, la liste ne ferait que grossir et le Super Admin
         verrait indéfiniment des anomalies déjà réglées — jusqu'à cesser de
         la consulter. On ne clôt que si l'audit a réellement tourné. */
      if (statut !== 'echec_technique') {
        await client.query(`
          UPDATE audit_findings
             SET statut = 'corrigee', traite_at = now()
           WHERE type_audit = $1
             AND statut = 'ouverte'
             AND run_id <> $2`, [typeAudit, runId]);
      }

      return run.rows[0];
    });

    return res.status(201).json({
      id: donnees.id,
      statut: donnees.statut,
      nb_fichiers: donnees.nb_fichiers,
      nb_anomalies: donnees.nb_anomalies,
      // L'appelant doit savoir qu'il a été requalifié, sinon la CI croirait
      // avoir publié un succès.
      requalifie: donnees.statut !== (b.statut || 'reussi')
    });
  } catch (err) {
    console.error('[audits] Ingestion impossible :', err.message);
    return res.status(500).json({ message: "Enregistrement de l'exécution impossible." });
  }
}

/* =========================================================================
   CONSULTATION — SUPER ADMIN
   ========================================================================= */

/** GET /super-admin/audits */
async function listerExecutions(req, res) {
  const limite = Math.min(Number(req.query.limite) || 30, 100);
  const type = req.query.type ? String(req.query.type).slice(0, 40) : null;

  try {
    const lignes = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(`
        SELECT id, type_audit, depot, commit_sha, branche, demarre_at, termine_at,
               statut, nb_fichiers, nb_anomalies, message, declenche_par
          FROM audit_runs
         WHERE ($1::text IS NULL OR type_audit = $1)
         ORDER BY demarre_at DESC
         LIMIT $2`, [type, limite]);
      return r.rows;
    });
    return res.json({ executions: lignes });
  } catch (err) {
    console.error('[audits] Lecture impossible :', err.message);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/audits/anomalies */
async function listerAnomalies(req, res) {
  const limite = Math.min(Number(req.query.limite) || 100, 500);
  const statut = req.query.statut ? String(req.query.statut).slice(0, 20) : 'ouverte';
  const type = req.query.type ? String(req.query.type).slice(0, 40) : null;

  try {
    const lignes = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(`
        SELECT f.id, f.type_audit, f.fichier, f.ligne, f.gravite, f.code, f.message,
               f.statut, f.occurrences, f.premiere_vue, f.derniere_vue, f.motif_ignore,
               r.commit_sha, r.depot
          FROM audit_findings f
          LEFT JOIN audit_runs r ON r.id = f.run_id
         WHERE ($1::text IS NULL OR f.statut = $1)
           AND ($2::text IS NULL OR f.type_audit = $2)
         ORDER BY CASE f.gravite
                    WHEN 'critique'   THEN 0 WHEN 'importante' THEN 1
                    WHEN 'moyenne'    THEN 2 WHEN 'faible'     THEN 3 ELSE 4 END,
                  f.derniere_vue DESC
         LIMIT $3`, [statut === 'toutes' ? null : statut, type, limite]);
      return r.rows;
    });
    return res.json({ anomalies: lignes });
  } catch (err) {
    console.error('[audits] Lecture impossible :', err.message);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /super-admin/audits/anomalies/:id
 * body : { statut, motif_ignore? }
 *
 * Ignorer une anomalie EXIGE un motif. C'est la traduction en code de la règle
 * « ne pas masquer une anomalie en l'ajoutant arbitrairement à une liste
 * d'exceptions » : la liste existe, mais chaque entrée porte sa justification,
 * et le rapport la reprend.
 */
async function modifierAnomalie(req, res) {
  const statut = req.body && req.body.statut;
  if (!['ouverte', 'corrigee', 'ignoree'].includes(statut)) {
    return res.status(400).json({ message: 'Statut invalide.' });
  }
  const motif = req.body && req.body.motif_ignore
    ? String(req.body.motif_ignore).trim().slice(0, 500) : null;

  if (statut === 'ignoree' && (!motif || motif.length < 15)) {
    return res.status(400).json({
      code: 'motif_requis',
      message: "Ignorer une anomalie exige un motif explicite d'au moins quinze caractères. "
             + 'Une exception non justifiée redevient une anomalie oubliée.'
    });
  }

  try {
    const ligne = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(`
        UPDATE audit_findings
           SET statut = $1, motif_ignore = $2, traite_par = $3, traite_at = now()
         WHERE id = $4::uuid
         RETURNING id, statut, motif_ignore`,
        [statut, statut === 'ignoree' ? motif : null,
         (req.auth && req.auth.userId) || null, req.params.id]);
      return r.rows[0] || null;
    });
    if (!ligne) return res.status(404).json({ message: 'Anomalie introuvable.' });
    return res.json(ligne);
  } catch (err) {
    console.error('[audits] Mise à jour impossible :', err.message);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  publierExecution,
  listerExecutions,
  listerAnomalies,
  modifierAnomalie,
  empreinteAnomalie,
  secretValide
};
