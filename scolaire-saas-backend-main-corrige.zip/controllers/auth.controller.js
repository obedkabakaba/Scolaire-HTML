const { runWithTenant } = require('../config/db');
const { comparePassword, hashPassword } = require('../utils/password.utils');
const crypto = require('crypto');
const { envoyerEmail } = require('../utils/email.utils');
const { emailWrapper, echapper } = require('../utils/email-template');
const {
  generateAccessToken,
  generateRefreshTokenRaw,
  hashRefreshToken
} = require('../utils/jwt.utils');

const REFRESH_EXPIRES_DAYS = parseInt(process.env.JWT_REFRESH_EXPIRES_DAYS || '30', 10);

/**
 * POST /auth/login
 * body: { email, password, code_ecole? }
 * Si code_ecole est absent, on tente une connexion Super Admin (ecole_id NULL).
 *
 * NOTE IMPORTANTE : toutes les requêtes ici passent par runWithTenant({isSuperAdmin:true}),
 * pas par un accès direct au pool. C'est indispensable : avant que l'utilisateur soit
 * authentifié, on ne connaît pas encore son ecole_id, donc on doit explicitement passer
 * en mode "super admin" pour que les policies RLS laissent passer la lecture — sans ça,
 * ces requêtes ne renverraient plus aucune ligne depuis qu'on utilise un rôle de base de
 * données qui respecte réellement RLS (au lieu du rôle "postgres" qui le contournait).
 */
async function login(req, res) {
  const { email, password, code_ecole } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email et mot de passe requis.' });
  }

  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      let ecoleId = null;

      if (code_ecole) {
        const ecoleResult = await client.query(
          'SELECT id, statut FROM ecoles WHERE code = $1',
          [code_ecole]
        );
        if (ecoleResult.rows.length === 0) {
          throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });
        }
        if (ecoleResult.rows[0].statut !== 'actif') {
          throw Object.assign(new Error("L'accès de cette école est actuellement restreint."), { statusCode: 403 });
        }
        ecoleId = ecoleResult.rows[0].id;
      }

      const userResult = await client.query(
        `SELECT u.id, u.mot_de_passe_hash, u.statut, u.ecole_id,
                COALESCE(u.doit_changer_mot_de_passe, false) AS doit_changer_mot_de_passe,
                array_agg(ur.role::text) AS roles
         FROM utilisateurs u
         LEFT JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE u.email = $1 AND u.ecole_id IS NOT DISTINCT FROM $2
         GROUP BY u.id`,
        [email, ecoleId]
      );

      if (userResult.rows.length === 0) {
        throw Object.assign(new Error('Identifiants invalides.'), { statusCode: 401 });
      }

      const user = userResult.rows[0];

      if (user.statut !== 'actif') {
        throw Object.assign(new Error('Compte désactivé.'), { statusCode: 403 });
      }

      const motDePasseValide = await comparePassword(password, user.mot_de_passe_hash);
      if (!motDePasseValide) {
        throw Object.assign(new Error('Identifiants invalides.'), { statusCode: 401 });
      }

      const userForToken = { id: user.id, ecole_id: user.ecole_id, roles: user.roles.filter(Boolean) };
      const doitChanger = user.doit_changer_mot_de_passe === true;
      const accessToken = generateAccessToken(userForToken);

      const refreshTokenRaw = generateRefreshTokenRaw();
      const refreshTokenHash = hashRefreshToken(refreshTokenRaw);
      const expireAt = new Date(Date.now() + REFRESH_EXPIRES_DAYS * 24 * 60 * 60 * 1000);

      await client.query(
        `INSERT INTO sessions (utilisateur_id, refresh_token_hash, user_agent, ip, expire_at)
         VALUES ($1, $2, $3, $4, $5)`,
        [user.id, refreshTokenHash, req.headers['user-agent'] || null, req.ip, expireAt]
      );

      return {
        access_token: accessToken,
        refresh_token: refreshTokenRaw,
        // Le jeton est délivré malgré l'obligation : sans lui, l'utilisateur
        // ne pourrait pas appeler l'API pour changer son mot de passe. C'est
        // le middleware qui bloque tout le reste.
        doit_changer_mot_de_passe: doitChanger,
        user: {
          id: user.id, ecole_id: user.ecole_id, roles: userForToken.roles,
          doit_changer_mot_de_passe: doitChanger
        }
      };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) {
      return res.status(err.statusCode).json({ message: err.message });
    }
    console.error('Erreur login:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /auth/refresh
 * body: { refresh_token }
 */
async function refresh(req, res) {
  const { refresh_token } = req.body;
  if (!refresh_token) {
    return res.status(400).json({ message: 'refresh_token requis.' });
  }

  try {
    const accessToken = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const hash = hashRefreshToken(refresh_token);
      const sessionResult = await client.query(
        `SELECT s.id, s.expire_at, u.id AS user_id, u.ecole_id, u.statut,
                array_agg(ur.role::text) AS roles
         FROM sessions s
         JOIN utilisateurs u ON u.id = s.utilisateur_id
         LEFT JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE s.refresh_token_hash = $1
         GROUP BY s.id, u.id`,
        [hash]
      );

      if (sessionResult.rows.length === 0) {
        throw Object.assign(new Error('Session invalide.'), { statusCode: 401 });
      }

      const session = sessionResult.rows[0];

      if (new Date(session.expire_at) < new Date() || session.statut !== 'actif') {
        throw Object.assign(new Error('Session expirée ou compte désactivé.'), { statusCode: 401 });
      }

      return generateAccessToken({
        id: session.user_id,
        ecole_id: session.ecole_id,
        roles: session.roles.filter(Boolean)
      });
    });

    return res.json({ access_token: accessToken });
  } catch (err) {
    if (err.statusCode) {
      return res.status(err.statusCode).json({ message: err.message });
    }
    console.error('Erreur refresh:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /auth/logout
 * body: { refresh_token }
 */
async function logout(req, res) {
  const { refresh_token } = req.body;
  if (!refresh_token) {
    return res.status(400).json({ message: 'refresh_token requis.' });
  }

  try {
    const hash = hashRefreshToken(refresh_token);
    await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query('DELETE FROM sessions WHERE refresh_token_hash = $1', [hash])
    );
    return res.json({ message: 'Déconnecté.' });
  } catch (err) {
    console.error('Erreur logout:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /auth/forgot-password
 * body: { email, code_ecole? }
 * Répond toujours avec un message générique de succès (même si l'email n'existe pas),
 * pour ne pas révéler quels comptes existent.
 */
async function forgotPassword(req, res) {
  const { email, code_ecole } = req.body;
  const messageGenerique = { message: 'Si un compte correspond à ces informations, un email de réinitialisation a été envoyé.' };

  if (!email) {
    return res.status(400).json({ message: 'Email requis.' });
  }

  try {
    await runWithTenant({ isSuperAdmin: true }, async (client) => {
      let ecoleId = null;
      if (code_ecole) {
        const ecoleResult = await client.query('SELECT id FROM ecoles WHERE code = $1', [code_ecole]);
        if (ecoleResult.rows.length === 0) return;
        ecoleId = ecoleResult.rows[0].id;
      }

      const userResult = await client.query(
        `SELECT id, nom FROM utilisateurs WHERE email = $1 AND ecole_id IS NOT DISTINCT FROM $2 AND statut = 'actif'`,
        [email, ecoleId]
      );

      if (userResult.rows.length === 0) return;
      const utilisateur = userResult.rows[0];

      const tokenBrut = crypto.randomBytes(32).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(tokenBrut).digest('hex');
      const expireAt = new Date(Date.now() + 60 * 60 * 1000); // 1 heure

      await client.query(
        `INSERT INTO reinitialisations_mot_de_passe (utilisateur_id, token_hash, expire_at) VALUES ($1, $2, $3)`,
        [utilisateur.id, tokenHash, expireAt]
      );

      const urlFrontend = process.env.FRONTEND_URL || '';
      const lienReinitialisation = `${urlFrontend}/reinitialiser-mot-de-passe.html?token=${tokenBrut}`;

      await envoyerEmail({
        to: email,
        subject: 'Réinitialisation de ton mot de passe — Ardoise',
        html: emailWrapper({
          type: 'reset_mdp',
          titre: 'Réinitialisation de votre mot de passe',
          preheader: 'Lien valable 1 heure pour choisir un nouveau mot de passe.',
          contenuHtml: `<p>Bonjour ${echapper(utilisateur.nom)},</p>
            <p>Vous avez demandé la réinitialisation de votre mot de passe.
            Cliquez sur le bouton ci-dessous pour en choisir un nouveau.</p>
            <p style="font-size:13px;color:#5B6560;">Ce lien expire dans 60 minutes.
            Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>`,
          boutonPrincipal: { libelle: 'Réinitialiser mon mot de passe', url: lienReinitialisation }
        })
      });
    });

    return res.json(messageGenerique);
  } catch (err) {
    console.error('Erreur forgot-password:', err);
    return res.json(messageGenerique);
  }
}

/**
 * POST /auth/reset-password
 * body: { token, password }
 */
async function resetPassword(req, res) {
  const { token, password } = req.body;
  if (!token || !password) {
    return res.status(400).json({ message: 'token et password sont requis.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: 'Le mot de passe doit contenir au moins 6 caractères.' });
  }

  try {
    await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

      const reinitResult = await client.query(
        `SELECT id, utilisateur_id, expire_at, utilise FROM reinitialisations_mot_de_passe WHERE token_hash = $1`,
        [tokenHash]
      );

      if (reinitResult.rows.length === 0) {
        throw Object.assign(new Error('Lien invalide ou expiré.'), { statusCode: 400 });
      }
      const reinit = reinitResult.rows[0];

      if (reinit.utilise || new Date(reinit.expire_at) < new Date()) {
        throw Object.assign(new Error('Ce lien a déjà été utilisé ou a expiré. Refais une demande.'), { statusCode: 400 });
      }

      const motDePasseHash = await hashPassword(password);

      await client.query('UPDATE utilisateurs SET mot_de_passe_hash = $1 WHERE id = $2', [motDePasseHash, reinit.utilisateur_id]);
      await client.query('UPDATE reinitialisations_mot_de_passe SET utilise = true WHERE id = $1', [reinit.id]);
      await client.query('DELETE FROM sessions WHERE utilisateur_id = $1', [reinit.utilisateur_id]);
    });

    return res.json({ message: 'Mot de passe mis à jour. Tu peux te connecter avec ton nouveau mot de passe.' });
  } catch (err) {
    if (err.statusCode) {
      return res.status(err.statusCode).json({ message: err.message });
    }
    console.error('Erreur reset-password:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { login, refresh, logout, forgotPassword, resetPassword };
