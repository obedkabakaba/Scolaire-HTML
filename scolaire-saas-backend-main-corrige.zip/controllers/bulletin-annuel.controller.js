const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { construireHtmlBulletinAnnuel } = require('../utils/bulletin-annuel-template');
const { construireHtmlBulletinSecondaire } = require('../utils/bulletin-secondaire-rdc.template');
const { construireHtmlBulletinPrimaire } = require('../utils/bulletin-primaire-rdc.template');
const { assemblerDonneesSecondaire, assemblerDonneesPrimaire } = require('../utils/bulletin-assemblage-officiel');
const { resoudreSignatures } = require('../utils/signatures.utils');
const { recalculerBulletinSemestre } = require('./bulletin-semestre.controller');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Un titulaire (sans rôle de direction/secrétariat) ne peut viser que SA classe.
 */
async function verifierAccesClasse(client, req, classeId) {
  const estPersonnelEcole = req.auth.isSuperAdmin
    || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
  if (estPersonnelEcole) return;
  const result = await client.query(`SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]);
  if (result.rows.length === 0) {
    throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
  }
}

/**
 * Agrège automatiquement les bulletins de SEMESTRE déjà calculés (et les
 * recalcule d'abord pour être sûr qu'ils sont à jour) pour produire le
 * récapitulatif annuel de chaque élève de la classe. L'année scolaire est
 * donc bien la moyenne des 2 semestres — pas une moyenne brute de toutes
 * les périodes/examens, qui donnerait un résultat différent si un semestre
 * a plus ou moins de composantes que l'autre.
 *
 * Le résultat est enregistré (upsert) en tant que ligne "bulletin annuel"
 * (periode_id NULL, annee_scolaire_id renseigné).
 */
async function recalculerBulletinAnnuel(client, classeId, anneeScolaireId) {
  // 1. Rafraîchir les regroupements de l'année avant de produire l'annuel.
  //
  // Le filtre portait sur `type = 'semestre'` seul. Une école PRIMAIRE tourne
  // sur trois TRIMESTRES : la requête ne ramenait rien, aucun regroupement
  // n'était recalculé, et le bulletin annuel du primaire sortait entièrement
  // vide. Le commentaire d'origine mentionnait pourtant « trois trimestres au
  // primaire » — l'intention était là, le filtre ne l'a jamais suivie.
  const regroupementsResult = await client.query(
    `SELECT id FROM periodes
      WHERE annee_scolaire_id = $1 AND type::text IN ('semestre', 'trimestre')`,
    [anneeScolaireId]
  );
  for (const regroupement of regroupementsResult.rows) {
    await recalculerBulletinSemestre(client, classeId, regroupement.id);
  }

  // 2. TOTAL DE L'ANNÉE = somme des semestres.
  //
  // C'est la règle du bulletin officiel (§9.1) : T.G. = tot1 + tot2, sur
  // 2 × le maximum d'un semestre. Et puisqu'un semestre est lui-même la somme
  // de ses périodes et de son examen, l'année entière revient à additionner
  // les points et les maxima de TOUTES les périodes de travail — ce que fait
  // `pourcentagesParEleve`. On n'a donc pas besoin de passer par les lignes de
  // regroupement : elles restent calculées ci-dessus parce que le bulletin les
  // IMPRIME, mais elles ne servent plus d'intermédiaire de calcul.
  //
  // L'ancienne version moyennait les pourcentages des deux semestres. Quand
  // les deux ont exactement le même maximum — le cas normal — la moyenne et la
  // somme donnent le même nombre, et le résultat était juste par accident.
  // Elle divergeait dès que ce n'était plus vrai : cours ajouté au second
  // semestre, examen configuré d'un côté seulement, ou école en trimestres.
  // Elle divergeait aussi pour un élève n'ayant composé qu'un semestre.
  const periodesTravail = await client.query(
    `SELECT id FROM periodes
      WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
        AND type::text IN ('periode', 'examen')`,
    [anneeScolaireId]
  );

  const lignes = periodesTravail.rows.length === 0 ? [] : (
    await pourcentagesParEleve(
      client, anneeScolaireId,
      { type: 'annuel', periodeIds: periodesTravail.rows.map((p) => p.id) },
      { inclureNonNotes: false }
    )
  )
    .filter((l) => l.classe_id === classeId)
    .sort((a, b) => (b.pourcentage - a.pourcentage)
      || String(a.nom_complet).localeCompare(String(b.nom_complet), 'fr'));

  const mentionsResult = await client.query(
    `SELECT seuil_min, seuil_max, libelle FROM mentions WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY seuil_min`
  );
  const mentions = mentionsResult.rows;
  // Conversion en Number obligatoire : node-pg renvoie les NUMERIC en chaînes,
  // et une comparaison de chaînes attribue de fausses mentions ("9.50" >= "10" est vrai en texte).
  function trouverMention(pourcentage) {
    if (pourcentage === null || pourcentage === undefined) return null;
    const p = Number(pourcentage);
    if (Number.isNaN(p)) return null;
    const m = mentions.find((m) => p >= Number(m.seuil_min) && p <= Number(m.seuil_max));
    return m ? m.libelle : null;
  }

  // Un élève sans AUCUNE cote de l'année n'apparaît pas dans `lignes` : il
  // n'est donc ni calculé ni classé (§9.3, pas de rang factice).
  let rang = 0;
  for (const ligne of lignes) {
    const moyenneArrondie = Math.round(ligne.pourcentage * 100) / 100;
    const classement = ++rang;
    const mention = trouverMention(moyenneArrondie);

    await client.query(
      `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, annee_scolaire_id, total, pourcentage, classement, mention)
       VALUES (${CURRENT_ECOLE}, $1, NULL, $2, $3, $4, $5, $6)
       ON CONFLICT (eleve_id, annee_scolaire_id) WHERE periode_id IS NULL
       DO UPDATE SET total = EXCLUDED.total, pourcentage = EXCLUDED.pourcentage,
                     classement = EXCLUDED.classement, mention = EXCLUDED.mention`,
      [ligne.eleve_id, anneeScolaireId, ligne.total_obtenu, moyenneArrondie, classement, mention]
    );
  }

  return lignes.map((l, i) => ({
    eleve_id: l.eleve_id, nom: l.nom, postnom: l.postnom, prenom: l.prenom,
    total: l.total_obtenu, maximum: l.total_maxima,
    moyenne_annuelle: Math.round(l.pourcentage * 100) / 100,
    classement_annuel: i + 1,
    mention_annuelle: trouverMention(l.moyenne_annuelle !== null ? Math.round(l.moyenne_annuelle * 100) / 100 : null)
  }));
}

/**
 * GET /bulletins/annuel/recapitulatif?classeId=&anneeScolaireId=
 */
async function recapitulatif(req, res) {
  const { classeId, anneeScolaireId } = req.query;
  if (!classeId || !anneeScolaireId) {
    return res.status(400).json({ message: 'classeId et anneeScolaireId sont requis.' });
  }

  try {
    const recap = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);
      return recalculerBulletinAnnuel(client, classeId, anneeScolaireId);
    });
    return res.json(recap);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur récapitulatif annuel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /bulletins/annuel/classe/:classeId/imprimer?anneeScolaireId=
 * Génère le PDF du bulletin annuel (1 page portrait par élève).
 */
async function genererPdfAnnuelClasse(req, res) {
  const { classeId } = req.params;
  const { anneeScolaireId } = req.query;
  if (!anneeScolaireId) {
    return res.status(400).json({ message: 'anneeScolaireId requis.' });
  }

  let browser;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);
      const ecoleResult = await client.query(`SELECT nom, ville, commune, province, logo_url FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const ecole = ecoleResult.rows[0];

      const classeResult = await client.query(
        `SELECT c.id, c.nom, c.cycle::text AS cycle, c.modele_annuel_id,
                o.nom AS option_nom, s.nom AS section_nom
         FROM classes c
         LEFT JOIN options o ON o.id = c.option_id
         LEFT JOIN sections s ON s.id = c.section_id
         WHERE c.id = $1`,
        [classeId]
      );
      const classe = classeResult.rows[0];
      if (!classe) throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });

      const anneeResult = await client.query(`SELECT libelle FROM annees_scolaires WHERE id = $1`, [anneeScolaireId]);
      const anneeLibelle = anneeResult.rows[0]?.libelle;

      // Recalcule (garantit des données à jour) puis récupère le détail par élève,
      // y compris le détail période par période pour le tableau récapitulatif.
      await recalculerBulletinAnnuel(client, classeId, anneeScolaireId);

      const elevesResult = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule,
                bAnnuel.pourcentage AS moyenne_annuelle, bAnnuel.classement AS classement_annuel,
                bAnnuel.mention AS mention_annuelle
         FROM eleves e
         LEFT JOIN bulletins bAnnuel ON bAnnuel.eleve_id = e.id
           AND bAnnuel.annee_scolaire_id = $2 AND bAnnuel.periode_id IS NULL
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         ORDER BY COALESCE(bAnnuel.classement, 999999), e.nom, e.postnom`,
        [classeId, anneeScolaireId]
      );
      const eleves = elevesResult.rows;

      for (const eleve of eleves) {
        const periodesResult = await client.query(
          `SELECT p.libelle, p.type, p.numero, b.total, b.pourcentage, b.classement, b.mention
           FROM periodes p
           LEFT JOIN bulletins b ON b.periode_id = p.id AND b.eleve_id = $2
           WHERE p.annee_scolaire_id = $1
             AND p.type::text IN ('semestre', 'trimestre')
           ORDER BY p.numero`,
          [anneeScolaireId, eleve.id]
        );
        eleve.periodes = periodesResult.rows.map((p) => ({
          libelle: p.libelle || `${p.type} ${p.numero}`,
          total: p.total, pourcentage: p.pourcentage, classement: p.classement, mention: p.mention
        }));
      }

      // ---------- Choix du gabarit ----------
      // Le bulletin ANNUEL est le document qui porte la grille complète de
      // l'année : deux semestres (ou trois trimestres au primaire), examens,
      // total général et décision de passage. C'est donc ici — et NON sur le
      // bulletin de période — que s'appliquent les gabarits officiels RDC.
      //
      // Priorité : modèle assigné à la classe, puis modèle officiel du cycle.
      // La variante 'terminale' n'est jamais choisie automatiquement : rien
      // dans le schéma ne permet de deviner qu'une classe de secondaire est une
      // terminale, c'est au Directeur de l'assigner explicitement.
      let modeleOfficiel = null;
      if (classe.modele_annuel_id) {
        const assigne = await client.query(
          `SELECT * FROM modeles_bulletins WHERE id = $1 AND variante IS NOT NULL`,
          [classe.modele_annuel_id]
        );
        modeleOfficiel = assigne.rows[0] || null;
      }
      if (!modeleOfficiel) {
        const parCycle = await client.query(
          `SELECT * FROM modeles_bulletins
            WHERE type = 'annuel' AND actif = true AND variante IS NOT NULL
              AND variante <> 'terminale'
              AND (ecole_id = ${CURRENT_ECOLE} OR ecole_id IS NULL)
              AND (cycle IS NULL OR cycle::text = $1)
            ORDER BY ecole_id NULLS LAST
            LIMIT 1`,
          [classe.cycle]
        );
        modeleOfficiel = parCycle.rows[0] || null;
      }

      const variante = modeleOfficiel?.variante || null;
      let donneesOfficielles = null;

      if (variante === 'primaire') {
        donneesOfficielles = await assemblerDonneesPrimaire(client, { classeId, anneeScolaireId });
        // Un cours sans domaine n'a pas de place dans la grille du primaire :
        // le laisser passer produirait un bulletin amputé de cette branche,
        // sans que ni le directeur ni le parent ne s'en aperçoivent.
        if (donneesOfficielles.sansDomaine.length > 0) {
          const noms = donneesOfficielles.sansDomaine.map((c) => c.nom).join(', ');
          throw Object.assign(
            new Error(`Impossible de générer le bulletin annuel du primaire : ${donneesOfficielles.sansDomaine.length} cours sans domaine (${noms}). Renseignez leur domaine dans la fiche du cours.`),
            { statusCode: 409 }
          );
        }
      } else if (variante === 'secondaire' || variante === 'terminale') {
        donneesOfficielles = await assemblerDonneesSecondaire(client, { classeId, anneeScolaireId });
      }

      // Le gabarit officiel ne porte qu'une signature, et elle est explicitement
      // celle du chef d'établissement (« LE CHEF D'ÉTABLISSEMENT / NOM & SIGNAT. »).
      // Y envoyer la dernière signature déposée par n'importe qui — un titulaire,
      // le plus souvent — y faisait signer l'école par quelqu'un qui ne l'engage
      // pas. Le récapitulatif générique, lui, a bien deux cases distinctes.
      const signatures = await resoudreSignatures(client, { classeId });

      return {
        ecole, classe, anneeLibelle, eleves, variante, donneesOfficielles,
        signatureTitulaireUrl: signatures.signatureTitulaireUrl,
        titulaireNom: signatures.titulaireNom,
        signatureChefUrl: signatures.signatureChefUrl,
        chefNom: signatures.chefNom,
        signatureUrl: signatures.signatureChefUrl,
        cachetUrl: signatures.cachetUrl
      };
    });

    // Gabarit officiel si l'école en a un pour ce cycle ; sinon le récapitulatif
    // générique historique, qui reste valable pour une école sans modèle défini.
    const utiliseGabaritOfficiel = !!donnees.variante && !!donnees.donneesOfficielles;
    let html;
    if (utiliseGabaritOfficiel) {
      const commun = {
        ecole: donnees.ecole,
        anneeLibelle: donnees.anneeLibelle,
        classe: donnees.classe,
        signatureUrl: donnees.signatureUrl,
        cachetUrl: donnees.cachetUrl,
      };
      html = donnees.variante === 'primaire'
        ? construireHtmlBulletinPrimaire({
            ...commun,
            eleves: donnees.donneesOfficielles.eleves,
            domaines: donnees.donneesOfficielles.domaines,
          })
        : construireHtmlBulletinSecondaire({
            ...commun,
            eleves: donnees.donneesOfficielles.eleves,
            cours: donnees.donneesOfficielles.cours,
            variante: donnees.variante,
          });
    } else {
      html = construireHtmlBulletinAnnuel(donnees);
    }

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true });
    await browser.close();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="bulletin-annuel-${classeId}.pdf"`);
    return res.send(pdfBuffer);
  } catch (err) {
    if (browser) await browser.close();
    console.error('Erreur génération PDF bulletin annuel:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

module.exports = { recapitulatif, genererPdfAnnuelClasse };
