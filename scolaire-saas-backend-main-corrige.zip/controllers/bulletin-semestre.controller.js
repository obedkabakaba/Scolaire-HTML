const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { construireHtmlBulletinSemestre } = require('../utils/bulletin-semestre-template');
// La fonction s'appelle `assemblerDonneesSemestre`. Ce fichier importait
// `assemblerDonneesRegroupement`, un nom qui n'existe nulle part : l'import
// valait `undefined` et l'impression du bulletin de SEMESTRE échouait sur
// « assemblerDonneesRegroupement is not a function ».
const { assemblerDonneesSemestre } = require('../utils/bulletin-assemblage-officiel');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');
const { resoudreSignatures } = require('../utils/signatures.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Un titulaire (sans rôle de direction/secrétariat) ne peut viser que SA classe.
 */
async function verifierAccesClasse(client, req, classeId) {
  const estPersonnelEcole = req.auth.isSuperAdmin
    || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
  if (estPersonnelEcole) return;
  const result = await client.query(`SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]);
  if (result.rows.length === 0) {
    throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
  }
}

/**
 * Un "semestre" est lui-même une ligne de la table periodes (type = 'semestre'),
 * qui ne reçoit jamais de notes directement — c'est un simple regroupement.
 * On agrège les bulletins de ses périodes/examens enfants (colonne semestre_id),
 * puis on enregistre le résultat comme un bulletin "normal" dont periode_id =
 * l'id du semestre lui-même (même mécanique que pour une période classique).
 */
async function recalculerBulletinSemestre(client, classeId, semestreId) {
  // Descente jusqu'aux périodes de travail, et non aux seuls enfants directs.
  //
  // La moyenne doit porter sur ce qui a réellement des notes : les périodes et
  // les examens. Un regroupement — semestre du secondaire, trimestre du
  // primaire — n'en a jamais. Prendre les enfants directs sans filtrer leur
  // type ferait entrer dans la moyenne des lignes de `bulletins` qui n'existent
  // pas, et la moyenne sortirait nulle.
  //
  // La descente est récursive par prudence : elle coûte une jointure et rend la
  // fonction indifférente au nombre de niveaux, alors qu'une profondeur écrite
  // en dur redeviendrait fausse au premier découpage qu'une école inventerait.
  const enfantsResult = await client.query(
    `WITH RECURSIVE descendance AS (
       SELECT id, type FROM periodes WHERE semestre_id = $1
       UNION ALL
       SELECT p.id, p.type FROM periodes p
         JOIN descendance d ON p.semestre_id = d.id
     )
     SELECT id FROM descendance WHERE type NOT IN ('semestre', 'trimestre')`,
    [semestreId]
  );
  const enfantsIds = enfantsResult.rows.map((r) => r.id);

  // ---------- Pourcentage du semestre ----------
  //
  // RÈGLE : total obtenu sur total des maxima, exactement comme le bulletin
  // officiel l'imprime — tot1 = P1 + P2 + Examen1, sur 2 × maxPériode +
  // maxExamen (§9.1).
  //
  // Cette fonction faisait la MOYENNE DES POURCENTAGES de ses trois composantes.
  // Or elles n'ont pas le même barème : l'examen vaut le double d'une période.
  // Moyenner revient à décider qu'ils pèsent pareil.
  //
  //   P1 8/10 · P2 8/10 · Examen 10/20
  //     somme officielle : 26/40 = 65,0 %
  //     moyenne des %    : (80 + 80 + 50) / 3 = 70,0 %
  //
  // Cinq points d'écart, sur le même bulletin : la grille imprimée par
  // `assemblerDonneesSemestre` affichait déjà 65 % pendant que cette ligne en
  // stockait 70. C'est la valeur stockée qui décidait de la mention.
  const anneeResult = await client.query(
    `SELECT annee_scolaire_id FROM periodes WHERE id = $1`, [semestreId]
  );
  const anneeSemestre = anneeResult.rows[0]?.annee_scolaire_id || null;

  const lignes = enfantsIds.length === 0 || !anneeSemestre ? [] : (
    await pourcentagesParEleve(
      client, anneeSemestre, { type: 'semestre', periodeIds: enfantsIds },
      { inclureNonNotes: false }
    )
  )
    .filter((l) => l.classe_id === classeId)
    // Classement : pourcentage décroissant, égalité départagée par ordre
    // alphabétique — `nom_complet` vaut « nom postnom prénom », donc le même
    // ordre que le tri SQL qu'il remplace.
    .sort((a, b) => (b.pourcentage - a.pourcentage)
      || String(a.nom_complet).localeCompare(String(b.nom_complet), 'fr'));

  const mentionsResult = await client.query(
    `SELECT seuil_min, seuil_max, libelle FROM mentions WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY seuil_min`
  );
  const mentions = mentionsResult.rows;
  // Conversion en Number obligatoire : node-pg renvoie les NUMERIC en chaînes,
  // et une comparaison de chaînes attribue de fausses mentions ("9.50" >= "10" est vrai en texte).
  function trouverMention(pourcentage) {
    if (pourcentage === null || pourcentage === undefined) return null;
    const p = Number(pourcentage);
    if (Number.isNaN(p)) return null;
    const m = mentions.find((m) => p >= Number(m.seuil_min) && p <= Number(m.seuil_max));
    return m ? m.libelle : null;
  }

    // Un élève SANS moyenne n'est PAS classé (règle §9.3 du handover : pas de
    // rang factice). `ORDER BY … NULLS LAST` le renvoie en fin de liste, mais
    // `i + 1` lui attribuait quand même un rang : le dernier arrivé de l'école,
    // celui dont aucune cote n'est encore saisie, se voyait imprimer « 42e/42 »
    // sur son bulletin. On compte donc les rangs séparément de la boucle.
  let rang = 0;
  for (const ligne of lignes) {
    const moyenneArrondie = Math.round(ligne.pourcentage * 100) / 100;
    const classement = ++rang;
    const mention = trouverMention(moyenneArrondie);

    // `total` est désormais renseigné : c'est le total de points du semestre,
    // celui que la grille imprime. La ligne stockée disait le classement et la
    // mention sans jamais dire d'où ils venaient.
    await client.query(
      `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, total, pourcentage, classement, mention)
       VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6)
       ON CONFLICT (eleve_id, periode_id)
       DO UPDATE SET total = EXCLUDED.total, pourcentage = EXCLUDED.pourcentage,
                     classement = EXCLUDED.classement, mention = EXCLUDED.mention`,
      [ligne.eleve_id, semestreId, ligne.total_obtenu, moyenneArrondie, classement, mention]
    );
  }

  return { lignes, enfantsIds, trouverMention };
}

/**
 * GET /bulletins/semestre/recapitulatif?classeId=&semestreId=
 */
async function recapitulatif(req, res) {
  const { classeId, semestreId } = req.query;
  if (!classeId || !semestreId) {
    return res.status(400).json({ message: 'classeId et semestreId sont requis.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);
      return recalculerBulletinSemestre(client, classeId, semestreId);
    });
    // `lignes` vient désormais de pourcentagesParEleve : elle porte
    // `nom_complet` et `pourcentage`, et ne contient QUE les élèves cotés —
    // ceux sans aucune note n'y figurent pas, donc ne reçoivent pas de rang.
    const recap = resultat.lignes.map((l, i) => {
      const moyenne = Math.round(l.pourcentage * 100) / 100;
      return {
        eleve_id: l.eleve_id,
        // nom / postnom / prenom sont conservés : bulletin-annuel.html les
        // affiche séparément. Les remplacer par `nom_complet` seul aurait
        // écrit « undefined undefined » dans chaque ligne du tableau.
        nom: l.nom, postnom: l.postnom, prenom: l.prenom,
        nom_complet: l.nom_complet,
        matricule: l.matricule,
        total: l.total_obtenu,
        maximum: l.total_maxima,
        moyenne_semestre: moyenne,
        classement_semestre: i + 1,
        mention_semestre: resultat.trouverMention(moyenne)
      };
    });
    return res.json(recap);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur récapitulatif semestre:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /bulletins/semestre/classe/:classeId/imprimer?semestreId=
 */
async function genererPdfSemestreClasse(req, res) {
  const { classeId } = req.params;
  const { semestreId } = req.query;
  if (!semestreId) return res.status(400).json({ message: 'semestreId requis.' });

  let browser;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);
      const ecoleResult = await client.query(`SELECT nom, logo_url FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const ecole = ecoleResult.rows[0];

      const classeResult = await client.query(
        `SELECT c.nom, o.nom AS option_nom
         FROM classes c LEFT JOIN options o ON o.id = c.option_id
         WHERE c.id = $1`,
        [classeId]
      );
      const classe = classeResult.rows[0];
      if (!classe) throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });

      // « Regroupement » et non « semestre » : la même route sert le semestre du
      // secondaire, le trimestre du primaire, et le semestre du primaire qui
      // englobe ses trimestres. Le libellé imprimé est celui que l'école a
      // donné à la période — on ne le reconstruit pas à partir du type.
      const regroupementResult = await client.query(
        `SELECT libelle, type FROM periodes WHERE id = $1`, [semestreId]
      );
      const regroupement = regroupementResult.rows[0];
      if (!regroupement) throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
      if (!['semestre', 'trimestre'].includes(regroupement.type)) {
        throw Object.assign(
          new Error(`« ${regroupement.libelle} » est une période de travail : ses bulletins s'impriment par la route des bulletins de période.`),
          { statusCode: 400 }
        );
      }
      const semestreLibelle = regroupement.libelle;

      // Le classement, la mention et les appréciations restent produits par
      // recalculerBulletinSemestre (qui les écrit dans `bulletins`) ; la GRILLE
      // par cours, elle, est assemblée à part. Les deux sont complémentaires :
      // l'un porte la synthèse stockée, l'autre le détail cours par cours que
      // le bulletin doit imprimer.
      await recalculerBulletinSemestre(client, classeId, semestreId);

      const grille = await assemblerDonneesSemestre(client, { classeId, semestreId });

      // Mention et appréciations viennent du bulletin de semestre déjà calculé.
      const synthese = await client.query(
        `SELECT eleve_id, mention, conduite, application, observation
           FROM bulletins WHERE periode_id = $1`,
        [semestreId]
      );
      const parEleve = new Map(synthese.rows.map((r) => [r.eleve_id, r]));
      for (const eleve of grille.eleves) {
        const s = parEleve.get(eleve.id) || {};
        eleve.mention = s.mention || null;
        eleve.observation = s.observation || null;

        // Conduite et application sont désormais reportées période par période
        // (colonnes 1ʳᵉ P. / 2ᵉ P. de la grille). Certaines écoles les saisissent
        // pourtant directement sur le bulletin de semestre : dans ce cas seul,
        // on les fait apparaître en 1ʳᵉ période plutôt que de les perdre.
        if (!eleve.conduites.p1 && !eleve.conduites.p2 && s.conduite) eleve.conduites.p1 = s.conduite;
        if (!eleve.applications.p1 && !eleve.applications.p2 && s.application) eleve.applications.p1 = s.application;
      }

      const anneeResult = await client.query(
        `SELECT a.libelle FROM periodes p
           JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
          WHERE p.id = $1`,
        [semestreId]
      );

      // Deux signatures distinctes, et non une seule reprise sous les deux
      // libellés : le titulaire atteste des cotes qu'il a saisies, le chef
      // d'établissement engage l'école. Le bulletin prenait auparavant la
      // signature la plus récente de l'école — souvent celle du directeur — et
      // l'imprimait sous la mention « Signature du titulaire ».
      // Seuil de réussite de l'école : il décide des cotes grisées sur le
      // bulletin. On lit le même paramètre que la promotion et les rapports,
      // pour qu'une branche en échec ici le soit aussi partout ailleurs.
      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuilReussite = Number(seuilResult.rows[0]?.seuil ?? 50);

      const signatures = await resoudreSignatures(client, { classeId });

      return {
        ecole, classe, semestreLibelle,
        anneeLibelle: anneeResult.rows[0]?.libelle || null,
        cours: grille.cours, eleves: grille.eleves, maxima: grille.maxima,
        // La grille est décrite par les données, pas par le gabarit : ce sont
        // les enfants du regroupement qui font les colonnes.
        colonnes: grille.colonnes, groupes: grille.groupes,
        // Domaines du primaire : null pour une classe de secondaire, dont les
        // cours n'en portent pas — le gabarit imprime alors sa liste plate.
        domaines: grille.domaines,
        seuilReussite,
        signatureTitulaireUrl: signatures.signatureTitulaireUrl,
        titulaireNom: signatures.titulaireNom,
        signatureChefUrl: signatures.signatureChefUrl,
        chefNom: signatures.chefNom,
        chefEstDirecteur: signatures.chefEstDirecteur,
        cachetUrl: signatures.cachetUrl
      };
    });

    const html = construireHtmlBulletinSemestre(donnees);

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true });
    await browser.close();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="bulletin-semestre-${classeId}.pdf"`);
    return res.send(pdfBuffer);
  } catch (err) {
    if (browser) await browser.close();
    console.error('Erreur génération PDF bulletin semestre:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

module.exports = { recapitulatif, genererPdfSemestreClasse, recalculerBulletinSemestre };
