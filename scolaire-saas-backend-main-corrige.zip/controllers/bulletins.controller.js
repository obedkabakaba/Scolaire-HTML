const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');
const { runWithTenant } = require('../config/db');
const { resoudreSignatures } = require('../utils/signatures.utils');
const { grouperParDomaine } = require('../utils/bulletin-assemblage-officiel');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { construireHtmlBulletins } = require('../utils/bulletin-template');
const { recalculerClassement } = require('./notes.controller');
const { construireHtmlBulletinPersonnalise, slugifier } = require('../utils/bulletin-personnalise-template');
const { situationFinanciere } = require('./controle-financier.controller');
const { verifierPeriodeActive } = require('../utils/annee.utils');
const { notifierEvenement, planifierVidage } = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Prévient les familles que le bulletin est disponible.
 *
 * POURQUOI À LA SIGNATURE, ET PAS À LA SAISIE DES NOTES
 * ----------------------------------------------------
 * Une note saisie peut encore être corrigée, dévalidée, recalculée. Un
 * bulletin signé est définitif. Écrire aux parents plus tôt les ferait venir
 * réclamer sur des chiffres qui vont changer — et l'école perdrait la seule
 * chose qui rend ce message crédible : qu'il soit juste.
 *
 * POURQUOI UNE SEULE REQUÊTE POUR TOUTE LA CLASSE
 * ----------------------------------------------
 * `signerToutLaClasse` traite jusqu'à 300 élèves dans une transaction. Aller
 * chercher l'adresse du responsable élève par élève, ce serait 300 allers-
 * retours supplémentaires pendant que la transaction tient ses verrous. Tout
 * est lu d'un coup, puis inséré.
 *
 * `visibleInterface: false` est indispensable : ces notifications n'ont pas
 * d'`utilisateur_id` (une famille n'a pas de compte), et le contrôleur affiche
 * à la direction toute ligne sans destinataire. Sans ce drapeau, signer une
 * classe déverserait 300 messages dans la boîte du directeur.
 */
async function notifierFamillesBulletinDisponible(client, req, { eleveIds, periodeId }) {
  if (!eleveIds || eleveIds.length === 0) return 0;

  const lignes = await client.query(
    `SELECT el.id,
            trim(concat_ws(' ', el.nom, el.postnom, el.prenom)) AS eleve,
            el.responsable_email, el.responsable_nom,
            cl.nom AS classe,
            COALESCE(p.libelle, concat(p.type::text, ' ', p.numero)) AS periode,
            e.nom AS ecole,
            b.pourcentage, b.classement, b.mention
       FROM eleves el
       JOIN ecoles e ON e.id = el.ecole_id
       LEFT JOIN classes cl ON cl.id = el.classe_id
       LEFT JOIN bulletins b ON b.eleve_id = el.id AND b.periode_id = $2
       CROSS JOIN LATERAL (SELECT libelle, type, numero FROM periodes WHERE id = $2) p
      WHERE el.id = ANY($1::uuid[])
        AND el.responsable_email IS NOT NULL
        AND el.responsable_email <> ''`,
    [eleveIds, periodeId]
  );

  let envoyees = 0;

  for (const l of lignes.rows) {
    envoyees += await notifierEvenement(client, {
      evenement: 'bulletin.disponible',
      destinataires: [{ email: l.responsable_email, nom: l.responsable_nom }],
      expediteurId: req.auth.userId,
      visibleInterface: false,
      donnees: {
        eleve: l.eleve,
        classe: l.classe,
        periode: l.periode,
        ecole: l.ecole,
        pourcentage: l.pourcentage,
        classement: l.classement,
        mention: l.mention
      },
      // Re-signer un bulletin déjà signé n'écrit pas une seconde fois aux
      // parents : la même période, le même élève, un seul message.
      cleUnicite: `bulletin_dispo:${l.id}:${periodeId}`
    });
  }

  return envoyees;
}

/**
 * Vérifie que l'utilisateur est bien le titulaire de la classe de cet élève
 * (ou directeur/préfet/super_admin, qui passent toujours).
 */
/**
 * Vérifie que l'utilisateur a le droit d'agir sur CETTE classe : le personnel
 * de direction/secrétariat passe toujours, un titulaire seulement si la classe
 * est bien la sienne. Sans ce contrôle, n'importe quel titulaire pouvait lister
 * ou imprimer les bulletins de n'importe quelle classe de l'école.
 */
async function estAutoriseSurClasse(client, req, classeId, { avecSecretaire = true } = {}) {
  const rolesToujoursOk = avecSecretaire ? ['directeur', 'prefet', 'secretaire'] : ['directeur', 'prefet'];
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => rolesToujoursOk.includes(r))) {
    return true;
  }
  const result = await client.query(
    `SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`,
    [classeId, req.auth.userId]
  );
  return result.rows.length > 0;
}

async function estAutoriseSurEleve(client, req, eleveId) {
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r))) {
    return true;
  }
  const result = await client.query(
    `SELECT 1 FROM eleves e
     JOIN classes c ON c.id = e.classe_id
     WHERE e.id = $1 AND c.titulaire_id = $2`,
    [eleveId, req.auth.userId]
  );
  return result.rows.length > 0;
}

/**
 * Vérifie qu'une signature exploitable existe avant d'autoriser à signer :
 * soit celle personnelle de l'utilisateur connecté, soit à défaut la
 * signature générique de l'école. Sans l'une des deux, impossible de signer
 * — un bulletin "signé" sans aucune signature associée n'aurait pas de sens.
 */
async function uneSignatureExisteDeja(client, req) {
  const result = await client.query(
    `SELECT 1 FROM documents WHERE ecole_id = ${CURRENT_ECOLE} AND type = 'signature' LIMIT 1`
  );
  return result.rows.length > 0;
}

/**
 * PATCH /bulletins/:eleveId
 * body: { periodeId, conduite, application, observation }
 * Réservé au titulaire de la classe de l'élève (ou directeur/préfet).
 */
async function mettreAJourAppreciations(req, res) {
  const { eleveId } = req.params;
  const { periodeId, conduite, application, observation } = req.body;

  if (!periodeId) {
    return res.status(400).json({ message: 'periodeId requis.' });
  }

  // Le Titulaire ne peut modifier QUE l'observation — la conduite et l'application
  // relèvent du Directeur/Préfet.
  const estDirecteurOuPrefet = req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
  const conduiteFinale = estDirecteurOuPrefet ? conduite : null;
  const applicationFinale = estDirecteurOuPrefet ? application : null;

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const autorise = await estAutoriseSurEleve(client, req, eleveId);
      if (!autorise) {
        throw Object.assign(new Error("Vous n'êtes pas le titulaire de la classe de cet élève."), { statusCode: 403 });
      }
      await verifierPeriodeActive(client, periodeId);

      // Une fois le bulletin signé, plus aucune modification n'est possible pour
      // le titulaire — sauf si l'école a explicitement autorisé cette exception
      // dans ses paramètres. Directeur/Préfet ne sont jamais bloqués.
      if (!estDirecteurOuPrefet) {
        const bulletinResult = await client.query(
          `SELECT signe_at FROM bulletins WHERE eleve_id = $1 AND periode_id = $2`,
          [eleveId, periodeId]
        );
        if (bulletinResult.rows[0]?.signe_at) {
          const ecoleResult = await client.query(`SELECT autoriser_modif_apres_signature FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
          if (!ecoleResult.rows[0]?.autoriser_modif_apres_signature) {
            throw Object.assign(new Error('Ce bulletin est déjà signé et ne peut plus être modifié. Adressez-vous au Directeur ou au Préfet si une correction est nécessaire.'), { statusCode: 403 });
          }
        }
      }

      await client.query(
        `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, conduite, application, observation)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5)
         ON CONFLICT (eleve_id, periode_id)
         DO UPDATE SET conduite = COALESCE(EXCLUDED.conduite, bulletins.conduite),
                       application = COALESCE(EXCLUDED.application, bulletins.application),
                       observation = COALESCE(EXCLUDED.observation, bulletins.observation)`,
        [eleveId, periodeId, conduiteFinale, applicationFinale, observation]
      );
    });

    return res.json({ message: 'Appréciations enregistrées.' });
  } catch (err) {
    console.error('Erreur appréciations bulletin:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /bulletins/:eleveId/signer
 * body: { periodeId }
 */
async function signer(req, res) {
  const { eleveId } = req.params;
  const { periodeId } = req.body;
  if (!periodeId) {
    return res.status(400).json({ message: 'periodeId requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const autorise = await estAutoriseSurEleve(client, req, eleveId);
      if (!autorise) {
        throw Object.assign(new Error("Vous n'êtes pas le titulaire de la classe de cet élève."), { statusCode: 403 });
      }
      await verifierPeriodeActive(client, periodeId);

      if (!(await uneSignatureExisteDeja(client, req))) {
        throw Object.assign(new Error("Aucune signature n'est enregistrée (ni la vôtre, ni celle de l'école). Téléversez d'abord une signature avant de pouvoir signer un bulletin."), { statusCode: 409 });
      }

      // WHERE signe_at IS NULL : on ne ré-écrase pas une signature déjà posée
      // (même comportement que « Tout signer », qui protégeait déjà les bulletins signés).
      const resultat = await client.query(
        `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, signe_par, signe_at)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, now())
         ON CONFLICT (eleve_id, periode_id)
         DO UPDATE SET signe_par = EXCLUDED.signe_par, signe_at = EXCLUDED.signe_at
         WHERE bulletins.signe_at IS NULL`,
        [eleveId, periodeId, req.auth.userId]
      );
      if (resultat.rowCount === 0) {
        throw Object.assign(new Error('Ce bulletin est déjà signé.'), { statusCode: 409 });
      }

      await notifierFamillesBulletinDisponible(client, req, {
        eleveIds: [eleveId], periodeId
      });
    });

    planifierVidage();

    return res.json({ message: 'Bulletin signé.' });
  } catch (err) {
    console.error('Erreur signature bulletin:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /bulletins/classe/:classeId/imprimer?periodeId=
 * Génère le PDF (4 colonnes, A4 paysage) de tous les élèves actifs de la classe.
 */

/**
 * GET /bulletins/classe/:classeId/verification?periodeId=
 *
 * Ce qui manque avant d'imprimer — SANS empêcher d'imprimer.
 *
 * Une école imprime parfois des bulletins incomplets en connaissance de cause :
 * un enseignant absent, une matière non évaluée ce trimestre. Bloquer
 * l'impression la mettrait dans l'impasse. Mais imprimer sans le savoir, puis
 * distribuer trois cents bulletins où il manque une note, est bien pire.
 *
 * On avertit donc, on ne bloque pas. C'est à l'école de décider.
 */
async function verifierAvantImpression(req, res) {
  const { classeId } = req.params;
  const { periodeId } = req.query;

  if (!periodeId) {
    return res.status(400).json({ message: 'periodeId requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (!(await estAutoriseSurClasse(client, req, classeId))) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      const periode = await client.query(
        `SELECT libelle, cloturee FROM periodes
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [periodeId]
      );
      if (periode.rows.length === 0) {
        throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
      }

      // Trois manques distincts, parce qu'ils appellent trois décisions
      // différentes : relancer un enseignant, corriger la configuration, ou
      // accepter une lacune connue.
      const cours = await client.query(
        `SELECT co.nom AS cours_nom,
                count(*) FILTER (WHERE n.points_obtenus IS NOT NULL) AS nb_notes,
                (SELECT count(*) FROM eleves e
                  WHERE e.classe_id = $1 AND e.statut = 'actif') AS nb_eleves,
                bool_or(n.valide) AS au_moins_une_validee,
                COALESCE(
                  (SELECT string_agg(DISTINCT trim(concat(u.prenom, ' ', u.nom)), ', ')
                     FROM enseignant_cours ec
                     JOIN utilisateurs u ON u.id = ec.utilisateur_id
                    WHERE ec.classe_cours_id = cc.id), ''
                ) AS enseignants
           FROM classe_cours cc
           JOIN cours co ON co.id = cc.cours_id
           LEFT JOIN notes n ON n.classe_cours_id = cc.id AND n.periode_id = $2
          WHERE cc.classe_id = $1 AND cc.ecole_id = ${CURRENT_ECOLE}
          GROUP BY co.nom, cc.id
          ORDER BY co.nom`,
        [classeId, periodeId]
      );

      const nbEleves = cours.rows.length > 0 ? Number(cours.rows[0].nb_eleves) : 0;

      const vides = [];
      const partiels = [];
      const nonValides = [];
      for (const c of cours.rows) {
        const notes = Number(c.nb_notes);
        if (notes === 0) {
          vides.push({ cours: c.cours_nom, enseignants: c.enseignants || null });
        } else if (notes < nbEleves) {
          partiels.push({
            cours: c.cours_nom, nb_notes: notes, nb_eleves: nbEleves,
            enseignants: c.enseignants || null
          });
        }
        if (Number(c.nb_notes) > 0 && !c.au_moins_une_validee) {
          nonValides.push({ cours: c.cours_nom, enseignants: c.enseignants || null });
        }
      }

      const eleveSansNote = await client.query(
        `SELECT trim(concat(e.nom, ' ', COALESCE(e.postnom, ''), ' ', COALESCE(e.prenom, ''))) AS nom
           FROM eleves e
          WHERE e.classe_id = $1 AND e.statut = 'actif' AND e.ecole_id = ${CURRENT_ECOLE}
            AND NOT EXISTS (
              SELECT 1 FROM notes n
               JOIN classe_cours cc ON cc.id = n.classe_cours_id
              WHERE n.eleve_id = e.id AND n.periode_id = $2 AND cc.classe_id = $1
                AND n.points_obtenus IS NOT NULL
            )
          ORDER BY e.nom`,
        [classeId, periodeId]
      );

      return {
        periode: periode.rows[0].libelle,
        periode_cloturee: periode.rows[0].cloturee === true,
        nb_eleves: nbEleves,
        nb_cours: cours.rows.length,
        // `impression_possible` est TOUJOURS vrai : le champ existe pour dire
        // explicitement à l'écran qu'il ne doit pas bloquer, plutôt que de le
        // laisser conclure d'une absence d'alerte.
        impression_possible: true,
        prete: vides.length === 0 && partiels.length === 0 && eleveSansNote.rows.length === 0,
        cours_sans_note: vides,
        cours_partiels: partiels,
        cours_non_valides: nonValides,
        eleves_sans_aucune_note: eleveSansNote.rows.map((e) => e.nom)
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur vérification avant impression:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function genererPdfClasse(req, res) {
  const { classeId } = req.params;
  const { periodeId } = req.query;

  if (!periodeId) {
    return res.status(400).json({ message: 'periodeId requis.' });
  }

  let browser;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (!(await estAutoriseSurClasse(client, req, classeId))) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      const ecoleResult = await client.query(
        `SELECT nom, ville, commune, province, logo_url FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const ecole = ecoleResult.rows[0];

      const classeResult = await client.query(
        `SELECT c.nom, o.nom AS option_nom
         FROM classes c
         LEFT JOIN options o ON o.id = c.option_id
         WHERE c.id = $1`,
        [classeId]
      );
      const classe = classeResult.rows[0];
      if (!classe) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }

      const periodeResult = await client.query(
        `SELECT p.libelle, p.type, p.numero, p.annee_scolaire_id, a.libelle AS annee_libelle
         FROM periodes p
         JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
         WHERE p.id = $1`,
        [periodeId]
      );
      const periode = periodeResult.rows[0];
      const periodeLibelle = periode?.libelle || `${periode?.type || ''} ${periode?.numero || ''}`;

      // `domaine` et `groupe_domaine` servent au primaire : sa grille officielle
      // range les branches par domaine, avec un sous-total par groupe. Sans ces
      // deux colonnes, le bulletin de période sortait en liste alphabétique
      // plate, alors que le bulletin annuel de la même classe est structuré —
      // deux présentations différentes des mêmes branches, pour un même élève.
      const coursResult = await client.query(
        `SELECT cc.id AS classe_cours_id, c.id AS cours_id, c.nom, c.domaine, c.groupe_domaine,
                COALESCE(cc.maximum_points_override, c.maximum_points) AS maximum
         FROM classe_cours cc
         JOIN cours c ON c.id = cc.cours_id
         WHERE cc.classe_id = $1
         ORDER BY c.nom`,
        [classeId]
      );
      const cours = coursResult.rows;

      // Le regroupement par domaines n'est produit que si les cours en portent
      // un. Une classe de secondaire reçoit `domaines: null` et garde sa liste
      // plate — rien ne change pour elle.
      let domaines = null;
      if (cours.some((c) => c.domaine)) {
        const groupement = grouperParDomaine(cours);
        domaines = groupement.domaines;
        // Un cours sans domaine dans une classe qui en a disparaîtrait du
        // tableau sans que personne ne le remarque. On le montre à part.
        if (groupement.sansDomaine.length > 0) {
          domaines = domaines.concat([{ nom: 'AUTRES BRANCHES', cours: groupement.sansDomaine }]);
        }
      }

      const elevesResult = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule,
                b.total, b.pourcentage, b.classement, b.mention,
                b.conduite, b.application, b.observation
         FROM eleves e
         LEFT JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         ORDER BY COALESCE(b.classement, 999999), e.nom, e.postnom`,
        [classeId, periodeId]
      );
      // ---------- Contrôle financier ----------
      // Désactivé par défaut : si l'école ne l'a pas activé, cette étape
      // renvoie simplement tout le monde et rien ne change.
      const { actif: controleActif, situations } =
        await situationFinanciere(client, elevesResult.rows.map((e) => e.id));

      const eleves = controleActif
        ? elevesResult.rows.filter((e) => !(situations.get(e.id) || {}).bloque)
        : elevesResult.rows;
      const retenus = elevesResult.rows.length - eleves.length;

      if (controleActif && eleves.length === 0) {
        throw Object.assign(
          new Error("Aucun bulletin délivrable : tous les élèves de cette classe ont un solde de frais non réglé. Accordez une dérogation si nécessaire."),
          { statusCode: 409 }
        );
      }

      const totauxMaxParEleve = cours.reduce((somme, c) => somme + Number(c.maximum || 0), 0);

      // Modèle personnalisé actif pour cette école (créé via le générateur visuel) ?
      // Le format officiel du bulletin diffère entre primaire et secondaire.
      // On retient le modèle du cycle de la classe s'il existe, sinon celui
      // qui ne cible aucun cycle — l'ordre de tri fait ce choix.
      const cycleClasseResult = await client.query(
        `SELECT cycle::text FROM classes WHERE id = $1`, [classeId]
      );
      const cycleClasse = cycleClasseResult.rows[0]?.cycle || null;

      // Sélection du modèle du bulletin DE PÉRIODE. Les gabarits officiels RDC
      // ne sont pas concernés : ils couvrent l'année entière (deux semestres,
      // T.G., décision de passage) et relèvent du bulletin ANNUEL — c'est
      // bulletin-annuel.controller.js qui les met en oeuvre.
      //
      // La clause `variante IS NULL` garantit qu'un modèle officiel seedé ne
      // peut jamais être choisi ici, même si son type était mal renseigné.
      const modeleActifResult = await client.query(
        `SELECT * FROM modeles_bulletins
         WHERE type = 'periode' AND actif = true AND variante IS NULL
           AND (ecole_id = ${CURRENT_ECOLE} OR ecole_id IS NULL)
           AND (cycle IS NULL OR cycle::text = $1)
         ORDER BY (cycle IS NULL), ecole_id NULLS LAST
         LIMIT 1`,
        [cycleClasse]
      );
      const modeleActif = modeleActifResult.rows[0] || null;
      let zonesModele = [];
      if (modeleActif) {
        const zonesResult = await client.query(
          `SELECT * FROM zones_modele WHERE modele_id = $1`,
          [modeleActif.id]
        );
        zonesModele = zonesResult.rows;
      }

      for (const eleve of eleves) {
        const notesResult = await client.query(
          `SELECT n.classe_cours_id, n.points_obtenus, c.nom AS cours_nom, c.code AS cours_code
           FROM notes n
           JOIN classe_cours cc ON cc.id = n.classe_cours_id
           JOIN cours c ON c.id = cc.cours_id
           WHERE n.eleve_id = $1 AND n.periode_id = $2`,
          [eleve.id, periodeId]
        );
        eleve.notes = notesResult.rows;
        eleve.total_maximum = totauxMaxParEleve;

        // Index des notes par "slug" du nom/code du cours, pour le modèle personnalisé
        eleve.notesParSlug = {};
        for (const n of notesResult.rows) {
          if (n.points_obtenus === null) continue;
          if (n.cours_nom) eleve.notesParSlug[slugifier(n.cours_nom)] = n.points_obtenus;
          if (n.cours_code) eleve.notesParSlug[slugifier(n.cours_code)] = n.points_obtenus;
        }
      }

      // Deux informations à distinguer : l'IMAGE de la signature (peu importe
      // qui elle est), et le LIBELLÉ à imprimer, qui doit refléter qui a
      // réellement signé — pas une supposition. Sans cette distinction, le
      // document affichait « Signature du titulaire » même quand aucune
      // signature de titulaire n'existait et que c'était en réalité celle du
      // directeur qui s'imprimait, empruntée par défaut.
      //
      // La règle vit maintenant dans utils/signatures.utils.js, partagée avec
      // les bulletins de semestre, annuels et les duplicatas d'archives : elle
      // était appliquée ici correctement et ailleurs pas du tout.
      // Seuil de réussite de l'école : il décide des cotes grisées sur le
      // bulletin. On lit le même paramètre que la promotion et les rapports,
      // pour qu'une branche en échec ici le soit aussi partout ailleurs.
      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuilReussite = Number(seuilResult.rows[0]?.seuil ?? 50);

      const signatures = await resoudreSignatures(client, { classeId });

      return {
        ecole, classe, periodeLibelle, anneeLibelle: periode?.annee_libelle, cours, eleves,
        modeleActif, zonesModele, retenus, domaines, seuilReussite,
        signatureUrl: signatures.signatureUrl,
        // Le gabarit choisit son libellé d'après ces deux informations plutôt
        // que d'écrire « Signature du titulaire » en dur.
        signatureEstTitulaire: signatures.signatureEstTitulaire,
        signatureEstDirecteur: signatures.signatureEstDirecteur,
        signatureNom: signatures.signatureNom,
        cachetUrl: signatures.cachetUrl
      };
    });

    const utiliseModelePersonnalise = !!donnees.modeleActif;
    const html = utiliseModelePersonnalise
      ? construireHtmlBulletinPersonnalise({
          modele: donnees.modeleActif, zones: donnees.zonesModele, eleves: donnees.eleves,
          classe: donnees.classe, periodeLibelle: donnees.periodeLibelle,
          anneeLibelle: donnees.anneeLibelle, ecole: donnees.ecole,
          // Sans ces deux-là, une zone « signature » ou « cachet » placée par
          // l'école sur son modèle restait désespérément vide à l'impression.
          signatureUrl: donnees.signatureUrl, cachetUrl: donnees.cachetUrl
        })
      : construireHtmlBulletins(donnees);

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({
      format: 'A4',
      landscape: !utiliseModelePersonnalise,
      printBackground: true
    });
    await browser.close();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="bulletins-${classeId}.pdf"`);
    return res.send(pdfBuffer);
  } catch (err) {
    if (browser) await browser.close();
    console.error('Erreur génération PDF bulletins:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /bulletins/classe/:classeId/liste?periodeId=
 * Vue d'ensemble pour l'écran Bulletins : notes calculées + appréciations actuelles
 * de chaque élève de la classe, pour une période donnée.
 */
async function listerBulletinsClasse(req, res) {
  const { classeId } = req.params;
  const { periodeId } = req.query;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (!(await estAutoriseSurClasse(client, req, classeId))) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      // Rafraîchir les totaux AVANT de les lire.
      //
      // `bulletins.total`, `.pourcentage` et `.classement` sont des valeurs
      // matérialisées, écrites au moment de la saisie des notes. Cet écran les
      // lisait telles quelles : un bulletin calculé avant une correction de
      // formule — ou avant qu'une note ne soit modifiée dans un autre cours —
      // affichait donc une valeur périmée, différente de celle du PDF.
      //
      // C'est exactement l'écart constaté entre l'écran et le document imprimé.
      // Recalculer ici plutôt que d'ajouter un bouton « rafraîchir » : un écart
      // entre deux affichages de la même donnée ne doit pas dépendre d'une
      // action manuelle que personne ne pensera à faire.
      await recalculerClassement(client, classeId, periodeId);

      return client.query(
        `SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom, e.matricule,
                b.total, b.pourcentage, b.classement, b.mention,
                b.conduite, b.application, b.observation, b.signe_at
         FROM eleves e
         LEFT JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         ORDER BY COALESCE(b.classement, 999999), e.nom, e.postnom`,
        [classeId, periodeId]
      );
    });
    return res.json(result.rows);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste bulletins classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /bulletins/:eleveId/detail?periodeId=
 * Détail complet façon "bulletin" pour un élève et une période : ses infos,
 * chaque cours avec côte/maximum, le total/pourcentage/classement, l'application
 * et la conduite, et pour chaque cours un indicateur "modifiable_par_moi" (vrai
 * si la personne connectée est le professeur assigné à ce cours précis dans
 * cette classe — sert à limiter les modifications à ses propres cours).
 */
async function obtenirDetailEleve(req, res) {
  const { eleveId } = req.params;
  const { periodeId } = req.query;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const autorise = await estAutoriseSurEleve(client, req, eleveId);
      if (!autorise) {
        throw Object.assign(new Error("Vous n'êtes pas autorisé à consulter cet élève."), { statusCode: 403 });
      }

      const eleveResult = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule, e.classe_id, c.nom AS classe_nom
         FROM eleves e JOIN classes c ON c.id = e.classe_id WHERE e.id = $1`,
        [eleveId]
      );
      if (eleveResult.rows.length === 0) throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      const eleve = eleveResult.rows[0];

      const periodeResult = await client.query(`SELECT libelle FROM periodes WHERE id = $1`, [periodeId]);

      // EXISTS et non LEFT JOIN : avec un JOIN, chaque professeur supplémentaire
      // assigné au même cours (co-enseignement) dupliquait la ligne du cours dans
      // le détail du bulletin.
      const coursResult = await client.query(
        `SELECT cc.id AS classe_cours_id, co.nom AS cours_nom,
                n.points_obtenus, COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum,
                EXISTS(
                  SELECT 1 FROM enseignant_cours ec
                  WHERE ec.classe_cours_id = cc.id AND ec.utilisateur_id = $3
                ) AS modifiable_par_moi
         FROM classe_cours cc
         JOIN cours co ON co.id = cc.cours_id
         LEFT JOIN notes n ON n.classe_cours_id = cc.id AND n.eleve_id = $1 AND n.periode_id = $2
         WHERE cc.classe_id = $4
         ORDER BY co.nom`,
        [eleveId, periodeId, req.auth.userId, eleve.classe_id]
      );

      const bulletinResult = await client.query(
        `SELECT total, pourcentage, classement, mention, conduite, application, observation
         FROM bulletins WHERE eleve_id = $1 AND periode_id = $2`,
        [eleveId, periodeId]
      );

      return {
        eleve, periode_libelle: periodeResult.rows[0]?.libelle,
        cours: coursResult.rows,
        bulletin: bulletinResult.rows[0] || { total: null, pourcentage: null, classement: null, mention: null, conduite: null, application: null, observation: null }
      };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détail élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /bulletins/classe/:classeId/signer-tout
 * body: { periodeId }
 * Signe en une fois tous les bulletins pas encore signés de cette classe pour
 * cette période (réservé au titulaire de cette classe, ou directeur/préfet).
 */
async function signerToutLaClasse(req, res) {
  const { classeId } = req.params;
  const { periodeId } = req.body;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const nb = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(`SELECT titulaire_id FROM classes WHERE id = $1`, [classeId]);
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      const estDirecteurOuPrefet = req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
      if (!estDirecteurOuPrefet && classeResult.rows[0].titulaire_id !== req.auth.userId) {
        throw Object.assign(new Error("Vous n'êtes pas le titulaire de cette classe."), { statusCode: 403 });
      }
      await verifierPeriodeActive(client, periodeId);

      if (!(await uneSignatureExisteDeja(client, req))) {
        throw Object.assign(new Error("Aucune signature n'est enregistrée (ni la vôtre, ni celle de l'école). Téléversez d'abord une signature avant de pouvoir signer."), { statusCode: 409 });
      }

      const elevesResult = await client.query(
        `SELECT id FROM eleves WHERE classe_id = $1 AND statut = 'actif'`,
        [classeId]
      );

      let nbSignes = 0;
      const signesMaintenant = [];
      for (const eleve of elevesResult.rows) {
        const resultat = await client.query(
          `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, signe_par, signe_at)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, now())
           ON CONFLICT (eleve_id, periode_id)
           DO UPDATE SET signe_par = EXCLUDED.signe_par, signe_at = EXCLUDED.signe_at
           WHERE bulletins.signe_at IS NULL`,
          [eleve.id, periodeId, req.auth.userId]
        );
        nbSignes += resultat.rowCount;
        // Seuls les bulletins signés À L'INSTANT sont annoncés : ceux qui
        // l'étaient déjà ont fait partir leur message la première fois.
        if (resultat.rowCount > 0) signesMaintenant.push(eleve.id);
      }

      const famillesPrevenues = await notifierFamillesBulletinDisponible(client, req, {
        eleveIds: signesMaintenant, periodeId
      });

      return {
        nbSignes,
        dejaSignes: elevesResult.rows.length - nbSignes,
        famillesPrevenues
      };
    });

    planifierVidage();

    const complement = nb.dejaSignes > 0 ? ` (${nb.dejaSignes} étai(en)t déjà signé(s))` : '';
    const familles = nb.famillesPrevenues > 0
      ? ` ${nb.famillesPrevenues} famille(s) ont été prévenues par e-mail.`
      : '';
    return res.json({ message: `${nb.nbSignes} bulletin(s) signé(s)${complement}.${familles}` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur signature en masse:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { mettreAJourAppreciations, signer, signerToutLaClasse, genererPdfClasse, listerBulletinsClasse, obtenirDetailEleve,
  verifierAvantImpression
};
