const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const {
  estJourOuvrable, periodeCourante, versDateSql, numeroJourSemaine
} = require('../utils/calendrier.utils');
const {
  notifierEvenement, destinatairesParRole, planifierVidage
} = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /evenements?debut=&fin=
 * Tous les utilisateurs authentifiés de l'école peuvent consulter le calendrier.
 */
async function lister(req, res) {
  const { debut, fin } = req.query;
  try {
    const conditions = [`ecole_id = ${CURRENT_ECOLE}`];
    const params = [];
    if (debut) { params.push(debut); conditions.push(`date_debut >= $${params.length}`); }
    if (fin) { params.push(fin); conditions.push(`date_debut <= $${params.length}`); }

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT * FROM evenements_calendrier WHERE ${conditions.join(' AND ')} ORDER BY date_debut`,
        params
      )
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste calendrier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /evenements
 * body: { titre, type, date_debut, date_fin }
 * type ∈ debut_cours | examen | depot_resultats | conseil_classe | proclamation | vacances | reunion
 */
async function creer(req, res) {
  const { titre, type, date_debut, date_fin } = req.body;
  if (!titre || !type || !date_debut) {
    return res.status(400).json({ message: 'titre, type et date_debut sont requis.' });
  }

  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `INSERT INTO evenements_calendrier (ecole_id, titre, type, date_debut, date_fin)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4) RETURNING id`,
        [titre, type, date_debut, date_fin || null]
      );

      // Annonce immédiate au personnel : un événement ajouté au calendrier
      // n'existe pour l'école que si quelqu'un ouvre le calendrier. Les
      // rappels J-7 / J-1 / jour J suivront (voir jobs.controller) ; celui-ci
      // signale simplement qu'une date vient d'être posée, pendant que les
      // emplois du temps peuvent encore s'organiser autour.
      //
      // Interne uniquement, et volontairement : un e-mail à chaque ajout de
      // ligne au calendrier serait insupportable pour un secrétariat qui en
      // saisit trente d'affilée en début d'année.
      await notifierEvenement(client, {
        evenement: 'calendrier.evenement_ajoute',
        destinataires: await destinatairesParRole(client, [
          'directeur', 'prefet', 'secretaire', 'professeur', 'titulaire',
          'directeur_discipline', 'charge_presences'
        ]),
        expediteurId: req.auth.userId,
        canal: 'interne',
        donnees: {
          titre, type,
          dateDebut: date_debut,
          dateFin: date_fin || null
        },
        cleUnicite: `evenement_ajoute:${r.rows[0].id}`
      });

      return r;
    });

    planifierVidage();

    return res.status(201).json({ id: result.rows[0].id });
  } catch (err) {
    console.error('Erreur création événement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /evenements/:id
 */
async function modifier(req, res) {
  const { id } = req.params;
  const { titre, type, date_debut, date_fin } = req.body;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE evenements_calendrier
         SET titre = COALESCE($1, titre), type = COALESCE($2, type),
             date_debut = COALESCE($3, date_debut), date_fin = COALESCE($4, date_fin)
         WHERE id = $5`,
        [titre, type, date_debut, date_fin, id]
      )
    );
    return res.json({ message: 'Événement mis à jour.' });
  } catch (err) {
    console.error('Erreur modification événement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /evenements/:id
 */
async function supprimer(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('DELETE FROM evenements_calendrier WHERE id = $1', [id])
    );
    return res.json({ message: 'Événement supprimé.' });
  } catch (err) {
    console.error('Erreur suppression événement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   JOURS SPÉCIAUX — fériés, vacances, congés
   ========================================================================== */

/** GET /evenements/jours-speciaux?anneeScolaireId= */
async function listerJoursSpeciaux(req, res) {
  const { anneeScolaireId } = req.query;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) => {
      const conditions = [`js.ecole_id = ${CURRENT_ECOLE}`];
      const params = [];
      if (anneeScolaireId) {
        params.push(anneeScolaireId);
        conditions.push(`(js.annee_scolaire_id = $${params.length} OR js.annee_scolaire_id IS NULL)`);
      }
      return client.query(
        `SELECT js.*, trim(concat(u.prenom, ' ', u.nom)) AS cree_par_nom
           FROM jours_speciaux js
           LEFT JOIN utilisateurs u ON u.id = js.cree_par
          WHERE ${conditions.join(' AND ')}
          ORDER BY js.date_debut`,
        params
      );
    });
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste jours spéciaux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /evenements/jours-speciaux
 * body: { libelle, type, date_debut, date_fin, cycle, annee_scolaire_id }
 */
async function creerJourSpecial(req, res) {
  const { libelle, type, date_debut, date_fin, cycle, annee_scolaire_id } = req.body;
  if (!libelle || !date_debut) {
    return res.status(400).json({ message: 'libelle et date_debut sont requis.' });
  }

  // Une plage inversée passerait les contrôles applicatifs mais ne bloquerait
  // AUCUN jour : la condition `BETWEEN date_debut AND date_fin` ne renvoie
  // jamais rien quand la fin précède le début. L'école croirait ses vacances
  // enregistrées alors que les présences resteraient ouvertes.
  const fin = date_fin || date_debut;
  if (fin < date_debut) {
    return res.status(400).json({ message: 'La date de fin doit suivre la date de début.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const chevauchement = await client.query(
        `SELECT libelle, date_debut, date_fin FROM jours_speciaux
          WHERE ecole_id = ${CURRENT_ECOLE}
            AND (cycle IS NULL OR $3::text IS NULL OR cycle::text = $3)
            AND daterange(date_debut, date_fin, '[]') && daterange($1::date, $2::date, '[]')
          LIMIT 1`,
        [date_debut, fin, cycle || null]
      );
      // Un chevauchement n'est pas bloquant — une journée pédagogique peut
      // tomber pendant une semaine de congé — mais il est signalé : c'est le
      // plus souvent une double saisie.
      const avertissement = chevauchement.rows[0] || null;

      const insere = await client.query(
        `INSERT INTO jours_speciaux
           (ecole_id, annee_scolaire_id, libelle, type, date_debut, date_fin, cycle, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, COALESCE($3, 'ferie')::type_jour_special, $4, $5, $6::cycle_enseignement, $7)
         RETURNING id`,
        [annee_scolaire_id || null, String(libelle).trim(), type || null,
         date_debut, fin, cycle || null, req.auth.userId]
      );

      return { id: insere.rows[0].id, avertissement };
    });

    const message = resultat.avertissement
      ? `Enregistré. Attention : chevauche « ${resultat.avertissement.libelle} », déjà au calendrier.`
      : 'Jour non ouvré enregistré.';
    return res.status(201).json({ id: resultat.id, message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création jour spécial:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** DELETE /evenements/jours-speciaux/:id */
async function supprimerJourSpecial(req, res) {
  const { id } = req.params;
  try {
    const supprimes = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `DELETE FROM jours_speciaux WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      return r.rowCount;
    });
    if (supprimes === 0) return res.status(404).json({ message: 'Jour non ouvré introuvable.' });
    return res.json({ message: 'Jour non ouvré supprimé.' });
  } catch (err) {
    console.error('Erreur suppression jour spécial:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   VUE MENSUELLE CONSOLIDÉE
   ========================================================================== */

/**
 * GET /evenements/mois?annee=2026&mois=10&cycle=
 *
 * Renvoie tout ce qu'il faut pour dessiner un mois d'un coup : le statut de
 * chaque jour, les événements, la période en cours. Une seule requête plutôt
 * qu'un aller-retour par jour — un mois en compte une trentaine, et l'écran
 * serait inutilisable sur une connexion lente.
 */
async function vueMensuelle(req, res) {
  const annee = parseInt(req.query.annee, 10);
  const mois = parseInt(req.query.mois, 10); // 1 = janvier
  const cycle = req.query.cycle || null;

  if (!annee || !mois || mois < 1 || mois > 12) {
    return res.status(400).json({ message: 'annee et mois (1-12) sont requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const premier = new Date(Date.UTC(annee, mois - 1, 1));
      const dernier = new Date(Date.UTC(annee, mois, 0));
      const debutSql = versDateSql(premier);
      const finSql = versDateSql(dernier);

      const evenements = await client.query(
        `SELECT id, titre, type::text AS type, date_debut, date_fin
           FROM evenements_calendrier
          WHERE ecole_id = ${CURRENT_ECOLE}
            AND date_debut::date <= $2::date
            AND COALESCE(date_fin, date_debut)::date >= $1::date
          ORDER BY date_debut`,
        [debutSql, finSql]
      );

      const speciaux = await client.query(
        `SELECT id, libelle, type::text AS type, date_debut, date_fin, cycle::text AS cycle
           FROM jours_speciaux
          WHERE ecole_id = ${CURRENT_ECOLE}
            AND date_debut <= $2::date AND date_fin >= $1::date
            AND (cycle IS NULL OR $3::text IS NULL OR cycle::text = $3)
          ORDER BY date_debut`,
        [debutSql, finSql, cycle]
      );

      const ecole = await client.query(
        `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5]) AS jours_cours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const joursOuvrables = (ecole.rows[0]?.jours_cours || [1, 2, 3, 4, 5]).map(Number);

      const bornes = await client.query(
        `SELECT libelle, date_debut, date_fin FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND active = true AND cloturee = false LIMIT 1`
      );
      const anneeScolaire = bornes.rows[0] || null;

      // Statut de chaque jour du mois, calculé en mémoire à partir des trois
      // sources déjà chargées : refaire un appel par jour multiplierait par 30
      // le nombre de requêtes pour un résultat identique.
      const jours = [];
      for (let n = 1; n <= dernier.getUTCDate(); n++) {
        const d = new Date(Date.UTC(annee, mois - 1, n));
        const dSql = versDateSql(d);
        const numeroJour = numeroJourSemaine(new Date(dSql + 'T12:00:00'));

        const special = speciaux.rows.find((j) => dSql >= versDateSql(j.date_debut) && dSql <= versDateSql(j.date_fin));
        const horsAnnee = anneeScolaire && anneeScolaire.date_debut && anneeScolaire.date_fin
          && (dSql < versDateSql(anneeScolaire.date_debut) || dSql > versDateSql(anneeScolaire.date_fin));

        let statut = 'ouvrable';
        if (horsAnnee) statut = 'hors_annee';
        else if (special) statut = special.type;
        else if (!joursOuvrables.includes(numeroJour)) statut = 'non_ouvre';

        jours.push({
          date: dSql,
          jour_semaine: numeroJour,
          statut,
          libelle_special: special ? special.libelle : null,
          evenements: evenements.rows
            .filter((e) => versDateSql(e.date_debut) <= dSql
                        && versDateSql(e.date_fin || e.date_debut) >= dSql)
            .map((e) => ({ id: e.id, titre: e.titre, type: e.type }))
        });
      }

      const periode = await periodeCourante(client, { cycle });

      return {
        annee, mois, jours,
        jours_ouvrables_semaine: joursOuvrables,
        annee_scolaire: anneeScolaire,
        periode_courante: periode,
        jours_speciaux: speciaux.rows,
        evenements: evenements.rows
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur vue mensuelle:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /evenements/jour?date=AAAA-MM-JJ&cycle=
 * Interrogation ponctuelle : « peut-on faire l'appel ce jour-là ? »
 * Sert à l'écran des présences, pour prévenir AVANT la saisie plutôt que de
 * laisser remplir toute une grille avant de la refuser.
 */
async function verifierJour(req, res) {
  const { date, cycle } = req.query;
  if (!date) return res.status(400).json({ message: 'date requise (AAAA-MM-JJ).' });
  try {
    const verdict = await runWithTenant(tenantContextFromReq(req), (client) =>
      estJourOuvrable(client, date, { cycle: cycle || null })
    );
    return res.json(verdict);
  } catch (err) {
    console.error('Erreur vérification jour:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /evenements/periode-courante?cycle= */
async function obtenirPeriodeCourante(req, res) {
  try {
    const periode = await runWithTenant(tenantContextFromReq(req), (client) =>
      periodeCourante(client, { cycle: req.query.cycle || null })
    );
    return res.json(periode || null);
  } catch (err) {
    console.error('Erreur période courante:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  lister, creer, modifier, supprimer,
  listerJoursSpeciaux, creerJourSpecial, supprimerJourSpecial,
  vueMensuelle, verifierJour, obtenirPeriodeCourante
};
