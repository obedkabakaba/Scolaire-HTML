/**
 * ARDOISE — CATALOGUE COMMERCIAL PUBLIC
 * ===========================================================================
 *
 * Ce que le site public a le droit de savoir : les offres, leurs prix, les
 * services complémentaires, et l'estimation d'une campagne de capture.
 *
 * TROISIÈME CONTRÔLEUR SANS JETON DU PROJET
 * -----------------------------------------
 * Les deux autres sont `public.controller.js` et le webhook WhatsApp. Les
 * mêmes règles s'appliquent ici :
 *
 *   1. Aucune donnée d'école, d'élève ou d'utilisateur ne sort d'ici. Ce
 *      contrôleur ne lit que deux tables de catalogue, qui ne contiennent que
 *      des informations déjà destinées à être affichées sur un site web.
 *   2. Tout est limité en débit.
 *   3. La seule écriture possible est une demande de rappel, plafonnée et
 *      volontairement pauvre en données personnelles.
 *
 * POURQUOI UNE API PLUTÔT QUE DES PRIX ÉCRITS DANS LA PAGE
 * -------------------------------------------------------
 * Parce que les prix figurent déjà dans `plans_abonnement` et que le Super
 * Admin peut les modifier. Les recopier dans du HTML créerait une seconde
 * vérité, qui divergerait au premier changement de tarif — et le visiteur
 * verrait un prix, le directeur un autre sur sa facture.
 *
 * Le HTML de la page contient tout de même les prix : ils sont nécessaires au
 * référencement, qui ne lit pas le JavaScript. Ils y sont ÉCRITS PAR UN
 * SCRIPT (`scripts/generer-tarifs-statiques.js`) à partir de cette même API,
 * et rafraîchis à l'affichage. La page n'invente jamais un chiffre.
 */

const { runWithTenant } = require('../config/db');
const catalogue = require('../utils/catalogue.utils');
const { alerterNouvelleDemande } = require('../utils/prospects.utils');

const SUPER = { isSuperAdmin: true };

/**
 * GET /catalogue/offres
 * Les quatre offres, leurs trois périodicités, leurs limites et leurs
 * fonctionnalités. Sert le site public, la page Abonnement du directeur et
 * le générateur de HTML statique.
 */
async function offres(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, async (client) => ({
      offres: await catalogue.listerOffres(client),
      periodicites: catalogue.PERIODICITES.map((p) => ({
        code: p.code, libelle: p.libelle, mois: p.mois
      })),
      // Le vocabulaire, pour que le tableau comparatif du site n'ait pas à
      // recopier les libellés — et ne puisse donc pas les faire diverger.
      fonctionnalites: catalogue.FONCTIONNALITES,
      limites: Object.fromEntries(
        Object.entries(catalogue.LIMITES).map(([k, v]) => [k, v.libelle]))
    }));

    // Cinq minutes de cache navigateur et CDN : une grille tarifaire ne change
    // pas plus d'une fois par trimestre, et la page d'accueil ne doit pas
    // attendre la base à chaque visite.
    res.set('Cache-Control', 'public, max-age=300, stale-while-revalidate=3600');
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur catalogue offres:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /catalogue/services
 * Les prestations d'accompagnement, groupées par catégorie.
 *
 * Elles sont renvoyées SÉPARÉMENT des offres, sur une route séparée, et
 * groupées par catégorie et non par plan. La structure de l'API dit d'elle-même
 * qu'un service n'appartient à aucune offre.
 */
async function services(req, res) {
  try {
    const liste = await runWithTenant(SUPER, (client) => catalogue.listerServices(client));

    const parCategorie = {
      installation: { titre: 'Installation & configuration',
                      resume: "Nous paramétrons votre école pour qu'elle soit utilisable dès le premier jour.",
                      services: [] },
      formation:    { titre: 'Formation du personnel',
                      resume: 'Nous formons vos équipes, du secrétariat aux professeurs.',
                      services: [] },
      capture:      { titre: 'Campagne de capture',
                      resume: 'Nous constituons votre base d\'élèves à partir de vos registres.',
                      services: [] },
      autre:        { titre: 'Autres prestations', resume: null, services: [] }
    };

    for (const s of liste) {
      (parCategorie[s.categorie] || parCategorie.autre).services.push(s);
    }

    for (const cle of Object.keys(parCategorie)) {
      if (parCategorie[cle].services.length === 0) delete parCategorie[cle];
    }

    res.set('Cache-Control', 'public, max-age=300, stale-while-revalidate=3600');
    return res.json({
      services: liste,
      categories: parCategorie,
      // Dit explicitement au client ce que la page doit dire au visiteur.
      note: "Les services complémentaires sont indépendants de l'abonnement. "
          + "Ils peuvent être commandés avec n'importe quelle offre, y compris Ardoise Ascension."
    });
  } catch (err) {
    console.error('Erreur catalogue services:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /catalogue/estimation?service=campagne_capture&quantite=500
 *
 * Le calcul du simulateur de la page publique. Il ne se fait PAS dans le
 * navigateur : la page afficherait alors un montant que le serveur n'a jamais
 * validé, et un changement de tarif laisserait les anciennes pages en cache
 * annoncer l'ancien prix. Le simulateur affiche un résultat provisoire pendant
 * l'appel, puis le remplace par la réponse du serveur.
 */
async function estimation(req, res) {
  const code = String(req.query.service || 'campagne_capture').trim();
  const quantite = req.query.quantite;

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const liste = await catalogue.listerServices(client);
      const service = liste.find((s) => s.code === code);
      if (!service) {
        throw Object.assign(new Error('Prestation inconnue.'), { statusCode: 404 });
      }
      const montant = catalogue.calculerMontantService(service, quantite);
      return {
        service: { code: service.code, nom: service.nom, unite: service.unite,
                   mode_tarification: service.mode_tarification },
        ...montant
      };
    });

    res.set('Cache-Control', 'no-store');
    return res.json(resultat);
  } catch (err) {
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /catalogue/demande-accompagnement
 * body: { contact_nom, contact_telephone?, contact_email?, ecole_nom?, ville?,
 *         nb_eleves_estime?, offre_envisagee?, services_souhaites?, message? }
 *
 * Le formulaire « Demander un accompagnement » de la page publique.
 *
 * On n'enregistre que ce qui sert à rappeler quelqu'un. Pas d'adresse, pas de
 * fonction, pas de budget : autant de champs que personne ne remplit
 * honnêtement et qui n'ont aucune raison de dormir dans une base.
 */
async function demandeAccompagnement(req, res) {
  const b = req.body || {};

  const nom = texte(b.contact_nom, 120);
  const telephone = texte(b.contact_telephone, 40);
  const email = texte(b.contact_email, 160);

  if (!nom) return res.status(400).json({ message: 'Indiquez votre nom.' });
  if (!telephone && !email) {
    return res.status(400).json({
      message: 'Indiquez au moins un numéro de téléphone ou une adresse e-mail pour être rappelé.'
    });
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ message: "Cette adresse e-mail n'est pas valide." });
  }

  try {
    const enregistree = await runWithTenant(SUPER, async (client) => {
      // Les codes de services et d'offres sont VÉRIFIÉS contre le catalogue :
      // sans cela, ce champ devient un dépotoir de texte libre venu d'un
      // formulaire public, et la demande devient inexploitable côté commercial.
      const [servicesConnus, offresConnues] = await Promise.all([
        catalogue.listerServices(client),
        catalogue.listerOffres(client)
      ]);
      const codesServices = new Set(servicesConnus.map((s) => s.code));
      const codesOffres = new Set(offresConnues.map((o) => o.code));

      const souhaites = Array.isArray(b.services_souhaites)
        ? [...new Set(b.services_souhaites.map((s) => String(s).trim())
            .filter((s) => codesServices.has(s)))]
        : [];

      const offre = codesOffres.has(String(b.offre_envisagee || '').trim())
        ? String(b.offre_envisagee).trim() : null;

      const resultat = await client.query(
        `INSERT INTO demandes_accompagnement
           (ecole_nom, contact_nom, contact_telephone, contact_email, ville,
            nb_eleves_estime, offre_envisagee, services_souhaites, message, origine)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,'site_public')
         RETURNING *`,
        [texte(b.ecole_nom, 160), nom, telephone, email, texte(b.ville, 80),
         entier(b.nb_eleves_estime, 0, 100000), offre,
         JSON.stringify(souhaites), texte(b.message, 1500)]
      );

      // Les libellés lisibles sont résolus ICI, où le catalogue est déjà en
      // mémoire. L'alerte dira « Ardoise Prime » et « Campagne de capture »,
      // pas « prime » et « campagne_capture » : un commercial ne devrait pas
      // avoir à traduire des codes techniques pour comprendre son prospect.
      const parCode = (liste, code) => (liste.find((x) => x.code === code) || {}).nom || code;
      return Object.assign(resultat.rows[0], {
        offre_libelle: offre ? parCode(offresConnues, offre) : null,
        services_libelles: souhaites.map((c) => parCode(servicesConnus, c))
      });
    });

    /*
     * Alerte commerciale — APRÈS le COMMIT, et sans `await`.
     *
     * Après, parce qu'une notification envoyée depuis une transaction qui
     * finit par échouer annonce un prospect qui n'existe pas. Sans `await`,
     * parce que le visiteur n'a pas à patienter derrière un appel à un
     * fournisseur d'e-mail : sa demande est déjà en base, et elle apparaît
     * dans l'espace Super Admin quoi qu'il arrive à ce message.
     */
    alerterNouvelleDemande(enregistree);

    return res.status(201).json({
      id: enregistree.id,
      message: 'Votre demande est enregistrée. Nous vous rappelons sous 48 heures ouvrées.'
    });
  } catch (err) {
    console.error('Erreur demande accompagnement:', err);
    return res.status(500).json({
      message: "Votre demande n'a pas pu être enregistrée. Réessayez dans un instant."
    });
  }
}

/* ------------------------------------------------------------------ outils */

function texte(v, max) {
  const s = String(v === undefined || v === null ? '' : v).trim();
  return s ? s.slice(0, max) : null;
}

function entier(v, min, max) {
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) return null;
  return Math.min(Math.max(n, min), max);
}

module.exports = { offres, services, estimation, demandeAccompagnement };
