const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  CLÔTURE DE PÉRIODE
 * ===========================================================================
 *
 * LE MODÈLE À SERVIR
 * ------------------
 *   « Les classes sont comme statiques et les élèves sont des passants
 *     dedans. »
 *
 * Une école ne reconstruit pas ses classes chaque année. Elle a une 5e A depuis
 * dix ans ; ce sont les élèves qui changent. Le schéma attache pourtant
 * `classes.annee_scolaire_id` : techniquement, une classe appartient à une
 * année.
 *
 * Plutôt que de refondre ce schéma — ce qui toucherait la promotion,
 * l'orientation, les inscriptions et les archives —, on RECONDUIT : ouvrir une
 * année recopie la structure de la précédente. L'école ne ressaisit plus
 * jamais rien ; le modèle interne reste inchangé.
 *
 * CE QUI EST RECONDUIT, ET CE QUI NE L'EST PAS
 * --------------------------------------------
 * Reconduit : les classes et leurs attributs, les cours de chaque classe avec
 * leurs maxima, la grille horaire, les horaires exceptionnels récurrents.
 * C'est la STRUCTURE — ce qui décrit l'école.
 *
 * Non reconduit : les élèves. Ils sont déplacés par la promotion, qui est un
 * acte distinct et réfléchi. Recopier les élèves ferait entrer toute une
 * cohorte dans l'année suivante sans que personne ait décidé qui passe.
 *
 * Non reconduits non plus : notes, présences, bulletins, incidents. Ce sont
 * des faits datés, ils appartiennent à l'année où ils se sont produits.
 */

// ---------------------------------------------------------------------------
//  Clôture de période
// ---------------------------------------------------------------------------

/**
 * GET /periodes/:id/etat-cloture
 *
 * Ce qui manque avant de pouvoir clôturer sereinement : les cours dont les
 * notes n'ont pas été validées, et QUI en est responsable.
 *
 * Nommer l'enseignant est le point important. « 12 cours non soumis » ne permet
 * d'agir sur personne ; « M. Kabila n'a pas soumis les mathématiques en 5e A et
 * 5e B » permet de lui écrire.
 */
async function etatCloture(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const periode = await client.query(
        `SELECT p.id, p.libelle, p.type::text AS type, p.numero, p.cloturee,
                p.cloturee_at, p.annee_scolaire_id,
                a.libelle AS annee_libelle, a.cloturee AS annee_cloturee,
                trim(concat(u.prenom, ' ', u.nom)) AS cloturee_par_nom
           FROM periodes p
           JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
           LEFT JOIN utilisateurs u ON u.id = p.cloturee_par
          WHERE p.id = $1 AND p.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (periode.rows.length === 0) {
        throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
      }
      const p = periode.rows[0];

      // Un cours est « non soumis » s'il n'a aucune note validée pour cette
      // période. On distingue trois cas, parce qu'ils appellent trois messages
      // différents à l'enseignant.
      const manquants = await client.query(
        `SELECT cl.id AS classe_id, cl.nom AS classe_nom,
                co.id AS cours_id, co.nom AS cours_nom,
                cc.id AS classe_cours_id,
                (SELECT count(*) FROM notes n
                  WHERE n.classe_cours_id = cc.id AND n.periode_id = $1
                    AND n.points_obtenus IS NOT NULL) AS nb_notes,
                COALESCE(
                  json_agg(DISTINCT jsonb_build_object(
                    'id', u.id,
                    'nom', trim(concat(u.prenom, ' ', u.nom)),
                    'email', u.email
                  )) FILTER (WHERE u.id IS NOT NULL), '[]'
                ) AS enseignants
           FROM classe_cours cc
           JOIN classes cl ON cl.id = cc.classe_id
           JOIN cours co ON co.id = cc.cours_id
           LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
           LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
          WHERE cc.ecole_id = ${CURRENT_ECOLE}
            AND cl.annee_scolaire_id = $2
            AND NOT EXISTS (
              SELECT 1 FROM notes n
               WHERE n.classe_cours_id = cc.id AND n.periode_id = $1 AND n.valide = true
            )
          GROUP BY cl.id, cl.nom, co.id, co.nom, cc.id
          ORDER BY cl.nom, co.nom`,
        [p.id, p.annee_scolaire_id]
      );

      const lignes = manquants.rows.map((m) => {
        const nb = Number(m.nb_notes);
        return {
          classe_id: m.classe_id, classe_nom: m.classe_nom,
          cours_id: m.cours_id, cours_nom: m.cours_nom,
          enseignants: m.enseignants || [],
          nb_notes: nb,
          etat: (m.enseignants || []).length === 0 ? 'sans_enseignant'
              : nb === 0 ? 'rien_saisi'
              : 'saisi_non_valide'
        };
      });

      // Regroupement PAR ENSEIGNANT : c'est la vue qui permet d'écrire un
      // message utile, plutôt qu'une liste de cours orpheline.
      const parEnseignant = new Map();
      for (const l of lignes) {
        for (const e of l.enseignants) {
          if (!parEnseignant.has(e.id)) {
            parEnseignant.set(e.id, { ...e, cours: [] });
          }
          parEnseignant.get(e.id).cours.push(`${l.cours_nom} — ${l.classe_nom}`);
        }
      }

      const sansEnseignant = lignes.filter((l) => l.etat === 'sans_enseignant');

      return {
        periode: {
          id: p.id, libelle: p.libelle, type: p.type, numero: p.numero,
          cloturee: p.cloturee, cloturee_at: p.cloturee_at,
          cloturee_par_nom: p.cloturee_par_nom,
          annee_libelle: p.annee_libelle, annee_cloturee: p.annee_cloturee
        },
        prete: lignes.length === 0,
        manquants: lignes,
        // Un cours sans enseignant affecté ne se règle pas par un message :
        // c'est un défaut de configuration, il faut l'affecter.
        sans_enseignant: sansEnseignant.map((l) => `${l.cours_nom} — ${l.classe_nom}`),
        enseignants_a_relancer: [...parEnseignant.values()],
        resume: {
          nb_cours_manquants: lignes.length,
          nb_rien_saisi: lignes.filter((l) => l.etat === 'rien_saisi').length,
          nb_saisi_non_valide: lignes.filter((l) => l.etat === 'saisi_non_valide').length,
          nb_sans_enseignant: sansEnseignant.length,
          nb_enseignants_concernes: parEnseignant.size
        }
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur état clôture:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /periodes/:id/cloturer
 * body : { confirmer: true, malgre_reserves?: boolean }
 *
 * Après clôture, plus personne n'écrit dans cette période — professeur comme
 * direction. C'est le geste qui fait passer l'école à la période suivante.
 */
async function cloturerPeriode(req, res) {
  const { id } = req.params;
  const { confirmer, malgre_reserves } = req.body;

  // Confirmation exigée côté serveur, pas seulement à l'écran : une opération
  // irréversible ne doit pas pouvoir être déclenchée par un appel direct.
  if (confirmer !== true) {
    return res.status(400).json({
      message: "Confirmation requise : la clôture empêche toute saisie ultérieure sur cette période."
    });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const p = await client.query(
        `SELECT p.id, p.libelle, p.cloturee, p.annee_scolaire_id, a.cloturee AS annee_cloturee
           FROM periodes p JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
          WHERE p.id = $1 AND p.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (p.rows.length === 0) {
        throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
      }
      if (p.rows[0].cloturee) {
        throw Object.assign(
          new Error(`« ${p.rows[0].libelle} » est déjà clôturée.`), { statusCode: 409 }
        );
      }

      const manquants = await client.query(
        `SELECT cl.nom AS classe_nom, co.nom AS cours_nom
           FROM classe_cours cc
           JOIN classes cl ON cl.id = cc.classe_id
           JOIN cours co ON co.id = cc.cours_id
          WHERE cc.ecole_id = ${CURRENT_ECOLE} AND cl.annee_scolaire_id = $2
            AND NOT EXISTS (
              SELECT 1 FROM notes n
               WHERE n.classe_cours_id = cc.id AND n.periode_id = $1 AND n.valide = true
            )`,
        [id, p.rows[0].annee_scolaire_id]
      );

      // Clôturer malgré des manques reste possible — une école doit pouvoir
      // avancer même si un enseignant est absent — mais c'est un acte séparé,
      // qui se déclare.
      if (manquants.rows.length > 0 && malgre_reserves !== true) {
        throw Object.assign(
          Object.assign(
            new Error(
              `${manquants.rows.length} cours n'ont pas leurs notes validées. `
              + `Relancez les enseignants concernés, ou clôturez en le déclarant `
              + `explicitement — la liste sera conservée.`
            ),
            { statusCode: 409 }
          ),
          { reserves: manquants.rows }
        );
      }

      const reserves = manquants.rows.length > 0
        ? { nb: manquants.rows.length, cours: manquants.rows.slice(0, 200) }
        : null;

      await client.query(
        `UPDATE periodes
            SET cloturee = true, cloturee_at = now(), cloturee_par = $2,
                cloture_reserves = $3::jsonb
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id, req.auth.userId, reserves ? JSON.stringify(reserves) : null]
      );

      return { libelle: p.rows[0].libelle, nbReserves: manquants.rows.length };
    });

    let message = `Période « ${resultat.libelle} » clôturée. Plus aucune note ne peut y être saisie.`;
    if (resultat.nbReserves > 0) {
      message += ` ${resultat.nbReserves} cours restaient non validés : la liste est conservée avec la clôture.`;
    }
    return res.json({ message });
  } catch (err) {
    if (err.statusCode) {
      return res.status(err.statusCode).json({ message: err.message, reserves: err.reserves });
    }
    console.error('Erreur clôture période:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /periodes/:id/rouvrir
 *
 * Rouvrir est possible mais reste une exception : une erreur de clôture ne doit
 * pas figer une école pour l'année. L'opération est tracée par la
 * journalisation automatique.
 */
async function rouvrirPeriode(req, res) {
  const { id } = req.params;
  try {
    const libelle = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `UPDATE periodes SET cloturee = false, cloturee_at = NULL, cloturee_par = NULL
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND cloturee = true
          RETURNING libelle`,
        [id]
      );
      if (r.rows.length === 0) {
        throw Object.assign(
          new Error("Période introuvable ou déjà ouverte."), { statusCode: 404 }
        );
      }
      return r.rows[0].libelle;
    });
    return res.json({
      message: `Période « ${libelle} » rouverte. La saisie y est de nouveau possible.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur réouverture période:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { etatCloture, cloturerPeriode, rouvrirPeriode };
