const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { envoyerEmail } = require('../utils/email.utils');
const { emailWrapper, echapper } = require('../utils/email-template');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const ROLES_DIFFUSABLES = ['directeur', 'prefet', 'secretaire', 'professeur', 'titulaire', 'comptable'];
const CANAUX = ['interne', 'email'];

const LIMITE_DESTINATAIRES = 500;

/** Rôles qui peuvent viser N'IMPORTE QUEL groupe : c'est un acte d'établissement. */
function peutToutDiffuser(auth) {
  return auth.isSuperAdmin
    || (auth.roles || []).some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
}

/**
 * Les classes dont une personne a la charge — titulariat, ou cours enseigné.
 *
 * POURQUOI CETTE REQUÊTE EXISTE
 * -----------------------------
 * Un titulaire ne pouvait pas écrire aux parents de sa propre classe. Il
 * devait demander au secrétariat de diffuser à sa place, ou téléphoner un par
 * un. Dans les faits, il ne prévenait personne.
 *
 * Ouvrir « les parents d'une classe » à tout le personnel serait excessif :
 * un professeur de 6e n'a rien à écrire aux parents de 2e. La limite naturelle
 * est celle du travail réel — les classes où l'on est titulaire, et celles où
 * l'on enseigne. Elle est calculée ici, côté serveur, et jamais déduite de ce
 * que le navigateur affirme.
 */
async function classesDeLEnseignant(client, userId) {
  const r = await client.query(
    `SELECT DISTINCT c.id, c.nom
       FROM classes c
      WHERE c.ecole_id = ${CURRENT_ECOLE}
        AND (
          c.titulaire_id = $1
          OR c.id IN (
            SELECT cc.classe_id
              FROM classe_cours cc
              JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
             WHERE ec.utilisateur_id = $1
          )
        )
      ORDER BY c.nom`,
    [userId]
  );
  return r.rows;
}

/**
 * GET /communication/destinataires
 * Groupes disponibles et leur taille, pour que l'expéditeur sache
 * exactement combien de personnes il s'apprête à toucher.
 */
async function destinataires(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Un enseignant n'a pas à connaître la composition du personnel par
      // rôle ni l'effectif de classes qui ne sont pas les siennes. Il reçoit
      // la seule chose dont il a besoin : la liste de SES classes.
      if (!peutToutDiffuser(req.auth)) {
        const miennes = await classesDeLEnseignant(client, req.auth.userId);
        const ids = miennes.map((c) => c.id);
        const compte = ids.length
          ? await client.query(
              `SELECT e.classe_id,
                      count(*) FILTER (WHERE e.statut = 'actif') AS nb_eleves,
                      count(*) FILTER (WHERE e.statut = 'actif'
                        AND e.responsable_email IS NOT NULL AND e.responsable_email <> '')
                        AS nb_parents_email
                 FROM eleves e
                WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.classe_id = ANY($1::uuid[])
                GROUP BY e.classe_id`,
              [ids]
            )
          : { rows: [] };
        const parId = {};
        compte.rows.forEach((l) => { parId[l.classe_id] = l; });
        return {
          roles: [],
          classes: miennes.map((c) => ({
            id: c.id, nom: c.nom,
            nb_eleves: Number(parId[c.id] ? parId[c.id].nb_eleves : 0),
            nb_parents_email: Number(parId[c.id] ? parId[c.id].nb_parents_email : 0),
            nb_enseignants: 0
          })),
          // L'interface s'en sert pour n'afficher que ce qui est réellement
          // permis, plutôt que de proposer un choix qui sera refusé ensuite.
          portee: 'mes_classes'
        };
      }

      const parRole = await client.query(
        `SELECT ur.role::text AS role,
                count(DISTINCT u.id) AS nb,
                count(DISTINCT u.id) FILTER (WHERE u.email IS NOT NULL AND u.email <> '') AS nb_email
         FROM utilisateur_roles ur
         JOIN utilisateurs u ON u.id = ur.utilisateur_id
         WHERE u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
         GROUP BY ur.role
         ORDER BY ur.role`
      );

      const anneeResult = await client.query(
        `SELECT id FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
      );
      const anneeId = anneeResult.rows[0]?.id || null;

      const parClasse = anneeId ? await client.query(
        `SELECT c.id, c.nom,
                (SELECT count(*) FROM eleves e
                  WHERE e.classe_id = c.id AND e.statut = 'actif') AS nb_eleves,
                (SELECT count(*) FROM eleves e
                  WHERE e.classe_id = c.id AND e.statut = 'actif'
                    AND e.responsable_email IS NOT NULL AND e.responsable_email <> '') AS nb_parents_email,
                (SELECT count(DISTINCT ec.utilisateur_id)
                   FROM classe_cours cc
                   JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
                  WHERE cc.classe_id = c.id) AS nb_enseignants
         FROM classes c
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
         ORDER BY c.nom`,
        [anneeId]
      ) : { rows: [] };

      return {
        portee: 'ecole',
        roles: parRole.rows
          .filter((r) => ROLES_DIFFUSABLES.includes(r.role))
          .map((r) => ({ role: r.role, nb: Number(r.nb), nb_email: Number(r.nb_email) })),
        classes: parClasse.rows.map((c) => ({
          id: c.id, nom: c.nom,
          nb_eleves: Number(c.nb_eleves),
          nb_parents_email: Number(c.nb_parents_email),
          nb_enseignants: Number(c.nb_enseignants)
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur destinataires:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /communication/envoyer
 * body: { cible: { type, roles?, classe_id? }, sujet, contenu, canaux: [] }
 *
 * Deux publics très différents :
 *   · le personnel, qui a un compte → message interne, et courriel en option ;
 *   · les parents, qui n'en ont pas → courriel uniquement, à l'adresse du
 *     responsable enregistrée sur la fiche de l'élève.
 */
async function envoyer(req, res) {
  const { cible, sujet, contenu, canaux } = req.body;

  if (!sujet || !String(sujet).trim()) {
    return res.status(400).json({ message: "L'objet du message est requis." });
  }
  if (!contenu || !String(contenu).trim()) {
    return res.status(400).json({ message: 'Le contenu du message est requis.' });
  }
  if (String(sujet).length > 200) {
    return res.status(400).json({ message: "L'objet ne peut pas dépasser 200 caractères." });
  }
  if (String(contenu).length > 5000) {
    return res.status(400).json({ message: 'Le message ne peut pas dépasser 5000 caractères.' });
  }
  if (!cible || !cible.type) {
    return res.status(400).json({ message: 'Choisissez des destinataires.' });
  }

  const canauxRetenus = (Array.isArray(canaux) ? canaux : []).filter((c) => CANAUX.includes(c));
  if (canauxRetenus.length === 0) {
    return res.status(400).json({ message: 'Choisissez au moins un canal d\'envoi.' });
  }

  const objet = String(sujet).trim();
  const texte = String(contenu).trim();

  /* ------------------------------------------------------------------
     TROIS NIVEAUX, ET NON DEUX

     Le contrôle était binaire : direction, ou rien. Un titulaire ne pouvait
     donc pas prévenir les parents de sa propre classe — le geste le plus
     ordinaire de son métier. On distingue désormais :

       · écrire à des personnes précises   → tout le personnel
       · écrire à une classe dont on a la  → l'enseignant concerné,
         charge (parents, équipe)            vérifié en base
       · diffuser à un rôle, à toute        → direction et secrétariat
         l'école, à tous les parents

     La vérification du deuxième niveau est faite plus bas, une fois la
     classe connue : elle exige une requête, et refuser ici sur la foi du
     seul type de cible reviendrait à refuser au titulaire sa propre classe.
     ------------------------------------------------------------------ */
  const peutDiffuser = peutToutDiffuser(req.auth);

  // Ce qu'un enseignant peut viser sans être de la direction : sa classe.
  const CIBLES_ENSEIGNANT = ['parents_classe', 'equipe_classe'];

  if (cible.type !== 'utilisateurs' && !peutDiffuser
      && !CIBLES_ENSEIGNANT.includes(cible.type)) {
    return res.status(403).json({
      message: "Vous pouvez écrire à des personnes précises, ou aux parents d'une classe "
        + "dont vous avez la charge. La diffusion à un rôle entier ou à toute l'école "
        + "est réservée à la direction et au secrétariat."
    });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      let utilisateurs = [];   // { id, email }
      let parents = [];        // { email, eleve }
      let libelleCible = '';

      // Deuxième niveau d'autorisation : la classe visée est-elle bien une
      // classe de cette personne ? La question ne se pose que pour un
      // enseignant — la direction voit toutes les classes.
      if (!peutDiffuser && CIBLES_ENSEIGNANT.includes(cible.type)) {
        if (!cible.classe_id) {
          throw Object.assign(new Error('Choisissez une classe.'), { statusCode: 400 });
        }
        const miennes = await classesDeLEnseignant(client, req.auth.userId);
        if (!miennes.some((c) => c.id === cible.classe_id)) {
          throw Object.assign(
            new Error("Vous ne pouvez écrire qu'aux classes dont vous êtes titulaire "
              + 'ou dans lesquelles vous enseignez.'),
            { statusCode: 403 }
          );
        }
      }

      if (cible.type === 'roles') {
        const roles = (cible.roles || []).filter((r) => ROLES_DIFFUSABLES.includes(r));
        if (roles.length === 0) {
          throw Object.assign(new Error('Aucun rôle valide sélectionné.'), { statusCode: 400 });
        }
        const r = await client.query(
          `SELECT DISTINCT u.id, u.email
           FROM utilisateurs u
           JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
           WHERE u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
             AND ur.role::text = ANY($1::text[])`,
          [roles]
        );
        utilisateurs = r.rows;
        libelleCible = `rôles : ${roles.join(', ')}`;

      } else if (cible.type === 'equipe_classe') {
        if (!cible.classe_id) {
          throw Object.assign(new Error('Choisissez une classe.'), { statusCode: 400 });
        }
        // Titulaire de la classe et tous les professeurs qui y enseignent.
        const r = await client.query(
          `SELECT DISTINCT u.id, u.email
           FROM utilisateurs u
           WHERE u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
             AND (
               u.id = (SELECT titulaire_id FROM classes WHERE id = $1)
               OR u.id IN (
                 SELECT ec.utilisateur_id FROM classe_cours cc
                 JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
                 WHERE cc.classe_id = $1
               )
             )`,
          [cible.classe_id]
        );
        utilisateurs = r.rows;
        const nom = await client.query(`SELECT nom FROM classes WHERE id = $1`, [cible.classe_id]);
        libelleCible = `équipe de la classe ${nom.rows[0]?.nom || ''}`;

      } else if (cible.type === 'parents_classe' || cible.type === 'parents_ecole') {
        // Garde-fou : sans classe, le paramètre `$1` valait NULL et la
        // condition « ($1 IS NULL OR classe_id = $1) » devenait toujours
        // vraie — un envoi « parents d'une classe » sans classe partait donc
        // silencieusement à TOUTE l'école. Ce n'était atteignable que par la
        // direction, mais une diffusion de cette ampleur ne doit jamais être
        // le résultat d'un champ oublié.
        if (cible.type === 'parents_classe' && !cible.classe_id) {
          throw Object.assign(new Error('Choisissez une classe.'), { statusCode: 400 });
        }
        const r = await client.query(
          `SELECT e.responsable_email AS email,
                  trim(concat(e.nom, ' ', COALESCE(e.postnom, ''))) AS eleve
           FROM eleves e
           JOIN classes c ON c.id = e.classe_id
           WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif'
             AND e.responsable_email IS NOT NULL AND e.responsable_email <> ''
             AND ($1::uuid IS NULL OR e.classe_id = $1::uuid)`,
          [cible.type === 'parents_classe' ? (cible.classe_id || null) : null]
        );
        parents = r.rows;
        if (cible.type === 'parents_classe') {
          // Le nom de la classe, et non « parents d'une classe » : l'historique
          // des envois devient illisible dès qu'on en a diffusé trois.
          const nom = await client.query('SELECT nom FROM classes WHERE id = $1',
                                         [cible.classe_id || null]);
          libelleCible = `parents de ${nom.rows[0] ? nom.rows[0].nom : 'la classe'}`;
        } else {
          libelleCible = "parents de toute l'école";
        }

        // Les parents n'ont pas de compte : un message interne ne leur
        // parviendrait jamais. On force donc le courriel.
        if (!canauxRetenus.includes('email')) {
          throw Object.assign(
            new Error("Les parents n'ont pas de compte sur la plateforme : le courriel est le seul canal possible."),
            { statusCode: 400 }
          );
        }
      } else if (cible.type === 'utilisateurs') {
        // ---------- Envoi à des personnes précises ----------
        // Il n'était possible d'écrire qu'à un GROUPE : tout un rôle, toute une
        // classe. Écrire à un seul enseignant obligeait à diffuser à tout le
        // corps enseignant — ce que personne ne fait, donc on n'écrivait pas.
        //
        // C'est aussi ce qui permet la communication entre enseignants, et la
        // relance nominative depuis la clôture de période.
        const ids = (cible.utilisateurs || []).filter(Boolean);
        if (ids.length === 0) {
          throw Object.assign(new Error('Choisissez au moins une personne.'), { statusCode: 400 });
        }
        const r = await client.query(
          `SELECT u.id, u.email, trim(concat(u.prenom, ' ', u.nom)) AS nom
             FROM utilisateurs u
            WHERE u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
              AND u.id = ANY($1::uuid[])`,
          [ids]
        );
        // Un identifiant qui ne correspond à personne de l'école est écarté
        // sans bruit par le filtre `ecole_id` : le décompte renvoyé dira
        // combien de destinataires ont réellement été retenus.
        utilisateurs = r.rows;
        libelleCible = r.rows.length === 1
          ? r.rows[0].nom
          : `${r.rows.length} personne(s)`;

      } else {
        throw Object.assign(new Error('Type de destinataires inconnu.'), { statusCode: 400 });
      }

      const total = utilisateurs.length + parents.length;
      if (total === 0) {
        throw Object.assign(
          new Error('Aucun destinataire ne correspond à cette sélection.'),
          { statusCode: 400 }
        );
      }
      if (total > LIMITE_DESTINATAIRES) {
        throw Object.assign(
          new Error(`Trop de destinataires (${total}). Découpez votre envoi en groupes de ${LIMITE_DESTINATAIRES} au maximum.`),
          { statusCode: 400 }
        );
      }

      // ---------- Canal interne ----------
      let nbInternes = 0;
      if (canauxRetenus.includes('interne') && utilisateurs.length > 0) {
        for (const u of utilisateurs) {
          await client.query(
            // L'expéditeur est enregistré : un message anonyme ne se répond
            // pas, et le destinataire doit savoir si le préfet lui écrit ou si
            // c'est la plateforme qui l'avertit.
            `INSERT INTO notifications (ecole_id, utilisateur_id, canal, sujet, contenu, statut, lu, expediteur_id)
             VALUES (${CURRENT_ECOLE}, $1, 'interne', $2, $3, 'envoye', false, $4)`,
            [u.id, objet, texte, req.auth.userId]
          );
          nbInternes++;
        }
      }

      // ---------- Canal courriel ----------
      // L'envoi est tenté hors transaction critique : un échec de Resend ne
      // doit pas annuler les messages internes déjà écrits.
      const adresses = [
        ...utilisateurs.map((u) => u.email),
        ...parents.map((p) => p.email)
      ].filter((e) => e && String(e).includes('@'));

      let nbEmails = 0;
      let nbEchecs = 0;
      if (canauxRetenus.includes('email')) {
        const corpsHtml = emailWrapper({
          type: 'message',
          titre: objet,
          preheader: texte.slice(0, 120),
          contenuHtml: `<div style="white-space:pre-wrap;">${echapper(texte)}</div>
            <p style="font-size:12px;color:#6B7269;margin:22px 0 0;">
            Message envoyé via Ardoise. Merci de ne pas répondre à cet e-mail.</p>`
        });

        for (const adresse of adresses) {
          const resultat = await envoyerEmail({ to: adresse, subject: objet, html: corpsHtml });
          if (resultat && resultat.envoye) nbEmails++; else nbEchecs++;
        }
      }

      // ---------- Trace de l'envoi ----------
      await client.query(
        `INSERT INTO messages_envoyes
           (ecole_id, expediteur_id, sujet, contenu, cible_type, cible_libelle,
            canaux, nb_destinataires, nb_internes, nb_emails, nb_echecs)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [req.auth.userId, objet, texte, cible.type, libelleCible,
         canauxRetenus.join(','), total, nbInternes, nbEmails, nbEchecs]
      );

      return { total, nbInternes, nbEmails, nbEchecs, sansEmail: total - adresses.length };
    });

    const morceaux = [];
    if (bilan.nbInternes > 0) morceaux.push(`${bilan.nbInternes} message(s) interne(s)`);
    if (bilan.nbEmails > 0) morceaux.push(`${bilan.nbEmails} courriel(s)`);
    let message = morceaux.length
      ? `Envoi effectué : ${morceaux.join(' et ')}.`
      : 'Envoi enregistré.';
    if (bilan.nbEchecs > 0) {
      message += ` ${bilan.nbEchecs} courriel(s) n'ont pas pu partir — vérifiez la configuration Resend.`;
    }
    if (bilan.sansEmail > 0) {
      message += ` ${bilan.sansEmail} destinataire(s) n'ont aucune adresse enregistrée.`;
    }

    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur envoi communication:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /communication/historique */

/**
 * GET /communication/personnel
 *
 * Les personnes joignables une par une. Séparé de `/destinataires`, qui ne
 * renvoie que des GROUPES (rôles, classes) : écrire à quelqu'un et diffuser à
 * un corps ne sont pas le même geste, et mélanger les deux dans une liste
 * rendrait le choix confus.
 */
async function personnel(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT u.id, trim(concat(u.prenom, ' ', u.nom)) AS nom, u.email,
                COALESCE(
                  (SELECT string_agg(DISTINCT ur.role::text, ', ' ORDER BY ur.role::text)
                     FROM utilisateur_roles ur WHERE ur.utilisateur_id = u.id), ''
                ) AS roles
           FROM utilisateurs u
          WHERE u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
            AND u.id <> $1
          ORDER BY u.nom, u.prenom`,
        [req.auth.userId]
      );
      // On s'exclut de sa propre liste : s'écrire à soi-même n'a pas d'usage,
      // et l'option occupe une place dans un menu déjà long.
      return r.rows;
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste personnel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function historique(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT m.id, m.sujet, m.contenu, m.cible_type, m.cible_libelle, m.canaux,
                m.nb_destinataires, m.nb_internes, m.nb_emails, m.nb_echecs, m.created_at,
                trim(concat(u.prenom, ' ', u.nom)) AS expediteur
         FROM messages_envoyes m
         LEFT JOIN utilisateurs u ON u.id = m.expediteur_id
         WHERE m.ecole_id = ${CURRENT_ECOLE}
         ORDER BY m.created_at DESC
         LIMIT 100`
      )
    );
    return res.json(result.rows.map((l) => ({
      ...l,
      nb_destinataires: Number(l.nb_destinataires),
      nb_internes: Number(l.nb_internes),
      nb_emails: Number(l.nb_emails),
      nb_echecs: Number(l.nb_echecs)
    })));
  } catch (err) {
    console.error('Erreur historique communication:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { destinataires, envoyer, historique, personnel };
