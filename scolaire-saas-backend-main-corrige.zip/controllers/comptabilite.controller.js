const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { lireConfigMonetaire, sqlPaiementConverti } = require('../utils/devise.utils');
const { anneeActive } = require('../utils/annee.utils');
const {
  notifierEvenement, destinatairesParRole, planifierVidage
} = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  COMPTABILITÉ — caisse, charges, paie
 * ===========================================================================
 *
 * LA QUESTION À LAQUELLE CE MODULE RÉPOND
 * ---------------------------------------
 * La plateforme savait ce qui entre, jamais ce qui sort. Un comptable pouvait
 * dire combien l'école avait encaissé, jamais combien il lui restait — or c'est
 * la seule question du quotidien : « puis-je payer les enseignants ce mois-ci ? »
 *
 * UN SEUL FLUX, DEUX SOURCES
 * --------------------------
 *   solde = Σ paiements_frais + Σ mouvements(entrée) − Σ mouvements(sortie)
 *
 * Les paiements de frais restent dans leur table ; les autres recettes et
 * TOUTES les sorties passent par `mouvements_caisse`. Recopier chaque paiement
 * de frais dans une seconde table ferait compter l'argent deux fois dès qu'une
 * synchronisation serait oubliée.
 *
 * CE QUI REND LA CAISSE COHÉRENTE
 * -------------------------------
 * Payer un salaire CRÉE un mouvement de sortie, dans la même transaction.
 * Le salaire ne se contente pas d'être marqué payé : l'argent quitte
 * réellement la caisse. Annuler le paiement supprime le mouvement.
 *
 * CONVERSION
 * ----------
 * Tout est ramené à la devise principale de l'école pour être additionné.
 * Chaque mouvement garde le taux du jour où il a eu lieu : recalculer avec le
 * taux courant réécrirait l'histoire — une dépense de 100 $ faite à 2 500 FC ne
 * devient pas 2 900 FC parce que le dollar a monté depuis.
 */

/** Conversion d'un mouvement vers la devise de référence. */
function sqlMouvementConverti(alias, deviseParam, tauxIndex) {
  return `CASE
    WHEN ${alias}.devise = ${deviseParam} THEN ${alias}.montant
    WHEN ${alias}.devise = 'USD' THEN ${alias}.montant * COALESCE(${alias}.taux_change, $${tauxIndex})
    ELSE ${alias}.montant / NULLIF(COALESCE(${alias}.taux_change, $${tauxIndex}), 0)
  END`;
}

/**
 * Un mouvement en devise étrangère sans taux connu est INCALCULABLE.
 * On refuse plutôt que de l'ignorer : une dépense qui disparaît du total est
 * pire qu'un message d'erreur, parce que le solde paraît juste.
 */
function exigerTaux(devise, deviseEcole, taux) {
  if (devise !== deviseEcole && !taux) {
    throw Object.assign(
      new Error(
        `Aucun taux de change enregistré : un montant en ${devise} ne peut pas être `
        + `converti en ${deviseEcole}. Renseignez le taux dans Paramètres › Devise.`
      ),
      { statusCode: 409 }
    );
  }
}

// ---------------------------------------------------------------------------
//  Catégories
// ---------------------------------------------------------------------------

async function listerCategories(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT c.id, c.nom, c.sens, c.ordre, c.actif,
                (SELECT count(*) FROM mouvements_caisse m WHERE m.categorie_id = c.id) AS nb_mouvements
           FROM categories_financieres c
          WHERE c.ecole_id = ${CURRENT_ECOLE}
          ORDER BY c.sens, c.ordre, c.nom`
      );
      return r.rows.map((c) => ({ ...c, nb_mouvements: Number(c.nb_mouvements) }));
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste catégories:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerCategorie(req, res) {
  const { nom, sens, ordre } = req.body;
  if (!nom || !String(nom).trim()) {
    return res.status(400).json({ message: 'Le nom de la catégorie est requis.' });
  }
  if (!['entree', 'sortie'].includes(sens)) {
    return res.status(400).json({ message: "Sens invalide : « entree » ou « sortie »." });
  }

  try {
    const id = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const doublon = await client.query(
        `SELECT id FROM categories_financieres
          WHERE ecole_id = ${CURRENT_ECOLE} AND sens = $2
            AND lower(btrim(nom)) = lower(btrim($1))`,
        [String(nom).trim(), sens]
      );
      if (doublon.rows.length > 0) {
        throw Object.assign(
          new Error(`La catégorie « ${String(nom).trim()} » existe déjà.`), { statusCode: 409 }
        );
      }
      const r = await client.query(
        `INSERT INTO categories_financieres (ecole_id, nom, sens, ordre)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3) RETURNING id`,
        [String(nom).trim(), sens, Number.isFinite(Number(ordre)) ? Number(ordre) : 0]
      );
      return r.rows[0].id;
    });
    return res.status(201).json({ id, message: 'Catégorie créée.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création catégorie:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function modifierCategorie(req, res) {
  const { id } = req.params;
  const { nom, ordre, actif } = req.body;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE categories_financieres
            SET nom = COALESCE(NULLIF(btrim($2), ''), nom),
                ordre = COALESCE($3, ordre),
                actif = COALESCE($4, actif)
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id, nom || null,
         Number.isFinite(Number(ordre)) ? Number(ordre) : null,
         typeof actif === 'boolean' ? actif : null]
      )
    );
    return res.json({ message: 'Catégorie mise à jour.' });
  } catch (err) {
    console.error('Erreur modification catégorie:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------------------------------------------------------------------------
//  Mouvements de caisse
// ---------------------------------------------------------------------------

async function listerMouvements(req, res) {
  const { depuis, jusqu, sens, categorieId, recherche } = req.query;
  const limite = Math.min(Math.max(parseInt(req.query.limit, 10) || 100, 1), 500);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      const conditions = [`m.ecole_id = ${CURRENT_ECOLE}`];
      const params = [devise, taux || null];

      if (depuis) { params.push(depuis); conditions.push(`m.date_mouvement >= $${params.length}::date`); }
      if (jusqu) { params.push(jusqu); conditions.push(`m.date_mouvement <= $${params.length}::date`); }
      if (['entree', 'sortie'].includes(sens)) { params.push(sens); conditions.push(`m.sens = $${params.length}`); }
      if (categorieId) { params.push(categorieId); conditions.push(`m.categorie_id = $${params.length}::uuid`); }
      if (recherche && String(recherche).trim()) {
        params.push(`%${String(recherche).trim()}%`);
        conditions.push(`(m.libelle ILIKE $${params.length} OR coalesce(m.beneficiaire,'') ILIKE $${params.length}
                          OR coalesce(m.reference,'') ILIKE $${params.length})`);
      }

      params.push(limite);
      const r = await client.query(
        `SELECT m.id, m.sens, m.libelle, m.montant, m.devise, m.taux_change,
                m.date_mouvement, m.mode_paiement, m.beneficiaire, m.reference,
                m.piece_url, m.salaire_id,
                ${sqlMouvementConverti('m', '$1', 2)} AS montant_converti,
                c.nom AS categorie_nom, c.id AS categorie_id,
                trim(concat(u.prenom, ' ', u.nom)) AS enregistre_par_nom
           FROM mouvements_caisse m
           LEFT JOIN categories_financieres c ON c.id = m.categorie_id
           LEFT JOIN utilisateurs u ON u.id = m.enregistre_par
          WHERE ${conditions.join(' AND ')}
          ORDER BY m.date_mouvement DESC, m.created_at DESC
          LIMIT $${params.length}`,
        params
      );

      return {
        devise,
        mouvements: r.rows.map((m) => ({
          ...m,
          montant: Number(m.montant),
          montant_converti: m.montant_converti === null ? null : Math.round(Number(m.montant_converti) * 100) / 100,
          // Un mouvement dont la conversion est impossible est SIGNALÉ, jamais
          // écarté du total en silence.
          conversion_impossible: m.montant_converti === null,
          // Un mouvement issu d'un salaire ne se modifie pas à la main : il
          // suit le paiement qui l'a créé.
          automatique: !!m.salaire_id
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste mouvements:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


async function modifierMouvement(req, res) {
  const { id } = req.params;
  const { libelle, beneficiaire, date_mouvement, categorie_id } = req.body;

  if (libelle !== undefined && !String(libelle).trim()) {
    return res.status(400).json({ message: 'Le libellé ne peut pas être vide.' });
  }
  if (date_mouvement && !/^\d{4}-\d{2}-\d{2}$/.test(String(date_mouvement))) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const m = await client.query(
        `SELECT sens, salaire_id FROM mouvements_caisse
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (m.rows.length === 0) {
        throw Object.assign(new Error('Mouvement introuvable.'), { statusCode: 404 });
      }
      if (m.rows[0].salaire_id) {
        throw Object.assign(
          new Error("Ce mouvement est lié à un salaire : modifiez-le depuis l'onglet Paie."),
          { statusCode: 409 }
        );
      }

      // Vérifier que la catégorie correspond au sens si elle change
      if (categorie_id) {
        const cat = await client.query(
          `SELECT sens FROM categories_financieres
            WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [categorie_id]
        );
        if (cat.rows.length === 0) {
          throw Object.assign(new Error('Catégorie introuvable.'), { statusCode: 400 });
        }
        if (cat.rows[0].sens !== m.rows[0].sens) {
          throw Object.assign(
            new Error('La catégorie choisie ne correspond pas au sens du mouvement.'),
            { statusCode: 400 }
          );
        }
      }

      await client.query(
        `UPDATE mouvements_caisse
            SET libelle          = COALESCE(NULLIF(btrim($2), ''), libelle),
                beneficiaire     = CASE WHEN $3::text IS NOT NULL THEN NULLIF(btrim($3), '') ELSE beneficiaire END,
                date_mouvement   = COALESCE($4::date, date_mouvement),
                categorie_id     = CASE WHEN $5::uuid IS NOT NULL THEN $5::uuid ELSE categorie_id END
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id,
         libelle ? String(libelle).trim() : null,
         beneficiaire !== undefined ? String(beneficiaire) : null,
         date_mouvement || null,
         categorie_id || null]
      );
    });
    return res.json({ message: 'Mouvement mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification mouvement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function enregistrerMouvement(req, res) {
  const { sens, categorie_id, libelle, montant, devise, date_mouvement,
          mode_paiement, beneficiaire, reference, piece_url } = req.body;

  if (!['entree', 'sortie'].includes(sens)) {
    return res.status(400).json({ message: "Précisez s'il s'agit d'une entrée ou d'une sortie." });
  }
  if (!libelle || !String(libelle).trim()) {
    return res.status(400).json({ message: 'Le libellé est requis : un mouvement sans objet est intraçable.' });
  }
  const montantNum = Number(montant);
  if (!Number.isFinite(montantNum) || montantNum <= 0) {
    return res.status(400).json({ message: 'Le montant doit être un nombre strictement positif.' });
  }
  if (date_mouvement && !/^\d{4}-\d{2}-\d{2}$/.test(String(date_mouvement))) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { devise_principale: deviseEcole, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
      const deviseRetenue = ['FC', 'USD'].includes(devise) ? devise : deviseEcole;
      exigerTaux(deviseRetenue, deviseEcole, taux);

      // La catégorie doit correspondre au sens : classer une dépense dans
      // « Dons reçus » fausserait tous les états sans qu'aucune erreur
      // n'apparaisse.
      if (categorie_id) {
        const cat = await client.query(
          `SELECT sens, nom FROM categories_financieres
            WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [categorie_id]
        );
        if (cat.rows.length === 0) {
          throw Object.assign(new Error('Catégorie introuvable.'), { statusCode: 400 });
        }
        if (cat.rows[0].sens !== sens) {
          throw Object.assign(
            new Error(
              `« ${cat.rows[0].nom} » est une catégorie de ${cat.rows[0].sens === 'entree' ? 'recette' : 'dépense'} : `
              + `elle ne peut pas recevoir ${sens === 'entree' ? 'une recette' : 'une dépense'} de l'autre sens.`
            ),
            { statusCode: 400 }
          );
        }
      }

      const annee = await anneeActive(client);

      const r = await client.query(
        `INSERT INTO mouvements_caisse
           (ecole_id, annee_scolaire_id, sens, categorie_id, libelle, montant, devise,
            taux_change, date_mouvement, mode_paiement, beneficiaire, reference,
            piece_url, enregistre_par)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,COALESCE($8::date, CURRENT_DATE),$9,$10,$11,$12,$13)
         RETURNING id`,
        [annee ? annee.id : null, sens, categorie_id || null, String(libelle).trim(),
         montantNum, deviseRetenue,
         // Le taux est FIGÉ maintenant : c'est ce qui rend l'historique stable.
         deviseRetenue !== deviseEcole ? taux : null,
         date_mouvement || null, mode_paiement || null,
         beneficiaire ? String(beneficiaire).trim() : null,
         reference ? String(reference).trim() : null,
         piece_url || null, req.auth.userId]
      );
      return r.rows[0].id;
    });

    return res.status(201).json({
      id: resultat,
      message: sens === 'sortie' ? 'Dépense enregistrée.' : 'Recette enregistrée.'
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement mouvement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerMouvement(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const m = await client.query(
        `SELECT salaire_id FROM mouvements_caisse
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (m.rows.length === 0) {
        throw Object.assign(new Error('Mouvement introuvable.'), { statusCode: 404 });
      }
      // Supprimer à la main le mouvement d'un salaire laisserait le salaire
      // marqué « payé » alors que l'argent serait revenu en caisse.
      if (m.rows[0].salaire_id) {
        throw Object.assign(
          new Error(
            "Ce mouvement provient du paiement d'un salaire. Annulez le paiement "
            + "dans l'écran Paie : le mouvement sera retiré avec lui."
          ),
          { statusCode: 409 }
        );
      }
      await client.query(
        `DELETE FROM mouvements_caisse WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
    });
    return res.json({ message: 'Mouvement supprimé.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur suppression mouvement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------------------------------------------------------------------------
//  Tableau de trésorerie
// ---------------------------------------------------------------------------

/**
 * GET /comptabilite/tresorerie?depuis=&jusqu=
 *
 * Entrées, sorties, solde, et la ventilation par catégorie. C'est l'écran que
 * regarde un comptable pour savoir s'il peut engager une dépense.
 */
async function tresorerie(req, res) {
  const { depuis, jusqu } = req.query;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
      const annee = await anneeActive(client);

      const bornes = [];
      const paramsDate = [];
      if (depuis) { paramsDate.push(depuis); bornes.push(`>= $${paramsDate.length}`); }
      if (jusqu) { paramsDate.push(jusqu); bornes.push(`<= $${paramsDate.length}`); }

      // Recettes scolaires : elles vivent dans `paiements_frais`, pas dans les
      // mouvements. Les y recopier ferait compter l'argent deux fois.
      const conditionsFrais = [`p.ecole_id = ${CURRENT_ECOLE}`];
      const paramsFrais = [devise, taux || null];
      if (depuis) { paramsFrais.push(depuis); conditionsFrais.push(`p.date_paiement >= $${paramsFrais.length}::date`); }
      if (jusqu) { paramsFrais.push(jusqu); conditionsFrais.push(`p.date_paiement < $${paramsFrais.length}::date + interval '1 day'`); }

      const frais = await client.query(
        `SELECT COALESCE(SUM(${sqlPaiementConverti('p', '$1', 2)}), 0) AS total,
                count(*) AS nb,
                count(*) FILTER (WHERE p.devise <> $1 AND p.taux_change IS NULL AND $2::numeric IS NULL) AS non_convertibles
           FROM paiements_frais p
          WHERE ${conditionsFrais.join(' AND ')}`,
        paramsFrais
      );

      const conditionsMvt = [`m.ecole_id = ${CURRENT_ECOLE}`];
      const paramsMvt = [devise, taux || null];
      if (depuis) { paramsMvt.push(depuis); conditionsMvt.push(`m.date_mouvement >= $${paramsMvt.length}::date`); }
      if (jusqu) { paramsMvt.push(jusqu); conditionsMvt.push(`m.date_mouvement <= $${paramsMvt.length}::date`); }

      const mouvements = await client.query(
        `SELECT m.sens, c.id AS categorie_id, c.nom AS categorie_nom,
                COALESCE(SUM(${sqlMouvementConverti('m', '$1', 2)}), 0) AS total,
                count(*) AS nb
           FROM mouvements_caisse m
           LEFT JOIN categories_financieres c ON c.id = m.categorie_id
          WHERE ${conditionsMvt.join(' AND ')}
          GROUP BY m.sens, c.id, c.nom
          ORDER BY total DESC`,
        paramsMvt
      );

      const totalFrais = Number(frais.rows[0].total);
      const entreesDiverses = mouvements.rows
        .filter((m) => m.sens === 'entree')
        .reduce((t, m) => t + Number(m.total), 0);
      const sorties = mouvements.rows
        .filter((m) => m.sens === 'sortie')
        .reduce((t, m) => t + Number(m.total), 0);

      const arrondi = (v) => Math.round(v * 100) / 100;

      // Salaires restant à payer : ce n'est pas une sortie effectuée, c'est un
      // engagement. Le montrer à part évite de croire la caisse plus saine
      // qu'elle ne l'est en fin de mois.
      const engagements = await client.query(
        `SELECT COALESCE(SUM(
                  CASE WHEN s.devise = $1 THEN s.montant_net
                       WHEN s.devise = 'USD' THEN s.montant_net * $2
                       ELSE s.montant_net / NULLIF($2, 0) END
                ), 0) AS total, count(*) AS nb
           FROM salaires s
          WHERE s.ecole_id = ${CURRENT_ECOLE} AND s.statut = 'a_payer'`,
        [devise, taux || null]
      );

      return {
        devise,
        periode: { depuis: depuis || null, jusqu: jusqu || null },
        annee: annee ? { id: annee.id, libelle: annee.libelle } : null,
        entrees: {
          frais_scolaires: arrondi(totalFrais),
          nb_paiements: Number(frais.rows[0].nb),
          autres: arrondi(entreesDiverses),
          total: arrondi(totalFrais + entreesDiverses)
        },
        sorties: { total: arrondi(sorties) },
        solde: arrondi(totalFrais + entreesDiverses - sorties),
        engagements: {
          salaires_a_payer: arrondi(Number(engagements.rows[0].total)),
          nb: Number(engagements.rows[0].nb),
          solde_apres_paie: arrondi(totalFrais + entreesDiverses - sorties - Number(engagements.rows[0].total))
        },
        par_categorie: mouvements.rows.map((m) => ({
          sens: m.sens,
          categorie_id: m.categorie_id,
          categorie_nom: m.categorie_nom || 'Sans catégorie',
          total: arrondi(Number(m.total)),
          nb: Number(m.nb)
        })),
        // Signalé plutôt que masqué : un paiement non convertible manque au
        // total, et le comptable doit le savoir.
        alertes: [
          Number(frais.rows[0].non_convertibles) > 0
            ? `${frais.rows[0].non_convertibles} paiement(s) en devise étrangère sans taux : ils manquent au total. Renseignez le taux de change.`
            : null
        ].filter(Boolean)
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur trésorerie:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


// ---------------------------------------------------------------------------
//  Contrats du personnel
// ---------------------------------------------------------------------------

/*
 * Le salaire est attaché au CONTRAT, pas à la personne. Une augmentation ferme
 * l'ancien contrat et en ouvre un nouveau : les bulletins de paie déjà émis
 * gardent le montant qui était le leur, et l'historique reste vrai.
 */

async function listerContrats(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT c.id, c.utilisateur_id, c.poste, c.salaire_base, c.devise,
                c.date_debut, c.date_fin, c.actif,
                trim(concat(u.prenom, ' ', u.nom)) AS personne,
                u.email,
                COALESCE(
                  (SELECT string_agg(ur.role::text, ', ') FROM utilisateur_roles ur
                    WHERE ur.utilisateur_id = u.id), ''
                ) AS roles
           FROM contrats_personnel c
           JOIN utilisateurs u ON u.id = c.utilisateur_id
          WHERE c.ecole_id = ${CURRENT_ECOLE}
          ORDER BY c.actif DESC, u.nom, c.date_debut DESC`
      );
      return r.rows.map((c) => ({ ...c, salaire_base: Number(c.salaire_base) }));
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste contrats:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerContrat(req, res) {
  const { utilisateur_id, poste, salaire_base, devise, date_debut } = req.body;

  if (!utilisateur_id) return res.status(400).json({ message: 'Choisissez la personne concernée.' });
  const salaire = Number(salaire_base);
  if (!Number.isFinite(salaire) || salaire < 0) {
    return res.status(400).json({ message: 'Le salaire de base doit être un nombre positif.' });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { devise_principale: deviseEcole, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
      const deviseRetenue = ['FC', 'USD'].includes(devise) ? devise : deviseEcole;
      exigerTaux(deviseRetenue, deviseEcole, taux);

      const personne = await client.query(
        `SELECT trim(concat(prenom, ' ', nom)) AS nom FROM utilisateurs
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [utilisateur_id]
      );
      if (personne.rows.length === 0) {
        throw Object.assign(new Error('Personne introuvable dans cette école.'), { statusCode: 400 });
      }

      // Un contrat en remplace un autre : deux contrats actifs produiraient
      // deux bulletins de paie le même mois. On ferme l'ancien à la veille du
      // nouveau plutôt que de le supprimer — l'historique de rémunération doit
      // rester lisible.
      const ancien = await client.query(
        `UPDATE contrats_personnel
            SET actif = false,
                date_fin = COALESCE(date_fin, (COALESCE($2::date, CURRENT_DATE) - interval '1 day')::date)
          WHERE utilisateur_id = $1 AND ecole_id = ${CURRENT_ECOLE} AND actif = true
          RETURNING id`,
        [utilisateur_id, date_debut || null]
      );

      await client.query(
        `INSERT INTO contrats_personnel
           (ecole_id, utilisateur_id, poste, salaire_base, devise, date_debut)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, COALESCE($5::date, CURRENT_DATE))`,
        [utilisateur_id, poste ? String(poste).trim() : null, salaire, deviseRetenue, date_debut || null]
      );

      return ancien.rowCount > 0
        ? `Nouveau contrat enregistré pour ${personne.rows[0].nom}. Le précédent est clôturé ; les bulletins de paie déjà émis gardent leur montant.`
        : `Contrat enregistré pour ${personne.rows[0].nom}.`;
    });
    return res.status(201).json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création contrat:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


async function modifierContrat(req, res) {
  const { id } = req.params;
  const { poste, salaire_base, devise } = req.body;
  const salaire = salaire_base !== undefined ? Number(salaire_base) : undefined;

  if (salaire !== undefined && (!Number.isFinite(salaire) || salaire < 0)) {
    return res.status(400).json({ message: 'Le salaire de base doit être un nombre positif.' });
  }

  try {
    const nb = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Vérifier que le contrat appartient bien à cette école et est actif
      const c = await client.query(
        `SELECT id FROM contrats_personnel
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND actif = true`,
        [id]
      );
      if (c.rows.length === 0) {
        throw Object.assign(
          new Error('Contrat introuvable ou déjà clôturé. Seul un contrat actif peut être modifié.'),
          { statusCode: 404 }
        );
      }

      const deviseRetenue = devise
        ? (['FC', 'USD'].includes(devise) ? devise : null)
        : null;

      const r = await client.query(
        `UPDATE contrats_personnel
            SET poste    = COALESCE(NULLIF(btrim($2), ''), poste),
                salaire_base = COALESCE($3, salaire_base),
                devise       = COALESCE($4, devise)
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id,
         poste !== undefined ? String(poste).trim() : null,
         salaire !== undefined ? salaire : null,
         deviseRetenue]
      );
      return r.rowCount;
    });
    return res.json({ message: 'Contrat mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification contrat:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function cloturerContrat(req, res) {
  const { id } = req.params;
  try {
    const nb = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `UPDATE contrats_personnel
            SET actif = false, date_fin = COALESCE(date_fin, CURRENT_DATE)
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND actif = true`,
        [id]
      );
      return r.rowCount;
    });
    if (nb === 0) return res.status(404).json({ message: 'Contrat introuvable ou déjà clôturé.' });
    return res.json({ message: 'Contrat clôturé. La personne ne sera plus incluse dans la paie.' });
  } catch (err) {
    console.error('Erreur clôture contrat:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------------------------------------------------------------------------
//  Paie mensuelle
// ---------------------------------------------------------------------------

const MOIS_VALIDE = /^\d{4}-(0[1-9]|1[0-2])$/;

/**
 * GET /comptabilite/paie?mois=AAAA-MM
 *
 * La paie du mois : ce qui est préparé, ce qui est payé, et le coût total.
 */
async function listerPaie(req, res) {
  const mois = req.query.mois;
  if (!mois || !MOIS_VALIDE.test(mois)) {
    return res.status(400).json({ message: 'Précisez le mois au format AAAA-MM.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      const r = await client.query(
        `SELECT s.id, s.utilisateur_id, s.mois, s.montant_base, s.primes, s.retenues,
                s.montant_net, s.devise, s.statut, s.date_paiement, s.note,
                trim(concat(u.prenom, ' ', u.nom)) AS personne,
                c.poste,
                CASE WHEN s.devise = $1 THEN s.montant_net
                     WHEN s.devise = 'USD' THEN s.montant_net * $2
                     ELSE s.montant_net / NULLIF($2, 0) END AS net_converti
           FROM salaires s
           JOIN utilisateurs u ON u.id = s.utilisateur_id
           LEFT JOIN contrats_personnel c ON c.id = s.contrat_id
          WHERE s.ecole_id = ${CURRENT_ECOLE} AND s.mois = $3 AND s.statut <> 'annule'
          ORDER BY u.nom, u.prenom`,
        [devise, taux || null, mois]
      );

      const lignes = r.rows.map((s) => ({
        ...s,
        montant_base: Number(s.montant_base), primes: Number(s.primes),
        retenues: Number(s.retenues), montant_net: Number(s.montant_net),
        net_converti: s.net_converti === null ? null : Math.round(Number(s.net_converti) * 100) / 100
      }));

      const arrondi = (v) => Math.round(v * 100) / 100;
      const somme = (f) => arrondi(lignes.filter(f).reduce((t, l) => t + (l.net_converti || 0), 0));

      return {
        mois, devise,
        salaires: lignes,
        resume: {
          nb_personnes: lignes.length,
          nb_payes: lignes.filter((l) => l.statut === 'paye').length,
          total: somme(() => true),
          deja_paye: somme((l) => l.statut === 'paye'),
          reste_a_payer: somme((l) => l.statut === 'a_payer')
        }
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste paie:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /comptabilite/paie/preparer  body: { mois }
 *
 * Crée un bulletin par contrat actif, au montant du contrat. Rejouable : les
 * bulletins déjà créés ne sont pas touchés, sinon relancer la préparation
 * écraserait une prime saisie à la main.
 */
async function preparerPaie(req, res) {
  const { mois } = req.body;
  if (!mois || !MOIS_VALIDE.test(mois)) {
    return res.status(400).json({ message: 'Précisez le mois au format AAAA-MM.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const contrats = await client.query(
        `SELECT c.id, c.utilisateur_id, c.salaire_base, c.devise
           FROM contrats_personnel c
          WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.actif = true`
      );

      let crees = 0, existants = 0;
      for (const c of contrats.rows) {
        const r = await client.query(
          `INSERT INTO salaires
             (ecole_id, contrat_id, utilisateur_id, mois, montant_base, montant_net, devise)
           SELECT ${CURRENT_ECOLE}, $1, $2, $3, $4, $4, $5
            WHERE NOT EXISTS (
              SELECT 1 FROM salaires s
               WHERE s.utilisateur_id = $2 AND s.mois = $3 AND s.statut <> 'annule'
            )
           RETURNING id`,
          [c.id, c.utilisateur_id, mois, Number(c.salaire_base), c.devise]
        );
        if (r.rowCount > 0) crees++; else existants++;
      }

      // Interne seulement : préparer la paie n'est pas la payer. Envoyer un
      // e-mail à ce stade ferait croire aux employés que l'argent est parti.
      if (crees > 0) {
        await notifierEvenement(client, {
          evenement: 'paie.preparee',
          destinataires: await destinatairesParRole(client, ['directeur', 'prefet', 'comptable']),
          expediteurId: req.auth.userId,
          donnees: { mois, crees },
          cleUnicite: `paie_preparee:${mois}`
        });
      }

      return { crees, existants, contrats: contrats.rows.length };
    });

    if (bilan.contrats === 0) {
      return res.status(409).json({
        message: "Aucun contrat actif : déclarez d'abord les contrats du personnel avant de préparer la paie."
      });
    }
    let message = `${bilan.crees} bulletin(s) de paie préparé(s) pour ${mois}.`;
    if (bilan.existants > 0) {
      message += ` ${bilan.existants} existaient déjà et n'ont pas été modifiés.`;
    }
    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur préparation paie:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PUT /comptabilite/paie/:id — primes, retenues, note. */
async function modifierSalaire(req, res) {
  const { id } = req.params;
  const { primes, retenues, note } = req.body;

  const primesNum = primes === undefined ? null : Number(primes);
  const retenuesNum = retenues === undefined ? null : Number(retenues);
  if ((primesNum !== null && (!Number.isFinite(primesNum) || primesNum < 0))
      || (retenuesNum !== null && (!Number.isFinite(retenuesNum) || retenuesNum < 0))) {
    return res.status(400).json({ message: 'Primes et retenues doivent être des nombres positifs.' });
  }

  try {
    const net = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const s = await client.query(
        `SELECT montant_base, primes, retenues, statut FROM salaires
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Bulletin de paie introuvable.'), { statusCode: 404 });
      }
      // Un salaire déjà payé ne se modifie plus : l'argent est sorti, et
      // changer le montant ferait mentir la caisse.
      if (s.rows[0].statut === 'paye') {
        throw Object.assign(
          new Error("Ce salaire est déjà payé. Annulez le paiement avant de le modifier."),
          { statusCode: 409 }
        );
      }

      const base = Number(s.rows[0].montant_base);
      const p = primesNum === null ? Number(s.rows[0].primes) : primesNum;
      const rt = retenuesNum === null ? Number(s.rows[0].retenues) : retenuesNum;
      const montantNet = Math.max(base + p - rt, 0);

      await client.query(
        `UPDATE salaires SET primes = $2, retenues = $3, montant_net = $4,
                             note = COALESCE($5, note)
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id, p, rt, montantNet, note === undefined ? null : (note || null)]
      );
      return montantNet;
    });
    return res.json({ message: `Bulletin mis à jour. Net à payer : ${net}.`, montant_net: net });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification salaire:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /comptabilite/paie/:id/payer
 *
 * LE point qui rend la caisse cohérente : payer crée un mouvement de sortie,
 * dans la même transaction. Le salaire ne se contente pas d'être marqué payé,
 * l'argent quitte réellement la caisse.
 */
async function payerSalaire(req, res) {
  const { id } = req.params;
  const { mode_paiement, date_paiement } = req.body;

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // `FOR UPDATE OF s` verrouille la ligne de paie pour la durée de la
      // transaction. Sans lui, la séquence « je lis le statut, je vérifie
      // qu'il n'est pas déjà payé, j'écris » n'est pas atomique : deux
      // requêtes simultanées — un double-clic, ou deux personnes sur le même
      // bulletin — lisent toutes deux « a_payer », passent toutes deux le
      // contrôle, et insèrent CHACUNE une sortie de caisse.
      //
      // Le salaire sort alors deux fois du compte, tandis que
      // `salaires.mouvement_id` ne retient que le dernier : le premier
      // mouvement devient un débit orphelin, que rien ne rattache plus à un
      // bulletin de paie. Personne ne le retrouve à la clôture du mois.
      //
      // `OF s` est explicite : sans lui, PostgreSQL tenterait aussi de
      // verrouiller `utilisateurs`, jointe seulement pour afficher un nom.
      const s = await client.query(
        `SELECT s.id, s.montant_net, s.montant_base, s.primes, s.retenues,
                s.devise, s.mois, s.statut, s.note, s.utilisateur_id,
                trim(concat(u.prenom, ' ', u.nom)) AS personne,
                u.prenom,
                c.poste,
                e.nom AS ecole_nom
           FROM salaires s
           JOIN utilisateurs u ON u.id = s.utilisateur_id
           JOIN ecoles e ON e.id = s.ecole_id
           LEFT JOIN contrats_personnel c ON c.id = s.contrat_id
          WHERE s.id = $1 AND s.ecole_id = ${CURRENT_ECOLE}
          FOR UPDATE OF s`,
        [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Bulletin de paie introuvable.'), { statusCode: 404 });
      }
      const salaire = s.rows[0];
      if (salaire.statut === 'paye') {
        throw Object.assign(
          new Error(`Le salaire de ${salaire.personne} pour ${salaire.mois} est déjà payé.`),
          { statusCode: 409 }
        );
      }

      const { devise_principale: deviseEcole, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
      exigerTaux(salaire.devise, deviseEcole, taux);

      const annee = await anneeActive(client);
      const categorie = await client.query(
        `SELECT id FROM categories_financieres
          WHERE ecole_id = ${CURRENT_ECOLE} AND sens = 'sortie'
            AND lower(nom) LIKE '%salaire%' AND actif = true
          LIMIT 1`
      );

      const mouvement = await client.query(
        `INSERT INTO mouvements_caisse
           (ecole_id, annee_scolaire_id, sens, categorie_id, libelle, montant, devise,
            taux_change, date_mouvement, mode_paiement, beneficiaire, salaire_id, enregistre_par)
         VALUES (${CURRENT_ECOLE}, $1, 'sortie', $2, $3, $4, $5, $6,
                 COALESCE($7::date, CURRENT_DATE), $8, $9, $10, $11)
         RETURNING id`,
        [annee ? annee.id : null,
         categorie.rows[0]?.id || null,
         `Salaire ${salaire.mois} — ${salaire.personne}`,
         Number(salaire.montant_net), salaire.devise,
         salaire.devise !== deviseEcole ? taux : null,
         date_paiement || null, mode_paiement || null,
         salaire.personne, id, req.auth.userId]
      );

      await client.query(
        `UPDATE salaires
            SET statut = 'paye', date_paiement = COALESCE($2::date, CURRENT_DATE),
                paye_par = $3, mouvement_id = $4
          WHERE id = $1`,
        [id, date_paiement || null, req.auth.userId, mouvement.rows[0].id]
      );

      // ------------------------------------------------------------------
      // Le bulletin de paie
      // ------------------------------------------------------------------
      // L'employé apprenait qu'il était payé en regardant son compte en
      // banque, ou en demandant. Le détail — base, primes, retenues — ne
      // sortait jamais de la plateforme : il fallait le réclamer au comptable,
      // qui le relisait à l'écran.
      //
      // L'e-mail EST le bulletin : le décompte y figure ligne par ligne, il
      // s'imprime, il se conserve, il se retrouve six mois plus tard dans une
      // boîte de réception. Passer par un PDF supposerait de lancer Chromium
      // (~300 Mo) et de stocker un fichier par employé et par mois, pour un
      // contenu qui tient dans un tableau.
      //
      // Écrit ici, dans la transaction : un bulletin de paie ne peut pas
      // annoncer un paiement que la caisse n'a pas enregistré.
      await notifierEvenement(client, {
        evenement: 'paie.salaire_paye',
        destinataires: [{ utilisateurId: salaire.utilisateur_id }],
        expediteurId: req.auth.userId,
        donnees: {
          personne: salaire.personne,
          prenom: salaire.prenom,
          poste: salaire.poste,
          ecole: salaire.ecole_nom,
          mois: salaire.mois,
          base: Number(salaire.montant_base),
          primes: Number(salaire.primes),
          retenues: Number(salaire.retenues),
          net: Number(salaire.montant_net),
          devise: salaire.devise,
          datePaiement: date_paiement || new Date().toISOString().slice(0, 10),
          modePaiement: mode_paiement || null,
          note: salaire.note
        },
        // Un même salaire ne peut être annoncé qu'une fois. Sans cette clé,
        // annuler puis re-payer enverrait deux bulletins pour le même mois,
        // et l'employé ne saurait pas lequel fait foi.
        cleUnicite: `salaire_paye:${id}`
      });

      return salaire;
    });

    planifierVidage();

    return res.json({
      message: `Salaire de ${resultat.personne} payé. La sortie a été enregistrée en caisse, `
             + `et le bulletin de paie a été envoyé à ${resultat.personne}.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur paiement salaire:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /comptabilite/paie/:id/annuler-paiement */
async function annulerPaiementSalaire(req, res) {
  const { id } = req.params;
  try {
    const personne = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const s = await client.query(
        `SELECT s.mouvement_id, s.statut, trim(concat(u.prenom, ' ', u.nom)) AS personne
           FROM salaires s JOIN utilisateurs u ON u.id = s.utilisateur_id
          WHERE s.id = $1 AND s.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Bulletin de paie introuvable.'), { statusCode: 404 });
      }
      if (s.rows[0].statut !== 'paye') {
        throw Object.assign(new Error("Ce salaire n'est pas marqué comme payé."), { statusCode: 409 });
      }

      // Le mouvement est retiré AVEC le paiement : laisser la sortie en caisse
      // ferait disparaître de l'argent qui n'est jamais parti.
      if (s.rows[0].mouvement_id) {
        await client.query(
          `DELETE FROM mouvements_caisse WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [s.rows[0].mouvement_id]
        );
      }
      await client.query(
        `UPDATE salaires SET statut = 'a_payer', date_paiement = NULL,
                             paye_par = NULL, mouvement_id = NULL
          WHERE id = $1`,
        [id]
      );
      return s.rows[0].personne;
    });
    return res.json({
      message: `Paiement annulé pour ${personne}. Le montant est remis en caisse.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur annulation paiement salaire:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  listerCategories, creerCategorie, modifierCategorie,
  listerMouvements, enregistrerMouvement, modifierMouvement, supprimerMouvement,
  tresorerie,
  listerContrats, creerContrat, modifierContrat, cloturerContrat,
  listerPaie, preparerPaie, modifierSalaire, payerSalaire, annulerPaiementSalaire
};
