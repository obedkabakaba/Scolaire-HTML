const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { anneeActive } = require('../utils/annee.utils');
const { sqlTotalFraisDus } = require('../utils/frais.utils');
const { lireConfigMonetaire, sqlPaiementConverti, sqlFraisConverti } = require('../utils/devise.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Contrôle financier des bulletins — Ardoise
 * --------------------------------------------------------------------------
 * Dans beaucoup d'écoles congolaises, le bulletin est le levier de
 * recouvrement : il n'est remis qu'aux familles à jour. Ce module rend ce
 * mécanisme explicite plutôt que manuel.
 *
 * Deux principes de conception :
 *
 *   1. DÉSACTIVÉ PAR DÉFAUT. Une école qui ne l'active pas ne voit aucune
 *      différence. Le blocage ne s'invite jamais de lui-même dans un
 *      processus qui fonctionne.
 *   2. La dérogation est un droit du directeur, mais elle est NOMINATIVE et
 *      MOTIVÉE. Un enfant peut être en difficulté sans que sa scolarité soit
 *      suspendue — encore faut-il que quelqu'un l'assume par écrit.
 */

/**
 * Situation financière d'un lot d'élèves pour l'année active.
 * Renvoie une carte eleve_id -> { attendu, verse, reste, bloque, derogation }.
 *
 * Fonction unique : la règle de blocage ne doit exister qu'à un seul endroit,
 * sinon le bulletin PDF et la page publique finiraient par diverger.
 */
async function situationFinanciere(client, eleveIds) {
  const reglage = await client.query(
    `SELECT COALESCE(bloquer_bulletin_impaye, false) AS actif,
            COALESCE(tolerance_impaye_pourcentage, 0) AS tolerance
     FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );
  const actif = reglage.rows[0]?.actif === true;
  const tolerance = Number(reglage.rows[0]?.tolerance || 0);

  const resultat = new Map();
  if (!eleveIds || eleveIds.length === 0) return { actif, tolerance, situations: resultat };

  // L'année active et la configuration monétaire sont résolues d'abord : le
  // solde qui décide de la délivrance d'un bulletin doit porter sur l'année EN
  // COURS. Auparavant la somme des versements couvrait toute la scolarité de
  // l'élève : une famille à jour l'an dernier mais qui n'avait rien réglé cette
  // année voyait le bulletin délivré malgré le blocage activé.
  const anneeCourante = await anneeActive(client);
  const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
  if (!anneeCourante) return { actif, tolerance, situations: resultat };

  const r = await client.query(
    `SELECT e.id,
            COALESCE(e.derogation_financiere, false) AS derogation,
            e.derogation_motif,
            ${sqlTotalFraisDus('e.classe_id', '$2', '$3', 4, CURRENT_ECOLE)} AS attendu,
            COALESCE((
              SELECT SUM(${sqlPaiementConverti('p', '$3', 4)})
                FROM paiements_frais p
               WHERE p.eleve_id = e.id AND p.annee_scolaire_id = $2
            ), 0) AS verse
     FROM eleves e
     WHERE e.id = ANY($1::uuid[]) AND e.ecole_id = ${CURRENT_ECOLE}`,
    [eleveIds, anneeCourante.id, devise, taux || null]
  );

  for (const l of r.rows) {
    const attendu = Number(l.attendu);
    const verse = Number(l.verse);
    const reste = Math.max(attendu - verse, 0);

    // La tolérance s'exprime en pourcentage du montant attendu : une école
    // peut accepter que 80 % soient versés pour délivrer le bulletin.
    const seuilRequis = attendu * (1 - tolerance / 100);
    const aJour = attendu === 0 || verse >= seuilRequis;

    resultat.set(l.id, {
      attendu, verse, reste, devise,
      derogation: l.derogation === true,
      derogation_motif: l.derogation_motif,
      // Le blocage n'existe que si l'école l'a activé ET que l'élève n'est
      // ni à jour ni bénéficiaire d'une dérogation.
      bloque: actif && !aJour && l.derogation !== true
    });
  }
  return { actif, tolerance, situations: resultat };
}

/** GET /frais/controle — état du réglage et nombre d'élèves concernés. */
async function etatControle(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleves = await client.query(
        `SELECT id FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif'`
      );
      const ids = eleves.rows.map((e) => e.id);
      const { actif, tolerance, situations } = await situationFinanciere(client, ids);

      let bloques = 0, derogations = 0, aJour = 0;
      situations.forEach((s) => {
        if (s.derogation) derogations++;
        if (s.bloque) bloques++; else aJour++;
      });

      return { actif, tolerance, total: ids.length, bloques, derogations, a_jour: aJour };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur état contrôle financier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PUT /frais/controle — active ou désactive le contrôle. */
async function enregistrerControle(req, res) {
  const { actif, tolerance } = req.body;
  const tol = Number(tolerance);
  if (tolerance !== undefined && (!Number.isFinite(tol) || tol < 0 || tol > 100)) {
    return res.status(400).json({ message: 'La tolérance doit être un pourcentage entre 0 et 100.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE ecoles SET
           bloquer_bulletin_impaye = COALESCE($1, bloquer_bulletin_impaye),
           tolerance_impaye_pourcentage = COALESCE($2, tolerance_impaye_pourcentage),
           updated_at = now()
         WHERE id = ${CURRENT_ECOLE}`,
        [typeof actif === 'boolean' ? actif : null, tolerance !== undefined ? tol : null]
      )
    );
    return res.json({
      message: actif === false
        ? "Contrôle désactivé : tous les bulletins redeviennent délivrables."
        : 'Contrôle financier enregistré.'
    });
  } catch (err) {
    console.error('Erreur réglage contrôle financier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /frais/derogation
 * body : { eleve_id, accorder, motif }
 *
 * La dérogation est nominative et motivée : elle engage celui qui la signe.
 */
async function deroger(req, res) {
  const { eleve_id, accorder, motif } = req.body;
  if (!eleve_id) return res.status(400).json({ message: "L'élève est requis." });

  if (accorder !== false && (!motif || !String(motif).trim())) {
    return res.status(400).json({
      message: "Une dérogation exige un motif écrit : il sera conservé au nom de qui l'accorde."
    });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `UPDATE eleves SET
           derogation_financiere = $2,
           derogation_motif = $3,
           derogation_par = $4,
           derogation_at = now()
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}
         RETURNING trim(concat(nom, ' ', COALESCE(postnom, ''))) AS nom`,
        [eleve_id, accorder !== false, accorder !== false ? String(motif).trim() : null, req.auth.userId]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      return accorder !== false
        ? `Dérogation accordée à ${r.rows[0].nom}. Son bulletin est délivrable malgré le solde.`
        : `Dérogation retirée à ${r.rows[0].nom}.`;
    });
    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur dérogation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { situationFinanciere, etatControle, enregistrerControle, deroger };
