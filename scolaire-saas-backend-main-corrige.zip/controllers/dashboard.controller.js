const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { sqlTotalFraisDus } = require('../utils/frais.utils');
// Le calcul des moyennes vit dans un utilitaire partagé : un contrôleur qui
// dépend d'un autre contrôleur crée un couplage que rien ne justifie, et deux
// écrans doivent pouvoir utiliser la même règle sans se connaître.
const { pourcentagesParEleve } = require('../utils/moyennes.utils');
const { lireConfigMonetaire, sqlPaiementConverti, sqlFraisConverti } = require('../utils/devise.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /dashboard/directeur
 * Regroupe tout ce que le tableau de bord doit afficher : effectifs,
 * notes encodées/restantes (sur la période en cours), événements à venir,
 * état de l'abonnement.
 */
async function directeur(req, res) {
  try {
    const data = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const effectifsResult = await client.query(`
        SELECT
          (SELECT count(*) FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif') AS nb_eleves,
          (SELECT count(DISTINCT ur.utilisateur_id) FROM utilisateur_roles ur
             JOIN utilisateurs u ON u.id = ur.utilisateur_id
             WHERE u.ecole_id = ${CURRENT_ECOLE} AND ur.role = 'professeur' AND u.statut = 'actif') AS nb_professeurs,
          (SELECT count(*) FROM classes WHERE ecole_id = ${CURRENT_ECOLE}) AS nb_classes
      `);

      // Période "courante" : celle dont la date du jour tombe dans l'intervalle,
      // sinon la plus récente par date de début.
      const periodeResult = await client.query(`
        SELECT id, libelle, type, numero, date_debut, date_fin
        FROM periodes
        WHERE ecole_id = ${CURRENT_ECOLE}
        ORDER BY
          (date_debut <= now() AND (date_fin IS NULL OR date_fin >= now())) DESC,
          date_debut DESC
        LIMIT 1
      `);
      const periodeCourante = periodeResult.rows[0] || null;

      let notesEncodees = 0;
      let notesAttendues = 0;

      if (periodeCourante) {
        const encodeesResult = await client.query(
          `SELECT count(*) FROM notes
           WHERE periode_id = $1 AND points_obtenus IS NOT NULL AND ecole_id = ${CURRENT_ECOLE}`,
          [periodeCourante.id]
        );
        notesEncodees = parseInt(encodeesResult.rows[0].count, 10);

        const attenduesResult = await client.query(`
          SELECT COALESCE(SUM(nb_eleves_classe * nb_cours_classe), 0) AS total
          FROM (
            SELECT c.id,
                   (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS nb_eleves_classe,
                   (SELECT count(*) FROM classe_cours cc WHERE cc.classe_id = c.id) AS nb_cours_classe
            FROM classes c
            WHERE c.ecole_id = ${CURRENT_ECOLE}
          ) sous_requete
        `);
        notesAttendues = parseInt(attenduesResult.rows[0].total, 10);
      }

      const evenementsResult = await client.query(`
        SELECT id, titre, type, date_debut, date_fin
        FROM evenements_calendrier
        WHERE ecole_id = ${CURRENT_ECOLE} AND date_debut >= now()
        ORDER BY date_debut ASC
        LIMIT 5
      `);

      const abonnementResult = await client.query(`
        SELECT a.statut, a.date_expiration, p.nom AS plan_nom
        FROM abonnements a
        JOIN plans_abonnement p ON p.id = a.plan_id
        WHERE a.ecole_id = ${CURRENT_ECOLE}
        ORDER BY a.created_at DESC
        LIMIT 1
      `);

      // ---------- Année active : base de tout ce qui suit ----------
      const anneeActiveResult = await client.query(
        `SELECT id, libelle FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
      );
      const anneeActive = anneeActiveResult.rows[0] || null;

      let etatPeriodesParClasse = [];
      let tauxReussiteGlobal = null;
      let impayes = { nb_eleves_en_retard: 0, montant_total_du: 0 };

      if (anneeActive) {
        // AVANCEMENT DE LA VALIDATION DES NOTES, par classe et par période.
        //
        // Ce tableau répond à une seule question, celle que se pose un
        // directeur en fin de période : « où en est la saisie, et qui dois-je
        // relancer ? » Il ne parle ni de résultats, ni de bulletins.
        //
        // Trois états, et non deux. L'ancienne version affichait ✓ ou —, ce
        // qui mettait dans le même sac « rien n'a été commencé » et « sept
        // cours sur huit sont validés ». Or ce sont deux situations opposées :
        // l'une demande de relancer toute une équipe, l'autre un seul
        // enseignant. On distingue donc :
        //   · aucune saisie      → personne n'a commencé
        //   · saisie en cours    → des notes existent, pas encore validées
        //   · partiellement validé / complet
        const etatResult = await client.query(
          `SELECT c.id AS classe_id, c.nom AS classe_nom,
                  p.id AS periode_id, p.libelle AS periode_libelle, p.numero,
                  p.type::text AS periode_type,
                  (
                    SELECT count(*) FROM classe_cours cc WHERE cc.classe_id = c.id
                  ) AS nb_cours,
                  (
                    SELECT count(DISTINCT cc.id) FROM classe_cours cc
                    WHERE cc.classe_id = c.id
                      AND EXISTS (SELECT 1 FROM notes n
                                   WHERE n.classe_cours_id = cc.id AND n.periode_id = p.id
                                     AND n.valide = true)
                  ) AS nb_cours_valides,
                  (
                    SELECT count(DISTINCT cc.id) FROM classe_cours cc
                    WHERE cc.classe_id = c.id
                      AND EXISTS (SELECT 1 FROM notes n
                                   WHERE n.classe_cours_id = cc.id AND n.periode_id = p.id
                                     AND n.points_obtenus IS NOT NULL)
                  ) AS nb_cours_saisis
           FROM classes c
           CROSS JOIN periodes p
           WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
             AND p.annee_scolaire_id = $1 AND p.type IN ('periode', 'examen')
           ORDER BY c.nom, p.numero`,
          [anneeActive.id]
        );

        etatPeriodesParClasse = etatResult.rows.map((r) => {
          const nbCours = Number(r.nb_cours);
          const valides = Number(r.nb_cours_valides);
          const saisis = Number(r.nb_cours_saisis);

          let etat;
          if (nbCours === 0) etat = 'sans_cours';
          else if (valides >= nbCours) etat = 'complet';
          else if (valides > 0) etat = 'validation_partielle';
          else if (saisis > 0) etat = 'saisie_en_cours';
          else etat = 'rien';

          return {
            classe_id: r.classe_id, classe_nom: r.classe_nom,
            periode_id: r.periode_id, periode_libelle: r.periode_libelle,
            numero: r.numero, periode_type: r.periode_type,
            nb_cours: nbCours, nb_cours_valides: valides, nb_cours_saisis: saisis,
            etat,
            // Conservé pour ne casser aucun appelant existant : le tableau de
            // bord n'est pas le seul écran susceptible de lire ce champ.
            soumis: etat === 'complet'
          };
        });

        // Moyenne générale de l'école, calculée EXACTEMENT comme dans les
        // rapports — même fonction, même source.
        //
        // Cette carte lisait `AVG(bulletins.pourcentage)` pendant que l'écran
        // des rapports calculait depuis les notes. Deux chiffres différents
        // pour la même chose, à un clic d'écart : la carte annonçait une
        // valeur, et la fenêtre ouverte en cliquant dessus en affichait une
        // autre. C'est ce qui rendait le widget incompréhensible.
        //
        // Elle héritait en outre du dénominateur partiel des anciens bulletins,
        // et ne voyait rien des classes notées sans bulletin généré.
        const periodesAnnee = await client.query(
          `SELECT id FROM periodes
            WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
              AND type::text IN ('periode', 'examen')`,
          [anneeActive.id]
        );
        const lignes = await pourcentagesParEleve(client, anneeActive.id, {
          type: 'annuel',
          periodeIds: periodesAnnee.rows.map((r) => r.id)
        });
        tauxReussiteGlobal = lignes.length
          ? Math.round((lignes.reduce((t, l) => t + l.pourcentage, 0) / lignes.length) * 10) / 10
          : null;

        // Impayés : élèves actifs de l'année dont le solde (attendu - payé) est positif.
        // Les versements sont bornés à l'année en cours et convertis dans la devise
        // d'affichage — sans quoi le total dû affiché en page d'accueil était faux.
        //
        // Ce bloc est isolé : c'est UNE carte du tableau de bord, elle ne doit pas
        // pouvoir emporter la page entière. Il dépend de colonnes ajoutées par la
        // migration 001 (devise_principale, taux_change, annee_scolaire_id sur les
        // paiements) ; tant qu'elle n'est pas jouée, PostgreSQL renvoie 42703 et le
        // Directeur se retrouvait devant un écran vide, sans effectifs ni notes ni
        // présences — alors que rien de tout cela n'a de rapport avec les finances.
        try {
          const configMonetaire = await lireConfigMonetaire(client);
          const impayesResult = await client.query(
            `WITH montants AS (
               SELECT e.id AS eleve_id,
                  -- Somme de TOUTES les lignes de frais applicables, une par
                  -- libellé (utils/frais.utils.js). Le LIMIT 1 qui figurait ici
                  -- n'en retenait qu'une : une école réclamant inscription +
                  -- minerval + laboratoire voyait ses familles déclarées à jour,
                  -- et le blocage de bulletin pour impayé ne bloquait personne.
                      ${sqlTotalFraisDus('e.classe_id', '$1', '$2', 3, CURRENT_ECOLE)} AS attendu,
                      COALESCE((
                        SELECT SUM(${sqlPaiementConverti('p', '$2', 3)})
                          FROM paiements_frais p
                         WHERE p.eleve_id = e.id AND p.annee_scolaire_id = $1
                      ), 0) AS paye
               FROM eleves e
               JOIN classes c ON c.id = e.classe_id
               WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif' AND c.annee_scolaire_id = $1
             )
             SELECT count(*) FILTER (WHERE attendu - paye > 0) AS nb_en_retard,
                    COALESCE(SUM(GREATEST(attendu - paye, 0)), 0) AS total_du
             FROM montants`,
            [anneeActive.id, configMonetaire.devise_principale, configMonetaire.taux_change_usd_fc || null]
          );
          impayes = {
            nb_eleves_en_retard: parseInt(impayesResult.rows[0].nb_en_retard, 10),
            montant_total_du: Number(impayesResult.rows[0].total_du),
            devise: configMonetaire.devise_principale
          };
        } catch (err) {
          // On signale explicitement l'indisponibilité plutôt que d'afficher zéro :
          // « 0 impayé » est une information, « indisponible » en est une autre, et
          // les confondre ferait croire au Directeur que toutes les familles sont
          // à jour.
          const migrationManquante = err.code === '42703';
          console.error(
            migrationManquante
              ? 'Impayés indisponibles : migration 001-annee-pivot-et-finances.sql non jouée (%s)'
              : 'Impayés indisponibles : %s',
            err.message
          );
          impayes = {
            nb_eleves_en_retard: null,
            montant_total_du: null,
            indisponible: true,
            raison: migrationManquante
              ? "Migration de base de données en attente : jouez migrations/001-annee-pivot-et-finances.sql."
              : "Le calcul des impayés est momentanément indisponible."
          };
        }
      }

      return {
        effectifs: effectifsResult.rows[0],
        periode_courante: periodeCourante,
        notes: {
          encodees: notesEncodees,
          attendues: notesAttendues,
          restantes: Math.max(notesAttendues - notesEncodees, 0)
        },
        evenements_a_venir: evenementsResult.rows,
        abonnement: abonnementResult.rows[0] || null,
        annee_active: anneeActive,
        etat_periodes_par_classe: etatPeriodesParClasse,
        taux_reussite_global: tauxReussiteGlobal,
        impayes
      };
    });

    return res.json(data);
  } catch (err) {
    console.error('Erreur dashboard directeur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { directeur };
