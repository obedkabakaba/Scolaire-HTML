const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { appelerIAJson, consommerQuota } = require('../utils/ia.utils');
const { extraireTexte, contientBareme, nettoyer } = require('../utils/document-texte.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  RÈGLEMENT INTÉRIEUR ET BARÈME DE DISCIPLINE
 * ===========================================================================
 *
 * Jusqu'ici, le barème de discipline était écrit en dur dans le code : les
 * mêmes huit fautes et les mêmes points pour toutes les écoles de la
 * plateforme. Ce module permet à chaque établissement d'installer le SIEN, à
 * partir de son propre règlement intérieur.
 *
 * TROIS CHEMINS, SELON CE QUE L'ÉCOLE POSSÈDE
 * -------------------------------------------
 *   1. L'école a un règlement AVEC un barème chiffré
 *      → l'assistant se contente de le TRANSCRIRE. Il ne réévalue rien, ne
 *        « corrige » aucun point. Le barème appartient à l'école, pas à nous.
 *   2. L'école a un règlement SANS barème (le cas le plus fréquent : un texte
 *      qui énumère les interdits sans les chiffrer)
 *      → l'assistant identifie les fautes ÉNONCÉES DANS LE TEXTE et leur
 *        attribue des points cohérents entre eux.
 *   3. L'école n'a pas de règlement du tout
 *      → l'assistant en rédige un (voir la base retenue plus bas).
 *
 * Le choix entre 1 et 2 n'est PAS laissé au modèle : il est décidé côté
 * serveur par `contientBareme()`, puis imposé dans la consigne. Un modèle à
 * qui l'on demande « devine s'il y a un barème » se trompe tôt ou tard, et se
 * tromper ici signifie soit écraser le barème d'une école, soit lui rendre un
 * règlement vide de chiffres.
 *
 * RIEN N'EST APPLIQUÉ SANS VALIDATION HUMAINE
 * -------------------------------------------
 * L'analyse produit une PROPOSITION. Elle n'entre en vigueur que lorsque le
 * directeur l'a relue et validée, en ayant pu corriger chaque ligne. Un
 * barème disciplinaire décide de sanctions réelles pour des enfants réels :
 * il ne s'installe pas tout seul.
 */

// ---------------------------------------------------------------------------
//  Vocabulaire
// ---------------------------------------------------------------------------

const MESURES = ['aucune', 'avertissement', 'convocation_parent', 'travail_supplementaire', 'exclusion_temporaire', 'conseil_discipline'];

/**
 * Codes historiques du barème écrit en dur. On les réutilise quand l'assistant
 * reconnaît la même faute : sans cela, une école qui importe son règlement
 * verrait ses incidents déjà saisis se rattacher à des codes disparus, et son
 * historique deviendrait illisible.
 */
const CODES_CONNUS = {
  retard: ['retard', 'arrivee tardive', 'arrive tard'],
  absence_injustifiee: ['absence injustifiee', 'absence non justifiee', 'absenteisme'],
  indiscipline: ['indiscipline', 'insolence', 'desobeissance', 'perturbation', 'bavardage'],
  bagarre: ['bagarre', 'violence', 'rixe', 'coups'],
  tricherie: ['tricherie', 'fraude', 'copiage', 'plagiat'],
  degradation: ['degradation', 'vandalisme', 'destruction', 'deterioration'],
  tenue: ['tenue', 'uniforme', 'coiffure', 'negligence vestimentaire'],
  entraide: ['entraide', 'solidarite', 'aide'],
  effort: ['effort', 'progres', 'assiduite remarquee'],
  exemplarite: ['exemplarite', 'exemple', 'conduite exemplaire'],
  service_rendu: ['service rendu', 'service', 'devouement'],
  distinction: ['distinction', 'felicitation', 'prix', 'excellence']
};

function sansAccents(texte) {
  return String(texte).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

/**
 * Transforme un libellé en code technique stable. On tente d'abord de
 * retrouver un code historique, pour préserver la continuité de l'historique
 * disciplinaire.
 */
function codeDepuisLibelle(libelle, codesPris) {
  const normalise = sansAccents(libelle);
  for (const [code, synonymes] of Object.entries(CODES_CONNUS)) {
    if (codesPris.has(code)) continue;
    if (synonymes.some((s) => normalise.includes(s))) return code;
  }

  let base = normalise.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
  if (!base) base = 'regle';
  let code = base;
  let n = 2;
  while (codesPris.has(code)) { code = `${base}_${n++}`; }
  return code;
}

// ---------------------------------------------------------------------------
//  Consignes données à l'assistant
// ---------------------------------------------------------------------------

const CADRE_COMMUN = `Tu assistes une école de la République Démocratique du Congo qui installe son barème de discipline dans un logiciel de gestion scolaire.

Tu réponds UNIQUEMENT par un objet JSON valide, sans texte avant ni après, sans balises de code.

Structure attendue :
{
  "capital_conduite_suggere": <entier entre 10 et 100>,
  "regles": [
    {
      "libelle": "<intitulé court de la faute ou du fait, en français>",
      "sens": "negatif" | "positif",
      "points": <nombre entier ou décimal, toujours POSITIF>,
      "mesure": "aucune" | "avertissement" | "convocation_parent" | "travail_supplementaire" | "exclusion_temporaire" | "conseil_discipline",
      "categorie": "<regroupement court : Assiduité, Tenue, Comportement, Probité, Biens, Mérite…>",
      "citation": "<le passage du règlement dont vient cette règle, ou null>"
    }
  ]
}

Règles de forme impératives :
- "points" est TOUJOURS un nombre positif. C'est "sens" qui dit s'il s'ajoute ou se retranche. N'écris jamais -3.
- Un fait à valoriser (entraide, effort, service rendu, exemplarité) a sens = "positif".
- Le total des points d'une faute ne doit jamais dépasser le capital de conduite suggéré.
- Entre 6 et 25 règles. Au-delà, le barème devient inutilisable au quotidien.
- Les libellés sont en français, courts, compréhensibles par un enseignant.`;

const CONSIGNE_TRANSCRIRE = `${CADRE_COMMUN}

MODE : TRANSCRIPTION.

Le règlement fourni contient DÉJÀ un barème chiffré. Ta tâche est de le
recopier fidèlement dans la structure ci-dessus, RIEN DE PLUS.

Interdictions absolues :
- Ne modifie AUCUN nombre de points présent dans le texte.
- N'ajoute AUCUNE règle qui ne figure pas dans le texte.
- Ne "corrige" pas une graduation qui te semblerait incohérente : ce barème est
  la décision de l'école, pas la tienne.

Si une faute est citée sans points alors que d'autres en ont, mets points = 0 et
signale-le en mettant "citation" sur le passage concerné : le directeur
tranchera lui-même.

Pour "capital_conduite_suggere", reprends la valeur indiquée dans le texte si
elle y figure ; sinon propose 20, usage le plus répandu en RDC.`;

const CONSIGNE_ATTRIBUER = `${CADRE_COMMUN}

MODE : ATTRIBUTION.

Le règlement fourni énumère des interdits et des devoirs, mais NE CHIFFRE PAS
les sanctions. Ta tâche est double :
1. Extraire les fautes et les faits réellement ÉNONCÉS DANS LE TEXTE. N'invente
   pas de faute absente du règlement.
2. Leur attribuer des points cohérents ENTRE EUX, sur un capital de 20.

Principe de graduation à respecter :
- Manquements légers (retard, tenue, bavardage) : 1 à 2 points.
- Manquements moyens (absence injustifiée, insolence, indiscipline) : 2 à 4.
- Fautes graves (tricherie, dégradation volontaire, vol) : 5 à 6.
- Fautes très graves (violence, bagarre) : 6 à 8.
- Aucune faute unique ne doit épuiser plus de la moitié du capital : un élève
  doit conserver la possibilité de se reprendre après une seule erreur.

Ajoute systématiquement 3 à 5 faits À VALORISER (sens = "positif", 2 à 4 points),
même si le règlement n'en parle pas : une école qui ne sait que sanctionner
passe à côté de la moitié de son rôle éducatif. Signale-les avec
"citation": null, pour que le directeur voie qu'ils viennent de toi.`;

/**
 * BASE DU RÈGLEMENT GÉNÉRÉ
 * ------------------------
 * Le choix de la base a été explicitement laissé à l'assistant. Retenu : les
 * usages courants des écoles conventionnées de RDC — capital de conduite sur
 * 20 reporté au bulletin, gradation des mesures allant de l'avertissement au
 * conseil de discipline, vocabulaire du système éducatif congolais.
 *
 * Pourquoi celle-là plutôt qu'un modèle international : le règlement produit
 * doit pouvoir être affiché au mur d'une école de Kinshasa sans retraduction,
 * et s'articuler avec ce que le bulletin officiel attend déjà (une conduite
 * appréciée, pas un score abstrait). Un modèle importé d'ailleurs aurait
 * produit un texte correct et inutilisable.
 */
const CONSIGNE_GENERER = `${CADRE_COMMUN}

MODE : RÉDACTION.

Cette école n'a pas de règlement disciplinaire écrit. Rédige un barème de départ
fondé sur les usages courants des écoles conventionnées de la République
Démocratique du Congo :
- capital de conduite de 20 points, reporté en appréciation sur le bulletin ;
- gradation des mesures de l'avertissement au conseil de discipline ;
- vocabulaire du système éducatif congolais (titulaire, préfet des études).

Couvre l'assiduité, la tenue, le comportement en classe, le respect des
personnes, la probité aux épreuves, le respect des biens — et le mérite.

Ajoute en plus, à la racine du JSON, une clé "texte_reglement" contenant un
règlement rédigé en articles numérotés (« Article 1. … »), en français simple,
que le directeur pourra afficher et amender. Il doit correspondre exactement aux
règles de la liste.

Ce texte est une PROPOSITION DE DÉPART destinée à être relue et amendée par le
chef d'établissement, pas un document faisant autorité.`;

// ---------------------------------------------------------------------------
//  Validation de ce que renvoie l'assistant
// ---------------------------------------------------------------------------

/**
 * On ne fait jamais confiance à la sortie du modèle : elle est renormalisée
 * ligne par ligne avant d'être montrée au directeur. Un point négatif, une
 * mesure inventée ou un libellé de trois cents caractères passeraient sinon
 * jusqu'en base.
 */
function normaliserProposition(brut, modeTranscription) {
  const regles = Array.isArray(brut && brut.regles) ? brut.regles : [];
  if (regles.length === 0) {
    throw Object.assign(
      new Error("L'assistant n'a identifié aucune règle dans ce document. Vérifiez qu'il contient bien la partie disciplinaire du règlement."),
      { statusCode: 422 }
    );
  }

  let capital = Number(brut.capital_conduite_suggere);
  if (!Number.isFinite(capital) || capital < 10 || capital > 100) capital = 20;
  capital = Math.round(capital);

  const codesPris = new Set();
  const propres = [];

  for (const r of regles.slice(0, 30)) {
    const libelle = String(r.libelle || '').trim().slice(0, 120);
    if (!libelle) continue;

    const sens = r.sens === 'positif' ? 'positif' : 'negatif';

    // Valeur absolue : malgré la consigne, un modèle écrit parfois -3 pour
    // « trois points en moins ». Le signe est porté par `sens`, jamais par le
    // nombre — sinon un retrait deviendrait un gain au moment du calcul.
    let points = Math.abs(Number(r.points));
    if (!Number.isFinite(points)) points = 0;
    // Un retrait supérieur au capital rendrait la règle inapplicable : le
    // contrôleur de signalement la refuserait à chaque usage.
    points = Math.min(Math.round(points * 100) / 100, capital);

    const mesure = MESURES.includes(r.mesure) ? r.mesure : 'aucune';
    const code = codeDepuisLibelle(libelle, codesPris);
    codesPris.add(code);

    propres.push({
      code,
      libelle,
      sens,
      points,
      mesure: sens === 'positif' ? 'aucune' : mesure,
      categorie: r.categorie ? String(r.categorie).trim().slice(0, 60) : null,
      citation: r.citation ? String(r.citation).trim().slice(0, 400) : null,
      // Tracer d'où viennent les points est ce qui permettra au directeur de
      // relire en priorité ceux que l'assistant a inventés.
      origine_points: modeTranscription && r.citation ? 'texte' : 'propose',
      ordre: propres.length
    });
  }

  if (propres.length === 0) {
    throw Object.assign(
      new Error("Aucune règle exploitable n'a pu être tirée de ce document."),
      { statusCode: 422 }
    );
  }

  return {
    capital_conduite_suggere: capital,
    regles: propres,
    texte_reglement: brut.texte_reglement ? String(brut.texte_reglement).slice(0, 20000) : null
  };
}

// ---------------------------------------------------------------------------
//  Endpoints
// ---------------------------------------------------------------------------

/**
 * GET /discipline/reglement
 * Le règlement en vigueur, la proposition en attente s'il y en a une, et le
 * barème réellement appliqué.
 */
async function etatReglement(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const reglements = await client.query(
        `SELECT r.id, r.nom, r.origine, r.statut, r.bareme_present, r.created_at, r.valide_at,
                r.analyse_ia AS analyse, length(r.texte_source) AS taille_texte,
                trim(concat(uc.prenom, ' ', uc.nom)) AS cree_par_nom,
                trim(concat(uv.prenom, ' ', uv.nom)) AS valide_par_nom
         FROM reglements_discipline r
         LEFT JOIN utilisateurs uc ON uc.id = r.cree_par
         LEFT JOIN utilisateurs uv ON uv.id = r.valide_par
         WHERE r.ecole_id = ${CURRENT_ECOLE} AND r.statut <> 'archive'
         ORDER BY r.created_at DESC`
      );

      const regles = await client.query(
        `SELECT id, code, libelle, sens, points, mesure, categorie, ordre, actif, origine_points
         FROM regles_discipline
         WHERE ecole_id = ${CURRENT_ECOLE}
         ORDER BY sens DESC, ordre, libelle`
      );

      const ecole = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );

      return {
        capital_conduite: Number(ecole.rows[0].capital),
        en_vigueur: reglements.rows.find((r) => r.statut === 'valide') || null,
        proposition: reglements.rows.find((r) => r.statut === 'propose') || null,
        // Dit à l'interface si l'école tourne encore sur le barème générique.
        // Sans cette information, un directeur ne peut pas savoir que le barème
        // affiché n'est pas le sien.
        bareme_par_defaut: regles.rows.length === 0,
        regles: regles.rows.map((r) => ({ ...r, points: Number(r.points) }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur état règlement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** Analyse commune aux trois chemins. */
async function analyser(req, { nom, texte, origine }) {
  const modeTranscription = origine === 'import' && contientBareme(texte || '');

  const consigne = origine === 'genere'
    ? CONSIGNE_GENERER
    : (modeTranscription ? CONSIGNE_TRANSCRIRE : CONSIGNE_ATTRIBUER);

  const message = origine === 'genere'
    ? `École : ${nom}. Rédige le barème et le règlement de départ.`
    : `Voici le règlement intérieur à analyser :\n\n${texte}`;

  const brut = await appelerIAJson({
    systeme: consigne,
    message,
    maxTokens: origine === 'genere' ? 3500 : 3000
  });

  const proposition = normaliserProposition(brut, modeTranscription);
  return { proposition, modeTranscription };
}

/**
 * POST /discipline/reglement/importer
 * Accepte un fichier (champ `fichier`) OU un texte collé (`texte`).
 */
async function importerReglement(req, res) {
  const nom = String(req.body.nom || '').trim() || 'Règlement intérieur';

  let texte;
  try {
    if (req.file) {
      texte = extraireTexte(req.file.buffer, req.file.originalname);
    } else if (req.body.texte && String(req.body.texte).trim()) {
      texte = nettoyer(req.body.texte);
      if (texte.length < 40) {
        return res.status(400).json({ message: 'Le texte collé est trop court pour être un règlement.' });
      }
    } else {
      return res.status(400).json({ message: 'Fournissez un fichier ou collez le texte du règlement.' });
    }
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    throw err;
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Le quota est consommé AVANT l'appel : mieux vaut refuser franchement
      // en fin de quota que lancer une analyse qu'on ne pourra pas facturer.
      await consommerQuota(client, req.auth.ecoleId, 1);

      const { proposition, modeTranscription } = await analyser(req, {
        nom, texte, origine: 'import'
      });

      // Une nouvelle proposition remplace la précédente non validée : deux
      // propositions en attente n'auraient aucun sens pour le directeur.
      await client.query(
        `DELETE FROM reglements_discipline
          WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'propose'`
      );

      const insertion = await client.query(
        `INSERT INTO reglements_discipline
           (ecole_id, nom, texte_source, origine, statut, analyse_ia, bareme_present, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, 'import', 'propose', $3::jsonb, $4, $5)
         RETURNING id`,
        [nom, texte, JSON.stringify(proposition), modeTranscription, req.auth.userId]
      );

      return { id: insertion.rows[0].id, proposition, modeTranscription };
    });

    const explication = resultat.modeTranscription
      ? "Votre règlement contenait déjà un barème : les points ont été repris tels quels, sans être réévalués."
      : "Votre règlement ne chiffrait pas les sanctions : des points cohérents ont été proposés. Relisez-les avant de valider.";

    return res.json({
      message: `${resultat.proposition.regles.length} règle(s) identifiée(s). ${explication}`,
      reglement_id: resultat.id,
      mode: resultat.modeTranscription ? 'transcription' : 'attribution',
      proposition: resultat.proposition
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur import règlement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /discipline/reglement/generer
 * Pour l'école qui n'a aucun règlement écrit.
 */
async function genererReglement(req, res) {
  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await consommerQuota(client, req.auth.ecoleId, 1);

      const ecole = await client.query(`SELECT nom FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const nomEcole = ecole.rows[0]?.nom || 'cet établissement';

      const { proposition } = await analyser(req, { nom: nomEcole, texte: null, origine: 'genere' });

      await client.query(
        `DELETE FROM reglements_discipline
          WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'propose'`
      );

      const insertion = await client.query(
        `INSERT INTO reglements_discipline
           (ecole_id, nom, texte_source, origine, statut, analyse_ia, bareme_present, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, 'genere', 'propose', $3::jsonb, false, $4)
         RETURNING id`,
        [`Règlement proposé — ${nomEcole}`, proposition.texte_reglement,
         JSON.stringify(proposition), req.auth.userId]
      );

      return { id: insertion.rows[0].id, proposition };
    });

    return res.json({
      message: `Proposition rédigée : ${resultat.proposition.regles.length} règle(s). `
        + "Ce texte est un point de départ à relire et amender — il n'a aucune valeur tant que vous ne l'avez pas validé.",
      reglement_id: resultat.id,
      mode: 'redaction',
      proposition: resultat.proposition
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur génération règlement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /discipline/reglement/:id/valider
 * body : { capital_conduite, regles: [{ code?, libelle, sens, points, mesure, categorie }] }
 *
 * Le directeur envoie les règles TELLES QU'IL LES A CORRIGÉES : ce sont
 * elles qui font foi, pas la proposition initiale de l'assistant.
 */
async function validerReglement(req, res) {
  const { id } = req.params;
  const { capital_conduite, regles } = req.body;

  if (!Array.isArray(regles) || regles.length === 0) {
    return res.status(400).json({ message: 'Aucune règle à enregistrer.' });
  }

  let capital = Number(capital_conduite);
  if (!Number.isInteger(capital) || capital < 1 || capital > 100) {
    return res.status(400).json({ message: 'Le capital de conduite doit être un entier entre 1 et 100.' });
  }

  // Validation exhaustive AVANT toute écriture : un barème à moitié installé
  // serait pire que pas de barème du tout.
  const codesPris = new Set();
  const propres = [];
  for (const r of regles) {
    const libelle = String(r.libelle || '').trim();
    if (!libelle) {
      return res.status(400).json({ message: 'Chaque règle doit avoir un libellé.' });
    }
    const points = Math.abs(Number(r.points));
    if (!Number.isFinite(points)) {
      return res.status(400).json({ message: `Points invalides pour « ${libelle} ».` });
    }
    if (points > capital) {
      return res.status(400).json({
        message: `« ${libelle} » retire ${points} points alors que le capital n'est que de ${capital}. Réduisez les points ou augmentez le capital.`
      });
    }
    const sens = r.sens === 'positif' ? 'positif' : 'negatif';
    let code = String(r.code || '').trim() || codeDepuisLibelle(libelle, codesPris);
    if (codesPris.has(code)) code = codeDepuisLibelle(libelle, codesPris);
    codesPris.add(code);

    propres.push({
      code, libelle, sens,
      points: Math.round(points * 100) / 100,
      mesure: MESURES.includes(r.mesure) ? r.mesure : 'aucune',
      categorie: r.categorie ? String(r.categorie).trim().slice(0, 60) : null,
      origine_points: ['texte', 'propose', 'manuel'].includes(r.origine_points) ? r.origine_points : 'manuel',
      ordre: propres.length
    });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const reglement = await client.query(
        `SELECT id, nom FROM reglements_discipline
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND statut = 'propose'`,
        [id]
      );
      if (reglement.rows.length === 0) {
        throw Object.assign(
          new Error("Proposition introuvable ou déjà traitée."), { statusCode: 404 }
        );
      }

      // L'ancien règlement passe en archive plutôt que d'être supprimé : c'est
      // la seule façon de savoir plus tard sous quel texte une sanction de
      // l'an dernier a été prononcée.
      await client.query(
        `UPDATE reglements_discipline SET statut = 'archive'
          WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'valide'`
      );

      // Les règles disparues sont DÉSACTIVÉES, pas effacées : un incident déjà
      // saisi renvoie à son code, qui doit rester lisible.
      await client.query(
        `UPDATE regles_discipline SET actif = false, updated_at = now()
          WHERE ecole_id = ${CURRENT_ECOLE} AND code <> ALL($1::text[])`,
        [propres.map((r) => r.code)]
      );

      for (const r of propres) {
        await client.query(
          `INSERT INTO regles_discipline
             (ecole_id, reglement_id, code, libelle, sens, points, mesure, categorie, ordre, actif, origine_points)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7, $8, true, $9)
           ON CONFLICT (ecole_id, code)
           DO UPDATE SET reglement_id = EXCLUDED.reglement_id,
                         libelle = EXCLUDED.libelle,
                         sens = EXCLUDED.sens,
                         points = EXCLUDED.points,
                         mesure = EXCLUDED.mesure,
                         categorie = EXCLUDED.categorie,
                         ordre = EXCLUDED.ordre,
                         actif = true,
                         origine_points = EXCLUDED.origine_points,
                         updated_at = now()`,
          [id, r.code, r.libelle, r.sens, r.points, r.mesure, r.categorie, r.ordre, r.origine_points]
        );
      }

      await client.query(
        `UPDATE reglements_discipline
            SET statut = 'valide', valide_par = $2, valide_at = now()
          WHERE id = $1`,
        [id, req.auth.userId]
      );

      await client.query(
        `UPDATE ecoles SET capital_conduite = $1, updated_at = now() WHERE id = ${CURRENT_ECOLE}`,
        [capital]
      );

      const desactivees = await client.query(
        `SELECT count(*) AS nb FROM regles_discipline
          WHERE ecole_id = ${CURRENT_ECOLE} AND actif = false`
      );

      return { installees: propres.length, desactivees: Number(desactivees.rows[0].nb) };
    });

    let message = `Règlement validé : ${bilan.installees} règle(s) en vigueur, capital de conduite fixé à ${capital} points.`;
    if (bilan.desactivees > 0) {
      message += ` ${bilan.desactivees} ancienne(s) règle(s) désactivée(s) — les incidents déjà saisis restent consultables.`;
    }
    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur validation règlement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** DELETE /discipline/reglement/:id — abandonne une proposition non validée. */
async function abandonnerProposition(req, res) {
  const { id } = req.params;
  try {
    const supprimees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `DELETE FROM reglements_discipline
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND statut = 'propose'`,
        [id]
      );
      return r.rowCount;
    });
    if (supprimees === 0) {
      return res.status(404).json({ message: "Proposition introuvable, ou déjà validée (une proposition validée s'archive, elle ne se supprime pas)." });
    }
    return res.json({ message: 'Proposition abandonnée.' });
  } catch (err) {
    console.error('Erreur abandon proposition:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /discipline/regles/:id — ajustement d'une règle unique, sans repasser
 * par tout le processus d'import.
 */
async function modifierRegle(req, res) {
  const { id } = req.params;
  const { libelle, points, mesure, categorie, actif } = req.body;

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const existante = await client.query(
        `SELECT code, libelle, sens FROM regles_discipline
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (existante.rows.length === 0) {
        throw Object.assign(new Error('Règle introuvable.'), { statusCode: 404 });
      }

      let pointsRetenus = null;
      if (points !== undefined && points !== null && points !== '') {
        pointsRetenus = Math.abs(Number(points));
        if (!Number.isFinite(pointsRetenus)) {
          throw Object.assign(new Error('Points invalides.'), { statusCode: 400 });
        }
        const capital = await client.query(
          `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
        );
        if (pointsRetenus > Number(capital.rows[0].capital)) {
          throw Object.assign(
            new Error(`Les points ne peuvent pas dépasser le capital de conduite (${capital.rows[0].capital}).`),
            { statusCode: 400 }
          );
        }
      }

      await client.query(
        `UPDATE regles_discipline
            SET libelle = COALESCE($2, libelle),
                points = COALESCE($3, points),
                mesure = COALESCE($4, mesure),
                categorie = COALESCE($5, categorie),
                actif = COALESCE($6, actif),
                -- Toute retouche humaine se déclare comme telle : on ne veut
                -- plus pouvoir croire que ces points viennent du règlement.
                origine_points = 'manuel',
                updated_at = now()
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [
          id,
          libelle ? String(libelle).trim() : null,
          pointsRetenus,
          MESURES.includes(mesure) ? mesure : null,
          categorie !== undefined ? (categorie ? String(categorie).trim() : null) : null,
          typeof actif === 'boolean' ? actif : null
        ]
      );

      return `Règle « ${libelle || existante.rows[0].libelle} » mise à jour.`;
    });
    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification règle:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  etatReglement,
  importerReglement,
  genererReglement,
  validerReglement,
  abandonnerProposition,
  modifierRegle,
  // exportés pour les tests
  normaliserProposition,
  codeDepuisLibelle
};
