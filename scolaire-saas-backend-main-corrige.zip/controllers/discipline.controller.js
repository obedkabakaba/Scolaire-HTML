const { runWithTenant } = require('../config/db');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { verifierPeriodeModifiable } = require('../utils/periode.utils');
const { verifierClasseActive } = require('../utils/annee.utils');
const {
  notifierEvenement, destinatairesParRole, planifierVidage
} = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const TYPES_NEGATIFS = ['retard', 'absence_injustifiee', 'indiscipline', 'bagarre', 'tricherie', 'degradation', 'tenue', 'autre'];
const TYPES_POSITIFS = ['entraide', 'effort', 'exemplarite', 'service_rendu', 'distinction'];

// Les deux familles forment UNE seule liste de types acceptés à la saisie.
// Auparavant, TYPES ne contenait que les fautes : l'écran proposait bien un
// groupe « Faits à valoriser » (il lit `types_positifs`), mais il le filtrait
// par `types.includes(...)` — donc le groupe sortait toujours vide, et une
// requête forgée à la main se serait vu répondre « Type d'incident inconnu ».
// La moitié valorisante du module était morte de ce seul oubli.
const TYPES = [...TYPES_NEGATIFS, ...TYPES_POSITIFS];

const MESURES = ['aucune', 'avertissement', 'convocation_parent', 'travail_supplementaire', 'exclusion_temporaire', 'conseil_discipline'];

// Barème indicatif : ces valeurs pré-remplissent le formulaire mais restent
// modifiables à chaque signalement, car la gravité dépend du contexte.
const POINTS_PAR_DEFAUT = {
  retard: 1, absence_injustifiee: 2, tenue: 1, indiscipline: 3,
  tricherie: 5, degradation: 5, bagarre: 6, autre: 2,
  // Faits positifs : ils ajoutent des points au lieu d'en retirer. Une école
  // qui ne sait que sanctionner passe à côté de la moitié de son rôle.
  entraide: 2, effort: 2, exemplarite: 3, service_rendu: 2, distinction: 4
};

function estPositif(type) { return TYPES_POSITIFS.includes(type); }

/**
 * Barème applicable à l'école : le sien s'il a été validé, celui du code
 * sinon.
 *
 * Tant qu'aucun règlement n'est validé, `regles_discipline` est vide et on
 * retombe sur les constantes ci-dessus — c'est ce qui permet d'installer cette
 * fonctionnalité sans changer le comportement d'une seule école existante.
 *
 * Les règles DÉSACTIVÉES sont chargées elles aussi, mais marquées : elles ne
 * doivent plus être proposées à la saisie, tout en restant lisibles pour
 * afficher correctement les incidents déjà enregistrés sous leur code.
 */
async function baremeEcole(client) {
  const r = await client.query(
    `SELECT code, libelle, sens, points, mesure, categorie, actif
     FROM regles_discipline
     WHERE ecole_id = ${CURRENT_ECOLE}
     ORDER BY sens DESC, ordre, libelle`
  );

  if (r.rows.length === 0) {
    return {
      personnalise: false,
      types: TYPES,
      types_positifs: TYPES_POSITIFS,
      points_par_defaut: POINTS_PAR_DEFAUT,
      regles: null
    };
  }

  const actives = r.rows.filter((x) => x.actif);
  const points = {};
  const mesures = {};
  for (const x of r.rows) {
    points[x.code] = Number(x.points);
    mesures[x.code] = x.mesure || 'aucune';
  }

  return {
    personnalise: true,
    // Les codes inactifs restent ACCEPTÉS à la validation d'un signalement en
    // cours de route, mais ne sont plus proposés : c'est `regles` qui alimente
    // le menu de l'écran.
    types: r.rows.map((x) => x.code),
    types_positifs: r.rows.filter((x) => x.sens === 'positif').map((x) => x.code),
    points_par_defaut: points,
    mesures_par_defaut: mesures,
    regles: actives.map((x) => ({
      code: x.code, libelle: x.libelle, sens: x.sens,
      points: Number(x.points), mesure: x.mesure, categorie: x.categorie
    }))
  };
}

// Rôles qui embrassent tout l'établissement en matière de discipline.
// `directeur_discipline` existait dans l'ENUM des rôles depuis la migration
// 008 mais n'était cité NULLE PART dans le code : un utilisateur portant ce
// rôle se voyait refuser l'accès à l'écran qu'il est censé tenir. L'école qui
// n'en nomme pas garde tout chez le directeur — d'où la présence des deux.
const AUTORITE_DISCIPLINE = ['directeur', 'prefet', 'directeur_discipline'];

function estAutoriteDiscipline(req) {
  return req.auth.isSuperAdmin || req.auth.roles.some((r) => AUTORITE_DISCIPLINE.includes(r));
}

/**
 * Le préfet est l'autorité disciplinaire de l'établissement : il voit et
 * signale partout. Le titulaire est limité à ses classes. Dans tous les cas,
 * la classe doit appartenir à l'année scolaire active : un incident d'une
 * ancienne année ne doit ni être consulté ni s'y ajouter depuis cet écran.
 */
async function verifierAccesClasse(client, req, classeId) {
  if (!estAutoriteDiscipline(req) && !req.auth.roles.some((r) => ['secretaire'].includes(r))) {
    const r = await client.query(`SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]);
    if (r.rows.length === 0) {
      throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
    }
  }
  await verifierClasseActive(client, classeId);
}

async function anneeActive(client) {
  const r = await client.query(
    `SELECT id, libelle FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
  );
  return r.rows[0] || null;
}

/**
 * Capital de conduite restant. Écrit UNE fois et appelé partout : l'écran de
 * consultation et le report sur bulletin appliquaient auparavant deux formules
 * différentes, ce qui laissait un enseignant lire « Très bonne » à l'écran et
 * voir « Mauvaise » s'imprimer sur le bulletin.
 *
 * Les faits positifs rattrapent des points perdus mais ne se capitalisent pas
 * au-delà du plafond : on peut redevenir irréprochable, pas devenir meilleur
 * qu'irréprochable.
 */
function capitalRestant(capital, perdus, gagnes) {
  return Math.min(Math.max(capital - perdus + gagnes, 0), capital);
}

/** Traduit un capital de conduite restant en appréciation de bulletin. */
function conduiteSuggeree(restant, capital) {
  if (!capital || capital <= 0) return null;
  const part = (restant / capital) * 100;
  if (part >= 90) return 'Très bonne';
  if (part >= 70) return 'Bonne';
  if (part >= 50) return 'Assez bonne';
  return 'Mauvaise';
}

/** GET /discipline/parametres */
async function parametres(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital_conduite FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const bareme = await baremeEcole(client);
      return {
        types_positifs: bareme.types_positifs,
        capital_conduite: Number(r.rows[0].capital_conduite),
        types: bareme.types,
        mesures: MESURES,
        points_par_defaut: bareme.points_par_defaut,
        mesures_par_defaut: bareme.mesures_par_defaut || null,
        // L'écran affiche les libellés de l'école quand elle en a. Sans ce
        // champ, il continuerait d'afficher « Tenue non conforme » alors que
        // le règlement dit « Négligence vestimentaire ».
        regles: bareme.regles,
        bareme_personnalise: bareme.personnalise,
        annee_active: await anneeActive(client)
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur paramètres discipline:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PUT /discipline/parametres */
async function enregistrerParametres(req, res) {
  const capital = Number(req.body.capital_conduite);
  if (!Number.isInteger(capital) || capital < 1 || capital > 100) {
    return res.status(400).json({ message: 'Le capital de conduite doit être un entier compris entre 1 et 100.' });
  }
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(`UPDATE ecoles SET capital_conduite = $1, updated_at = now() WHERE id = ${CURRENT_ECOLE}`, [capital])
    );
    return res.json({ message: `Capital de conduite fixé à ${capital} points.` });
  } catch (err) {
    console.error('Erreur paramètres discipline:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /discipline/incidents?classeId=&periodeId=&eleveId=
 */
async function listerIncidents(req, res) {
  const { classeId, periodeId, eleveId } = req.query;
  if (!classeId && !eleveId) {
    return res.status(400).json({ message: 'Précisez une classe ou un élève.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      let classeCible = classeId;
      if (!classeCible && eleveId) {
        const e = await client.query(`SELECT classe_id FROM eleves WHERE id = $1`, [eleveId]);
        if (e.rows.length === 0) throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
        classeCible = e.rows[0].classe_id;
      }
      await verifierAccesClasse(client, req, classeCible);

      const result = await client.query(
        `SELECT i.id, i.date_incident, i.type, i.points, i.description, i.mesure,
                i.sens, i.periode_id, p.libelle AS periode_libelle,
                e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                trim(concat(u.prenom, ' ', u.nom)) AS signale_par_nom
         FROM incidents_discipline i
         JOIN eleves e ON e.id = i.eleve_id
         LEFT JOIN periodes p ON p.id = i.periode_id
         LEFT JOIN utilisateurs u ON u.id = i.signale_par
         WHERE i.classe_id = $1
           AND ($2::uuid IS NULL OR i.periode_id = $2::uuid)
           AND ($3::uuid IS NULL OR i.eleve_id = $3::uuid)
         ORDER BY i.date_incident DESC, i.created_at DESC
         LIMIT 300`,
        [classeCible, periodeId || null, eleveId || null]
      );
      return result.rows.map((l) => ({ ...l, points: Number(l.points) }));
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste incidents:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /discipline/incidents */
async function signalerIncident(req, res) {
  const { eleve_id, date_incident, type, points, description, mesure, periode_id } = req.body;

  if (!eleve_id || !date_incident || !type) {
    return res.status(400).json({ message: 'Élève, date et type sont requis.' });
  }
  if (mesure && !MESURES.includes(mesure)) {
    return res.status(400).json({ message: 'Mesure inconnue.' });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date_incident))) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }
  if (points !== undefined && points !== null && points !== '' && !Number.isFinite(Number(points))) {
    return res.status(400).json({ message: 'Les points doivent être un nombre.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Le type et les points par défaut se lisent dans le barème de l'ÉCOLE
      // quand elle en a validé un. Cette vérification ne peut donc plus se
      // faire avant d'ouvrir une connexion, contrairement aux contrôles de
      // forme ci-dessus qui, eux, ne dépendent d'aucune donnée.
      const bareme = await baremeEcole(client);
      if (!bareme.types.includes(type)) {
        throw Object.assign(
          new Error(
            bareme.personnalise
              ? "Ce type de fait ne figure pas dans le règlement de votre école."
              : "Type d'incident inconnu."
          ),
          { statusCode: 400 }
        );
      }

      const pointsNum = points === undefined || points === null || points === ''
        ? Number(bareme.points_par_defaut[type] ?? 0)
        : Number(points);
      if (!Number.isFinite(pointsNum) || pointsNum < 0) {
        throw Object.assign(
          new Error('Les points doivent être un nombre positif.'), { statusCode: 400 }
        );
      }

      const positif = bareme.types_positifs.includes(type);

      const eleveResult = await client.query(
        `SELECT id, classe_id, nom, postnom, prenom FROM eleves WHERE id = $1 AND statut = 'actif'`,
        [eleve_id]
      );
      if (eleveResult.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable ou inactif.'), { statusCode: 404 });
      }
      const eleve = eleveResult.rows[0];
      await verifierAccesClasse(client, req, eleve.classe_id);

      const annee = await anneeActive(client);
      if (!annee) throw Object.assign(new Error('Aucune année scolaire active.'), { statusCode: 409 });

      // Le plafond dépend du barème de l'école : une conduite notée sur 100
      // doit pouvoir supporter un retrait supérieur à 20 points.
      const capitalResult = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const capital = Number(capitalResult.rows[0].capital);
      if (pointsNum > capital) {
        throw Object.assign(
          new Error(`Les points retirés ne peuvent pas dépasser le capital de conduite de l'école (${capital}).`),
          { statusCode: 400 }
        );
      }

      // Rattachement automatique à la période dont la date encadre l'incident :
      // sans lui, le calcul de conduite par période serait impossible.
      let periode = periode_id || null;
      if (!periode) {
        const p = await client.query(
          `SELECT id FROM periodes
           WHERE annee_scolaire_id = $1 AND type IN ('periode','examen')
             AND date_debut <= $2::date AND (date_fin IS NULL OR date_fin >= $2::date)
           ORDER BY numero LIMIT 1`,
          [annee.id, date_incident]
        );
        periode = p.rows[0]?.id || null;
      }

      await client.query(
        `INSERT INTO incidents_discipline
           (ecole_id, eleve_id, classe_id, annee_scolaire_id, periode_id, date_incident, type, points, description, mesure, signale_par, sens)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [eleve.id, eleve.classe_id, annee.id, periode, date_incident, type,
         pointsNum, (description || '').trim() || null,
         // La mesure habituelle vient du règlement de l'école quand elle n'est
         // pas précisée à la saisie : c'est ce que le directeur a défini pour
         // cette faute, pas un choix par défaut du logiciel.
         mesure || (positif ? 'aucune' : (bareme.mesures_par_defaut?.[type] || 'aucune')),
         req.auth.userId,
         positif ? 'positif' : 'negatif']
      );

      // ------------------------------------------------------------------
      // Prévenir la famille pendant qu'il est encore temps d'en parler
      // ------------------------------------------------------------------
      // Un fait disciplinaire ne se découvrait qu'au bulletin, sous la forme
      // d'une conduite dégradée sans explication. Le parent apprenait à la
      // fois la faute et sa sanction, des mois après, sans avoir eu la
      // moindre occasion d'intervenir.
      //
      // Deux règles :
      //   • Seuls les faits NÉGATIFS partent par e-mail. Écrire pour chaque
      //     bon point transformerait le message en bruit, et le jour où un
      //     vrai problème arrive, plus personne ne l'ouvre.
      //   • Un fait à 0 point (simple observation consignée) ne déclenche
      //     rien non plus : ce n'est pas une nouvelle pour la famille.
      //
      // Le capital restant est calculé et transmis : « −3 points » ne dit
      // rien à un parent, « il reste 12 points sur 20 » situe la gravité.
      if (!positif && pointsNum > 0) {
        const contact = await client.query(
          `SELECT el.responsable_email, el.responsable_nom,
                  cl.nom AS classe, e.nom AS ecole
             FROM eleves el
             JOIN ecoles e ON e.id = el.ecole_id
             LEFT JOIN classes cl ON cl.id = el.classe_id
            WHERE el.id = $1`,
          [eleve.id]
        );
        const infos = contact.rows[0] || {};

        // Bilan de l'année : ce qui a été perdu et regagné jusqu'ici,
        // incident du jour compris (il vient d'être inséré).
        const bilan = await client.query(
          `SELECT COALESCE(SUM(points) FILTER (WHERE sens = 'negatif'), 0) AS perdus,
                  COALESCE(SUM(points) FILTER (WHERE sens = 'positif'), 0) AS gagnes
             FROM incidents_discipline
            WHERE eleve_id = $1 AND annee_scolaire_id = $2`,
          [eleve.id, annee.id]
        );
        const restant = capitalRestant(
          capital,
          Number(bilan.rows[0].perdus),
          Number(bilan.rows[0].gagnes)
        );

        const nomEleve = [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' ');

        if (infos.responsable_email) {
          await notifierEvenement(client, {
            evenement: 'discipline.incident',
            destinataires: [{ email: infos.responsable_email, nom: infos.responsable_nom }],
            expediteurId: req.auth.userId,
            visibleInterface: false,
            donnees: {
              eleve: nomEleve,
              classe: infos.classe,
              ecole: infos.ecole,
              type,
              date: date_incident,
              points: pointsNum,
              mesure: mesure || bareme.mesures_par_defaut?.[type] || null,
              description: (description || '').trim() || null,
              capital,
              capitalRestant: restant
            }
          });
        }

        // La direction est alertée quand la conduite devient critique —
        // sous 50 % du capital, c'est-à-dire au seuil où l'appréciation
        // bascule en « Mauvaise ». C'est le moment de convoquer, pas le
        // conseil de classe de fin de période.
        if (capital > 0 && restant < capital * 0.5) {
          await notifierEvenement(client, {
            evenement: 'discipline.conduite_critique',
            destinataires: await destinatairesParRole(
              client, ['directeur', 'prefet', 'directeur_discipline']
            ),
            expediteurId: req.auth.userId,
            donnees: {
              eleve: nomEleve, classe: infos.classe, restant, capital
            },
            // Une alerte par élève et par période : sans cette clé, chaque
            // nouvel incident d'un élève déjà en difficulté rouvrirait la
            // même alerte, et la direction cesserait de les lire.
            cleUnicite: `conduite_critique:${eleve.id}:${periode || annee.id}`
          });
        }
      }

      return {
        nom: [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '),
        positif,
        points: pointsNum
      };
    });
    // Annoncer « −3 points » après avoir enregistré une exemplarité serait un
    // contresens visible par l'enseignant : le signe suit le sens du fait.
    planifierVidage();

    const message = resultat.positif
      ? `Fait à valoriser enregistré pour ${resultat.nom} (+${resultat.points} point(s)).`
      : `Incident enregistré pour ${resultat.nom} (−${resultat.points} point(s)).`;
    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur signalement incident:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** DELETE /discipline/incidents/:id */
async function supprimerIncident(req, res) {
  const { id } = req.params;
  try {
    const supprimes = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const incident = await client.query(`SELECT classe_id FROM incidents_discipline WHERE id = $1`, [id]);
      if (incident.rows.length === 0) return 0;
      await verifierAccesClasse(client, req, incident.rows[0].classe_id);
      const r = await client.query(`DELETE FROM incidents_discipline WHERE id = $1`, [id]);
      return r.rowCount;
    });
    if (supprimes === 0) return res.status(404).json({ message: 'Incident introuvable.' });
    return res.json({ message: 'Incident supprimé.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur suppression incident:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /discipline/conduite?classeId=&periodeId=
 * Capital restant et appréciation suggérée pour chaque élève de la classe.
 */
async function conduiteClasse(req, res) {
  const { classeId, periodeId } = req.query;
  if (!classeId) return res.status(400).json({ message: 'classeId est requis.' });

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);

      const ecoleResult = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const capital = Number(ecoleResult.rows[0].capital);

      const result = await client.query(
        `SELECT e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                COALESCE(SUM(i.points) FILTER (WHERE i.sens IS DISTINCT FROM 'positif'), 0) AS points_perdus,
                COALESCE(SUM(i.points) FILTER (WHERE i.sens = 'positif'), 0) AS points_gagnes,
                count(i.id) FILTER (WHERE i.sens = 'positif') AS nb_positifs,
                count(i.id) AS nb_incidents
         FROM eleves e
         LEFT JOIN incidents_discipline i
           ON i.eleve_id = e.id
          AND ($2::uuid IS NULL OR i.periode_id = $2::uuid)
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         GROUP BY e.id, e.matricule, e.nom, e.postnom, e.prenom
         ORDER BY e.nom, e.postnom, e.prenom`,
        [classeId, periodeId || null]
      );

      return {
        capital_conduite: capital,
        eleves: result.rows.map((l) => {
          const perdus = Number(l.points_perdus);
          const gagnes = Number(l.points_gagnes);
          const restant = capitalRestant(capital, perdus, gagnes);
          return {
            eleve_id: l.eleve_id, matricule: l.matricule,
            nom: l.nom, postnom: l.postnom, prenom: l.prenom,
            nb_incidents: Number(l.nb_incidents) - Number(l.nb_positifs),
            nb_positifs: Number(l.nb_positifs),
            points_perdus: perdus,
            points_gagnes: gagnes,
            points_restants: restant,
            conduite_suggeree: conduiteSuggeree(restant, capital)
          };
        })
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur conduite classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /discipline/conduite/appliquer
 * Reporte les appréciations calculées sur les bulletins de la période.
 * Réservé au directeur et au préfet : ce sont les seuls habilités à fixer
 * la conduite, exactement comme dans l'écran Bulletins.
 */
async function appliquerConduite(req, res) {
  const { classe_id, periode_id, ecraser } = req.body;
  if (!classe_id || !periode_id) {
    return res.status(400).json({ message: 'classe_id et periode_id sont requis.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierClasseActive(client, classe_id);

      // La conduite est écrite dans la table `bulletins`, exactement comme les
      // notes. Elle doit donc respecter le MÊME verrou : sans cela, un Préfet
      // clôturait une période, constatait que les notes se figeaient — et le
      // report de conduite continuait pourtant d'écrire dessus.
      await verifierPeriodeModifiable(client, periode_id, 'conduite');

      const ecoleResult = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const capital = Number(ecoleResult.rows[0].capital);

      // Un bulletin créé ici sans année scolaire serait invisible dans les
      // Archives (qui filtrent par année) : on la déduit de la période plutôt
      // que de laisser la colonne à NULL.
      const periodeResult = await client.query(
        `SELECT annee_scolaire_id FROM periodes WHERE id = $1`, [periode_id]
      );
      if (periodeResult.rows.length === 0) {
        throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
      }
      const anneeId = periodeResult.rows[0].annee_scolaire_id;

      // Même agrégat que l'écran « Conduite » : les faits positifs REGAGNENT
      // des points. Auparavant cette requête sommait indistinctement tous les
      // points, si bien qu'un élève félicité pour son exemplarité voyait sa
      // conduite BAISSER — et l'appréciation reportée sur le bulletin pouvait
      // contredire celle affichée à l'écran juste avant de cliquer.
      const result = await client.query(
        `SELECT e.id AS eleve_id,
                COALESCE(SUM(i.points) FILTER (WHERE i.sens IS DISTINCT FROM 'positif'), 0) AS perdus,
                COALESCE(SUM(i.points) FILTER (WHERE i.sens = 'positif'), 0) AS gagnes
         FROM eleves e
         LEFT JOIN incidents_discipline i ON i.eleve_id = e.id AND i.periode_id = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         GROUP BY e.id`,
        [classe_id, periode_id]
      );

      let ecrits = 0;
      let ignores = 0;

      for (const ligne of result.rows) {
        const restant = capitalRestant(capital, Number(ligne.perdus), Number(ligne.gagnes));
        const appreciation = conduiteSuggeree(restant, capital);
        if (!appreciation) continue;

        // Un bulletin déjà signé n'est jamais réécrit, et une conduite saisie
        // à la main est préservée sauf demande explicite d'écrasement.
        const r = await client.query(
          `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, annee_scolaire_id, conduite)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4)
           ON CONFLICT (eleve_id, periode_id)
           DO UPDATE SET conduite = EXCLUDED.conduite
           WHERE bulletins.signe_at IS NULL
             AND ($5::bool = true OR bulletins.conduite IS NULL)`,
          [ligne.eleve_id, periode_id, anneeId, appreciation, ecraser === true]
        );
        if (r.rowCount > 0) ecrits++; else ignores++;
      }
      return { ecrits, ignores };
    });

    const complement = bilan.ignores > 0
      ? ` (${bilan.ignores} bulletin(s) ignoré(s) : déjà signés ou conduite déjà saisie)`
      : '';
    return res.json({ message: `${bilan.ecrits} conduite(s) reportée(s)${complement}.` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur application conduite:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /discipline/resume?debut=&fin=
 * Vue école : volume d'incidents par type et classes les plus concernées.
 */
async function resume(req, res) {
  const debut = req.query.debut;
  const fin = req.query.fin;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(debut)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(fin))) {
    return res.status(400).json({ message: 'Dates invalides. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Toutes les agrégations ci-dessous distinguent le sens : additionner
      // une bagarre et une entraide sous l'étiquette « incidents » donnerait
      // une lecture fausse du climat de l'établissement, et un classement des
      // classes « les plus concernées » où une classe exemplaire remonterait
      // en tête pour de mauvaises raisons.
      // Le cycle se lit sur la CLASSE de l'incident : la table des incidents
      // n'en porte pas, mais elle porte classe_id, ce qui suffit. Sans ce
      // filtre, une école qui a choisi « primaire » verrait le climat de ses
      // humanités compté dans ses totaux.
      const cycle = cycleDemande(req);
      const jointureCycle = cycle
        ? `AND EXISTS (SELECT 1 FROM classes cx WHERE cx.id = incidents_discipline.classe_id
                        AND (cx.cycle IS NULL OR cx.cycle::text = $3))`
        : '';
      const paramsCycle = cycle ? [debut, fin, cycle] : [debut, fin];

      const parType = await client.query(
        `SELECT type, sens, count(*) AS nb FROM incidents_discipline
         WHERE ecole_id = ${CURRENT_ECOLE} AND date_incident BETWEEN $1 AND $2
         ${jointureCycle}
         GROUP BY type, sens ORDER BY nb DESC`,
        paramsCycle
      );
      const parClasse = await client.query(
        `SELECT c.nom AS classe_nom,
                count(i.id) FILTER (WHERE i.sens IS DISTINCT FROM 'positif') AS nb,
                count(i.id) FILTER (WHERE i.sens = 'positif') AS nb_positifs,
                COALESCE(SUM(i.points) FILTER (WHERE i.sens IS DISTINCT FROM 'positif'), 0) AS points
         FROM incidents_discipline i
         JOIN classes c ON c.id = i.classe_id
         WHERE i.ecole_id = ${CURRENT_ECOLE} AND i.date_incident BETWEEN $1 AND $2
           ${cycle ? `AND ${conditionCycle('c', 3)}` : ''}
         GROUP BY c.nom
         ORDER BY nb DESC LIMIT 10`,
        paramsCycle
      );
      const total = await client.query(
        `SELECT count(*) FILTER (WHERE sens IS DISTINCT FROM 'positif') AS nb,
                count(*) FILTER (WHERE sens = 'positif') AS nb_positifs,
                count(DISTINCT eleve_id) FILTER (WHERE sens IS DISTINCT FROM 'positif') AS eleves,
                count(DISTINCT eleve_id) FILTER (WHERE sens = 'positif') AS eleves_positifs
         FROM incidents_discipline
         WHERE ecole_id = ${CURRENT_ECOLE} AND date_incident BETWEEN $1 AND $2
         ${jointureCycle}`,
        paramsCycle
      );
      return {
        debut, fin,
        total_incidents: Number(total.rows[0].nb),
        total_positifs: Number(total.rows[0].nb_positifs),
        eleves_concernes: Number(total.rows[0].eleves),
        eleves_valorises: Number(total.rows[0].eleves_positifs),
        par_type: parType.rows.map((l) => ({
          type: l.type, sens: l.sens, nb: Number(l.nb)
        })),
        par_classe: parClasse.rows.map((l) => ({
          classe_nom: l.classe_nom,
          nb: Number(l.nb),
          nb_positifs: Number(l.nb_positifs),
          points: Number(l.points)
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur résumé discipline:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /discipline/eleves/:eleveId/historique
 *
 * Historique COMPLET d'un élève : toutes années, toutes classes, tous
 * signalants confondus. C'est la demande explicite formulée pour le rôle
 * `directeur_discipline` — il doit voir ce qu'un professeur a saisi l'an
 * dernier dans une autre classe, sinon il ne peut pas juger d'une récidive.
 *
 * Cette vue échappe donc volontairement au cantonnement à l'année active qui
 * s'applique partout ailleurs dans le module (`verifierAccesClasse`). C'est
 * assumé : une décision disciplinaire se prend au vu d'un parcours, pas d'un
 * trimestre. En contrepartie, l'accès est réservé à l'autorité disciplinaire —
 * un titulaire n'y a droit que pour les élèves de SA classe et pour l'année
 * en cours, car rien ne justifie qu'il consulte le passé d'un élève qui n'est
 * pas le sien.
 */
async function historiqueEleve(req, res) {
  const { eleveId } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleveResult = await client.query(
        `SELECT e.id, e.matricule, e.nom, e.postnom, e.prenom, e.classe_id,
                c.nom AS classe_nom
         FROM eleves e
         LEFT JOIN classes c ON c.id = e.classe_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [eleveId]
      );
      if (eleveResult.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      const eleve = eleveResult.rows[0];

      // Portée : totale pour l'autorité disciplinaire, limitée à sa propre
      // classe et à l'année active pour un titulaire.
      const complet = estAutoriteDiscipline(req);
      if (!complet) {
        await verifierAccesClasse(client, req, eleve.classe_id);
      }

      const capitalResult = await client.query(
        `SELECT COALESCE(capital_conduite, 20) AS capital FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const capital = Number(capitalResult.rows[0].capital);

      const annee = await anneeActive(client);

      const incidents = await client.query(
        `SELECT i.id, i.date_incident, i.type, i.sens, i.points, i.description, i.mesure,
                i.classe_id, cl.nom AS classe_nom,
                i.annee_scolaire_id, a.libelle AS annee_libelle,
                i.periode_id, p.libelle AS periode_libelle,
                trim(concat(u.prenom, ' ', u.nom)) AS signale_par_nom
         FROM incidents_discipline i
         LEFT JOIN classes cl ON cl.id = i.classe_id
         LEFT JOIN annees_scolaires a ON a.id = i.annee_scolaire_id
         LEFT JOIN periodes p ON p.id = i.periode_id
         LEFT JOIN utilisateurs u ON u.id = i.signale_par
         WHERE i.ecole_id = ${CURRENT_ECOLE} AND i.eleve_id = $1
           AND ($2::bool = true OR i.annee_scolaire_id = $3::uuid)
         ORDER BY i.date_incident DESC, i.created_at DESC
         LIMIT 500`,
        [eleveId, complet, annee ? annee.id : null]
      );

      // Un bilan PAR ANNÉE : c'est la lecture qui rend la récidive visible.
      // Un élève à 3 bagarres réparties sur trois ans ne se lit pas comme un
      // élève à 3 bagarres en un trimestre.
      const parAnnee = new Map();
      for (const i of incidents.rows) {
        const cle = i.annee_scolaire_id || 'sans_annee';
        if (!parAnnee.has(cle)) {
          parAnnee.set(cle, {
            annee_scolaire_id: i.annee_scolaire_id,
            annee_libelle: i.annee_libelle || 'Année non renseignée',
            nb_fautes: 0, nb_positifs: 0, points_perdus: 0, points_gagnes: 0
          });
        }
        const bilan = parAnnee.get(cle);
        if (i.sens === 'positif') {
          bilan.nb_positifs++;
          bilan.points_gagnes += Number(i.points);
        } else {
          bilan.nb_fautes++;
          bilan.points_perdus += Number(i.points);
        }
      }

      const bilans = [...parAnnee.values()].map((b) => ({
        ...b,
        points_restants: capitalRestant(capital, b.points_perdus, b.points_gagnes),
        conduite_suggeree: conduiteSuggeree(
          capitalRestant(capital, b.points_perdus, b.points_gagnes), capital
        )
      }));

      return {
        eleve: {
          id: eleve.id, matricule: eleve.matricule,
          nom: eleve.nom, postnom: eleve.postnom, prenom: eleve.prenom,
          nom_complet: [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '),
          classe_nom: eleve.classe_nom
        },
        capital_conduite: capital,
        portee_complete: complet,
        bilans_par_annee: bilans,
        incidents: incidents.rows.map((i) => ({ ...i, points: Number(i.points) }))
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur historique discipline:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  parametres,
  enregistrerParametres,
  listerIncidents,
  signalerIncident,
  supprimerIncident,
  conduiteClasse,
  appliquerConduite,
  resume,
  historiqueEleve
};
