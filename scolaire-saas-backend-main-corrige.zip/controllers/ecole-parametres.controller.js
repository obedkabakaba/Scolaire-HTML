const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /ecole/moi
 */
async function obtenirEcoleCourante(req, res) {
  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const ecoleResult = await client.query(`SELECT * FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const ecole = ecoleResult.rows[0];
      if (!ecole) return null;

      // Droit personnel de générer les bulletins, pour l'utilisateur CONNECTÉ précisément
      // (évite d'exposer la liste complète des titulaires autorisés à tout le monde).
      let mesDroitsBulletins = req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
      if (!mesDroitsBulletins && req.auth.roles.includes('titulaire')) {
        if (ecole.autoriser_bulletins_titulaires) {
          if (ecole.bulletins_titulaires_mode === 'tous') {
            mesDroitsBulletins = true;
          } else {
            const autorisationResult = await client.query(
              `SELECT 1 FROM titulaires_generation_autorises WHERE ecole_id = ${CURRENT_ECOLE} AND utilisateur_id = $1`,
              [req.auth.userId]
            );
            mesDroitsBulletins = autorisationResult.rows.length > 0;
          }
        }
      }

      return { ...ecole, mes_droits_bulletins: mesDroitsBulletins };
    });

    return res.json(resultat);
  } catch (err) {
    console.error('Erreur lecture école courante:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /ecole/moi  (Directeur uniquement)
 * body: n'importe quel sous-ensemble des champs modifiables de l'école
 */
async function modifierEcoleCourante(req, res) {
  const {
    nom, adresse, telephone, email, province, ville, type_enseignement,
    nb_periodes, nb_trimestres, nb_semestres, max_par_cours_defaut, systeme_notation,
    seuil_promotion_pourcentage, autoriser_bulletins_titulaires, bulletins_titulaires_mode,
    autoriser_titulaire_multi_classes, autoriser_modif_apres_signature,
    mode_presences, commune,
    devise_principale, taux_change_usd_fc,
    seuil_redoublement_pourcentage, sortie_auto_sans_notes
  } = req.body;

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      // ---------- Changement du type d'enseignement ----------
      // Rétrécir le type (« les_deux » -> « primaire », par exemple) rendrait
      // orphelines toutes les classes du cycle exclu : elles resteraient en
      // base, invisibles dans les écrans filtrés par cycle, avec leurs élèves,
      // leurs notes et leurs bulletins devenus inatteignables. On refuse tant
      // que ces classes existent, en disant lesquelles.
      //
      // L'élargissement (« primaire » -> « les_deux ») ne pose aucun problème
      // et reste toujours autorisé : c'est le cas d'une école qui ouvre un
      // nouveau cycle.
      if (type_enseignement && type_enseignement !== 'les_deux') {
        const cycleExclu = type_enseignement === 'primaire' ? 'secondaire' : 'primaire';
        const classesResult = await client.query(
          `SELECT c.nom, a.libelle AS annee
             FROM classes c
             LEFT JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
            WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.cycle::text = $1
            ORDER BY a.date_debut DESC NULLS LAST, c.nom
            LIMIT 10`,
          [cycleExclu]
        );

        if (classesResult.rows.length > 0) {
          const exemples = classesResult.rows
            .map((c) => `${c.nom}${c.annee ? ` (${c.annee})` : ''}`)
            .join(', ');
          throw Object.assign(
            new Error(`Impossible de passer cette école en « ${type_enseignement} » : des classes du ${cycleExclu} existent encore — ${exemples}. Supprimez-les ou archivez leur année scolaire avant de restreindre le type d'enseignement.`),
            { statusCode: 409 }
          );
        }
      }

      // Le mode pilote qui peut faire l'appel : une valeur inconnue passerait
      // la contrainte CHECK en erreur SQL brute, illisible pour l'utilisateur.
      const MODES = ['titulaire', 'professeur', 'charge'];
      if (mode_presences && !MODES.includes(mode_presences)) {
        throw Object.assign(
          new Error(`Mode de saisie des présences inconnu : « ${mode_presences} ». Valeurs acceptées : ${MODES.join(', ')}.`),
          { statusCode: 400 }
        );
      }
      const modeValide = mode_presences || null;

      // ---------- Seuils de fin d'année ----------
      // `seuil_promotion_pourcentage` disait déjà à partir de quand on passe.
      // Rien ne distinguait REDOUBLER de QUITTER : un élève à 45 % redouble,
      // un élève à 12 % n'a manifestement pas suivi l'année et relève d'une
      // autre décision. Le manuel de configuration promettait ce réglage.
      let seuilRedoublement = null;
      if (seuil_redoublement_pourcentage !== undefined && seuil_redoublement_pourcentage !== null
          && seuil_redoublement_pourcentage !== '') {
        seuilRedoublement = Number(seuil_redoublement_pourcentage);
        if (!Number.isFinite(seuilRedoublement) || seuilRedoublement < 0 || seuilRedoublement > 100) {
          throw Object.assign(
            new Error('Le seuil de redoublement doit être un pourcentage entre 0 et 100.'),
            { statusCode: 400 }
          );
        }

        // Cohérence entre les deux seuils. Un seuil de redoublement au-dessus
        // du seuil de promotion créerait une zone où l'élève ne passe ni ne
        // redouble : la plateforme ne saurait plus quoi décider, et l'erreur
        // ne se verrait qu'en fin d'année, au pire moment.
        const actuel = await client.query(
          `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS promotion FROM ecoles WHERE id = ${CURRENT_ECOLE}`
        );
        const promotion = seuil_promotion_pourcentage !== undefined
            && seuil_promotion_pourcentage !== null && seuil_promotion_pourcentage !== ''
          ? Number(seuil_promotion_pourcentage)
          : Number(actuel.rows[0].promotion);

        if (seuilRedoublement >= promotion) {
          throw Object.assign(
            new Error(
              `Le seuil de redoublement (${seuilRedoublement} %) doit être INFÉRIEUR au seuil de `
              + `promotion (${promotion} %). Sinon, un élève situé entre les deux ne passerait `
              + `ni ne redoublerait.`
            ),
            { statusCode: 400 }
          );
        }
      }

      // ---------- Devise et taux de change ----------
      // Ces deux colonnes existent depuis la migration 001 et sont LUES par
      // tout le module financier (`devise.utils.js`), mais rien ne les écrivait :
      // aucun écran, aucun endpoint. Une école travaillant en deux devises ne
      // pouvait donc pas déclarer son taux, et les conversions se faisaient sur
      // une valeur nulle. Le guide de configuration décrivait pourtant cette
      // étape — d'où l'incohérence signalée entre le manuel et la plateforme.
      let deviseValide = null;
      if (devise_principale !== undefined && devise_principale !== null) {
        if (!['FC', 'USD'].includes(devise_principale)) {
          throw Object.assign(
            new Error("Devise principale invalide : choisissez FC ou USD."),
            { statusCode: 400 }
          );
        }
        deviseValide = devise_principale;
      }

      let tauxValide = null;
      let effacerTaux = false;
      if (taux_change_usd_fc !== undefined) {
        if (taux_change_usd_fc === null || taux_change_usd_fc === '') {
          // Effacement explicite : l'école cesse de travailler en deux devises.
          // COALESCE ne permet pas d'écrire NULL, d'où l'indicateur séparé.
          effacerTaux = true;
        } else {
          tauxValide = Number(taux_change_usd_fc);
          if (!Number.isFinite(tauxValide) || tauxValide <= 0) {
            throw Object.assign(
              new Error("Le taux de change doit être un nombre strictement positif (combien de FC pour 1 USD)."),
              { statusCode: 400 }
            );
          }
          // Garde-fou de saisie : un taux à 3 ou à 300 000 est presque
          // toujours une erreur de frappe, et il fausserait silencieusement
          // toutes les conversions de frais et de paiements.
          if (tauxValide < 100 || tauxValide > 100000) {
            throw Object.assign(
              new Error(
                `Taux inhabituel (${tauxValide} FC pour 1 USD). Vérifiez la saisie : `
                + `le taux attendu est le nombre de francs congolais pour un dollar.`
              ),
              { statusCode: 400 }
            );
          }
        }
      }

      return client.query(
        `UPDATE ecoles SET
           nom = COALESCE($1, nom), adresse = COALESCE($2, adresse), telephone = COALESCE($3, telephone),
           email = COALESCE($4, email), province = COALESCE($5, province), ville = COALESCE($6, ville),
           type_enseignement = COALESCE($7, type_enseignement), nb_periodes = COALESCE($8, nb_periodes),
           nb_trimestres = COALESCE($9, nb_trimestres), nb_semestres = COALESCE($10, nb_semestres),
           max_par_cours_defaut = COALESCE($11, max_par_cours_defaut),
           systeme_notation = COALESCE($12, systeme_notation),
           seuil_promotion_pourcentage = COALESCE($13, seuil_promotion_pourcentage),
           autoriser_bulletins_titulaires = COALESCE($14, autoriser_bulletins_titulaires),
           bulletins_titulaires_mode = COALESCE($15, bulletins_titulaires_mode),
           autoriser_titulaire_multi_classes = COALESCE($16, autoriser_titulaire_multi_classes),
           autoriser_modif_apres_signature = COALESCE($17, autoriser_modif_apres_signature),
           mode_presences = COALESCE($18, mode_presences),
           -- La commune apparaît sur l'en-tête des bulletins officiels
           -- (« COMMUNE / TER. ») mais n'était modifiable nulle part : elle
           -- s'imprimait donc toujours vide.
           commune = COALESCE($19, commune),
           devise_principale = COALESCE($20, devise_principale),
           -- Le taux, sa date et son auteur bougent ENSEMBLE : un taux sans
           -- date ne dit pas s'il est d'aujourd'hui ou de l'an dernier, et la
           -- conversion d'un paiement en dépend.
           taux_change_usd_fc = CASE WHEN $22::bool THEN NULL
                                     ELSE COALESCE($21, taux_change_usd_fc) END,
           taux_change_maj_at = CASE WHEN $22::bool OR $21 IS NOT NULL THEN now()
                                     ELSE taux_change_maj_at END,
           taux_change_maj_par = CASE WHEN $22::bool OR $21 IS NOT NULL THEN $23::uuid
                                      ELSE taux_change_maj_par END,
           seuil_redoublement_pourcentage = COALESCE($24, seuil_redoublement_pourcentage),
           sortie_auto_sans_notes = COALESCE($25, sortie_auto_sans_notes),
           updated_at = now()
         WHERE id = ${CURRENT_ECOLE}`,
        [nom, adresse, telephone, email, province, ville, type_enseignement,
         nb_periodes, nb_trimestres, nb_semestres, max_par_cours_defaut,
         systeme_notation ? JSON.stringify(systeme_notation) : null, seuil_promotion_pourcentage,
         autoriser_bulletins_titulaires, bulletins_titulaires_mode, autoriser_titulaire_multi_classes,
         autoriser_modif_apres_signature, modeValide, commune || null,
         deviseValide, tauxValide, effacerTaux, req.auth.userId,
         seuilRedoublement,
         typeof sortie_auto_sans_notes === 'boolean' ? sortie_auto_sans_notes : null]
      );
    });
    return res.json({ message: 'Paramètres mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification école courante:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /ecole/titulaires  (Directeur/Préfet)
 * Liste tous les titulaires de l'école, avec un indicateur "autorise_generation"
 * (utile pour l'écran Paramètres, mode "certains titulaires").
 */
async function listerTitulairesAvecAutorisation(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(`
        SELECT u.id, u.nom, u.prenom, u.email,
               (tga.id IS NOT NULL) AS autorise_generation
        FROM utilisateurs u
        JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id AND ur.role = 'titulaire'
        LEFT JOIN titulaires_generation_autorises tga ON tga.utilisateur_id = u.id AND tga.ecole_id = ${CURRENT_ECOLE}
        WHERE u.ecole_id = ${CURRENT_ECOLE}
        ORDER BY u.nom
      `)
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste titulaires:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /ecole/titulaires-autorises  (Directeur/Préfet)
 * body: { utilisateur_ids: [...] }
 * Remplace entièrement la liste des titulaires autorisés à générer les bulletins
 * (pertinent uniquement quand bulletins_titulaires_mode = 'certains').
 */
async function definirTitulairesAutorises(req, res) {
  const { utilisateur_ids } = req.body;
  if (!Array.isArray(utilisateur_ids)) {
    return res.status(400).json({ message: 'utilisateur_ids (tableau) requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      await client.query(`DELETE FROM titulaires_generation_autorises WHERE ecole_id = ${CURRENT_ECOLE}`);
      for (const utilisateurId of utilisateur_ids) {
        await client.query(
          `INSERT INTO titulaires_generation_autorises (ecole_id, utilisateur_id) VALUES (${CURRENT_ECOLE}, $1)`,
          [utilisateurId]
        );
      }
    });
    return res.json({ message: 'Liste des titulaires autorisés mise à jour.' });
  } catch (err) {
    console.error('Erreur définition titulaires autorisés:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  obtenirEcoleCourante, modifierEcoleCourante,
  listerTitulairesAvecAutorisation, definirTitulairesAutorises
};
