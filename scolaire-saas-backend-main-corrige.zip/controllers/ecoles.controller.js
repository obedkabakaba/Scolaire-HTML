const { runWithTenant } = require('../config/db');
const { hashPassword } = require('../utils/password.utils');
const crypto = require('crypto');

/**
 * POST /admin/ecoles  (Super Admin uniquement)
 * Crée une école + son abonnement initial + le premier compte Directeur.
 * body: { nom, code, email, telephone, adresse, province, ville, type_enseignement, plan_id, directeur: { nom, prenom, email, password } }
 */
async function creerEcole(req, res) {
  const {
    nom, code, email, telephone, adresse, province, ville,
    type_enseignement, plan_id, directeur
  } = req.body;

  if (!nom || !code || !plan_id || !directeur?.email || !directeur?.password) {
    return res.status(400).json({ message: 'Champs requis manquants (nom, code, plan_id, directeur.email, directeur.password).' });
  }

  try {
    const result = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecoleResult = await client.query(
        `INSERT INTO ecoles (nom, code, email, telephone, adresse, province, ville, type_enseignement)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         RETURNING id`,
        [nom, code, email, telephone, adresse, province, ville, type_enseignement || 'les_deux']
      );
      const ecoleId = ecoleResult.rows[0].id;

      const planResult = await client.query(
        'SELECT duree_jours FROM plans_abonnement WHERE id = $1',
        [plan_id]
      );
      if (planResult.rows.length === 0) {
        throw new Error('Plan d\'abonnement introuvable.');
      }
      const dureeJours = planResult.rows[0].duree_jours;
      const dateDebut = new Date();
      const dateExpiration = new Date(dateDebut.getTime() + dureeJours * 24 * 60 * 60 * 1000);

      const abonnementResult = await client.query(
        `INSERT INTO abonnements (ecole_id, plan_id, statut, date_debut, date_expiration, en_periode_essai)
         VALUES ($1,$2,'en_attente',$3,$4,true)
         RETURNING id`,
        [ecoleId, plan_id, dateDebut, dateExpiration]
      );

      const motDePasseHash = await hashPassword(directeur.password);
      const directeurResult = await client.query(
        `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, mot_de_passe_hash)
         VALUES ($1,$2,$3,$4,$5)
         RETURNING id`,
        [ecoleId, directeur.nom || nom, directeur.prenom || '', directeur.email, motDePasseHash]
      );
      const directeurId = directeurResult.rows[0].id;

      await client.query(
        `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, 'directeur')`,
        [directeurId]
      );

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id)
         VALUES ($1, NULL, 'ecole.creee', 'ecole', $1)`,
        [ecoleId]
      );

      return { ecoleId, abonnementId: abonnementResult.rows[0].id, directeurId };
    });

    return res.status(201).json({
      message: 'École créée avec succès.',
      ecole_id: result.ecoleId,
      abonnement_id: result.abonnementId,
      directeur_id: result.directeurId
    });
  } catch (err) {
    console.error('Erreur création école:', err);
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Ce code école ou cet email est déjà utilisé.' });
    }
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /admin/ecoles  (Super Admin uniquement)
 */
async function listerEcoles(req, res) {
  try {
    const result = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(`
        SELECT e.id, e.nom, e.code, e.ville, e.statut,
               a.statut AS statut_abonnement, a.date_expiration
        FROM ecoles e
        LEFT JOIN LATERAL (
          SELECT statut, date_expiration FROM abonnements
          WHERE ecole_id = e.id ORDER BY created_at DESC LIMIT 1
        ) a ON true
        ORDER BY e.created_at DESC
      `)
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste écoles:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /admin/plans  (Super Admin uniquement)
 */
async function listerPlans(req, res) {
  try {
    const result = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query('SELECT * FROM plans_abonnement ORDER BY prix')
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste plans:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /admin/ecoles/:id  (Super Admin uniquement)
 * Vue détaillée : infos école, abonnement courant, compte Directeur principal
 * (le premier créé), et quelques statistiques d'usage.
 */
async function obtenirEcole(req, res) {
  const { id } = req.params;
  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecoleResult = await client.query(`SELECT * FROM ecoles WHERE id = $1`, [id]);
      if (ecoleResult.rows.length === 0) {
        throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });
      }

      const abonnementResult = await client.query(
        `SELECT a.*, p.nom AS plan_nom, p.prix, p.devise, p.duree_jours
         FROM abonnements a JOIN plans_abonnement p ON p.id = a.plan_id
         WHERE a.ecole_id = $1 ORDER BY a.created_at DESC LIMIT 1`,
        [id]
      );

      // Le premier compte Directeur créé pour cette école (celui généré à la création)
      const directeurResult = await client.query(
        `SELECT u.id, u.nom, u.prenom, u.email, u.statut, u.created_at
         FROM utilisateurs u
         JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE u.ecole_id = $1 AND ur.role = 'directeur'
         ORDER BY u.created_at ASC LIMIT 1`,
        [id]
      );

      const statsResult = await client.query(
        `SELECT
           (SELECT count(*) FROM eleves WHERE ecole_id = $1 AND statut = 'actif') AS nb_eleves,
           (SELECT count(*) FROM utilisateurs WHERE ecole_id = $1) AS nb_utilisateurs,
           (SELECT count(*) FROM classes WHERE ecole_id = $1) AS nb_classes`,
        [id]
      );

      const paiementsResult = await client.query(
        `SELECT p.montant, p.methode, p.statut, p.date_paiement, p.reference_externe
         FROM paiements p WHERE p.ecole_id = $1 ORDER BY p.date_paiement DESC LIMIT 20`,
        [id]
      );

      return {
        ecole: ecoleResult.rows[0],
        abonnement: abonnementResult.rows[0] || null,
        directeur_principal: directeurResult.rows[0] || null,
        stats: statsResult.rows[0],
        paiements: paiementsResult.rows
      };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détail école:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /admin/ecoles/:id  (Super Admin uniquement)
 * Modifier les infos d'une école et/ou son statut (suspendre/réactiver manuellement).
 * body: { nom?, telephone?, email?, adresse?, province?, ville?, statut? }
 */
async function modifierEcole(req, res) {
  const { id } = req.params;
  const { nom, telephone, email, adresse, province, ville, statut } = req.body;

  try {
    await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(
        `UPDATE ecoles SET
           nom = COALESCE($1, nom), telephone = COALESCE($2, telephone),
           email = COALESCE($3, email), adresse = COALESCE($4, adresse),
           province = COALESCE($5, province), ville = COALESCE($6, ville),
           statut = COALESCE($7, statut), updated_at = now()
         WHERE id = $8`,
        [nom, telephone, email, adresse, province, ville, statut, id]
      )
    );
    return res.json({ message: 'École mise à jour.' });
  } catch (err) {
    console.error('Erreur modification école:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /admin/ecoles/:id/abonnement  (Super Admin uniquement)
 * Ajustement manuel de l'abonnement (plan, date d'expiration, statut) —
 * pour les cas hors paiement Mobile Money (virement, geste commercial, etc.)
 * body: { plan_id?, date_expiration?, statut? }
 */
async function modifierAbonnementEcole(req, res) {
  const { id } = req.params;
  const { plan_id, date_expiration, statut } = req.body;

  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const abonnementResult = await client.query(
        `SELECT id FROM abonnements WHERE ecole_id = $1 ORDER BY created_at DESC LIMIT 1`,
        [id]
      );
      if (abonnementResult.rows.length === 0) {
        throw Object.assign(new Error('Aucun abonnement trouvé pour cette école.'), { statusCode: 404 });
      }

      await client.query(
        `UPDATE abonnements SET
           plan_id = COALESCE($1, plan_id),
           date_expiration = COALESCE($2, date_expiration),
           statut = COALESCE($3, statut),
           updated_at = now()
         WHERE id = $4`,
        [plan_id || null, date_expiration || null, statut || null, abonnementResult.rows[0].id]
      );

      // Si on réactive manuellement, on réactive aussi l'école si elle était suspendue
      if (statut === 'actif') {
        await client.query(`UPDATE ecoles SET statut = 'actif' WHERE id = $1 AND statut = 'suspendu'`, [id]);
      }
    });

    // L'offre de cette école vient de changer : le catalogue garde en mémoire
    // les droits et les plafonds pendant une minute, et continuerait sinon à
    // refuser la comptabilité à une école qu'on vient de faire passer en
    // Pilote. Une minute d'écart entre « j'ai payé » et « ça marche » est
    // exactement le moment où le directeur appelle le support.
    require('../utils/catalogue.utils').invaliderCache();

    return res.json({ message: 'Abonnement mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification abonnement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /admin/ecoles/:id/reset-directeur-password  (Super Admin uniquement)
 * Génère un nouveau mot de passe aléatoire pour le compte Directeur principal
 * de cette école, et le renvoie en clair une seule fois (à transmettre à l'école).
 */
async function reinitialiserMotDePasseDirecteur(req, res) {
  const { id } = req.params;

  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const directeurResult = await client.query(
        `SELECT u.id, u.email FROM utilisateurs u
         JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE u.ecole_id = $1 AND ur.role = 'directeur'
         ORDER BY u.created_at ASC LIMIT 1`,
        [id]
      );
      if (directeurResult.rows.length === 0) {
        throw Object.assign(new Error('Aucun compte Directeur trouvé pour cette école.'), { statusCode: 404 });
      }
      const directeur = directeurResult.rows[0];

      const nouveauMotDePasse = crypto.randomBytes(6).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 10);
      const hash = await hashPassword(nouveauMotDePasse);
      await client.query(`UPDATE utilisateurs SET mot_de_passe_hash = $1 WHERE id = $2`, [hash, directeur.id]);
      await client.query(`DELETE FROM sessions WHERE utilisateur_id = $1`, [directeur.id]);

      return { email: directeur.email, nouveau_mot_de_passe: nouveauMotDePasse };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur réinitialisation mot de passe directeur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /admin/stats  (Super Admin uniquement)
 * Statistiques globales de la plateforme, toutes écoles confondues.
 */
async function statistiquesGlobales(req, res) {
  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const result = await client.query(`
        SELECT
          (SELECT count(*) FROM ecoles) AS nb_ecoles,
          (SELECT count(*) FROM ecoles WHERE statut = 'actif') AS nb_ecoles_actives,
          (SELECT count(*) FROM ecoles WHERE statut = 'suspendu') AS nb_ecoles_suspendues,
          (SELECT count(*) FROM abonnements WHERE statut = 'actif') AS nb_abonnements_actifs,
          (SELECT count(*) FROM eleves WHERE statut = 'actif') AS nb_eleves_total,
          (SELECT count(*) FROM utilisateurs WHERE ecole_id IS NOT NULL) AS nb_utilisateurs_total,
          (SELECT COALESCE(sum(p.montant), 0) FROM paiements p WHERE p.statut = 'confirme') AS revenu_total_confirme
      `);
      return result.rows[0];
    });
    return res.json(resultat);
  } catch (err) {
    console.error('Erreur statistiques globales:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  creerEcole, listerEcoles, listerPlans,
  obtenirEcole, modifierEcole, modifierAbonnementEcole,
  reinitialiserMotDePasseDirecteur, statistiquesGlobales
};
