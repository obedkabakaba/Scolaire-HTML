const XLSX = require('xlsx');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /eleves?classeId=&q=&statut=
 * Liste les élèves, filtrable par classe, recherche rapide et statut.
 * Par défaut, seuls les élèves "actif" sont renvoyés (pas les renvoyés/partis),
 * sauf si un statut précis (ou "tous") est demandé.
 */
async function lister(req, res) {
  const { classeId, q, statut } = req.query;

  // Un Titulaire (sans autre rôle de gestion) ne peut voir que les élèves de
  // sa PROPRE classe — jamais toute l'école, même en passant un autre classeId.
  const estGestionnaire = req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
  if (!estGestionnaire) {
    if (!req.auth.roles.includes('titulaire')) {
      return res.status(403).json({ message: 'Accès refusé.' });
    }
    try {
      const verifResult = await runWithTenant(tenantContextFromReq(req), (client) =>
        client.query(`SELECT id FROM classes WHERE titulaire_id = $1 AND id = $2`, [req.auth.userId, classeId])
      );
      if (!classeId || verifResult.rows.length === 0) {
        return res.status(403).json({ message: "Tu ne peux voir que les élèves de ta propre classe." });
      }
    } catch (err) {
      console.error('Erreur vérification titulaire:', err);
      return res.status(500).json({ message: 'Erreur serveur.' });
    }
  }

  try {
    const conditions = [`e.ecole_id = ${CURRENT_ECOLE}`];
    const params = [];

    if (classeId) {
      params.push(classeId);
      conditions.push(`e.classe_id = $${params.length}`);
    }
    if (q) {
      params.push(`%${q}%`);
      conditions.push(`(e.nom ILIKE $${params.length} OR e.postnom ILIKE $${params.length} OR e.prenom ILIKE $${params.length} OR e.matricule ILIKE $${params.length})`);
    }
    // Le cycle porte sur la CLASSE de l'élève : c'est elle qui sait s'il est
    // au primaire ou aux humanités. Un élève sans classe reste visible — le
    // masquer le rendrait impossible à rattacher.
    const cycle = cycleDemande(req);
    if (cycle) {
      params.push(cycle);
      conditions.push(`(e.classe_id IS NULL OR ${conditionCycle('c', params.length)})`);
    }

    if (!statut || statut === 'actif') {
      conditions.push(`e.statut = 'actif'`);
    } else if (statut !== 'tous') {
      params.push(statut);
      conditions.push(`e.statut = $${params.length}`);
    }

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT e.*, c.nom AS classe_nom
         FROM eleves e
         LEFT JOIN classes c ON c.id = e.classe_id
         WHERE ${conditions.join(' AND ')}
         ORDER BY e.nom, e.postnom`,
        params
      )
    );

    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste élèves:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Génère un matricule séquentiel unique pour l'école (ex: ELV-0001), utilisé
 * quand aucun matricule n'est fourni (saisie manuelle ou import Excel).
 */
async function genererMatricule(client) {
  const result = await client.query(
    `SELECT count(*) AS total FROM eleves WHERE ecole_id = ${CURRENT_ECOLE}`
  );
  let compteur = parseInt(result.rows[0].total, 10) + 1;

  // Sécurité anti-collision : si ce matricule existe déjà (élève supprimé entre-temps
  // par ex.), on avance jusqu'à en trouver un libre.
  let matricule;
  let libre = false;
  while (!libre) {
    matricule = `ELV-${String(compteur).padStart(4, '0')}`;
    const existant = await client.query(
      `SELECT 1 FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND matricule = $1`,
      [matricule]
    );
    if (existant.rows.length === 0) libre = true;
    else compteur++;
  }
  return matricule;
}

/**
 * GET /eleves/:id/historique
 */
async function historique(req, res) {
  const { id } = req.params;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT h.*, c.nom AS classe_nom, a.libelle AS annee_libelle
         FROM eleve_classe_historique h
         JOIN classes c ON c.id = h.classe_id
         JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
         WHERE h.eleve_id = $1
         ORDER BY a.date_debut DESC`,
        [id]
      )
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur historique élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /eleves
 */
async function creer(req, res) {
  const {
    matricule, nom, postnom, prenom, sexe, date_naissance, lieu_naissance, adresse, telephone,
    responsable_nom, responsable_telephone, responsable_email, responsable_adresse,
    photo_url, classe_id
  } = req.body;

  if (!nom) {
    return res.status(400).json({ message: 'Le nom est requis.' });
  }

  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const matriculeFinal = matricule?.trim() || await genererMatricule(client);

      const eleveResult = await client.query(
        `INSERT INTO eleves (
           ecole_id, matricule, nom, postnom, prenom, sexe, date_naissance, lieu_naissance,
           adresse, telephone, responsable_nom, responsable_telephone,
           responsable_email, responsable_adresse, photo_url, classe_id
         ) VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
         RETURNING id, matricule`,
        [matriculeFinal, nom, postnom, prenom, sexe, date_naissance, lieu_naissance,
         adresse, telephone, responsable_nom, responsable_telephone,
         responsable_email, responsable_adresse, photo_url, classe_id || null]
      );

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id)
         VALUES (${CURRENT_ECOLE}, $1, 'eleve.cree', 'eleve', $2)`,
        [req.auth.userId, eleveResult.rows[0].id]
      );

      return eleveResult.rows[0];
    });

    return res.status(201).json({ id: result.id, matricule: result.matricule, message: 'Élève créé.' });
  } catch (err) {
    console.error('Erreur création élève:', err);
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Ce matricule existe déjà dans cette école.' });
    }
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /eleves/:id
 */
async function modifier(req, res) {
  const { id } = req.params;
  const {
    nom, postnom, prenom, sexe, date_naissance, lieu_naissance, adresse, telephone,
    responsable_nom, responsable_telephone, responsable_email, responsable_adresse,
    photo_url, classe_id, statut
  } = req.body;

  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE eleves SET
           nom = COALESCE($1, nom), postnom = COALESCE($2, postnom), prenom = COALESCE($3, prenom),
           sexe = COALESCE($4, sexe), date_naissance = COALESCE($5, date_naissance),
           lieu_naissance = COALESCE($6, lieu_naissance),
           adresse = COALESCE($7, adresse), telephone = COALESCE($8, telephone),
           responsable_nom = COALESCE($9, responsable_nom),
           responsable_telephone = COALESCE($10, responsable_telephone),
           responsable_email = COALESCE($11, responsable_email),
           responsable_adresse = COALESCE($12, responsable_adresse),
           photo_url = COALESCE($13, photo_url), classe_id = COALESCE($14, classe_id),
           statut = COALESCE($15, statut)
         WHERE id = $16`,
        [nom, postnom, prenom, sexe, date_naissance, lieu_naissance, adresse, telephone,
         responsable_nom, responsable_telephone, responsable_email, responsable_adresse,
         photo_url, classe_id, statut, id]
      )
    );
    return res.json({ message: 'Élève mis à jour.' });
  } catch (err) {
    console.error('Erreur modification élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /eleves/:id
 */
async function supprimer(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id)
         VALUES (${CURRENT_ECOLE}, $1, 'eleve.supprime', 'eleve', $2)`,
        [req.auth.userId, id]
      );
      await client.query('DELETE FROM eleves WHERE id = $1', [id]);
    });
    return res.json({ message: 'Élève supprimé.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({
        message: "Impossible de supprimer : cet élève a déjà des notes, bulletins ou paiements enregistrés. Marque-le plutôt comme \"renvoyé\" ou \"transféré\" dans le statut."
      });
    }
    console.error('Erreur suppression élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /eleves/export?classeId=
 * Génère un fichier Excel (.xlsx) des élèves, filtrable par classe.
 */
async function exporter(req, res) {
  const { classeId } = req.query;
  try {
    const conditions = [`e.ecole_id = ${CURRENT_ECOLE}`];
    const params = [];
    if (classeId) { params.push(classeId); conditions.push(`e.classe_id = $${params.length}`); }

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT e.matricule, e.nom, e.postnom, e.prenom, e.sexe, e.date_naissance,
                e.adresse, e.telephone, e.responsable_nom, e.responsable_telephone,
                c.nom AS classe, e.statut
         FROM eleves e
         LEFT JOIN classes c ON c.id = e.classe_id
         WHERE ${conditions.join(' AND ')}
         ORDER BY e.nom, e.postnom`,
        params
      )
    );

    const lignes = result.rows.map((e) => ({
      Matricule: e.matricule,
      Nom: e.nom,
      Postnom: e.postnom,
      Prenom: e.prenom,
      Sexe: e.sexe,
      DateNaissance: e.date_naissance ? new Date(e.date_naissance).toISOString().slice(0, 10) : '',
      Adresse: e.adresse,
      Telephone: e.telephone,
      ResponsableNom: e.responsable_nom,
      ResponsableTelephone: e.responsable_telephone,
      Classe: e.classe,
      Statut: e.statut
    }));

    const feuille = XLSX.utils.json_to_sheet(lignes);
    const classeur = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(classeur, feuille, 'Eleves');
    const buffer = XLSX.write(classeur, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="eleves.xlsx"');
    return res.send(buffer);
  } catch (err) {
    console.error('Erreur export élèves:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /eleves/import
 * Multipart form-data, champ "fichier" (.xlsx).
 * Colonnes attendues (en-têtes) : Matricule, Nom, Postnom, Prenom, Sexe,
 * DateNaissance, Adresse, Telephone, ResponsableNom, ResponsableTelephone, Classe
 *
 * Comportement : upsert par matricule (une ligne avec un matricule déjà existant
 * met à jour l'élève au lieu de créer un doublon). La colonne "Classe" est
 * recherchée par nom dans les classes de l'école (insensible à la casse) ;
 * si aucune correspondance, l'élève est importé sans classe assignée.
 */
/**
 * Écrit un lot de lignes normalisées dans la table élèves.
 *
 * Les clés attendues sont celles du modèle d'import : Nom, Postnom, Prenom,
 * Matricule, Classe, Sexe, DateNaissance, Adresse, Telephone, ResponsableNom,
 * ResponsableTelephone, ResponsableEmail.
 *
 * Exportée pour que l'import assisté par IA passe exactement par le même
 * chemin : un seul comportement, une seule règle de validation.
 */
/**
 * Convertit une date de tableur en AAAA-MM-JJ, ou renvoie null.
 *
 * PostgreSQL lit « 13/01/2007 » comme mois 13 et refuse la ligne. Il faut
 * donc normaliser en JavaScript AVANT l'envoi — on ne peut pas se reposer sur
 * le réglage « datestyle » du serveur, qui n'est pas garanti.
 *
 * Quatre formes arrivent en pratique :
 *   · une vraie date Excel, lue comme objet Date ;
 *   · un numéro de série Excel (39095 = 13 janvier 2007) ;
 *   · un texte jour/mois/année, avec / - ou . comme séparateur ;
 *   · un texte déjà au format ISO.
 *
 * Convention retenue : JOUR d'abord. C'est l'usage francophone, donc celui
 * des écoles congolaises. « 03/04/2010 » est donc le 3 avril, pas le 4 mars.
 */
function normaliserDate(valeur) {
  if (valeur === null || valeur === undefined || valeur === '') return null;

  // Objet Date, produit par la lecture du tableur avec cellDates.
  if (valeur instanceof Date && !isNaN(valeur)) {
    return valeur.toISOString().slice(0, 10);
  }

  // Numéro de série Excel. L'origine est le 30/12/1899 : Excel considère à
  // tort 1900 comme bissextile, et ce décalage est la façon usuelle de le
  // compenser.
  if (typeof valeur === 'number' && Number.isFinite(valeur)) {
    if (valeur < 1 || valeur > 100000) return null;
    const base = Date.UTC(1899, 11, 30);
    const d = new Date(base + Math.round(valeur) * 86400000);
    return isNaN(d) ? null : d.toISOString().slice(0, 10);
  }

  const texte = String(valeur).trim();
  if (!texte) return null;

  // Déjà au format ISO.
  const iso = texte.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;

  const parties = texte.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
  if (!parties) return null;

  let jour = Number(parties[1]);
  let mois = Number(parties[2]);
  let annee = Number(parties[3]);

  // Année sur deux chiffres : au-delà de 30, on suppose le siècle précédent.
  if (annee < 100) annee += annee > 30 ? 1900 : 2000;

  // Si le premier nombre dépasse 12, c'est forcément un jour — et si c'est le
  // second qui dépasse 12, le fichier était en mois/jour : on rétablit.
  if (jour > 12 && mois > 12) return null;
  if (jour <= 12 && mois > 12) { const t = jour; jour = mois; mois = t; }

  if (mois < 1 || mois > 12 || jour < 1 || jour > 31) return null;
  if (annee < 1900 || annee > 2200) return null;

  const d = new Date(Date.UTC(annee, mois - 1, jour));
  // Contrôle de cohérence : le 31 février serait sinon ramené au 3 mars.
  if (d.getUTCMonth() !== mois - 1 || d.getUTCDate() !== jour) return null;

  return `${annee}-${String(mois).padStart(2, '0')}-${String(jour).padStart(2, '0')}`;
}

async function traiterLignesImport(client, lignes) {
  const classesResult = await client.query(
    `SELECT id, nom FROM classes WHERE ecole_id = ${CURRENT_ECOLE}`
  );
  const classesParNom = new Map(classesResult.rows.map((c) => [c.nom.trim().toLowerCase(), c.id]));

  const bilan = { crees: 0, mis_a_jour: 0, erreurs: [] };

  for (let i = 0; i < lignes.length; i++) {
    const ligne = lignes[i];
    const numeroLigne = i + 2; // +2 car ligne 1 = en-têtes, tableur indexé à partir de 1

    const nom = ligne.Nom?.toString().trim();
    let matricule = ligne.Matricule?.toString().trim();

    if (!nom) {
      bilan.erreurs.push(`Ligne ${numeroLigne} : le Nom est obligatoire — ignorée.`);
      continue;
    }
    if (!matricule) {
      matricule = await genererMatricule(client);
    }

    const dateNaissance = normaliserDate(ligne.DateNaissance);
    if (ligne.DateNaissance && dateNaissance === null) {
      // Une date illisible ne doit plus faire échouer tout le fichier : on
      // importe l'élève sans sa date et on nomme la ligne à corriger.
      bilan.erreurs.push(
        `Ligne ${numeroLigne} : date de naissance illisible ("${ligne.DateNaissance}") — élève importé sans cette date.`
      );
    }

    let classeId = null;
    if (ligne.Classe) {
      classeId = classesParNom.get(ligne.Classe.toString().trim().toLowerCase()) || null;
      if (!classeId) {
        bilan.erreurs.push(`Ligne ${numeroLigne} : classe "${ligne.Classe}" introuvable — élève importé sans classe.`);
      }
    }

    const existantResult = await client.query(
      `SELECT id FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND matricule = $1`,
      [matricule]
    );

    if (existantResult.rows.length > 0) {
      await client.query(
        `UPDATE eleves SET nom=$1, postnom=$2, prenom=$3, sexe=$4, date_naissance=$5,
         adresse=$6, telephone=$7, responsable_nom=$8, responsable_telephone=$9,
         responsable_email = COALESCE($10, responsable_email),
         classe_id = COALESCE($11, classe_id)
         WHERE id = $12`,
        [nom, ligne.Postnom, ligne.Prenom, ligne.Sexe, dateNaissance,
         ligne.Adresse, ligne.Telephone, ligne.ResponsableNom, ligne.ResponsableTelephone,
         ligne.ResponsableEmail || null, classeId, existantResult.rows[0].id]
      );
      bilan.mis_a_jour++;
    } else {
      await client.query(
        `INSERT INTO eleves (ecole_id, matricule, nom, postnom, prenom, sexe, date_naissance,
         adresse, telephone, responsable_nom, responsable_telephone, responsable_email, classe_id)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [matricule, nom, ligne.Postnom, ligne.Prenom, ligne.Sexe, dateNaissance,
         ligne.Adresse, ligne.Telephone, ligne.ResponsableNom, ligne.ResponsableTelephone,
         ligne.ResponsableEmail || null, classeId]
      );
      bilan.crees++;
    }
  }

  return bilan;
}

async function importer(req, res) {
  if (!req.file) {
    return res.status(400).json({ message: 'Aucun fichier reçu (champ attendu : "fichier").' });
  }

  try {
    const classeur = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
    const premiereFeuille = classeur.Sheets[classeur.SheetNames[0]];
    const lignes = XLSX.utils.sheet_to_json(premiereFeuille, { defval: null });

    const resultat = await runWithTenant(tenantContextFromReq(req), (client) =>
      traiterLignesImport(client, lignes)
    );

    return res.json({ message: 'Import terminé.', bilan: resultat });
  } catch (err) {
    console.error('Erreur import élèves:', err);
    return res.status(500).json({ message: 'Erreur serveur lors de la lecture du fichier.' });
  }
}



const MOTIFS_SORTIE = ['diplome', 'echec_repete', 'depart_volontaire', 'transfert',
                       'exclusion', 'abandon', 'sans_notes', 'autre'];

const LIBELLES_MOTIF = {
  diplome: 'a terminé son cycle',
  echec_repete: "n'a pas réussi",
  depart_volontaire: 'part à la demande de la famille',
  transfert: 'est transféré dans un autre établissement',
  exclusion: 'est exclu par décision disciplinaire',
  abandon: 'ne se présente plus',
  sans_notes: "était inscrit mais n'a jamais été évalué",
  autre: 'quitte l\'école'
};

/**
 * POST /eleves/:id/sortie
 * body : { motif, date_sortie?, note? }
 *
 * POURQUOI UN MOTIF EST OBLIGATOIRE
 * ---------------------------------
 * Un élève quittait l'école en passant simplement au statut « transféré »,
 * quelle que soit la raison. Or les raisons ne se valent pas : un élève exclu,
 * un élève transféré et un élève qui abandonne appellent des suites
 * différentes — dossier à transmettre, conseil de discipline à archiver,
 * famille à relancer. Sans motif, le secrétariat ne peut ni les distinguer,
 * ni en rendre compte.
 */
async function enregistrerSortie(req, res) {
  const { id } = req.params;
  const { motif, date_sortie, note } = req.body;

  if (!MOTIFS_SORTIE.includes(motif)) {
    return res.status(400).json({
      message: 'Précisez le motif du départ : ' + MOTIFS_SORTIE.join(', ') + '.'
    });
  }
  if (date_sortie && !/^\d{4}-\d{2}-\d{2}$/.test(String(date_sortie))) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleve = await client.query(
        `SELECT e.id, e.statut::text, e.classe_id,
                trim(concat(e.nom, ' ', COALESCE(e.postnom, ''), ' ', COALESCE(e.prenom, ''))) AS nom,
                c.annee_scolaire_id
           FROM eleves e LEFT JOIN classes c ON c.id = e.classe_id
          WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (eleve.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      if (eleve.rows[0].statut !== 'actif') {
        throw Object.assign(
          new Error(`${eleve.rows[0].nom} n'est déjà plus actif dans l'école.`),
          { statusCode: 409 }
        );
      }

      // Un diplômé n'est pas un partant : c'est une fin de parcours réussie, et
      // le statut le dit. Les confondre effacerait la distinction dans toutes
      // les statistiques ultérieures.
      const statut = motif === 'diplome' ? 'diplome' : 'transfere';

      await client.query(
        `UPDATE eleves
            SET statut = $2::statut_eleve, motif_sortie = $3,
                date_sortie = COALESCE($4::date, CURRENT_DATE),
                annee_sortie_id = $5
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id, statut, motif, date_sortie || null, eleve.rows[0].annee_scolaire_id || null]
      );

      // La place libérée doit se voir immédiatement dans les effectifs : c'est
      // elle qui permet d'inscrire quelqu'un d'autre.
      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'eleve.sortie', 'eleve', $2, $3::jsonb)`,
        [req.auth.userId, id, JSON.stringify({ motif, note: note || null })]
      );

      return { nom: eleve.rows[0].nom, statut };
    });

    return res.json({
      message: `${resultat.nom} ${LIBELLES_MOTIF[motif]}. Sa place est libérée ; `
        + `son dossier reste consultable dans les Archives.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur sortie élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /eleves/motifs-sortie — vocabulaire commun à l'écran et au serveur. */
function listerMotifsSortie(req, res) {
  return res.json(MOTIFS_SORTIE.map((code) => ({ code, libelle: LIBELLES_MOTIF[code] })));
}

module.exports = {
  enregistrerSortie, listerMotifsSortie, lister, historique, creer, modifier, supprimer, exporter, importer, traiterLignesImport, normaliserDate };
