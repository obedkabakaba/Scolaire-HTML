const { runWithTenant } = require('../config/db');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const NOMS_JOURS = { 1: 'lundi', 2: 'mardi', 3: 'mercredi', 4: 'jeudi', 5: 'vendredi', 6: 'samedi', 7: 'dimanche' };

function estGestionnaire(req) {
  return req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
}

/**
 * Lecture : la direction et le secrétariat voient toutes les classes,
 * un titulaire uniquement les siennes.
 */
async function verifierLectureClasse(client, req, classeId) {
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r))) return;
  const r = await client.query(`SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]);
  if (r.rows.length === 0) {
    throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
  }
}

/** Année scolaire active de l'école, socle de tout emploi du temps. */
async function anneeActive(client) {
  const r = await client.query(
    `SELECT id, libelle FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
  );
  return r.rows[0] || null;
}

/**
 * GET /emploi-du-temps/configuration
 * Grille horaire de l'école et jours travaillés. Tout le monde peut la lire :
 * elle sert à dessiner la grille dans chaque écran.
 */
async function configuration(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const ecoleResult = await client.query(
        `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5,6]) AS jours_cours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      // `vacations` porte son propre cycle : la vacation du matin du primaire
      // n'a rien à faire dans la grille des humanités quand le filtre est posé.
      const vacationsResult = await client.query(
        `SELECT id, nom, cycle::text, ordre FROM vacations v
         WHERE v.ecole_id = ${CURRENT_ECOLE}
           AND ($1::text IS NULL OR v.cycle IS NULL OR v.cycle::text = $1)
         ORDER BY v.ordre, v.nom`,
        [cycleDemande(req)]
      );
      const creneauxResult = await client.query(
        `SELECT id, ordre, libelle, heure_debut, heure_fin, vacation_id
         FROM creneaux WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY ordre`
      );
      const jours = (ecoleResult.rows[0]?.jours_cours || [1, 2, 3, 4, 5, 6]).map(Number).sort((a, b) => a - b);

      return {
        jours: jours.map((j) => ({ numero: j, nom: NOMS_JOURS[j] })),
        vacations: vacationsResult.rows.map((v) => ({
          ...v,
          creneaux: creneauxResult.rows.filter((c) => c.vacation_id === v.id)
        })),
        // Créneaux d'avant l'introduction des vacations : conservés pour que
        // les emplois du temps existants continuent de s'afficher.
        creneaux: creneauxResult.rows,
        annee_active: await anneeActive(client)
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur configuration emploi du temps:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /emploi-du-temps/configuration
 * Redéfinit les jours travaillés et la grille horaire.
 */
async function enregistrerConfiguration(req, res) {
  const { jours, creneaux, vacation_id } = req.body;

  if (!Array.isArray(jours) || jours.length === 0) {
    return res.status(400).json({ message: 'Sélectionnez au moins un jour de cours.' });
  }
  const joursValides = jours.map(Number);
  if (joursValides.some((j) => !Number.isInteger(j) || j < 1 || j > 7)) {
    return res.status(400).json({ message: 'Jour invalide : les valeurs vont de 1 (lundi) à 7 (dimanche).' });
  }
  if (!Array.isArray(creneaux) || creneaux.length === 0) {
    return res.status(400).json({ message: 'Définissez au moins une heure de cours.' });
  }

  const horaire = /^([01]\d|2[0-3]):[0-5]\d$/;
  for (const c of creneaux) {
    if (!c.libelle || !String(c.libelle).trim()) {
      return res.status(400).json({ message: 'Chaque heure de cours doit avoir un libellé.' });
    }
    const debut = String(c.heure_debut || '').slice(0, 5);
    const fin = String(c.heure_fin || '').slice(0, 5);
    if (!horaire.test(debut) || !horaire.test(fin)) {
      return res.status(400).json({ message: `Horaires invalides pour « ${c.libelle} ». Format attendu : HH:MM.` });
    }
    if (debut >= fin) {
      return res.status(400).json({ message: `Pour « ${c.libelle} », l'heure de fin doit suivre l'heure de début.` });
    }
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await client.query(`UPDATE ecoles SET jours_cours = $1, updated_at = now() WHERE id = ${CURRENT_ECOLE}`,
        [[...new Set(joursValides)].sort((a, b) => a - b)]);

      // La grille est propre à une vacation : on ne touche qu'aux créneaux
      // de celle-ci, sinon enregistrer les horaires du matin effacerait
      // ceux de l'après-midi.
      let vacationRetenue = vacation_id || null;
      if (vacationRetenue) {
        const v = await client.query(
          `SELECT id FROM vacations WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [vacationRetenue]
        );
        if (v.rows.length === 0) {
          throw Object.assign(new Error('Vacation introuvable.'), { statusCode: 400 });
        }
      }

      const idsConserves = creneaux.map((c) => c.id).filter(Boolean);
      const utilisesResult = await client.query(
        `SELECT DISTINCT cr.libelle
         FROM creneaux cr
         JOIN emploi_du_temps edt ON edt.creneau_id = cr.id
         WHERE cr.ecole_id = ${CURRENT_ECOLE}
           AND cr.vacation_id IS NOT DISTINCT FROM $2::uuid
           AND ($1::uuid[] IS NULL OR NOT (cr.id = ANY($1::uuid[])))`,
        [idsConserves.length ? idsConserves : null, vacationRetenue]
      );
      if (utilisesResult.rows.length > 0) {
        const noms = utilisesResult.rows.map((r) => `« ${r.libelle} »`).join(', ');
        throw Object.assign(
          new Error(`Impossible de supprimer ${noms} : des cours y sont encore placés. Retirez-les d'abord de l'emploi du temps.`),
          { statusCode: 409 }
        );
      }

      await client.query(
        `DELETE FROM creneaux WHERE ecole_id = ${CURRENT_ECOLE}
         AND vacation_id IS NOT DISTINCT FROM $2::uuid
         AND ($1::uuid[] IS NULL OR NOT (id = ANY($1::uuid[])))`,
        [idsConserves.length ? idsConserves : null, vacationRetenue]
      );

      for (let i = 0; i < creneaux.length; i++) {
        const c = creneaux[i];
        const debut = String(c.heure_debut).slice(0, 5);
        const fin = String(c.heure_fin).slice(0, 5);
        if (c.id) {
          await client.query(
            `UPDATE creneaux SET ordre = $1, libelle = $2, heure_debut = $3, heure_fin = $4,
                                 vacation_id = $6
             WHERE id = $5 AND ecole_id = ${CURRENT_ECOLE}`,
            [i + 1, String(c.libelle).trim(), debut, fin, c.id, vacationRetenue]
          );
        } else {
          await client.query(
            `INSERT INTO creneaux (ecole_id, ordre, libelle, heure_debut, heure_fin, vacation_id)
             VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5)`,
            [i + 1, String(c.libelle).trim(), debut, fin, vacationRetenue]
          );
        }
      }
      return creneaux.length;
    });

    return res.json({ message: `Grille horaire enregistrée (${resultat} heure(s) de cours).` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement configuration:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /emploi-du-temps/classe/:classeId
 * Toutes les séances d'une classe pour l'année active.
 */
async function emploiDeClasse(req, res) {
  const { classeId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierLectureClasse(client, req, classeId);
      const annee = await anneeActive(client);
      if (!annee) {
        throw Object.assign(new Error("Aucune année scolaire active : activez-en une avant de bâtir l'emploi du temps."), { statusCode: 409 });
      }

      // La grille affichée est celle de la vacation de la classe. Une classe
      // du matin ne doit pas voir les créneaux de l'après-midi.
      const classeInfo = await client.query(
        `SELECT c.vacation_id, c.cycle::text, v.nom AS vacation_nom
         FROM classes c LEFT JOIN vacations v ON v.id = c.vacation_id
         WHERE c.id = $1 AND c.ecole_id = ${CURRENT_ECOLE}`,
        [classeId]
      );
      const vacationClasse = classeInfo.rows[0] || {};

      const creneauxClasse = await client.query(
        `SELECT id, ordre, libelle, heure_debut, heure_fin
         FROM creneaux
         WHERE ecole_id = ${CURRENT_ECOLE}
           AND vacation_id IS NOT DISTINCT FROM $1::uuid
         ORDER BY ordre`,
        [vacationClasse.vacation_id || null]
      );

      const seancesResult = await client.query(
        `SELECT edt.id, edt.jour, edt.creneau_id, edt.classe_cours_id,
                co.nom AS cours_nom,
                COALESCE(
                  string_agg(DISTINCT trim(concat(u.prenom, ' ', u.nom)), ', '),
                  ''
                ) AS professeurs
         FROM emploi_du_temps edt
         JOIN classe_cours cc ON cc.id = edt.classe_cours_id
         JOIN cours co ON co.id = cc.cours_id
         LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
         LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
         WHERE edt.classe_id = $1 AND edt.annee_scolaire_id = $2
         GROUP BY edt.id, edt.jour, edt.creneau_id, edt.classe_cours_id, co.nom
         ORDER BY edt.jour`,
        [classeId, annee.id]
      );

      // Cours disponibles pour cette classe, avec leur volume déjà placé :
      // c'est ce qui permet de voir en un coup d'œil ce qu'il reste à caser.
      const coursResult = await client.query(
        `SELECT cc.id AS classe_cours_id, co.nom AS cours_nom,
                (SELECT count(*) FROM emploi_du_temps e
                 WHERE e.classe_cours_id = cc.id AND e.annee_scolaire_id = $2) AS nb_heures
         FROM classe_cours cc
         JOIN cours co ON co.id = cc.cours_id
         WHERE cc.classe_id = $1
         ORDER BY co.nom`,
        [classeId, annee.id]
      );

      return {
        annee_active: annee,
        vacation: vacationClasse.vacation_id
          ? { id: vacationClasse.vacation_id, nom: vacationClasse.vacation_nom }
          : null,
        cycle: vacationClasse.cycle || null,
        creneaux: creneauxClasse.rows,
        seances: seancesResult.rows,
        cours: coursResult.rows.map((c) => ({ ...c, nb_heures: Number(c.nb_heures) }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur emploi du temps classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /emploi-du-temps/seance
 * Place un cours sur une case de la grille. Un professeur ne peut jamais
 * être dans deux classes au même moment : la sauvegarde est refusée.
 */
async function placerSeance(req, res) {
  const { classe_id, classe_cours_id, jour, creneau_id } = req.body;

  if (!classe_id || !classe_cours_id || !creneau_id) {
    return res.status(400).json({ message: 'classe_id, classe_cours_id et creneau_id sont requis.' });
  }
  const jourNum = Number(jour);
  if (!Number.isInteger(jourNum) || jourNum < 1 || jourNum > 7) {
    return res.status(400).json({ message: 'Jour invalide.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) {
        throw Object.assign(new Error("Aucune année scolaire active."), { statusCode: 409 });
      }

      // Le cours doit appartenir à la classe visée.
      const coursResult = await client.query(
        `SELECT cc.id, co.nom AS cours_nom FROM classe_cours cc
         JOIN cours co ON co.id = cc.cours_id
         WHERE cc.id = $1 AND cc.classe_id = $2`,
        [classe_cours_id, classe_id]
      );
      if (coursResult.rows.length === 0) {
        throw Object.assign(new Error("Ce cours n'est pas programmé dans cette classe."), { statusCode: 400 });
      }

      // Le jour doit faire partie des jours travaillés de l'école.
      const joursResult = await client.query(
        `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5,6]) AS jours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      if (!joursResult.rows[0].jours.map(Number).includes(jourNum)) {
        throw Object.assign(
          new Error(`L'école ne travaille pas le ${NOMS_JOURS[jourNum]}. Modifiez la grille horaire si besoin.`),
          { statusCode: 400 }
        );
      }

      // ---------- Conflit professeur : contrainte bloquante ----------
      const professeursResult = await client.query(
        `SELECT utilisateur_id FROM enseignant_cours WHERE classe_cours_id = $1`,
        [classe_cours_id]
      );
      const idsProfesseurs = professeursResult.rows.map((r) => r.utilisateur_id);

      if (idsProfesseurs.length > 0) {
        // Le conflit se mesure au CHEVAUCHEMENT HORAIRE, pas à l'identité du
        // créneau. Avec plusieurs vacations, deux grilles distinctes peuvent
        // couvrir la même heure : comparer les identifiants laisserait passer
        // un professeur placé à 8h le matin ET à 8h en « deux gongs ».
        const horaire = await client.query(
          `SELECT heure_debut, heure_fin FROM creneaux WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [creneau_id]
        );
        if (horaire.rows.length === 0) {
          throw Object.assign(new Error('Créneau introuvable.'), { statusCode: 400 });
        }
        const { heure_debut, heure_fin } = horaire.rows[0];

        const conflitResult = await client.query(
          `SELECT DISTINCT c.nom AS classe_nom,
                  trim(concat(u.prenom, ' ', u.nom)) AS professeur,
                  cr.libelle AS creneau,
                  v.nom AS vacation
           FROM emploi_du_temps edt
           JOIN creneaux cr ON cr.id = edt.creneau_id
           LEFT JOIN vacations v ON v.id = cr.vacation_id
           JOIN enseignant_cours ec ON ec.classe_cours_id = edt.classe_cours_id
           JOIN utilisateurs u ON u.id = ec.utilisateur_id
           JOIN classes c ON c.id = edt.classe_id
           WHERE edt.jour = $1 AND edt.annee_scolaire_id = $2
             AND edt.classe_id <> $3
             AND ec.utilisateur_id = ANY($4::uuid[])
             AND cr.heure_debut < $6::time AND cr.heure_fin > $5::time`,
          [jourNum, annee.id, classe_id, idsProfesseurs, heure_debut, heure_fin]
        );
        if (conflitResult.rows.length > 0) {
          const c = conflitResult.rows[0];
          const precision = c.vacation ? ` (${c.vacation}, ${c.creneau})` : ` (${c.creneau})`;
          throw Object.assign(
            new Error(`${c.professeur} donne déjà cours en ${c.classe_nom} à ce moment-là${precision}. Choisissez un autre créneau ou un autre professeur.`),
            { statusCode: 409 }
          );
        }
      }

      // Une case ne contient qu'un cours : replacer sur une case occupée remplace.
      await client.query(
        `INSERT INTO emploi_du_temps (ecole_id, classe_id, classe_cours_id, jour, creneau_id, annee_scolaire_id, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6)
         ON CONFLICT (classe_id, jour, creneau_id, annee_scolaire_id)
         DO UPDATE SET classe_cours_id = EXCLUDED.classe_cours_id, cree_par = EXCLUDED.cree_par, updated_at = now()`,
        [classe_id, classe_cours_id, jourNum, creneau_id, annee.id, req.auth.userId]
      );

      return coursResult.rows[0].cours_nom;
    });

    return res.json({ message: `${resultat} placé.` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur placement séance:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** DELETE /emploi-du-temps/seance — retire un cours d'une case. */
async function retirerSeance(req, res) {
  const { classe_id, jour, creneau_id } = req.body;
  if (!classe_id || !creneau_id || !jour) {
    return res.status(400).json({ message: 'classe_id, jour et creneau_id sont requis.' });
  }

  try {
    const supprimees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) throw Object.assign(new Error('Aucune année scolaire active.'), { statusCode: 409 });
      const r = await client.query(
        `DELETE FROM emploi_du_temps
         WHERE classe_id = $1 AND jour = $2 AND creneau_id = $3 AND annee_scolaire_id = $4`,
        [classe_id, Number(jour), creneau_id, annee.id]
      );
      return r.rowCount;
    });

    if (supprimees === 0) return res.status(404).json({ message: 'Cette case est déjà vide.' });
    return res.json({ message: 'Cours retiré.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur retrait séance:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /emploi-du-temps/mon-emploi
 * Emploi du temps personnel d'un professeur, toutes classes confondues.
 */
async function monEmploi(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) return { annee_active: null, seances: [] };

      const result = await client.query(
        `SELECT edt.id, edt.jour, edt.creneau_id,
                c.nom AS classe_nom, co.nom AS cours_nom
         FROM emploi_du_temps edt
         JOIN classe_cours cc ON cc.id = edt.classe_cours_id
         JOIN cours co ON co.id = cc.cours_id
         JOIN classes c ON c.id = edt.classe_id
         JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
         WHERE ec.utilisateur_id = $1 AND edt.annee_scolaire_id = $2
         ORDER BY edt.jour`,
        [req.auth.userId, annee.id]
      );

      // Un directeur ou un préfet n'enseigne pas forcément un cours. « Mon
      // emploi du temps » reste alors simplement vide — c'est la grille des
      // classes (l'autre onglet de l'écran) qui donne la vue d'établissement,
      // et c'est elle qu'il doit consulter pour piloter. On ne substitue plus
      // cette grille ici : mélanger les deux sous « mon emploi du temps »
      // laissait croire, à tort, que les cours affichés étaient les siens.
      // S'il enseigne effectivement un cours (professeur d'un classe_cours,
      // qu'il soit par ailleurs directeur ou non), la requête ci-dessus le
      // retrouve normalement et cette section n'est jamais atteinte.
      return { annee_active: annee, portee: 'personnel', seances: result.rows };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur mon emploi du temps:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /emploi-du-temps/aujourdhui
 * Séances du jour pour l'utilisateur connecté : alimente l'espace Professeur.
 */
async function aujourdhui(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) return { jour: null, seances: [] };

      // getDay() JavaScript renvoie 0 pour dimanche ; on reste sur la
      // convention ISO utilisée partout ailleurs (1 = lundi … 7 = dimanche).
      const jsJour = new Date().getDay();
      const jour = jsJour === 0 ? 7 : jsJour;

      // Les horaires exceptionnels s'appliquent ICI en priorité : c'est
      // l'écran que le professeur regarde le matin. Lui afficher l'horaire
      // habituel un jour où l'école a décidé d'écourter reviendrait à le
      // faire arriver — ou repartir — à la mauvaise heure.
      //
      // Arbitrage : une exception posée sur SA classe l'emporte sur celle
      // posée pour toute l'école (ORDER BY ... NULLS LAST place la plus
      // spécifique en tête).
      const result = await client.query(
        `SELECT edt.id, cr.libelle AS creneau,
                COALESCE(exc.heure_debut, cr.heure_debut) AS heure_debut,
                COALESCE(exc.heure_fin,   cr.heure_fin)   AS heure_fin,
                (exc.id IS NOT NULL) AS horaire_exceptionnel,
                exc.motif AS motif_exception,
                cr.heure_debut AS heure_habituelle_debut,
                cr.heure_fin   AS heure_habituelle_fin,
                c.id AS classe_id, c.nom AS classe_nom, co.nom AS cours_nom
         FROM emploi_du_temps edt
         JOIN creneaux cr ON cr.id = edt.creneau_id
         JOIN classe_cours cc ON cc.id = edt.classe_cours_id
         JOIN cours co ON co.id = cc.cours_id
         JOIN classes c ON c.id = edt.classe_id
         JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
         LEFT JOIN LATERAL (
           SELECT ex.id, ex.heure_debut, ex.heure_fin, ex.motif
           FROM creneaux_exceptions ex
           WHERE ex.ecole_id = ${CURRENT_ECOLE}
             AND ex.creneau_id = edt.creneau_id
             AND ex.jour = edt.jour
             AND (ex.classe_id = edt.classe_id OR ex.classe_id IS NULL)
           ORDER BY ex.classe_id NULLS LAST
           LIMIT 1
         ) exc ON true
         WHERE ec.utilisateur_id = $1 AND edt.annee_scolaire_id = $2 AND edt.jour = $3
         ORDER BY COALESCE(exc.heure_debut, cr.heure_debut), cr.ordre`,
        [req.auth.userId, annee.id, jour]
      );
      return { jour, jour_nom: NOMS_JOURS[jour], seances: result.rows };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur séances du jour:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ============================================================================
//  Horaires exceptionnels
//
//  La page `emploi-du-temps.html` appelait ces trois routes depuis sa carte
//  « Horaires exceptionnels » — mais ni la table, ni le contrôleur, ni les
//  routes n'existaient : chaque clic renvoyait 404. Le backend est écrit ici,
//  et la table par la migration 011.
//
//  Sémantique : `jour` est un jour de la SEMAINE récurrent (1 = lundi …
//  7 = dimanche). On exprime « le mercredi, la 3ᵉ heure finit à 11h30 », pas
//  « ce mercredi 15 octobre ». Une fermeture ponctuelle relève de
//  `jours_speciaux` (calendrier), pas d'ici.
// ============================================================================

const FORMAT_HEURE = /^([01]\d|2[0-3]):[0-5]\d$/;

/**
 * GET /emploi-du-temps/exceptions
 * Toutes les exceptions de l'école, avec l'horaire habituel qu'elles
 * remplacent — sans lui, le tableau afficherait une nouvelle heure sans
 * qu'on puisse voir ce qu'elle change.
 */
async function listerExceptions(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const result = await client.query(
        `SELECT ex.id, ex.jour, ex.creneau_id, ex.classe_id,
                ex.heure_debut, ex.heure_fin, ex.motif,
                cr.libelle AS creneau_libelle,
                cr.heure_debut AS heure_habituelle_debut,
                cr.heure_fin   AS heure_habituelle_fin,
                c.nom AS classe_nom
         FROM creneaux_exceptions ex
         JOIN creneaux cr ON cr.id = ex.creneau_id
         LEFT JOIN classes c ON c.id = ex.classe_id
         WHERE ex.ecole_id = ${CURRENT_ECOLE}
         ORDER BY ex.jour, cr.ordre, c.nom NULLS FIRST`
      );
      return result.rows;
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste horaires exceptionnels:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /emploi-du-temps/exceptions
 * Pose ou remplace l'exception d'une case (créneau × jour × portée).
 */
async function definirException(req, res) {
  const { creneau_id, jour, classe_id, heure_debut, heure_fin, motif } = req.body;

  if (!creneau_id) return res.status(400).json({ message: 'Choisissez l\'heure habituelle à remplacer.' });

  const jourNum = Number(jour);
  if (!Number.isInteger(jourNum) || jourNum < 1 || jourNum > 7) {
    return res.status(400).json({ message: 'Jour invalide : les valeurs vont de 1 (lundi) à 7 (dimanche).' });
  }

  const debut = String(heure_debut || '').slice(0, 5);
  const fin = String(heure_fin || '').slice(0, 5);
  if (!FORMAT_HEURE.test(debut) || !FORMAT_HEURE.test(fin)) {
    return res.status(400).json({ message: 'Horaires invalides. Format attendu : HH:MM.' });
  }
  if (debut >= fin) {
    return res.status(400).json({ message: "L'heure de fin doit suivre l'heure de début." });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const creneauResult = await client.query(
        `SELECT id, libelle, heure_debut, heure_fin FROM creneaux
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [creneau_id]
      );
      if (creneauResult.rows.length === 0) {
        throw Object.assign(new Error('Heure de cours introuvable.'), { statusCode: 400 });
      }
      const creneau = creneauResult.rows[0];

      let nomClasse = null;
      if (classe_id) {
        const classeResult = await client.query(
          `SELECT nom FROM classes WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [classe_id]
        );
        if (classeResult.rows.length === 0) {
          throw Object.assign(new Error('Classe introuvable.'), { statusCode: 400 });
        }
        nomClasse = classeResult.rows[0].nom;
      }

      // Le jour doit rester un jour travaillé : poser un horaire exceptionnel
      // sur un dimanche non travaillé produirait une ligne que personne ne
      // verrait jamais s'appliquer.
      const joursResult = await client.query(
        `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5,6]) AS jours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      if (!joursResult.rows[0].jours.map(Number).includes(jourNum)) {
        throw Object.assign(
          new Error(`Le ${NOMS_JOURS[jourNum]} ne fait pas partie des jours de cours de l'école.`),
          { statusCode: 400 }
        );
      }

      // Deux requêtes distinctes, et non un seul ON CONFLICT : l'unicité
      // repose sur deux index PARTIELS (classe_id NULL / non NULL), et
      // PostgreSQL exige que la clause ON CONFLICT désigne un index précis.
      if (classe_id) {
        await client.query(
          `INSERT INTO creneaux_exceptions
             (ecole_id, creneau_id, jour, classe_id, heure_debut, heure_fin, motif, cree_par)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (creneau_id, jour, classe_id) WHERE classe_id IS NOT NULL
           DO UPDATE SET heure_debut = EXCLUDED.heure_debut,
                         heure_fin = EXCLUDED.heure_fin,
                         motif = EXCLUDED.motif,
                         cree_par = EXCLUDED.cree_par,
                         updated_at = now()`,
          [creneau_id, jourNum, classe_id, debut, fin, (motif || '').trim() || null, req.auth.userId]
        );
      } else {
        await client.query(
          `INSERT INTO creneaux_exceptions
             (ecole_id, creneau_id, jour, classe_id, heure_debut, heure_fin, motif, cree_par)
           VALUES (${CURRENT_ECOLE}, $1, $2, NULL, $3, $4, $5, $6)
           ON CONFLICT (creneau_id, jour) WHERE classe_id IS NULL
           DO UPDATE SET heure_debut = EXCLUDED.heure_debut,
                         heure_fin = EXCLUDED.heure_fin,
                         motif = EXCLUDED.motif,
                         cree_par = EXCLUDED.cree_par,
                         updated_at = now()`,
          [creneau_id, jourNum, debut, fin, (motif || '').trim() || null, req.auth.userId]
        );
      }

      const portee = nomClasse ? `pour ${nomClasse}` : "pour toute l'école";
      return `Le ${NOMS_JOURS[jourNum]}, « ${creneau.libelle} » se tiendra de ${debut} à ${fin} ${portee}.`;
    });

    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement horaire exceptionnel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /emploi-du-temps/exceptions/:id
 * Rétablit l'horaire habituel : l'exception disparaît, la grille reprend.
 */
async function supprimerException(req, res) {
  const { id } = req.params;
  try {
    const supprimees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `DELETE FROM creneaux_exceptions WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      return r.rowCount;
    });
    if (supprimees === 0) {
      return res.status(404).json({ message: 'Horaire exceptionnel introuvable.' });
    }
    return res.json({ message: 'Horaire habituel rétabli.' });
  } catch (err) {
    console.error('Erreur suppression horaire exceptionnel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  configuration,
  enregistrerConfiguration,
  emploiDeClasse,
  placerSeance,
  retirerSeance,
  monEmploi,
  aujourdhui,
  listerExceptions,
  definirException,
  supprimerException
};
