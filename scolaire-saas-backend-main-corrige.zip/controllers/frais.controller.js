const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const {
  anneeActive, exigerAnnee, estExempteRestrictionAnnee, prefixeNumerotation
} = require('../utils/annee.utils');
const {
  DEVISES, DEVISE_PAR_DEFAUT, normaliserDevise, lireConfigMonetaire,
  exigerTaux, convertir, formaterMontant, sqlPaiementConverti, sqlFraisConverti
} = require('../utils/devise.utils');
// BUG PRÉEXISTANT CORRIGÉ ICI (indépendant des notifications).
// `detailFraisDus` et `sqlTotalFraisDus` étaient déjà utilisés à quatre
// endroits de ce fichier — lignes des frais dus d'un élève, dettes
// antérieures, statistiques globales — sans jamais être importés. Chacun de
// ces appels lève un ReferenceError à l'exécution : l'écran « frais dus »
// d'un élève et le calcul des arriérés ne pouvaient pas fonctionner.
// Le vérificateur d'imports du projet ne l'a pas vu, car il contrôle les
// chemins de `require` et les handlers de routes, pas les symboles employés.
const { detailFraisDus, sqlTotalFraisDus } = require('../utils/frais.utils');
const { notifierEvenement, planifierVidage } = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Vérifie qu'aucun paiement n'exige une conversion impossible.
 *
 * Sans ce garde-fou, un SUM(CASE ...) renvoie NULL pour les lignes non convertibles
 * et PostgreSQL les ignore silencieusement : le total versé serait sous-évalué et
 * l'école réclamerait de l'argent déjà payé. On préfère une erreur explicite.
 */
async function verifierConversionsPossibles(client, { anneeScolaireId, taux, eleveId = null, classeId = null }) {
  if (taux) return;
  const conditions = [`p.ecole_id = ${CURRENT_ECOLE}`, `p.annee_scolaire_id = $1`];
  const params = [anneeScolaireId];
  if (eleveId) { params.push(eleveId); conditions.push(`p.eleve_id = $${params.length}`); }
  if (classeId) {
    params.push(classeId);
    conditions.push(`p.eleve_id IN (SELECT id FROM eleves WHERE classe_id = $${params.length})`);
  }

  const r = await client.query(
    `SELECT count(*) AS n FROM paiements_frais p
      WHERE ${conditions.join(' AND ')}
        AND p.taux_change IS NULL
        -- Devise DOMINANTE de l'année, et non celle d'une ligne prise au
        -- hasard : une école qui facture surtout en FC avec une ligne annexe en
        -- USD ne doit pas voir tous ses paiements en FC signalés comme
        -- nécessitant une conversion.
        AND p.devise <> COALESCE((
          SELECT f.devise FROM frais_scolaires f
           WHERE f.ecole_id = ${CURRENT_ECOLE} AND f.annee_scolaire_id = p.annee_scolaire_id
           GROUP BY f.devise
           ORDER BY count(*) DESC, f.devise
           LIMIT 1
        ), '${DEVISE_PAR_DEFAUT}')`,
    params
  );
  if (Number(r.rows[0].n) > 0) exigerTaux(null);
}

/**
 * Seul le comptable (et le super admin) peut consulter les frais/dettes d'une
 * année scolaire différente de l'année active — c'est la SEULE exception à
 * la règle "tout est cantonné à l'année pivot". Directeur, préfet et
 * secrétaire restent limités à l'année active sur ces écrans financiers.
 * Renvoie l'anneeScolaireId à utiliser réellement pour la requête.
 */
async function resoudreAnneeAutorisee(client, req, anneeScolaireIdDemandee) {
  const active = await anneeActive(client);
  if (estExempteRestrictionAnnee(req)) {
    return anneeScolaireIdDemandee || active?.id || null;
  }
  if (anneeScolaireIdDemandee && active && String(anneeScolaireIdDemandee) !== String(active.id)) {
    throw Object.assign(
      new Error("Seul le comptable peut consulter les frais/dettes d'une année antérieure à l'année active."),
      { statusCode: 403 }
    );
  }
  return active?.id || null;
}

// ---------- Configuration des montants attendus ----------

/**
 * GET /frais/config?anneeScolaireId=
 */
async function listerConfig(req, res) {
  const { anneeScolaireId } = req.query;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const anneeAutorisee = await resoudreAnneeAutorisee(client, req, anneeScolaireId);
      const conditions = [`f.ecole_id = ${CURRENT_ECOLE}`];
      const params = [];
      if (anneeAutorisee) { params.push(anneeAutorisee); conditions.push(`f.annee_scolaire_id = $${params.length}`); }
      return client.query(
        `SELECT f.*, c.nom AS classe_nom, a.libelle AS annee_libelle FROM frais_scolaires f
         LEFT JOIN classes c ON c.id = f.classe_id
         JOIN annees_scolaires a ON a.id = f.annee_scolaire_id
         WHERE ${conditions.join(' AND ')}
         ORDER BY c.nom NULLS FIRST`,
        params
      );
    });
    res.json(result.rows);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste config frais:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /frais/config
 * body: { annee_scolaire_id, classe_id (optionnel, NULL = toutes les classes),
 *         montant, devise ('FC' | 'USD'), libelle (optionnel) }
 *
 * Le montant est décidé dans UNE devise — en RDC, le minerval est très souvent
 * libellé en dollars alors que les familles règlent en francs. Le taux du jour est
 * figé ici avec la configuration : si le taux de l'école évolue en cours d'année,
 * le montant réclamé aux familles ne bouge pas en douce derrière leur dos.
 *
 * Le libellé est celui qui apparaîtra sur les reçus des paiements rattachés
 * à cette config (ex. "Minerval", "Frais d'inscription").
 */
async function creerConfig(req, res) {
  const { annee_scolaire_id, classe_id, montant, libelle } = req.body;
  if (!annee_scolaire_id || montant === undefined || montant === null || montant === '') {
    return res.status(400).json({ message: 'annee_scolaire_id et montant sont requis.' });
  }

  const montantNum = Number(montant);
  if (Number.isNaN(montantNum) || montantNum < 0) {
    return res.status(400).json({ message: 'Le montant doit être un nombre positif.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const devise = normaliserDevise(req.body.devise);

      // On ne configure pas de frais sur une année clôturée : ses comptes sont arrêtés.
      const annee = await client.query(
        `SELECT id, libelle, cloturee FROM annees_scolaires
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [annee_scolaire_id]
      );
      if (annee.rows.length === 0) {
        throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
      }
      if (annee.rows[0].cloturee) {
        throw Object.assign(
          new Error(`L'année « ${annee.rows[0].libelle} » est clôturée : ses frais ne peuvent plus être modifiés.`),
          { statusCode: 409 }
        );
      }

      const { taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      // L'équivalent dans l'autre devise n'est calculé que si un taux existe.
      // Sans taux, on enregistre le montant dans sa devise et rien d'autre :
      // aucun chiffre inventé ne doit se retrouver sur un document comptable.
      let montantUsd = null;
      let montantFc = null;
      if (devise === 'USD') {
        montantUsd = montantNum;
        montantFc = taux ? convertir(montantNum, 'USD', 'FC', taux) : null;
      } else {
        montantFc = montantNum;
        montantUsd = taux ? convertir(montantNum, 'FC', 'USD', taux) : null;
      }

      const insere = await client.query(
        `INSERT INTO frais_scolaires
           (ecole_id, annee_scolaire_id, classe_id, montant, devise, taux_change,
            montant_usd, montant_fc, libelle)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [annee_scolaire_id, classe_id || null, montantNum, devise, taux || null,
         montantUsd, montantFc, (libelle || '').trim() || 'Frais scolaires']
      );

      return {
        id: insere.rows[0].id,
        devise,
        taux_applique: taux || null,
        equivalent: devise === 'USD' ? montantFc : montantUsd
      };
    });

    return res.status(201).json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création config frais:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Taux de change
   Le taux n'est pas une donnée de marché récupérée automatiquement : c'est une
   décision de gestion. L'école affiche SON taux, celui auquel elle accepte les
   règlements, et c'est le comptable qui le fixe et l'ajuste.
   ========================================================================== */

/** GET /frais/taux-change */
async function lireTauxChange(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const config = await lireConfigMonetaire(client);
      const auteur = await client.query(
        `SELECT trim(concat(u.prenom, ' ', u.nom)) AS nom
           FROM ecoles e LEFT JOIN utilisateurs u ON u.id = e.taux_change_maj_par
          WHERE e.id = ${CURRENT_ECOLE}`
      );
      return { ...config, devises_disponibles: DEVISES, maj_par: auteur.rows[0]?.nom || null };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur lecture taux de change:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /frais/taux-change  (Directeur / Comptable)
 * body: { taux_change_usd_fc, devise_principale (optionnel) }
 *
 * Le taux n'est PAS rétroactif : les paiements déjà encaissés conservent le taux
 * qui leur a été appliqué (colonne taux_change de paiements_frais), et les montants
 * attendus déjà configurés gardent le leur. Changer le taux n'affecte donc que ce
 * qui sera saisi ensuite — sans quoi tous les soldes de l'école bougeraient d'un
 * coup à chaque ajustement.
 */
async function definirTauxChange(req, res) {
  const { taux_change_usd_fc, devise_principale } = req.body;
  const taux = Number(taux_change_usd_fc);
  if (!taux_change_usd_fc || Number.isNaN(taux) || taux <= 0) {
    return res.status(400).json({ message: 'Le taux de change doit être un nombre strictement positif (nombre de FC pour 1 USD).' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const devise = devise_principale ? normaliserDevise(devise_principale) : null;
      const avant = await lireConfigMonetaire(client);

      await client.query(
        `UPDATE ecoles SET
           taux_change_usd_fc = $1,
           devise_principale = COALESCE($2, devise_principale),
           taux_change_maj_at = now(),
           taux_change_maj_par = $3,
           updated_at = now()
         WHERE id = ${CURRENT_ECOLE}`,
        [taux, devise, req.auth.userId]
      );

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'frais.taux_change_modifie', 'ecole', $2)`,
        [req.auth.userId, JSON.stringify({ ancien: avant.taux_change_usd_fc, nouveau: taux })]
      );

      return { taux_change_usd_fc: taux, devise_principale: devise || avant.devise_principale };
    });

    return res.json({
      ...resultat,
      message: `Taux enregistré : 1 USD = ${formaterMontant(resultat.taux_change_usd_fc, 'FC')}. Les paiements déjà encaissés conservent leur taux d'origine.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur définition taux de change:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerConfig(req, res) {
  const { id } = req.params;
  await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query('DELETE FROM frais_scolaires WHERE id = $1', [id])
  );
  res.json({ message: 'Configuration supprimée.' });
}

// ---------- Vue élèves avec état des paiements ----------

/**
 * GET /frais/eleves?classeId=&anneeScolaireId=
 * Pour chaque élève : montant attendu (config de sa classe, sinon config "toutes classes"),
 * total payé, et solde restant.
 */
async function listerElevesAvecPaiements(req, res) {
  const { classeId, anneeScolaireId } = req.query;
  if (!classeId || !anneeScolaireId) {
    return res.status(400).json({ message: 'classeId et anneeScolaireId sont requis.' });
  }

  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (!estExempteRestrictionAnnee(req)) {
        const active = await anneeActive(client);
        if (!active || String(active.id) !== String(anneeScolaireId)) {
          throw Object.assign(
            new Error("Seul le comptable peut consulter les frais/dettes d'une année antérieure à l'année active."),
            { statusCode: 403 }
          );
        }
      }
      const { taux_change_usd_fc: taux } = await lireConfigMonetaire(client);
      await verifierConversionsPossibles(client, { anneeScolaireId, taux, classeId });

      // DEUX corrections majeures dans cette requête :
      //
      // 1. Les paiements sont filtrés sur `annee_scolaire_id`. Auparavant la somme
      //    portait sur TOUS les paiements de l'élève depuis son inscription : ce qu'il
      //    avait réglé l'an dernier venait éteindre la dette de cette année, et la
      //    notion de dette antérieure était impossible à calculer.
      // 2. Chaque paiement est ramené dans la devise du montant attendu. Additionner
      //    directement des dollars et des francs donnait un total dénué de sens.
      const paiementConverti = sqlPaiementConverti('p', 'a.devise', 3);

      return client.query(
        // Le montant attendu est la SOMME de toutes les lignes de frais
        // applicables, une par libellé, la ligne propre à la classe primant sur
        // la ligne générale du même nom. Auparavant une seule ligne était
        // retenue : une école réclamant inscription + minerval + laboratoire
        // n'en voyait compter qu'une, et déclarait ses familles à jour.
        //
        // La devise de référence reste celle de la ligne la plus spécifique :
        // c'est elle qui exprime l'intention de l'école pour cette classe.
        `WITH attendu AS (
           SELECT
             COALESCE((
               SELECT SUM(t.montant) FROM (
                 SELECT DISTINCT ON (f.libelle) f.montant
                   FROM frais_scolaires f
                  WHERE f.ecole_id = ${CURRENT_ECOLE} AND f.annee_scolaire_id = $2
                    AND (f.classe_id = $1 OR f.classe_id IS NULL)
                  ORDER BY f.libelle, f.classe_id NULLS LAST
               ) t
             ), 0) AS montant,
             COALESCE(
               (SELECT devise FROM frais_scolaires
                 WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $2 AND classe_id = $1 LIMIT 1),
               (SELECT devise FROM frais_scolaires
                 WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $2 AND classe_id IS NULL LIMIT 1),
               '${DEVISE_PAR_DEFAUT}'
             ) AS devise
         )
         SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule,
                COALESCE(e.derogation_financiere, false) AS derogation_financiere,
                a.montant AS montant_attendu,
                a.devise,
                COALESCE((
                  SELECT SUM(${paiementConverti})
                    FROM paiements_frais p
                   WHERE p.eleve_id = e.id AND p.annee_scolaire_id = $2
                ), 0) AS montant_paye
         FROM eleves e CROSS JOIN attendu a
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         ORDER BY e.nom, e.postnom`,
        [classeId, anneeScolaireId, taux || null]
      );
    });

    const lignes = result.rows.map(r => {
      const attendu = Number(r.montant_attendu);
      const paye = Math.round(Number(r.montant_paye) * 100) / 100;
      return { ...r, montant_paye: paye, solde: Math.round((attendu - paye) * 100) / 100 };
    });
    res.json(lignes);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste élèves avec paiements:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /frais/eleves/:eleveId/paiements
 */
async function listerPaiementsEleve(req, res) {
  const { eleveId } = req.params;
  const { anneeScolaireId, toutes } = req.query;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const exempte = estExempteRestrictionAnnee(req);

      // L'historique COMPLET (toutes années) est réservé aux rôles exemptés :
      // c'est ce dont le comptable a besoin pour reconstituer une dette ancienne.
      // Pour tous les autres, la liste est cantonnée à une seule année — le pivot
      // par défaut. L'ancien code renvoyait systématiquement tous les paiements de
      // toute la scolarité, quel que soit le rôle.
      if (exempte && (toutes === '1' || toutes === 'true')) {
        return client.query(
          `SELECT p.*, u.nom AS enregistre_par_nom, a.libelle AS annee_libelle
             FROM paiements_frais p
             LEFT JOIN utilisateurs u ON u.id = p.enregistre_par
             LEFT JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
            WHERE p.eleve_id = $1
            ORDER BY a.date_debut DESC NULLS LAST, p.date_paiement DESC`,
          [eleveId]
        );
      }

      const anneeId = await resoudreAnneeAutorisee(client, req, anneeScolaireId);
      return client.query(
        `SELECT p.*, u.nom AS enregistre_par_nom, a.libelle AS annee_libelle
           FROM paiements_frais p
           LEFT JOIN utilisateurs u ON u.id = p.enregistre_par
           LEFT JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
          WHERE p.eleve_id = $1 AND p.annee_scolaire_id = $2
          ORDER BY p.date_paiement DESC`,
        [eleveId, anneeId]
      );
    });
    res.json(result.rows);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste paiements élève:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Dettes des années antérieures

   Fonctionnalité qui manquait entièrement. Elle n'était d'ailleurs pas
   calculable : sans `annee_scolaire_id` sur les paiements, impossible de dire
   ce qui restait dû sur un exercice passé. C'est la seule exception à la règle
   « tout est cantonné à l'année pivot » — une dette ne s'efface pas au
   changement d'année, et c'est au comptable de la réclamer.
   ========================================================================== */

/**
 * Calcule, année par année, ce qui reste dû par un élève en dehors de l'année
 * active. On s'appuie sur `eleve_classe_historique` : c'est lui qui garde la
 * trace de la classe occupée chaque année, donc du montant qui était attendu.
 */
async function calculerDettesEleve(client, eleveId, { anneeActiveId, devise, taux }) {
  const r = await client.query(
    `WITH annees_eleve AS (
       SELECT DISTINCT h.annee_scolaire_id AS annee_id, h.classe_id
         FROM eleve_classe_historique h
        WHERE h.eleve_id = $1 AND h.ecole_id = ${CURRENT_ECOLE}
          AND ($2::uuid IS NULL OR h.annee_scolaire_id <> $2)
       UNION
       -- Un paiement rattaché à une année sans ligne d'historique (élève parti
       -- avant la clôture, reprise de données) ne doit pas disparaître du calcul.
       SELECT DISTINCT p.annee_scolaire_id, NULL::uuid
         FROM paiements_frais p
        WHERE p.eleve_id = $1 AND p.ecole_id = ${CURRENT_ECOLE}
          AND p.annee_scolaire_id IS NOT NULL
          AND ($2::uuid IS NULL OR p.annee_scolaire_id <> $2)
     )
     SELECT ae.annee_id, a.libelle AS annee_libelle, a.date_debut, a.cloturee,
            cl.nom AS classe_nom,
            ${sqlTotalFraisDus('ae.classe_id', 'ae.annee_id', '$3', 4, CURRENT_ECOLE)} AS attendu,
            COALESCE((
              SELECT SUM(${sqlPaiementConverti('p', '$3', 4)})
                FROM paiements_frais p
               WHERE p.eleve_id = $1 AND p.annee_scolaire_id = ae.annee_id
            ), 0) AS paye
       FROM annees_eleve ae
       JOIN annees_scolaires a ON a.id = ae.annee_id
       LEFT JOIN classes cl ON cl.id = ae.classe_id
      ORDER BY a.date_debut DESC NULLS LAST`,
    [eleveId, anneeActiveId || null, devise, taux || null]
  );

  const arrondi = (v) => Math.round(Number(v || 0) * 100) / 100;
  const annees = r.rows.map((ligne) => {
    const attendu = arrondi(ligne.attendu);
    const paye = arrondi(ligne.paye);
    return {
      annee_scolaire_id: ligne.annee_id,
      annee_libelle: ligne.annee_libelle,
      classe_nom: ligne.classe_nom,
      cloturee: ligne.cloturee,
      attendu, paye,
      solde: arrondi(attendu - paye)
    };
  });

  // Un trop-perçu sur une année n'annule pas une dette sur une autre : on ne
  // compense pas, chaque exercice reste lu séparément. Seuls les soldes
  // positifs forment la dette réclamable.
  const dette = arrondi(annees.reduce((t, a) => t + Math.max(a.solde, 0), 0));
  return { annees, dette_totale: dette, devise };
}

/**
 * GET /frais/dettes-anterieures?eleveId=      → détail année par année d'un élève
 * GET /frais/dettes-anterieures?classeId=     → total par élève d'une classe
 *
 * Réservé au comptable (et au super admin) : c'est l'exception assumée à la
 * règle du pivot, déjà documentée dans utils/annee.utils.js.
 */
async function dettesAnterieures(req, res) {
  const { eleveId, classeId } = req.query;
  if (!eleveId && !classeId) {
    return res.status(400).json({ message: 'eleveId ou classeId est requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const active = await anneeActive(client);
      const config = await lireConfigMonetaire(client);
      const contexte = {
        anneeActiveId: active?.id || null,
        devise: config.devise_principale,
        taux: config.taux_change_usd_fc
      };

      if (eleveId) {
        const eleve = await client.query(
          `SELECT id, matricule, nom, postnom, prenom FROM eleves
            WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [eleveId]
        );
        if (eleve.rows.length === 0) {
          throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
        }
        const detail = await calculerDettesEleve(client, eleveId, contexte);
        return { eleve: eleve.rows[0], ...detail, annee_active: active?.libelle || null };
      }

      const eleves = await client.query(
        `SELECT id, matricule, nom, postnom, prenom FROM eleves
          WHERE classe_id = $1 AND ecole_id = ${CURRENT_ECOLE} AND statut = 'actif'
          ORDER BY nom, postnom`,
        [classeId]
      );

      const lignes = [];
      for (const eleve of eleves.rows) {
        const detail = await calculerDettesEleve(client, eleve.id, contexte);
        // On ne renvoie que les élèves réellement débiteurs : une liste où 90 %
        // des lignes sont à zéro est illisible pour le comptable qui relance.
        if (detail.dette_totale > 0) {
          lignes.push({
            ...eleve,
            dette_totale: detail.dette_totale,
            annees: detail.annees.filter((a) => a.solde > 0)
          });
        }
      }

      const arrondi = (v) => Math.round(Number(v || 0) * 100) / 100;
      return {
        classe_id: classeId,
        devise: config.devise_principale,
        annee_active: active?.libelle || null,
        nb_debiteurs: lignes.length,
        dette_totale: arrondi(lignes.reduce((t, l) => t + l.dette_totale, 0)),
        eleves: lignes
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur dettes antérieures:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Génère un numéro de pièce comptable unique, ex. "PAI-2025-2026-000123".
 *
 * Le préfixe porte l'année SCOLAIRE, pas l'année civile. Avec l'ancienne
 * numérotation (`PAI-2026-…`), une même année scolaire produisait deux séries —
 * l'une jusqu'au 31 décembre, l'autre à partir du 1er janvier — et un reçu de
 * janvier semblait appartenir à l'exercice suivant. Le compteur redémarre
 * maintenant à chaque année scolaire, ce qui est aussi ce qu'attend un
 * vérificateur qui feuillette un carnet de reçus.
 */
async function genererNumeroPiece(client, { table, colonne, prefixe, annee }) {
  const motif = `${prefixe}-${prefixeNumerotation(annee)}-`;

  for (let essai = 0; essai < 6; essai++) {
    const suivant = await client.query(
      `SELECT COALESCE(max((regexp_match(${colonne}, '(\\d+)$'))[1]::bigint), 0) + 1 AS n
         FROM ${table}
        WHERE ecole_id = ${CURRENT_ECOLE} AND ${colonne} LIKE $1`,
      [`${motif}%`]
    );
    const rang = Number(suivant.rows[0].n) + essai;
    const numero = `${motif}${String(rang).padStart(6, '0')}`;

    const conflit = await client.query(
      `SELECT 1 FROM ${table} WHERE ecole_id = ${CURRENT_ECOLE} AND ${colonne} = $1`,
      [numero]
    );
    if (conflit.rows.length === 0) return numero;
  }
  throw new Error(`Impossible de générer un numéro unique (${prefixe}).`);
}

/**
 * POST /frais/paiements
 * body: { eleve_id, montant, devise ('FC' | 'USD'), methode, notes }
 *
 * La référence est générée par le serveur (jamais par le client) et le
 * libellé est celui configuré par le comptable pour la classe de l'élève —
 * il est figé au moment du paiement pour ne pas bouger sur les reçus déjà
 * émis si la config change ensuite.
 *
 * Deux informations désormais figées avec le paiement :
 *   - `annee_scolaire_id` : sans lui, un règlement encaissé aujourd'hui venait
 *     s'imputer sur la dette de n'importe quelle année. C'est ce qui rendait tout
 *     suivi d'impayés faux et les dettes antérieures incalculables.
 *   - `taux_change` : le taux appliqué à cet encaissement précis, pour que le reçu
 *     reste exact quand l'école révisera son taux.
 */
async function enregistrerPaiement(req, res) {
  const { eleve_id, montant, methode, notes, frais_id } = req.body;
  const montantNum = Number(montant);
  if (!eleve_id || !montant || Number.isNaN(montantNum) || montantNum <= 0) {
    return res.status(400).json({ message: 'eleve_id et un montant strictement positif sont requis.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const devise = normaliserDevise(req.body.devise);

      // Un encaissement se fait TOUJOURS sur l'année en cours : c'est l'exercice
      // ouvert. Le comptable peut consulter les années antérieures, pas y écrire.
      const annee = exigerAnnee(await anneeActive(client));

      const eleve = await client.query(
        `SELECT id, classe_id FROM eleves WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [eleve_id]
      );
      if (eleve.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }

      const { taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      // ---------- Quel frais est réglé ? ----------
      // Un encaissement était un montant sans objet. Une famille versant 50 $
      // sur un total de 170 $ réparti en quatre lignes : personne ne savait ce
      // qui était réglé, ni le reçu, ni la relance.
      //
      // Quand `frais_id` est fourni, l'encaissement s'y rattache et le reçu le
      // nomme. Sinon on retombe sur l'ancien comportement — un versement
      // global reste légitime, certaines écoles encaissent ainsi.
      let ligneFrais = null;
      if (frais_id) {
        const r = await client.query(
          `SELECT id, libelle, devise, classe_id FROM frais_scolaires
            WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $2`,
          [frais_id, annee.id]
        );
        if (r.rows.length === 0) {
          throw Object.assign(
            new Error("Ce frais n'existe pas pour l'année en cours."), { statusCode: 400 }
          );
        }
        // Un frais propre à une AUTRE classe ne concerne pas cet élève :
        // l'imputer là fausserait le solde des deux classes.
        if (r.rows[0].classe_id && r.rows[0].classe_id !== eleve.rows[0].classe_id) {
          throw Object.assign(
            new Error(
              `« ${r.rows[0].libelle} » est défini pour une autre classe que celle de cet élève.`
            ),
            { statusCode: 400 }
          );
        }
        ligneFrais = r.rows[0];
      }

      // Le libellé ET la devise attendue viennent de la ligne réglée si elle
      // est connue, sinon de la configuration générale de l'année.
      const config = await client.query(
        `SELECT libelle, devise FROM frais_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND (classe_id = $2 OR classe_id IS NULL)
          ORDER BY classe_id NULLS LAST
          LIMIT 1`,
        [annee.id, eleve.rows[0].classe_id]
      );
      const libelle = ligneFrais?.libelle || config.rows[0]?.libelle || 'Frais scolaires';
      const deviseAttendue = ligneFrais?.devise || config.rows[0]?.devise || DEVISE_PAR_DEFAUT;

      // Si la famille règle dans une autre devise que celle du minerval, il faut
      // un taux : sans lui le solde serait faux. On refuse tôt, avec un message
      // qui dit quoi faire, plutôt que d'enregistrer un paiement inexploitable.
      if (devise !== deviseAttendue) exigerTaux(taux);

      const reference = await genererNumeroPiece(client, {
        table: 'paiements_frais', colonne: 'reference', prefixe: 'PAI', annee
      });

      const paiement = await client.query(
        `INSERT INTO paiements_frais
           (ecole_id, eleve_id, annee_scolaire_id, montant, devise, taux_change,
            methode, enregistre_par, notes, reference, libelle, frais_id)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [eleve_id, annee.id, montantNum, devise, taux || null,
         methode || null, req.auth.userId, notes || null, reference, libelle,
         ligneFrais ? ligneFrais.id : null]
      );

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'frais.paiement_enregistre', 'eleve', $2, $3)`,
        [req.auth.userId, eleve_id,
         JSON.stringify({ montant: montantNum, devise, methode, reference, annee: annee.libelle })]
      );

      // ------------------------------------------------------------------
      // La trace écrite du versement
      // ------------------------------------------------------------------
      // Dans une école où le paiement se fait souvent en espèces, au guichet,
      // le seul justificatif d'une famille est un reçu papier qui se perd. Une
      // confirmation horodatée, avec la référence et le solde restant, règle
      // la moitié des litiges de fin d'année avant qu'ils n'existent.
      //
      // Elle ne remplace pas le reçu officiel (voir `imprimerRecu`) : elle le
      // double, ce qui est exactement le but.
      const contact = await client.query(
        `SELECT trim(concat_ws(' ', el.nom, el.postnom, el.prenom)) AS eleve,
                el.responsable_email, el.responsable_nom,
                cl.nom AS classe, e.nom AS ecole
           FROM eleves el
           JOIN ecoles e ON e.id = el.ecole_id
           LEFT JOIN classes cl ON cl.id = el.classe_id
          WHERE el.id = $1`,
        [eleve_id]
      );
      const infoEleve = contact.rows[0];

      if (infoEleve?.responsable_email) {
        // Le solde restant est calculé APRÈS l'insertion du paiement : c'est
        // la seule façon qu'il tienne compte du versement qu'on annonce.
        // L'afficher sans lui ferait croire à la famille que son argent n'a
        // pas été pris en compte.
        //
        // C'est bien le solde de l'ANNÉE EN COURS. `calculerDettesEleve`, qui
        // existe juste au-dessus, ne convient pas ici : il exclut délibérément
        // l'année active pour ne montrer que les arriérés. L'utiliser
        // afficherait « reste à payer : 0 » à une famille qui doit encore le
        // solde du minerval de cette année.
        let reste = null;
        try {
          const lignes = await detailFraisDus(client, {
            classeId: eleve.rows[0].classe_id,
            anneeScolaireId: annee.id,
            devise: deviseAttendue, taux, ecoleSql: CURRENT_ECOLE
          });
          const totalDu = lignes.reduce((t, l) => t + Number(l.montant_converti || 0), 0);

          const verse = await client.query(
            `SELECT COALESCE(SUM(${sqlPaiementConverti('p', '$2', 3)}), 0) AS total
               FROM paiements_frais p
              WHERE p.eleve_id = $1 AND p.ecole_id = ${CURRENT_ECOLE}
                AND p.annee_scolaire_id = $4`,
            [eleve_id, deviseAttendue, taux || null, annee.id]
          );
          const totalVerse = Number(verse.rows[0].total);

          reste = Math.round(Math.max(totalDu - totalVerse, 0) * 100) / 100;
        } catch (err) {
          // Un solde incalculable (taux manquant sur une ligne ancienne) ne
          // doit pas empêcher le reçu de partir : le montant versé, lui, est
          // certain. Le tableau omettra simplement la ligne « reste à payer ».
          console.warn('[frais] solde non calculable pour le reçu :', err.message);
        }

        await notifierEvenement(client, {
          evenement: 'frais.paiement_recu',
          destinataires: [{ email: infoEleve.responsable_email, nom: infoEleve.responsable_nom }],
          expediteurId: req.auth.userId,
          visibleInterface: false,
          donnees: {
            eleve: infoEleve.eleve,
            classe: infoEleve.classe,
            ecole: infoEleve.ecole,
            reference,
            libelle,
            montant: montantNum,
            devise,
            methode: methode || null,
            date: new Date().toISOString().slice(0, 10),
            resteAPayer: reste,
            deviseReste: deviseAttendue
          },
          cleUnicite: `recu_paiement:${paiement.rows[0].id}`
        });
      }

      return {
        id: paiement.rows[0].id, reference, devise,
        montant: montantNum, annee_scolaire: annee.libelle,
        equivalent: devise === deviseAttendue
          ? null
          : convertir(montantNum, devise, deviseAttendue, taux),
        devise_attendue: deviseAttendue
      };
    });

    // Hors transaction, après le commit : le reçu part dans la seconde plutôt
    // que d'attendre le prochain passage du cron. Sans cette ligne, l'e-mail
    // partirait quand même — mais avec jusqu'à cinq minutes de retard, alors
    // que la famille est peut-être encore au guichet.
    planifierVidage();

    return res.status(201).json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement paiement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


/**
 * GET /frais/eleves/:eleveId/frais-dus
 *
 * Le DÉTAIL des frais dus par un élève, ligne par ligne, avec ce qui a déjà été
 * versé sur chacune. C'est ce qui permet au comptable d'encaisser « le
 * minerval » plutôt qu'« un montant », et à la relance de dire précisément ce
 * qui manque.
 */
async function fraisDusEleve(req, res) {
  const { eleveId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));
      const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      const eleve = await client.query(
        `SELECT e.id, e.classe_id, c.nom AS classe_nom,
                trim(concat(e.nom, ' ', COALESCE(e.postnom, ''), ' ', COALESCE(e.prenom, ''))) AS nom_complet
           FROM eleves e LEFT JOIN classes c ON c.id = e.classe_id
          WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [eleveId]
      );
      if (eleve.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }

      const lignes = await detailFraisDus(client, {
        classeId: eleve.rows[0].classe_id,
        anneeScolaireId: annee.id,
        devise, taux, ecoleSql: CURRENT_ECOLE
      });

      // Versements déjà imputés à chaque ligne. Les paiements sans objet
      // (antérieurs, ou versements globaux) sont comptés à part : les répartir
      // au hasard entre les lignes donnerait une fausse précision.
      const verses = await client.query(
        `SELECT p.frais_id,
                COALESCE(SUM(${sqlPaiementConverti('p', '$2', 3)}), 0) AS total
           FROM paiements_frais p
          WHERE p.eleve_id = $1 AND p.ecole_id = ${CURRENT_ECOLE}
            AND p.annee_scolaire_id = $4
          GROUP BY p.frais_id`,
        [eleveId, devise, taux || null, annee.id]
      );
      const parLigne = new Map(verses.rows.map((v) => [v.frais_id, Number(v.total)]));
      const nonImpute = parLigne.get(null) || 0;

      const detail = lignes.map((l) => {
        const verse = parLigne.get(l.id) || 0;
        return {
          ...l,
          verse: Math.round(verse * 100) / 100,
          reste: Math.round(Math.max(l.montant_converti - verse, 0) * 100) / 100,
          solde: verse >= l.montant_converti
        };
      });

      const totalDu = detail.reduce((t, l) => t + l.montant_converti, 0);
      const totalVerse = detail.reduce((t, l) => t + l.verse, 0) + nonImpute;

      return {
        eleve: eleve.rows[0], annee: { id: annee.id, libelle: annee.libelle }, devise,
        lignes: detail,
        // Un versement non imputé n'est pas une erreur : c'est un encaissement
        // global, ou antérieur au rattachement. On le montre pour que le total
        // reste juste, sans prétendre savoir ce qu'il réglait.
        versements_non_imputes: Math.round(nonImpute * 100) / 100,
        total_du: Math.round(totalDu * 100) / 100,
        total_verse: Math.round(totalVerse * 100) / 100,
        solde: Math.round(Math.max(totalDu - totalVerse, 0) * 100) / 100
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur frais dus élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerPaiement(req, res) {
  const { id } = req.params;
  await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query('DELETE FROM paiements_frais WHERE id = $1', [id])
  );
  res.json({ message: 'Paiement supprimé.' });
}

/**
 * GET /frais/stats-globales
 * Résumé des impayés de l'année active, pour le tableau de bord Comptable
 * (même logique que le résumé impayés du tableau de bord Directeur).
 *
 * Tout est ramené dans la devise principale de l'école : additionner des dollars
 * et des francs pour afficher un « total dû » unique n'aurait aucun sens.
 */
async function statsGlobales(req, res) {
  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      const config = await lireConfigMonetaire(client);
      if (!annee) {
        return {
          annee_active: null, nb_eleves_en_retard: 0,
          montant_total_du: 0, montant_total_encaisse: 0,
          devise: config.devise_principale
        };
      }

      await verifierConversionsPossibles(client, {
        anneeScolaireId: annee.id, taux: config.taux_change_usd_fc
      });

      // $2 = devise d'affichage, $3 = taux courant (secours si un paiement n'a
      // pas de taux figé). Les paiements sont filtrés sur l'année : auparavant la
      // somme couvrait toute la scolarité de l'élève, ce qui gonflait l'encaissé
      // et effaçait des impayés bien réels.
      const result = await client.query(
        `WITH montants AS (
           SELECT e.id AS eleve_id,
                  -- Somme de TOUTES les lignes de frais applicables, une par
                  -- libellé (utils/frais.utils.js). Le LIMIT 1 qui figurait ici
                  -- n'en retenait qu'une : une école réclamant inscription +
                  -- minerval + laboratoire voyait ses familles déclarées à jour,
                  -- et le blocage de bulletin pour impayé ne bloquait personne.
                  ${sqlTotalFraisDus('e.classe_id', '$1', '$2', 3, CURRENT_ECOLE)} AS attendu,
                  COALESCE((
                    SELECT SUM(${sqlPaiementConverti('p', '$2', 3)})
                      FROM paiements_frais p
                     WHERE p.eleve_id = e.id AND p.annee_scolaire_id = $1
                  ), 0) AS paye
           FROM eleves e
           JOIN classes c ON c.id = e.classe_id
           WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif'
             AND c.annee_scolaire_id = $1
             AND COALESCE(e.derogation_financiere, false) = false
         )
         SELECT count(*) FILTER (WHERE attendu - paye > 0) AS nb_en_retard,
                COALESCE(SUM(GREATEST(attendu - paye, 0)), 0) AS total_du,
                COALESCE(SUM(paye), 0) AS total_encaisse
         FROM montants`,
        [annee.id, config.devise_principale, config.taux_change_usd_fc || null]
      );

      return {
        annee_active: { id: annee.id, libelle: annee.libelle },
        nb_eleves_en_retard: parseInt(result.rows[0].nb_en_retard, 10),
        montant_total_du: Math.round(Number(result.rows[0].total_du) * 100) / 100,
        montant_total_encaisse: Math.round(Number(result.rows[0].total_encaisse) * 100) / 100,
        devise: config.devise_principale
      };
    });
    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur stats globales frais:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Reçus de paiement
   Dans une école qui encaisse en espèces, le reçu papier n'est pas une
   commodité : c'est la seule preuve dont dispose la famille. Le numéro est
   attribué une fois pour toutes à la première impression, de sorte qu'un
   même paiement ne puisse jamais produire deux reçus de numéros différents.
   ========================================================================== */

const puppeteer = require('puppeteer-core');
const chromium = require('@sparticuz/chromium');

function echapperHtml(t) {
  return String(t == null ? '' : t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/**
 * Attribue un numéro au paiement s'il n'en a pas encore.
 *
 * Le numéro porte l'année SCOLAIRE du paiement (« REC-2025-2026-000123 ») et non
 * l'année civile. C'est le point que tu avais relevé : un reçu émis en janvier
 * 2026 s'affichait « REC-2026-… » alors qu'il appartient à l'exercice 2025-2026,
 * et la série repartait de zéro au 1er janvier, en plein milieu de l'année.
 *
 * L'année retenue est celle rattachée au paiement lui-même, pas l'année active du
 * jour : réimprimer un ancien reçu doit redonner exactement le même numéro.
 */
async function numeroRecu(client, paiementId, anneePaiement) {
  const existant = await client.query(
    `SELECT numero FROM recus_paiement WHERE paiement_id = $1`, [paiementId]
  );
  if (existant.rows.length > 0) return existant.rows[0].numero;

  for (let essai = 0; essai < 6; essai++) {
    const numero = await genererNumeroPiece(client, {
      table: 'recus_paiement', colonne: 'numero', prefixe: 'REC', annee: anneePaiement
    });

    // SAVEPOINT indispensable : sans lui, un INSERT en échec avorte toute la
    // transaction et la tentative suivante échoue à son tour avec 25P02
    // ("current transaction is aborted"), même sur une requête valide.
    await client.query('SAVEPOINT tentative_numero_recu');
    try {
      await client.query(
        `INSERT INTO recus_paiement (ecole_id, paiement_id, numero, emis_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3)`,
        [paiementId, numero, null]
      );
      await client.query('RELEASE SAVEPOINT tentative_numero_recu');
      return numero;
    } catch (e) {
      await client.query('ROLLBACK TO SAVEPOINT tentative_numero_recu');
      if (essai === 5) throw e;   // collision improbable : on retente
    }
  }
}

/**
 * GET /frais/paiements/:paiementId/recu — PDF étroit, format ticket.
 *
 * Le calcul du solde porte sur l'ANNÉE DU PAIEMENT. Auparavant il confrontait le
 * montant attendu de l'année active à la somme de tous les paiements de l'élève
 * depuis son inscription : un reçu pouvait donc afficher « Reste : 0 » alors que
 * la famille n'avait rien réglé pour l'année en cours.
 */
async function imprimerRecu(req, res) {
  const { paiementId } = req.params;
  let browser;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT p.id, p.montant, p.devise, p.taux_change, p.methode, p.reference,
                p.date_paiement, p.libelle, p.annee_scolaire_id,
                e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                c.nom AS classe_nom, c.id AS classe_id,
                ec.nom AS ecole_nom, ec.adresse, ec.telephone, ec.logo_url,
                COALESCE(ec.devise_principale, '${DEVISE_PAR_DEFAUT}') AS devise_principale,
                ec.taux_change_usd_fc,
                an.libelle AS annee_libelle, an.date_debut AS annee_debut, an.date_fin AS annee_fin,
                trim(concat(u.prenom, ' ', u.nom)) AS encaisse_par
         FROM paiements_frais p
         JOIN eleves e ON e.id = p.eleve_id
         LEFT JOIN classes c ON c.id = e.classe_id
         LEFT JOIN annees_scolaires an ON an.id = p.annee_scolaire_id
         JOIN ecoles ec ON ec.id = ${CURRENT_ECOLE}
         LEFT JOIN utilisateurs u ON u.id = p.enregistre_par
         WHERE p.id = $1 AND p.ecole_id = ${CURRENT_ECOLE}`,
        [paiementId]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Paiement introuvable.'), { statusCode: 404 });
      }
      const paiement = r.rows[0];

      const anneePaiement = paiement.annee_scolaire_id
        ? {
            id: paiement.annee_scolaire_id,
            libelle: paiement.annee_libelle,
            date_debut: paiement.annee_debut,
            date_fin: paiement.annee_fin
          }
        : await anneeActive(client);

      const numero = await numeroRecu(client, paiementId, anneePaiement);

      // Même cachet que celui utilisé sur les bulletins (documents.type = 'cachet').
      const cachetResult = await client.query(
        `SELECT url FROM documents WHERE ecole_id = ${CURRENT_ECOLE} AND type = 'cachet' ORDER BY created_at DESC LIMIT 1`
      );

      const taux = paiement.taux_change_usd_fc === null || paiement.taux_change_usd_fc === undefined
        ? null : Number(paiement.taux_change_usd_fc);

      // Montant attendu de l'année du paiement, pour la classe de l'élève.
      const attenduResult = await client.query(
        // Le reçu annonçait le montant d'UNE SEULE ligne de frais : le LIMIT 1
        // corrigé ailleurs subsistait ici. Une famille recevait donc un papier
        // portant « attendu : 40 $ » alors que l'école en réclame 150 en
        // quatre lignes — et se croyait quitte. C'est le document que la
        // famille conserve : l'erreur y survit à toutes les corrections
        // d'écran.
        //
        // La devise de référence reste celle de la ligne la PLUS SPÉCIFIQUE
        // (celle de la classe si elle existe) : c'est elle qui exprime
        // l'intention de l'école. Les autres lignes y sont converties.
        `WITH reference AS (
           SELECT devise FROM frais_scolaires
            WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
              AND (classe_id = $2 OR classe_id IS NULL)
            ORDER BY classe_id NULLS LAST
            LIMIT 1
         )
         SELECT (SELECT devise FROM reference) AS devise,
                COALESCE((
                  SELECT SUM(t.montant) FROM (
                    SELECT DISTINCT ON (f.libelle)
                           ${sqlFraisConverti('f', '(SELECT devise FROM reference)', 3)} AS montant
                      FROM frais_scolaires f
                     WHERE f.ecole_id = ${CURRENT_ECOLE} AND f.annee_scolaire_id = $1
                       AND (f.classe_id = $2 OR f.classe_id IS NULL)
                     ORDER BY f.libelle, f.classe_id NULLS LAST
                  ) t
                ), 0) AS montant`,
        [anneePaiement?.id || null, paiement.classe_id, taux || null]
      );
      const config = attenduResult.rows[0];
      const deviseCompte = config?.devise || paiement.devise || DEVISE_PAR_DEFAUT;
      const attendu = Number(config?.montant || 0);

      // Total versé sur cette même année, ramené dans la devise du compte.
      const verseResult = await client.query(
        `SELECT COALESCE(SUM(${sqlPaiementConverti('p', '$2', 3)}), 0) AS verse
           FROM paiements_frais p
          WHERE p.eleve_id = $1 AND p.annee_scolaire_id = $4`,
        [paiement.eleve_id, deviseCompte, taux, anneePaiement?.id || null]
      );

      // Dette des années antérieures : information capitale sur un reçu, c'est
      // souvent le seul document que la famille lit vraiment.
      let detteAnterieure = 0;
      try {
        const dettes = await calculerDettesEleve(client, paiement.eleve_id, {
          anneeActiveId: anneePaiement?.id || null,
          devise: deviseCompte,
          taux
        });
        detteAnterieure = dettes.dette_totale;
      } catch (e) {
        // Un taux manquant ne doit jamais empêcher d'imprimer un reçu : la
        // famille attend son papier. On omet simplement la ligne de dette.
        detteAnterieure = 0;
      }

      return {
        ...paiement,
        numero,
        cachetUrl: cachetResult.rows[0]?.url,
        devise_compte: deviseCompte,
        attendu,
        verse: Math.round(Number(verseResult.rows[0].verse) * 100) / 100,
        dette_anterieure: detteAnterieure,
        annee_libelle: anneePaiement?.libelle || null
      };
    });

    const eleve = [donnees.nom, donnees.postnom, donnees.prenom].filter(Boolean).join(' ');
    const reste = Math.max(Math.round((donnees.attendu - donnees.verse) * 100) / 100, 0);
    const dateEmission = new Date(donnees.date_paiement || Date.now())
      .toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });

    // Le montant encaissé est affiché dans SA devise ; le compte de l'élève est
    // tenu dans la devise du minerval. Quand les deux diffèrent, on montre
    // l'équivalent : sans quoi la famille voit « 280 000 FC versés » sous un
    // « total dû 300 USD » et ne peut pas rapprocher les deux.
    const devisesDifferentes = donnees.devise !== donnees.devise_compte;
    let equivalent = null;
    if (devisesDifferentes) {
      const taux = donnees.taux_change ? Number(donnees.taux_change) : Number(donnees.taux_change_usd_fc);
      if (taux > 0) equivalent = convertir(donnees.montant, donnees.devise, donnees.devise_compte, taux);
    }

    // Largeur 80 mm : le format des imprimantes thermiques de caisse, qui
    // reste parfaitement lisible imprimé sur une A4 coupée.
    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<style>
  @page { size: 80mm auto; margin: 4mm; }
  body { font-family: 'Courier New', monospace; font-size: 11px; color: #000; margin: 0; }
  .centre { text-align: center; }
  .titre { font-size: 15px; font-weight: bold; margin: 6px 0; }
  .ecole { font-weight: bold; font-size: 12px; }
  .trait { border-top: 1px dashed #000; margin: 7px 0; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 2px 0; vertical-align: top; }
  td.droite { text-align: right; }
  .gros { font-size: 14px; font-weight: bold; }
  .dette { font-weight: bold; }
  .equivalent { font-size: 9px; color: #333; }

  /* Logo de l'école : à GAUCHE de l'en-tête. Il était auparavant en haut à
     droite, exactement là où le cachet vient mordre — les deux se
     superposaient et le logo devenait illisible. */
  .entete { position: relative; padding-left: 46px; min-height: 44px; }
  .logo-ecole { position: absolute; top: 0; left: 0; max-width: 42px; max-height: 42px; object-fit: contain; }

  /* Cachet : décalé vers la DROITE et remonté, de façon à mordre sur le bas du
     tableau des totaux plutôt que sur le pied de page. La mention « Émis via
     Ardoise » et le nom de l'école restent lisibles, ce qui est le but : un
     tampon doit authentifier le document, pas le masquer. */
  .zone-cachet { text-align: right; margin-top: -30px; margin-bottom: -6px; padding-right: 4px; position: relative; z-index: 2; pointer-events: none; }
  .cachet-ecole { width: 72px; opacity: 0.8; transform: rotate(-9deg); mix-blend-mode: multiply; }

  /* Le pied de page passe AU-DESSUS du cachet dans l'ordre d'empilement :
     même si le tampon dépasse, le texte reste lisible par-dessus. */
  .pied { font-size: 9px; margin-top: 8px; position: relative; z-index: 3; }
</style></head><body>
  <div class="entete">
    ${donnees.logo_url ? `<img class="logo-ecole" src="${donnees.logo_url}" />` : ''}
    <div class="centre">
      <div class="ecole">${echapperHtml(donnees.ecole_nom)}</div>
      ${donnees.adresse ? `<div>${echapperHtml(donnees.adresse)}</div>` : ''}
      ${donnees.telephone ? `<div>${echapperHtml(donnees.telephone)}</div>` : ''}
    </div>
  </div>
  <div class="centre">
    <div class="titre">REÇU DE PAIEMENT</div>
    <div>N° ${echapperHtml(donnees.numero)}</div>
    ${donnees.annee_libelle ? `<div>Année scolaire ${echapperHtml(donnees.annee_libelle)}</div>` : ''}
  </div>
  <div class="trait"></div>
  <table>
    <tr><td>Date</td><td class="droite">${dateEmission}</td></tr>
    <tr><td>Élève</td><td class="droite">${echapperHtml(eleve)}</td></tr>
    <tr><td>Matricule</td><td class="droite">${echapperHtml(donnees.matricule)}</td></tr>
    <tr><td>Classe</td><td class="droite">${echapperHtml(donnees.classe_nom || '-')}</td></tr>
  </table>
  <div class="trait"></div>
  <table>
    <tr><td>${echapperHtml(donnees.libelle || 'Frais scolaires')}</td>
        <td class="droite gros">${formaterMontant(donnees.montant, donnees.devise)}</td></tr>
    ${equivalent !== null ? `<tr><td class="equivalent">soit</td>
        <td class="droite equivalent">${formaterMontant(equivalent, donnees.devise_compte)} (1 USD = ${formaterMontant(donnees.taux_change || donnees.taux_change_usd_fc, 'FC')})</td></tr>` : ''}
    <tr><td>Mode</td><td class="droite">${echapperHtml(donnees.methode || 'espèces')}</td></tr>
    ${donnees.reference ? `<tr><td>Référence</td><td class="droite">${echapperHtml(donnees.reference)}</td></tr>` : ''}
  </table>
  <div class="trait"></div>
  <table>
    <tr><td>Total dû</td><td class="droite">${formaterMontant(donnees.attendu, donnees.devise_compte)}</td></tr>
    <tr><td>Total versé</td><td class="droite">${formaterMontant(donnees.verse, donnees.devise_compte)}</td></tr>
    <tr><td class="gros">Reste</td><td class="droite gros">${formaterMontant(reste, donnees.devise_compte)}</td></tr>
    ${donnees.dette_anterieure > 0 ? `<tr><td class="dette">Dette antérieure</td>
        <td class="droite dette">${formaterMontant(donnees.dette_anterieure, donnees.devise_compte)}</td></tr>` : ''}
  </table>
  ${donnees.cachetUrl ? `<div class="zone-cachet"><img class="cachet-ecole" src="${donnees.cachetUrl}" /></div>` : ''}
  <div class="trait"></div>
  <div class="centre pied">
    Encaissé par ${echapperHtml(donnees.encaisse_par || "l'établissement")}<br/>
    Conservez ce reçu : il est votre seule preuve de paiement.<br/>
    Émis via Ardoise
  </div>
</body></html>`;

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdf = await page.pdf({ width: '80mm', printBackground: true, margin: { top: '4mm', bottom: '4mm', left: '4mm', right: '4mm' } });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="recu-${donnees.numero}.pdf"`);
    return res.send(pdf);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur impression reçu:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = {
  imprimerRecu,
  listerConfig, creerConfig, supprimerConfig,
  lireTauxChange, definirTauxChange,
  dettesAnterieures,
  listerElevesAvecPaiements, listerPaiementsEleve, fraisDusEleve,
  enregistrerPaiement, supprimerPaiement, statsGlobales
};
