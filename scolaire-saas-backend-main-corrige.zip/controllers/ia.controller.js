const { runWithTenant, executerRequeteLectureIA } = require('../config/db');
const { validerRequete, VUES_AUTORISEES } = require('../utils/sql-garde-fou.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { verifierPeriodeModifiable } = require('../utils/periode.utils');
const { appelerIAJson, pseudonymiser, consommerQuota, etatQuota } = require('../utils/ia.utils');
const XLSX = require('xlsx');
const { traiterLignesImport } = require('./eleves.controller');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * RÈGLE ABSOLUE DE CE CONTRÔLEUR
 * L'IA ne calcule jamais rien. Moyennes, écarts, taux et scores sont produits
 * par PostgreSQL ; l'IA reçoit des chiffres déjà établis et se contente de les
 * mettre en mots. Un bulletin ne doit jamais contenir un nombre inventé.
 */

async function anneeActive(client) {
  const r = await client.query(
    `SELECT id, libelle FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
  );
  return r.rows[0] || null;
}

async function ecoleId(client) {
  const r = await client.query(`SELECT id FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
  return r.rows[0]?.id || null;
}

/** Le titulaire est limité à ses classes ; la direction voit tout. */
async function verifierAccesClasse(client, req, classeId) {
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r))) return;
  const r = await client.query(`SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]);
  if (r.rows.length === 0) {
    throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
  }
}

/** GET /ia/quota */
async function quota(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const id = await ecoleId(client);
      return etatQuota(client, id);
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur quota IA:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   1. Détection précoce du décrochage
   Le repérage est fait en SQL ; l'IA ne sert qu'à formuler l'alerte et
   proposer une action. Un seul appel couvre toute l'école.
   ========================================================================== */

async function decrochage(req, res) {
  const jours = Math.min(Math.max(Number(req.query.jours) || 45, 7), 180);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) {
        throw Object.assign(new Error("Aucune année scolaire active."), { statusCode: 409 });
      }

      // ---------- Signaux, calculés par la base ----------
      const signaux = await client.query(
        `WITH periodes_ordonnees AS (
           SELECT id, numero FROM periodes
           WHERE annee_scolaire_id = $1 AND type IN ('periode','examen')
           ORDER BY numero DESC LIMIT 2
         ),
         derniere AS (SELECT id FROM periodes_ordonnees ORDER BY numero DESC LIMIT 1),
         precedente AS (SELECT id FROM periodes_ordonnees ORDER BY numero ASC LIMIT 1),
         notes_eleve AS (
           SELECT e.id AS eleve_id,
                  (SELECT b.pourcentage FROM bulletins b
                    WHERE b.eleve_id = e.id AND b.periode_id = (SELECT id FROM derniere)) AS actuel,
                  (SELECT b.pourcentage FROM bulletins b
                    WHERE b.eleve_id = e.id AND b.periode_id = (SELECT id FROM precedente)) AS precedent
           FROM eleves e WHERE e.statut = 'actif'
         )
         SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom, e.matricule,
                c.nom AS classe_nom,
                n.actuel, n.precedent,
                COALESCE((
                  SELECT count(*) FROM presences p
                  WHERE p.eleve_id = e.id AND p.statut = 'absent'
                    AND p.date_jour >= current_date - $2::int
                ), 0) AS nb_absences,
                COALESCE((
                  SELECT count(*) FROM presences p
                  WHERE p.eleve_id = e.id AND p.date_jour >= current_date - $2::int
                ), 0) AS nb_appels,
                COALESCE((
                  SELECT count(*) FROM incidents_discipline i
                  WHERE i.eleve_id = e.id AND i.date_incident >= current_date - $2::int
                ), 0) AS nb_incidents
         FROM eleves e
         JOIN classes c ON c.id = e.classe_id
         LEFT JOIN notes_eleve n ON n.eleve_id = e.id
         WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif'
           AND c.annee_scolaire_id = $1`,
        [annee.id, jours]
      );

      // ---------- Score de risque, en JavaScript, jamais par l'IA ----------
      const candidats = signaux.rows.map((l) => {
        const actuel = l.actuel === null ? null : Number(l.actuel);
        const precedent = l.precedent === null ? null : Number(l.precedent);
        const chute = (actuel !== null && precedent !== null)
          ? Math.round((precedent - actuel) * 10) / 10 : null;
        const nbAppels = Number(l.nb_appels);
        const nbAbsences = Number(l.nb_absences);
        const tauxAbsence = nbAppels > 0 ? Math.round((nbAbsences / nbAppels) * 1000) / 10 : null;
        const nbIncidents = Number(l.nb_incidents);

        let score = 0;
        const motifs = [];
        if (chute !== null && chute >= 10) { score += 3; motifs.push(`baisse de ${chute} points`); }
        else if (chute !== null && chute >= 5) { score += 2; motifs.push(`baisse de ${chute} points`); }
        if (actuel !== null && actuel < 40) { score += 2; motifs.push(`moyenne à ${actuel} %`); }
        if (tauxAbsence !== null && tauxAbsence >= 25) { score += 3; motifs.push(`${tauxAbsence} % d'absence`); }
        else if (tauxAbsence !== null && tauxAbsence >= 12) { score += 2; motifs.push(`${tauxAbsence} % d'absence`); }
        if (nbIncidents >= 3) { score += 2; motifs.push(`${nbIncidents} faits disciplinaires`); }
        else if (nbIncidents >= 1) { score += 1; motifs.push(`${nbIncidents} fait(s) disciplinaire(s)`); }

        return {
          eleve_id: l.eleve_id, matricule: l.matricule,
          nom: l.nom, postnom: l.postnom, prenom: l.prenom,
          classe_nom: l.classe_nom,
          moyenne_actuelle: actuel, moyenne_precedente: precedent,
          chute, taux_absence: tauxAbsence, nb_absences: nbAbsences,
          nb_incidents: nbIncidents, score, motifs
        };
      })
        // Un seul signal faible ne fait pas un décrochage : le croisement
        // d'au moins deux indices est ce qui rend l'alerte crédible.
        .filter((c) => c.score >= 3)
        .sort((a, b) => b.score - a.score)
        .slice(0, 15);

      if (candidats.length === 0) {
        return { annee, jours, eleves: [], quota: await etatQuota(client, await ecoleId(client)) };
      }

      // ---------- Un seul appel IA pour tout le lot ----------
      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);
      const { anonymes, table } = pseudonymiser(candidats);

      const systeme = `Tu assistes la direction d'une école secondaire en République démocratique du Congo.
On te transmet des élèves repérés comme fragiles par des indicateurs déjà calculés.
Ta tâche : pour chacun, rédiger un constat court et une action concrète.

Règles impératives :
- N'invente AUCUN chiffre. N'utilise que ceux fournis.
- Ne pose aucun diagnostic médical, psychologique ou familial.
- Reste factuel et respectueux : ces textes seront lus par des adultes responsables.
- L'action proposée doit être réalisable par une école congolaise : convocation
  du responsable, entretien avec le titulaire, appui d'un pair, suivi rapproché.
- Réponds UNIQUEMENT par un tableau JSON, sans texte autour, au format :
  [{"etiquette":"Élève 1","constat":"…","action":"…","urgence":"haute|moyenne"}]
- Le constat fait au maximum 200 caractères, l'action 140.`;

      const resultat = await appelerIAJson({
        systeme,
        message: JSON.stringify(anonymes.map((a) => ({
          etiquette: a.etiquette,
          moyenne_actuelle: a.moyenne_actuelle,
          moyenne_precedente: a.moyenne_precedente,
          baisse_points: a.chute,
          taux_absence_pourcent: a.taux_absence,
          nombre_absences: a.nb_absences,
          faits_disciplinaires: a.nb_incidents
        })), null, 1),
        maxTokens: 2500
      });

      // ---------- Réassociation des vrais noms, côté serveur ----------
      const parEtiquette = Object.fromEntries(
        (Array.isArray(resultat) ? resultat : []).map((r) => [r.etiquette, r])
      );

      const eleves = candidats.map((c, i) => {
        const etiquette = `Élève ${i + 1}`;
        const ia = parEtiquette[etiquette] || {};
        return {
          ...c,
          nom_complet: [c.nom, c.postnom, c.prenom].filter(Boolean).join(' '),
          constat: ia.constat || c.motifs.join(', '),
          action: ia.action || 'Entretien avec le titulaire.',
          urgence: ia.urgence === 'haute' ? 'haute' : 'moyenne'
        };
      });

      return { annee, jours, eleves, quota: infoQuota };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détection décrochage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   2. Propositions d'appréciations de bulletin
   Un appel pour toute la classe, jamais un par élève : à 40 élèves,
   la différence est de 1 génération contre 40.
   ========================================================================== */

async function appreciations(req, res) {
  const { classeId, periodeId } = req.query;
  if (!classeId || !periodeId) {
    return res.status(400).json({ message: 'classeId et periodeId sont requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);

      const contexte = await client.query(
        `SELECT c.nom AS classe_nom, p.libelle AS periode_libelle, p.numero
         FROM classes c, periodes p WHERE c.id = $1 AND p.id = $2`,
        [classeId, periodeId]
      );
      if (contexte.rows.length === 0) {
        throw Object.assign(new Error('Classe ou période introuvable.'), { statusCode: 404 });
      }

      const eleves = await client.query(
        `SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom, e.matricule,
                b.pourcentage, b.classement, b.mention, b.conduite, b.signe_at,
                (SELECT b2.pourcentage FROM bulletins b2
                   JOIN periodes p2 ON p2.id = b2.periode_id
                  WHERE b2.eleve_id = e.id AND p2.numero < (SELECT numero FROM periodes WHERE id = $2)
                    AND p2.annee_scolaire_id = (SELECT annee_scolaire_id FROM periodes WHERE id = $2)
                  ORDER BY p2.numero DESC LIMIT 1) AS pourcentage_precedent
         FROM eleves e
         JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif' AND b.pourcentage IS NOT NULL
         ORDER BY e.nom, e.postnom`,
        [classeId, periodeId]
      );

      if (eleves.rows.length === 0) {
        throw Object.assign(
          new Error("Aucun bulletin calculé pour cette classe et cette période. Lancez d'abord le récapitulatif."),
          { statusCode: 409 }
        );
      }

      // Un bulletin signé ne doit plus bouger : inutile d'en proposer le texte.
      const modifiables = eleves.rows.filter((e) => !e.signe_at);
      if (modifiables.length === 0) {
        throw Object.assign(
          new Error('Tous les bulletins de cette classe sont déjà signés.'),
          { statusCode: 409 }
        );
      }

      const prepares = modifiables.map((e) => {
        const actuel = Number(e.pourcentage);
        const precedent = e.pourcentage_precedent === null ? null : Number(e.pourcentage_precedent);
        return {
          eleve_id: e.eleve_id, nom: e.nom, postnom: e.postnom, prenom: e.prenom,
          matricule: e.matricule,
          pourcentage: actuel,
          pourcentage_precedent: precedent,
          evolution: precedent === null ? null : Math.round((actuel - precedent) * 10) / 10,
          classement: e.classement, mention: e.mention, conduite: e.conduite
        };
      });

      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);
      const { anonymes } = pseudonymiser(prepares);

      const systeme = `Tu rédiges des appréciations de bulletin pour une école secondaire en République démocratique du Congo.

Règles impératives :
- N'invente AUCUN chiffre : tu peux mentionner ceux fournis, jamais d'autres.
- Une à deux phrases, 220 caractères maximum, en français soutenu mais simple.
- Vouvoiement proscrit : l'appréciation parle de l'élève à la troisième personne.
- Ne nomme jamais l'élève, n'utilise pas l'étiquette dans le texte.
- Varie les formulations : deux élèves aux résultats proches ne doivent pas
  recevoir la même phrase.
- Mentionne la progression quand elle existe, encourage sans complaisance,
  et propose un axe de travail quand les résultats sont faibles.
- Réponds UNIQUEMENT par un tableau JSON, sans texte autour :
  [{"etiquette":"Élève 1","appreciation":"…"}]`;

      const resultat = await appelerIAJson({
        systeme,
        message: `Classe : ${contexte.rows[0].classe_nom}, période : ${contexte.rows[0].periode_libelle || contexte.rows[0].numero}.\n\n`
          + JSON.stringify(anonymes.map((a) => ({
            etiquette: a.etiquette,
            pourcentage: a.pourcentage,
            pourcentage_periode_precedente: a.pourcentage_precedent,
            evolution_points: a.evolution,
            place_en_classe: a.classement,
            mention: a.mention,
            conduite: a.conduite
          })), null, 1),
        maxTokens: 4000
      });

      const parEtiquette = Object.fromEntries(
        (Array.isArray(resultat) ? resultat : []).map((r) => [r.etiquette, r.appreciation])
      );

      return {
        classe_nom: contexte.rows[0].classe_nom,
        periode_libelle: contexte.rows[0].periode_libelle,
        nb_signes_ignores: eleves.rows.length - modifiables.length,
        quota: infoQuota,
        propositions: prepares.map((e, i) => ({
          eleve_id: e.eleve_id,
          nom_complet: [e.nom, e.postnom, e.prenom].filter(Boolean).join(' '),
          matricule: e.matricule,
          pourcentage: e.pourcentage,
          evolution: e.evolution,
          appreciation: parEtiquette[`Élève ${i + 1}`] || ''
        }))
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur appréciations IA:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /ia/appreciations/appliquer
 * Écrit les appréciations retenues dans le champ observation du bulletin.
 * Rien n'est enregistré sans cette étape : la proposition seule ne modifie
 * aucun bulletin.
 */
async function appliquerAppreciations(req, res) {
  const { classe_id, periode_id, appreciations: lignes } = req.body;
  if (!classe_id || !periode_id || !Array.isArray(lignes) || lignes.length === 0) {
    return res.status(400).json({ message: 'classe_id, periode_id et appreciations sont requis.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classe_id);

      // Troisième module à écrire dans `bulletins`, troisième à ignorer le
      // verrou de période. Seul `signe_at IS NULL` était contrôlé : un bulletin
      // NON signé d'une période CLÔTURÉE restait donc modifiable, et l'IA
      // pouvait y déposer une observation des mois après la clôture.
      await verifierPeriodeModifiable(client, periode_id, 'appréciation');

      let ecrits = 0, ignores = 0;
      for (const ligne of lignes) {
        if (!ligne.eleve_id || !ligne.appreciation || !String(ligne.appreciation).trim()) continue;

        // L'élève doit appartenir à la classe, et le bulletin ne pas être signé.
        const r = await client.query(
          `UPDATE bulletins b
           SET observation = $3
           FROM eleves e
           WHERE b.eleve_id = e.id AND b.eleve_id = $1 AND b.periode_id = $2
             AND e.classe_id = $4 AND b.signe_at IS NULL`,
          [ligne.eleve_id, periode_id, String(ligne.appreciation).trim().slice(0, 500), classe_id]
        );
        if (r.rowCount > 0) ecrits++; else ignores++;
      }
      return { ecrits, ignores };
    });

    const complement = bilan.ignores > 0
      ? ` ${bilan.ignores} bulletin(s) ignoré(s) : déjà signés ou hors de cette classe.` : '';
    return res.json({ message: `${bilan.ecrits} appréciation(s) enregistrée(s).${complement}` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur application appréciations:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   3. Question libre sur un élève — le « coin IA » contextuel
   L'assistant ne voit QUE le dossier de l'élève concerné. Il ne peut donc
   rien répondre sur un autre élève, ni sur l'école, ni sur autre chose.
   ========================================================================== */

const QUESTION_MAX = 400;

async function questionEleve(req, res) {
  const { eleve_id, question } = req.body;
  if (!eleve_id) return res.status(400).json({ message: "L'élève est requis." });
  if (!question || !String(question).trim()) {
    return res.status(400).json({ message: 'Posez une question.' });
  }
  if (String(question).length > QUESTION_MAX) {
    return res.status(400).json({ message: `Question trop longue (${QUESTION_MAX} caractères maximum).` });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleveResult = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule, e.classe_id, c.nom AS classe_nom
         FROM eleves e JOIN classes c ON c.id = e.classe_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [eleve_id]
      );
      if (eleveResult.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      const eleve = eleveResult.rows[0];
      await verifierAccesClasse(client, req, eleve.classe_id);

      const annee = await anneeActive(client);
      if (!annee) throw Object.assign(new Error('Aucune année scolaire active.'), { statusCode: 409 });

      // ---------- Dossier complet, chiffres calculés par la base ----------
      const bulletins = await client.query(
        `SELECT p.libelle AS periode, p.numero, b.pourcentage, b.classement, b.mention, b.conduite
         FROM periodes p
         LEFT JOIN bulletins b ON b.periode_id = p.id AND b.eleve_id = $1
         WHERE p.annee_scolaire_id = $2 AND p.type IN ('periode','examen')
         ORDER BY p.numero`,
        [eleve_id, annee.id]
      );

      const parCours = await client.query(
        `SELECT co.nom AS cours, p.numero AS periode_numero, p.libelle AS periode,
                n.points_obtenus,
                COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum
         FROM notes n
         JOIN classe_cours cc ON cc.id = n.classe_cours_id
         JOIN cours co ON co.id = cc.cours_id
         JOIN periodes p ON p.id = n.periode_id
         WHERE n.eleve_id = $1 AND p.annee_scolaire_id = $2 AND n.points_obtenus IS NOT NULL
         ORDER BY co.nom, p.numero`,
        [eleve_id, annee.id]
      );

      const assiduite = await client.query(
        `SELECT count(*) FILTER (WHERE statut = 'present') AS present,
                count(*) FILTER (WHERE statut = 'absent')  AS absent,
                count(*) FILTER (WHERE statut = 'retard')  AS retard,
                count(*) AS total
         FROM presences WHERE eleve_id = $1`,
        [eleve_id]
      );

      const discipline = await client.query(
        `SELECT count(*) AS nb, COALESCE(SUM(points), 0) AS points
         FROM incidents_discipline WHERE eleve_id = $1 AND annee_scolaire_id = $2`,
        [eleve_id, annee.id]
      );

      const a = assiduite.rows[0];
      const d = discipline.rows[0];

      // Le dossier envoyé ne contient ni nom, ni matricule, ni identifiant.
      const dossier = {
        classe: eleve.classe_nom,
        annee: annee.libelle,
        bulletins: bulletins.rows.map((b) => ({
          periode: b.periode || `Période ${b.numero}`,
          pourcentage: b.pourcentage === null ? null : Number(b.pourcentage),
          place: b.classement, mention: b.mention, conduite: b.conduite
        })),
        notes_par_cours: parCours.rows.map((n) => ({
          cours: n.cours, periode: n.periode || `Période ${n.periode_numero}`,
          note: Number(n.points_obtenus), maximum: Number(n.maximum)
        })),
        assiduite: Number(a.total) > 0 ? {
          jours_appeles: Number(a.total), presences: Number(a.present),
          absences: Number(a.absent), retards: Number(a.retard)
        } : null,
        discipline: { faits: Number(d.nb), points_retires: Number(d.points) }
      };

      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);

      const systeme = `Tu aides un enseignant à analyser le dossier scolaire d'UN élève, dans une école secondaire en République démocratique du Congo.

Règles impératives :
- Tu ne disposes QUE du dossier ci-dessous. Si la question porte sur autre chose
  (un autre élève, l'école, un sujet extérieur), réponds que tu n'as pas cette
  information et rappelle ce que tu peux analyser.
- N'invente AUCUN chiffre. Ne cite que ceux du dossier. Si une donnée manque,
  dis-le franchement plutôt que d'estimer.
- Aucun diagnostic médical, psychologique ou familial.
- L'élève est anonyme : ne cherche pas son nom, écris « cet élève ».
- Réponse en français, 250 mots maximum, structurée en courts paragraphes.
  Pas de titres, pas de listes à puces sauf si la question l'appelle vraiment.
- Termine par une suggestion concrète et réalisable si la question s'y prête.`;

      const reponse = await appelerIAJson({
        systeme: systeme + '\n- Réponds UNIQUEMENT en JSON : {"reponse":"…"}',
        message: `Dossier :\n${JSON.stringify(dossier, null, 1)}\n\nQuestion de l'enseignant : ${String(question).trim()}`,
        maxTokens: 1200
      });

      return {
        eleve: {
          nom_complet: [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '),
          classe_nom: eleve.classe_nom
        },
        reponse: (reponse && reponse.reponse) || "L'assistant n'a pas pu formuler de réponse.",
        quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur question élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. Rédaction et traduction de messages
   ========================================================================== */

const LANGUES = {
  francais: 'français',
  lingala: 'lingala',
  swahili: 'swahili (kiswahili)',
  kikongo: 'kikongo',
  tshiluba: 'tshiluba'
};

async function redaction(req, res) {
  const { mode, texte, langue, intention } = req.body;

  if (!['rediger', 'reformuler', 'traduire'].includes(mode)) {
    return res.status(400).json({ message: 'Mode inconnu.' });
  }
  if (mode === 'rediger' && (!intention || !String(intention).trim())) {
    return res.status(400).json({ message: 'Décrivez ce que le message doit dire.' });
  }
  if (mode !== 'rediger' && (!texte || !String(texte).trim())) {
    return res.status(400).json({ message: 'Le message est vide.' });
  }
  if (mode === 'traduire' && !LANGUES[langue]) {
    return res.status(400).json({ message: 'Langue non prise en charge.' });
  }
  const source = String(mode === 'rediger' ? intention : texte).trim();
  if (source.length > 4000) {
    return res.status(400).json({ message: 'Texte trop long (4000 caractères maximum).' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);

      const commun = `Tu rédiges des communications officielles pour une école secondaire en République démocratique du Congo.
Le lecteur est soit un membre du personnel, soit un parent d'élève.

Règles impératives :
- Ton respectueux, clair, sans jargon administratif inutile.
- N'invente AUCUN fait : ni date, ni montant, ni nom, ni horaire qui ne soit
  déjà dans la demande. S'il manque une information, laisse un espace réservé
  entre crochets, par exemple [date à préciser].
- Pas de formule d'ouverture pompeuse ni de signature : l'école ajoutera la sienne.
- Réponds UNIQUEMENT en JSON : {"objet":"…","message":"…"}
  Pour une traduction, garde l'objet dans la langue demandée lui aussi.`;

      let consigne;
      if (mode === 'rediger') {
        consigne = `${commun}\n- Rédige un message complet à partir de l'intention donnée. 200 mots maximum.`;
      } else if (mode === 'reformuler') {
        consigne = `${commun}\n- Reformule le message fourni : plus clair, mieux structuré, même sens exactement. Ne change aucune information.`;
      } else {
        consigne = `${commun}\n- Traduis fidèlement le message fourni en ${LANGUES[langue]}.
- Garde les noms propres, les dates et les chiffres tels quels.
- Si un terme scolaire n'a pas d'équivalent courant, garde le mot français entre parenthèses.`;
      }

      const resultat = await appelerIAJson({
        systeme: consigne,
        message: mode === 'rediger'
          ? `Intention du message : ${source}`
          : `Message à traiter :\n${source}`,
        maxTokens: 1500
      });

      return {
        objet: (resultat && resultat.objet) || '',
        message: (resultat && resultat.message) || '',
        quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur rédaction IA:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. Préparation du conseil de classe
   ========================================================================== */

async function conseilClasse(req, res) {
  const { classeId, periodeId } = req.query;
  if (!classeId || !periodeId) {
    return res.status(400).json({ message: 'classeId et periodeId sont requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);

      const contexte = await client.query(
        `SELECT c.nom AS classe_nom, p.libelle AS periode_libelle, p.numero
         FROM classes c, periodes p WHERE c.id = $1 AND p.id = $2`,
        [classeId, periodeId]
      );
      if (contexte.rows.length === 0) {
        throw Object.assign(new Error('Classe ou période introuvable.'), { statusCode: 404 });
      }

      const eleves = await client.query(
        `SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom,
                b.pourcentage, b.classement, b.mention, b.conduite,
                (SELECT count(*) FROM incidents_discipline i
                  WHERE i.eleve_id = e.id AND i.periode_id = $2) AS nb_incidents,
                (SELECT count(*) FROM presences pr
                  WHERE pr.eleve_id = e.id AND pr.statut = 'absent') AS nb_absences
         FROM eleves e
         JOIN bulletins b ON b.eleve_id = e.id AND b.periode_id = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif' AND b.pourcentage IS NOT NULL
         ORDER BY b.pourcentage DESC NULLS LAST`,
        [classeId, periodeId]
      );

      if (eleves.rows.length === 0) {
        throw Object.assign(
          new Error("Aucun bulletin calculé pour cette classe et cette période."),
          { statusCode: 409 }
        );
      }

      // Statistiques calculées ici, jamais par l'IA.
      const pourcentages = eleves.rows.map((e) => Number(e.pourcentage));
      const moyenne = Math.round((pourcentages.reduce((a, b) => a + b, 0) / pourcentages.length) * 10) / 10;
      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuil = Number(seuilResult.rows[0].seuil);
      const nbReussites = pourcentages.filter((p) => p >= seuil).length;

      const prepares = eleves.rows.map((e) => ({
        nom: e.nom, postnom: e.postnom, prenom: e.prenom,
        pourcentage: Number(e.pourcentage),
        place: e.classement, mention: e.mention, conduite: e.conduite,
        faits_disciplinaires: Number(e.nb_incidents),
        absences: Number(e.nb_absences)
      }));

      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);
      const { anonymes } = pseudonymiser(prepares);

      const systeme = `Tu prépares la note de synthèse d'un conseil de classe, dans une école secondaire en République démocratique du Congo.

Règles impératives :
- N'invente AUCUN chiffre. N'utilise que ceux fournis.
- Aucun diagnostic médical, psychologique ou familial.
- Les élèves sont anonymes : désigne-les par leur étiquette exacte.
- Reste factuel et mesuré : ce texte est lu à voix haute devant des collègues.
- Réponds UNIQUEMENT en JSON :
  {"synthese":"…","points_attention":["…"],"eleves_a_evoquer":[{"etiquette":"Élève 1","note":"…"}]}
- « synthese » : 150 mots maximum sur la physionomie générale de la classe.
- « points_attention » : 2 à 4 constats courts, utiles au débat.
- « eleves_a_evoquer » : au maximum 8 élèves méritant une discussion,
  qu'ils soient en difficulté ou remarquables. Note de 140 caractères maximum.`;

      const resultat = await appelerIAJson({
        systeme,
        message: `Classe : ${contexte.rows[0].classe_nom}, période : ${contexte.rows[0].periode_libelle || contexte.rows[0].numero}.
Effectif avec bulletin : ${prepares.length}. Moyenne de classe : ${moyenne} %. Seuil de réussite : ${seuil} %. Réussites : ${nbReussites}.

${JSON.stringify(anonymes.map((a) => ({
  etiquette: a.etiquette, pourcentage: a.pourcentage, place: a.place,
  mention: a.mention, conduite: a.conduite,
  faits_disciplinaires: a.faits_disciplinaires, absences: a.absences
})), null, 1)}`,
        maxTokens: 3000
      });

      // Réassociation des vrais noms côté serveur.
      const nomsParEtiquette = {};
      prepares.forEach((e, i) => {
        nomsParEtiquette[`Élève ${i + 1}`] = [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ');
      });

      return {
        classe_nom: contexte.rows[0].classe_nom,
        periode_libelle: contexte.rows[0].periode_libelle,
        effectif: prepares.length,
        moyenne, seuil, nb_reussites: nbReussites,
        taux_reussite: Math.round((nbReussites / prepares.length) * 1000) / 10,
        synthese: (resultat && resultat.synthese) || '',
        points_attention: (resultat && resultat.points_attention) || [],
        eleves_a_evoquer: ((resultat && resultat.eleves_a_evoquer) || []).map((e) => ({
          nom_complet: nomsParEtiquette[e.etiquette] || 'Élève',
          note: e.note || ''
        })),
        quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur conseil de classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   6. Import Excel assisté
   L'IA ne lit PAS le fichier entier : elle reçoit les en-têtes et trois
   lignes d'exemple, et propose une correspondance de colonnes. C'est
   l'utilisateur qui valide, et l'écriture passe par le même code que
   l'import classique.
   ========================================================================== */

const CHAMPS_CIBLES = [
  'Matricule', 'Nom', 'Postnom', 'Prenom', 'Sexe', 'DateNaissance',
  'Classe', 'Adresse', 'Telephone', 'ResponsableNom', 'ResponsableTelephone', 'ResponsableEmail'
];

const LIGNES_MAX = 1000;

function lireClasseur(tampon) {
  const classeur = XLSX.read(tampon, { type: 'buffer', cellDates: true });
  const feuille = classeur.Sheets[classeur.SheetNames[0]];
  const lignes = XLSX.utils.sheet_to_json(feuille, { defval: null });
  return lignes;
}

/** POST /ia/import/analyser — fichier en multipart, champ « fichier ». */
async function analyserImport(req, res) {
  if (!req.file) {
    return res.status(400).json({ message: 'Aucun fichier reçu.' });
  }

  let lignes;
  try {
    lignes = lireClasseur(req.file.buffer);
  } catch (e) {
    return res.status(400).json({ message: "Fichier illisible. Attendu : un classeur Excel ou un CSV." });
  }

  if (lignes.length === 0) {
    return res.status(400).json({ message: 'Le fichier ne contient aucune ligne de données.' });
  }
  if (lignes.length > LIGNES_MAX) {
    return res.status(400).json({
      message: `Fichier trop volumineux (${lignes.length} lignes). Découpez-le en lots de ${LIGNES_MAX} au maximum.`
    });
  }

  const colonnes = Object.keys(lignes[0]);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classes = await client.query(
        `SELECT nom FROM classes WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY nom`
      );

      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);

      const systeme = `Tu aides à importer une liste d'élèves dans un logiciel scolaire congolais.
On te donne les en-têtes d'un fichier et trois lignes d'exemple.

Ta tâche : associer chaque champ cible à la colonne du fichier qui lui correspond.

Champs cibles : ${CHAMPS_CIBLES.join(', ')}.

Règles impératives :
- Utilise EXACTEMENT les noms de colonnes du fichier, sans les modifier.
- Si aucune colonne ne correspond à un champ cible, mets null.
- « Postnom » est le nom du père, courant en RDC : ne le confonds pas avec le prénom.
- Si une seule colonne contient le nom complet, associe-la à « Nom » et laisse
  Postnom et Prenom à null.
- Sexe : les valeurs peuvent être M/F, H/F, Garçon/Fille, Homme/Femme.
- Réponds UNIQUEMENT en JSON :
  {"correspondance":{"Nom":"…","Matricule":null,…},"remarques":["…"]}
- « remarques » : au maximum 3 observations utiles (colonne ambiguë, format de
  date inhabituel, valeurs de classe qui ne ressemblent pas à celles de l'école).`;

      const resultat = await appelerIAJson({
        systeme,
        message: `Colonnes du fichier : ${JSON.stringify(colonnes)}

Trois premières lignes :
${JSON.stringify(lignes.slice(0, 3), null, 1)}

Classes existantes dans l'école : ${JSON.stringify(classes.rows.map((c) => c.nom))}`,
        maxTokens: 1200
      });

      // On ne fait jamais confiance à une correspondance renvoyée : chaque
      // colonne citée doit exister réellement dans le fichier.
      const brute = (resultat && resultat.correspondance) || {};
      const correspondance = {};
      for (const champ of CHAMPS_CIBLES) {
        const colonne = brute[champ];
        correspondance[champ] = (colonne && colonnes.includes(colonne)) ? colonne : null;
      }

      const apercu = lignes.slice(0, 5).map((ligne) => {
        const converti = {};
        for (const champ of CHAMPS_CIBLES) {
          converti[champ] = correspondance[champ] ? ligne[correspondance[champ]] : null;
        }
        return converti;
      });

      return {
        colonnes,
        champs_cibles: CHAMPS_CIBLES,
        correspondance,
        remarques: (resultat && resultat.remarques) || [],
        nb_lignes: lignes.length,
        apercu,
        quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur analyse import:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /ia/import/appliquer — fichier en multipart + champ « correspondance ».
 * Aucun appel IA ici : la correspondance a déjà été validée par l'utilisateur.
 */
async function appliquerImport(req, res) {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu.' });

  let correspondance;
  try {
    correspondance = JSON.parse(req.body.correspondance || '{}');
  } catch (e) {
    return res.status(400).json({ message: 'Correspondance de colonnes illisible.' });
  }
  if (!correspondance.Nom) {
    return res.status(400).json({ message: 'La colonne du nom doit être renseignée.' });
  }

  let lignes;
  try {
    lignes = lireClasseur(req.file.buffer);
  } catch (e) {
    return res.status(400).json({ message: 'Fichier illisible.' });
  }
  if (lignes.length > LIGNES_MAX) {
    return res.status(400).json({ message: `Fichier trop volumineux (${lignes.length} lignes).` });
  }

  const normalisees = lignes.map((ligne) => {
    const converti = {};
    for (const champ of CHAMPS_CIBLES) {
      const colonne = correspondance[champ];
      converti[champ] = colonne ? ligne[colonne] : null;
    }
    return converti;
  });

  try {
    // Exactement le même chemin d'écriture que l'import classique.
    const bilan = await runWithTenant(tenantContextFromReq(req), (client) =>
      traiterLignesImport(client, normalisees)
    );
    return res.json({ message: 'Import terminé.', bilan });
  } catch (err) {
    console.error('Erreur application import:', err);
    return res.status(500).json({ message: "Erreur serveur pendant l'import." });
  }
}

/* ==========================================================================
   7. Recherche en langage naturel dans les archives
   L'IA ne génère JAMAIS de SQL. Elle choisit un modèle de requête parmi une
   liste fermée et en remplit les paramètres ; le SQL est écrit ici, à la main.
   ========================================================================== */

const MODELES_RECHERCHE = {
  redoublants: {
    description: "Élèves ayant redoublé, avec le nombre de fois. Paramètre : nb_minimum (entier, défaut 1).",
    sql: `SELECT e.matricule, e.nom, e.postnom, e.prenom,
                 count(*) AS nb_redoublements,
                 string_agg(DISTINCT a.libelle, ', ' ORDER BY a.libelle) AS annees
          FROM eleve_classe_historique h
          JOIN eleves e ON e.id = h.eleve_id
          JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
          WHERE h.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true
            AND h.resultat_final ILIKE '%redouble%'
          GROUP BY e.id, e.matricule, e.nom, e.postnom, e.prenom
          HAVING count(*) >= $1
          ORDER BY count(*) DESC, e.nom
          LIMIT 200`,
    parametres: ['nb_minimum']
  },
  par_resultat: {
    description: "Élèves selon leur résultat de fin d'année. Paramètres : resultat (texte : promu, redouble, sortant), annee (libellé ou null pour toutes).",
    sql: `SELECT e.matricule, e.nom, e.postnom, e.prenom, c.nom AS classe,
                 a.libelle AS annee, h.resultat_final
          FROM eleve_classe_historique h
          JOIN eleves e ON e.id = h.eleve_id
          JOIN classes c ON c.id = h.classe_id
          JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
          WHERE h.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true
            AND ($1::text IS NULL OR h.resultat_final ILIKE '%' || $1 || '%')
            AND ($2::text IS NULL OR a.libelle ILIKE '%' || $2 || '%')
          ORDER BY a.libelle DESC, c.nom, e.nom
          LIMIT 200`,
    parametres: ['resultat', 'annee']
  },
  parcours_eleve: {
    description: "Parcours complet d'un élève sur toutes les années archivées. Paramètre : nom (fragment du nom ou matricule).",
    sql: `SELECT e.matricule, e.nom, e.postnom, e.prenom,
                 a.libelle AS annee, c.nom AS classe, h.resultat_final
          FROM eleve_classe_historique h
          JOIN eleves e ON e.id = h.eleve_id
          JOIN classes c ON c.id = h.classe_id
          JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
          WHERE h.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true
            AND (e.nom ILIKE '%' || $1 || '%' OR e.postnom ILIKE '%' || $1 || '%'
                 OR e.prenom ILIKE '%' || $1 || '%' OR e.matricule ILIKE '%' || $1 || '%')
          ORDER BY e.nom, a.libelle
          LIMIT 200`,
    parametres: ['nom']
  },
  effectifs_annee: {
    description: "Effectifs par classe pour une année archivée. Paramètre : annee (libellé ou null pour toutes).",
    sql: `SELECT a.libelle AS annee, c.nom AS classe, count(*) AS effectif
          FROM eleve_classe_historique h
          JOIN classes c ON c.id = h.classe_id
          JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
          WHERE h.ecole_id = ${CURRENT_ECOLE} AND a.cloturee = true
            AND ($1::text IS NULL OR a.libelle ILIKE '%' || $1 || '%')
          GROUP BY a.libelle, c.nom
          ORDER BY a.libelle DESC, c.nom
          LIMIT 200`,
    parametres: ['annee']
  },
  meilleurs_resultats: {
    description: "Meilleurs pourcentages des années archivées. Paramètre : annee (libellé ou null).",
    sql: `SELECT e.matricule, e.nom, e.postnom, e.prenom, c.nom AS classe,
                 a.libelle AS annee, p.libelle AS periode, b.pourcentage, b.mention
          FROM bulletins b
          JOIN eleves e ON e.id = b.eleve_id
          JOIN periodes p ON p.id = b.periode_id
          JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
          JOIN eleve_classe_historique h ON h.eleve_id = e.id AND h.annee_scolaire_id = a.id
          JOIN classes c ON c.id = h.classe_id
          WHERE a.cloturee = true AND b.pourcentage IS NOT NULL
            AND h.ecole_id = ${CURRENT_ECOLE}
            AND ($1::text IS NULL OR a.libelle ILIKE '%' || $1 || '%')
          ORDER BY b.pourcentage DESC
          LIMIT 50`,
    parametres: ['annee']
  }
};

/** Journalise une recherche, qu'elle ait abouti ou non. Jamais bloquant. */
async function journaliser(client, req, entree) {
  try {
    await client.query(
      `INSERT INTO ia_requetes_journal
         (ecole_id, utilisateur_id, question, modele, sql_genere, nb_lignes, duree_ms, statut, detail)
       VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7, $8)`,
      [req.auth.userId, entree.question, entree.modele || null, entree.sql || null,
       entree.nbLignes ?? null, entree.duree ?? null, entree.statut, entree.detail || null]
    );
  } catch (e) {
    // Un registre indisponible ne doit jamais empêcher une recherche.
    console.error('Journalisation IA impossible:', e.message);
  }
}

const DESCRIPTION_VUES = `Vues disponibles (aucune autre relation n'est accessible) :
- ia_eleves(eleve_id, matricule, nom_complet, sexe, date_naissance, statut, classe_id, classe_nom, annee_libelle)
- ia_classes(classe_id, classe_nom, section, option, annee_libelle, annee_cloturee, effectif)
- ia_bulletins(eleve_id, nom_complet, classe_nom, annee_libelle, periode_libelle, periode_numero, pourcentage, total, classement, mention, conduite, signe)
- ia_notes(eleve_id, nom_complet, classe_nom, cours, periode_libelle, points_obtenus, maximum, annee_libelle)
- ia_presences(eleve_id, nom_complet, classe_nom, date_jour, statut)
- ia_discipline(eleve_id, nom_complet, classe_nom, date_incident, type, points, mesure, annee_libelle)
- ia_paiements(eleve_id, nom_complet, classe_nom, montant, date_paiement, methode)
- ia_historique(eleve_id, nom_complet, classe_nom, annee_libelle, resultat_final)
- ia_annees(annee_id, libelle, date_debut, date_fin, active, cloturee)
- ia_periodes(periode_id, libelle, numero, type, annee_libelle, date_debut, date_fin)
- ia_cours(cours_id, cours_nom, code, maximum_points, classe_nom, annee_libelle)`;

/**
 * POST /ia/archives/recherche
 *
 * Deux chemins, un seul appel au modèle :
 *   · la question correspond à une recherche préécrite → SQL figé, vérifié,
 *     gratuit à exécuter et identique d'une fois sur l'autre ;
 *   · sinon → requête produite par l'assistant, passée au garde-fou puis
 *     exécutée dans le harnais en lecture seule.
 *
 * Le second chemin est le dernier recours, jamais le premier réflexe.
 */
async function rechercheArchives(req, res) {
  const { question } = req.body;
  if (!question || !String(question).trim()) {
    return res.status(400).json({ message: 'Posez une question.' });
  }
  if (String(question).length > 300) {
    return res.status(400).json({ message: 'Question trop longue (300 caractères maximum).' });
  }
  const demande = String(question).trim();

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);

      const catalogue = Object.entries(MODELES_RECHERCHE)
        .map(([cle, m]) => `- ${cle} : ${m.description}`)
        .join('\n');

      const systeme = `Tu traduis une question posée en français vers une recherche dans les données d'une école congolaise.

RECHERCHES PRÉÉCRITES — à privilégier absolument :
${catalogue}

Si la question correspond, même approximativement, à l'une d'elles, choisis-la.
Elles sont vérifiées et fiables ; une requête écrite par toi ne l'est pas.

SI ET SEULEMENT SI aucune ne convient, écris une requête SQL PostgreSQL.

${DESCRIPTION_VUES}

Contraintes absolues pour une requête écrite par toi :
- Une seule instruction SELECT (un WITH est admis). Jamais de point-virgule.
- Aucun commentaire, aucun paramètre, aucune écriture.
- Uniquement les vues ci-dessus : toute autre table sera rejetée.
- N'ajoute AUCUN filtre sur l'école : il est appliqué automatiquement.
- Ajoute toujours une clause LIMIT (300 au maximum).
- Nomme les colonnes de sortie en français, avec des alias explicites.

Réponds UNIQUEMENT en JSON, dans l'une de ces trois formes :
{"modele":"nom","parametres":{…},"explication":"…"}
{"sql":"SELECT …","explication":"…"}
{"modele":null,"sql":null,"explication":"pourquoi la question ne peut pas aboutir"}`;

      const choix = await appelerIAJson({ systeme, message: demande, maxTokens: 900 });

      // ---------- Chemin 1 : recherche préécrite ----------
      const cle = choix && choix.modele;
      if (cle && MODELES_RECHERCHE[cle]) {
        const modele = MODELES_RECHERCHE[cle];
        const params = modele.parametres.map((nom) => {
          const valeur = (choix.parametres || {})[nom];
          if (nom === 'nb_minimum') {
            const n = Number(valeur);
            return Number.isFinite(n) && n >= 1 ? Math.min(Math.floor(n), 20) : 1;
          }
          if (valeur === undefined || valeur === null || valeur === '') return null;
          return String(valeur).slice(0, 80);
        });

        const debut = Date.now();
        const resultat = await client.query(modele.sql, params);
        await journaliser(client, req, {
          question: demande, modele: cle, statut: 'preecrite',
          nbLignes: resultat.rows.length, duree: Date.now() - debut
        });

        return {
          origine: 'preecrite',
          modele: cle,
          explication: choix.explication || modele.description,
          colonnes: resultat.rows.length ? Object.keys(resultat.rows[0]) : [],
          lignes: resultat.rows,
          quota: infoQuota
        };
      }

      // ---------- Chemin 2 : requête produite par l'assistant ----------
      if (choix && choix.sql) {
        let sqlValide;
        try {
          sqlValide = validerRequete(choix.sql);
        } catch (e) {
          await journaliser(client, req, {
            question: demande, sql: choix.sql, statut: 'refusee',
            detail: e.detailValidation || e.message
          });
          return {
            origine: 'refusee',
            explication: "La requête proposée n'a pas satisfait les contrôles de sécurité. Reformulez votre question ou passez par les recherches proposées.",
            sql: choix.sql, detail: e.detailValidation || e.message,
            lignes: [], colonnes: [], quota: infoQuota
          };
        }

        try {
          const { lignes, duree } = await executerRequeteLectureIA({ ecoleId: id, sql: sqlValide });
          await journaliser(client, req, {
            question: demande, sql: sqlValide, statut: 'executee',
            nbLignes: lignes.length, duree
          });

          return {
            origine: 'generee',
            explication: choix.explication || 'Recherche construite pour cette question.',
            sql: sqlValide, duree,
            colonnes: lignes.length ? Object.keys(lignes[0]) : [],
            lignes, quota: infoQuota
          };
        } catch (e) {
          await journaliser(client, req, {
            question: demande, sql: sqlValide, statut: 'erreur',
            detail: (e.message || '').slice(0, 400), duree: e.dureeIA ?? null
          });
          return {
            origine: 'erreur',
            explication: "La recherche n'a pas pu être exécutée. Reformulez votre question autrement.",
            sql: sqlValide, detail: (e.message || '').slice(0, 300),
            lignes: [], colonnes: [], quota: infoQuota
          };
        }
      }

      // ---------- Chemin 3 : rien de possible ----------
      await journaliser(client, req, {
        question: demande, statut: 'sans_reponse',
        detail: (choix && choix.explication) || null
      });
      return {
        origine: 'aucune',
        explication: (choix && choix.explication)
          || "Cette question ne correspond à aucune recherche possible sur les données disponibles.",
        lignes: [], colonnes: [], quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur recherche archives:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /ia/journal
 * Registre des recherches. Réservé au Super Administrateur : c'est un outil
 * de diagnostic, pas une information utile à un directeur d'école.
 */
async function journal(req, res) {
  const limite = Math.min(Math.max(Number(req.query.limite) || 100, 1), 500);
  const statut = req.query.statut || null;

  try {
    const lignes = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(
        `SELECT j.id, j.question, j.modele, j.sql_genere, j.nb_lignes, j.duree_ms,
                j.statut, j.detail, j.created_at,
                e.nom AS ecole_nom, e.code AS ecole_code,
                trim(concat(u.prenom, ' ', u.nom)) AS utilisateur
         FROM ia_requetes_journal j
         LEFT JOIN ecoles e ON e.id = j.ecole_id
         LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
         WHERE ($1::text IS NULL OR j.statut = $1)
         ORDER BY j.created_at DESC
         LIMIT $2`,
        [statut, limite]
      )
    );
    return res.json(lignes.rows.map((l) => ({
      ...l,
      nb_lignes: l.nb_lignes === null ? null : Number(l.nb_lignes),
      duree_ms: l.duree_ms === null ? null : Number(l.duree_ms)
    })));
  } catch (err) {
    console.error('Erreur journal IA:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


/* ==========================================================================
   8. Questions sur la plateforme Ardoise (assistant d'aide)
   L'assistant répond aux questions sur l'utilisation de la plateforme.
   Il n'a accès à aucune donnée de l'école.
   ========================================================================== */

const BASE_CONNAISSANCE_PLATEFORME = `
Tu es l'assistant d'aide de la plateforme Ardoise, un logiciel de gestion
scolaire pour les écoles secondaires en République démocratique du Congo.

Tu peux répondre à des questions sur :
- La navigation dans la plateforme (où trouver un écran, comment y accéder)
- Les fonctionnalités disponibles (bulletins, notes, présences, frais, etc.)
- Les procédures courantes (créer une classe, inscrire un élève, générer des bulletins, etc.)
- La signification des termes et réglages (capital de conduite, seuil de promotion, etc.)
- Les rôles et leurs permissions (directeur, préfet, secrétaire, professeur, titulaire, comptable)

Tu n'as accès à AUCUNE donnée de l'école (pas de notes, pas de noms d'élèves,
pas de paiements, pas de dossiers). Si on te demande une donnée précise sur
l'école, réponds clairement que tu ne peux pas y accéder et oriente vers l'écran
approprié.

Règles :
- Réponses courtes et pratiques, 150 mots maximum
- Indique toujours le nom de l'écran ou du menu concerné
- Si tu n'es pas sûr, dis-le franchement
- Réponds en JSON : {"question":"…","reponse":"…"}
`;

async function questionPlateforme(req, res) {
  const { question, page } = req.body;
  if (!question || !String(question).trim()) {
    return res.status(400).json({ message: 'Posez une question.' });
  }
  if (String(question).length > 400) {
    return res.status(400).json({ message: 'Question trop longue (400 caractères maximum).' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const id = await ecoleId(client);
      const infoQuota = await consommerQuota(client, id, 1);

      const contexte = page ? `\n\nL'utilisateur pose cette question depuis l'écran : ${page}.` : '';

      const resultat = await appelerIAJson({
        systeme: BASE_CONNAISSANCE_PLATEFORME,
        message: `${String(question).trim()}${contexte}`,
        maxTokens: 600
      });

      return {
        question: String(question).trim(),
        reponse: (resultat && resultat.reponse) || "Je n'ai pas pu formuler une réponse. Consultez le manuel de votre rôle.",
        quota: infoQuota
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur question plateforme:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  quota, questionPlateforme, decrochage, appreciations, appliquerAppreciations,
  questionEleve, redaction, conseilClasse,
  analyserImport, appliquerImport, rechercheArchives, journal
};
