const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Inscriptions et concours d'admission — Ardoise
 * --------------------------------------------------------------------------
 * Ce module décide qui entre dans une école. Il porte donc des règles d'équité
 * qui ne sont PAS de simples consignes, mais des refus du serveur :
 *
 *   1. Le classement est CALCULÉ à partir des notes, jamais saisi.
 *   2. Un candidat strictement au-dessus de la note plancher est admis de
 *      droit. Le serveur refuse de le rejeter, quel que soit le rôle du
 *      demandeur — directeur compris.
 *   3. Une recommandation ne peut qu'AJOUTER un candidat au-delà du quota.
 *      Elle ne déplace jamais personne, et laisse une trace nominative.
 *   4. Les résultats restent invisibles tant que la session n'est pas
 *      publiée, y compris pour le secrétariat.
 *   5. Le correcteur ne voit que des numéros de candidats, jamais des noms,
 *      et uniquement pour l'épreuve qui lui est confiée.
 */

const STATUTS_SESSION = ['brouillon', 'ouverte', 'fermee', 'corrigee', 'publiee'];

function estDirection(req) {
  return req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
}

function nomComplet(c) {
  return [c.nom, c.postnom, c.prenom].filter(Boolean).join(' ');
}

async function chargerSession(client, sessionId) {
  const r = await client.query(
    `SELECT s.* FROM sessions_inscription s WHERE s.id = $1 AND s.ecole_id = ${CURRENT_ECOLE}`,
    [sessionId]
  );
  if (r.rows.length === 0) {
    throw Object.assign(new Error('Session introuvable.'), { statusCode: 404 });
  }
  const session = r.rows[0];

  // Une session recrute pour une promotion entière — la 7e année — qui peut
  // compter plusieurs classes. Une destination unique obligeait à entasser
  // tous les admis dans la même, ce qui n'a aucun sens passé trente élèves.
  const classes = await client.query(
    `SELECT c.id, c.nom, c.capacite, c.annee_scolaire_id,
            (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS effectif
     FROM sessions_classes_cibles sc
     JOIN classes c ON c.id = sc.classe_id
     WHERE sc.session_id = $1 AND sc.ecole_id = ${CURRENT_ECOLE}
     ORDER BY c.nom`,
    [sessionId]
  );

  session.classes_cibles = classes.rows.map((c) => {
    const capacite = c.capacite === null ? null : Number(c.capacite);
    const effectif = Number(c.effectif);
    return {
      id: c.id, nom: c.nom, capacite, effectif,
      annee_scolaire_id: c.annee_scolaire_id,
      // Places RESTANTES, et non capacité brute. L'effectif d'une classe de
      // l'année à venir, ce sont les élèves que la promotion interne y a déjà
      // fait monter : ce sont eux qui déterminent ce qui reste à offrir aux
      // candidats extérieurs. Afficher la capacité totale ferait promettre des
      // places déjà prises.
      places_restantes: capacite === null ? null : Math.max(capacite - effectif, 0),
      // Une classe qui n'appartient pas à l'année d'entrée est une erreur de
      // configuration : on la signale plutôt que d'y inscrire quelqu'un.
      annee_incoherente: session.annee_cible_id
        ? c.annee_scolaire_id !== session.annee_cible_id
        : false
    };
  });
  session.classe_nom = session.classes_cibles.map((c) => c.nom).join(', ') || null;

  // Libellés des deux années : l'écran doit pouvoir dire « organisé en
  // 2025-2026, entrée en 2026-2027 » sans deviner.
  const annees = await client.query(
    `SELECT id, libelle, active, date_debut FROM annees_scolaires
      WHERE ecole_id = ${CURRENT_ECOLE} AND id = ANY($1::uuid[])`,
    [[session.annee_scolaire_id, session.annee_cible_id].filter(Boolean)]
  );
  const parId = new Map(annees.rows.map((a) => [a.id, a]));
  session.annee_organisation = parId.get(session.annee_scolaire_id) || null;
  session.annee_cible = parId.get(session.annee_cible_id) || null;

  // Places totales encore offertes, toutes classes d'accueil confondues.
  const avecCapacite = session.classes_cibles.filter((c) => c.capacite !== null);
  session.places_restantes_total = avecCapacite.length === session.classes_cibles.length
    && session.classes_cibles.length > 0
      ? avecCapacite.reduce((t, c) => t + c.places_restantes, 0)
      : null;

  return session;
}

/** Enregistre la liste des classes d'accueil d'une session. */
async function definirClassesCibles(client, sessionId, classeIds) {
  await client.query(`DELETE FROM sessions_classes_cibles WHERE session_id = $1`, [sessionId]);
  for (const classeId of (classeIds || []).filter(Boolean)) {
    await client.query(
      `INSERT INTO sessions_classes_cibles (ecole_id, session_id, classe_id)
       VALUES (${CURRENT_ECOLE}, $1, $2) ON CONFLICT DO NOTHING`,
      [sessionId, classeId]
    );
  }
}


/**
 * Résout l'année d'ENTRÉE des candidats d'une session.
 *
 * Un concours recrute pour l'année suivante : c'est la règle, parce que la
 * place offerte est celle que libère la promotion sortante. La valeur peut
 * être imposée explicitement (une école qui recrute en cours d'année pour
 * combler un départ), mais le défaut suit la logique métier.
 *
 * L'année suivante se détermine par la DATE DE DÉBUT, pas par le libellé :
 * « 2026-2027 » et « 2026 – 2027 » se trient différemment selon les écoles, et
 * un tri alphabétique casserait au premier changement de convention.
 */
async function resoudreAnneeCible(client, anneeActiveId, anneeCibleDemandee) {
  if (anneeCibleDemandee) {
    const r = await client.query(
      `SELECT id, libelle, cloturee FROM annees_scolaires
        WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
      [anneeCibleDemandee]
    );
    if (r.rows.length === 0) {
      throw Object.assign(new Error("Année d'entrée introuvable."), { statusCode: 400 });
    }
    if (r.rows[0].cloturee) {
      throw Object.assign(
        new Error(`L'année ${r.rows[0].libelle} est clôturée : on ne peut pas y faire entrer de nouveaux élèves.`),
        { statusCode: 409 }
      );
    }
    return r.rows[0];
  }

  const active = await client.query(
    `SELECT id, libelle, date_debut FROM annees_scolaires WHERE id = $1`, [anneeActiveId]
  );
  const suivante = await client.query(
    `SELECT id, libelle FROM annees_scolaires
      WHERE ecole_id = ${CURRENT_ECOLE} AND cloturee = false
        AND date_debut > $1::date
      ORDER BY date_debut LIMIT 1`,
    [active.rows[0]?.date_debut || null]
  );

  if (suivante.rows.length > 0) return suivante.rows[0];

  // Aucune année suivante : on ne bascule PAS silencieusement sur l'année en
  // cours. Inscrire un candidat au milieu d'une année déjà commencée est une
  // décision, pas un défaut technique — le directeur doit la prendre.
  throw Object.assign(
    new Error(
      "Aucune année scolaire à venir n'est créée. Créez d'abord l'année prochaine "
      + "dans Structure › Années scolaires, ou choisissez explicitement l'année d'entrée "
      + "s'il s'agit d'un recrutement en cours d'année."
    ),
    { statusCode: 409 }
  );
}

/**
 * Vérifie que les classes d'accueil appartiennent bien à l'année d'entrée.
 *
 * C'est le contrôle qui manquait, et il explique le symptôme observé : un
 * admis se retrouvait affecté à une classe de l'année EN COURS, donc au milieu
 * d'une année déjà entamée, avec des périodes auxquelles il n'a pas participé.
 */
async function verifierClassesCibles(client, classeIds, anneeCible) {
  const ids = (classeIds || []).filter(Boolean);
  if (ids.length === 0) return [];

  const r = await client.query(
    `SELECT c.id, c.nom, c.annee_scolaire_id, a.libelle AS annee_libelle
       FROM classes c
       LEFT JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
      WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.id = ANY($1::uuid[])`,
    [ids]
  );

  if (r.rows.length !== ids.length) {
    throw Object.assign(new Error("Une des classes d'accueil est introuvable."), { statusCode: 400 });
  }

  const horsAnnee = r.rows.filter((c) => c.annee_scolaire_id !== anneeCible.id);
  if (horsAnnee.length > 0) {
    throw Object.assign(
      new Error(
        `Ces classes n'appartiennent pas à ${anneeCible.libelle} : `
        + horsAnnee.map((c) => `${c.nom} (${c.annee_libelle || 'sans année'})`).join(', ')
        + `. Un candidat admis entre dans une classe de l'année d'accueil, `
        + `celle que libère la promotion sortante.`
      ),
      { statusCode: 400 }
    );
  }
  return r.rows;
}

/** Aujourd'hui au format AAAA-MM-JJ, en heure locale. */
function aujourdhui() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Vérifie que la date du jour tombe dans la fenêtre d'inscription.
 * Sans ce contrôle, une session oubliée ouverte laisserait entrer un candidat
 * des mois après le test — et donc après la publication des résultats.
 */
function verifierFenetre(session) {
  const jour = aujourdhui();
  const debut = session.date_ouverture ? String(session.date_ouverture).slice(0, 10) : null;
  const fin = session.date_cloture ? String(session.date_cloture).slice(0, 10) : null;

  if (debut && jour < debut) {
    throw Object.assign(
      new Error(`Les inscriptions n'ouvrent que le ${debut}.`),
      { statusCode: 409 }
    );
  }
  if (fin && jour > fin) {
    throw Object.assign(
      new Error(`Les inscriptions sont closes depuis le ${fin}. Rouvrez la période si c'est justifié.`),
      { statusCode: 409 }
    );
  }
}

/* ==========================================================================
   Sessions
   ========================================================================== */

async function listerSessions(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT s.id, s.libelle, s.mode, s.statut, s.places, s.date_test,
                s.date_ouverture, s.date_cloture, s.publie_at,
                (SELECT string_agg(c2.nom, ', ' ORDER BY c2.nom)
                   FROM sessions_classes_cibles sc JOIN classes c2 ON c2.id = sc.classe_id
                  WHERE sc.session_id = s.id) AS classe_nom,
                a.libelle AS annee_libelle,
                (SELECT count(*) FROM candidats k WHERE k.session_id = s.id) AS nb_candidats,
                (SELECT count(*) FROM candidats k WHERE k.session_id = s.id AND k.statut = 'admis') AS nb_admis,
                (SELECT count(*) FROM epreuves_inscription e WHERE e.session_id = s.id) AS nb_epreuves
         FROM sessions_inscription s
         LEFT JOIN annees_scolaires a ON a.id = s.annee_scolaire_id
         WHERE s.ecole_id = ${CURRENT_ECOLE}
         ORDER BY s.created_at DESC`
      )
    );
    return res.json(result.rows.map((s) => ({
      ...s,
      places: Number(s.places),
      nb_candidats: Number(s.nb_candidats),
      nb_admis: Number(s.nb_admis),
      nb_epreuves: Number(s.nb_epreuves)
    })));
  } catch (err) {
    console.error('Erreur liste sessions:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerSession(req, res) {
  const { libelle, classes_cibles, places, mode, date_test,
          date_ouverture, date_cloture, annee_cible_id } = req.body;

  if (!libelle || !String(libelle).trim()) {
    return res.status(400).json({ message: 'Le libellé de la session est requis.' });
  }
  const nbPlaces = Number(places);
  if (!Number.isInteger(nbPlaces) || nbPlaces < 1 || nbPlaces > 5000) {
    return res.status(400).json({ message: 'Le nombre de places doit être un entier entre 1 et 5000.' });
  }
  if (!['direct', 'test'].includes(mode)) {
    return res.status(400).json({ message: "Mode inconnu : « direct » ou « test »." });
  }

  try {
    const id = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await client.query(
        `SELECT id FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
      );
      if (annee.rows.length === 0) {
        throw Object.assign(new Error('Aucune année scolaire active.'), { statusCode: 409 });
      }
      if (date_ouverture && date_cloture && date_ouverture > date_cloture) {
        throw Object.assign(
          new Error("La date de clôture doit suivre la date d'ouverture."),
          { statusCode: 400 }
        );
      }

      // L'année d'ENTRÉE, distincte de l'année d'organisation. Un concours
      // recrute pour l'année suivante : c'est la promotion sortante qui libère
      // les places, la promotion montante qui les occupe, et le reste qui est
      // offert aux candidats extérieurs.
      const anneeCible = await resoudreAnneeCible(client, annee.rows[0].id, annee_cible_id);
      await verifierClassesCibles(client, classes_cibles, anneeCible);

      const r = await client.query(
        `INSERT INTO sessions_inscription
           (ecole_id, annee_scolaire_id, annee_cible_id, libelle, places, mode, date_test,
            date_ouverture, date_cloture, statut, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7, $8, 'ouverte', $9)
         RETURNING id`,
        [annee.rows[0].id, anneeCible.id, String(libelle).trim(), nbPlaces, mode, date_test || null,
         date_ouverture || null, date_cloture || null, req.auth.userId]
      );
      await definirClassesCibles(client, r.rows[0].id, classes_cibles);
      return { id: r.rows[0].id, anneeCible };
    });
    return res.status(201).json({
      id: id.id,
      annee_cible: id.anneeCible,
      message: `Session créée et ouverte. Les admis entreront en ${id.anneeCible.libelle}.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création session:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /inscriptions/sessions/:id — libellé, places, date, statut. */
async function modifierSession(req, res) {
  const { id } = req.params;
  const { libelle, places, date_test, statut, classes_cibles,
          date_ouverture, date_cloture, annee_cible_id } = req.body;

  if (statut && !STATUTS_SESSION.includes(statut)) {
    return res.status(400).json({ message: 'Statut inconnu.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, id);

      // Le nombre de places d'une session publiée est figé : l'augmenter
      // après coup reviendrait à rouvrir l'admission dans le dos du classement.
      if (places !== undefined && session.statut === 'publiee') {
        throw Object.assign(
          new Error('Les places ne peuvent plus être modifiées : la session est publiée. Dépubliez-la si c\'est vraiment nécessaire.'),
          { statusCode: 409 }
        );
      }
      // Dépublier est autorisé mais laisse une trace : c'est ce qui rend
      // une correction tardive visible plutôt que discrète.
      if (statut && statut !== 'publiee' && session.statut === 'publiee' && !estDirection(req)) {
        throw Object.assign(new Error('Seule la direction peut dépublier une session.'), { statusCode: 403 });
      }

      const nbPlaces = places !== undefined ? Number(places) : null;
      if (nbPlaces !== null && (!Number.isInteger(nbPlaces) || nbPlaces < 1)) {
        throw Object.assign(new Error('Nombre de places invalide.'), { statusCode: 400 });
      }

      // Changer l'année d'entrée après que des candidats ont été convertis
      // déplacerait des élèves déjà inscrits d'une année à l'autre. On refuse.
      if (annee_cible_id && annee_cible_id !== session.annee_cible_id) {
        const convertis = await client.query(
          `SELECT count(*) AS nb FROM candidats
            WHERE session_id = $1 AND eleve_id IS NOT NULL`, [id]
        );
        if (Number(convertis.rows[0].nb) > 0) {
          throw Object.assign(
            new Error(
              `${convertis.rows[0].nb} candidat(s) ont déjà été inscrits comme élèves pour `
              + `l'année d'entrée actuelle. Changer cette année les déplacerait de classe. `
              + `Créez plutôt une nouvelle session.`
            ),
            { statusCode: 409 }
          );
        }
      }

      const anneeCible = annee_cible_id
        ? await resoudreAnneeCible(client, session.annee_scolaire_id, annee_cible_id)
        : { id: session.annee_cible_id, libelle: session.annee_cible?.libelle || '' };

      // Les classes d'accueil sont revalidées à CHAQUE modification, même
      // quand seule l'année change : sinon on garderait des classes de
      // l'ancienne année, et l'incohérence ne se verrait qu'à la conversion.
      if (Array.isArray(classes_cibles)) {
        await verifierClassesCibles(client, classes_cibles, anneeCible);
        await definirClassesCibles(client, id, classes_cibles);
      } else if (annee_cible_id && annee_cible_id !== session.annee_cible_id) {
        await verifierClassesCibles(
          client, session.classes_cibles.map((c) => c.id), anneeCible
        );
      }

      await client.query(
        `UPDATE sessions_inscription SET
           annee_cible_id = COALESCE($8, annee_cible_id),
           date_ouverture = COALESCE($6, date_ouverture),
           date_cloture = COALESCE($7, date_cloture),
           libelle = COALESCE($1, libelle),
           places = COALESCE($2, places),
           date_test = COALESCE($3, date_test),
           statut = COALESCE($4, statut),
           publie_at = CASE WHEN $4 = 'publiee' THEN publie_at
                            WHEN $4 IS NOT NULL THEN NULL ELSE publie_at END
         WHERE id = $5 AND ecole_id = ${CURRENT_ECOLE}`,
        [libelle ? String(libelle).trim() : null, nbPlaces, date_test || null, statut || null, id,
         date_ouverture || null, date_cloture || null, annee_cible_id || null]
      );
    });
    return res.json({ message: 'Session mise à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification session:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Épreuves
   ========================================================================== */

async function listerEpreuves(req, res) {
  const { sessionId } = req.params;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT e.id, e.nom, e.maximum, e.ordre, e.correcteur_id,
                trim(concat(u.prenom, ' ', u.nom)) AS correcteur_nom,
                (SELECT count(*) FROM notes_candidats n
                  WHERE n.epreuve_id = e.id AND n.points IS NOT NULL) AS nb_notes
         FROM epreuves_inscription e
         LEFT JOIN utilisateurs u ON u.id = e.correcteur_id
         WHERE e.session_id = $1 AND e.ecole_id = ${CURRENT_ECOLE}
         ORDER BY e.ordre, e.nom`,
        [sessionId]
      )
    );
    return res.json(result.rows.map((e) => ({
      ...e, maximum: Number(e.maximum), nb_notes: Number(e.nb_notes)
    })));
  } catch (err) {
    console.error('Erreur liste épreuves:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerEpreuve(req, res) {
  const { sessionId } = req.params;
  const { nom, maximum } = req.body;

  if (!nom || !String(nom).trim()) {
    return res.status(400).json({ message: "Le nom de l'épreuve est requis." });
  }
  const max = Number(maximum);
  if (!Number.isFinite(max) || max <= 0 || max > 1000) {
    return res.status(400).json({ message: 'Le maximum doit être un nombre entre 1 et 1000.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, sessionId);
      if (session.statut === 'publiee') {
        throw Object.assign(
          new Error('Session publiée : la structure du test ne peut plus changer.'),
          { statusCode: 409 }
        );
      }
      const ordre = await client.query(
        `SELECT COALESCE(max(ordre), 0) + 1 AS suivant FROM epreuves_inscription WHERE session_id = $1`,
        [sessionId]
      );
      await client.query(
        `INSERT INTO epreuves_inscription (ecole_id, session_id, nom, maximum, ordre)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4)`,
        [sessionId, String(nom).trim(), max, ordre.rows[0].suivant]
      );
    });
    return res.status(201).json({ message: 'Épreuve ajoutée.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création épreuve:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /inscriptions/epreuves/:epreuveId/correcteur
 * Confie une épreuve à un enseignant et le prévient par message interne.
 */
async function assignerCorrecteur(req, res) {
  const { epreuveId } = req.params;
  const { correcteur_id } = req.body;
  if (!correcteur_id) return res.status(400).json({ message: 'Choisissez un correcteur.' });

  try {
    const info = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const epreuve = await client.query(
        `SELECT e.id, e.nom, e.session_id, s.libelle AS session_libelle, s.statut
         FROM epreuves_inscription e
         JOIN sessions_inscription s ON s.id = e.session_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [epreuveId]
      );
      if (epreuve.rows.length === 0) {
        throw Object.assign(new Error('Épreuve introuvable.'), { statusCode: 404 });
      }
      if (epreuve.rows[0].statut === 'publiee') {
        throw Object.assign(new Error('Session publiée : la correction est close.'), { statusCode: 409 });
      }

      const correcteur = await client.query(
        `SELECT u.id, u.nom, u.prenom FROM utilisateurs u
         JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE u.id = $1 AND u.ecole_id = ${CURRENT_ECOLE} AND u.statut = 'actif'
           AND ur.role::text IN ('professeur','titulaire','prefet','directeur')`,
        [correcteur_id]
      );
      if (correcteur.rows.length === 0) {
        throw Object.assign(
          new Error("Cette personne ne fait pas partie du personnel enseignant de l'école."),
          { statusCode: 400 }
        );
      }

      await client.query(
        `UPDATE epreuves_inscription SET correcteur_id = $1, assignee_at = now() WHERE id = $2`,
        [correcteur_id, epreuveId]
      );

      // La demande arrive dans la messagerie du correcteur : c'est ce qui
      // déclenche son travail, il n'a pas à surveiller un écran.
      await client.query(
        `INSERT INTO notifications (ecole_id, utilisateur_id, canal, sujet, contenu, statut, lu)
         VALUES (${CURRENT_ECOLE}, $1, 'interne', $2, $3, 'envoye', false)`,
        [correcteur_id,
         `Correction à saisir — ${epreuve.rows[0].nom}`,
         `L'épreuve « ${epreuve.rows[0].nom} » de la session « ${epreuve.rows[0].session_libelle} » vous est confiée.\n\n`
         + `Ouvrez l'écran Inscriptions pour saisir les points. Les copies sont anonymes : `
         + `vous ne verrez que des numéros de candidats.`]
      );

      return [correcteur.rows[0].prenom, correcteur.rows[0].nom].filter(Boolean).join(' ');
    });
    return res.json({ message: `Épreuve confiée à ${info}, qui vient d'être prévenu.` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur assignation correcteur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Candidats
   ========================================================================== */

async function listerCandidats(req, res) {
  const { sessionId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, sessionId);

      // Les résultats sont sous scellé : tant que la session n'est pas
      // publiée, personne ne voit ni total, ni rang, ni décision.
      const publiee = session.statut === 'publiee';

      const r = await client.query(
        `SELECT k.id, k.numero_candidat, k.nom, k.postnom, k.prenom, k.sexe,
                k.date_naissance, k.responsable_nom, k.responsable_telephone,
                k.ecole_provenance, k.statut::text, k.eleve_id,
                k.recommande, k.motif_recommandation,
                k.total, k.rang,
                trim(concat(u.prenom, ' ', u.nom)) AS decide_par_nom
         FROM candidats k
         LEFT JOIN utilisateurs u ON u.id = k.decide_par
         WHERE k.session_id = $1 AND k.ecole_id = ${CURRENT_ECOLE}
         ORDER BY ${publiee ? 'k.rang NULLS LAST, k.nom' : 'k.nom, k.postnom'}`,
        [sessionId]
      );

      return {
        session: {
          id: session.id, libelle: session.libelle, statut: session.statut,
          mode: session.mode, places: Number(session.places),
          classe_nom: session.classe_nom, classes_cibles: session.classes_cibles,
          date_ouverture: session.date_ouverture, date_cloture: session.date_cloture,
          publie_at: session.publie_at
        },
        publiee,
        candidats: r.rows.map((k) => ({
          ...k,
          nom_complet: nomComplet(k),
          total: publiee && k.total !== null ? Number(k.total) : null,
          rang: publiee ? k.rang : null,
          statut: publiee ? k.statut : 'inscrit'
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste candidats:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function inscrireCandidat(req, res) {
  const { sessionId } = req.params;
  const { nom, postnom, prenom, sexe, date_naissance,
          responsable_nom, responsable_telephone, responsable_email, ecole_provenance } = req.body;

  if (!nom || !String(nom).trim()) {
    return res.status(400).json({ message: 'Le nom du candidat est requis.' });
  }

  try {
    const numero = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, sessionId);
      if (!['ouverte', 'brouillon'].includes(session.statut)) {
        throw Object.assign(
          new Error('Les inscriptions de cette session sont closes.'),
          { statusCode: 409 }
        );
      }
      verifierFenetre(session);

      // Numéro anonyme, séquentiel dans la session. C'est lui — et lui seul —
      // que verra le correcteur.
      const suivant = await client.query(
        `SELECT COALESCE(max(NULLIF(regexp_replace(numero_candidat, '\\D', '', 'g'), '')::int), 0) + 1 AS n
         FROM candidats WHERE session_id = $1`,
        [sessionId]
      );
      const numeroCandidat = `C-${String(suivant.rows[0].n).padStart(4, '0')}`;

      await client.query(
        `INSERT INTO candidats
           (ecole_id, session_id, numero_candidat, nom, postnom, prenom, sexe, date_naissance,
            responsable_nom, responsable_telephone, responsable_email, ecole_provenance, inscrit_par)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [sessionId, numeroCandidat, String(nom).trim(), postnom || null, prenom || null,
         sexe || null, date_naissance || null, responsable_nom || null,
         responsable_telephone || null, responsable_email || null,
         ecole_provenance || null, req.auth.userId]
      );

      // Une ligne de note vide est créée pour chaque épreuve : le correcteur
      // voit ainsi la liste complète des copies attendues, absents compris.
      await client.query(
        `INSERT INTO notes_candidats (ecole_id, epreuve_id, candidat_id)
         SELECT ${CURRENT_ECOLE}, e.id, k.id
         FROM epreuves_inscription e, candidats k
         WHERE e.session_id = $1 AND k.session_id = $1 AND k.numero_candidat = $2
         ON CONFLICT (epreuve_id, candidat_id) DO NOTHING`,
        [sessionId, numeroCandidat]
      );

      return numeroCandidat;
    });
    return res.status(201).json({ message: `Candidat inscrit sous le numéro ${numero}.`, numero_candidat: numero });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur inscription candidat:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Correction — vue anonyme du correcteur
   ========================================================================== */

/** GET /inscriptions/mes-corrections */
async function mesCorrections(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT e.id, e.nom, e.maximum, s.id AS session_id, s.libelle AS session_libelle,
                s.statut::text AS session_statut, s.date_test,
                (SELECT count(*) FROM notes_candidats n WHERE n.epreuve_id = e.id) AS nb_copies,
                (SELECT count(*) FROM notes_candidats n WHERE n.epreuve_id = e.id AND n.points IS NOT NULL) AS nb_saisies
         FROM epreuves_inscription e
         JOIN sessions_inscription s ON s.id = e.session_id
         WHERE e.correcteur_id = $1 AND e.ecole_id = ${CURRENT_ECOLE}
         ORDER BY s.date_test DESC NULLS LAST, e.ordre`,
        [req.auth.userId]
      )
    );
    return res.json(result.rows.map((e) => ({
      ...e, maximum: Number(e.maximum),
      nb_copies: Number(e.nb_copies), nb_saisies: Number(e.nb_saisies)
    })));
  } catch (err) {
    console.error('Erreur mes corrections:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /inscriptions/epreuves/:epreuveId/copies
 * Liste anonyme : numéros de candidats seulement, jamais de noms.
 */
async function copiesEpreuve(req, res) {
  const { epreuveId } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const epreuve = await client.query(
        `SELECT e.id, e.nom, e.maximum, e.correcteur_id, s.statut::text AS session_statut
         FROM epreuves_inscription e
         JOIN sessions_inscription s ON s.id = e.session_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [epreuveId]
      );
      if (epreuve.rows.length === 0) {
        throw Object.assign(new Error('Épreuve introuvable.'), { statusCode: 404 });
      }
      const e = epreuve.rows[0];

      // La correction appartient au CORRECTEUR désigné, pas à la direction.
      //
      // Auparavant, `estDirection(req)` ouvrait l'accès au directeur et au
      // préfet à toutes les copies, à tout moment. Ce n'est pas leur rôle : ils
      // ne corrigent pas, et voir les notes avant la publication leur permet
      // de connaître le classement avant qu'il ne soit scellé — exactement ce
      // que l'anonymat des copies cherche à empêcher.
      //
      // La direction conserve un accès de CONTRÔLE, mais seulement une fois la
      // session publiée : à ce moment les notes sont figées et les résultats
      // déjà connus des familles, la consultation ne peut plus rien influencer.
      const estCorrecteur = e.correcteur_id === req.auth.userId;
      const controleApresPublication = estDirection(req) && e.session_statut === 'publiee';
      if (!estCorrecteur && !controleApresPublication) {
        throw Object.assign(
          new Error(
            estDirection(req)
              ? "Les copies restent chez le correcteur désigné jusqu'à la publication des résultats."
              : "Cette épreuve ne vous est pas confiée."
          ),
          { statusCode: 403 }
        );
      }

      const copies = await client.query(
        `SELECT k.id AS candidat_id, k.numero_candidat, n.points
         FROM candidats k
         LEFT JOIN notes_candidats n ON n.candidat_id = k.id AND n.epreuve_id = $1
         WHERE k.session_id = (SELECT session_id FROM epreuves_inscription WHERE id = $1)
         ORDER BY k.numero_candidat`,
        [epreuveId]
      );

      return {
        epreuve: { id: e.id, nom: e.nom, maximum: Number(e.maximum), session_statut: e.session_statut },
        // L'écran doit savoir s'il affiche une grille de saisie ou une simple
        // consultation : sans cette information, il proposerait un bouton
        // « Enregistrer » que le serveur refuserait.
        lecture_seule: !estCorrecteur,
        // Aucun nom ici, volontairement : la correction reste anonyme.
        copies: copies.rows.map((c) => ({
          candidat_id: c.candidat_id,
          numero_candidat: c.numero_candidat,
          points: c.points === null ? null : Number(c.points)
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur copies épreuve:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /inscriptions/epreuves/:epreuveId/notes */
async function enregistrerNotes(req, res) {
  const { epreuveId } = req.params;
  const { notes } = req.body;
  if (!Array.isArray(notes) || notes.length === 0) {
    return res.status(400).json({ message: 'Aucune note à enregistrer.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const epreuve = await client.query(
        `SELECT e.id, e.nom, e.maximum, e.correcteur_id, e.session_id, s.statut::text AS session_statut
         FROM epreuves_inscription e
         JOIN sessions_inscription s ON s.id = e.session_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [epreuveId]
      );
      if (epreuve.rows.length === 0) {
        throw Object.assign(new Error('Épreuve introuvable.'), { statusCode: 404 });
      }
      const e = epreuve.rows[0];

      // Saisir une note est l'acte du correcteur, et de lui seul. La direction
      // n'a plus de dérogation ici : si elle veut corriger une épreuve, elle
      // doit se l'attribuer explicitement comme correcteur, ce qui laisse une
      // trace dans `epreuves_inscription.correcteur_id` et dans le journal.
      if (e.correcteur_id !== req.auth.userId) {
        throw Object.assign(
          new Error(
            estDirection(req)
              ? "Vous n'êtes pas le correcteur de cette épreuve. Attribuez-la-vous d'abord si vous devez la corriger vous-même."
              : "Cette épreuve ne vous est pas confiée."
          ),
          { statusCode: 403 }
        );
      }
      // Une note modifiée après publication fausserait un classement déjà
      // annoncé aux familles. Il faut dépublier, ce qui laisse une trace.
      if (e.session_statut === 'publiee') {
        throw Object.assign(
          new Error('Session publiée : les notes sont figées. Dépubliez la session pour corriger.'),
          { statusCode: 409 }
        );
      }

      const maximum = Number(e.maximum);

      // Validation complète AVANT écriture : soit tout passe, soit rien.
      const idsCandidats = notes.map((n) => n.candidat_id).filter(Boolean);
      const valides = await client.query(
        `SELECT id, numero_candidat FROM candidats WHERE session_id = $1 AND id = ANY($2::uuid[])`,
        [e.session_id, idsCandidats]
      );
      const numeroParId = Object.fromEntries(valides.rows.map((c) => [c.id, c.numero_candidat]));

      for (const n of notes) {
        if (!numeroParId[n.candidat_id]) {
          throw Object.assign(
            new Error("Un des candidats n'appartient pas à cette session (rechargez la page)."),
            { statusCode: 400 }
          );
        }
        const brut = n.points;
        if (brut === null || brut === undefined || brut === '') continue;
        const points = Number(brut);
        if (!Number.isFinite(points) || points < 0 || points > maximum) {
          throw Object.assign(
            new Error(`Note invalide pour ${numeroParId[n.candidat_id]} : « ${brut} » — doit être comprise entre 0 et ${maximum}.`),
            { statusCode: 400 }
          );
        }
      }

      let saisies = 0;
      for (const n of notes) {
        const brut = n.points;
        const points = (brut === null || brut === undefined || brut === '') ? null : Number(brut);
        await client.query(
          `INSERT INTO notes_candidats (ecole_id, epreuve_id, candidat_id, points, saisi_par)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4)
           ON CONFLICT (epreuve_id, candidat_id)
           DO UPDATE SET points = EXCLUDED.points, saisi_par = EXCLUDED.saisi_par, updated_at = now()`,
          [epreuveId, n.candidat_id, points, req.auth.userId]
        );
        if (points !== null) saisies++;
      }
      return saisies;
    });

    return res.json({ message: `${bilan} note(s) enregistrée(s).` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement notes candidats:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Publication — c'est ici que se joue l'équité
   ========================================================================== */

/**
 * Calcule totaux, rangs et admissions. Fonction unique : le classement ne
 * doit jamais être établi ailleurs, sous peine de divergence.
 */
async function calculerClassement(client, sessionId) {
  const session = await chargerSession(client, sessionId);
  const places = Number(session.places);

  if (session.mode === 'direct') {
    // Sans test, l'ordre d'inscription fait foi : le premier arrivé est
    // le premier servi, et cela reste vérifiable.
    const r = await client.query(
      `SELECT id FROM candidats WHERE session_id = $1 ORDER BY created_at`,
      [sessionId]
    );
    for (let i = 0; i < r.rows.length; i++) {
      await client.query(
        `UPDATE candidats SET total = NULL, rang = $2,
                statut = CASE WHEN recommande THEN 'admis'
                              WHEN $2 <= $3 THEN 'admis' ELSE 'liste_attente' END
         WHERE id = $1`,
        [r.rows[i].id, i + 1, places]
      );
    }
    return { places, note_plancher: null, nb_admis: Math.min(r.rows.length, places) };
  }

  // ---------- Mode test ----------
  const totaux = await client.query(
    `SELECT k.id, k.recommande,
            SUM(COALESCE(n.points, 0)) AS total,
            count(n.points) AS nb_notes
     FROM candidats k
     LEFT JOIN notes_candidats n ON n.candidat_id = k.id
     WHERE k.session_id = $1
     GROUP BY k.id, k.recommande
     ORDER BY SUM(COALESCE(n.points, 0)) DESC, k.numero_candidat`,
    [sessionId]
  );

  const lignes = totaux.rows.map((l) => ({
    id: l.id,
    recommande: l.recommande === true,
    total: Number(l.total),
    absent: Number(l.nb_notes) === 0
  }));

  // Un candidat absent au test n'entre pas dans le classement : lui donner
  // le rang de sa note nulle le placerait devant des présents plus faibles
  // en cas d'égalité, ce qui serait absurde.
  const presents = lignes.filter((l) => !l.absent);
  const absents = lignes.filter((l) => l.absent);

  const notePlancher = presents.length >= places ? presents[places - 1].total : null;

  for (let i = 0; i < presents.length; i++) {
    const l = presents[i];
    const rang = i + 1;
    // Admis de droit : dans la limite des places. L'égalité sur la note
    // plancher est traitée à part, par décision explicite de la direction.
    const admisDeDroit = rang <= places;
    await client.query(
      `UPDATE candidats SET total = $2, rang = $3,
              statut = CASE WHEN $4 OR recommande THEN 'admis' ELSE 'liste_attente' END
       WHERE id = $1 AND statut <> 'desiste'`,
      [l.id, l.total, rang, admisDeDroit]
    );
  }
  for (const l of absents) {
    await client.query(
      `UPDATE candidats SET total = NULL, rang = NULL, statut = 'absent' WHERE id = $1 AND statut <> 'desiste'`,
      [l.id]
    );
  }

  const nbExAequo = notePlancher !== null
    ? presents.filter((l) => l.total === notePlancher).length : 0;

  return {
    places,
    note_plancher: notePlancher,
    nb_presents: presents.length,
    nb_absents: absents.length,
    nb_ex_aequo_plancher: nbExAequo
  };
}

/** POST /inscriptions/sessions/:id/publier */
async function publierSession(req, res) {
  const { id } = req.params;
  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, id);
      if (session.statut === 'publiee') {
        throw Object.assign(new Error('Cette session est déjà publiée.'), { statusCode: 409 });
      }

      if (session.mode === 'test') {
        // Publier avec des copies non corrigées produirait un classement faux
        // et définitif : on refuse tant que tout n'est pas saisi.
        const manquantes = await client.query(
          `SELECT e.nom, count(*) AS nb
           FROM epreuves_inscription e
           JOIN candidats k ON k.session_id = e.session_id
           LEFT JOIN notes_candidats n ON n.epreuve_id = e.id AND n.candidat_id = k.id
           WHERE e.session_id = $1 AND n.points IS NULL
           GROUP BY e.nom`,
          [id]
        );
        if (manquantes.rows.length > 0) {
          const detail = manquantes.rows
            .map((m) => `${m.nom} (${m.nb} copie(s))`).join(', ');
          throw Object.assign(
            new Error(`Correction incomplète : ${detail}. Saisissez toutes les notes, ou marquez les absents à 0.`),
            { statusCode: 409 }
          );
        }
      }

      const resultat = await calculerClassement(client, id);

      await client.query(
        `UPDATE sessions_inscription SET statut = 'publiee', publie_par = $1, publie_at = now()
         WHERE id = $2 AND ecole_id = ${CURRENT_ECOLE}`,
        [req.auth.userId, id]
      );

      // Certaines écoles inscrivent sur-le-champ, d'autres attendent le
      // dossier complet : le réglage tranche, pas le code.
      const reglage = await client.query(
        `SELECT COALESCE(conversion_admis_auto, false) AS auto FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      let convertis = 0;
      if (reglage.rows[0].auto === true && (session.classes_cibles || []).length > 0) {
        const sessionPubliee = await chargerSession(client, id);
        convertis = await convertirAdmisInterne(client, sessionPubliee, req.auth.userId, null);
      }

      return { ...resultat, convertis };
    });

    let message = `Résultats publiés : ${bilan.places} place(s) attribuée(s).`;
    if (bilan.nb_ex_aequo_plancher > 1) {
      message += ` Attention : ${bilan.nb_ex_aequo_plancher} candidats sont à égalité sur la note plancher (${bilan.note_plancher}). Tranchez entre eux depuis la liste.`;
    }
    if (bilan.nb_absents > 0) {
      message += ` ${bilan.nb_absents} candidat(s) absent(s) au test.`;
    }
    if (bilan.convertis > 0) {
      message += ` ${bilan.convertis} admis inscrit(s) automatiquement comme élève(s).`;
    }
    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur publication session:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /inscriptions/candidats/:id/decision
 * body : { action: 'recommander' | 'retirer_recommandation' | 'refuser', motif }
 *
 * C'est la fonction la plus sensible du module. Elle refuse structurellement
 * de retirer un candidat admis de droit.
 */
async function deciderCandidat(req, res) {
  const { id } = req.params;
  const { action, motif } = req.body;

  if (!['recommander', 'retirer_recommandation', 'refuser'].includes(action)) {
    return res.status(400).json({ message: 'Action inconnue.' });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT k.id, k.numero_candidat, k.nom, k.postnom, k.prenom, k.total, k.rang,
                k.statut::text, k.recommande, k.session_id
         FROM candidats k WHERE k.id = $1 AND k.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Candidat introuvable.'), { statusCode: 404 });
      }
      const candidat = r.rows[0];
      const session = await chargerSession(client, candidat.session_id);

      if (session.statut !== 'publiee') {
        throw Object.assign(
          new Error("Les décisions ne se prennent qu'après publication des résultats."),
          { statusCode: 409 }
        );
      }

      if (action === 'refuser') {
        // ------ La règle d'équité, appliquée par le serveur ------
        const places = Number(session.places);
        const classement = await client.query(
          `SELECT total FROM candidats
           WHERE session_id = $1 AND statut <> 'absent' AND total IS NOT NULL
           ORDER BY total DESC, numero_candidat`,
          [candidat.session_id]
        );
        const notePlancher = classement.rows.length >= places
          ? Number(classement.rows[places - 1].total) : null;

        if (candidat.total !== null && notePlancher !== null && Number(candidat.total) > notePlancher) {
          throw Object.assign(
            new Error(
              `Refus impossible : ${nomComplet(candidat)} a obtenu ${Number(candidat.total)} points, `
              + `au-dessus de la note plancher de ${notePlancher}. Ce candidat est admis de droit — `
              + `aucun rôle ne permet de le retirer au profit d'un autre.`
            ),
            { statusCode: 403 }
          );
        }

        await client.query(
          `UPDATE candidats SET statut = 'refuse', recommande = false,
                  motif_recommandation = $2, decide_par = $3, decide_at = now()
           WHERE id = $1`,
          [id, (motif || '').trim() || null, req.auth.userId]
        );
        return `${nomComplet(candidat)} écarté.`;
      }

      if (action === 'recommander') {
        if (!motif || !String(motif).trim()) {
          throw Object.assign(
            new Error('Une recommandation exige un motif écrit : il figurera au registre.'),
            { statusCode: 400 }
          );
        }
        await client.query(
          `UPDATE candidats SET recommande = true, statut = 'admis',
                  motif_recommandation = $2, decide_par = $3, decide_at = now()
           WHERE id = $1`,
          [id, String(motif).trim(), req.auth.userId]
        );
        return `${nomComplet(candidat)} admis par recommandation. La décision est enregistrée à votre nom.`;
      }

      await client.query(
        `UPDATE candidats SET recommande = false, motif_recommandation = NULL,
                decide_par = $2, decide_at = now()
         WHERE id = $1`,
        [id, req.auth.userId]
      );
      await calculerClassement(client, candidat.session_id);
      return `Recommandation retirée pour ${nomComplet(candidat)}.`;
    });

    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur décision candidat:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /inscriptions/candidats/:id/desister
 * Libère la place et repêche automatiquement le premier de la liste d'attente.
 */
async function desisterCandidat(req, res) {
  const { id } = req.params;
  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT id, session_id, nom, postnom, prenom, statut::text
         FROM candidats WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Candidat introuvable.'), { statusCode: 404 });
      }
      const candidat = r.rows[0];
      if (candidat.statut !== 'admis') {
        throw Object.assign(new Error('Seul un candidat admis peut se désister.'), { statusCode: 409 });
      }

      await client.query(
        `UPDATE candidats SET statut = 'desiste', decide_par = $2, decide_at = now() WHERE id = $1`,
        [id, req.auth.userId]
      );

      // Repêchage : le meilleur de la liste d'attente prend la place, dans
      // l'ordre du classement. Personne ne choisit qui monte.
      const suivant = await client.query(
        `SELECT id, numero_candidat, nom, postnom, prenom FROM candidats
         WHERE session_id = $1 AND statut = 'liste_attente'
         ORDER BY rang NULLS LAST, total DESC NULLS LAST, numero_candidat
         LIMIT 1`,
        [candidat.session_id]
      );

      if (suivant.rows.length === 0) {
        return `${nomComplet(candidat)} désisté. Aucun candidat en liste d'attente pour le remplacer.`;
      }

      await client.query(
        `UPDATE candidats SET statut = 'admis', decide_par = $2, decide_at = now() WHERE id = $1`,
        [suivant.rows[0].id, req.auth.userId]
      );
      return `${nomComplet(candidat)} désisté. ${nomComplet(suivant.rows[0])} est repêché depuis la liste d'attente.`;
    });

    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur désistement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /inscriptions/sessions/:id/convertir
 * Transforme les admis en élèves. Selon le paramètre de l'école, cette étape
 * est automatique à l'admission ou déclenchée après confirmation du dossier.
 */
/**
 * Crée les élèves à partir des candidats admis. Extraite pour être appelée
 * aussi bien manuellement qu'automatiquement à la publication, selon le
 * réglage de l'école — un seul chemin d'écriture, une seule règle.
 */
async function convertirAdmisInterne(client, session, utilisateurId, candidatIds) {
  const classes = session.classes_cibles || [];
  if (classes.length === 0) {
    throw Object.assign(
      new Error("Cette session n'a aucune classe d'accueil. Renseignez la promotion qui recrute avant la conversion."),
      { statusCode: 409 }
    );
  }

  // Dernier rempart avant d'inscrire quelqu'un. Les contrôles de création et
  // de modification devraient l'avoir rendu inutile — mais une session créée
  // AVANT la migration 015, ou une classe déplacée d'année depuis, passerait
  // au travers. Or c'est ici que la faute devient irréversible : un élève est
  // créé dans une classe, et le défaire suppose de le supprimer.
  const incoherentes = classes.filter((c) => c.annee_incoherente);
  if (incoherentes.length > 0) {
    throw Object.assign(
      new Error(
        `Conversion interrompue : ${incoherentes.map((c) => c.nom).join(', ')} `
        + `n'appartien${incoherentes.length > 1 ? 'nent' : 't'} pas à l'année d'entrée `
        + `${session.annee_cible ? session.annee_cible.libelle : 'de la session'}. `
        + `Corrigez les classes d'accueil de la session avant de convertir : `
        + `sans cela, ces élèves entreraient au milieu d'une année déjà commencée.`
      ),
      { statusCode: 409 }
    );
  }

  // Une année clôturée ne reçoit plus personne.
  if (session.annee_cible && session.annee_cible.cloturee) {
    throw Object.assign(
      new Error(`L'année ${session.annee_cible.libelle} est clôturée : aucune inscription n'y est plus possible.`),
      { statusCode: 409 }
    );
  }

  // Répartition sur les classes de la promotion, la moins remplie d'abord.
  //
  // `effectif` compte les élèves DÉJÀ dans la classe de l'année d'accueil —
  // c'est-à-dire ceux que la promotion interne y a fait monter. Les candidats
  // extérieurs se placent après eux, dans ce qui reste. C'est l'enchaînement
  // réel d'une rentrée : la promotion sortante libère, la promotion montante
  // occupe, le concours comble.
  //
  // Une capacité absente vaut « sans limite » : mieux vaut une classe un peu
  // chargée qu'un admis sans affectation.
  const places = classes.map((c) => ({ ...c, occupe: c.effectif }));
  function prochaineClasse() {
    const libres = places
      .filter((p) => p.capacite === null || p.occupe < p.capacite)
      .sort((a, b) => a.occupe - b.occupe);
    // Toutes pleines : on continue quand même, sur la moins chargée, plutôt
    // que de laisser un élève admis sans classe.
    return libres[0] || [...places].sort((a, b) => a.occupe - b.occupe)[0];
  }

  const admis = await client.query(
    `SELECT id, nom, postnom, prenom, sexe, date_naissance,
            responsable_nom, responsable_telephone, responsable_email
     FROM candidats
     WHERE session_id = $1 AND statut = 'admis' AND eleve_id IS NULL
       AND ($2::uuid[] IS NULL OR id = ANY($2::uuid[]))
     ORDER BY rang NULLS LAST`,
    [session.id, Array.isArray(candidatIds) && candidatIds.length ? candidatIds : null]
  );

  let crees = 0;
  for (const c of admis.rows) {
    const suivant = await client.query(
      `SELECT COALESCE(max(NULLIF(regexp_replace(matricule, '\\D', '', 'g'), '')::int), 0) + 1 AS n
       FROM eleves WHERE ecole_id = ${CURRENT_ECOLE}`
    );
    const matricule = `ELV-${String(suivant.rows[0].n).padStart(4, '0')}`;

    const cible = prochaineClasse();
    cible.occupe++;

    const eleve = await client.query(
      `INSERT INTO eleves (ecole_id, matricule, nom, postnom, prenom, sexe, date_naissance,
                           responsable_nom, responsable_telephone, responsable_email,
                           classe_id, statut)
       VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'actif')
       RETURNING id`,
      [matricule, c.nom, c.postnom, c.prenom, c.sexe, c.date_naissance,
       c.responsable_nom, c.responsable_telephone, c.responsable_email,
       cible.id]
    );

    await client.query(
      `UPDATE candidats SET statut = 'converti', eleve_id = $2 WHERE id = $1`,
      [c.id, eleve.rows[0].id]
    );
    crees++;
  }
  return crees;
}

async function convertirAdmis(req, res) {
  const { id } = req.params;
  const { candidat_ids } = req.body;   // facultatif : conversion sélective

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, id);
      if (session.statut !== 'publiee') {
        throw Object.assign(new Error('Publiez les résultats avant de convertir les admis.'), { statusCode: 409 });
      }
      const crees = await convertirAdmisInterne(client, session, req.auth.userId, candidat_ids);
      return { crees, classe: session.classe_nom };
    });

    return res.json({
      message: bilan.crees === 0
        ? 'Aucun admis à convertir : ils le sont déjà tous.'
        : `${bilan.crees} élève(s) créé(s) en ${bilan.classe}.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur conversion admis:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /inscriptions/sessions/:sessionId/resultats?filtre=&recherche=
 *
 * Vue « résultats du test » : le classement complet, le détail par épreuve, et
 * de quoi répondre aux questions qu'une école se pose vraiment après un
 * concours — combien d'admis, qui est juste sous la barre, qui a échoué dans
 * une seule matière.
 *
 * La liste des candidats existante répond à « qui s'est inscrit ». Elle ne
 * répondait pas à « qui a réussi » : ni notes par épreuve, ni filtres, ni
 * repères de lecture.
 *
 * `filtre` : tous | admis | liste_attente | refuses | absents | recommandes
 */
async function resultatsSession(req, res) {
  const { sessionId } = req.params;
  const filtre = req.query.filtre || 'tous';
  const recherche = (req.query.recherche || '').trim();

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const session = await chargerSession(client, sessionId);

      // Le scellé vaut ici comme ailleurs : avant publication, aucun résultat
      // ne sort, pas même à la direction. Même règle que la liste des
      // candidats, et sans exception.
      if (session.statut !== 'publiee') {
        throw Object.assign(
          new Error("Les résultats ne sont consultables qu'après publication de la session."),
          { statusCode: 409 }
        );
      }

      const epreuves = await client.query(
        `SELECT id, nom, maximum, ordre FROM epreuves_inscription
         WHERE session_id = $1 AND ecole_id = ${CURRENT_ECOLE}
         ORDER BY ordre, nom`,
        [sessionId]
      );
      const maximumTotal = epreuves.rows.reduce((somme, e) => somme + Number(e.maximum), 0);

      const candidats = await client.query(
        `SELECT k.id, k.numero_candidat, k.nom, k.postnom, k.prenom, k.sexe,
                k.ecole_provenance, k.statut::text, k.total, k.rang,
                k.recommande, k.motif_recommandation, k.eleve_id,
                trim(concat(u.prenom, ' ', u.nom)) AS decide_par_nom,
                COALESCE(
                  jsonb_object_agg(n.epreuve_id, n.points) FILTER (WHERE n.epreuve_id IS NOT NULL),
                  '{}'::jsonb
                ) AS notes
         FROM candidats k
         LEFT JOIN utilisateurs u ON u.id = k.decide_par
         LEFT JOIN notes_candidats n ON n.candidat_id = k.id
         WHERE k.session_id = $1 AND k.ecole_id = ${CURRENT_ECOLE}
         GROUP BY k.id, u.prenom, u.nom
         ORDER BY k.rang NULLS LAST, k.total DESC NULLS LAST, k.nom`,
        [sessionId]
      );

      const places = Number(session.places);

      // Note plancher : celle du dernier candidat dans les places. C'est elle
      // qui rend lisible la frontière entre admis et liste d'attente — et qui
      // justifie qu'un refus au-dessus d'elle soit refusé par le serveur.
      const classes = candidats.rows
        .filter((k) => k.statut !== 'absent' && k.total !== null)
        .map((k) => Number(k.total));
      const notePlancher = classes.length >= places ? classes[places - 1] : null;

      const lignes = candidats.rows.map((k) => {
        const total = k.total === null ? null : Number(k.total);
        const notes = {};
        let epreuvesEchouees = 0;
        for (const e of epreuves.rows) {
          const brut = k.notes ? k.notes[e.id] : null;
          const points = brut === null || brut === undefined ? null : Number(brut);
          notes[e.id] = points;
          // « Échouée » = sous la moitié du maximum de l'épreuve. Repère usuel,
          // et surtout révélateur du candidat au bon total général mais
          // effondré dans une matière — cas que le seul classement masque.
          if (points !== null && points < Number(e.maximum) / 2) epreuvesEchouees++;
        }
        return {
          id: k.id,
          numero_candidat: k.numero_candidat,
          nom_complet: nomComplet(k),
          sexe: k.sexe,
          ecole_provenance: k.ecole_provenance,
          statut: k.statut,
          recommande: k.recommande === true,
          motif_recommandation: k.motif_recommandation,
          decide_par_nom: k.decide_par_nom,
          deja_eleve: !!k.eleve_id,
          rang: k.rang,
          total,
          pourcentage: total !== null && maximumTotal > 0
            ? Math.round((total / maximumTotal) * 1000) / 10
            : null,
          notes,
          epreuves_echouees: epreuvesEchouees,
          // Juste sous la barre : ceux dont l'école doit se souvenir au premier
          // désistement.
          sous_la_barre: notePlancher !== null && total !== null
            && total < notePlancher && k.statut !== 'admis'
        };
      });

      const correspond = (l) => {
        if (recherche) {
          const cible = `${l.nom_complet} ${l.numero_candidat} ${l.ecole_provenance || ''}`.toLowerCase();
          if (!cible.includes(recherche.toLowerCase())) return false;
        }
        switch (filtre) {
          case 'admis': return l.statut === 'admis' || l.statut === 'converti';
          case 'liste_attente': return l.statut === 'liste_attente';
          case 'refuses': return l.statut === 'refuse';
          case 'absents': return l.statut === 'absent';
          case 'recommandes': return l.recommande;
          default: return true;
        }
      };

      const totaux = lignes.filter((l) => l.statut !== 'absent' && l.total !== null).map((l) => l.total);
      const admis = lignes.filter((l) => l.statut === 'admis' || l.statut === 'converti');

      return {
        session: {
          id: session.id, libelle: session.libelle, statut: session.statut,
          places, date_test: session.date_test, publie_at: session.publie_at
        },
        epreuves: epreuves.rows.map((e) => ({ ...e, maximum: Number(e.maximum) })),
        maximum_total: maximumTotal,
        note_plancher: notePlancher,
        statistiques: {
          inscrits: lignes.length,
          presents: lignes.filter((l) => l.statut !== 'absent').length,
          absents: lignes.filter((l) => l.statut === 'absent').length,
          admis: admis.length,
          liste_attente: lignes.filter((l) => l.statut === 'liste_attente').length,
          refuses: lignes.filter((l) => l.statut === 'refuse').length,
          recommandes: lignes.filter((l) => l.recommande).length,
          convertis: lignes.filter((l) => l.deja_eleve).length,
          // Moyenne des PRÉSENTS seulement : compter les absents à 0 ferait
          // chuter la moyenne sans rien dire du niveau des candidats.
          moyenne: totaux.length
            ? Math.round((totaux.reduce((a, b) => a + b, 0) / totaux.length) * 10) / 10
            : null,
          meilleur: totaux.length ? Math.max(...totaux) : null
        },
        filtre,
        resultats: lignes.filter(correspond)
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur résultats session:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


module.exports = {
  listerSessions, creerSession, modifierSession,
  listerEpreuves, creerEpreuve, assignerCorrecteur,
  listerCandidats, inscrireCandidat,
  mesCorrections, copiesEpreuve, enregistrerNotes,
  publierSession, deciderCandidat, desisterCandidat, convertirAdmis,
  resultatsSession
};
