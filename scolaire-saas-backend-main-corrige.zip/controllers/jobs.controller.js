const { runWithTenant } = require('../config/db');
const { creerEtEnvoyerNotification, notifier, notifierPlusieurs, utilisateursAvecRole } = require('../utils/notification.utils');
const {
  notifierEvenement, destinatairesParRole, viderFile
} = require('../utils/notifications.service');

/**
 * POST /jobs/abonnements
 * Protégé par un secret partagé (header x-cron-secret), pas par JWT,
 * pour pouvoir être appelé directement par cron-job.org — même principe
 * que la détection de no-show sur Enviro Cleans.
 *
 * Logique exécutée une fois par jour :
 *  - J-7 avant expiration  -> email de rappel au Directeur
 *  - J-1 avant expiration  -> email de rappel au Directeur
 *  - Date d'expiration atteinte -> statut = 'expire' + email
 *  - Délai de grâce dépassé après expiration -> statut = 'suspendu' + école suspendue + email
 */
async function executerJobAbonnements(req, res) {
  const secretRecu = req.headers['x-cron-secret'];
  if (!secretRecu || secretRecu !== process.env.CRON_SECRET) {
    return res.status(403).json({ message: 'Non autorisé.' });
  }

  try {
    const resultat = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const abonnements = await client.query(`
        SELECT a.id, a.ecole_id, a.statut, a.date_expiration, a.delai_grace_jours,
               e.nom AS ecole_nom
        FROM abonnements a
        JOIN ecoles e ON e.id = a.ecole_id
        WHERE a.statut IN ('actif', 'expire')
      `);

      const bilan = { rappels_j7: 0, rappels_j1: 0, passes_en_expire: 0, passes_en_suspendu: 0 };
      const maintenant = new Date();

      for (const abonnement of abonnements.rows) {
        const expiration = new Date(abonnement.date_expiration);
        const joursRestants = Math.ceil((expiration - maintenant) / (1000 * 60 * 60 * 24));

        if (abonnement.statut === 'actif' && joursRestants === 7) {
          const traite = await creerEtEnvoyerNotification(client, {
            ecoleId: abonnement.ecole_id,
            sujet: 'rappel_expiration_j7',
            titre: `${abonnement.ecole_nom} — Abonnement : expiration dans 7 jours`,
            contenu: "Votre abonnement expire dans 7 jours. Pensez à renouveler pour éviter toute interruption de service."
          });
          if (traite) bilan.rappels_j7++;
        }

        if (abonnement.statut === 'actif' && joursRestants === 1) {
          const traite = await creerEtEnvoyerNotification(client, {
            ecoleId: abonnement.ecole_id,
            sujet: 'rappel_expiration_j1',
            titre: `${abonnement.ecole_nom} — Abonnement : expiration demain`,
            contenu: "Votre abonnement expire demain. Renouvelez dès maintenant pour éviter toute interruption de service."
          });
          if (traite) bilan.rappels_j1++;
        }

        if (abonnement.statut === 'actif' && joursRestants <= 0) {
          await client.query(
            `UPDATE abonnements SET statut = 'expire', updated_at = now() WHERE id = $1`,
            [abonnement.id]
          );
          await client.query(
            `INSERT INTO journal_activite (ecole_id, action, cible_type, cible_id)
             VALUES ($1, 'abonnement.expire', 'abonnement', $2)`,
            [abonnement.ecole_id, abonnement.id]
          );
          await creerEtEnvoyerNotification(client, {
            ecoleId: abonnement.ecole_id,
            sujet: 'abonnement_expire',
            titre: `${abonnement.ecole_nom} — Abonnement expiré`,
            contenu: "Votre abonnement a expiré. Merci de régulariser le paiement pour éviter la suspension de l'accès."
          });
          bilan.passes_en_expire++;
        }

        if (abonnement.statut === 'expire') {
          const limiteGrace = new Date(expiration.getTime() + abonnement.delai_grace_jours * 24 * 60 * 60 * 1000);
          if (maintenant > limiteGrace) {
            await client.query(
              `UPDATE abonnements SET statut = 'suspendu', updated_at = now() WHERE id = $1`,
              [abonnement.id]
            );
            await client.query(`UPDATE ecoles SET statut = 'suspendu' WHERE id = $1`, [abonnement.ecole_id]);
            await client.query(
              `INSERT INTO journal_activite (ecole_id, action, cible_type, cible_id)
               VALUES ($1, 'ecole.suspendue', 'ecole', $2)`,
              [abonnement.ecole_id, abonnement.ecole_id]
            );
            await creerEtEnvoyerNotification(client, {
              ecoleId: abonnement.ecole_id,
              sujet: 'ecole_suspendue',
              titre: `${abonnement.ecole_nom} — Accès suspendu`,
              contenu: "L'accès de votre école a été suspendu suite à un impayé au-delà du délai de grâce. Contactez-nous pour régulariser."
            });
            bilan.passes_en_suspendu++;
          }
        }
      }

      return bilan;
    });

    // Des abonnements viennent de passer en « expiré » ou « suspendu ».
    // Sans cette ligne, le catalogue continue pendant une minute à accorder
    // les droits d'un abonnement qui n'existe plus. Une minute n'est pas grave
    // ici — le job tourne la nuit — mais l'oubli le serait le jour où il sera
    // déclenché à la main après une relance de paiement.
    require('../utils/catalogue.utils').invaliderCache();

    return res.json({ message: 'Job abonnements exécuté.', bilan: resultat });
  } catch (err) {
    console.error('Erreur job abonnements:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /jobs/calendrier
 *
 * Rappels quotidiens fondés sur le calendrier scolaire. Même protection que le
 * job des abonnements : secret partagé plutôt que JWT, pour être appelable
 * directement par un planificateur externe.
 *
 * Deux rappels, tous deux dédupliqués par `cle_unicite` : la tâche peut tourner
 * chaque jour sans jamais republier le même message. Sans cette clé,
 * l'utilisateur recevrait le même rappel quotidiennement jusqu'à ce qu'il
 * agisse, et finirait par ignorer toutes ses notifications.
 *
 *   1. Une période se termine dans ≤ 7 jours
 *        → direction (directeur, préfet) : « pensez à clôturer »
 *   2. Une période se termine dans ≤ 7 jours et un professeur n'a pas soumis
 *        → ce professeur, nommément : « déposez vos notes »
 */
async function executerJobCalendrier(req, res) {
  const secretRecu = req.headers['x-cron-secret'];
  if (!secretRecu || secretRecu !== process.env.CRON_SECRET) {
    return res.status(403).json({ message: 'Non autorisé.' });
  }

  try {
    const bilan = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecoles = await client.query(
        `SELECT id, nom FROM ecoles WHERE statut = 'actif'`
      );

      let rappelsDirection = 0;
      let rappelsProfesseurs = 0;

      for (const ecole of ecoles.rows) {
        // Le contexte tenant est posé école par école : les utilitaires
        // (notifier, utilisateursAvecRole) s'appuient sur app.current_ecole_id,
        // et sans ce SET ils viseraient la mauvaise école — ou aucune.
        await client.query(`SET LOCAL app.current_ecole_id = '${ecole.id}'`);

        const periodes = await client.query(
          `SELECT p.id, p.libelle, p.type::text AS type, p.date_fin,
                  (p.date_fin - CURRENT_DATE) AS jours_restants
             FROM periodes p
             JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
            WHERE p.ecole_id = $1 AND a.active = true AND a.cloturee = false
              AND p.date_fin IS NOT NULL
              AND p.date_fin BETWEEN CURRENT_DATE AND (CURRENT_DATE + 7)`,
          [ecole.id]
        );

        for (const periode of periodes.rows) {
          const jours = Number(periode.jours_restants);
          const quand = jours === 0 ? "aujourd'hui" : jours === 1 ? 'demain' : `dans ${jours} jours`;

          // ---- 1. Direction : clôturer la période ----
          const direction = await utilisateursAvecRole(client, ['directeur', 'prefet']);
          rappelsDirection += await notifierPlusieurs(client, direction, {
            sujet: `Fin de « ${periode.libelle} » ${quand}`,
            contenu: `La période « ${periode.libelle} » se termine le ${new Date(periode.date_fin).toLocaleDateString('fr-FR')}. `
                   + `Pensez à vérifier que toutes les notes sont soumises, puis à clôturer la période.`,
            lien: '/annee-scolaire.html',
            cleUnicite: `periode_fin:${periode.id}`
          });

          // ---- 2. Professeurs n'ayant pas soumis ----
          // Un cours est considéré non soumis si AUCUNE note validée n'existe
          // pour ce classe_cours sur cette période. On vise le professeur
          // assigné, pas la direction : c'est lui qui doit agir.
          const enRetard = await client.query(
            `SELECT DISTINCT ec.utilisateur_id, c.nom AS cours_nom, cl.nom AS classe_nom
               FROM enseignant_cours ec
               JOIN classe_cours cc ON cc.id = ec.classe_cours_id
               JOIN cours c ON c.id = cc.cours_id
               JOIN classes cl ON cl.id = cc.classe_id
               JOIN utilisateurs u ON u.id = ec.utilisateur_id
              WHERE ec.ecole_id = $1 AND u.statut = 'actif'
                AND NOT EXISTS (
                  SELECT 1 FROM notes n
                   WHERE n.classe_cours_id = cc.id
                     AND n.periode_id = $2
                     AND n.valide = true
                )`,
            [ecole.id, periode.id]
          );

          for (const ligne of enRetard.rows) {
            const cree = await notifier(client, {
              utilisateurId: ligne.utilisateur_id,
              sujet: `Notes à soumettre — ${ligne.cours_nom} (${ligne.classe_nom})`,
              contenu: `La période « ${periode.libelle} » se termine ${quand}. `
                     + `Les notes de ${ligne.cours_nom} en ${ligne.classe_nom} ne sont pas encore soumises.`,
              lien: '/notes.html',
              // La clé inclut le cours ET la classe : un professeur qui a trois
              // cours en retard doit recevoir trois rappels distincts, sinon il
              // en corrigerait un seul en croyant avoir tout traité.
              cleUnicite: `notes_non_soumises:${periode.id}:${ligne.cours_nom}:${ligne.classe_nom}`
            });
            if (cree) rappelsProfesseurs++;
          }
        }
      }

      return { ecoles: ecoles.rows.length, rappelsDirection, rappelsProfesseurs };
    });

    return res.json({
      message: `Rappels calendrier : ${bilan.rappelsDirection} à la direction, `
             + `${bilan.rappelsProfesseurs} aux professeurs (${bilan.ecoles} école(s) parcourue(s)).`,
      ...bilan
    });
  } catch (err) {
    console.error('Erreur job calendrier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ===========================================================================
   RAPPELS D'ÉVÉNEMENTS DU CALENDRIER
   =========================================================================== */

/**
 * Quand rappeler un événement.
 *
 * Trois échéances, pas plus. Un rappel quotidien pendant deux semaines n'est
 * pas trois fois plus efficace : il est ignoré. Chaque échéance répond à une
 * question différente —
 *   J-7  : « ai-je le temps de m'organiser ? »   (réserver, préparer, prévenir)
 *   J-1  : « est-ce que je n'oublie pas ? »       (dernier ajustement)
 *   J-0  : « c'est aujourd'hui »                  (le matin même)
 *
 * `canal: 'interne'` à J-7 : sept jours à l'avance, la plateforme suffit.
 * L'e-mail est réservé à J-1 et au jour même, quand ne pas savoir a une
 * conséquence.
 */
const ECHEANCES_RAPPEL = [
  { jours: 7, quand: 'j7',         canal: 'interne' },
  { jours: 1, quand: 'demain',     canal: 'email'   },
  { jours: 0, quand: 'aujourdhui', canal: 'email'   }
];

/**
 * Ce que chaque type d'événement demande de préparer, et qui est concerné.
 *
 * Un « examen » ne s'adresse pas aux mêmes personnes qu'une « réunion » :
 * envoyer tout à tout le monde est la façon la plus sûre de faire désactiver
 * les notifications. La consigne, elle, transforme un rappel en action —
 * « Examens dans 7 jours » n'appelle rien, « préparez et déposez vos sujets »
 * si.
 */
const PROFIL_EVENEMENT = {
  debut_cours: {
    libelle: 'Rentrée',
    roles: ['directeur', 'prefet', 'secretaire', 'professeur', 'titulaire', 'charge_presences'],
    consigne: "Vérifiez que les classes, les affectations de cours et les emplois du temps sont en place."
  },
  examen: {
    libelle: 'Session d\'examens',
    roles: ['directeur', 'prefet', 'professeur', 'titulaire'],
    consigne: "Préparez vos épreuves et vérifiez les maximums de points de vos cours."
  },
  depot_resultats: {
    libelle: 'Dépôt des résultats',
    roles: ['directeur', 'prefet', 'professeur', 'titulaire'],
    consigne: "Saisissez et soumettez vos cotes : après clôture de la période, elles ne seront plus modifiables."
  },
  conseil_classe: {
    libelle: 'Conseil de classe',
    roles: ['directeur', 'prefet', 'titulaire'],
    consigne: "Assurez-vous que toutes les notes sont soumises et les appréciations saisies."
  },
  proclamation: {
    libelle: 'Proclamation',
    roles: ['directeur', 'prefet', 'secretaire', 'titulaire'],
    consigne: "Vérifiez que les bulletins sont signés et imprimés."
  },
  vacances: {
    libelle: 'Vacances',
    roles: ['directeur', 'prefet', 'secretaire', 'professeur', 'titulaire', 'charge_presences'],
    consigne: null
  },
  reunion: {
    libelle: 'Réunion',
    roles: ['directeur', 'prefet', 'secretaire', 'professeur', 'titulaire'],
    consigne: null
  }
};

// Type inconnu (la base peut en gagner de nouveaux) : on prévient la direction
// plutôt que de ne rien envoyer. Un rappel de trop vaut mieux qu'un oubli.
const PROFIL_PAR_DEFAUT = {
  libelle: null,
  roles: ['directeur', 'prefet', 'secretaire'],
  consigne: null
};

/**
 * POST /jobs/evenements
 *
 * Rappels des événements inscrits au calendrier scolaire. Même protection que
 * les autres tâches : secret partagé, pas de JWT — un planificateur externe
 * n'a pas de session.
 *
 * À exécuter UNE FOIS PAR JOUR, tôt le matin. Chaque rappel est dédupliqué par
 * `cle_unicite` (événement + échéance + destinataire) : relancer la tâche
 * plusieurs fois dans la journée ne produit aucun doublon. C'est ce qui rend
 * l'opération sûre à réessayer, ce qu'un planificateur fait toujours en cas
 * de timeout réseau.
 */
async function executerJobEvenements(req, res) {
  const secretRecu = req.headers['x-cron-secret'];
  if (!secretRecu || secretRecu !== process.env.CRON_SECRET) {
    return res.status(403).json({ message: 'Non autorisé.' });
  }

  try {
    const bilan = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecoles = await client.query(
        `SELECT id, nom FROM ecoles WHERE statut = 'actif'`
      );

      let rappels = 0;
      let evenementsConcernes = 0;

      for (const ecole of ecoles.rows) {
        // Le contexte tenant est posé école par école : `notifierEvenement` et
        // `destinatairesParRole` lisent `app.current_ecole_id`. Sans ce SET,
        // ils viseraient la mauvaise école — ou aucune.
        await client.query(`SET LOCAL app.current_ecole_id = '${ecole.id}'`);

        for (const echeance of ECHEANCES_RAPPEL) {
          // Comparaison sur la DATE, pas sur l'horodatage : un événement à
          // 08 h et un autre à 19 h le même jour doivent tous deux tomber
          // dans la même échéance. Comparer des `timestamptz` ferait
          // dépendre le résultat de l'heure d'exécution de la tâche.
          const evenements = await client.query(
            `SELECT id, titre, type::text AS type, date_debut, date_fin
               FROM evenements_calendrier
              WHERE ecole_id = $1
                AND date_debut::date = (CURRENT_DATE + $2::int)
              ORDER BY date_debut`,
            [ecole.id, echeance.jours]
          );

          for (const evenement of evenements.rows) {
            const profil = PROFIL_EVENEMENT[evenement.type] || PROFIL_PAR_DEFAUT;
            const destinataires = await destinatairesParRole(client, profil.roles);
            if (destinataires.length === 0) continue;

            const crees = await notifierEvenement(client, {
              evenement: 'calendrier.rappel',
              destinataires,
              canal: echeance.canal,
              donnees: {
                titre: evenement.titre,
                typeLisible: profil.libelle,
                dateDebut: evenement.date_debut,
                dateFin: evenement.date_fin,
                consigne: profil.consigne,
                quand: echeance.quand,
                jours: echeance.jours,
                ecole: ecole.nom
              },
              // La clé porte l'échéance : le même événement doit pouvoir
              // rappeler à J-7 PUIS à J-1 PUIS le jour même. Sans elle, le
              // premier rappel bloquerait les deux suivants.
              cleUnicite: `evenement_rappel:${evenement.id}:${echeance.quand}`
            });

            if (crees > 0) {
              rappels += crees;
              evenementsConcernes++;
            }
          }
        }
      }

      return { ecoles: ecoles.rows.length, evenementsConcernes, rappels };
    });

    // Les e-mails partent après le COMMIT, jamais pendant : la boucle
    // ci-dessus écrit en file, elle n'appelle pas Resend.
    const envois = await viderFile({ limite: 200 });

    return res.json({
      message: `${bilan.rappels} rappel(s) créé(s) pour ${bilan.evenementsConcernes} événement(s) `
             + `sur ${bilan.ecoles} école(s). ${envois.envoyes} e-mail(s) envoyé(s).`,
      ...bilan,
      envois
    });
  } catch (err) {
    console.error('Erreur job événements:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ===========================================================================
   VIDAGE DE LA FILE D'ENVOI
   =========================================================================== */

/**
 * POST /jobs/notifications
 *
 * Le filet de sécurité de la file d'e-mails.
 *
 * En marche normale, chaque contrôleur appelle `planifierVidage()` après son
 * commit : l'e-mail part dans la seconde. Cette tâche existe pour tout ce que
 * ce mécanisme ne peut pas couvrir :
 *
 *   • le serveur a redémarré entre l'écriture et l'envoi ;
 *   • Resend était injoignable, ou a répondu 429 (quota dépassé) ;
 *   • l'adresse a rebondi temporairement (boîte pleine) ;
 *   • un processus est mort en plein envoi — la ligne restée « en_cours »
 *     depuis plus de 15 minutes est remise en file par `viderFile`.
 *
 * À programmer toutes les 5 à 10 minutes. Sans elle, un e-mail raté est un
 * e-mail perdu : personne ne le saurait, et le destinataire non plus.
 *
 * `limite` accepte un dépassement volontaire par le corps de requête, pour
 * rattraper une file accumulée après une panne longue.
 */
async function executerJobNotifications(req, res) {
  const secretRecu = req.headers['x-cron-secret'];
  if (!secretRecu || secretRecu !== process.env.CRON_SECRET) {
    return res.status(403).json({ message: 'Non autorisé.' });
  }

  try {
    const limite = Math.min(Math.max(Number(req.body?.limite) || 100, 1), 500);
    const bilan = await viderFile({ limite });

    // L'état de la file APRÈS vidage : c'est ce chiffre qui dit s'il faut
    // s'inquiéter. `abandonne` compte les e-mails définitivement perdus —
    // adresses invalides, clé d'API absente. Ils doivent être visibles, pas
    // silencieux.
    const etat = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(
        `SELECT statut, count(*)::int AS n
           FROM notifications
          WHERE canal = 'email'
            AND statut IN ('en_attente', 'echoue', 'en_cours', 'abandonne')
            AND created_at > now() - interval '7 days'
          GROUP BY statut`
      )
    );

    const file = {};
    for (const ligne of etat.rows) file[ligne.statut] = ligne.n;

    return res.json({
      message: `${bilan.envoyes} e-mail(s) envoyé(s), ${bilan.echecs} échec(s) `
             + `sur ${bilan.traites} traité(s).`,
      ...bilan,
      file_restante: file
    });
  } catch (err) {
    console.error('Erreur job notifications:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  executerJobAbonnements,
  executerJobCalendrier,
  executerJobEvenements,
  executerJobNotifications
};