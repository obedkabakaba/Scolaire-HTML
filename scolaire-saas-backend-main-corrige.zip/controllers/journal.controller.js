const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { appelerIA, appelerIAJson, consommerQuota } = require('../utils/ia.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Journal d'activité — consultation
 * ---------------------------------------------------------------------------
 * Depuis la mise en place de `middleware/journal.middleware.js`, le journal
 * enregistre TOUTES les écritures de TOUS les utilisateurs. Le volume change
 * donc d'ordre de grandeur : une liste des 100 dernières lignes, sans
 * recherche, ne permet plus de retrouver quoi que ce soit.
 *
 * Ce contrôleur ajoute ce que réclame ce volume : une recherche libre, des
 * filtres par personne et par résultat, et une pagination. Sans eux,
 * l'exhaustivité rendrait le journal moins utile qu'avant, pas plus.
 */

const LIMITE_DEFAUT = 50;
const LIMITE_MAX = 200;

/**
 * Traduit les codes techniques en libellés lisibles. Le journal est lu par
 * un directeur : « eleve.cree » lui parle moins que « Élève créé ».
 *
 * Cette table couvre les entrées métier historiques ET le motif des entrées
 * automatiques (`ressource.verbe`). Un code non listé est renvoyé tel quel :
 * mieux vaut un code brut qu'une ligne masquée.
 */
const LIBELLES = {
  // Entrées métier écrites explicitement par les contrôleurs
  'notes.validees': 'Notes validées',
  'notes.devalidees': 'Notes déverrouillées',
  'eleve.cree': 'Élève créé',
  'eleve.supprime': 'Élève supprimé',
  'utilisateur.cree': 'Utilisateur créé',
  'ecole.creee': 'École créée',
  'ecole.suspendue': 'École suspendue',
  'abonnement.paiement_confirme': 'Paiement confirmé (manuel)',
  'abonnement.paiement_confirme_mobile_money': 'Paiement confirmé (Mobile Money)',
  'abonnement.expire': 'Abonnement expiré',
  // Entrées automatiques les plus fréquentes
  'session.login': 'Connexion',
  'session.logout': 'Déconnexion',
  'eleve.modifie': 'Élève modifié',
  'classe.cree': 'Classe créée',
  'classe.modifie': 'Classe modifiée',
  'classe.supprime': 'Classe supprimée',
  'note.cree': 'Notes enregistrées',
  'presence.cree': 'Appel enregistré',
  'discipline.incidents': 'Fait de discipline signalé',
  'discipline.conduite_appliquer': 'Conduite reportée sur les bulletins',
  'frais.cree': 'Frais enregistrés',
  'paiement.cree': 'Paiement enregistré',
  'orientation.repartir': 'Orientation répartie',
  'promotion.cree': 'Promotion exécutée',
  'emploi_du_temps.exceptions': 'Horaire exceptionnel modifié'
};

function libelleAction(code) {
  return LIBELLES[code] || code;
}

/**
 * Construit la clause WHERE commune à la liste et au comptage. Écrite une
 * seule fois : deux constructions parallèles finiraient par diverger, et la
 * pagination annoncerait alors un nombre de pages qui ne correspond à rien.
 */
function construireFiltres(req) {
  const { depuis, jusqu, action, cibleType, utilisateurId, resultat, source, recherche } = req.query;

  const conditions = [];
  const params = [];

  if (!req.auth.isSuperAdmin) {
    conditions.push(`j.ecole_id = ${CURRENT_ECOLE}`);
  } else if (req.query.ecoleId) {
    params.push(req.query.ecoleId);
    conditions.push(`j.ecole_id = $${params.length}::uuid`);
  }

  if (depuis) { params.push(depuis); conditions.push(`j.created_at >= $${params.length}::date`); }
  // `jusqu` est une date sans heure : sans le décalage d'un jour, filtrer
  // « jusqu'au 12 » exclurait tout ce qui s'est passé le 12 après minuit.
  if (jusqu) { params.push(jusqu); conditions.push(`j.created_at < ($${params.length}::date + interval '1 day')`); }
  if (action) { params.push(action); conditions.push(`j.action = $${params.length}`); }
  if (cibleType) { params.push(cibleType); conditions.push(`j.cible_type = $${params.length}`); }
  if (utilisateurId) { params.push(utilisateurId); conditions.push(`j.utilisateur_id = $${params.length}::uuid`); }

  if (resultat === 'echec') {
    conditions.push(`(j.metadata->>'reussite') = 'false'`);
  } else if (resultat === 'succes') {
    conditions.push(`(j.metadata->>'reussite') IS DISTINCT FROM 'false'`);
  }

  // Permet de revenir à la lecture d'avant : seulement les événements métier,
  // sans le détail technique de chaque requête.
  if (source === 'metier') {
    conditions.push(`(j.metadata->>'source') IS DISTINCT FROM 'automatique'`);
  } else if (source === 'automatique') {
    conditions.push(`(j.metadata->>'source') = 'automatique'`);
  }

  // Recherche libre : on cherche dans le code d'action, le type de cible, le
  // nom de la personne ET le contenu des métadonnées (chemin appelé, motif de
  // refus, données transmises). C'est ce dernier point qui rend la recherche
  // réellement utile — retrouver « qui a touché à ce matricule ».
  if (recherche && String(recherche).trim()) {
    params.push(`%${String(recherche).trim()}%`);
    const p = `$${params.length}`;
    conditions.push(`(
      j.action ILIKE ${p}
      OR j.cible_type ILIKE ${p}
      OR j.cible_id::text ILIKE ${p}
      OR coalesce(u.nom, '') ILIKE ${p}
      OR coalesce(u.prenom, '') ILIKE ${p}
      OR coalesce(u.email, '') ILIKE ${p}
      OR coalesce(j.metadata::text, '') ILIKE ${p}
    )`);
  }

  return {
    where: conditions.length ? `WHERE ${conditions.join(' AND ')}` : '',
    params
  };
}

/**
 * GET /journal-activite
 * Paramètres : depuis, jusqu, action, cibleType, utilisateurId, resultat,
 *              source, recherche, limit, offset
 */
async function lister(req, res) {
  const limite = Math.min(Math.max(parseInt(req.query.limit, 10) || LIMITE_DEFAUT, 1), LIMITE_MAX);
  const decalage = Math.max(parseInt(req.query.offset, 10) || 0, 0);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const { where, params } = construireFiltres(req);

      // Comptage AVANT d'ajouter limite/décalage aux paramètres, sinon les
      // numéros $n de la clause WHERE seraient décalés dans la seconde requête.
      const total = await client.query(
        `SELECT count(*) AS nb
         FROM journal_activite j
         LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
         ${where}`,
        params
      );

      const paramsListe = [...params, limite, decalage];
      const result = await client.query(
        `SELECT j.id, j.ecole_id, j.action, j.cible_type, j.cible_id,
                j.metadata, j.created_at,
                j.utilisateur_id,
                u.nom AS utilisateur_nom, u.prenom AS utilisateur_prenom,
                u.email AS utilisateur_email
         FROM journal_activite j
         LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
         ${where}
         ORDER BY j.created_at DESC
         LIMIT $${paramsListe.length - 1} OFFSET $${paramsListe.length}`,
        paramsListe
      );

      const nb = Number(total.rows[0].nb);
      return {
        total: nb,
        limite,
        decalage,
        // Calculé ici plutôt que dans la page : c'est le serveur qui connaît
        // le total, l'interface n'a pas à le redéduire.
        reste: Math.max(nb - (decalage + result.rows.length), 0),
        entrees: result.rows.map((e) => ({
          ...e,
          action_libelle: libelleAction(e.action),
          // Un échec doit sauter aux yeux dans la liste sans qu'on ait à
          // déplier les métadonnées.
          reussite: e.metadata && e.metadata.reussite === false ? false : true,
          automatique: !!(e.metadata && e.metadata.source === 'automatique')
        }))
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste journal activité:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /journal-activite/filtres
 *
 * Les valeurs réellement présentes dans le journal de CETTE école. La page
 * proposait auparavant une liste d'actions écrite en dur dans le HTML : elle
 * ne contenait que 10 entrées et ne pouvait pas suivre l'ajout de nouvelles
 * actions. Un menu construit depuis les données ne peut pas se périmer.
 */
async function filtresDisponibles(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const portee = req.auth.isSuperAdmin ? '' : `WHERE j.ecole_id = ${CURRENT_ECOLE}`;

      const actions = await client.query(
        `SELECT j.action, count(*) AS nb
         FROM journal_activite j
         ${portee}
         GROUP BY j.action
         ORDER BY nb DESC, j.action
         LIMIT 200`
      );

      const types = await client.query(
        `SELECT DISTINCT j.cible_type
         FROM journal_activite j
         ${portee ? portee + ' AND' : 'WHERE'} j.cible_type IS NOT NULL
         ORDER BY j.cible_type`
      );

      // Seulement les personnes qui ont RÉELLEMENT laissé une trace : lister
      // tous les comptes de l'école donnerait un menu où presque tous les
      // choix ne renvoient rien.
      const auteurs = await client.query(
        `SELECT DISTINCT u.id, u.nom, u.prenom
         FROM journal_activite j
         JOIN utilisateurs u ON u.id = j.utilisateur_id
         ${portee}
         ORDER BY u.nom, u.prenom
         LIMIT 300`
      );

      return {
        actions: actions.rows.map((a) => ({
          code: a.action, libelle: libelleAction(a.action), nb: Number(a.nb)
        })),
        types_cible: types.rows.map((t) => t.cible_type),
        auteurs: auteurs.rows.map((u) => ({
          id: u.id, nom_complet: [u.nom, u.prenom].filter(Boolean).join(' ')
        }))
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur filtres journal:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


// ---------------------------------------------------------------------------
//  Recherche assistée
// ---------------------------------------------------------------------------

/*
 * Le journal contient désormais toutes les écritures de tous les utilisateurs.
 * Les filtres manuels supposent qu'on sache déjà quoi chercher — or la question
 * réelle d'un directeur ressemble plutôt à « qui a touché aux notes de 4ème A
 * la semaine dernière ? ».
 *
 * DEUX APPELS, DEUX PÉRIMÈTRES DE DONNÉES
 * ---------------------------------------
 *   1. INTERPRÉTATION — l'assistant ne voit QUE la question. Il la traduit en
 *      filtres. Aucune donnée de l'école ne sort à cette étape.
 *   2. SYNTHÈSE — l'assistant voit une projection RÉDUITE des résultats :
 *      date, action, auteur, réussite. Jamais `metadata`, qui contient des
 *      noms d'élèves, des montants et des adresses.
 *
 * POURQUOI DES FILTRES ET NON DU SQL
 * ----------------------------------
 * La plateforme dispose d'un harnais SQL en lecture seule pour l'assistant
 * (`executerRequeteLectureIA`). Il n'est pas utilisé ici. Traduire la question
 * en FILTRES plutôt qu'en requête donne trois garanties que le harnais ne
 * donne pas : la requête exécutée est toujours celle qu'on a écrite nous-mêmes,
 * les filtres sont montrés à l'utilisateur qui peut les corriger à la main, et
 * une réponse aberrante du modèle produit au pire une recherche vide — jamais
 * une requête coûteuse ou une jointure inattendue.
 */

const CONSIGNE_INTERPRETATION = `Tu traduis une question en français en filtres de recherche pour le journal d'activité d'un logiciel de gestion scolaire congolais.

Tu réponds UNIQUEMENT par un objet JSON valide, sans texte avant ni après, sans balises de code :
{
  "depuis": "AAAA-MM-JJ" ou null,
  "jusqu": "AAAA-MM-JJ" ou null,
  "action": "<code d'action exact issu de la liste fournie>" ou null,
  "cibleType": "<type exact issu de la liste fournie>" ou null,
  "auteur": "<nom ou fragment de nom de la personne recherchée>" ou null,
  "resultat": "succes" | "echec" | null,
  "recherche": "<mots-clés à chercher dans le détail des opérations>" ou null,
  "explication": "<une phrase disant ce que tu as compris de la question>"
}

Règles :
- N'invente JAMAIS un code d'action ou un type de cible absent des listes fournies. Si aucun ne correspond, mets null et utilise "recherche".
- "recherche" sert aux noms propres, matricules, libellés : tout ce qui n'est pas un code.
- Les échecs se demandent par des mots comme « refusé », « bloqué », « tentative », « n'a pas pu ».
- Interprète les dates relatives par rapport à la date du jour qui t'est donnée. « La semaine dernière » = les 7 jours précédents.
- Sois PRUDENT : mieux vaut un filtre trop large, que l'utilisateur affinera, qu'un filtre trop étroit qui cache la réponse.
- "explication" est rédigée à la 1ʳᵉ personne du pluriel, en français simple.`;

const CONSIGNE_SYNTHESE = `Tu analyses un extrait de journal d'activité scolaire et tu réponds à la question posée.

Tu réponds en français, en 2 à 5 phrases, sans liste à puces, sans titre.

Règles :
- Appuie-toi UNIQUEMENT sur les lignes fournies. N'invente aucun fait.
- Si les lignes ne permettent pas de répondre, dis-le franchement.
- Signale les échecs et les répétitions inhabituelles : ce sont eux qui intéressent une direction.
- Ne conclus JAMAIS à une faute ou à une malveillance : le journal montre des actions, pas des intentions. Décris ce qui s'est passé, laisse le directeur juger.
- Ne cite pas de codes techniques : parle en français courant.`;

/**
 * POST /journal-activite/recherche-ia
 * body : { question }
 */
async function rechercheAssistee(req, res) {
  const question = String(req.body.question || '').trim();
  if (question.length < 5) {
    return res.status(400).json({ message: 'Posez une question un peu plus précise.' });
  }
  if (question.length > 500) {
    return res.status(400).json({ message: 'Question trop longue (500 caractères maximum).' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Deux appels sont facturés d'avance : interprétation et synthèse.
      await consommerQuota(client, req.auth.ecoleId, 2);

      const portee = req.auth.isSuperAdmin ? '' : `WHERE j.ecole_id = ${CURRENT_ECOLE}`;

      // On fournit au modèle le vocabulaire RÉEL de cette école, pas une liste
      // générique : il ne peut proposer un filtre que sur ce qui existe.
      const actions = await client.query(
        `SELECT DISTINCT j.action FROM journal_activite j ${portee} ORDER BY j.action LIMIT 150`
      );
      const types = await client.query(
        `SELECT DISTINCT j.cible_type FROM journal_activite j
         ${portee ? portee + ' AND' : 'WHERE'} j.cible_type IS NOT NULL
         ORDER BY j.cible_type LIMIT 60`
      );

      const aujourdhui = new Date().toISOString().slice(0, 10);
      const brut = await appelerIAJson({
        systeme: CONSIGNE_INTERPRETATION,
        message: `Date du jour : ${aujourdhui}.\n\n`
          + `Codes d'action existants : ${actions.rows.map((a) => a.action).join(', ') || 'aucun'}.\n\n`
          + `Types de cible existants : ${types.rows.map((t) => t.cible_type).join(', ') || 'aucun'}.\n\n`
          + `Question : ${question}`,
        maxTokens: 600
      });

      // Rien de ce que renvoie le modèle n'est utilisé tel quel : chaque filtre
      // est validé contre les valeurs réellement présentes en base.
      const codesConnus = new Set(actions.rows.map((a) => a.action));
      const typesConnus = new Set(types.rows.map((t) => t.cible_type));
      const dateValide = (v) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) ? v : null;

      const filtres = {
        depuis: dateValide(brut.depuis),
        jusqu: dateValide(brut.jusqu),
        action: codesConnus.has(brut.action) ? brut.action : null,
        cibleType: typesConnus.has(brut.cibleType) ? brut.cibleType : null,
        resultat: ['succes', 'echec'].includes(brut.resultat) ? brut.resultat : null,
        recherche: brut.recherche ? String(brut.recherche).slice(0, 120) : null,
        auteur: brut.auteur ? String(brut.auteur).slice(0, 80) : null
      };

      // Le nom d'une personne est résolu en identifiant côté base : le modèle
      // ne manipule jamais d'identifiant, et un nom mal orthographié ne
      // produit pas un filtre silencieusement inopérant.
      let utilisateurId = null;
      let auteurTrouve = null;
      if (filtres.auteur) {
        const u = await client.query(
          `SELECT u.id, trim(concat(u.prenom, ' ', u.nom)) AS nom_complet
           FROM utilisateurs u
           WHERE u.ecole_id = ${CURRENT_ECOLE}
             AND (u.nom ILIKE $1 OR u.prenom ILIKE $1 OR concat(u.prenom, ' ', u.nom) ILIKE $1)
           LIMIT 2`,
          [`%${filtres.auteur}%`]
        );
        // Un seul résultat : on filtre. Plusieurs homonymes : on ne choisit pas
        // à la place de l'utilisateur, le nom retombe dans la recherche libre.
        if (u.rows.length === 1) {
          utilisateurId = u.rows[0].id;
          auteurTrouve = u.rows[0].nom_complet;
        } else if (!filtres.recherche) {
          filtres.recherche = filtres.auteur;
        }
      }

      // La requête est construite par le MÊME code que la recherche manuelle :
      // deux constructions parallèles finiraient par diverger, et l'assistant
      // renverrait alors des résultats que les filtres à l'écran ne
      // reproduiraient pas.
      const fausseRequete = {
        auth: req.auth,
        query: {
          depuis: filtres.depuis, jusqu: filtres.jusqu,
          action: filtres.action, cibleType: filtres.cibleType,
          resultat: filtres.resultat, recherche: filtres.recherche,
          utilisateurId
        }
      };
      const { where, params } = construireFiltres(fausseRequete);

      const LIMITE_ANALYSE = 120;
      const result = await client.query(
        `SELECT j.id, j.action, j.cible_type, j.cible_id, j.metadata, j.created_at,
                j.utilisateur_id,
                u.nom AS utilisateur_nom, u.prenom AS utilisateur_prenom, u.email AS utilisateur_email
         FROM journal_activite j
         LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
         ${where}
         ORDER BY j.created_at DESC
         LIMIT ${LIMITE_ANALYSE}`,
        params
      );

      const entrees = result.rows.map((e) => ({
        ...e,
        action_libelle: libelleAction(e.action),
        reussite: !(e.metadata && e.metadata.reussite === false),
        automatique: !!(e.metadata && e.metadata.source === 'automatique')
      }));

      let synthese;
      if (entrees.length === 0) {
        // Aucun résultat : inutile de dépenser un appel pour faire dire à
        // l'assistant qu'il n'a rien à dire.
        synthese = "Aucune entrée ne correspond à cette question. Élargissez la période, ou reformulez : "
          + "les filtres déduits sont affichés ci-dessous et restent modifiables à la main.";
      } else {
        // Projection RÉDUITE : ni `metadata`, ni identifiants, ni emails. Le
        // détail des opérations contient des noms d'élèves, des montants et des
        // adresses ; il n'a aucune raison de sortir de l'école.
        const extrait = entrees.map((e) => ({
          date: e.created_at,
          action: libelleAction(e.action),
          cible: e.cible_type,
          auteur: e.utilisateur_nom
            ? `${e.utilisateur_nom} ${e.utilisateur_prenom || ''}`.trim()
            : 'Système',
          reussite: e.reussite
        }));

        synthese = await appelerIA({
          systeme: CONSIGNE_SYNTHESE,
          message: `Question : ${question}\n\n`
            + `${entrees.length} entrée(s) trouvée(s)`
            + (entrees.length === LIMITE_ANALYSE ? ' (limite atteinte, il peut y en avoir davantage)' : '')
            + ` :\n${JSON.stringify(extrait)}`,
          maxTokens: 500
        });
      }

      return {
        question,
        interpretation: {
          explication: brut.explication ? String(brut.explication).slice(0, 300) : null,
          filtres: { ...filtres, auteur_trouve: auteurTrouve, utilisateurId }
        },
        synthese: String(synthese).trim(),
        total: entrees.length,
        limite_atteinte: entrees.length === LIMITE_ANALYSE,
        entrees
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur recherche assistée journal:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { lister, filtresDisponibles, rechercheAssistee };
