const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

async function lister(req, res) {
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(`SELECT * FROM mentions WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY seuil_min`)
  );
  res.json(result.rows);
}

async function creer(req, res) {
  const { seuil_min, seuil_max, libelle } = req.body;
  if (seuil_min === undefined || seuil_max === undefined || !libelle) {
    return res.status(400).json({ message: 'seuil_min, seuil_max et libelle sont requis.' });
  }
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `INSERT INTO mentions (ecole_id, seuil_min, seuil_max, libelle) VALUES (${CURRENT_ECOLE}, $1,$2,$3) RETURNING id`,
      [seuil_min, seuil_max, libelle]
    )
  );
  res.status(201).json({ id: result.rows[0].id });
}

async function supprimer(req, res) {
  const { id } = req.params;
  await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query('DELETE FROM mentions WHERE id = $1', [id])
  );
  res.json({ message: 'Mention supprimée.' });
}

module.exports = { lister, creer, supprimer };
