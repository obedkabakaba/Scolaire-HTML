const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { sqlMaximumApplicable } = require('../utils/bareme.utils');
// Verrou de période extrait dans utils/periode.utils.js : il était local à
// ce fichier, donc le module Discipline écrivait sur des périodes clôturées.
const { verifierPeriodeModifiable } = require('../utils/periode.utils');
const {
  notifierEvenement, destinatairesParRole, planifierVidage
} = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Bloque tout accès (lecture ET écriture) aux notes/points d'une période dont
 * l'année scolaire n'est pas l'année ACTIVE (le "pivot" choisi par le Directeur) —
 * pour TOUT LE MONDE, y compris directeur/préfet. Ça couvre deux cas :
 *   - l'année est clôturée (définitif) ;
 *   - l'année n'est simplement plus l'année active (une ancienne année encore
 *     techniquement "ouverte" ne doit pas non plus réapparaître dans les écrans
 *     courants : chaque année reste avec ses notes, rien ne doit "revenir").
 * Seule une réactivation explicite de l'année (module Année scolaire) ou une
 * consultation via le module Archives (lecture seule, direction/secrétariat)
 * permet d'y retoucher ou de la consulter.
 */
/**
 * Résout classe_cours_id à partir de (classeId, coursId), dans la transaction en cours.
 *
 * `maximum` dépend de la PÉRIODE visée, pas seulement du cours : une session
 * d'examen se cote sur `maximum_examen` (2 × la période quand l'école ne l'a
 * pas configuré), jamais sur le maximum de période. Sans `periodeId`, la
 * fonction retombe sur le maximum de période — c'est l'ancien comportement,
 * conservé pour les appelants qui ne visent aucune période précise.
 *
 * Le champ `maximum_periode` est renvoyé en plus : les messages d'erreur et
 * les écrans ont besoin de dire « sur 40 (examen) » plutôt que « sur 40 » tout
 * court, sans quoi le professeur croit à une faute de saisie.
 */
async function resoudreClasseCours(client, classeId, coursId, periodeId = null) {
  const result = await client.query(
    `SELECT cc.id, cc.classe_id,
            COALESCE(cc.maximum_points_override, c.maximum_points, 0) AS maximum_periode,
            ${sqlMaximumApplicable('cc', 'c', "COALESCE(p.type::text, 'periode')")} AS maximum,
            COALESCE(p.type::text, 'periode') AS type_periode
     FROM classe_cours cc
     JOIN cours c ON c.id = cc.cours_id
     LEFT JOIN periodes p ON p.id = $3::uuid
     WHERE cc.classe_id = $1 AND cc.cours_id = $2`,
    [classeId, coursId, periodeId]
  );
  return result.rows[0] || null;
}

/**
 * Vérifie qu'un professeur est bien affecté à ce classe_cours.
 * Les directeur/préfet/super_admin passent toujours.
 */
/**
 * Qui peut ÉCRIRE une cote dans un cours donné.
 *
 * La cote appartient à celui qui a corrigé. Le directeur et le préfet
 * disposaient d'une dérogation totale : ils pouvaient modifier n'importe quelle
 * note de n'importe quel cours. Ce n'est pas leur rôle — ils n'ont pas corrigé
 * la copie, et une note changée par-dessus l'enseignant sans qu'il le sache
 * détruit la confiance qui fait tenir le dispositif.
 *
 * Leur pouvoir sur les notes reste entier, mais il s'exerce ailleurs :
 * VALIDER, DÉVALIDER, et bientôt CLÔTURER une période. Ce sont des actes de
 * direction — ils portent sur le processus, pas sur le contenu.
 *
 * L'exception qui demeure : un membre de la direction qui enseigne réellement
 * un cours y est affecté dans `enseignant_cours`, et saisit alors ses cotes
 * comme n'importe quel enseignant. C'est bien sa qualité d'enseignant qui
 * l'autorise, pas son grade.
 */
async function professeurEstAutorise(client, req, classeCoursId) {
  // Le super-admin conserve l'accès : c'est un rôle d'exploitation de la
  // plateforme, pas un acteur de l'école.
  if (req.auth.isSuperAdmin) return true;

  const result = await client.query(
    `SELECT 1 FROM enseignant_cours WHERE utilisateur_id = $1 AND classe_cours_id = $2`,
    [req.auth.userId, classeCoursId]
  );
  return result.rows.length > 0;
}

/**
 * Autorisation de LECTURE pour la direction : elle voit tout, partout.
 * Séparée de l'écriture, justement pour que voir n'implique plus modifier.
 */
function estDirectionLecture(req) {
  return req.auth.isSuperAdmin
    || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
}

/**
 * Autorisation "lecture seule" : en plus du professeur assigné, le titulaire
 * de la classe peut CONSULTER la grille de n'importe quel cours de sa classe
 * (mais ne peut ni saisir ni modifier les points s'il n'est pas lui-même le
 * professeur de ce cours précis — ça reste vérifié par professeurEstAutorise
 * au moment d'enregistrer).
 */
async function autoriseEnLectureSeule(client, req, classeCoursId) {
  // La direction consulte toutes les grilles : c'est ainsi qu'elle contrôle
  // l'avancement de la saisie. Elle ne peut simplement plus y écrire.
  if (estDirectionLecture(req)) return true;
  if (await professeurEstAutorise(client, req, classeCoursId)) return true;
  if (!req.auth.roles.includes('titulaire')) return false;
  const result = await client.query(
    `SELECT 1 FROM classe_cours cc JOIN classes c ON c.id = cc.classe_id
     WHERE cc.id = $1 AND c.titulaire_id = $2`,
    [classeCoursId, req.auth.userId]
  );
  return result.rows.length > 0;
}

/**
 * Recalcule total / pourcentage / classement / mention pour toute la classe,
 * à une période donnée, et met à jour la table `bulletins` (upsert).
 * Classement : tri par pourcentage décroissant, égalité départagée par ordre alphabétique
 * (nom, postnom, prénom) — conformément à la règle retenue pour cette école.
 */
async function recalculerClassement(client, classeId, periodeId) {
  const totauxResult = await client.query(
    `WITH maximum_classe AS (
       -- Dénominateur : le total des maximums de TOUS les cours de la classe.
       --
       -- Il était auparavant calculé en sommant les maximums des seules lignes de
       -- la table notes existantes. Un élève noté dans 5 cours sur 10 voyait donc son
       -- pourcentage calculé sur 5 cours : 200 points sur un maximum de 200, soit
       -- 100 %, alors que le bulletin imprimait « 200 / 400 » juste au-dessus —
       -- le PDF, lui, a toujours affiché le maximum complet de la classe.
       -- Conséquence : un élève à qui il manquait des cotes passait devant un
       -- élève noté partout.
       --
       -- Un cours sans note compte donc pour 0 : c'est la règle « total obtenu
       -- sur total des maximums », et cela suppose que toutes les cotes de la
       -- période soient saisies avant de générer les bulletins.
       --
       -- Le maximum dépend du TYPE de la période. Cette requête employait
       -- toujours le maximum de période, examens compris : sur une session
       -- d'examen le dénominateur valait donc la moitié du barème réel, et le
       -- pourcentage enregistré dans la table bulletins dépassait 100 %. Le
       -- classement et la mention en découlaient, et la promotion les lisait.
       -- La règle est désormais celle de utils/bareme.utils.js, la même que
       -- celle des bulletins officiels.
       SELECT COALESCE(SUM(
                ${sqlMaximumApplicable('cc', 'c', 'per.type::text')}
              ), 0) AS total_maximum
       FROM classe_cours cc
       JOIN cours c ON c.id = cc.cours_id
       CROSS JOIN (SELECT type FROM periodes WHERE id = $2) per
       WHERE cc.classe_id = $1
     ),
     totaux AS (
       SELECT n.eleve_id, SUM(n.points_obtenus) AS total_obtenu
       FROM notes n
       JOIN classe_cours cc ON cc.id = n.classe_cours_id
       WHERE cc.classe_id = $1 AND n.periode_id = $2 AND n.points_obtenus IS NOT NULL
       GROUP BY n.eleve_id
     )
     SELECT t.eleve_id, e.nom, e.postnom, e.prenom,
            t.total_obtenu, m.total_maximum,
            ROUND((t.total_obtenu / NULLIF(m.total_maximum, 0)) * 100, 2) AS pourcentage
     FROM totaux t
     JOIN eleves e ON e.id = t.eleve_id
     CROSS JOIN maximum_classe m
     ORDER BY pourcentage DESC NULLS LAST, e.nom ASC, e.postnom ASC, e.prenom ASC`,
    [classeId, periodeId]
  );

  const mentionsResult = await client.query(
    `SELECT seuil_min, seuil_max, libelle FROM mentions
     WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY seuil_min`
  );
  const mentions = mentionsResult.rows;

  // IMPORTANT : node-pg renvoie les colonnes NUMERIC sous forme de chaînes.
  // Sans conversion en Number, ">=" compare les chaînes caractère par caractère
  // ("9.50" >= "10" est VRAI en comparaison de texte) et attribue de fausses mentions.
  function trouverMention(pourcentage) {
    if (pourcentage === null || pourcentage === undefined) return null;
    const p = Number(pourcentage);
    if (Number.isNaN(p)) return null;
    const m = mentions.find((m) => p >= Number(m.seuil_min) && p <= Number(m.seuil_max));
    return m ? m.libelle : null;
  }

  const lignes = totauxResult.rows;

  for (let i = 0; i < lignes.length; i++) {
    const ligne = lignes[i];
    const classement = i + 1;
    const mention = trouverMention(ligne.pourcentage);

    await client.query(
      `INSERT INTO bulletins (ecole_id, eleve_id, periode_id, total, pourcentage, classement, mention)
       VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6)
       ON CONFLICT (eleve_id, periode_id)
       DO UPDATE SET total = EXCLUDED.total, pourcentage = EXCLUDED.pourcentage,
                     classement = EXCLUDED.classement, mention = EXCLUDED.mention`,
      [ligne.eleve_id, periodeId, ligne.total_obtenu, ligne.pourcentage, classement, mention]
    );
  }

  return lignes.map((l, i) => ({
    eleve_id: l.eleve_id,
    nom: l.nom, postnom: l.postnom, prenom: l.prenom,
    total: l.total_obtenu, maximum: l.total_maximum, pourcentage: l.pourcentage,
    classement: i + 1, mention: trouverMention(l.pourcentage)
  }));
}

/**
 * GET /notes/grille?classeId=&coursId=&periodeId=
 */
async function grille(req, res) {
  const { classeId, coursId, periodeId } = req.query;
  if (!classeId || !coursId || !periodeId) {
    return res.status(400).json({ message: 'classeId, coursId et periodeId sont requis.' });
  }

  try {
    const data = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }

      const autorise = await autoriseEnLectureSeule(client, req, classeCours.id);
      if (!autorise) {
        throw Object.assign(new Error('Vous n\'êtes pas affecté à ce cours pour cette classe.'), { statusCode: 403 });
      }

      // Une période d'une année qui n'est plus l'année active ne doit même pas
      // pouvoir être consultée ici : elle ne doit pas "revenir" mélangée aux
      // écrans de l'année en cours (consultation via Archives uniquement).
      await verifierPeriodeModifiable(client, periodeId);

      const elevesResult = await client.query(
        `SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom, e.matricule,
                n.points_obtenus, n.valide
         FROM eleves e
         LEFT JOIN notes n ON n.eleve_id = e.id AND n.classe_cours_id = $1 AND n.periode_id = $2
         WHERE e.classe_id = $3 AND e.statut = 'actif'
         ORDER BY e.nom, e.postnom`,
        [classeCours.id, periodeId, classeId]
      );

      return { maximum: classeCours.maximum, eleves: elevesResult.rows };
    });

    return res.json(data);
  } catch (err) {
    console.error('Erreur grille notes:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /notes/grille
 * body: { classeId, coursId, periodeId, notes: [{ eleve_id, points_obtenus }] }
 */
async function enregistrerGrille(req, res) {
  const { classeId, coursId, periodeId, notes, classeCoursId: classeCoursIdDirect } = req.body;
  if (!periodeId || !Array.isArray(notes) || (!classeCoursIdDirect && (!classeId || !coursId))) {
    return res.status(400).json({ message: 'periodeId, notes (tableau), et (classeId+coursId OU classeCoursId) sont requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      let classeCours;
      if (classeCoursIdDirect) {
        // Même règle de barème que par (classeId, coursId) : ce chemin sert
        // l'écran des travaux, qui vise lui aussi une période précise.
        const r = await client.query(
          `SELECT cc.id, cc.classe_id,
                  COALESCE(cc.maximum_points_override, c.maximum_points, 0) AS maximum_periode,
                  ${sqlMaximumApplicable('cc', 'c', "COALESCE(p.type::text, 'periode')")} AS maximum,
                  COALESCE(p.type::text, 'periode') AS type_periode
           FROM classe_cours cc
           JOIN cours c ON c.id = cc.cours_id
           LEFT JOIN periodes p ON p.id = $2::uuid
           WHERE cc.id = $1`,
          [classeCoursIdDirect, periodeId]
        );
        classeCours = r.rows[0];
      } else {
        classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      }
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }

      const autorise = await professeurEstAutorise(client, req, classeCours.id);
      if (!autorise) {
        // Deux refus différents, parce que ce sont deux situations
        // différentes : un enseignant s'est trompé d'écran, un directeur se
        // heurte à une règle qu'il ignore peut-être.
        throw Object.assign(
          new Error(estDirectionLecture(req)
            ? "La saisie des cotes appartient à l'enseignant du cours. Vous pouvez consulter, "
              + "valider ou déverrouiller cette grille, mais pas en modifier les points. "
              + "Si vous enseignez ce cours, faites-vous affecter dans Structure › Classes › Cours."
            : "Vous n'êtes pas affecté à ce cours pour cette classe."),
          { statusCode: 403 }
        );
      }

      // Une année clôturée est définitive : ni le professeur ni le directeur
      // ne doivent pouvoir y toucher via cet écran.
      await verifierPeriodeModifiable(client, periodeId);

      // Le verrou de validation vaut pour TOUT LE MONDE, sans exception.
      // La direction bénéficiait d'un contournement : elle pouvait réécrire
      // par-dessus des notes validées sans passer par le déverrouillage, donc
      // sans que l'opération laisse la trace qu'un déverrouillage laisse.
      // Le pouvoir de la direction sur des notes verrouillées existe toujours,
      // mais il passe par « Déverrouiller » — c'est-à-dire au vu de tous.
      {
        const verrouResult = await client.query(
          `SELECT 1 FROM notes WHERE classe_cours_id = $1 AND periode_id = $2 AND valide = true LIMIT 1`,
          [classeCours.id, periodeId]
        );
        if (verrouResult.rows.length > 0) {
          throw Object.assign(
            new Error('Ces notes ont déjà été validées et sont verrouillées. Contactez le Directeur ou le Préfet pour les déverrouiller.'),
            { statusCode: 403 }
          );
        }
      }

      // IMPORTANT : le maximum arrive de PostgreSQL sous forme de chaîne ("30.00") et
      // les points peuvent arriver du client sous forme de chaîne aussi. Sans conversion
      // en Number, la comparaison se fait caractère par caractère ("8" > "30.00" est VRAI
      // en texte) et rejette à tort des notes parfaitement valides.
      const maximumCours = Number(classeCours.maximum);

      // `maximum_examen = 0` veut dire « ce cours n'est pas examiné » : la case
      // est noircie sur le bulletin officiel. Sans ce garde-fou, la boucle de
      // validation ci-dessous refuserait chaque note avec « comprise entre 0 et
      // 0 », un message que personne ne sait interpréter.
      if (classeCours.type_periode === 'examen' && maximumCours === 0) {
        throw Object.assign(
          new Error(
            "Ce cours n'est pas examiné : son maximum d'examen est fixé à 0. "
            + "Aucune cote ne peut y être saisie pour une session d'examen. "
            + "Pour l'examiner, renseignez son maximum d'examen dans Structure › Cours."
          ),
          { statusCode: 409 }
        );
      }

      // Noms des élèves pour produire des messages d'erreur lisibles (au lieu d'un identifiant technique)
      const idsEleves = notes.map((n) => n.eleve_id).filter(Boolean);
      const nomsResult = idsEleves.length > 0
        ? await client.query(`SELECT id, nom, postnom, prenom FROM eleves WHERE id = ANY($1::uuid[])`, [idsEleves])
        : { rows: [] };
      const nomsParId = Object.fromEntries(
        nomsResult.rows.map((e) => [e.id, [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ')])
      );

      // On valide TOUT le lot avant d'écrire quoi que ce soit : soit tout passe, soit rien n'est enregistré.
      for (const n of notes) {
        const brut = n.points_obtenus;
        const pts = (brut === null || brut === undefined || brut === '') ? null : Number(brut);
        if (pts !== null && (Number.isNaN(pts) || pts < 0 || pts > maximumCours)) {
          const nomEleve = nomsParId[n.eleve_id] || 'cet élève';
          throw Object.assign(
            new Error(
              `Note invalide pour ${nomEleve} : « ${brut} » — la note doit être comprise entre 0 et ${maximumCours} `
              + (classeCours.type_periode === 'examen'
                ? `(maximum d'EXAMEN de ce cours).`
                : `(maximum du cours).`)
            ),
            { statusCode: 400 }
          );
        }
        n.points_obtenus = pts;
      }

      for (const n of notes) {
        await client.query(
          `INSERT INTO notes (ecole_id, eleve_id, classe_cours_id, periode_id, points_obtenus, saisi_par)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5)
           ON CONFLICT (eleve_id, classe_cours_id, periode_id)
           DO UPDATE SET points_obtenus = EXCLUDED.points_obtenus, saisi_par = EXCLUDED.saisi_par, updated_at = now()`,
          [n.eleve_id, classeCours.id, periodeId, n.points_obtenus, req.auth.userId]
        );
      }

      // `classeId` est absent du corps de requête quand l'appelant fournit
      // directement `classeCoursId` : on prend la classe portée par le
      // classe_cours lui-même, toujours renseignée dans les deux chemins.
      const classeConcernee = classeCours.classe_id || classeId;

      // Recalcul immédiat du total, du pourcentage et du classement.
      //
      // Il n'avait lieu qu'à la VALIDATION des notes et à l'ouverture du
      // récapitulatif : entre la saisie et la validation, `bulletins` gardait
      // donc des valeurs périmées. Un bulletin imprimé dans cet intervalle
      // affichait l'ancien classement, sans que rien ne signale l'écart —
      // c'est précisément ce qui a produit des pourcentages calculés avec une
      // formule déjà corrigée dans le code.
      await recalculerClassement(client, classeConcernee, periodeId);
    });

    return res.json({ message: 'Notes enregistrées.' });
  } catch (err) {
    console.error('Erreur enregistrement notes:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /notes/valider  (directeur/préfet uniquement)
 * body: { classeId, coursId, periodeId }
 * Verrouille les notes de ce cours pour cette classe/période, puis recalcule
 * automatiquement le classement de toute la classe pour cette période.
 */
async function valider(req, res) {
  const { classeId, coursId, periodeId } = req.body;
  if (!classeId || !coursId || !periodeId) {
    return res.status(400).json({ message: 'classeId, coursId et periodeId sont requis.' });
  }

  try {
    const recap = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }

      // Le professeur assigné peut soumettre (verrouiller) SES notes lui-même ;
      // le directeur/préfet peuvent le faire pour n'importe quel cours.
      const autorise = await professeurEstAutorise(client, req, classeCours.id);
      if (!autorise) {
        throw Object.assign(new Error("Vous n'êtes pas affecté à ce cours pour cette classe."), { statusCode: 403 });
      }

      await verifierPeriodeModifiable(client, periodeId);

      // Rien à soumettre ? On refuse : sinon un cours "vide" serait marqué comme
      // clôturé dans l'état des périodes alors qu'aucune note n'existe.
      const etatResult = await client.query(
        `SELECT count(*) FILTER (WHERE points_obtenus IS NOT NULL) AS nb_notes,
                count(*) FILTER (WHERE valide = true) AS nb_validees
         FROM notes WHERE classe_cours_id = $1 AND periode_id = $2`,
        [classeCours.id, periodeId]
      );
      const nbNotes = Number(etatResult.rows[0].nb_notes);
      const nbValidees = Number(etatResult.rows[0].nb_validees);
      if (nbNotes === 0) {
        throw Object.assign(
          new Error("Aucune note n'a encore été saisie pour ce cours et cette période : il n'y a rien à soumettre."),
          { statusCode: 400 }
        );
      }
      if (nbValidees > 0) {
        throw Object.assign(
          new Error('Ces notes sont déjà soumises et verrouillées.'),
          { statusCode: 409 }
        );
      }

      await client.query(
        `UPDATE notes SET valide = true, valide_par = $1, valide_at = now()
         WHERE classe_cours_id = $2 AND periode_id = $3`,
        [req.auth.userId, classeCours.id, periodeId]
      );

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'notes.validees', 'classe_cours', $2, $3)`,
        [req.auth.userId, classeCours.id, JSON.stringify({ periodeId })]
      );

      // ------------------------------------------------------------------
      // Qui doit savoir, et qui ne doit PAS savoir
      // ------------------------------------------------------------------
      // Le titulaire et la direction : oui — c'est eux qui relancent les
      // retardataires et décident du moment de clôturer la période. Sans ce
      // signal, ils découvrent l'état d'avancement en ouvrant l'écran, donc
      // seulement s'ils y pensent.
      //
      // Les familles : non. Des notes soumises restent dévalidables et
      // recalculables. La famille est prévenue à la signature du bulletin
      // (voir bulletins.controller), quand les chiffres sont définitifs.
      //
      // Interne uniquement : c'est un signal de travail, pas une annonce.
      // Un e-mail par cours et par classe noierait la direction — une école
      // de 20 classes × 12 cours, c'est 240 messages par période.
      const contexte = await client.query(
        `SELECT c.nom AS cours, cl.nom AS classe, cl.titulaire_id,
                COALESCE(p.libelle, concat(p.type::text, ' ', p.numero)) AS periode,
                trim(concat(u.prenom, ' ', u.nom)) AS professeur
           FROM classe_cours cc
           JOIN cours c ON c.id = cc.cours_id
           JOIN classes cl ON cl.id = cc.classe_id
           CROSS JOIN LATERAL (SELECT libelle, type, numero FROM periodes WHERE id = $2) p
           LEFT JOIN utilisateurs u ON u.id = $3
          WHERE cc.id = $1`,
        [classeCours.id, periodeId, req.auth.userId]
      );
      const info = contexte.rows[0];

      if (info) {
        const direction = await destinatairesParRole(client, ['directeur', 'prefet']);
        // Le titulaire est ajouté à la liste ; `notifierEvenement` écarte les
        // doublons, donc un préfet qui serait aussi titulaire ne reçoit
        // qu'un seul message.
        const destinataires = [...direction];
        if (info.titulaire_id) destinataires.push(info.titulaire_id);

        await notifierEvenement(client, {
          evenement: 'notes.soumises',
          destinataires,
          expediteurId: req.auth.userId,
          donnees: {
            cours: info.cours,
            classe: info.classe,
            periode: info.periode,
            professeur: info.professeur
          },
          cleUnicite: `notes_soumises:${classeCours.id}:${periodeId}`
        });
      }

      return recalculerClassement(client, classeId, periodeId);
    });

    planifierVidage();

    return res.json({ message: 'Notes soumises et verrouillées.', recapitulatif: recap });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur validation notes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /notes/devalider  (directeur/préfet uniquement)
 * Déverrouille les notes en cas d'erreur à corriger après validation.
 * body: { classeId, coursId, periodeId }
 */
async function devalider(req, res) {
  const { classeId, coursId, periodeId } = req.body;
  if (!classeId || !coursId || !periodeId) {
    return res.status(400).json({ message: 'classeId, coursId et periodeId sont requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }

      await verifierPeriodeModifiable(client, periodeId);

      const majResult = await client.query(
        `UPDATE notes SET valide = false, valide_par = NULL, valide_at = NULL
         WHERE classe_cours_id = $1 AND periode_id = $2 AND valide = true`,
        [classeCours.id, periodeId]
      );
      if (majResult.rowCount === 0) {
        throw Object.assign(
          new Error("Ces notes ne sont pas verrouillées : il n'y a rien à déverrouiller."),
          { statusCode: 400 }
        );
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'notes.devalidees', 'classe_cours', $2, $3)`,
        [req.auth.userId, classeCours.id, JSON.stringify({ periodeId })]
      );
    });

    return res.json({ message: 'Notes déverrouillées.' });
  } catch (err) {
    console.error('Erreur dévalidation notes:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /notes/recapitulatif?classeId=&periodeId=
 * Recalcule et renvoie le classement actuel de la classe pour cette période
 * (basé sur les notes déjà encodées, même partiellement).
 */
async function recapitulatif(req, res) {
  const { classeId, periodeId } = req.query;
  if (!classeId || !periodeId) {
    return res.status(400).json({ message: 'classeId et periodeId sont requis.' });
  }

  try {
    const recap = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Un titulaire (sans rôle de direction/secrétariat) ne peut consulter que SA classe.
      const estPersonnelEcole = req.auth.isSuperAdmin
        || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r));
      if (!estPersonnelEcole) {
        const proprio = await client.query(
          `SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`,
          [classeId, req.auth.userId]
        );
        if (proprio.rows.length === 0) {
          throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
        }
      }
      await verifierPeriodeModifiable(client, periodeId);
      return recalculerClassement(client, classeId, periodeId);
    });
    return res.json(recap);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur récapitulatif:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /notes/fiche-cotes?classeId=&coursId=&periodeId=
 * Génère un PDF imprimable de la grille de notes d'un professeur pour un cours/classe/période.
 * Accessible au professeur pour ses propres cours, et au directeur/préfet pour n'importe lequel.
 */
async function genererFicheCotes(req, res) {
  const { classeId, coursId, periodeId } = req.query;
  if (!classeId || !coursId || !periodeId) {
    return res.status(400).json({ message: 'classeId, coursId et periodeId sont requis.' });
  }

  let browser;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error("Ce cours n'est pas programmé dans cette classe."), { statusCode: 404 });
      }
      const autorise = await professeurEstAutorise(client, req, classeCours.id);
      if (!autorise) {
        throw Object.assign(new Error("Vous n'êtes pas affecté à ce cours pour cette classe."), { statusCode: 403 });
      }
      await verifierPeriodeModifiable(client, periodeId);

      const ecoleResult = await client.query(`SELECT nom FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const classeResult = await client.query(`SELECT nom FROM classes WHERE id = $1`, [classeId]);
      const coursResult = await client.query(`SELECT nom FROM cours WHERE id = $1`, [coursId]);
      const periodeResult = await client.query(`SELECT libelle, type, numero FROM periodes WHERE id = $1`, [periodeId]);
      const profResult = await client.query(`SELECT nom, prenom FROM utilisateurs WHERE id = $1`, [req.auth.userId]);

      const elevesResult = await client.query(
        `SELECT e.nom, e.postnom, e.prenom, e.matricule, n.points_obtenus
         FROM eleves e
         LEFT JOIN notes n ON n.eleve_id = e.id AND n.classe_cours_id = $1 AND n.periode_id = $2
         WHERE e.classe_id = $3 AND e.statut = 'actif'
         ORDER BY e.nom, e.postnom`,
        [classeCours.id, periodeId, classeId]
      );

      const periode = periodeResult.rows[0];
      return {
        ecoleNom: ecoleResult.rows[0]?.nom,
        classeNom: classeResult.rows[0]?.nom,
        coursNom: coursResult.rows[0]?.nom,
        periodeLibelle: periode?.libelle || `${periode?.type || ''} ${periode?.numero || ''}`,
        professeurNom: profResult.rows[0] ? `${profResult.rows[0].nom} ${profResult.rows[0].prenom || ''}` : '',
        maximum: classeCours.maximum,
        eleves: elevesResult.rows
      };
    });

    const lignes = donnees.eleves.map((e, i) => `
      <tr>
        <td>${i + 1}</td>
        <td class="matricule">${e.matricule}</td>
        <td>${e.nom} ${e.postnom || ''} ${e.prenom || ''}</td>
        <td>${e.points_obtenus ?? ''}</td>
      </tr>
    `).join('');

    const html = `<!DOCTYPE html>
      <html><head><meta charset="utf-8" /><style>
        @page { size: A4 portrait; margin: 18mm; }
        body { font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
        h1 { font-size: 16px; margin-bottom: 2px; }
        .sous-titre { color: #555; font-size: 12px; margin-bottom: 18px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #999; padding: 6px 8px; text-align: left; }
        th { background: #eee; }
        .matricule { font-family: monospace; font-size: 11px; }
        .pied { margin-top: 40px; display: flex; justify-content: space-between; font-size: 11px; }
      </style></head>
      <body>
        <h1>${donnees.ecoleNom}</h1>
        <div class="sous-titre">
          Fiche des cotes — ${donnees.classeNom} — ${donnees.coursNom} — ${donnees.periodeLibelle}<br/>
          Professeur : ${donnees.professeurNom} · Maximum : ${donnees.maximum}
        </div>
        <table>
          <thead><tr><th>#</th><th>Matricule</th><th>Élève</th><th>Points</th></tr></thead>
          <tbody>${lignes}</tbody>
        </table>
        <div class="pied">
          <span>Date : ____________________</span>
          <span>Signature du professeur : ____________________</span>
        </div>
      </body></html>`;

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true });
    await browser.close();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename="fiche-des-cotes.pdf"');
    return res.send(pdfBuffer);
  } catch (err) {
    if (browser) await browser.close();
    console.error('Erreur génération fiche des cotes:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /notes/grille-travaux?classeId=&coursId=&periodeId=
 * Pour chaque élève de la classe : ses points sur chaque travail (interro/devoir)
 * déjà créé pour ce cours+période, plus son total déjà calculé (notes.points_obtenus).
 */
async function grilleTravaux(req, res) {
  const { classeId, coursId, periodeId } = req.query;
  if (!classeId || !coursId || !periodeId) {
    return res.status(400).json({ message: 'classeId, coursId et periodeId sont requis.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }
      const autorise = await autoriseEnLectureSeule(client, req, classeCours.id);
      if (!autorise) {
        throw Object.assign(new Error('Vous n\'êtes pas affecté à ce cours pour cette classe.'), { statusCode: 403 });
      }
      await verifierPeriodeModifiable(client, periodeId);

      const travauxResult = await client.query(
        `SELECT id, nom, maximum_points FROM travaux WHERE classe_cours_id = $1 AND periode_id = $2 ORDER BY ordre, created_at`,
        [classeCours.id, periodeId]
      );

      const elevesResult = await client.query(
        `SELECT e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                n.points_obtenus AS total, n.valide
         FROM eleves e
         LEFT JOIN notes n ON n.eleve_id = e.id AND n.classe_cours_id = $1 AND n.periode_id = $2
         WHERE e.classe_id = $3 AND e.statut = 'actif'
         ORDER BY e.nom, e.postnom`,
        [classeCours.id, periodeId, classeId]
      );

      const pointsTravauxResult = await client.query(
        `SELECT nt.travail_id, nt.eleve_id, nt.points_obtenus
         FROM notes_travaux nt JOIN travaux t ON t.id = nt.travail_id
         WHERE t.classe_cours_id = $1 AND t.periode_id = $2`,
        [classeCours.id, periodeId]
      );

      const eleves = elevesResult.rows.map((e) => ({
        ...e,
        points_travaux: Object.fromEntries(
          pointsTravauxResult.rows.filter(p => p.eleve_id === e.eleve_id).map(p => [p.travail_id, p.points_obtenus])
        )
      }));

      return { maximum: classeCours.maximum, travaux: travauxResult.rows, eleves };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur grille travaux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /notes/grille-travaux
 * body: { classeId, coursId, periodeId, notes: [{ eleve_id, points_par_travail: { travail_id: points } }] }
 * Enregistre les points de chaque travail, PUIS recalcule et enregistre
 * automatiquement le total dans notes.points_obtenus (même mécanique qu'une
 * saisie simple ensuite pour le classement/bulletins/tout le reste).
 */
async function enregistrerGrilleTravaux(req, res) {
  const { classeId, coursId, periodeId, notes } = req.body;
  if (!classeId || !coursId || !periodeId || !Array.isArray(notes)) {
    return res.status(400).json({ message: 'classeId, coursId, periodeId et notes (tableau) sont requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeCours = await resoudreClasseCours(client, classeId, coursId, periodeId);
      if (!classeCours) {
        throw Object.assign(new Error('Ce cours n\'est pas programmé dans cette classe.'), { statusCode: 404 });
      }
      const autorise = await professeurEstAutorise(client, req, classeCours.id);
      if (!autorise) {
        // Deux refus différents, parce que ce sont deux situations
        // différentes : un enseignant s'est trompé d'écran, un directeur se
        // heurte à une règle qu'il ignore peut-être.
        throw Object.assign(
          new Error(estDirectionLecture(req)
            ? "La saisie des cotes appartient à l'enseignant du cours. Vous pouvez consulter, "
              + "valider ou déverrouiller cette grille, mais pas en modifier les points. "
              + "Si vous enseignez ce cours, faites-vous affecter dans Structure › Classes › Cours."
            : "Vous n'êtes pas affecté à ce cours pour cette classe."),
          { statusCode: 403 }
        );
      }

      // Même règle que pour la grille de notes : une année clôturée est
      // définitive, quel que soit le rôle, et le verrou de validation ne se
      // contourne pour personne.
      await verifierPeriodeModifiable(client, periodeId);

      {
        const verrouResult = await client.query(
          `SELECT 1 FROM notes WHERE classe_cours_id = $1 AND periode_id = $2 AND valide = true LIMIT 1`,
          [classeCours.id, periodeId]
        );
        if (verrouResult.rows.length > 0) {
          throw Object.assign(new Error('Ces notes ont déjà été validées et sont verrouillées.'), { statusCode: 403 });
        }
      }

      const travauxResult = await client.query(
        `SELECT id, nom, maximum_points FROM travaux WHERE classe_cours_id = $1 AND periode_id = $2`,
        [classeCours.id, periodeId]
      );
      const travauxParId = Object.fromEntries(
        travauxResult.rows.map((t) => [t.id, { nom: t.nom, maximum: Number(t.maximum_points) }])
      );
      const sommeMaximumsTravaux = travauxResult.rows.reduce((acc, t) => acc + Number(t.maximum_points), 0);

      // Noms des élèves pour des messages d'erreur lisibles
      const idsEleves = notes.map((n) => n.eleve_id).filter(Boolean);
      const nomsResult = idsEleves.length > 0
        ? await client.query(`SELECT id, nom, postnom, prenom FROM eleves WHERE id = ANY($1::uuid[])`, [idsEleves])
        : { rows: [] };
      const nomsParId = Object.fromEntries(
        nomsResult.rows.map((e) => [e.id, [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ')])
      );

      // Validation COMPLÈTE avant toute écriture : chaque point est comparé au maximum
      // de SON travail (et pas seulement au maximum du cours), avec conversion en Number
      // pour éviter les comparaisons de chaînes.
      for (const n of notes) {
        for (const [travailId, points] of Object.entries(n.points_par_travail || {})) {
          const travail = travauxParId[travailId];
          if (!travail) {
            throw Object.assign(new Error("Un des travaux référencés n'existe pas (rechargez la page)."), { statusCode: 400 });
          }
          if (points === null || points === '' || points === undefined) continue;
          const pts = Number(points);
          if (Number.isNaN(pts) || pts < 0 || pts > travail.maximum) {
            const nomEleve = nomsParId[n.eleve_id] || 'cet élève';
            throw Object.assign(
              new Error(`Point invalide pour ${nomEleve} sur « ${travail.nom} » : « ${points} » — doit être compris entre 0 et ${travail.maximum}.`),
              { statusCode: 400 }
            );
          }
        }
      }

      const maximumCoursNum = Number(classeCours.maximum);

      for (const n of notes) {
        let totalBrut = 0;
        let auMoinsUnePoint = false;

        for (const [travailId, points] of Object.entries(n.points_par_travail || {})) {
          const estVide = (points === null || points === '' || points === undefined);
          if (!estVide) {
            totalBrut += Number(points);
            auMoinsUnePoint = true;
          }
          await client.query(
            `INSERT INTO notes_travaux (ecole_id, travail_id, eleve_id, points_obtenus)
             VALUES (${CURRENT_ECOLE}, $1, $2, $3)
             ON CONFLICT (travail_id, eleve_id) DO UPDATE SET points_obtenus = EXCLUDED.points_obtenus`,
            [travailId, n.eleve_id, estVide ? null : Number(points)]
          );
        }

        // Redimensionnement proportionnel : le total brut (ex: sur 50 pour 5 interros
        // de 10) est ramené au VRAI maximum du cours (ex: sur 30), pas laissé tel quel.
        // Formule : note_finale = (total_brut / somme_des_maximums_des_travaux) * maximum_du_cours
        let noteFinale = null;
        if (auMoinsUnePoint && sommeMaximumsTravaux > 0) {
          noteFinale = Math.round((totalBrut / sommeMaximumsTravaux) * maximumCoursNum * 100) / 100;
        }

        // Le total calculé automatiquement alimente la MÊME colonne que la saisie
        // simple habituelle — tout le reste (classement, bulletins) continue de
        // fonctionner exactement pareil, sans aucun changement en aval.
        await client.query(
          `INSERT INTO notes (ecole_id, eleve_id, classe_cours_id, periode_id, points_obtenus, saisi_par)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5)
           ON CONFLICT (eleve_id, classe_cours_id, periode_id)
           DO UPDATE SET points_obtenus = EXCLUDED.points_obtenus, saisi_par = EXCLUDED.saisi_par, updated_at = now()`,
          [n.eleve_id, classeCours.id, periodeId, noteFinale, req.auth.userId]
        );
      }

      // Même raison que dans enregistrerGrille : la note de synthèse issue des
      // travaux alimente la même colonne, elle doit donc déclencher le même
      // recalcul en aval.
      await recalculerClassement(client, classeId, periodeId);
    });

    return res.json({ message: 'Notes enregistrées (total recalculé automatiquement).' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement grille travaux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /notes/recalculer
 * body: { classeId, periodeId }
 *
 * Force le recalcul du classement d'une période, SANS modifier aucune note.
 *
 * Nécessaire pour rattraper les bulletins déjà générés avec l'ancienne formule
 * du pourcentage (dénominateur = seuls les cours notés, plutôt que tous les
 * cours de la classe) : `bulletins.pourcentage` est une valeur MATÉRIALISÉE,
 * écrite au moment de la saisie ou de la validation des notes — elle ne se
 * recalcule jamais toute seule à l'impression. Sans cet endpoint, la seule
 * façon de faire revenir la formule corrigée sur un bulletin déjà généré
 * aurait été de rouvrir et resaisir une note dans chaque cours, ce qui n'a
 * aucun sens pour une classe entière.
 */
async function recalculer(req, res) {
  const { classeId, periodeId } = req.body;
  if (!classeId || !periodeId) {
    return res.status(400).json({ message: 'classeId et periodeId sont requis.' });
  }

  try {
    const nb = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classe = await client.query(
        `SELECT id FROM classes WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [classeId]
      );
      if (classe.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      const recap = await recalculerClassement(client, classeId, periodeId);
      return recap.length;
    });

    return res.json({ message: `Classement recalculé pour ${nb} élève(s).` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur recalcul classement:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  grille, enregistrerGrille, valider, devalider, recapitulatif, genererFicheCotes,
  grilleTravaux, enregistrerGrilleTravaux, recalculer,
  // Exporté pour que bulletins.controller.js puisse rafraîchir les totaux avant
  // de les afficher : sans cela, l'écran des bulletins montrait la valeur figée
  // en base pendant que le PDF, lui, travaillait sur des données fraîches.
  recalculerClassement
};
