const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const ROLES_LIBELLES = {
  directeur: 'Directeur',
  prefet: 'Préfet',
  professeur: 'Professeur',
  enseignant: 'Professeur',
  eleve: 'Élève',
  parent: 'Parent',
  surveillant: 'Surveillant',
  administrateur: 'Administrateur',
  comptable: 'Comptable'
};

/**
 * Normalise un rôle pour pouvoir reconnaître les différentes écritures
 * possibles du rôle de super administrateur.
 */
function normaliserRole(role) {
  return String(role || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[\s_-]+/g, '');
}

/**
 * Retourne true lorsque la notification doit être présentée
 * comme provenant de la plateforme Ardoise.
 *
 * Cela couvre :
 * - une notification automatique sans expediteur_id ;
 * - un ancien message dont l'expéditeur n'est plus joignable ;
 * - un expéditeur dont le rôle enregistré est super-admin ;
 * - un message envoyé par le super-admin avant le déploiement de la correction.
 */
function estExpediteurPlateforme(notification) {
  if (!notification.expediteur_id) {
    return true;
  }

  const nom = String(notification.expediteur_nom || '').trim();
  const roles = String(notification.expediteur_roles || '')
    .split(',')
    .map((role) => normaliserRole(role))
    .filter(Boolean);

  const roleSuperAdmin = roles.some((role) => [
    'superadmin',
    'superadministrateur',
    'administrateurgeneral',
    'platformadmin',
    'plateformeadmin'
  ].includes(role));

  // Ne jamais afficher « Utilisateur ». Si aucun nom exploitable n'est
  // disponible, l'identité sûre est celle de la plateforme.
  return roleSuperAdmin || !nom;
}

function roleLisible(expediteurRoles) {
  const roles = String(expediteurRoles || '')
    .split(',')
    .map((role) => role.trim())
    .filter(Boolean);

  if (roles.length === 0) {
    return null;
  }

  const role = roles[0];
  const roleNormalise = normaliserRole(role);

  if ([
    'superadmin',
    'superadministrateur',
    'administrateurgeneral',
    'platformadmin',
    'plateformeadmin'
  ].includes(roleNormalise)) {
    return null;
  }

  return ROLES_LIBELLES[roleNormalise] || role;
}

/**
 * GET /notifications
 * Notifications de l'école courante, les plus récentes en premier.
 */
async function lister(req, res) {
  const limite = Math.min(Math.max(Number(req.query.limite) || 30, 1), 200);

  try {
    const estDirection = req.auth.isSuperAdmin
      || req.auth.roles.some((role) => ['directeur', 'prefet'].includes(role));

    const result = await runWithTenant(
      tenantContextFromReq(req),
      (client) => client.query(
        `
        SELECT
          n.id,
          n.canal,
          n.sujet,
          n.contenu,
          n.statut,
          n.lu,
          n.created_at,
          n.utilisateur_id,
          n.lien,
          n.evenement,
          n.expediteur_id,
          trim(concat(u.prenom, ' ', u.nom)) AS expediteur_nom,
          COALESCE(
            (
              SELECT string_agg(
                DISTINCT ur.role::text,
                ', '
                ORDER BY ur.role::text
              )
              FROM utilisateur_roles ur
              WHERE ur.utilisateur_id = u.id
            ),
            ''
          ) AS expediteur_roles
        FROM notifications n
        LEFT JOIN utilisateurs u
          ON u.id = n.expediteur_id
        WHERE n.ecole_id = ${CURRENT_ECOLE}
          -- SANS CE FILTRE, LA BOÎTE DU DIRECTEUR DÉBORDE.
          -- Les messages aux familles (bulletin disponible, absence, reçu de
          -- paiement) n'ont pas d'utilisateur_id : un parent n'a pas de
          -- compte, il n'est joignable que par e-mail. Or la condition
          -- ci-dessous montre à la direction TOUTE ligne sans destinataire.
          -- Signer une classe de 300 élèves y déverserait donc 300 messages
          -- destinés à des tiers — bruit massif, et fuite de données
          -- familiales vers un écran qui n'a pas à les afficher ainsi.
          AND n.visible_interface = true
          AND (
            n.utilisateur_id = $1
            OR (
              n.utilisateur_id IS NULL
              AND $2::bool = true
            )
          )
        ORDER BY n.created_at DESC
        LIMIT $3
        `,
        [req.auth.userId, estDirection, limite]
      )
    );

    const notifications = result.rows.map((notification) => {
      const plateforme = estExpediteurPlateforme(notification);

      return {
        ...notification,
        origine: plateforme ? 'plateforme' : 'personne',
        expediteur_libelle: plateforme
          ? 'Plateforme Ardoise'
          : String(notification.expediteur_nom).trim(),
        expediteur_role: plateforme
          ? null
          : roleLisible(notification.expediteur_roles),
        expediteur_est_plateforme: plateforme
      };
    });

    return res.json(notifications);
  } catch (err) {
    console.error('Erreur liste notifications:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /notifications/:id/lu
 */
async function marquerLue(req, res) {
  const { id } = req.params;

  try {
    const estDirection = req.auth.isSuperAdmin
      || req.auth.roles.some((role) => ['directeur', 'prefet'].includes(role));

    const modifiees = await runWithTenant(
      tenantContextFromReq(req),
      async (client) => {
        const result = await client.query(
          `
          UPDATE notifications
          SET lu = true
          WHERE id = $1
            AND ecole_id = ${CURRENT_ECOLE}
            AND visible_interface = true
            AND (
              utilisateur_id = $2
              OR (
                utilisateur_id IS NULL
                AND $3::bool = true
              )
            )
          `,
          [id, req.auth.userId, estDirection]
        );

        return result.rowCount;
      }
    );

    if (modifiees === 0) {
      return res.status(404).json({
        message: 'Notification introuvable.'
      });
    }

    return res.json({
      message: 'Notification marquée comme lue.'
    });
  } catch (err) {
    console.error('Erreur marquage notification:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /notifications/tout-marquer-lu
 */
async function toutMarquerLu(req, res) {
  try {
    const estDirection = req.auth.isSuperAdmin
      || req.auth.roles.some((role) => ['directeur', 'prefet'].includes(role));

    await runWithTenant(
      tenantContextFromReq(req),
      (client) => client.query(
        `
        UPDATE notifications
        SET lu = true
        WHERE ecole_id = ${CURRENT_ECOLE}
          AND lu = false
          AND visible_interface = true
          AND (
            utilisateur_id = $1
            OR (
              utilisateur_id IS NULL
              AND $2::bool = true
            )
          )
        `,
        [req.auth.userId, estDirection]
      )
    );

    return res.json({
      message: 'Toutes les notifications sont marquées comme lues.'
    });
  } catch (err) {
    console.error('Erreur marquage global notifications:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  lister,
  marquerLue,
  toutMarquerLu
};
