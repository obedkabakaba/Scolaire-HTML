const { runWithTenant } = require('../config/db');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Orientation de fin de 8ème — Ardoise
 * --------------------------------------------------------------------------
 * En RDC, l'élève choisit son option à la fin de la 8ème. Une même classe se
 * disperse donc vers plusieurs 1ères humanités, ce que le pointeur
 * « classe suivante » ne sait pas exprimer : il ne connaît qu'une destination.
 *
 * Ce module produit une destination PAR ÉLÈVE, à partir de deux éléments :
 *   · le vœu exprimé, avec un repli ;
 *   · le mérite, qui départage quand une option est pleine.
 *
 * L'attribution automatique se fait par moyenne décroissante. La direction
 * peut corriger au cas par cas — un enseignant connaît parfois mieux l'élève
 * qu'une moyenne — mais chaque correction manuelle est marquée comme telle
 * et motivée. On distingue ainsi toujours ce qui vient du mérite de ce qui
 * vient d'une décision humaine.
 */

const STATUTS = ['voeu_exprime', 'accordee_voeu', 'accordee_repli', 'sans_place', 'non_promu'];

const CRITERES = ['moyenne_globale', 'branche'];

function nomComplet(e) {
  return [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ');
}

/**
 * Portée d'un utilisateur sur l'orientation.
 *
 * L'orientation est DÉLÉGUÉE au titulaire de la classe pivot : c'est lui qui
 * recueille les vœux, parce que c'est lui qui connaît les élèves. Mais la
 * délégation portait jusqu'ici uniquement sur la route (`requireRole` laissait
 * passer le rôle titulaire) et sur rien d'autre : le contrôleur ne vérifiait
 * jamais QUELLE classe. Un titulaire de 8ᵉ A pouvait donc lire les vœux de la
 * 8ᵉ B et les réécrire — y compris juste avant la répartition, sans que le
 * titulaire de B s'en aperçoive.
 *
 * Retourne `null` quand l'utilisateur voit toute l'école (direction,
 * secrétariat, super-admin), ou la liste de SES classes d'orientation sinon.
 */
async function classesAutorisees(client, req, anneeId) {
  if (req.auth.isSuperAdmin) return null;
  if (req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r))) return null;

  const r = await client.query(
    `SELECT id FROM classes
     WHERE ecole_id = ${CURRENT_ECOLE} AND titulaire_id = $1
       AND annee_scolaire_id = $2 AND classe_orientation = true`,
    [req.auth.userId, anneeId]
  );
  if (r.rows.length === 0) {
    throw Object.assign(
      new Error("Vous n'êtes titulaire d'aucune classe d'orientation pour cette année."),
      { statusCode: 403 }
    );
  }
  return r.rows.map((c) => c.id);
}

async function seuilPromotion(client) {
  const r = await client.query(
    `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );
  return Number(r.rows[0].seuil);
}

/**
 * Élèves concernés par l'orientation : ceux des classes marquées comme
 * classes d'orientation, avec leur moyenne annuelle et leurs vœux.
 */
async function chargerEleves(client, anneeId, classesFiltre) {
  const r = await client.query(
    `SELECT e.id AS eleve_id, e.nom, e.postnom, e.prenom, e.matricule,
            c.id AS classe_id, c.nom AS classe_nom,
            o.option_voeu_id, o.option_repli_id, o.option_accordee_id,
            o.classe_affectee_id, o.statut::text AS statut_orientation,
            o.attribue_au_merite, o.motif,
            ov.nom AS voeu_nom, orep.nom AS repli_nom, oacc.nom AS accordee_nom,
            ca.nom AS classe_affectee_nom
     FROM eleves e
     JOIN classes c ON c.id = e.classe_id
     LEFT JOIN orientations o ON o.eleve_id = e.id AND o.annee_scolaire_id = $1
     LEFT JOIN options ov ON ov.id = o.option_voeu_id
     LEFT JOIN options orep ON orep.id = o.option_repli_id
     LEFT JOIN options oacc ON oacc.id = o.option_accordee_id
     LEFT JOIN classes ca ON ca.id = o.classe_affectee_id
     WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif'
       AND c.annee_scolaire_id = $1 AND c.classe_orientation = true
       AND ($2::uuid[] IS NULL OR c.id = ANY($2::uuid[]))
     ORDER BY e.nom`,
    [anneeId, classesFiltre && classesFiltre.length ? classesFiltre : null]
  );

  // ---------- Moyenne annuelle ----------
  //
  // C'est le chiffre qui classe les élèves et qui décide, au mérite, lequel
  // obtient l'option qu'il a demandée. Il était obtenu par
  // AVG(bulletins.pourcentage) sur les périodes de l'année : une moyenne de
  // pourcentages issus de barèmes différents (une session d'examen pèse le
  // double d'une période), lue depuis une valeur matérialisée qui n'existe pas
  // tant qu'aucun bulletin n'a été généré.
  //
  // Un élève dont la classe n'avait pas encore imprimé ses bulletins sortait
  // donc SANS moyenne, et se retrouvait en fin de classement — dernier servi
  // sur les options les plus demandées, pour une raison purement technique.
  //
  // Même source unique que la promotion et le repêchage : utils/moyennes.utils.js.
  const periodesAnnee = await client.query(
    `SELECT id FROM periodes
      WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
        AND type::text IN ('periode', 'examen')`,
    [anneeId]
  );
  const moyennes = new Map();
  if (periodesAnnee.rows.length > 0) {
    const lignes = await pourcentagesParEleve(
      client, anneeId,
      { type: 'annuel', periodeIds: periodesAnnee.rows.map((p) => p.id) },
      { inclureNonNotes: false }
    );
    for (const l of lignes) moyennes.set(l.eleve_id, l.pourcentage);
  }

  return r.rows
    .map((e) => ({
      ...e,
      nom_complet: nomComplet(e),
      moyenne: moyennes.has(e.eleve_id)
        ? Math.round(Number(moyennes.get(e.eleve_id)) * 10) / 10
        : null,
      attribue_au_merite: e.attribue_au_merite === true
    }))
    // Le tri au mérite se faisait en SQL ; il se fait ici, sur la moyenne
    // recalculée. Un élève sans moyenne reste en fin de liste, et les égalités
    // sont départagées par ordre alphabétique — la même règle que partout
    // ailleurs dans Ardoise (§9.3).
    .sort((a, b) => {
      if (a.moyenne === null && b.moyenne === null) return 0;
      if (a.moyenne === null) return 1;
      if (b.moyenne === null) return -1;
      if (b.moyenne !== a.moyenne) return b.moyenne - a.moyenne;
      return String(a.nom || '').localeCompare(String(b.nom || ''), 'fr');
    });
}

/**
 * Options de l'école avec leur critère d'admission.
 */
async function chargerOptions(client) {
  const r = await client.query(
    `SELECT o.id, o.nom, o.critere_type, o.critere_cours_id, o.critere_minimum,
            co.nom AS critere_cours_nom
     FROM options o
     LEFT JOIN cours co ON co.id = o.critere_cours_id
     WHERE o.ecole_id = ${CURRENT_ECOLE}
     ORDER BY o.nom`
  );
  return r.rows.map((o) => ({
    ...o,
    critere_minimum: o.critere_minimum === null ? null : Number(o.critere_minimum)
  }));
}

/**
 * Moyenne d'un élève dans une branche précise, en pourcentage.
 *
 * On calcule TOTAL OBTENU / TOTAL DES MAXIMA × 100, jamais une moyenne de
 * pourcentages : c'est la règle de calcul de toute la plateforme, et l'écart
 * entre les deux méthodes n'est pas anecdotique dès que les périodes n'ont pas
 * le même barème.
 *
 * Seules les branches réellement utilisées comme critère sont calculées : il
 * n'y a aucune raison de charger toutes les notes de tous les cours pour
 * vérifier une exigence qui ne porte que sur les mathématiques.
 */
async function chargerMoyennesBranches(client, anneeId, coursIds, eleveIds) {
  if (!coursIds.length || !eleveIds.length) return new Map();

  const r = await client.query(
    `SELECT n.eleve_id, cc.cours_id,
            SUM(n.points_obtenus) AS obtenus,
            SUM(COALESCE(cc.maximum_points_override, co.maximum_points)) AS maxima
     FROM notes n
     JOIN classe_cours cc ON cc.id = n.classe_cours_id
     JOIN cours co ON co.id = cc.cours_id
     JOIN periodes p ON p.id = n.periode_id
     WHERE n.ecole_id = ${CURRENT_ECOLE}
       AND p.annee_scolaire_id = $1
       AND p.type <> 'semestre'
       AND cc.cours_id = ANY($2::uuid[])
       AND n.eleve_id = ANY($3::uuid[])
       AND n.points_obtenus IS NOT NULL
     GROUP BY n.eleve_id, cc.cours_id`,
    [anneeId, coursIds, eleveIds]
  );

  const parEleve = new Map();
  for (const ligne of r.rows) {
    const maxima = Number(ligne.maxima);
    // Un maximum nul signifie que la branche n'est pas notée : on ne divise
    // pas par zéro, et on ne prétend pas non plus que l'élève a 0 %.
    if (!maxima) continue;
    if (!parEleve.has(ligne.eleve_id)) parEleve.set(ligne.eleve_id, {});
    parEleve.get(ligne.eleve_id)[ligne.cours_id] =
      Math.round((Number(ligne.obtenus) / maxima) * 1000) / 10;
  }
  return parEleve;
}

/**
 * L'élève satisfait-il le critère d'admission de cette option ?
 *
 * Retourne `{ admissible, motif }`. Le motif sert à expliquer un refus à
 * l'écran : « recalé faute de place » et « recalé faute du niveau exigé en
 * mathématiques » appellent des conversations très différentes avec la famille.
 */
function verifierCritere(option, eleve, moyennesBranches) {
  if (!option || option.critere_minimum === null || option.critere_minimum === undefined) {
    return { admissible: true, motif: null };
  }

  if (option.critere_type === 'branche') {
    if (!option.critere_cours_id) return { admissible: true, motif: null };
    const notes = moyennesBranches.get(eleve.eleve_id) || {};
    const valeur = notes[option.critere_cours_id];
    // Aucune note dans la branche exigée : on ne peut pas conclure que le
    // niveau est insuffisant. On laisse passer et la direction tranchera —
    // écarter un élève sur une absence de donnée serait une injustice
    // silencieuse.
    if (valeur === undefined) return { admissible: true, motif: null };
    if (valeur < option.critere_minimum) {
      return {
        admissible: false,
        motif: `${option.critere_cours_nom || 'branche exigée'} : ${valeur} % (minimum ${option.critere_minimum} %)`
      };
    }
    return { admissible: true, motif: null };
  }

  // moyenne_globale
  if (eleve.moyenne === null || eleve.moyenne === undefined) return { admissible: true, motif: null };
  if (eleve.moyenne < option.critere_minimum) {
    return {
      admissible: false,
      motif: `moyenne générale ${eleve.moyenne} % (minimum ${option.critere_minimum} %)`
    };
  }
  return { admissible: true, motif: null };
}

/** GET /orientation?anneeScolaireId=&anneeCibleId= */
async function tableau(req, res) {
  const { anneeScolaireId, anneeCibleId } = req.query;
  if (!anneeScolaireId) return res.status(400).json({ message: 'anneeScolaireId est requis.' });

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const seuil = await seuilPromotion(client);
      const classesFiltre = await classesAutorisees(client, req, anneeScolaireId);
      const eleves = await chargerEleves(client, anneeScolaireId, classesFiltre);

      const options = await chargerOptions(client);

      // Moyennes des seules branches servant de critère, pour les seuls élèves
      // affichés.
      const coursCriteres = [...new Set(
        options.filter((o) => o.critere_type === 'branche' && o.critere_cours_id)
               .map((o) => o.critere_cours_id)
      )];
      const moyennesBranches = await chargerMoyennesBranches(
        client, anneeScolaireId, coursCriteres, eleves.map((e) => e.eleve_id)
      );

      // Chaque élève sait, avant la répartition, quelles options lui sont
      // ouvertes. C'est ce qui permet au titulaire de conseiller un vœu de
      // repli réaliste plutôt que de laisser l'élève se faire recaler.
      const elevesAvecAdmissibilite = eleves.map((e) => ({
        ...e,
        moyennes_branches: moyennesBranches.get(e.eleve_id) || {},
        options_refusees: options
          .map((o) => ({ option: o, verdict: verifierCritere(o, e, moyennesBranches) }))
          .filter((x) => !x.verdict.admissible)
          .map((x) => ({ option_id: x.option.id, option_nom: x.option.nom, motif: x.verdict.motif }))
      }));

      // Classes d'accueil : celles de l'année cible qui portent une option.
      const classesCibles = anneeCibleId ? await client.query(
        `SELECT c.id, c.nom, c.option_id, o.nom AS option_nom, c.capacite,
                (SELECT count(*) FROM orientations ori
                  WHERE ori.classe_affectee_id = c.id AND ori.annee_scolaire_id = $2) AS nb_affectes
         FROM classes c
         JOIN options o ON o.id = c.option_id
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
           -- L'orientation ne concerne que les humanités, mais une école
           -- « les_deux » qui a choisi un cycle ne doit pas voir passer les
           -- classes de l'autre dans la liste d'affectation.
           AND ($3::text IS NULL OR c.cycle IS NULL OR c.cycle::text = $3)
         ORDER BY o.nom, c.nom`,
        [anneeCibleId, anneeScolaireId, cycleDemande(req)]
      ) : { rows: [] };

      return {
        seuil,
        // Dit à l'interface si elle montre toute l'école ou une seule classe :
        // sans cette information, un titulaire croirait que l'école n'a qu'une
        // classe d'orientation.
        portee_complete: classesFiltre === null,
        eleves: elevesAvecAdmissibilite,
        options,
        classes_cibles: classesCibles.rows.map((c) => ({
          ...c,
          capacite: c.capacite === null ? null : Number(c.capacite),
          nb_affectes: Number(c.nb_affectes)
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur tableau orientation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /orientation/voeux
 * body : { annee_scolaire_id, voeux: [{ eleve_id, option_voeu_id, option_repli_id }] }
 */
async function enregistrerVoeux(req, res) {
  const { annee_scolaire_id, voeux } = req.body;
  if (!annee_scolaire_id || !Array.isArray(voeux) || voeux.length === 0) {
    return res.status(400).json({ message: 'annee_scolaire_id et voeux sont requis.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Deux contrôles distincts, et non un seul :
      //   · l'élève doit appartenir à une classe d'orientation de cette année
      //     (empêche d'écrire un vœu sur n'importe quel élève de l'école) ;
      //   · cette classe doit être dans la PORTÉE de l'utilisateur (empêche un
      //     titulaire d'écrire sur la classe parallèle d'un collègue).
      // Le second manquait entièrement.
      const classesFiltre = await classesAutorisees(client, req, annee_scolaire_id);

      const ids = voeux.map((v) => v.eleve_id).filter(Boolean);
      const valides = await client.query(
        `SELECT e.id FROM eleves e
         JOIN classes c ON c.id = e.classe_id
         WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.id = ANY($1::uuid[])
           AND c.annee_scolaire_id = $2 AND c.classe_orientation = true
           AND ($3::uuid[] IS NULL OR c.id = ANY($3::uuid[]))`,
        [ids, annee_scolaire_id, classesFiltre && classesFiltre.length ? classesFiltre : null]
      );
      const autorises = new Set(valides.rows.map((e) => e.id));

      // Un élève écarté par le contrôle n'est plus ignoré en silence : passer
      // sous silence un vœu non enregistré ferait croire au titulaire que son
      // travail est sauvegardé.
      const refuses = ids.filter((id) => !autorises.has(id));

      let enregistres = 0;
      for (const v of voeux) {
        if (!autorises.has(v.eleve_id)) continue;
        if (v.option_voeu_id && v.option_voeu_id === v.option_repli_id) {
          throw Object.assign(
            new Error('Le vœu de repli doit être différent du premier vœu : sinon il ne sert à rien.'),
            { statusCode: 400 }
          );
        }

        await client.query(
          `INSERT INTO orientations (ecole_id, eleve_id, annee_scolaire_id,
                                     option_voeu_id, option_repli_id, statut)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, 'voeu_exprime')
           ON CONFLICT (eleve_id, annee_scolaire_id)
           DO UPDATE SET option_voeu_id = EXCLUDED.option_voeu_id,
                         option_repli_id = EXCLUDED.option_repli_id`,
          [v.eleve_id, annee_scolaire_id, v.option_voeu_id || null, v.option_repli_id || null]
        );
        enregistres++;
      }
      return { enregistres, refuses: refuses.length };
    });

    let message = `${bilan.enregistres} vœu(x) enregistré(s).`;
    if (bilan.refuses > 0) {
      message += ` ${bilan.refuses} élève(s) hors de votre portée n'ont PAS été enregistrés.`;
    }
    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement vœux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /orientation/repartir
 * body : { annee_scolaire_id, annee_cible_id }
 *
 * Répartition automatique au mérite. Chaque élève promu obtient son premier
 * vœu si une place existe ; sinon son repli ; sinon il reste sans place et
 * la direction tranche. Les affectations posées à la main sont conservées.
 */
async function repartir(req, res) {
  const { annee_scolaire_id, annee_cible_id } = req.body;
  if (!annee_scolaire_id || !annee_cible_id) {
    return res.status(400).json({ message: 'annee_scolaire_id et annee_cible_id sont requis.' });
  }
  if (annee_scolaire_id === annee_cible_id) {
    return res.status(400).json({ message: "L'année cible doit être différente de l'année en cours." });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Une année clôturée est définitive : y affecter des élèves reviendrait à
      // rouvrir un exercice déjà arrêté. Rien ne l'empêchait jusqu'ici, et le
      // sélecteur d'année d'accueil proposait bel et bien les années clôturées.
      const anneeCible = await client.query(
        `SELECT libelle, cloturee FROM annees_scolaires
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [annee_cible_id]
      );
      if (anneeCible.rows.length === 0) {
        throw Object.assign(new Error("Année d'accueil introuvable."), { statusCode: 404 });
      }
      if (anneeCible.rows[0].cloturee) {
        throw Object.assign(
          new Error(`L'année « ${anneeCible.rows[0].libelle} » est clôturée : aucun élève ne peut y être affecté.`),
          { statusCode: 409 }
        );
      }

      const seuil = await seuilPromotion(client);
      // La répartition est un acte de direction : elle porte sur TOUTE l'école,
      // jamais sur une classe seule. D'où l'absence de filtre de portée ici —
      // la route la réserve déjà au directeur et au préfet.
      const eleves = await chargerEleves(client, annee_scolaire_id, null);

      const options = await chargerOptions(client);
      const optionsParId = new Map(options.map((o) => [o.id, o]));
      const coursCriteres = [...new Set(
        options.filter((o) => o.critere_type === 'branche' && o.critere_cours_id)
               .map((o) => o.critere_cours_id)
      )];
      const moyennesBranches = await chargerMoyennesBranches(
        client, annee_scolaire_id, coursCriteres, eleves.map((e) => e.eleve_id)
      );

      const classesResult = await client.query(
        `SELECT c.id, c.nom, c.option_id, c.capacite
         FROM classes c
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
           AND c.option_id IS NOT NULL
         ORDER BY c.nom`,
        [annee_cible_id]
      );
      if (classesResult.rows.length === 0) {
        throw Object.assign(
          new Error("Aucune classe d'accueil avec option n'existe pour l'année cible. Créez-les d'abord."),
          { statusCode: 409 }
        );
      }

      // État des places. Une capacité absente vaut « sans limite » : mieux
      // vaut une classe surchargée qu'un élève sans affectation.
      const places = classesResult.rows.map((c) => ({
        id: c.id, nom: c.nom, option_id: c.option_id,
        capacite: c.capacite === null ? null : Number(c.capacite),
        occupe: 0
      }));

      // Les affectations manuelles déjà posées occupent leur place et ne
      // sont jamais remises en cause par la répartition automatique.
      const manuelles = eleves.filter((e) => e.classe_affectee_id && e.attribue_au_merite === false);
      for (const e of manuelles) {
        const p = places.find((x) => x.id === e.classe_affectee_id);
        if (p) p.occupe++;
      }

      function attribuer(optionId) {
        const candidates = places
          .filter((p) => p.option_id === optionId)
          .filter((p) => p.capacite === null || p.occupe < p.capacite)
          // La classe la moins remplie d'abord : les effectifs restent équilibrés.
          .sort((a, b) => a.occupe - b.occupe);
        return candidates[0] || null;
      }

      let voeuAccorde = 0, repliAccorde = 0, sansPlace = 0, nonPromus = 0, recalesCritere = 0;
      const refusesCritere = [];

      /**
       * Tente d'attribuer une option à un élève. Deux obstacles distincts, et
       * il importe de savoir lequel a joué :
       *   · le CRITÈRE d'admission (l'élève n'a pas le niveau exigé) ;
       *   · la PLACE (l'élève avait le niveau, mais d'autres sont passés avant).
       * Un directeur qui voit « recalé » sans savoir pourquoi ne peut ni
       * expliquer à la famille, ni corriger son paramétrage.
       */
      function tenter(optionId, eleve) {
        if (!optionId) return { classe: null, refus: null };
        const option = optionsParId.get(optionId);
        const verdict = verifierCritere(option, eleve, moyennesBranches);
        if (!verdict.admissible) {
          return { classe: null, refus: verdict.motif };
        }
        return { classe: attribuer(optionId), refus: null };
      }

      // Tri par mérite : la moyenne départage, et personne d'autre.
      const parMerite = [...eleves]
        .filter((e) => !(e.classe_affectee_id && e.attribue_au_merite === false))
        .sort((a, b) => (b.moyenne ?? -1) - (a.moyenne ?? -1));

      for (const e of parMerite) {
        if (e.moyenne === null || e.moyenne < seuil) {
          await client.query(
            `INSERT INTO orientations (ecole_id, eleve_id, annee_scolaire_id, statut)
             VALUES (${CURRENT_ECOLE}, $1, $2, 'non_promu')
             ON CONFLICT (eleve_id, annee_scolaire_id)
             DO UPDATE SET statut = 'non_promu', option_accordee_id = NULL,
                           classe_affectee_id = NULL, attribue_au_merite = true`,
            [e.eleve_id, annee_scolaire_id]
          );
          nonPromus++;
          continue;
        }

        let essai = tenter(e.option_voeu_id, e);
        let cible = essai.classe;
        let statut = 'accordee_voeu';
        let optionAccordee = e.option_voeu_id;
        const motifs = [];
        if (essai.refus) motifs.push(`${e.voeu_nom || 'premier vœu'} — ${essai.refus}`);

        if (!cible && e.option_repli_id) {
          essai = tenter(e.option_repli_id, e);
          cible = essai.classe;
          statut = 'accordee_repli';
          optionAccordee = e.option_repli_id;
          if (essai.refus) motifs.push(`${e.repli_nom || 'repli'} — ${essai.refus}`);
        }
        if (!cible) {
          statut = 'sans_place';
          optionAccordee = null;
        }

        if (cible) cible.occupe++;

        // Le motif du refus est conservé sur la ligne d'orientation : sans lui,
        // l'écran ne pourrait afficher que « sans place », ce qui serait faux
        // quand la place existait et que c'est le niveau qui a manqué.
        const motif = (!cible && motifs.length) ? motifs.join(' ; ') : null;
        if (motif) { recalesCritere++; refusesCritere.push({ eleve: nomComplet(e), motif }); }

        await client.query(
          `INSERT INTO orientations (ecole_id, eleve_id, annee_scolaire_id,
                                     option_voeu_id, option_repli_id,
                                     option_accordee_id, classe_affectee_id,
                                     statut, attribue_au_merite, motif, decide_par, decide_at)
           VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,true,$8,$9, now())
           ON CONFLICT (eleve_id, annee_scolaire_id)
           DO UPDATE SET option_accordee_id = EXCLUDED.option_accordee_id,
                         classe_affectee_id = EXCLUDED.classe_affectee_id,
                         statut = EXCLUDED.statut,
                         attribue_au_merite = true,
                         motif = EXCLUDED.motif,
                         decide_par = EXCLUDED.decide_par, decide_at = now()`,
          [e.eleve_id, annee_scolaire_id, e.option_voeu_id || null, e.option_repli_id || null,
           optionAccordee, cible ? cible.id : null, statut, motif, req.auth.userId]
        );

        if (statut === 'accordee_voeu') voeuAccorde++;
        else if (statut === 'accordee_repli') repliAccorde++;
        else sansPlace++;
      }

      return {
        voeuAccorde, repliAccorde, sansPlace, nonPromus,
        recalesCritere, refusesCritere, manuelles: manuelles.length
      };
    });

    let message = `${bilan.voeuAccorde} élève(s) ont obtenu leur premier vœu`;
    if (bilan.repliAccorde > 0) message += `, ${bilan.repliAccorde} leur repli`;
    message += '.';
    if (bilan.sansPlace > 0) {
      message += ` ${bilan.sansPlace} élève(s) restent sans affectation : tranchez au cas par cas.`;
    }
    if (bilan.recalesCritere > 0) {
      message += ` Dont ${bilan.recalesCritere} écarté(s) par un critère d'admission, pas par manque de place.`;
    }
    if (bilan.nonPromus > 0) message += ` ${bilan.nonPromus} non promu(s).`;
    if (bilan.manuelles > 0) message += ` ${bilan.manuelles} affectation(s) manuelle(s) conservée(s).`;

    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur répartition orientation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /orientation/:eleveId
 * Correction manuelle. Elle exige un motif, et laisse une trace distincte
 * de l'attribution au mérite.
 */
async function corrigerAffectation(req, res) {
  const { eleveId } = req.params;
  const { annee_scolaire_id, classe_affectee_id, motif } = req.body;

  if (!annee_scolaire_id) return res.status(400).json({ message: 'annee_scolaire_id est requis.' });
  if (!motif || !String(motif).trim()) {
    return res.status(400).json({
      message: "Une affectation manuelle exige un motif : il distingue une décision pédagogique d'un passe-droit."
    });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleve = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom
         FROM eleves e JOIN classes c ON c.id = e.classe_id
         WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}
           AND c.annee_scolaire_id = $2 AND c.classe_orientation = true`,
        [eleveId, annee_scolaire_id]
      );
      if (eleve.rows.length === 0) {
        throw Object.assign(
          new Error("Cet élève ne fait pas partie d'une classe d'orientation pour cette année."),
          { statusCode: 404 }
        );
      }

      let optionCible = null;
      let nomClasse = null;
      if (classe_affectee_id) {
        const classe = await client.query(
          `SELECT id, nom, option_id, capacite,
                  (SELECT count(*) FROM orientations o WHERE o.classe_affectee_id = classes.id
                    AND o.annee_scolaire_id = $2) AS occupe
           FROM classes WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
          [classe_affectee_id, annee_scolaire_id]
        );
        if (classe.rows.length === 0) {
          throw Object.assign(new Error("Classe d'accueil introuvable."), { statusCode: 400 });
        }
        const c = classe.rows[0];
        // Le dépassement de capacité est autorisé mais signalé : une classe
        // surchargée est un choix assumé, pas un accident.
        optionCible = c.option_id;
        nomClasse = c.nom;
        if (c.capacite !== null && Number(c.occupe) >= Number(c.capacite)) {
          nomClasse += ' (au-delà de la capacité)';
        }
      }

      await client.query(
        `INSERT INTO orientations (ecole_id, eleve_id, annee_scolaire_id,
                                   option_accordee_id, classe_affectee_id, statut,
                                   attribue_au_merite, motif, decide_par, decide_at)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,false,$6,$7, now())
         ON CONFLICT (eleve_id, annee_scolaire_id)
         DO UPDATE SET option_accordee_id = EXCLUDED.option_accordee_id,
                       classe_affectee_id = EXCLUDED.classe_affectee_id,
                       statut = EXCLUDED.statut,
                       attribue_au_merite = false,
                       motif = EXCLUDED.motif,
                       decide_par = EXCLUDED.decide_par, decide_at = now()`,
        [eleveId, annee_scolaire_id, optionCible, classe_affectee_id || null,
         classe_affectee_id ? 'accordee_voeu' : 'sans_place',
         String(motif).trim(), req.auth.userId]
      );

      return `${nomComplet(eleve.rows[0])} affecté${nomClasse ? ' en ' + nomClasse : ''}. Décision enregistrée à votre nom.`;
    });

    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur correction orientation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /orientation/options/:optionId/critere
 * body : { critere_type, critere_cours_id, critere_minimum }
 *
 * Réservé à la direction. Le critère se règle PAR OPTION, pas par école :
 * la Math-Physique peut exiger un niveau en mathématiques pendant que la
 * Pédagogie recrute sur la moyenne générale.
 */
async function definirCritere(req, res) {
  const { optionId } = req.params;
  const { critere_type, critere_cours_id, critere_minimum } = req.body;

  const type = critere_type || 'moyenne_globale';
  if (!CRITERES.includes(type)) {
    return res.status(400).json({ message: "Critère inconnu : choisissez la moyenne générale ou une branche." });
  }

  // `null` explicite = retirer l'exigence. On distingue soigneusement l'absence
  // de valeur d'un zéro : `0 || null` vaut null en JavaScript, piège classique
  // qui transformerait « minimum 0 % » en « aucun minimum ».
  let minimum = null;
  if (critere_minimum !== null && critere_minimum !== undefined && critere_minimum !== '') {
    minimum = Number(critere_minimum);
    if (!Number.isFinite(minimum) || minimum < 0 || minimum > 100) {
      return res.status(400).json({ message: 'Le minimum exigé doit être un pourcentage entre 0 et 100.' });
    }
  }

  if (type === 'branche' && minimum !== null && !critere_cours_id) {
    return res.status(400).json({
      message: "Un critère par branche exige de désigner la branche concernée."
    });
  }

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const option = await client.query(
        `SELECT nom FROM options WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [optionId]
      );
      if (option.rows.length === 0) {
        throw Object.assign(new Error('Option introuvable.'), { statusCode: 404 });
      }

      let nomCours = null;
      const coursRetenu = type === 'branche' ? (critere_cours_id || null) : null;
      if (coursRetenu) {
        const cours = await client.query(
          `SELECT nom FROM cours WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [coursRetenu]
        );
        if (cours.rows.length === 0) {
          throw Object.assign(new Error('Branche introuvable.'), { statusCode: 400 });
        }
        nomCours = cours.rows[0].nom;
      }

      await client.query(
        `UPDATE options
            SET critere_type = $2, critere_cours_id = $3, critere_minimum = $4
          WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [optionId, type, coursRetenu, minimum]
      );

      if (minimum === null) {
        return `Aucun critère d'admission pour « ${option.rows[0].nom} » : tous les élèves promus peuvent la demander.`;
      }
      return type === 'branche'
        ? `« ${option.rows[0].nom} » exige désormais ${minimum} % en ${nomCours}.`
        : `« ${option.rows[0].nom} » exige désormais ${minimum} % de moyenne générale.`;
    });

    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur critère orientation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /orientation/acces
 *
 * Dit simplement si l'utilisateur a quelque chose à faire dans ce module.
 *
 * Le menu de navigation est filtré par une carte de rôles écrite en dur dans
 * chaque page : elle sait qu'un titulaire peut accéder à l'orientation, mais
 * pas si CE titulaire tient une classe d'orientation. Un enseignant de 3e
 * année voyait donc un menu qui ne lui répondait que par un refus.
 *
 * Réponse volontairement minimale : un booléen et un nombre. Aucune donnée
 * d'élève, pour que l'appel puisse être fait au chargement de n'importe quelle
 * page sans exposer quoi que ce soit.
 */
async function acces(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (req.auth.isSuperAdmin
          || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r))) {
        return { autorise: true, portee_complete: true, nb_classes: null };
      }
      if (!req.auth.roles.includes('titulaire')) {
        return { autorise: false, portee_complete: false, nb_classes: 0 };
      }

      const annee = await client.query(
        `SELECT id FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
      );
      if (annee.rows.length === 0) {
        return { autorise: false, portee_complete: false, nb_classes: 0 };
      }

      const r = await client.query(
        `SELECT count(*) AS nb FROM classes
          WHERE ecole_id = ${CURRENT_ECOLE} AND titulaire_id = $1
            AND annee_scolaire_id = $2 AND classe_orientation = true`,
        [req.auth.userId, annee.rows[0].id]
      );
      const nb = Number(r.rows[0].nb);
      return { autorise: nb > 0, portee_complete: false, nb_classes: nb };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur accès orientation:', err);
    // En cas de panne, on n'interdit pas : masquer un menu sur une erreur
    // technique ferait croire à une perte de droits.
    return res.json({ autorise: true, portee_complete: false, nb_classes: null });
  }
}

module.exports = { tableau, enregistrerVoeux, repartir, corrigerAffectation, definirCritere, acces };
