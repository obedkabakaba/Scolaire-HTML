const crypto = require('crypto');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { initierDepot, verifierStatutDepot } = require('../utils/pawapay.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * POST /abonnements/:abonnementId/payer-mobile-money  (Directeur)
 * body: { telephone, provider, methode }
 * - telephone : format international sans "+" (ex: "243812345678")
 * - provider  : code correspondant PawaPay exact (ex: "ORANGE_COD") — à vérifier dans ton
 *               tableau de bord PawaPay, voir la note dans utils/pawapay.utils.js
 * - methode   : 'orange_money' | 'airtel_money' | 'mpesa' (pour nos propres statistiques)
 */
async function initierPaiementMobileMoney(req, res) {
  const { abonnementId } = req.params;
  const { telephone, provider, methode } = req.body;

  if (!telephone || !provider || !methode) {
    return res.status(400).json({ message: 'telephone, provider et methode sont requis.' });
  }
  if (!process.env.PAWAPAY_API_TOKEN) {
    return res.status(500).json({ message: "PAWAPAY_API_TOKEN n'est pas configuré sur le serveur." });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const abonnementResult = await client.query(
        `SELECT a.id, a.ecole_id, a.plan_id, p.prix, p.devise
         FROM abonnements a
         JOIN plans_abonnement p ON p.id = a.plan_id
         WHERE a.id = $1 AND a.ecole_id = ${CURRENT_ECOLE}`,
        [abonnementId]
      );
      if (abonnementResult.rows.length === 0) {
        throw Object.assign(new Error('Abonnement introuvable.'), { statusCode: 404 });
      }
      const abonnement = abonnementResult.rows[0];

      const numeroFacture = `FAC-${Date.now()}`;
      const factureResult = await client.query(
        `INSERT INTO factures (ecole_id, abonnement_id, numero, montant, devise, statut, date_echeance)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, 'en_attente', now())
         RETURNING id`,
        [abonnement.id, numeroFacture, abonnement.prix, abonnement.devise]
      );
      const factureId = factureResult.rows[0].id;

      const depositId = crypto.randomUUID();

      const paiementResult = await client.query(
        `INSERT INTO paiements (ecole_id, facture_id, montant, methode, reference_externe, statut)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, 'en_attente')
         RETURNING id`,
        [factureId, abonnement.prix, methode, depositId]
      );

      return {
        depositId, factureId, paiementId: paiementResult.rows[0].id,
        montant: abonnement.prix, devise: abonnement.devise
      };
    });

    // Appel à PawaPay HORS transaction DB (ne bloque pas la connexion pendant l'appel réseau)
    const reponsePawaPay = await initierDepot({
      depositId: resultat.depositId,
      montant: String(resultat.montant),
      devise: resultat.devise,
      telephone,
      provider,
      reference: resultat.factureId,
      message: 'Abonnement Ardoise'
    });

    if (reponsePawaPay.status === 'REJECTED') {
      await runWithTenant(tenantContextFromReq(req), (client) =>
        client.query(`UPDATE paiements SET statut = 'echoue' WHERE id = $1`, [resultat.paiementId])
      );
      return res.status(400).json({ message: 'Le paiement a été rejeté par PawaPay.' });
    }

    return res.status(202).json({
      message: 'Demande de paiement envoyée. Le client doit confirmer sur son téléphone.',
      depositId: resultat.depositId
    });
  } catch (err) {
    console.error('Erreur initiation paiement PawaPay:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /paiements/webhook-pawapay
 * Endpoint PUBLIC appelé directement par PawaPay (pas d'authentification JWT possible ici).
 * Par sécurité, on ne fait JAMAIS confiance au contenu du callback tel quel : on revérifie
 * le statut réel directement auprès de PawaPay avant d'appliquer le moindre changement.
 */
async function webhookPawaPay(req, res) {
  const { depositId } = req.body;
  if (!depositId) {
    return res.status(400).json({ message: 'depositId manquant.' });
  }

  try {
    const statutReel = await verifierStatutDepot(depositId);
    if (!statutReel) {
      return res.status(200).json({ message: 'Dépôt introuvable côté PawaPay, ignoré.' });
    }

    const paiementResult = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(
        `SELECT p.id, p.ecole_id, p.facture_id, f.abonnement_id
         FROM paiements p
         JOIN factures f ON f.id = p.facture_id
         WHERE p.reference_externe = $1`,
        [depositId]
      )
    );
    if (paiementResult.rows.length === 0) {
      return res.status(200).json({ message: 'Paiement local introuvable, ignoré.' });
    }
    const paiement = paiementResult.rows[0];

    if (statutReel.status === 'COMPLETED') {
      await runWithTenant({ isSuperAdmin: true }, async (client) => {
        await client.query(`UPDATE paiements SET statut = 'confirme' WHERE id = $1`, [paiement.id]);
        await client.query(`UPDATE factures SET statut = 'payee' WHERE id = $1`, [paiement.facture_id]);

        const abonnementResult = await client.query(
          `SELECT a.id, a.ecole_id, a.periodicite, a.date_expiration, p.duree_jours
           FROM abonnements a JOIN plans_abonnement p ON p.id = a.plan_id
           WHERE a.id = $1`,
          [paiement.abonnement_id]
        );
        const abonnement = abonnementResult.rows[0];
        if (abonnement) {
          // Deux corrections, pour les mêmes raisons que dans
          // abonnements.controller.js — le chemin Mobile Money les avait
          // toutes les deux, et c'est le chemin le plus emprunté :
          //
          //   · la durée suit la PÉRIODICITÉ, pas le `duree_jours` du plan,
          //     qui vaut 30 pour les quatre offres. Une école réglant l'année
          //     par Mobile Money voyait sa plateforme expirer un mois plus tard.
          //   · le décompte repart de l'échéance EN COURS si elle n'est pas
          //     atteinte, et de maintenant sinon. L'ancien calcul partait
          //     toujours de `Date.now()` : renouveler deux semaines à l'avance
          //     faisait perdre ces deux semaines, déjà payées.
          const catalogue = require('../utils/catalogue.utils');
          const joursAjoutes = catalogue.joursDePeriodicite(
            abonnement.periodicite, abonnement.duree_jours);

          const maintenant = new Date();
          const expirationActuelle = abonnement.date_expiration
            ? new Date(abonnement.date_expiration) : null;
          const pointDeDepart = (expirationActuelle && expirationActuelle > maintenant)
            ? expirationActuelle : maintenant;

          const nouvelleExpiration =
            new Date(pointDeDepart.getTime() + joursAjoutes * 24 * 60 * 60 * 1000);
          await client.query(
            `UPDATE abonnements SET statut = 'actif', date_expiration = $1, updated_at = now() WHERE id = $2`,
            [nouvelleExpiration, abonnement.id]
          );
          await client.query(`UPDATE ecoles SET statut = 'actif' WHERE id = $1`, [abonnement.ecole_id]);
          await client.query(
            `INSERT INTO journal_activite (ecole_id, action, cible_type, cible_id, metadata)
             VALUES ($1, 'abonnement.paiement_confirme_mobile_money', 'abonnement', $2, $3)`,
            [abonnement.ecole_id, abonnement.id,
             JSON.stringify({ depositId,
                              periodicite: abonnement.periodicite,
                              jours_ajoutes: joursAjoutes })]
          );
        }
      });

      // L'école vient peut-être d'être réactivée : le catalogue ne doit pas
      // continuer à répondre « aucun abonnement actif » pendant une minute.
      require('../utils/catalogue.utils').invaliderCache();
    } else if (['FAILED', 'REJECTED'].includes(statutReel.status)) {
      await runWithTenant({ isSuperAdmin: true }, (client) =>
        client.query(`UPDATE paiements SET statut = 'echoue' WHERE id = $1`, [paiement.id])
      );
    }

    return res.status(200).json({ message: 'Callback traité.' });
  } catch (err) {
    console.error('Erreur webhook PawaPay:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { initierPaiementMobileMoney, webhookPawaPay };
