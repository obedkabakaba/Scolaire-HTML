const { runWithTenant } = require('../config/db');
const { sqlMaximumApplicable } = require('../utils/bareme.utils');
const { sqlTotalFraisDus } = require('../utils/frais.utils');
const { lireConfigMonetaire, sqlPaiementConverti } = require('../utils/devise.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  PARCOURS D'UN ÉLÈVE — vue transversale
 * ===========================================================================
 *
 * LE BESOIN
 * ---------
 * La fiche d'un élève montrait son identité et rien d'autre. Pour savoir
 * comment il travaille, s'il est assidu, s'il a des soucis de discipline ou
 * d'écolage, il fallait ouvrir quatre écrans, y retrouver la bonne classe, la
 * bonne période, puis l'élève parmi trois cents.
 *
 * Cet endpoint rassemble ce qui le concerne, sans le détail : des CHIFFRES et
 * des points d'entrée. Le détail reste dans les écrans spécialisés, qui savent
 * l'afficher et le modifier. Dupliquer ici la saisie des notes ou l'appel
 * produirait deux endroits où faire la même chose, qui divergeraient.
 *
 * CE QU'IL NE FAIT PAS
 * --------------------
 * Il ne remplace aucun écran et n'autorise aucune modification. C'est une vue
 * de lecture, qui répond à « où en est cet enfant ? » et renvoie ensuite au
 * bon endroit.
 */

async function parcoursEleve(req, res) {
  const { id } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleveResult = await client.query(
        `SELECT e.id, e.matricule, e.nom, e.postnom, e.prenom, e.sexe,
                e.date_naissance, e.statut::text, e.classe_id,
                e.motif_sortie, e.date_sortie,
                c.nom AS classe_nom, c.annee_scolaire_id,
                a.libelle AS annee_libelle
           FROM eleves e
           LEFT JOIN classes c ON c.id = e.classe_id
           LEFT JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
          WHERE e.id = $1 AND e.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (eleveResult.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      const eleve = eleveResult.rows[0];
      const anneeId = eleve.annee_scolaire_id;

      // Un élève sans classe n'a pas d'année de rattachement : tout le reste
      // serait vide. On le dit plutôt que de renvoyer des zéros, qui se
      // liraient comme de mauvais résultats.
      if (!anneeId) {
        return {
          eleve: formaterEleve(eleve),
          sans_classe: true,
          message: "Cet élève n'est rattaché à aucune classe : son parcours ne peut pas être établi."
        };
      }

      const periodes = await client.query(
        `SELECT id, libelle, numero, type::text AS type, cloturee
           FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen')
          ORDER BY numero`,
        [anneeId]
      );

      // Moyennes calculées depuis les NOTES, par la même fonction que les
      // rapports et le tableau de bord. Lire `bulletins.pourcentage` ici
      // donnerait un troisième chiffre différent des deux autres.
      const parPeriode = [];
      for (const p of periodes.rows) {
        const lignes = await pourcentagesParEleve(client, anneeId, {
          type: 'periode', periodeIds: [p.id]
        });
        const sien = lignes.find((l) => l.eleve_id === id);
        parPeriode.push({
          periode_id: p.id, libelle: p.libelle, type: p.type, cloturee: p.cloturee,
          pourcentage: sien ? sien.pourcentage : null,
          total_obtenu: sien ? sien.total_obtenu : null,
          total_maxima: sien ? sien.total_maxima : null,
          // Le rang se calcule dans la classe, pas dans l'école : c'est ce que
          // l'élève et sa famille comparent.
          rang: sien ? rangDans(lignes, sien, eleve.classe_id) : null,
          effectif_classe: lignes.filter((l) => l.classe_id === eleve.classe_id).length
        });
      }

      const annuel = await pourcentagesParEleve(client, anneeId, {
        type: 'annuel', periodeIds: periodes.rows.map((p) => p.id)
      });
      const sienAnnuel = annuel.find((l) => l.eleve_id === id) || null;

      // ---------- Présences ----------
      const presences = await client.query(
        `SELECT statut::text, count(*) AS nb
           FROM presences
          WHERE ecole_id = ${CURRENT_ECOLE} AND eleve_id = $1
          GROUP BY statut`,
        [id]
      );
      const compteur = {};
      for (const p of presences.rows) compteur[p.statut] = Number(p.nb);
      const totalAppels = Object.values(compteur).reduce((t, n) => t + n, 0);

      // ---------- Discipline ----------
      const discipline = await client.query(
        `SELECT count(*) FILTER (WHERE sens IS DISTINCT FROM 'positif') AS fautes,
                count(*) FILTER (WHERE sens = 'positif') AS positifs,
                COALESCE(SUM(points) FILTER (WHERE sens IS DISTINCT FROM 'positif'), 0) AS points_perdus,
                COALESCE(SUM(points) FILTER (WHERE sens = 'positif'), 0) AS points_gagnes,
                max(date_incident) AS dernier
           FROM incidents_discipline
          WHERE ecole_id = ${CURRENT_ECOLE} AND eleve_id = $1 AND annee_scolaire_id = $2`,
        [id, anneeId]
      );

      // ---------- Frais ----------
      // Deux défauts cumulés sur ces deux requêtes, qui produisaient une
      // situation financière fausse dans les DEUX sens :
      //
      //   · `SUM(f.montant)` additionnait la ligne générale ET la ligne propre
      //     à la classe pour un même libellé. Un minerval général de 100
      //     ajusté à 120 pour la 6e A était réclamé 220. La règle du projet
      //     (utils/frais.utils.js) est qu'une ligne de classe REMPLACE la
      //     ligne générale du même nom.
      //   · Aucune conversion de devise : des montants en FC et en USD étaient
      //     additionnés bruts, des deux côtés. 200 USD + 50 000 FC donnait
      //     « 50 200 ». Les versements retenaient en plus les lignes
      //     `annee_scolaire_id IS NULL`, donc d'autres années.
      const { devise_principale: deviseFiche, taux_change_usd_fc: tauxFiche } =
        await lireConfigMonetaire(client);

      const frais = await client.query(
        `SELECT ${sqlTotalFraisDus('$2', '$1', '$3', 4, CURRENT_ECOLE)} AS du`,
        [anneeId, eleve.classe_id, deviseFiche, tauxFiche || null]
      );
      const paye = await client.query(
        `SELECT COALESCE(SUM(${sqlPaiementConverti('p', '$3', 4)}), 0) AS paye,
                count(*) AS nb, max(p.date_paiement) AS dernier
           FROM paiements_frais p
          WHERE p.ecole_id = ${CURRENT_ECOLE} AND p.eleve_id = $1
            AND p.annee_scolaire_id = $2`,
        [id, anneeId, deviseFiche, tauxFiche || null]
      );

      // ---------- Bulletins ----------
      const bulletins = await client.query(
        `SELECT b.id, b.periode_id, p.libelle AS periode_libelle,
                b.pourcentage, b.classement, b.mention, b.conduite,
                b.signe_at IS NOT NULL AS signe
           FROM bulletins b
           LEFT JOIN periodes p ON p.id = b.periode_id
          WHERE b.ecole_id = ${CURRENT_ECOLE} AND b.eleve_id = $1
            AND (b.annee_scolaire_id = $2 OR b.periode_id IN (
              SELECT id FROM periodes WHERE annee_scolaire_id = $2))
          ORDER BY p.numero NULLS LAST`,
        [id, anneeId]
      );

      // ---------- Parcours des années antérieures ----------
      const historique = await client.query(
        `SELECT h.annee_scolaire_id, a.libelle AS annee_libelle,
                c.nom AS classe_nom, h.resultat_final
           FROM eleve_classe_historique h
           LEFT JOIN annees_scolaires a ON a.id = h.annee_scolaire_id
           LEFT JOIN classes c ON c.id = h.classe_id
          WHERE h.ecole_id = ${CURRENT_ECOLE} AND h.eleve_id = $1
          ORDER BY a.date_debut DESC NULLS LAST`,
        [id]
      );

      const d = discipline.rows[0];
      const montantDu = Number(frais.rows[0].du);
      const montantPaye = Number(paye.rows[0].paye);

      return {
        eleve: formaterEleve(eleve),
        annee: { id: anneeId, libelle: eleve.annee_libelle },
        scolarite: {
          par_periode: parPeriode,
          moyenne_annuelle: sienAnnuel ? sienAnnuel.pourcentage : null,
          // Distinguer « aucune note » de « moyenne nulle » : ce sont deux
          // situations opposées, et elles s'afficheraient pareil.
          aucune_note: !sienAnnuel
        },
        presences: {
          total: totalAppels,
          present: compteur.present || 0,
          absent: compteur.absent || 0,
          retard: compteur.retard || 0,
          justifie: compteur.justifie || 0,
          taux_presence: totalAppels > 0
            ? Math.round(((compteur.present || 0) + (compteur.justifie || 0)) / totalAppels * 1000) / 10
            : null
        },
        discipline: {
          nb_fautes: Number(d.fautes),
          nb_positifs: Number(d.positifs),
          points_perdus: Number(d.points_perdus),
          points_gagnes: Number(d.points_gagnes),
          dernier_incident: d.dernier
        },
        frais: {
          montant_du: montantDu,
          montant_paye: montantPaye,
          solde: Math.max(montantDu - montantPaye, 0),
          nb_paiements: Number(paye.rows[0].nb),
          dernier_paiement: paye.rows[0].dernier,
          en_regle: montantPaye >= montantDu
        },
        bulletins: bulletins.rows.map((b) => ({
          ...b, pourcentage: b.pourcentage === null ? null : Number(b.pourcentage)
        })),
        historique: historique.rows
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur parcours élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}


/*
 * ===========================================================================
 *  FICHE D'UNE CLASSE
 * ===========================================================================
 *
 * Répond à « où en est cette classe ? » : effectif, résultats, assiduité,
 * climat, écolage. Même principe que le parcours d'un élève — des chiffres et
 * des points d'entrée, jamais le détail ni la modification.
 */
async function ficheClasse(req, res) {
  const { id } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(
        `SELECT c.id, c.nom, c.niveau, c.division, c.cycle::text AS cycle, c.capacite,
                c.classe_orientation, c.classe_terminale, c.annee_scolaire_id,
                s.nom AS section_nom, o.nom AS option_nom, v.nom AS vacation_nom,
                cs.nom AS classe_suivante_nom,
                trim(concat(u.prenom, ' ', u.nom)) AS titulaire_nom, u.id AS titulaire_id,
                a.libelle AS annee_libelle,
                mp.nom AS modele_periode_nom, ma.nom AS modele_annuel_nom
           FROM classes c
           LEFT JOIN sections s ON s.id = c.section_id
           LEFT JOIN options o ON o.id = c.option_id
           LEFT JOIN vacations v ON v.id = c.vacation_id
           LEFT JOIN classes cs ON cs.id = c.classe_suivante_id
           LEFT JOIN utilisateurs u ON u.id = c.titulaire_id
           LEFT JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
           LEFT JOIN modeles_bulletins mp ON mp.id = c.modele_periode_id
           LEFT JOIN modeles_bulletins ma ON ma.id = c.modele_annuel_id
          WHERE c.id = $1 AND c.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      const classe = classeResult.rows[0];
      const anneeId = classe.annee_scolaire_id;

      const effectif = await client.query(
        `SELECT count(*) FILTER (WHERE statut = 'actif') AS actifs,
                count(*) FILTER (WHERE statut = 'actif' AND sexe = 'M') AS garcons,
                count(*) FILTER (WHERE statut = 'actif' AND sexe = 'F') AS filles,
                count(*) FILTER (WHERE statut <> 'actif') AS partis
           FROM eleves WHERE classe_id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );

      const cours = await client.query(
        `SELECT co.id, co.nom, co.code,
                COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum,
                COALESCE(
                  json_agg(DISTINCT trim(concat(u.prenom, ' ', u.nom)))
                    FILTER (WHERE u.id IS NOT NULL), '[]'
                ) AS enseignants
           FROM classe_cours cc
           JOIN cours co ON co.id = cc.cours_id
           LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
           LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
          WHERE cc.classe_id = $1 AND cc.ecole_id = ${CURRENT_ECOLE}
          GROUP BY co.id, co.nom, co.code, cc.maximum_points_override, co.maximum_points
          ORDER BY co.nom`,
        [id]
      );

      // Résultats par période, restreints à cette classe.
      let parPeriode = [];
      let moyenneAnnuelle = null;
      if (anneeId) {
        const periodes = await client.query(
          `SELECT id, libelle, numero, cloturee FROM periodes
            WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
              AND type::text IN ('periode', 'examen') ORDER BY numero`,
          [anneeId]
        );
        for (const p of periodes.rows) {
          const lignes = (await pourcentagesParEleve(client, anneeId, {
            type: 'periode', periodeIds: [p.id]
          })).filter((l) => l.classe_id === id);
          parPeriode.push({
            periode_id: p.id, libelle: p.libelle, cloturee: p.cloturee,
            nb_eleves_notes: lignes.length,
            moyenne: lignes.length
              ? Math.round(lignes.reduce((t, l) => t + l.pourcentage, 0) / lignes.length * 10) / 10
              : null,
            mini: lignes.length ? Math.min(...lignes.map((l) => l.pourcentage)) : null,
            maxi: lignes.length ? Math.max(...lignes.map((l) => l.pourcentage)) : null
          });
        }
        const annuel = (await pourcentagesParEleve(client, anneeId, {
          type: 'annuel', periodeIds: periodes.rows.map((p) => p.id)
        })).filter((l) => l.classe_id === id);
        moyenneAnnuelle = annuel.length
          ? Math.round(annuel.reduce((t, l) => t + l.pourcentage, 0) / annuel.length * 10) / 10
          : null;
      }

      const presences = await client.query(
        `SELECT statut::text, count(*) AS nb FROM presences
          WHERE classe_id = $1 AND ecole_id = ${CURRENT_ECOLE} GROUP BY statut`,
        [id]
      );
      const compteur = {};
      for (const p of presences.rows) compteur[p.statut] = Number(p.nb);
      const totalAppels = Object.values(compteur).reduce((t, n) => t + n, 0);

      const discipline = await client.query(
        `SELECT count(*) FILTER (WHERE sens IS DISTINCT FROM 'positif') AS fautes,
                count(*) FILTER (WHERE sens = 'positif') AS positifs,
                count(DISTINCT eleve_id) FILTER (WHERE sens IS DISTINCT FROM 'positif') AS eleves_concernes
           FROM incidents_discipline
          WHERE classe_id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );

      const seances = await client.query(
        `SELECT count(*) AS nb FROM emploi_du_temps
          WHERE classe_id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );

      const eff = effectif.rows[0];
      const d = discipline.rows[0];
      const actifs = Number(eff.actifs);

      return {
        classe: {
          id: classe.id, nom: classe.nom, niveau: classe.niveau, division: classe.division,
          cycle: classe.cycle, capacite: classe.capacite === null ? null : Number(classe.capacite),
          section_nom: classe.section_nom, option_nom: classe.option_nom,
          vacation_nom: classe.vacation_nom, titulaire_nom: classe.titulaire_nom,
          titulaire_id: classe.titulaire_id, annee_libelle: classe.annee_libelle,
          classe_suivante_nom: classe.classe_suivante_nom,
          classe_orientation: classe.classe_orientation, classe_terminale: classe.classe_terminale,
          modele_periode_nom: classe.modele_periode_nom, modele_annuel_nom: classe.modele_annuel_nom
        },
        // Les défauts de configuration sont remontés ICI plutôt que découverts
        // en fin d'année : ce sont eux qui bloquent la promotion et les
        // bulletins, et rien ne les signalait.
        alertes: [
          classe.niveau === null
            ? "Aucun niveau renseigné : la promotion de fin d'année ne pourra pas s'exécuter."
            : null,
          !classe.titulaire_id ? 'Aucun titulaire désigné.' : null,
          cours.rows.length === 0 ? 'Aucun cours rattaché : aucune note ne peut être saisie.' : null,
          !classe.modele_periode_nom ? 'Aucun modèle de bulletin de période affecté.' : null,
          classe.capacite !== null && actifs > Number(classe.capacite)
            ? `Effectif (${actifs}) supérieur à la capacité (${classe.capacite}).` : null,
          cours.rows.filter((c) => (c.enseignants || []).length === 0).length > 0
            ? `${cours.rows.filter((c) => (c.enseignants || []).length === 0).length} cours sans enseignant affecté.`
            : null
        ].filter(Boolean),
        effectif: {
          actifs, garcons: Number(eff.garcons), filles: Number(eff.filles),
          partis: Number(eff.partis),
          places_restantes: classe.capacite === null ? null : Math.max(Number(classe.capacite) - actifs, 0)
        },
        cours: cours.rows.map((c) => ({ ...c, maximum: Number(c.maximum) })),
        resultats: { par_periode: parPeriode, moyenne_annuelle: moyenneAnnuelle },
        presences: {
          total: totalAppels,
          absent: compteur.absent || 0, retard: compteur.retard || 0,
          taux_presence: totalAppels > 0
            ? Math.round(((compteur.present || 0) + (compteur.justifie || 0)) / totalAppels * 1000) / 10
            : null
        },
        discipline: {
          nb_fautes: Number(d.fautes), nb_positifs: Number(d.positifs),
          eleves_concernes: Number(d.eleves_concernes)
        },
        emploi_du_temps: { nb_seances: Number(seances.rows[0].nb) }
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur fiche classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/*
 * ===========================================================================
 *  FICHE D'UN COURS
 * ===========================================================================
 *
 * Répond à « comment se passe cette matière ? ». Le taux de réussite PAR
 * PÉRIODE et PAR CLASSE est l'information qu'aucun écran ne donnait : un cours
 * peut se passer correctement en 5e A et s'effondrer en 5e B, et la moyenne
 * générale du cours masque exactement cela.
 */
async function ficheCours(req, res) {
  const { id } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const coursResult = await client.query(
        `SELECT id, nom, code, maximum_points, maximum_examen, domaine, groupe_domaine, coefficient
           FROM cours WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (coursResult.rows.length === 0) {
        throw Object.assign(new Error('Cours introuvable.'), { statusCode: 404 });
      }
      const cours = coursResult.rows[0];

      const annee = await client.query(
        `SELECT id, libelle FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
      );
      if (annee.rows.length === 0) {
        return { cours, sans_annee: true, message: "Aucune année scolaire active : les résultats ne peuvent pas être calculés." };
      }
      const anneeId = annee.rows[0].id;

      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuil = Number(seuilResult.rows[0].seuil);

      const periodes = await client.query(
        `SELECT id, libelle, numero, type::text AS type, cloturee FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen') ORDER BY numero`,
        [anneeId]
      );

      // Réussite par période ET par classe. Le calcul se fait sur le cours
      // seul : total obtenu dans CE cours sur son maximum, pas sur l'ensemble
      // des matières.
      const resultats = await client.query(
        `SELECT n.periode_id, cl.id AS classe_id, cl.nom AS classe_nom,
                p.type::text AS periode_type,
                count(*) FILTER (WHERE n.points_obtenus IS NOT NULL) AS nb_notes,
                SUM(n.points_obtenus) AS obtenus,
                -- Barème : voir utils/bareme.utils.js.
                SUM(${sqlMaximumApplicable('cc', 'co', 'p.type::text')}) AS maxima,
                count(*) FILTER (
                  WHERE n.points_obtenus IS NOT NULL
                    AND n.points_obtenus >= (${sqlMaximumApplicable('cc', 'co', 'p.type::text')}) * $3 / 100.0
                ) AS nb_reussites
           FROM notes n
           JOIN classe_cours cc ON cc.id = n.classe_cours_id
           JOIN cours co ON co.id = cc.cours_id
           JOIN classes cl ON cl.id = cc.classe_id
           JOIN periodes p ON p.id = n.periode_id
          WHERE cc.cours_id = $1 AND n.ecole_id = ${CURRENT_ECOLE}
            AND p.annee_scolaire_id = $2
          GROUP BY n.periode_id, cl.id, cl.nom, p.type
          ORDER BY cl.nom`,
        [id, anneeId, seuil]
      );

      const parPeriode = periodes.rows.map((p) => {
        const lignes = resultats.rows.filter((r) => r.periode_id === p.id);
        const obtenus = lignes.reduce((t, l) => t + Number(l.obtenus || 0), 0);
        const maxima = lignes.reduce((t, l) => t + Number(l.maxima || 0), 0);
        const notes = lignes.reduce((t, l) => t + Number(l.nb_notes), 0);
        const reussites = lignes.reduce((t, l) => t + Number(l.nb_reussites), 0);
        return {
          periode_id: p.id, libelle: p.libelle, type: p.type, cloturee: p.cloturee,
          nb_notes: notes,
          moyenne: maxima > 0 ? Math.round(obtenus / maxima * 1000) / 10 : null,
          taux_reussite: notes > 0 ? Math.round(reussites / notes * 1000) / 10 : null,
          par_classe: lignes.map((l) => ({
            classe_id: l.classe_id, classe_nom: l.classe_nom,
            nb_notes: Number(l.nb_notes),
            moyenne: Number(l.maxima) > 0
              ? Math.round(Number(l.obtenus) / Number(l.maxima) * 1000) / 10 : null,
            taux_reussite: Number(l.nb_notes) > 0
              ? Math.round(Number(l.nb_reussites) / Number(l.nb_notes) * 1000) / 10 : null
          }))
        };
      });

      const classes = await client.query(
        `SELECT cl.id, cl.nom,
                COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum,
                COALESCE(
                  json_agg(DISTINCT trim(concat(u.prenom, ' ', u.nom)))
                    FILTER (WHERE u.id IS NOT NULL), '[]'
                ) AS enseignants
           FROM classe_cours cc
           JOIN cours co ON co.id = cc.cours_id
           JOIN classes cl ON cl.id = cc.classe_id
           LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
           LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
          WHERE cc.cours_id = $1 AND cc.ecole_id = ${CURRENT_ECOLE}
            AND cl.annee_scolaire_id = $2
          GROUP BY cl.id, cl.nom, cc.maximum_points_override, co.maximum_points
          ORDER BY cl.nom`,
        [id, anneeId]
      );

      return {
        cours: {
          ...cours,
          maximum_points: Number(cours.maximum_points),
          maximum_examen: cours.maximum_examen === null ? null : Number(cours.maximum_examen)
        },
        annee: annee.rows[0],
        seuil,
        classes: classes.rows.map((c) => ({ ...c, maximum: Number(c.maximum) })),
        resultats: parPeriode,
        alertes: [
          classes.rows.length === 0
            ? "Ce cours n'est rattaché à aucune classe de l'année active." : null,
          cours.maximum_examen === null
            ? "Aucun maximum d'examen : ce cours comptera pour zéro sur les périodes d'examen."
            : null,
          classes.rows.filter((c) => (c.enseignants || []).length === 0).length > 0
            ? `${classes.rows.filter((c) => (c.enseignants || []).length === 0).length} classe(s) sans enseignant pour ce cours.`
            : null
        ].filter(Boolean)
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur fiche cours:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

function formaterEleve(e) {
  return {
    id: e.id, matricule: e.matricule,
    nom_complet: [e.nom, e.postnom, e.prenom].filter(Boolean).join(' '),
    sexe: e.sexe, date_naissance: e.date_naissance,
    statut: e.statut, motif_sortie: e.motif_sortie, date_sortie: e.date_sortie,
    classe_id: e.classe_id, classe_nom: e.classe_nom
  };
}

/** Rang de l'élève dans SA classe, à égalité partagée. */
function rangDans(lignes, sien, classeId) {
  const classe = lignes
    .filter((l) => l.classe_id === classeId)
    .sort((a, b) => b.pourcentage - a.pourcentage);
  // Les ex æquo partagent le même rang : deux élèves à 78 % sont tous deux
  // troisièmes, et le suivant est cinquième. Un classement strict par position
  // en désignerait un « meilleur » sans raison.
  const meilleurs = classe.filter((l) => l.pourcentage > sien.pourcentage).length;
  return meilleurs + 1;
}

module.exports = { parcoursEleve, ficheClasse, ficheCours };
