const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { estJourOuvrable } = require('../utils/calendrier.utils');
const { verifierClasseActive } = require('../utils/annee.utils');
const { notifierEvenement, planifierVidage } = require('../utils/notifications.service');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const STATUTS = ['present', 'absent', 'retard', 'excuse'];

/**
 * Le personnel de direction et le secrétariat voient toutes les classes.
 * Un titulaire est strictement limité à la ou aux classes dont il est titulaire.
 * Dans tous les cas, la classe doit appartenir à l'année scolaire ACTIVE :
 * un titulaire resté rattaché à une ancienne classe (clôturée ou simplement
 * plus active) ne doit plus pouvoir y faire ou consulter l'appel.
 */
/**
 * Qui a le droit de faire l'appel dans cette classe ?
 *
 * Le mode est choisi par le directeur (`ecoles.mode_presences`) parce que les
 * organisations réelles diffèrent : au primaire un maître unique tient sa
 * classe toute la journée, au secondaire les professeurs se succèdent, et
 * certaines écoles confient l'appel à une personne dédiée.
 *
 *   'titulaire'  → le titulaire de la classe seulement (défaut, adapté au primaire)
 *   'professeur' → tout professeur assigné à un cours de cette classe
 *   'charge'     → l'utilisateur portant le rôle charge_presences
 *
 * Consultation (lecture) : directeur, préfet, secrétariat et directeur de
 * discipline voient toutes les classes dans TOUS les modes.
 *
 * Écriture (faire ou corriger l'appel) : le directeur et le préfet n'ont PAS
 * ce droit — ils pilotent et consultent, mais ne saisissent pas l'appel à la
 * place de celui qui a réellement la classe sous les yeux. Seuls gardent
 * l'accès en écriture, quel que soit le mode :
 *   - le secrétariat, pour remplacer un titulaire absent ou rattraper un appel
 *     manqué ;
 *   - le directeur de discipline, parce que corriger une fiche fait partie de
 *     son suivi.
 * Si un directeur ou un préfet est PAR AILLEURS professeur d'un cours de
 * cette classe, il garde la main comme n'importe quel professeur (mode
 * 'professeur') — c'est la branche normale ci-dessous qui s'en charge, sans
 * bypass particulier.
 *
 * Le directeur de discipline reste par ailleurs, avec le chargé des
 * présences, le seul rôle à qui le menu reste offert en mode 'charge'.
 */
async function verifierAccesClasse(client, req, classeId, { estEcriture = false } = {}) {
  const roles = req.auth.roles || [];
  const rolesBypass = estEcriture
    ? ['secretaire', 'directeur_discipline']
    : ['directeur', 'prefet', 'secretaire', 'directeur_discipline'];
  const estDirection = req.auth.isSuperAdmin || roles.some((r) => rolesBypass.includes(r));

  if (!estDirection) {
    const ecole = await client.query(
      `SELECT COALESCE(mode_presences, 'titulaire') AS mode FROM ecoles WHERE id = ${CURRENT_ECOLE}`
    );
    const mode = ecole.rows[0]?.mode || 'titulaire';

    let autorise = false;
    let messageRefus = "Vous n'êtes pas titulaire de cette classe.";

    if (mode === 'charge') {
      // Le mode est exclusif, et c'est tout son intérêt : une école qui le
      // choisit veut UNE personne responsable de l'appel de toutes les salles,
      // pas un partage avec les titulaires. Le titulaire conservait auparavant
      // sa propre classe en repli ; ce repli est retiré, car il rendait la
      // responsabilité floue — deux personnes pouvaient saisir la même feuille
      // sans savoir qui devait le faire. La direction, elle, garde l'accès
      // ci-dessus pour corriger une erreur.
      autorise = roles.includes('charge_presences');
      messageRefus = "Dans cette école, seul le chargé des présences fait l'appel.";
    } else if (mode === 'professeur') {
      // Assigné à au moins un cours de cette classe — pas seulement titulaire.
      const r = await client.query(
        `SELECT 1
           FROM enseignant_cours ec
           JOIN classe_cours cc ON cc.id = ec.classe_cours_id
          WHERE cc.classe_id = $1 AND ec.utilisateur_id = $2
          LIMIT 1`,
        [classeId, req.auth.userId]
      );
      autorise = r.rows.length > 0;
      if (!autorise) {
        const t = await client.query(
          `SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`, [classeId, req.auth.userId]
        );
        autorise = t.rows.length > 0;
      }
      messageRefus = "Vous n'enseignez aucun cours dans cette classe.";
    } else {
      const r = await client.query(
        `SELECT 1 FROM classes WHERE id = $1 AND titulaire_id = $2`,
        [classeId, req.auth.userId]
      );
      autorise = r.rows.length > 0;
    }

    if (!autorise) {
      throw Object.assign(new Error(messageRefus), { statusCode: 403 });
    }
  }

  await verifierClasseActive(client, classeId);
}

/**
 * En mode 'professeur', l'appel du jour appartient au premier qui le fait.
 *
 * Sans cette règle, chaque professeur passant dans la classe réécrirait
 * l'appel : le dernier de la journée écraserait tous les précédents, et un
 * élève arrivé en retard le matin apparaîtrait présent toute la journée. Une
 * modification reste possible — un retard se constate en cours de journée —
 * mais elle exige un motif, ce qui distingue la correction délibérée de
 * l'écrasement machinal.
 *
 * @returns {Promise<{dejaFait: boolean, auteur: string|null, estAuteur: boolean}>}
 */
async function etatAppelDuJour(client, req, classeId, date) {
  const r = await client.query(
    `SELECT p.saisi_par, COALESCE(p.saisi_par_initial, p.saisi_par) AS auteur_initial,
            trim(concat(u.prenom, ' ', u.nom)) AS auteur_nom
       FROM presences p
       LEFT JOIN utilisateurs u ON u.id = COALESCE(p.saisi_par_initial, p.saisi_par)
      WHERE p.classe_id = $1 AND p.date_jour = $2
      LIMIT 1`,
    [classeId, date]
  );
  if (r.rows.length === 0) return { dejaFait: false, auteur: null, estAuteur: false, auteurId: null };
  const ligne = r.rows[0];
  return {
    dejaFait: true,
    auteur: ligne.auteur_nom || null,
    auteurId: ligne.auteur_initial,
    estAuteur: String(ligne.auteur_initial) === String(req.auth.userId)
  };
}

/** Renvoie la date du jour au format AAAA-MM-JJ, sans dépendance à un fuseau. */
function aujourdhui() {
  return new Date().toISOString().slice(0, 10);
}

function dateValide(valeur) {
  return typeof valeur === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(valeur) && !isNaN(new Date(valeur).getTime());
}

/**
 * GET /presences/classe/:classeId?date=AAAA-MM-JJ
 * Feuille d'appel d'une classe pour une journée : tous les élèves actifs,
 * avec leur statut déjà enregistré s'il existe.
 */
async function feuilleAppel(req, res) {
  const { classeId } = req.params;
  const date = req.query.date || aujourdhui();

  if (!dateValide(date)) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);

      const classeResult = await client.query(
        `SELECT id, nom FROM classes WHERE id = $1`, [classeId]
      );
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }

      const elevesResult = await client.query(
        `SELECT e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                p.statut, p.motif, p.updated_at AS saisi_le
         FROM eleves e
         LEFT JOIN presences p ON p.eleve_id = e.id AND p.date_jour = $2
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         ORDER BY e.nom, e.postnom, e.prenom`,
        [classeId, date]
      );

      // Un appel est considéré comme fait dès qu'au moins un élève a un statut.
      const dejaFait = elevesResult.rows.some((l) => l.statut !== null);

      return {
        classe: classeResult.rows[0],
        date,
        deja_fait: dejaFait,
        eleves: elevesResult.rows
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur feuille appel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /presences/classe/:classeId
 * Enregistre l'appel du jour. Tout le lot est validé avant la moindre écriture :
 * soit l'appel entier est enregistré, soit rien ne l'est.
 */
async function enregistrerAppel(req, res) {
  const { classeId } = req.params;
  const { date, presences, motif_modification } = req.body;

  if (!dateValide(date)) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }
  if (!Array.isArray(presences) || presences.length === 0) {
    return res.status(400).json({ message: "Aucune présence à enregistrer." });
  }
  // On ne fait pas l'appel d'une journée qui n'a pas eu lieu.
  if (date > aujourdhui()) {
    return res.status(400).json({ message: "Impossible de faire l'appel pour une date future." });
  }

  try {
    const resume = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId, { estEcriture: true });

      // ---------- Le calendrier scolaire fait foi ----------
      //
      // Faire l'appel un dimanche, un jour férié ou pendant les vacances
      // produit des absences qui n'ont aucun sens : elles gonflent ensuite les
      // statistiques d'assiduité et peuvent faire convoquer les parents d'un
      // élève qui n'avait tout simplement pas classe ce jour-là.
      //
      // Le cycle de la classe est transmis : un congé peut ne concerner qu'un
      // cycle (session d'examens du secondaire pendant que le primaire
      // travaille normalement).
      const classeInfo = await client.query(
        `SELECT cycle::text AS cycle FROM classes WHERE id = $1`,
        [classeId]
      );
      const verdict = await estJourOuvrable(client, date, { cycle: classeInfo.rows[0]?.cycle || null });
      if (!verdict.ouvrable) {
        throw Object.assign(
          new Error(`${verdict.message} L'appel n'y est pas possible.`),
          { statusCode: 409, motif: verdict.motif }
        );
      }

      // ---------- Un seul appel par jour, en mode 'professeur' ----------
      const ecoleMode = await client.query(
        `SELECT COALESCE(mode_presences, 'titulaire') AS mode FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const mode = ecoleMode.rows[0]?.mode || 'titulaire';
      const etat = await etatAppelDuJour(client, req, classeId, date);

      // La règle ne s'applique qu'aux professeurs entre eux : le secrétariat
      // et le directeur de discipline corrigent sans justification (c'est
      // leur rôle d'arbitrer), et l'auteur de l'appel peut revenir sur sa
      // propre saisie librement. Le directeur et le préfet ne sont plus dans
      // ce groupe : s'ils saisissent, c'est en tant que professeur, et la
      // règle s'applique à eux comme à n'importe quel professeur.
      const motifNettoye = (motif_modification || '').trim();
      const estDirectionEcriture = req.auth.isSuperAdmin
        || (req.auth.roles || []).some((r) => ['secretaire', 'directeur_discipline'].includes(r));
      if (mode === 'professeur' && etat.dejaFait && !etat.estAuteur && !estDirectionEcriture && !motifNettoye) {
        throw Object.assign(
          new Error(
            `L'appel de ce jour a déjà été fait${etat.auteur ? ` par ${etat.auteur}` : ''}. `
            + `Vous pouvez le modifier, mais un motif est obligatoire (retard constaté, erreur de saisie...).`
          ),
          { statusCode: 409, motif: 'appel_deja_fait', auteur: etat.auteur }
        );
      }

      // Les élèves envoyés doivent tous appartenir à cette classe : sans ce
      // contrôle, un identifiant modifié permettrait d'écrire sur une autre classe.
      const idsEnvoyes = presences.map((p) => p.eleve_id).filter(Boolean);
      const elevesResult = await client.query(
        `SELECT id, nom, postnom, prenom FROM eleves
         WHERE classe_id = $1 AND statut = 'actif' AND id = ANY($2::uuid[])`,
        [classeId, idsEnvoyes]
      );
      const elevesValides = new Set(elevesResult.rows.map((e) => e.id));

      for (const ligne of presences) {
        if (!elevesValides.has(ligne.eleve_id)) {
          throw Object.assign(
            new Error("Un des élèves ne fait pas partie de cette classe (rechargez la page)."),
            { statusCode: 400 }
          );
        }
        if (!STATUTS.includes(ligne.statut)) {
          throw Object.assign(
            new Error(`Statut inconnu : « ${ligne.statut} ». Valeurs acceptées : présent, absent, retard, excusé.`),
            { statusCode: 400 }
          );
        }
      }

      let compteur = { present: 0, absent: 0, retard: 0, excuse: 0 };
      for (const ligne of presences) {
        const motif = (ligne.motif || '').trim() || null;
        await client.query(
          `INSERT INTO presences (ecole_id, eleve_id, classe_id, date_jour, statut, motif,
                                  saisi_par, saisi_par_initial)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $6)
           ON CONFLICT (eleve_id, date_jour)
           DO UPDATE SET statut = EXCLUDED.statut, motif = EXCLUDED.motif,
                         classe_id = EXCLUDED.classe_id,
                         saisi_par = EXCLUDED.saisi_par,
                         -- saisi_par_initial n'est JAMAIS écrasé : il garde
                         -- l'auteur du premier appel, sans quoi la trace de qui
                         -- a fait quoi disparaîtrait à la première correction.
                         saisi_par_initial = COALESCE(presences.saisi_par_initial, EXCLUDED.saisi_par_initial),
                         motif_modification = CASE WHEN $7::text <> '' THEN $7 ELSE presences.motif_modification END,
                         modifie_at = CASE WHEN $7::text <> '' THEN now() ELSE presences.modifie_at END,
                         updated_at = now()`,
          [ligne.eleve_id, classeId, date, ligne.statut, motif, req.auth.userId, motifNettoye]
        );
        compteur[ligne.statut] += 1;
      }

      // ------------------------------------------------------------------
      // Prévenir la famille LE JOUR MÊME
      // ------------------------------------------------------------------
      // Une absence signalée au bulletin, trois mois plus tard, n'informe
      // plus personne : ni le parent ni l'élève ne se souviennent du
      // 14 octobre. Le jour même, la journée peut encore s'expliquer — et
      // c'est aussi la seule fenêtre où l'école apprend qu'un enfant parti
      // de chez lui n'est jamais arrivé.
      //
      // Seuls les ABSENTS déclenchent un message. Un retard ou une absence
      // excusée n'appelle rien : écrire pour tout ferait ignorer le reste.
      //
      // La clé d'unicité porte sur l'élève ET la date : corriger l'appel
      // trois fois dans l'après-midi n'envoie qu'un seul e-mail. Elle porte
      // aussi le statut, pour qu'un élève d'abord marqué présent puis
      // corrigé en absent déclenche bien le message.
      const absents = presences
        .filter((l) => l.statut === 'absent')
        .map((l) => l.eleve_id);

      let famillesPrevenues = 0;

      if (absents.length > 0) {
        // Une seule requête pour toute la classe : trente absents ne doivent
        // pas coûter trente allers-retours pendant que la transaction dure.
        const contacts = await client.query(
          `SELECT el.id,
                  trim(concat_ws(' ', el.nom, el.postnom, el.prenom)) AS eleve,
                  el.responsable_email, el.responsable_nom,
                  cl.nom AS classe, e.nom AS ecole
             FROM eleves el
             JOIN ecoles e ON e.id = el.ecole_id
             LEFT JOIN classes cl ON cl.id = el.classe_id
            WHERE el.id = ANY($1::uuid[])
              AND el.responsable_email IS NOT NULL
              AND el.responsable_email <> ''`,
          [absents]
        );

        for (const contact of contacts.rows) {
          famillesPrevenues += await notifierEvenement(client, {
            evenement: 'presence.absence',
            destinataires: [{ email: contact.responsable_email, nom: contact.responsable_nom }],
            expediteurId: req.auth.userId,
            // Les familles n'ont pas de compte : sans ce drapeau, chaque
            // absence de l'école atterrirait dans la boîte du directeur.
            visibleInterface: false,
            donnees: {
              eleve: contact.eleve,
              classe: contact.classe,
              ecole: contact.ecole,
              date
            },
            cleUnicite: `absence:${contact.id}:${date}`
          });
        }
      }

      return { ...compteur, famillesPrevenues };
    });

    planifierVidage();

    const familles = resume.famillesPrevenues > 0
      ? ` ${resume.famillesPrevenues} famille(s) prévenue(s).`
      : '';

    return res.json({
      message: `Appel enregistré : ${resume.present} présent(s), ${resume.absent} absent(s), `
             + `${resume.retard} en retard, ${resume.excuse} excusé(s).${familles}`,
      resume
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur enregistrement appel:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /presences/statistiques?classeId=&debut=&fin=
 * Taux de présence par élève sur une plage de dates. C'est cette vue qui
 * alimentera plus tard la ligne « assiduité » du bulletin.
 */
async function statistiques(req, res) {
  const { classeId } = req.query;
  const debut = req.query.debut;
  const fin = req.query.fin || aujourdhui();

  if (!classeId) return res.status(400).json({ message: 'classeId est requis.' });
  if (!dateValide(debut) || !dateValide(fin)) {
    return res.status(400).json({ message: 'Dates invalides. Format attendu : AAAA-MM-JJ.' });
  }
  if (debut > fin) {
    return res.status(400).json({ message: 'La date de début doit précéder la date de fin.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      await verifierAccesClasse(client, req, classeId);

      const result = await client.query(
        `SELECT e.id AS eleve_id, e.matricule, e.nom, e.postnom, e.prenom,
                count(p.id) FILTER (WHERE p.statut = 'present') AS nb_present,
                count(p.id) FILTER (WHERE p.statut = 'absent')  AS nb_absent,
                count(p.id) FILTER (WHERE p.statut = 'retard')  AS nb_retard,
                count(p.id) FILTER (WHERE p.statut = 'excuse')  AS nb_excuse,
                count(p.id) AS nb_jours
         FROM eleves e
         LEFT JOIN presences p
           ON p.eleve_id = e.id AND p.date_jour BETWEEN $2 AND $3
         WHERE e.classe_id = $1 AND e.statut = 'actif'
         GROUP BY e.id, e.matricule, e.nom, e.postnom, e.prenom
         ORDER BY e.nom, e.postnom, e.prenom`,
        [classeId, debut, fin]
      );

      // count() revient de PostgreSQL en chaîne : la conversion est obligatoire,
      // sans quoi les additions concatènent au lieu d'additionner.
      const lignes = result.rows.map((l) => {
        const present = Number(l.nb_present);
        const retard = Number(l.nb_retard);
        const excuse = Number(l.nb_excuse);
        const absent = Number(l.nb_absent);
        const jours = Number(l.nb_jours);
        // Un retard reste une présence ; une absence excusée n'est pas comptée
        // comme présence mais ne pénalise pas le taux de la même façon.
        const tauxPresence = jours > 0
          ? Math.round(((present + retard) / jours) * 1000) / 10
          : null;
        return {
          eleve_id: l.eleve_id, matricule: l.matricule,
          nom: l.nom, postnom: l.postnom, prenom: l.prenom,
          nb_present: present, nb_absent: absent, nb_retard: retard,
          nb_excuse: excuse, nb_jours: jours,
          taux_presence: tauxPresence
        };
      });

      const joursOuvresResult = await client.query(
        `SELECT count(DISTINCT date_jour) AS nb FROM presences
         WHERE classe_id = $1 AND date_jour BETWEEN $2 AND $3`,
        [classeId, debut, fin]
      );

      return {
        classe_id: classeId, debut, fin,
        nb_jours_appeles: Number(joursOuvresResult.rows[0].nb),
        eleves: lignes
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur statistiques présences:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /presences/eleve/:eleveId?debut=&fin=
 * Historique détaillé d'un élève : utile pour justifier une absence auprès
 * d'un parent ou préparer un conseil de discipline.
 */
async function historiqueEleve(req, res) {
  const { eleveId } = req.params;
  const debut = req.query.debut;
  const fin = req.query.fin || aujourdhui();

  if (!dateValide(debut) || !dateValide(fin)) {
    return res.status(400).json({ message: 'Dates invalides. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const eleveResult = await client.query(
        `SELECT id, classe_id, matricule, nom, postnom, prenom FROM eleves WHERE id = $1`,
        [eleveId]
      );
      if (eleveResult.rows.length === 0) {
        throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
      }
      const eleve = eleveResult.rows[0];
      await verifierAccesClasse(client, req, eleve.classe_id);

      const result = await client.query(
        `SELECT date_jour, statut, motif
         FROM presences
         WHERE eleve_id = $1 AND date_jour BETWEEN $2 AND $3
         ORDER BY date_jour DESC`,
        [eleveId, debut, fin]
      );

      return { eleve, debut, fin, journees: result.rows };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur historique présences:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /presences/resume-jour?date=AAAA-MM-JJ
 * Vue école : quelles classes ont fait l'appel, combien d'absents au total.
 * Réservé au personnel de direction et au secrétariat.
 */
async function resumeJour(req, res) {
  const date = req.query.date || aujourdhui();
  if (!dateValide(date)) {
    return res.status(400).json({ message: 'Date invalide. Format attendu : AAAA-MM-JJ.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const result = await client.query(
        `SELECT c.id AS classe_id, c.nom AS classe_nom,
                (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS nb_eleves,
                count(p.id) AS nb_saisis,
                count(p.id) FILTER (WHERE p.statut = 'absent') AS nb_absents,
                count(p.id) FILTER (WHERE p.statut = 'retard') AS nb_retards,
                count(p.id) FILTER (WHERE p.statut = 'excuse') AS nb_excuses
         FROM classes c
         LEFT JOIN presences p ON p.classe_id = c.id AND p.date_jour = $1
         WHERE c.ecole_id = ${CURRENT_ECOLE}
         GROUP BY c.id, c.nom
         ORDER BY c.nom`,
        [date]
      );

      const classes = result.rows.map((l) => ({
        classe_id: l.classe_id,
        classe_nom: l.classe_nom,
        nb_eleves: Number(l.nb_eleves),
        nb_saisis: Number(l.nb_saisis),
        nb_absents: Number(l.nb_absents),
        nb_retards: Number(l.nb_retards),
        nb_excuses: Number(l.nb_excuses),
        appel_fait: Number(l.nb_saisis) > 0
      }));

      return {
        date,
        nb_classes: classes.length,
        nb_classes_appelees: classes.filter((c) => c.appel_fait).length,
        total_absents: classes.reduce((acc, c) => acc + c.nb_absents, 0),
        total_retards: classes.reduce((acc, c) => acc + c.nb_retards, 0),
        classes
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur résumé présences:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  feuilleAppel,
  enregistrerAppel,
  statistiques,
  historiqueEleve,
  resumeJour
};
