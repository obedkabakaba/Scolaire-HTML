const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');

// Motifs de sortie acceptés, alignés sur la contrainte de la migration 016.
// Les valider ici plutôt que de laisser passer permet un message clair au lieu
// d'une erreur de contrainte PostgreSQL.
const MOTIFS_SORTIE = ['diplome', 'echec_repete', 'depart_volontaire', 'transfert',
                       'exclusion', 'abandon', 'sans_notes', 'autre'];

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * GET /promotion/apercu?anneeScolaireId=
 * Pour chaque élève actif de l'année donnée : calcule sa moyenne annuelle
 * (moyenne des pourcentages de bulletins de période sur l'année), la compare
 * au seuil de promotion de l'école, et propose une classe cible.
 * Le Directeur ajuste ensuite les décisions avant d'exécuter la promotion.
 */
/**
 * Trouve les classes d'accueil possibles pour une classe donnée, dans l'année
 * cible, et propose une répartition des élèves entre elles.
 *
 * RÈGLE : on ne monte JAMAIS entre options différentes. Les classes cibles sont
 * cherchées sur (niveau + 1, MÊME option, MÊME cycle). Un élève de 3ème
 * Scientifique ne peut donc atterrir que dans une 4ème Scientifique — A, B ou C
 * selon les places, mais jamais en Commerciale. C'est la recherche elle-même qui
 * l'interdit, pas un contrôle ajouté après coup qu'on pourrait oublier.
 *
 * Répartition entre divisions parallèles : on remplit par ordre de division
 * (A, puis B, puis C) en respectant `capacite`. Une classe sans capacité
 * déclarée est considérée comme sans limite — c'est le cas le plus fréquent, et
 * refuser de promouvoir faute de capacité saisie bloquerait toute l'école.
 *
 * Le résultat reste une PROPOSITION : l'écran de promotion laisse le Directeur
 * changer la classe cible de chaque élève avant validation.
 */
async function classesCibles(client, { classeSource, anneeCibleId }) {
  // `classe_suivante_id` reste prioritaire : c'est la destination explicitement
  // choisie par le Directeur, elle prime sur toute règle automatique.
  if (classeSource.classe_suivante_id) {
    const forcee = await client.query(
      `SELECT id, nom, capacite, division,
              (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS effectif
         FROM classes c WHERE c.id = $1`,
      [classeSource.classe_suivante_id]
    );
    return forcee.rows;
  }

  if (!classeSource.niveau || !anneeCibleId) return [];

  const r = await client.query(
    `SELECT c.id, c.nom, c.capacite, c.division,
            (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS effectif
       FROM classes c
      WHERE c.ecole_id = ${CURRENT_ECOLE}
        AND c.annee_scolaire_id = $1
        AND c.niveau = $2
        AND c.cycle IS NOT DISTINCT FROM $3
        AND c.option_id IS NOT DISTINCT FROM $4
      ORDER BY c.division NULLS FIRST, c.nom`,
    [anneeCibleId, classeSource.niveau + 1, classeSource.cycle, classeSource.option_id]
  );
  return r.rows;
}

/**
 * Choisit, parmi les classes cibles, celle qui doit accueillir le prochain
 * élève. `deja` compte les élèves déjà affectés dans cet aperçu, pour que la
 * répartition tienne compte des décisions prises juste avant.
 */
function choisirDivision(cibles, deja) {
  if (cibles.length === 0) return null;

  for (const c of cibles) {
    const occupation = Number(c.effectif) + (deja.get(c.id) || 0);
    if (!c.capacite || occupation < Number(c.capacite)) return c;
  }

  // Toutes pleines : on renvoie tout de même la dernière plutôt que rien.
  // Un élève sans destination disparaîtrait de l'écran de promotion ; mieux
  // vaut une classe en surcapacité VISIBLE, que le Directeur pourra corriger.
  return cibles[cibles.length - 1];
}

async function apercu(req, res) {
  const { anneeScolaireId, anneeCibleId } = req.query;
  if (!anneeScolaireId) return res.status(400).json({ message: 'anneeScolaireId requis.' });

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const ecoleResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS promotion,
                COALESCE(seuil_redoublement_pourcentage, 30) AS redoublement,
                COALESCE(sortie_auto_sans_notes, true) AS sortie_sans_notes
           FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuil = Number(ecoleResult.rows[0].promotion);
      const seuilRedoublement = Number(ecoleResult.rows[0].redoublement);
      const sortieSansNotes = ecoleResult.rows[0].sortie_sans_notes === true;

      // ---------- Contrôle préalable : périodes non clôturées ----------
      // Promouvoir sur des résultats non figés, c'est décider du sort d'un
      // élève à partir de chiffres qui peuvent encore bouger. On ne bloque pas
      // — une école doit pouvoir avancer — mais on le dit avant, pas après.
      const periodesOuvertes = await client.query(
        `SELECT p.id, p.libelle,
                (SELECT count(*) FROM classe_cours cc
                   JOIN classes cl ON cl.id = cc.classe_id
                  WHERE cl.annee_scolaire_id = $1 AND cc.ecole_id = ${CURRENT_ECOLE}
                    AND NOT EXISTS (SELECT 1 FROM notes n
                                     WHERE n.classe_cours_id = cc.id
                                       AND n.periode_id = p.id AND n.valide = true)
                ) AS cours_non_valides
           FROM periodes p
          WHERE p.ecole_id = ${CURRENT_ECOLE} AND p.annee_scolaire_id = $1
            AND p.type::text IN ('periode', 'examen')
            AND p.cloturee = false
          ORDER BY p.numero`,
        [anneeScolaireId]
      );

      const elevesResult = await client.query(
        `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule, e.classe_id,
                c.nom AS classe_nom, c.classe_suivante_id, cs.nom AS classe_suivante_nom,
                c.classe_orientation, c.classe_terminale, c.niveau, c.cycle::text AS cycle, c.option_id,
                o.classe_affectee_id, co.nom AS classe_affectee_nom, o.statut::text AS statut_orientation
         FROM eleves e
         JOIN classes c ON c.id = e.classe_id
         LEFT JOIN classes cs ON cs.id = c.classe_suivante_id
         LEFT JOIN orientations o ON o.eleve_id = e.id AND o.annee_scolaire_id = $1
         LEFT JOIN classes co ON co.id = o.classe_affectee_id
         WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif' AND c.annee_scolaire_id = $1
         ORDER BY c.nom, e.nom`,
        [anneeScolaireId]
      );

      // ---------- Moyenne annuelle ----------
      //
      // Elle était obtenue par AVG(bulletins.pourcentage) sur les périodes de
      // l'année. Deux erreurs cumulées, sur le chiffre qui décide si un élève
      // passe, redouble ou sort :
      //
      //   1. `bulletins.pourcentage` est une valeur MATÉRIALISÉE. Elle
      //      n'existe que si un bulletin a été généré, et les bulletins
      //      produits avant les correctifs de dénominateur en portent une
      //      version fausse. Un élève dont la classe n'a pas encore imprimé
      //      ses bulletins n'avait aucune moyenne : il était traité comme
      //      « sans notes » et proposé à la sortie.
      //   2. Moyenner des pourcentages de périodes aux barèmes différents
      //      revient à décider qu'ils pèsent pareil. Une session d'examen
      //      vaut le double d'une période ordinaire ; la moyenne l'ignorait.
      //
      // On passe donc par la source unique du projet (utils/moyennes.utils.js),
      // celle qu'emploient déjà les rapports, le tableau de bord et le
      // repêchage : total obtenu sur total des maxima, périodes additionnées.
      //
      // `inclureNonNotes: false` est délibéré : un élève absent du résultat est
      // un élève sans AUCUNE cote sur l'année. C'est exactement la distinction
      // que la suite exploite pour proposer une sortie plutôt qu'un échec.
      const periodesAnnee = await client.query(
        `SELECT id FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen')`,
        [anneeScolaireId]
      );
      const moyennesParEleve = new Map();
      if (periodesAnnee.rows.length > 0) {
        const lignes = await pourcentagesParEleve(
          client, anneeScolaireId,
          { type: 'annuel', periodeIds: periodesAnnee.rows.map((p) => p.id) },
          { inclureNonNotes: false }
        );
        for (const l of lignes) moyennesParEleve.set(l.eleve_id, l.pourcentage);
      }

      // Classes cibles par classe source, calculées une seule fois : toutes les
      // classes d'une même source partagent la même liste de divisions.
      const ciblesParClasse = new Map();
      const dejaAffectes = new Map();

      const lignes = [];
      for (const e of elevesResult.rows) {
        const moyenne = moyennesParEleve.has(e.id) ? Number(moyennesParEleve.get(e.id)) : null;
        const admis = moyenne !== null && moyenne >= seuil;

        // Un élève SANS AUCUNE NOTE n'a pas échoué : il n'était pas là. Le
        // traiter comme un 0 % en ferait le plus mauvais de l'école, ce qui est
        // faux et injuste. On propose la sortie, avec un motif qui le dit.
        const sansNotes = moyenne === null;

        // Une classe TERMINALE ne mène nulle part : ses élèves admis sortent
        // diplômés. Sans cela, la promotion cherche une classe supérieure qui
        // n'existe pas, les élèves restent bloqués, et ils occupent des places
        // dont la promotion montante a besoin.
        const terminale = e.classe_terminale === true;

        // En classe d'orientation, la destination vient de l'affectation
        // d'option, pas du pointeur « classe suivante » : une 8ème se disperse
        // vers plusieurs 1ères humanités, une seule destination ne suffit pas.
        const parOrientation = e.classe_orientation === true && e.classe_affectee_id;

        let cibleId = e.classe_id;
        let cibleNom = e.classe_nom;
        let divisionsPossibles = [];

        if (admis && parOrientation) {
          cibleId = e.classe_affectee_id;
          cibleNom = e.classe_affectee_nom;
        } else if (admis) {
          if (!ciblesParClasse.has(e.classe_id)) {
            ciblesParClasse.set(e.classe_id, await classesCibles(client, {
              classeSource: {
                classe_suivante_id: e.classe_suivante_id, niveau: e.niveau,
                cycle: e.cycle, option_id: e.option_id
              },
              anneeCibleId: anneeCibleId || null
            }));
          }
          divisionsPossibles = ciblesParClasse.get(e.classe_id);

          const choisie = choisirDivision(divisionsPossibles, dejaAffectes);
          if (choisie) {
            cibleId = choisie.id;
            cibleNom = choisie.nom;
            dejaAffectes.set(choisie.id, (dejaAffectes.get(choisie.id) || 0) + 1);
          } else {
            cibleId = null;
            cibleNom = null;
          }
        }

        lignes.push({
          // Toutes les divisions ouvertes à cet élève, pour que l'écran de
          // promotion propose un choix restreint aux classes légitimes — et
          // rende un mélange d'options impossible même à la main.
          divisions_possibles: divisionsPossibles.map((c) => ({
            id: c.id, nom: c.nom, division: c.division,
            capacite: c.capacite, effectif: Number(c.effectif)
          })),
          eleve_id: e.id, nom: e.nom, postnom: e.postnom, prenom: e.prenom, matricule: e.matricule,
          classe_actuelle_id: e.classe_id, classe_actuelle_nom: e.classe_nom,
          moyenne_annuelle: moyenne,
          decision_proposee:
            sansNotes ? (sortieSansNotes ? 'sortant' : 'indetermine')
            : (admis && terminale) ? 'diplome'
            : admis ? 'promu'
            : moyenne >= seuilRedoublement ? 'redouble'
            : 'sortant',
          // Le motif accompagne la décision : « sortant » sans raison ne
          // permet ni de l'expliquer à une famille, ni de le retrouver plus tard.
          motif_propose:
            sansNotes ? 'sans_notes'
            : (admis && terminale) ? 'diplome'
            : (!admis && moyenne < seuilRedoublement) ? 'echec_repete'
            : null,
          classe_terminale: terminale,
          seuils: { promotion: seuil, redoublement: seuilRedoublement },
          classe_cible_proposee_id: cibleId,
          classe_cible_proposee_nom: cibleNom,
          // Signale à l'écran qu'un élève d'orientation n'a pas de destination :
          // sans ça, il serait promu vers nulle part, en silence.
          orientation_requise: e.classe_orientation === true,
          orientation_manquante: e.classe_orientation === true && admis && !e.classe_affectee_id,
          // Un élève admis sans destination ne doit pas passer inaperçu : soit
          // le niveau de sa classe n'est pas renseigné, soit aucune classe
          // d'accueil n'existe pour son option dans l'année cible.
          // Une classe terminale n'a PAS besoin de destination : ne pas
          // l'exclure ici ferait apparaître toute la promotion sortante comme
          // « cible introuvable », c'est-à-dire comme un problème.
          cible_introuvable: admis && !terminale && !cibleId
        });
      }
      return {
        lignes,
        seuils: { promotion: seuil, redoublement: seuilRedoublement, sortie_sans_notes: sortieSansNotes },
        periodes_non_cloturees: periodesOuvertes.rows.map((p) => ({
          id: p.id, libelle: p.libelle, cours_non_valides: Number(p.cours_non_valides)
        }))
      };
    });

    return res.json({
      eleves: resultat.lignes,
      seuils: resultat.seuils,
      periodes_non_cloturees: resultat.periodes_non_cloturees,
      avertissement: resultat.periodes_non_cloturees.length > 0
        ? `${resultat.periodes_non_cloturees.length} période(s) ne sont pas clôturées : `
          + `les moyennes peuvent encore changer. Clôturez-les avant d'enregistrer les passages.`
        : null
    });
  } catch (err) {
    console.error('Erreur aperçu promotion:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /promotion/executer
 * body: { anneeSourceId, decisions: [{ eleve_id, action: 'promu'|'redouble'|'sortant', classe_cible_id, resultat_libelle }] }
 * Applique les décisions : historise le résultat de l'année source, déplace
 * l'élève vers sa classe cible (année suivante) ou le marque sortant.
 */
async function executer(req, res) {
  const { anneeSourceId, decisions, malgre_periodes_ouvertes } = req.body;
  if (!anneeSourceId || !Array.isArray(decisions) || decisions.length === 0) {
    return res.status(400).json({ message: 'anneeSourceId et decisions (tableau non vide) sont requis.' });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const anneeResult = await client.query(`SELECT cloturee FROM annees_scolaires WHERE id = $1`, [anneeSourceId]);
      if (anneeResult.rows[0]?.cloturee) {
        throw Object.assign(new Error('Cette année scolaire est déjà clôturée.'), { statusCode: 403 });
      }

      // ---------- Contrôle bloquant avant d'écrire ----------
      // La promotion déplace des centaines d'élèves et historise leur résultat.
      // La lancer sur des périodes encore ouvertes, c'est figer des décisions
      // à partir de moyennes qui peuvent encore bouger — et défaire une
      // promotion est très coûteux.
      //
      // Le passage en force reste possible (une école peut avoir de bonnes
      // raisons), mais il se déclare : `malgre_periodes_ouvertes`.
      const ouvertes = await client.query(
        `SELECT libelle FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen') AND cloturee = false
          ORDER BY numero`,
        [anneeSourceId]
      );
      if (ouvertes.rows.length > 0 && malgre_periodes_ouvertes !== true) {
        throw Object.assign(
          Object.assign(
            new Error(
              `${ouvertes.rows.length} période(s) ne sont pas clôturées : `
              + ouvertes.rows.map((p) => p.libelle).join(', ')
              + `. Clôturez-les d'abord — les moyennes peuvent encore changer, `
              + `et une promotion enregistrée est très difficile à défaire.`
            ),
            { statusCode: 409 }
          ),
          { periodes_ouvertes: ouvertes.rows.map((p) => p.libelle) }
        );
      }

      let traites = 0;
      let diplomes = 0;
      for (const decision of decisions) {
        const { eleve_id, action, classe_cible_id, resultat_libelle } = decision;
        if (!eleve_id || !action) continue;

        const eleveActuel = await client.query(`SELECT classe_id FROM eleves WHERE id = $1`, [eleve_id]);
        const ancienneClasseId = eleveActuel.rows[0]?.classe_id;
        if (!ancienneClasseId) continue;

        // Historise le résultat de l'année qui se termine
        await client.query(
          `INSERT INTO eleve_classe_historique (ecole_id, eleve_id, classe_id, annee_scolaire_id, resultat_final)
           VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4)`,
          [eleve_id, ancienneClasseId, anneeSourceId,
           resultat_libelle || (
             action === 'promu' ? 'Promu(e)'
             : action === 'diplome' ? 'Diplômé(e)'
             : action === 'redouble' ? 'Redouble'
             : 'Sortant(e)'
           )]
        );

        if (action === 'diplome') {
          // Fin de parcours : l'élève libère sa place et sort de l'effectif.
          // Il n'apparaîtra plus l'année prochaine, seulement dans les
          // Archives — ce qui est exactement ce qu'il faut pour que la
          // promotion montante trouve la classe disponible.
          await client.query(
            `UPDATE eleves
                SET statut = 'diplome', motif_sortie = 'diplome',
                    date_sortie = CURRENT_DATE, annee_sortie_id = $2
              WHERE id = $1`,
            [eleve_id, anneeSourceId]
          );
          diplomes++;
        } else if (action === 'sortant') {
          // Le MOTIF est enregistré, pas seulement le fait de partir. « Sortant »
          // sans raison ne permet ni de l'expliquer à une famille, ni de
          // distinguer un transfert d'un abandon dans les statistiques.
          const motif = MOTIFS_SORTIE.includes(decision.motif_sortie)
            ? decision.motif_sortie : 'autre';
          await client.query(
            `UPDATE eleves
                SET statut = 'transfere', motif_sortie = $2,
                    date_sortie = CURRENT_DATE, annee_sortie_id = $3
              WHERE id = $1`,
            [eleve_id, motif, anneeSourceId]
          );
        } else if (classe_cible_id) {
          // ---------- Garde-fou : jamais de mélange entre options ----------
          //
          // L'aperçu ne PROPOSE que des classes de la même option, mais il ne
          // fait que proposer : rien n'empêchait jusqu'ici d'envoyer une autre
          // classe dans les décisions. Un élève de Scientifique se serait
          // retrouvé en Commerciale sans que rien ne le signale — et le
          // constat n'aurait été fait qu'à la rentrée, l'élève assis dans la
          // mauvaise salle avec un bulletin aux mauvaises branches.
          //
          // Deux exceptions légitimes :
          //   * la classe d'orientation, dont le rôle est justement de répartir
          //     les élèves vers des options différentes ;
          //   * la destination explicitement fixée par le Directeur via
          //     classe_suivante_id, qui est une décision assumée.
          if (classe_cible_id !== ancienneClasseId) {
            const comparaison = await client.query(
              `SELECT src.option_id AS option_source, src.cycle::text AS cycle_source,
                      src.classe_orientation, src.classe_suivante_id,
                      cible.option_id AS option_cible, cible.cycle::text AS cycle_cible,
                      cible.nom AS nom_cible, src.nom AS nom_source,
                      opt_src.nom AS option_source_nom, opt_cible.nom AS option_cible_nom
                 FROM classes src
                 JOIN classes cible ON cible.id = $2
                 LEFT JOIN options opt_src ON opt_src.id = src.option_id
                 LEFT JOIN options opt_cible ON opt_cible.id = cible.option_id
                WHERE src.id = $1`,
              [ancienneClasseId, classe_cible_id]
            );
            const c = comparaison.rows[0];

            if (!c) {
              throw Object.assign(
                new Error(`Classe de destination introuvable pour l'élève ${eleve_id}.`),
                { statusCode: 400 }
              );
            }

            const destinationForcee = c.classe_suivante_id === classe_cible_id;
            const viaOrientation = c.classe_orientation === true;

            if (!destinationForcee && !viaOrientation) {
              if (c.cycle_source !== c.cycle_cible) {
                throw Object.assign(
                  new Error(`Promotion impossible : « ${c.nom_source} » (${c.cycle_source}) vers « ${c.nom_cible} » (${c.cycle_cible}). Un élève ne change pas de cycle par promotion.`),
                  { statusCode: 409 }
                );
              }
              if (String(c.option_source || '') !== String(c.option_cible || '')) {
                throw Object.assign(
                  new Error(`Promotion impossible : « ${c.nom_source} » (${c.option_source_nom || 'sans option'}) vers « ${c.nom_cible} » (${c.option_cible_nom || 'sans option'}). Les élèves ne peuvent pas changer d'option par promotion — passez par une classe d'orientation.`),
                  { statusCode: 409 }
                );
              }
            }
          }

          await client.query(`UPDATE eleves SET classe_id = $1 WHERE id = $2`, [classe_cible_id, eleve_id]);
        }
        traites++;
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'promotion.executee', 'annee_scolaire', $2)`,
        [req.auth.userId, JSON.stringify({ anneeSourceId, nombreEleves: traites })]
      );

      return { traites, diplomes };
    });

    let message = `Promotion appliquée pour ${bilan.traites} élève(s).`;
    if (bilan.diplomes > 0) {
      message += ` ${bilan.diplomes} élève(s) de classe terminale sont diplômés : `
        + `ils libèrent leur place et n'apparaîtront plus l'année prochaine, `
        + `seulement dans les Archives.`;
    }
    return res.json({ message, traites: bilan.traites, diplomes: bilan.diplomes });
  } catch (err) {
    if (err.statusCode) {
      return res.status(err.statusCode).json({
        message: err.message, periodes_ouvertes: err.periodes_ouvertes
      });
    }
    console.error('Erreur exécution promotion:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { apercu, executer };
