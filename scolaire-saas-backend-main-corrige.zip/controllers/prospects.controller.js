// controllers/prospects.controller.js

/**
 * DEMANDES D'ACCOMPAGNEMENT — espace Super Administrateur.
 *
 * Ce que le site public dépose dans `demandes_accompagnement`, et ce que le
 * commercial en fait : lire, filtrer, changer de statut, rattacher à une école
 * une fois la vente conclue.
 *
 * POURQUOI UN CONTRÔLEUR SÉPARÉ
 * -----------------------------
 * `services.controller.js` gère les COMMANDES : une prestation vendue à une
 * école qui existe déjà. Ici, l'école n'existe pas encore — c'est tout
 * l'objet du travail. Les deux tables, les deux cycles de vie et les deux
 * publics sont distincts ; les mélanger produirait un contrôleur où la
 * moitié des champs est toujours nulle.
 *
 * Toutes les routes sont montées derrière `authMiddleware` + `superAdminSeul`
 * par `super-admin.routes.js` : aucun contrôle de rôle n'est répété ici.
 */

const { runWithTenant } = require('../config/db');

const SUPER = { isSuperAdmin: true };

const STATUTS = ['nouvelle', 'contactee', 'convertie', 'sans_suite'];

function texte(v, max) {
  const s = String(v === undefined || v === null ? '' : v).trim();
  return s ? s.slice(0, max) : null;
}

function entier(v, defaut, min, max) {
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) return defaut;
  return Math.min(Math.max(n, min), max);
}

/**
 * GET /super-admin/prospects
 * query : statut?, recherche?, origine?, page?, taille?
 *
 * Le tri place les demandes non traitées en tête, puis les plus récentes.
 * Un prospect vieux de trois jours qu'on n'a pas rappelé doit se voir avant
 * celui d'hier qu'on a déjà appelé — c'est le seul ordre qui serve à quelque
 * chose dans une file de rappel.
 */
async function lister(req, res) {
  const q = req.query || {};
  const page = entier(q.page, 1, 1, 10000);
  const taille = entier(q.taille, 30, 5, 200);
  const statut = STATUTS.includes(q.statut) ? q.statut : null;
  const recherche = texte(q.recherche, 120);

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conditions = [];
      const valeurs = [];

      if (statut) {
        valeurs.push(statut);
        conditions.push(`d.statut = $${valeurs.length}`);
      }
      if (recherche) {
        valeurs.push(`%${recherche}%`);
        const i = valeurs.length;
        conditions.push(`(d.contact_nom ILIKE $${i} OR d.ecole_nom ILIKE $${i}
                          OR d.ville ILIKE $${i} OR d.contact_telephone ILIKE $${i}
                          OR d.contact_email ILIKE $${i})`);
      }
      const ou = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

      const total = await client.query(
        `SELECT count(*)::int AS n FROM demandes_accompagnement d ${ou}`, valeurs);

      valeurs.push(taille, (page - 1) * taille);

      const lignes = await client.query(`
        SELECT d.*,
               p.nom  AS offre_nom,
               e.nom  AS ecole_liee_nom,
               trim(concat_ws(' ', u.prenom, u.nom)) AS traite_par_nom
          FROM demandes_accompagnement d
          LEFT JOIN plans_abonnement p ON lower(p.code) = lower(d.offre_envisagee)
          LEFT JOIN ecoles e           ON e.id = d.ecole_id
          LEFT JOIN utilisateurs u     ON u.id = d.traite_par
          ${ou}
         ORDER BY (d.statut = 'nouvelle') DESC, d.created_at DESC
         LIMIT $${valeurs.length - 1} OFFSET $${valeurs.length}`, valeurs);

      // Le décompte par statut alimente les pastilles de filtre. Une requête
      // de plus, mais elle évite au commercial de cliquer sur quatre onglets
      // pour savoir s'il a du travail.
      const parStatut = await client.query(`
        SELECT statut, count(*)::int AS n FROM demandes_accompagnement GROUP BY statut`);

      const compteurs = { nouvelle: 0, contactee: 0, convertie: 0, sans_suite: 0 };
      parStatut.rows.forEach((r) => { compteurs[r.statut] = r.n; });

      return { lignes: lignes.rows, total: total.rows[0].n, compteurs };
    });

    return res.json({
      donnees: donnees.lignes.map((d) => Object.assign(d, {
        services_souhaites: Array.isArray(d.services_souhaites) ? d.services_souhaites : []
      })),
      compteurs: donnees.compteurs,
      pagination: {
        page, taille, total: donnees.total,
        pages: Math.max(1, Math.ceil(donnees.total / taille))
      }
    });
  } catch (err) {
    console.error('Erreur liste des prospects :', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /super-admin/prospects/:id
 * body : { statut?, ecole_id?, message? }
 *
 * `traite_par` n'est pas dans le corps : il est pris sur le jeton. Laisser
 * l'appelant désigner qui a traité une demande revient à laisser signer le
 * travail d'un autre.
 */
async function majDemande(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const statut = b.statut === undefined ? undefined
    : (STATUTS.includes(b.statut) ? b.statut : null);
  if (statut === null) {
    return res.status(400).json({
      message: `statut doit valoir : ${STATUTS.join(', ')}.`
    });
  }

  const ecoleId = b.ecole_id === undefined ? undefined : (b.ecole_id || null);

  if (statut === undefined && ecoleId === undefined) {
    return res.status(400).json({ message: 'Rien à modifier.' });
  }

  try {
    const misAJour = await runWithTenant(SUPER, async (client) => {
      // Rattacher une demande à une école inexistante ferait échouer la
      // contrainte de clé étrangère sur un message illisible côté interface.
      if (ecoleId) {
        const existe = await client.query('SELECT 1 FROM ecoles WHERE id = $1', [ecoleId]);
        if (!existe.rows.length) {
          throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });
        }
      }

      const champs = [];
      const valeurs = [];

      if (statut !== undefined) {
        valeurs.push(statut);
        champs.push(`statut = $${valeurs.length}`);
      }
      if (ecoleId !== undefined) {
        valeurs.push(ecoleId);
        champs.push(`ecole_id = $${valeurs.length}`);
      }

      valeurs.push(req.auth.userId);
      champs.push(`traite_par = $${valeurs.length}`);

      valeurs.push(id);

      const r = await client.query(
        `UPDATE demandes_accompagnement SET ${champs.join(', ')}
          WHERE id = $${valeurs.length} RETURNING *`, valeurs);

      if (!r.rows.length) {
        throw Object.assign(new Error('Demande introuvable.'), { statusCode: 404 });
      }
      return r.rows[0];
    });

    return res.json({ donnees: misAJour, message: 'Demande mise à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur mise à jour prospect :', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { lister, majDemande };
