const { runWithTenant } = require('../config/db');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ATTENTION — Ce contrôleur est le SEUL du projet accessible sans jeton.
 * Trois règles s'appliquent donc à chaque requête écrite ici :
 *
 *   1. Ne jamais renvoyer autre chose que ce qu'une école a explicitement
 *      choisi de publier (site_public_actif).
 *   2. Ne jamais exposer d'identifiant technique, d'adresse e-mail d'agent,
 *      ni la moindre donnée d'un élève autre que celui qui s'authentifie
 *      par son matricule ET son code d'accès.
 *   3. Toute réponse d'erreur reste volontairement vague : distinguer
 *      « matricule inconnu » de « code incorrect » permettrait d'énumérer
 *      les élèves d'une école.
 */

/** Résout un code d'école en identifiant, uniquement si le site est publié. */
async function resoudreEcolePubliee(client, code) {
  const result = await client.query(
    `SELECT id, code, nom, logo_url, adresse, telephone, email, province, ville,
            type_enseignement, site_description, site_message_accueil, site_config
     FROM ecoles
     WHERE lower(code) = lower($1) AND statut = 'actif' AND site_public_actif = true`,
    [String(code || '').trim()]
  );
  return result.rows[0] || null;
}

/**
 * GET /public/ecole/:code
 * Page de présentation d'une école : identité, contacts, options proposées
 * et dernières annonces.
 */
async function pageEcole(req, res) {
  const { code } = req.params;

  try {
    // Contexte super-admin indispensable : sans jeton, aucune école n'est
    // encore connue, donc l'isolation par locataire ne peut pas s'appliquer.
    // Les requêtes ci-dessous sont volontairement étroites et filtrées.
    const donnees = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecole = await resoudreEcolePubliee(client, code);
      if (!ecole) return null;

      const optionsResult = await client.query(
        `SELECT nom FROM options WHERE ecole_id = $1 ORDER BY nom`,
        [ecole.id]
      );

      const annoncesResult = await client.query(
        `SELECT titre, contenu, date_publication
         FROM annonces
         WHERE ecole_id = $1 AND publiee = true
         ORDER BY date_publication DESC
         LIMIT 10`,
        [ecole.id]
      );

      const anneeResult = await client.query(
        `SELECT libelle FROM annees_scolaires WHERE ecole_id = $1 AND active = true LIMIT 1`,
        [ecole.id]
      );

      // L'identifiant interne n'est jamais renvoyé au public.
      const { id, ...publiable } = ecole;
      return {
        ecole: publiable,
        annee_active: anneeResult.rows[0]?.libelle || null,
        options: optionsResult.rows.map(r => r.nom),
        annonces: annoncesResult.rows
      };
    });

    if (!donnees) {
      return res.status(404).json({ message: "Aucune école publiée ne correspond à ce code." });
    }
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur page publique école:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /public/resultats
 * Consultation d'un bulletin par un parent, à partir du code de l'école,
 * du matricule de l'élève et de son code d'accès.
 */
async function consulterResultats(req, res) {
  const { code_ecole, matricule, code_acces } = req.body;

  if (!code_ecole || !matricule || !code_acces) {
    return res.status(400).json({ message: "Code de l'école, matricule et code d'accès sont requis." });
  }

  // Message unique quelle que soit la cause : matricule inexistant, code
  // erroné ou résultats non publiés donnent exactement la même réponse.
  const REFUS = { message: 'Matricule ou code d\'accès incorrect.' };

  try {
    const donnees = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const ecole = await resoudreEcolePubliee(client, code_ecole);
      if (!ecole) return null;

      const eleveResult = await client.query(
        `SELECT e.id, e.matricule, e.nom, e.postnom, e.prenom, e.classe_id,
                COALESCE(e.derogation_financiere, false) AS derogation,
                c.nom AS classe_nom
         FROM eleves e
         LEFT JOIN classes c ON c.id = e.classe_id
         WHERE e.ecole_id = $1
           AND upper(e.matricule) = upper($2)
           AND e.code_acces IS NOT NULL
           AND e.code_acces = upper($3)
           AND e.statut = 'actif'`,
        [ecole.id, String(matricule).trim(), String(code_acces).trim()]
      );
      if (eleveResult.rows.length === 0) return null;
      const eleve = eleveResult.rows[0];

      // Année de référence de la consultation publique : l'année active de
      // l'école. Résolue ici parce que DEUX blocs en dépendent — le contrôle
      // financier et la liste des bulletins — et qu'ils divergeaient.
      const anneeResult = await client.query(
        `SELECT id FROM annees_scolaires
          WHERE ecole_id = $1 AND active = true AND cloturee = false
          ORDER BY date_debut DESC NULLS LAST LIMIT 1`,
        [ecole.id]
      );
      const anneeCourante = anneeResult.rows[0]?.id || null;

      // Le contrôle financier vaut aussi ici — c'est même l'endroit où il
      // compte le plus, puisque c'est là que les familles regardent.
      const reglage = await client.query(
        `SELECT COALESCE(bloquer_bulletin_impaye, false) AS actif,
                COALESCE(tolerance_impaye_pourcentage, 0) AS tolerance
         FROM ecoles WHERE id = $1`,
        [ecole.id]
      );

      if (reglage.rows[0].actif === true && eleve.derogation !== true) {
        // Ce contrôleur tourne hors contexte de tenant (accès public) : la devise,
        // le taux et l'année active sont donc résolus explicitement depuis ecole.id.
        //
        // Le versement était auparavant sommé sur TOUTE la scolarité de l'élève et
        // toutes devises confondues. Conséquence côté famille : un bulletin
        // s'affichait alors que rien n'avait été réglé pour l'année en cours.
        const contexte = await client.query(
          `SELECT COALESCE(devise_principale, 'FC') AS devise,
                  taux_change_usd_fc AS taux
             FROM ecoles WHERE id = $1`,
          [ecole.id]
        );
        const { devise, taux } = contexte.rows[0];
        const anneeId = anneeCourante;

        // Somme de TOUTES les lignes de frais applicables, une par libellé.
        // Ce contrôleur gardait le LIMIT 1 corrigé partout ailleurs : c'est
        // pourtant ICI qu'il comptait le plus, puisque c'est l'écran où les
        // familles consultent le bulletin. Une école réclamant inscription +
        // minerval + laboratoire n'en voyait attendre qu'une, et le blocage
        // pour impayé laissait passer tout le monde.
        //
        // `sqlTotalFraisDus` n'est pas réutilisable tel quel : il suppose le
        // contexte de locataire (`app.current_ecole_id`), absent sur cette
        // route publique. L'école est donc passée en paramètre explicite.
        const compte = await client.query(
          `SELECT COALESCE((
                    SELECT SUM(t.montant) FROM (
                      SELECT DISTINCT ON (f.libelle)
                             CASE
                               WHEN f.devise = $4 THEN f.montant
                               WHEN f.devise = 'USD' THEN f.montant * COALESCE(f.taux_change, $5)
                               ELSE f.montant / NULLIF(COALESCE(f.taux_change, $5), 0)
                             END AS montant
                        FROM frais_scolaires f
                       WHERE f.ecole_id = $2 AND f.annee_scolaire_id = $6
                         AND (f.classe_id = $3 OR f.classe_id IS NULL)
                       ORDER BY f.libelle, f.classe_id NULLS LAST
                    ) t
                  ), 0) AS attendu,
                  COALESCE((
                    SELECT SUM(CASE
                                 WHEN p.devise = $4 THEN p.montant
                                 WHEN p.devise = 'USD' THEN p.montant * COALESCE(p.taux_change, $5)
                                 ELSE p.montant / NULLIF(COALESCE(p.taux_change, $5), 0)
                               END)
                      FROM paiements_frais p
                     WHERE p.eleve_id = $1 AND p.annee_scolaire_id = $6
                  ), 0) AS verse`,
          [eleve.id, ecole.id, eleve.classe_id, devise, taux || null, anneeId]
        );
        const attendu = Number(compte.rows[0].attendu);
        const verse = Number(compte.rows[0].verse);
        const tolerance = Number(reglage.rows[0].tolerance);

        if (attendu > 0 && verse < attendu * (1 - tolerance / 100)) {
          return {
            eleve: {
              matricule: eleve.matricule,
              nom_complet: [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '),
              classe: eleve.classe_nom
            },
            ecole: { nom: ecole.nom, logo_url: ecole.logo_url },
            bloque: true,
            reste_du: Math.max(attendu - verse, 0),
            bulletins: []
          };
        }
      }

      // Seuls les bulletins SIGNÉS sont visibles : un bulletin en cours de
      // calcul ou non validé par le titulaire ne doit jamais sortir.
      // Les bulletins n'étaient filtrés QUE sur l'élève : ceux de toutes ses
      // années scolaires remontaient ensemble, triés par `p.numero`. La
      // première période de 2024 et celle de 2025 portent le même numéro : les
      // familles voyaient deux lignes « 1ère période » aux résultats
      // différents, sans rien pour les distinguer. On se limite désormais à
      // l'année en cours — c'est ce que le parent vient consulter ; l'historique
      // relève du dossier scolaire, pas de la page publique.
      const bulletinsResult = await client.query(
        `SELECT p.libelle AS periode, p.numero, p.type,
                b.total, b.pourcentage, b.classement, b.mention,
                b.conduite, b.application, b.signe_at
         FROM bulletins b
         JOIN periodes p ON p.id = b.periode_id
         WHERE b.eleve_id = $1 AND b.signe_at IS NOT NULL
           AND p.annee_scolaire_id = $2
         ORDER BY p.numero`,
        [eleve.id, anneeCourante]
      );

      // Effectif compté sur l'IDENTIFIANT de la classe, pas sur son nom. Deux
      // classes peuvent porter le même nom — d'une année à l'autre, et entre
      // divisions parallèles. Le total servait de dénominateur au rang affiché
      // à la famille (« 12e sur 45 ») : il annonçait donc un rang sur un
      // effectif qui n'était pas celui de la classe.
      const effectifResult = await client.query(
        `SELECT count(*) AS nb FROM eleves e
         WHERE e.statut = 'actif' AND e.classe_id = $1 AND e.ecole_id = $2`,
        [eleve.classe_id, ecole.id]
      );

      return {
        eleve: {
          matricule: eleve.matricule,
          nom_complet: [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '),
          classe: eleve.classe_nom
        },
        ecole: { nom: ecole.nom, logo_url: ecole.logo_url },
        effectif_classe: Number(effectifResult.rows[0].nb),
        bulletins: bulletinsResult.rows.map((b) => ({
          periode: b.periode || `${b.type} ${b.numero}`,
          total: b.total,
          pourcentage: b.pourcentage,
          classement: b.classement,
          mention: b.mention,
          conduite: b.conduite,
          application: b.application
        }))
      };
    });

    if (!donnees) return res.status(404).json(REFUS);
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur consultation résultats:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { pageEcole, consulterResultats };
