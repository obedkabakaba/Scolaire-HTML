const XLSX = require('xlsx');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { periodeCourante } = require('../utils/calendrier.utils');
const { pourcentagesParEleve, agreger } = require('../utils/moyennes.utils');
const catalogue = require('../utils/catalogue.utils');
const { lireConfigMonetaire, sqlPaiementConverti, sqlFraisConverti } = require('../utils/devise.utils');
const { sqlTotalFraisDus } = require('../utils/frais.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * Périmètre : les rapports portent sur l'ANNÉE ACTIVE, à partir des données
 * vivantes. Les années révolues relèvent du module Archives, qui lit
 * l'historique des inscriptions. Cette séparation évite de dupliquer une
 * logique délicate et garantit qu'un rapport ne mélange jamais deux années.
 */

async function anneeActive(client) {
  const r = await client.query(
    `SELECT id, libelle FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE} AND active = true LIMIT 1`
  );
  return r.rows[0] || null;
}

function exigerAnnee(annee) {
  if (!annee) {
    throw Object.assign(
      new Error("Aucune année scolaire active : activez-en une pour produire des rapports."),
      { statusCode: 409 }
    );
  }
  return annee;
}

/** Découpe une série de pourcentages en tranches lisibles. */
function repartirParTranche(pourcentages) {
  const tranches = [
    { libelle: '80 % et plus', min: 80, max: Infinity, nb: 0 },
    { libelle: '70 – 79 %', min: 70, max: 80, nb: 0 },
    { libelle: '60 – 69 %', min: 60, max: 70, nb: 0 },
    { libelle: '50 – 59 %', min: 50, max: 60, nb: 0 },
    { libelle: 'Moins de 50 %', min: -Infinity, max: 50, nb: 0 }
  ];
  pourcentages.forEach((p) => {
    const v = Number(p);
    if (!Number.isFinite(v)) return;
    const t = tranches.find((t) => v >= t.min && v < t.max);
    if (t) t.nb += 1;
  });
  return tranches;
}

/**
 * GET /rapports/effectifs
 * Répartition des élèves : par classe, par sexe, par option.
 */
async function effectifs(req, res) {
  const cycle = cycleDemande(req);
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));
      const filtreClasse = cycle ? ` AND ${conditionCycle('c', 2)}` : '';
      const paramsClasse = cycle ? [annee.id, cycle] : [annee.id];

      const parClasse = await client.query(
        `SELECT c.id, c.nom, o.nom AS option_nom,
                count(e.id) FILTER (WHERE e.statut = 'actif') AS nb_actifs,
                count(e.id) FILTER (WHERE e.statut = 'actif' AND e.sexe = 'M') AS nb_garcons,
                count(e.id) FILTER (WHERE e.statut = 'actif' AND e.sexe = 'F') AS nb_filles
         FROM classes c
         LEFT JOIN options o ON o.id = c.option_id
         LEFT JOIN eleves e ON e.classe_id = c.id
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1${filtreClasse}
         GROUP BY c.id, c.nom, o.nom
         ORDER BY c.nom`,
        paramsClasse
      );

      const parStatut = await client.query(
        `SELECT e.statut, count(*) AS nb
         FROM eleves e JOIN classes c ON c.id = e.classe_id
         WHERE e.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1${filtreClasse}
         GROUP BY e.statut ORDER BY count(*) DESC`,
        paramsClasse
      );

      const classes = parClasse.rows.map((c) => ({
        id: c.id, nom: c.nom,
        option_nom: c.option_nom,
        nb_actifs: Number(c.nb_actifs),
        nb_garcons: Number(c.nb_garcons),
        nb_filles: Number(c.nb_filles),
        // Un élève sans sexe renseigné ne doit pas disparaître du total.
        nb_non_renseigne: Number(c.nb_actifs) - Number(c.nb_garcons) - Number(c.nb_filles)
      }));

      return {
        annee,
        total_actifs: classes.reduce((a, c) => a + c.nb_actifs, 0),
        total_garcons: classes.reduce((a, c) => a + c.nb_garcons, 0),
        total_filles: classes.reduce((a, c) => a + c.nb_filles, 0),
        classes,
        par_statut: parStatut.rows.map((l) => ({ statut: l.statut, nb: Number(l.nb) }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur rapport effectifs:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/reussite?periodeId=
 * Résultats par classe et répartition des pourcentages.
 */
/**
 * Résout la portée d'un rapport : quelles périodes entrent dans le calcul.
 *
 * PROBLÈME CORRIGÉ : sans `periodeId`, les rapports agrégeaient TOUTES les
 * périodes de l'année confondues. Un élève ayant quatre bulletins apparaissait
 * quatre fois dans le palmarès — occupant quatre places du top 20 à lui seul —
 * et les taux de réussite comptaient chaque élève autant de fois qu'il avait de
 * bulletins. Les chiffres étaient donc systématiquement faux dès qu'une
 * deuxième période existait.
 *
 * `portee` accepte :
 *   'periode'  → une période de travail précise (periodeId obligatoire)
 *   'semestre' → un semestre ou trimestre précis (periodeId obligatoire)
 *   'examen'   → toutes les périodes de type examen de l'année
 *   'annee'    → le bulletin ANNUEL (periode_id IS NULL), pas la somme des périodes
 *
 * Par défaut, en l'absence de tout paramètre, on retient la période COURANTE
 * plutôt que « toutes » : un tableau de bord doit montrer la situation du
 * moment, pas un agrégat sans signification.
 */
/**
 * Développe une liste d'identifiants de périodes en périodes FEUILLES, les
 * seules qui portent des notes.
 *
 * Un semestre ou un trimestre est une ligne de `periodes` qui ne reçoit jamais
 * de cote : c'est un regroupement, relié à ses enfants par `semestre_id`.
 * Interroger les notes avec l'identifiant du semestre lui-même ne remontait
 * donc rien, et l'écran concluait « aucun bulletin calculé » alors que les
 * quatre périodes en dessous étaient pleines.
 *
 * La descente est RÉCURSIVE parce que le primaire empile deux niveaux :
 * semestre → trimestres → périodes. Un semestre du primaire additionne donc
 * bien les périodes de ses deux trimestres, plus l'examen qui lui est rattaché.
 *
 * C'est la règle métier attendue :
 *   total semestre 1 = total P1 + total P2 + total examen du semestre 1
 */
async function periodesFeuilles(client, ids) {
  if (!ids || ids.length === 0) return [];
  const r = await client.query(
    `WITH RECURSIVE arbre AS (
       SELECT id, type::text AS type
         FROM periodes
        WHERE id = ANY($1::uuid[]) AND ecole_id = ${CURRENT_ECOLE}
       UNION
       SELECT p.id, p.type::text
         FROM periodes p
         JOIN arbre a ON p.semestre_id = a.id
        WHERE p.ecole_id = ${CURRENT_ECOLE}
     )
     SELECT DISTINCT id FROM arbre WHERE type IN ('periode', 'examen')`,
    [ids]
  );
  return r.rows.map((x) => x.id);
}

async function resoudrePortee(client, { portee, periodeId, anneeId }) {
  if (periodeId) {
    // Une période de travail se résout en elle-même ; un semestre ou un
    // trimestre se résout en tout ce qu'il contient.
    const feuilles = await periodesFeuilles(client, [periodeId]);
    if (feuilles.length === 0) return { type: 'aucune', periodeIds: [], libelle: null };
    return {
      type: feuilles.length === 1 ? 'periode_precise' : 'regroupement',
      periodeIds: feuilles,
      libelle: null
    };
  }

  if (portee === 'annee') {
    // « Année complète » = TOUTES les périodes de travail additionnées :
    // total obtenu sur total des maxima, sur l'ensemble de l'année.
    //
    // Auparavant, cette portée renvoyait `periode_id IS NULL`, c'est-à-dire la
    // ligne du bulletin ANNUEL. Elle n'existe que si l'école a généré ses
    // bulletins annuels — sinon le rapport « année complète » était vide, et
    // quand elle existait, son pourcentage venait d'un calcul figé à la
    // génération. D'où des chiffres qui ne correspondaient à rien de ce que
    // l'écran des notes affichait.
    const r = await client.query(
      `SELECT id FROM periodes
        WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
          AND type::text IN ('periode', 'examen')
        ORDER BY numero`,
      [anneeId]
    );
    return { type: 'annuel', periodeIds: r.rows.map((x) => x.id), libelle: 'Année complète' };
  }

  if (portee === 'examen') {
    const r = await client.query(
      `SELECT id FROM periodes
        WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1 AND type = 'examen'`,
      [anneeId]
    );
    return { type: 'liste', periodeIds: r.rows.map((x) => x.id), libelle: 'Examens' };
  }

  if (portee === 'semestre') {
    const r = await client.query(
      `SELECT id FROM periodes
        WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
          AND type IN ('semestre', 'trimestre')`,
      [anneeId]
    );
    return { type: 'liste', periodeIds: r.rows.map((x) => x.id), libelle: 'Semestres' };
  }

  // Défaut : la période en cours d'après le calendrier.
  const courante = await periodeCourante(client);
  if (courante) {
    return { type: 'periode_precise', periodeIds: [courante.id], libelle: courante.libelle };
  }

  // Aucune période courante (hors année scolaire, ou dates non renseignées) :
  // on retombe sur la dernière période de travail connue plutôt que sur
  // « toutes », qui produirait les doublons décrits plus haut.
  const derniere = await client.query(
    `SELECT id, libelle FROM periodes
      WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1 AND type = 'periode'
      ORDER BY numero DESC LIMIT 1`,
    [anneeId]
  );
  if (derniere.rows.length > 0) {
    return { type: 'periode_precise', periodeIds: [derniere.rows[0].id], libelle: derniere.rows[0].libelle };
  }
  return { type: 'aucune', periodeIds: [], libelle: null };
}

async function reussite(req, res) {
  const { periodeId, portee } = req.query;
  const cycle = cycleDemande(req);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));

      const seuilResult = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuil = Number(seuilResult.rows[0].seuil);

      const p = await resoudrePortee(client, { portee, periodeId, anneeId: annee.id });

      // MÊME source que l'écran des moyennes : les notes. Auparavant, la
      // réussite comptait des BULLETINS (`avg(b.pourcentage)`) pendant que la
      // moyenne d'école comptait autre chose — deux écrans côte à côte
      // donnaient donc deux chiffres différents sur les mêmes élèves. C'est
      // très probablement l'origine des « infos bizarres » constatées.
      const lignes = await pourcentagesParEleve(client, annee.id, p, { cycle, inclureNonNotes: true });

      const parClasse = new Map();
      for (const l of lignes) {
        if (!parClasse.has(l.classe_id)) {
          parClasse.set(l.classe_id, { id: l.classe_id, nom: l.classe_nom, lignes: [] });
        }
        parClasse.get(l.classe_id).lignes.push(l);
      }

      const classes = [...parClasse.values()].map((c) => {
        const pourcentages = c.lignes.map((l) => l.pourcentage);
        const reussites = pourcentages.filter((x) => x >= seuil).length;
        const a = agreger(c.lignes);
        return {
          id: c.id, nom: c.nom,
          // Le libellé dit désormais la vérité : ce sont des ÉLÈVES qu'on
          // compte, pas des bulletins. Un élève sans bulletin généré mais
          // avec des notes entre bien dans le calcul.
          nb_eleves: a.nb_eleves,
          nb_bulletins: a.nb_eleves,
          // Un zéro faute de cote saisie n'est pas un zéro scolaire. L'écran a
          // besoin de la distinction pour ne pas annoncer un effondrement là
          // où il n'y a qu'une correction en retard.
          nb_sans_note: a.nb_sans_note,
          moyenne: a.moyenne,
          nb_reussites: reussites,
          taux_reussite: a.nb_eleves > 0 ? Math.round((reussites / a.nb_eleves) * 1000) / 10 : null,
          mini: pourcentages.length ? Math.min(...pourcentages) : null,
          maxi: pourcentages.length ? Math.max(...pourcentages) : null
        };
      }).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));

      const total = lignes.length;
      const totalReussites = lignes.filter((l) => l.pourcentage >= seuil).length;
      const totalSansNote = lignes.filter((l) => l.sans_note).length;

      return {
        annee,
        portee: { type: p.type, libelle: p.libelle }, seuil,
        nb_eleves: total,
        nb_bulletins: total,
        nb_sans_note: totalSansNote,
        taux_reussite_global: total > 0 ? Math.round((totalReussites / total) * 1000) / 10 : null,
        classes,
        repartition: repartirParTranche(lignes.map((l) => l.pourcentage))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur rapport réussite:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/palmares?periodeId=&limite=
 * Meilleurs résultats de l'école, toutes classes confondues.
 */
async function palmares(req, res) {
  const { periodeId, portee } = req.query;
  const cycle = cycleDemande(req);
  const limite = Math.min(Math.max(Number(req.query.limite) || 20, 1), 100);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));
      const p = await resoudrePortee(client, { portee, periodeId, anneeId: annee.id });

      // MÊME source que la réussite et les moyennes : les NOTES.
      //
      // Le palmarès lisait jusqu'ici `bulletins.pourcentage`, une valeur figée
      // à la génération du bulletin. Deux conséquences : les élèves d'une
      // classe notée mais dont les bulletins n'avaient pas été produits
      // n'apparaissaient pas du tout (« aucun bulletin calculé »), et les
      // bulletins antérieurs au correctif du dénominateur portaient encore un
      // pourcentage calculé sur les seuls cours cotés — précisément ce qu'il
      // faut bannir. Un élève coté dans 3 cours sur 5 était comparé aux autres
      // sur une base plus petite que la leur, donc avantagé.
      //
      // Le calcul depuis les notes applique le même dénominateur pour tout le
      // monde : le total des maxima de TOUS les cours de la classe.
      const lignes = await pourcentagesParEleve(client, annee.id, p, { cycle, inclureNonNotes: true });

      const mentionsResult = await client.query(
        `SELECT seuil_min, seuil_max, libelle FROM mentions WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY seuil_min`
      );
      const mentions = mentionsResult.rows;
      const trouverMention = (pourcentage) => {
        const v = Number(pourcentage);
        if (!Number.isFinite(v)) return null;
        const m = mentions.find((x) => v >= Number(x.seuil_min) && v <= Number(x.seuil_max));
        return m ? m.libelle : null;
      };

      // La place dans la classe est recalculée elle aussi : la lire dans
      // `bulletins.classement` reviendrait à mélanger un rang figé avec un
      // pourcentage vivant, donc à afficher un 3e de classe devant un 1er.
      const placeParEleve = new Map();
      const parClasse = new Map();
      for (const l of lignes) {
        if (!parClasse.has(l.classe_id)) parClasse.set(l.classe_id, []);
        parClasse.get(l.classe_id).push(l);
      }
      for (const groupe of parClasse.values()) {
        groupe.sort((a, b) => b.pourcentage - a.pourcentage);
        groupe.forEach((l, i) => {
          // Ex æquo : même place, la suivante saute d'autant.
          const precedent = groupe[i - 1];
          placeParEleve.set(
            l.eleve_id,
            precedent && precedent.pourcentage === l.pourcentage ? placeParEleve.get(precedent.eleve_id) : i + 1
          );
        });
      }

      const classes = [...lignes].sort((a, b) => b.pourcentage - a.pourcentage).slice(0, limite);

      return {
        annee,
        portee: { type: p.type, libelle: p.libelle },
        nb_eleves: lignes.length,
        nb_sans_note: lignes.filter((l) => l.sans_note).length,
        eleves: classes.map((l, i) => ({
          rang: i + 1,
          matricule: l.matricule,
          nom_complet: l.nom_complet,
          classe_nom: l.classe_nom,
          pourcentage: l.pourcentage,
          total: l.total_obtenu,
          total_maxima: l.total_maxima,
          sans_note: l.sans_note,
          mention: trouverMention(l.pourcentage),
          place_classe: placeParEleve.get(l.eleve_id) || null
        }))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur palmarès:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/finances
 * Recouvrement des frais scolaires, classe par classe.
 */
async function finances(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));

      // Les paiements sont filtrés sur l'année du rapport et ramenés dans la
      // devise d'affichage : un état de recouvrement qui additionne les
      // versements de toutes les années et mélange francs et dollars ne veut
      // rien dire.
      const { devise_principale: devise, taux_change_usd_fc: taux } = await lireConfigMonetaire(client);

      const r = await client.query(
        `WITH montants AS (
           SELECT c.id AS classe_id, c.nom AS classe_nom, e.id AS eleve_id,
                  -- Somme de TOUTES les lignes de frais applicables, une par
                  -- libellé (utils/frais.utils.js). Le LIMIT 1 qui figurait ici
                  -- n'en retenait qu'une : une école réclamant inscription +
                  -- minerval + laboratoire voyait ses familles déclarées à jour.
                  ${sqlTotalFraisDus('c.id', '$1', '$2', 3, CURRENT_ECOLE)} AS attendu,
                  COALESCE((
                    SELECT SUM(${sqlPaiementConverti('p', '$2', 3)})
                      FROM paiements_frais p
                     WHERE p.eleve_id = e.id AND p.annee_scolaire_id = $1
                  ), 0) AS paye
           FROM classes c
           JOIN eleves e ON e.classe_id = c.id AND e.statut = 'actif'
           WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
         )
         SELECT classe_id, classe_nom,
                count(*) AS nb_eleves,
                SUM(attendu) AS total_attendu,
                SUM(LEAST(paye, attendu)) AS total_recouvre,
                count(*) FILTER (WHERE attendu - paye > 0) AS nb_en_retard
         FROM montants
         GROUP BY classe_id, classe_nom
         ORDER BY classe_nom`,
        [annee.id, devise, taux || null]
      );

      const classes = r.rows.map((l) => {
        const attendu = Number(l.total_attendu);
        const recouvre = Number(l.total_recouvre);
        return {
          classe_id: l.classe_id, classe_nom: l.classe_nom,
          nb_eleves: Number(l.nb_eleves),
          nb_en_retard: Number(l.nb_en_retard),
          total_attendu: attendu,
          total_recouvre: recouvre,
          reste_du: Math.max(attendu - recouvre, 0),
          taux_recouvrement: attendu > 0 ? Math.round((recouvre / attendu) * 1000) / 10 : null
        };
      });

      const attendu = classes.reduce((a, c) => a + c.total_attendu, 0);
      const recouvre = classes.reduce((a, c) => a + c.total_recouvre, 0);

      return {
        annee,
        total_attendu: attendu,
        total_recouvre: recouvre,
        reste_du: Math.max(attendu - recouvre, 0),
        taux_recouvrement: attendu > 0 ? Math.round((recouvre / attendu) * 1000) / 10 : null,
        nb_en_retard: classes.reduce((a, c) => a + c.nb_en_retard, 0),
        classes
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur rapport finances:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/assiduite?debut=&fin=
 * Taux de présence par classe sur une plage de dates.
 */
async function assiduite(req, res) {
  const cycle = cycleDemande(req);
  const debut = req.query.debut;
  const fin = req.query.fin;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(debut)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(fin))) {
    return res.status(400).json({ message: 'Dates invalides. Format attendu : AAAA-MM-JJ.' });
  }
  if (debut > fin) {
    return res.status(400).json({ message: 'La date de début doit précéder la date de fin.' });
  }

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));

      const r = await client.query(
        `SELECT c.id AS classe_id, c.nom AS classe_nom,
                count(p.id) AS nb_saisies,
                count(p.id) FILTER (WHERE p.statut IN ('present','retard')) AS nb_presents,
                count(p.id) FILTER (WHERE p.statut = 'absent') AS nb_absents,
                count(DISTINCT p.date_jour) AS nb_jours
         FROM classes c
         LEFT JOIN presences p ON p.classe_id = c.id AND p.date_jour BETWEEN $2 AND $3
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1
           AND ($4::text IS NULL OR c.cycle IS NULL OR c.cycle::text = $4)
         GROUP BY c.id, c.nom
         ORDER BY c.nom`,
        [annee.id, debut, fin, cycle]
      );

      const classes = r.rows.map((l) => {
        const saisies = Number(l.nb_saisies);
        const presents = Number(l.nb_presents);
        return {
          classe_id: l.classe_id, classe_nom: l.classe_nom,
          nb_jours: Number(l.nb_jours),
          nb_saisies: saisies,
          nb_absents: Number(l.nb_absents),
          taux_presence: saisies > 0 ? Math.round((presents / saisies) * 1000) / 10 : null
        };
      });

      const totalSaisies = classes.reduce((a, c) => a + c.nb_saisies, 0);
      const totalAbsents = classes.reduce((a, c) => a + c.nb_absents, 0);

      return {
        annee, debut, fin,
        classes_sans_appel: classes.filter((c) => c.nb_jours === 0).length,
        taux_global: totalSaisies > 0
          ? Math.round(((totalSaisies - totalAbsents) / totalSaisies) * 1000) / 10
          : null,
        classes
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur rapport assiduité:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/export?type=effectifs|reussite|finances|assiduite|palmares
 * Reprend le rapport demandé et le sert en classeur Excel.
 */
async function exporter(req, res) {
  const { type } = req.query;

  // Chaque rapport est reconstruit par sa propre fonction, via un objet
  // de réponse simulé : un seul calcul fait foi, jamais deux versions
  // divergentes entre l'écran et le fichier téléchargé.
  const collecteur = {
    statut: 200, corps: null,
    status(code) { this.statut = code; return this; },
    json(donnees) { this.corps = donnees; return this; }
  };

  // Chaque rapport porte ses propres droits. Le contrôle DOIT être refait
  // ici : l'export appelle les fonctions directement, sans passer par les
  // routes, donc le middleware de rôle de chaque rapport ne s'applique pas.
  //
  // `offre` porte la fonctionnalité EXIGÉE par ce rapport, ou `null` s'il
  // relève du socle. Sans ce champ, `/rapports/export?type=palmares` servait
  // en Excel exactement ce que `/rapports/palmares` refuse en 402 : le verrou
  // de route se contournait par une chaîne de requête, ce qui est la
  // définition même d'une protection qui n'en est pas une.
  const producteurs = {
    effectifs: { fn: effectifs, roles: ['directeur', 'prefet', 'secretaire'], offre: null },
    finances:  { fn: finances,  roles: ['directeur', 'prefet', 'comptable'],  offre: null },
    reussite:  { fn: reussite,  roles: ['directeur', 'prefet'], offre: 'rapports_avances' },
    palmares:  { fn: palmares,  roles: ['directeur', 'prefet'], offre: 'rapports_avances' },
    assiduite: { fn: assiduite, roles: ['directeur', 'prefet'], offre: 'rapports_avances' }
  };

  const producteur = producteurs[type];
  if (!producteur) {
    return res.status(400).json({ message: 'Type de rapport inconnu.' });
  }

  const autorise = req.auth.isSuperAdmin
    || req.auth.roles.some((r) => producteur.roles.includes(r));
  if (!autorise) {
    return res.status(403).json({ message: "Vous n'avez pas accès à ce rapport." });
  }

  // Contrôle d'OFFRE, distinct du contrôle de RÔLE : le directeur A le droit
  // au palmarès, son école ne l'a pas souscrit. D'où 402 et non 403, avec le
  // même corps que le middleware — le frontend n'a qu'un cas à traiter.
  if (producteur.offre) {
    const ecoleId = (req.auth && (req.auth.ecoleId || req.auth.ecole_id)) || null;
    if (ecoleId) {
      let droit = true;
      try {
        droit = await runWithTenant(tenantContextFromReq(req), (client) =>
          catalogue.aDroitA(client, ecoleId, producteur.offre));
      } catch (err) {
        // Même politique qu'ailleurs : une panne de lecture du catalogue ne
        // ferme pas l'école. On laisse passer et on le dit dans les journaux.
        console.error("Contrôle d'offre impossible sur l'export, requête laissée passer :", err.message);
        droit = true;
      }
      if (!droit) {
        return res.status(402).json({
          code: 'offre_insuffisante',
          fonctionnalite: producteur.offre,
          message: `${catalogue.FONCTIONNALITES[producteur.offre]} n'est pas comprise dans votre offre actuelle.`,
          action: "Consultez les offres depuis Paramètres → Abonnement pour voir celle qui l'inclut."
        });
      }
    }
  }

  await producteur.fn(req, collecteur);
  if (collecteur.statut !== 200) {
    return res.status(collecteur.statut).json(collecteur.corps);
  }
  const d = collecteur.corps;

  let feuilles = {};
  let nom = 'rapport';

  if (type === 'effectifs') {
    nom = 'effectifs';
    feuilles['Par classe'] = d.classes.map((c) => ({
      Classe: c.nom, Option: c.option_nom || '',
      Effectif: c.nb_actifs, Garcons: c.nb_garcons, Filles: c.nb_filles,
      NonRenseigne: c.nb_non_renseigne
    }));
    feuilles['Par statut'] = d.par_statut.map((s) => ({ Statut: s.statut, Nombre: s.nb }));
  } else if (type === 'reussite') {
    nom = 'reussite';
    feuilles['Par classe'] = d.classes.map((c) => ({
      Classe: c.nom, Bulletins: c.nb_bulletins,
      Moyenne: c.moyenne ?? '', TauxReussite: c.taux_reussite ?? '',
      Minimum: c.mini ?? '', Maximum: c.maxi ?? ''
    }));
    feuilles['Repartition'] = d.repartition.map((t) => ({ Tranche: t.libelle, Nombre: t.nb }));
  } else if (type === 'finances') {
    nom = 'finances';
    feuilles['Recouvrement'] = d.classes.map((c) => ({
      Classe: c.classe_nom, Eleves: c.nb_eleves,
      Attendu: c.total_attendu, Recouvre: c.total_recouvre,
      ResteDu: c.reste_du, TauxRecouvrement: c.taux_recouvrement ?? '',
      ElevesEnRetard: c.nb_en_retard
    }));
  } else if (type === 'assiduite') {
    nom = 'assiduite';
    feuilles['Assiduite'] = d.classes.map((c) => ({
      Classe: c.classe_nom, JoursAppeles: c.nb_jours,
      Saisies: c.nb_saisies, Absences: c.nb_absents,
      TauxPresence: c.taux_presence ?? ''
    }));
  } else if (type === 'palmares') {
    nom = 'palmares';
    feuilles['Palmares'] = d.eleves.map((e) => ({
      Rang: e.rang, Matricule: e.matricule, Eleve: e.nom_complet,
      Classe: e.classe_nom, Pourcentage: e.pourcentage ?? '',
      Mention: e.mention || '', PlaceDansLaClasse: e.place_classe ?? ''
    }));
  }

  const classeur = XLSX.utils.book_new();
  for (const [titre, lignes] of Object.entries(feuilles)) {
    XLSX.utils.book_append_sheet(
      classeur,
      XLSX.utils.json_to_sheet(lignes.length ? lignes : [{ Information: 'Aucune donnée' }]),
      titre.slice(0, 31)
    );
  }
  const tampon = XLSX.write(classeur, { type: 'buffer', bookType: 'xlsx' });

  const libelle = String(d.annee?.libelle || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9-]+/g, '-');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="rapport-${nom}-${libelle || 'annee'}.xlsx"`);
  return res.send(tampon);
}

/**
 * GET /rapports/moyennes?portee=&periodeId=
 *
 * Moyenne générale de l'école pour une portée donnée, avec le détail par
 * classe. Alimente le widget « moyenne » du tableau de bord, dont le filtre
 * s'ouvre au clic.
 *
 * La moyenne est calculée sur des élèves DISTINCTS. Le tableau de bord
 * affichait jusqu'ici `AVG(b.pourcentage)` sur tous les bulletins de période
 * confondus : un élève avec quatre bulletins pesait quatre fois plus lourd
 * qu'un élève arrivé en cours d'année, ce qui déforme la moyenne d'école sans
 * que rien ne le laisse voir.
 */
async function moyennes(req, res) {
  const { portee, periodeId } = req.query;
  const cycle = cycleDemande(req);

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));
      const p = await resoudrePortee(client, { portee, periodeId, anneeId: annee.id });

      // Calcul depuis les NOTES : voir le commentaire de pourcentagesParEleve.
      const lignes = await pourcentagesParEleve(client, annee.id, p, { cycle, inclureNonNotes: true });
      const global = agreger(lignes);

      const parClasse = new Map();
      for (const l of lignes) {
        if (!parClasse.has(l.classe_id)) {
          parClasse.set(l.classe_id, { classe_id: l.classe_id, classe_nom: l.classe_nom, lignes: [] });
        }
        parClasse.get(l.classe_id).lignes.push(l);
      }

      return {
        annee,
        portee: { type: p.type, libelle: p.libelle },
        moyenne_generale: global.moyenne,
        nb_eleves: global.nb_eleves,
        nb_sans_note: global.nb_sans_note,
        // Rend le calcul vérifiable à la main : un directeur qui doute peut
        // rapprocher ces deux nombres de ce qu'affiche l'écran des notes.
        detail_calcul: {
          total_obtenu: lignes.reduce((t, l) => t + l.total_obtenu, 0),
          total_maxima: lignes.reduce((t, l) => t + l.total_maxima, 0),
          nb_periodes_retenues: (p.periodeIds || []).length
        },
        par_classe: [...parClasse.values()]
          .map((c) => {
            const a = agreger(c.lignes);
            return {
              classe_id: c.classe_id, classe_nom: c.classe_nom,
              nb_eleves: a.nb_eleves, nb_sans_note: a.nb_sans_note, moyenne: a.moyenne
            };
          })
          .sort((a, b) => (b.moyenne ?? -1) - (a.moyenne ?? -1))
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur moyennes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /rapports/portees
 * Liste les filtres proposables à l'utilisateur, construite depuis les périodes
 * réellement créées par l'école — proposer « Semestres » à une école qui
 * fonctionne en trimestres n'aurait aucun sens.
 */
async function porteesDisponibles(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = exigerAnnee(await anneeActive(client));
      // Les périodes elles-mêmes appartiennent à un cycle : le primaire
      // travaille en trimestres pendant que les humanités travaillent en
      // semestres. Proposer les deux découpages dans le même menu produirait
      // exactement le mélange que le filtre est censé empêcher.
      const periodes = await client.query(
        `SELECT id, libelle, type::text AS type, numero, date_debut, date_fin
           FROM periodes p
          WHERE p.ecole_id = ${CURRENT_ECOLE} AND p.annee_scolaire_id = $1
            AND ($2::text IS NULL OR p.cycle IS NULL OR p.cycle::text = $2)
          ORDER BY CASE p.type::text WHEN 'periode' THEN 1 WHEN 'examen' THEN 2 ELSE 3 END, p.numero`,
        [annee.id, cycleDemande(req)]
      );
      const courante = await periodeCourante(client);

      const options = [];
      if (courante) options.push({ cle: 'courante', libelle: `Période en cours — ${courante.libelle}`, periodeId: courante.id });
      for (const p of periodes.rows.filter((x) => x.type === 'periode')) {
        options.push({ cle: `periode:${p.id}`, libelle: p.libelle, periodeId: p.id });
      }
      // Chaque examen séparément : « Tous les examens » additionne les sessions,
      // ce qui ne permet pas de juger une session en particulier. Les deux
      // lectures sont nécessaires et ne se déduisent pas l'une de l'autre.
      const examens = periodes.rows.filter((x) => x.type === 'examen');
      for (const p of examens) {
        options.push({ cle: `examen:${p.id}`, libelle: p.libelle, periodeId: p.id });
      }
      // Un regroupement est résolu côté serveur en ses périodes filles : un
      // semestre vaut ses périodes de travail PLUS son examen, et au primaire
      // il descend encore d'un cran par les trimestres.
      const regroupements = periodes.rows.filter((x) => ['semestre', 'trimestre'].includes(x.type));
      for (const p of regroupements) {
        options.push({ cle: `regroupement:${p.id}`, libelle: `${p.libelle} (périodes + examen)`, periodeId: p.id });
      }
      if (examens.length > 1) {
        options.push({ cle: 'examen', libelle: 'Tous les examens (cumul des sessions)', portee: 'examen' });
      }
      options.push({ cle: 'annee', libelle: 'Année complète (bulletin annuel)', portee: 'annee' });

      return { annee, periode_courante: courante, options };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur portées disponibles:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  effectifs, reussite, palmares, finances, assiduite, exporter,
  moyennes, porteesDisponibles
};
