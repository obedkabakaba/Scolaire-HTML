const { runWithTenant } = require('../config/db');
const { sqlMaximumApplicable } = require('../utils/bareme.utils');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { anneeActive } = require('../utils/annee.utils');
const { pourcentagesParEleve } = require('../utils/moyennes.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  EXAMEN DE REPÊCHAGE
 * ===========================================================================
 *
 * LE PRINCIPE
 * -----------
 * En fin d'année, un élève proche de la moyenne de passage peut repasser les
 * matières où il a échoué. S'il satisfait aux conditions, il est admis ; sinon
 * il redouble.
 *
 * LES CRITÈRES APPARTIENNENT À L'ÉCOLE
 * ------------------------------------
 * Nombre maximal de cours en échec, écart toléré, mode de calcul de la note
 * retenue, droit à une mention : tout relève du règlement intérieur. Rien n'est
 * décidé ici — la plateforme applique ce que l'école a fixé.
 *
 * TROIS RÈGLES QUE LE CODE IMPOSE, ET POURQUOI
 * --------------------------------------------
 * 1. La note d'origine n'est JAMAIS écrasée. Le bulletin montre les deux.
 *    Sans cela, personne ne pourrait plus savoir qu'un élève a été repêché —
 *    et l'école, les parents et l'établissement d'accueil ont le droit de le
 *    savoir.
 * 2. Les conditions sont FIGÉES à l'ouverture. Les modifier en cours de session
 *    requalifierait des élèves déjà écartés, ou en écarterait après l'envoi des
 *    convocations.
 * 3. La direction peut RETIRER un candidat, jamais en AJOUTER un qui ne remplit
 *    pas les conditions. Sinon les conditions ne serviraient à rien, et le
 *    repêchage deviendrait une faveur.
 */

const POLITIQUES = ['plafonnee', 'remplacement', 'moyenne'];

/**
 * Note retenue après repêchage, selon la politique de l'école.
 *
 * `plafonnee` est le défaut recommandé : un repêchage réussi ramène le cours
 * exactement au seuil de passage, jamais au-dessus. Il rattrape, il ne
 * récompense pas — un élève repêché ne doit pas se retrouver mieux noté qu'un
 * élève qui a réussi du premier coup avec la même copie.
 */
function noteRetenue({ politique, pointsOrigine, pointsRepechage, maximum, seuilEchec }) {
  if (pointsRepechage === null || pointsRepechage === undefined) return null;

  const plafond = (Number(maximum) * Number(seuilEchec)) / 100;

  switch (politique) {
    case 'remplacement':
      return Math.round(Number(pointsRepechage) * 100) / 100;
    case 'moyenne':
      return Math.round(((Number(pointsOrigine) + Number(pointsRepechage)) / 2) * 100) / 100;
    case 'plafonnee':
    default:
      // Le repêchage ne peut pas faire BAISSER une note : si l'élève fait moins
      // bien qu'en session ordinaire, on garde l'original. Le pénaliser d'avoir
      // tenté serait absurde.
      if (Number(pointsRepechage) < plafond) {
        return Math.round(Math.max(Number(pointsOrigine), Number(pointsRepechage)) * 100) / 100;
      }
      return Math.round(Math.max(plafond, Number(pointsOrigine)) * 100) / 100;
  }
}

// ---------------------------------------------------------------------------
//  Sessions
// ---------------------------------------------------------------------------

async function listerSessions(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT s.*, a.libelle AS annee_libelle,
                (SELECT count(DISTINCT eleve_id) FROM repechages r
                  WHERE r.session_id = s.id AND r.statut <> 'retire') AS nb_eleves,
                (SELECT count(*) FROM repechages r
                  WHERE r.session_id = s.id AND r.statut <> 'retire') AS nb_cours
           FROM sessions_repechage s
           JOIN annees_scolaires a ON a.id = s.annee_scolaire_id
          WHERE s.ecole_id = ${CURRENT_ECOLE}
          ORDER BY s.created_at DESC`
      );
      return r.rows.map((s) => ({
        ...s,
        nb_eleves: Number(s.nb_eleves), nb_cours: Number(s.nb_cours),
        seuil_echec_cours: Number(s.seuil_echec_cours),
        moyenne_min: Number(s.moyenne_min), moyenne_max: Number(s.moyenne_max)
      }));
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste sessions repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /repechage/sessions
 * body : { libelle, seuil_echec_cours, max_cours_repechables, moyenne_min,
 *          moyenne_max, politique_note, mention_autorisee, date_debut, date_fin }
 */
async function creerSession(req, res) {
  const {
    libelle, seuil_echec_cours, max_cours_repechables,
    moyenne_min, moyenne_max, politique_note, mention_autorisee,
    date_debut, date_fin
  } = req.body;

  if (!libelle || !String(libelle).trim()) {
    return res.status(400).json({ message: 'Donnez un intitulé à la session.' });
  }

  const nombre = (v, defaut) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : defaut;
  };
  const seuil = nombre(seuil_echec_cours, 50);
  const maxCours = Math.round(nombre(max_cours_repechables, 3));
  const mini = nombre(moyenne_min, 40);
  const maxi = nombre(moyenne_max, 50);
  const politique = POLITIQUES.includes(politique_note) ? politique_note : 'plafonnee';

  if (seuil < 0 || seuil > 100 || mini < 0 || maxi > 100) {
    return res.status(400).json({ message: 'Les seuils doivent être des pourcentages entre 0 et 100.' });
  }
  if (mini >= maxi) {
    return res.status(400).json({
      message: `La moyenne minimale (${mini} %) doit être inférieure à la maximale (${maxi} %). `
        + `Entre les deux se trouvent les élèves qu'on repêche.`
    });
  }
  if (maxCours < 1) {
    return res.status(400).json({ message: 'Le nombre de cours repêchables doit être d\'au moins 1.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annee = await anneeActive(client);
      if (!annee) {
        throw Object.assign(new Error('Aucune année scolaire active.'), { statusCode: 409 });
      }

      // Le repêchage se prononce sur des résultats DÉFINITIFS. Le lancer sur
      // des périodes encore ouvertes, c'est convoquer des élèves sur des
      // moyennes qui peuvent encore bouger — et devoir décommander ensuite.
      const ouvertes = await client.query(
        `SELECT libelle FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen') AND cloturee = false
          ORDER BY numero`,
        [annee.id]
      );
      if (ouvertes.rows.length > 0) {
        throw Object.assign(
          new Error(
            `${ouvertes.rows.length} période(s) ne sont pas clôturées : `
            + ouvertes.rows.map((p) => p.libelle).join(', ')
            + `. Le repêchage se prononce sur des résultats définitifs.`
          ),
          { statusCode: 409 }
        );
      }

      const existante = await client.query(
        `SELECT libelle FROM sessions_repechage
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1 AND statut <> 'cloturee'`,
        [annee.id]
      );
      if (existante.rows.length > 0) {
        throw Object.assign(
          new Error(`Une session est déjà en cours : « ${existante.rows[0].libelle} ». Clôturez-la d'abord.`),
          { statusCode: 409 }
        );
      }

      const r = await client.query(
        `INSERT INTO sessions_repechage
           (ecole_id, annee_scolaire_id, libelle, date_debut, date_fin,
            seuil_echec_cours, max_cours_repechables, moyenne_min, moyenne_max,
            politique_note, mention_autorisee, cree_par)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
         RETURNING id`,
        [annee.id, String(libelle).trim(), date_debut || null, date_fin || null,
         seuil, maxCours, mini, maxi, politique, mention_autorisee === true, req.auth.userId]
      );
      return { id: r.rows[0].id, annee };
    });

    return res.status(201).json({
      id: resultat.id,
      message: "Session créée. Les conditions sont désormais figées : les modifier après "
        + "l'ouverture requalifierait des élèves déjà écartés."
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création session repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------------------------------------------------------------------------
//  Éligibilité
// ---------------------------------------------------------------------------

/**
 * Calcule qui remplit les conditions, et pourquoi les autres ne les remplissent
 * pas. Le motif de non-éligibilité est aussi important que la liste : un
 * directeur à qui l'on dit « 12 éligibles » sans dire pourquoi les autres ne le
 * sont pas ne peut ni vérifier ni expliquer.
 */
async function calculerEligibles(client, session, cycle = null) {
  const annee = { id: session.annee_scolaire_id };

  const periodes = await client.query(
    `SELECT id FROM periodes
      WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
        AND type::text IN ('periode', 'examen')`,
    [annee.id]
  );
  const periodeIds = periodes.rows.map((p) => p.id);
  if (periodeIds.length === 0) return { eligibles: [], ecartes: [] };

  const moyennes = await pourcentagesParEleve(client, annee.id, {
    type: 'annuel', periodeIds
  }, { cycle });

  // Résultat par cours, sur toute l'année : c'est le cours qui est en échec,
  // pas une période isolée.
  const parCours = await client.query(
    `SELECT n.eleve_id, cc.id AS classe_cours_id, co.nom AS cours_nom,
            cl.id AS classe_id, cl.nom AS classe_nom,
            SUM(n.points_obtenus) AS obtenus,
            -- Barème : voir utils/bareme.utils.js. Le repli sur 0 pour un
            -- maximum d'examen non configuré traitait « pas encore réglé »
            -- comme « pas d'examen » : le dénominateur s'effondrait, le
            -- pourcentage du cours gonflait, et des élèves réellement en
            -- échec n'étaient plus proposés au jury de repêchage.
            SUM(${sqlMaximumApplicable('cc', 'co', 'p.type::text')}) AS maxima
       FROM notes n
       JOIN classe_cours cc ON cc.id = n.classe_cours_id
       JOIN cours co ON co.id = cc.cours_id
       JOIN classes cl ON cl.id = cc.classe_id
       JOIN periodes p ON p.id = n.periode_id
      WHERE n.ecole_id = ${CURRENT_ECOLE} AND p.annee_scolaire_id = $1
        AND n.points_obtenus IS NOT NULL
        -- Les élèves proposés au repêchage suivent le cycle affiché : mélanger
        -- primaire et humanités dans une même session de repêchage n'a pas de
        -- sens, les jurys ne sont pas les mêmes.
        AND ($2::text IS NULL OR cl.cycle IS NULL OR cl.cycle::text = $2)
      GROUP BY n.eleve_id, cc.id, co.nom, cl.id, cl.nom`,
    [annee.id, cycle]
  );

  const echecsParEleve = new Map();
  for (const l of parCours.rows) {
    const maxima = Number(l.maxima);
    if (!maxima) continue;
    const pourcentage = Math.round((Number(l.obtenus) / maxima) * 1000) / 10;
    if (pourcentage >= Number(session.seuil_echec_cours)) continue;
    if (!echecsParEleve.has(l.eleve_id)) echecsParEleve.set(l.eleve_id, []);
    echecsParEleve.get(l.eleve_id).push({
      classe_cours_id: l.classe_cours_id, cours_nom: l.cours_nom,
      classe_id: l.classe_id, classe_nom: l.classe_nom,
      pourcentage, points_origine: Number(l.obtenus), maximum: maxima
    });
  }

  const eligibles = [];
  const ecartes = [];

  for (const m of moyennes) {
    const echecs = echecsParEleve.get(m.eleve_id) || [];

    // Trois motifs d'exclusion, distincts et tous explicables à une famille.
    if (m.pourcentage >= Number(session.moyenne_max)) {
      continue;   // il passe déjà : ce n'est pas une exclusion, il n'est pas concerné
    }
    if (m.pourcentage < Number(session.moyenne_min)) {
      ecartes.push({ ...m, motif: `moyenne ${m.pourcentage} % — sous le minimum de ${session.moyenne_min} %`,
                     nb_echecs: echecs.length });
      continue;
    }
    if (echecs.length === 0) {
      ecartes.push({ ...m, motif: 'aucun cours sous le seuil d\'échec', nb_echecs: 0 });
      continue;
    }
    if (echecs.length > Number(session.max_cours_repechables)) {
      ecartes.push({ ...m,
        motif: `${echecs.length} cours en échec — au-delà du maximum de ${session.max_cours_repechables}`,
        nb_echecs: echecs.length });
      continue;
    }

    eligibles.push({ ...m, cours: echecs, nb_echecs: echecs.length });
  }

  return { eligibles, ecartes };
}

/** GET /repechage/sessions/:id/eligibles */
async function listerEligibles(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const s = await client.query(
        `SELECT * FROM sessions_repechage WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Session introuvable.'), { statusCode: 404 });
      }
      const session = s.rows[0];
      const { eligibles, ecartes } = await calculerEligibles(client, session, cycleDemande(req));

      return {
        session,
        conditions: {
          seuil_echec_cours: Number(session.seuil_echec_cours),
          max_cours_repechables: session.max_cours_repechables,
          moyenne_min: Number(session.moyenne_min),
          moyenne_max: Number(session.moyenne_max),
          politique_note: session.politique_note,
          mention_autorisee: session.mention_autorisee
        },
        eligibles,
        // Montré pour que le directeur puisse vérifier et expliquer : « 12
        // éligibles » sans dire pourquoi les autres ne le sont pas ne se
        // contrôle pas.
        ecartes
      };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur éligibles repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /repechage/sessions/:id/ouvrir
 * body : { exclure?: [eleve_id] }
 *
 * Fige la liste des convoqués. La direction peut RETIRER quelqu'un, jamais en
 * ajouter un qui ne remplit pas les conditions — sinon les conditions ne
 * serviraient à rien.
 */
async function ouvrirSession(req, res) {
  const { id } = req.params;
  const exclure = new Set(Array.isArray(req.body.exclure) ? req.body.exclure : []);

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const s = await client.query(
        `SELECT * FROM sessions_repechage WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Session introuvable.'), { statusCode: 404 });
      }
      const session = s.rows[0];
      if (session.statut !== 'preparee') {
        throw Object.assign(
          new Error(`Cette session est déjà ${session.statut === 'ouverte' ? 'ouverte' : 'clôturée'}.`),
          { statusCode: 409 }
        );
      }

      const { eligibles } = await calculerEligibles(client, session, cycleDemande(req));
      let nbEleves = 0, nbCours = 0;

      for (const e of eligibles) {
        if (exclure.has(e.eleve_id)) continue;
        nbEleves++;
        for (const c of e.cours) {
          await client.query(
            `INSERT INTO repechages
               (ecole_id, session_id, eleve_id, classe_cours_id,
                pourcentage_origine, points_origine, maximum, statut)
             VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, 'eligible')
             ON CONFLICT (session_id, eleve_id, classe_cours_id) DO NOTHING`,
            [id, e.eleve_id, c.classe_cours_id, c.pourcentage, c.points_origine, c.maximum]
          );
          nbCours++;
        }
      }

      if (nbEleves === 0) {
        throw Object.assign(
          new Error("Aucun élève ne remplit les conditions : la session n'a pas lieu d'être ouverte."),
          { statusCode: 409 }
        );
      }

      await client.query(
        `UPDATE sessions_repechage SET statut = 'ouverte', ouverte_at = now() WHERE id = $1`,
        [id]
      );
      return { nbEleves, nbCours };
    });

    return res.json({
      message: `${bilan.nbEleves} élève(s) convoqué(s) sur ${bilan.nbCours} cours. `
        + `Les notes d'origine sont conservées : le bulletin final montrera les deux.`,
      bilan
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur ouverture session repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------------------------------------------------------------------------
//  Saisie et clôture
// ---------------------------------------------------------------------------

/** GET /repechage/sessions/:id/copies */
async function listerCopies(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT r.id, r.eleve_id, r.classe_cours_id, r.pourcentage_origine,
                r.points_origine, r.maximum, r.points_repechage, r.points_retenus, r.statut,
                trim(concat(e.nom, ' ', COALESCE(e.postnom, ''), ' ', COALESCE(e.prenom, ''))) AS eleve_nom,
                e.matricule, co.nom AS cours_nom, cl.nom AS classe_nom
           FROM repechages r
           JOIN eleves e ON e.id = r.eleve_id
           JOIN classe_cours cc ON cc.id = r.classe_cours_id
           JOIN cours co ON co.id = cc.cours_id
           JOIN classes cl ON cl.id = cc.classe_id
          WHERE r.session_id = $1 AND r.ecole_id = ${CURRENT_ECOLE}
          ORDER BY cl.nom, e.nom, co.nom`,
        [id]
      );
      return r.rows.map((c) => ({
        ...c,
        pourcentage_origine: c.pourcentage_origine === null ? null : Number(c.pourcentage_origine),
        points_origine: Number(c.points_origine), maximum: Number(c.maximum),
        points_repechage: c.points_repechage === null ? null : Number(c.points_repechage),
        points_retenus: c.points_retenus === null ? null : Number(c.points_retenus)
      }));
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur copies repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PUT /repechage/copies/:id — points obtenus au repêchage. */
async function saisirNote(req, res) {
  const { id } = req.params;
  const { points } = req.body;

  try {
    const message = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT r.maximum, r.statut, s.statut AS statut_session
           FROM repechages r JOIN sessions_repechage s ON s.id = r.session_id
          WHERE r.id = $1 AND r.ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Copie introuvable.'), { statusCode: 404 });
      }
      if (r.rows[0].statut_session !== 'ouverte') {
        throw Object.assign(
          new Error("La session n'est pas ouverte : aucune note ne peut y être saisie."),
          { statusCode: 409 }
        );
      }

      if (points === null || points === '') {
        await client.query(
          `UPDATE repechages SET points_repechage = NULL, statut = 'eligible',
                                 saisi_par = $2, updated_at = now() WHERE id = $1`,
          [id, req.auth.userId]
        );
        return 'Note effacée.';
      }

      const valeur = Number(points);
      if (!Number.isFinite(valeur) || valeur < 0) {
        throw Object.assign(new Error('La note doit être un nombre positif.'), { statusCode: 400 });
      }
      if (valeur > Number(r.rows[0].maximum)) {
        throw Object.assign(
          new Error(`La note dépasse le maximum du cours (${r.rows[0].maximum}).`),
          { statusCode: 400 }
        );
      }

      await client.query(
        `UPDATE repechages SET points_repechage = $2, statut = 'compose',
                               saisi_par = $3, updated_at = now() WHERE id = $1`,
        [id, valeur, req.auth.userId]
      );
      return 'Note enregistrée.';
    });
    return res.json({ message });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur saisie note repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /repechage/sessions/:id/cloturer
 * body : { confirmer: true }
 *
 * Applique la politique de l'école, calcule la moyenne après repêchage et
 * prononce la décision. C'est ici que le repêchage produit ses effets.
 */
async function cloturerSession(req, res) {
  const { id } = req.params;
  if (req.body.confirmer !== true) {
    return res.status(400).json({
      message: 'Confirmation requise : la clôture fige les décisions de passage.'
    });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const s = await client.query(
        `SELECT * FROM sessions_repechage WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      if (s.rows.length === 0) {
        throw Object.assign(new Error('Session introuvable.'), { statusCode: 404 });
      }
      const session = s.rows[0];
      if (session.statut !== 'ouverte') {
        throw Object.assign(new Error("Cette session n'est pas ouverte."), { statusCode: 409 });
      }

      const sansNote = await client.query(
        `SELECT count(*) AS nb FROM repechages
          WHERE session_id = $1 AND statut = 'eligible'`, [id]
      );

      const copies = await client.query(
        `SELECT * FROM repechages WHERE session_id = $1 AND statut <> 'retire'`, [id]
      );

      const seuilPromotion = await client.query(
        `SELECT COALESCE(seuil_promotion_pourcentage, 50) AS seuil FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const seuil = Number(seuilPromotion.rows[0].seuil);

      // Regroupement par élève : la décision se prend sur l'ensemble, pas
      // cours par cours.
      const parEleve = new Map();
      for (const c of copies.rows) {
        const retenus = noteRetenue({
          politique: session.politique_note,
          pointsOrigine: Number(c.points_origine),
          pointsRepechage: c.points_repechage === null ? null : Number(c.points_repechage),
          maximum: Number(c.maximum),
          seuilEchec: Number(session.seuil_echec_cours)
        });

        const reussi = retenus !== null
          && (retenus / Number(c.maximum)) * 100 >= Number(session.seuil_echec_cours);

        await client.query(
          `UPDATE repechages SET points_retenus = $2, statut = $3, updated_at = now()
            WHERE id = $1`,
          [c.id, retenus, retenus === null ? 'echoue' : (reussi ? 'reussi' : 'echoue')]
        );

        if (!parEleve.has(c.eleve_id)) {
          parEleve.set(c.eleve_id, { gainPoints: 0, gainMaxima: 0, nb: 0, reussis: 0 });
        }
        const e = parEleve.get(c.eleve_id);
        e.nb++;
        if (reussi) e.reussis++;
        // Le gain est la DIFFÉRENCE entre la note retenue et l'originale : la
        // moyenne annuelle se recalcule en ajoutant ce gain au total, sans
        // avoir à rejouer tout le calcul.
        if (retenus !== null) e.gainPoints += retenus - Number(c.points_origine);
      }

      const periodes = await client.query(
        `SELECT id FROM periodes
          WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
            AND type::text IN ('periode', 'examen')`,
        [session.annee_scolaire_id]
      );
      const moyennes = await pourcentagesParEleve(client, session.annee_scolaire_id, {
        type: 'annuel', periodeIds: periodes.rows.map((p) => p.id)
      });
      const parId = new Map(moyennes.map((m) => [m.eleve_id, m]));

      let admis = 0, redoublent = 0;
      for (const [eleveId, e] of parEleve) {
        const m = parId.get(eleveId);
        if (!m) continue;
        const avant = m.pourcentage;
        const apres = Math.round(((m.total_obtenu + e.gainPoints) / m.total_maxima) * 1000) / 10;
        const decision = apres >= seuil ? 'admis_apres_repechage' : 'redouble';
        if (decision === 'admis_apres_repechage') admis++; else redoublent++;

        await client.query(
          `INSERT INTO decisions_repechage
             (ecole_id, session_id, eleve_id, moyenne_avant, moyenne_apres,
              nb_cours_repeches, nb_cours_reussis, decision)
           VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (session_id, eleve_id) DO UPDATE
             SET moyenne_avant = EXCLUDED.moyenne_avant,
                 moyenne_apres = EXCLUDED.moyenne_apres,
                 nb_cours_repeches = EXCLUDED.nb_cours_repeches,
                 nb_cours_reussis = EXCLUDED.nb_cours_reussis,
                 decision = EXCLUDED.decision, decide_at = now()`,
          [id, eleveId, avant, apres, e.nb, e.reussis, decision]
        );
      }

      await client.query(
        `UPDATE sessions_repechage
            SET statut = 'cloturee', cloturee_at = now(), cloturee_par = $2 WHERE id = $1`,
        [id, req.auth.userId]
      );

      return { admis, redoublent, sansNote: Number(sansNote.rows[0].nb) };
    });

    let message = `Repêchage clôturé : ${bilan.admis} élève(s) admis, ${bilan.redoublent} redoublent.`;
    if (bilan.sansNote > 0) {
      // Une copie sans note n'est pas une note nulle : l'élève ne s'est pas
      // présenté, ou personne n'a saisi. On le dit plutôt que de le compter
      // comme un échec silencieux.
      message += ` ${bilan.sansNote} copie(s) sans note saisie ont été comptées comme non composées.`;
    }
    message += " Les notes d'origine restent visibles sur le bulletin final.";
    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur clôture repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /repechage/sessions/:id/resultats */
async function resultats(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `SELECT d.*, trim(concat(e.nom, ' ', COALESCE(e.postnom, ''), ' ', COALESCE(e.prenom, ''))) AS eleve_nom,
                e.matricule, c.nom AS classe_nom
           FROM decisions_repechage d
           JOIN eleves e ON e.id = d.eleve_id
           LEFT JOIN classes c ON c.id = e.classe_id
          WHERE d.session_id = $1 AND d.ecole_id = ${CURRENT_ECOLE}
          ORDER BY d.decision, c.nom, e.nom`,
        [id]
      );
      return r.rows.map((d) => ({
        ...d,
        moyenne_avant: d.moyenne_avant === null ? null : Number(d.moyenne_avant),
        moyenne_apres: d.moyenne_apres === null ? null : Number(d.moyenne_apres)
      }));
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur résultats repêchage:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  listerSessions, creerSession,
  listerEligibles, ouvrirSession,
  listerCopies, saisirNote,
  cloturerSession, resultats,
  noteRetenue   // exporté pour les tests
};
