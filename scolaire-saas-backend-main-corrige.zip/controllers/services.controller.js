/**
 * ARDOISE — SERVICES COMPLÉMENTAIRES (côté école et côté Super Admin)
 * ===========================================================================
 *
 * Un service complémentaire N'EST PAS une fonctionnalité. Rien de ce qui est
 * commandé ici n'ouvre le moindre écran dans Ardoise : ce sont des heures de
 * travail humain — paramétrer, former, saisir — vendues séparément.
 *
 * CONSÉQUENCE DIRECTE SUR CE FICHIER
 * ----------------------------------
 * Aucune fonction d'ici ne consulte l'offre de l'école, et aucune ne la
 * modifie. Une école en Ascension commande la formation personnalisée à 100 $
 * exactement comme une école en Infinite, avec le même code, le même prix et
 * le même parcours. Si un jour une ligne de ce fichier lit `plan_id`, c'est
 * que la séparation des deux étages a été perdue.
 *
 * CYCLE DE VIE D'UNE COMMANDE
 * ---------------------------
 *   demandee → confirmee → planifiee → en_cours → realisee
 *                     ↘ annulee (possible tant que rien n'a commencé)
 *
 * Le prix est FIGÉ à la demande. Une hausse de tarif ne réécrit jamais une
 * commande passée : c'est la règle qui vaut déjà pour `abonnements.prix_applique`.
 */

const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const catalogue = require('../utils/catalogue.utils');

const SUPER = { isSuperAdmin: true };
const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/** Statuts après lesquels une annulation par l'école n'a plus de sens. */
const STATUTS_ENGAGES = ['en_cours', 'realisee', 'annulee'];

/* =========================================================================
   CÔTÉ ÉCOLE
   ========================================================================= */

/**
 * GET /services
 * Le catalogue tel que le voit un directeur, avec ses propres commandes.
 *
 * Le catalogue est renvoyé ENTIER, sans filtrage selon l'offre. C'est la
 * traduction dans l'API de la règle commerciale : aucun service n'est réservé
 * à un niveau d'abonnement.
 */
async function listerCatalogue(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const services = await catalogue.listerServices(client);

      const commandes = await client.query(`
        SELECT c.id, c.service_id, c.quantite, c.prix_unitaire_applique,
               c.montant_total, c.devise, c.statut, c.date_demande,
               c.date_planifiee, c.date_realisation, c.note,
               s.code AS service_code, s.nom AS service_nom, s.categorie
          FROM commandes_services c
          JOIN services_complementaires s ON s.id = c.service_id
         WHERE c.ecole_id = ${CURRENT_ECOLE}
         ORDER BY c.date_demande DESC`);

      return { services, commandes: commandes.rows };
    });

    return res.json({
      ...donnees,
      note: "Ces prestations sont indépendantes de votre abonnement. "
          + "Elles sont disponibles quelle que soit votre offre."
    });
  } catch (err) {
    console.error('Erreur catalogue services (école):', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /services/commander
 * body: { service_code, quantite?, date_souhaitee?, contact_nom?,
 *         contact_telephone?, contact_email?, note? }
 *
 * Enregistre une DEMANDE, pas un achat. Rien n'est débité, rien n'est facturé :
 * une prestation humaine se planifie avant de se payer. Le Super Admin
 * confirme, planifie, réalise, puis facture.
 */
async function commander(req, res) {
  const b = req.body || {};
  const code = String(b.service_code || '').trim();
  if (!code) return res.status(400).json({ message: 'Indiquez la prestation souhaitée.' });

  try {
    const commande = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const services = await catalogue.listerServices(client, { inclureNonPublics: true });
      const service = services.find((s) => s.code === code);
      if (!service) {
        throw Object.assign(new Error('Prestation inconnue.'), { statusCode: 404 });
      }

      // Le montant est calculé par le catalogue, jamais lu dans la requête.
      // Un montant envoyé par le client est un montant choisi par le client.
      const montant = catalogue.calculerMontantService(service, b.quantite);

      // Une demande identique déjà en cours : on la renvoie plutôt que d'en
      // créer une seconde. Un double-clic sur « Demander » ne doit pas
      // produire deux interventions à planifier.
      const doublon = await client.query(`
        SELECT id FROM commandes_services
         WHERE ecole_id = ${CURRENT_ECOLE}
           AND service_id = $1
           AND statut IN ('demandee','confirmee','planifiee')
         LIMIT 1`, [service.id]);
      if (doublon.rows.length > 0) {
        throw Object.assign(
          new Error('Une demande pour cette prestation est déjà en cours de traitement.'),
          { statusCode: 409, id: doublon.rows[0].id });
      }

      const resultat = await client.query(`
        INSERT INTO commandes_services
          (ecole_id, service_id, quantite, prix_unitaire_applique, montant_total,
           devise, statut, date_planifiee, demande_par,
           contact_nom, contact_telephone, contact_email, note)
        VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4, $5, 'demandee', $6, $7, $8, $9, $10, $11)
        RETURNING *`,
        [service.id, montant.quantite_facturee || montant.quantite,
         montant.prix_unitaire, montant.montant_total, montant.devise,
         dateOuNull(b.date_souhaitee), req.auth.userId,
         texte(b.contact_nom, 120), texte(b.contact_telephone, 40),
         texte(b.contact_email, 160), texte(b.note, 1000)]);

      await client.query(`
        INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
        VALUES (${CURRENT_ECOLE}, $1, 'service.demande', 'commande_service', $2, $3::jsonb)`,
        [req.auth.userId, resultat.rows[0].id,
         JSON.stringify({ service: service.code, quantite: montant.quantite,
                          montant: montant.montant_total, devise: montant.devise })]);

      return { ...resultat.rows[0], service_nom: service.nom, service_code: service.code };
    });

    return res.status(201).json({
      message: 'Votre demande est enregistrée. Notre équipe vous contacte pour la planifier.',
      commande
    });
  } catch (err) {
    if (err.statusCode === 409) {
      return res.status(409).json({ message: err.message, id: err.id });
    }
    console.error('Erreur commande service:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * DELETE /services/commandes/:id
 * Annulation par l'école, tant que la prestation n'a pas commencé.
 */
async function annuler(req, res) {
  const { id } = req.params;
  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const actuelle = await client.query(`
        SELECT statut FROM commandes_services
         WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]);

      if (actuelle.rows.length === 0) {
        throw Object.assign(new Error('Demande introuvable.'), { statusCode: 404 });
      }
      if (STATUTS_ENGAGES.includes(actuelle.rows[0].statut)) {
        throw Object.assign(
          new Error('Cette prestation est engagée ou déjà terminée : contactez le support pour toute modification.'),
          { statusCode: 409 });
      }

      await client.query(
        `UPDATE commandes_services SET statut = 'annulee' WHERE id = $1`, [id]);

      await client.query(`
        INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
        VALUES (${CURRENT_ECOLE}, $1, 'service.annule', 'commande_service', $2, $3::jsonb)`,
        [req.auth.userId, id, JSON.stringify({ statut_precedent: actuelle.rows[0].statut })]);

      return true;
    });

    return res.json({ message: 'Demande annulée.', ok: resultat });
  } catch (err) {
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /services/estimation?service=campagne_capture&quantite=500
 * Même calcul que la page publique, pour le simulateur intégré à
 * l'application. Un seul calcul, deux points d'entrée.
 */
async function estimer(req, res) {
  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const services = await catalogue.listerServices(client, { inclureNonPublics: true });
      const service = services.find((s) => s.code === String(req.query.service || '').trim());
      if (!service) throw Object.assign(new Error('Prestation inconnue.'), { statusCode: 404 });
      return { service: { code: service.code, nom: service.nom, unite: service.unite },
               ...catalogue.calculerMontantService(service, req.query.quantite) };
    });
    return res.json(resultat);
  } catch (err) {
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* =========================================================================
   CÔTÉ SUPER ADMIN
   ========================================================================= */

/** GET /super-admin/services/commandes?statut=&ecole= */
async function listerCommandesAdmin(req, res) {
  const statut = String(req.query.statut || '').trim();
  const ecole = String(req.query.ecole || '').trim();

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`c.statut = $${params.length}`); }
  if (ecole)  { params.push(ecole);  conditions.push(`c.ecole_id = $${params.length}::uuid`); }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const commandes = await client.query(`
        SELECT c.*, s.code AS service_code, s.nom AS service_nom, s.categorie,
               e.nom AS ecole_nom, e.code AS ecole_code, e.ville
          FROM commandes_services c
          JOIN services_complementaires s ON s.id = c.service_id
          JOIN ecoles e ON e.id = c.ecole_id
          ${where}
         ORDER BY c.date_demande DESC
         LIMIT 300`, params);

      // Le chiffre qui justifie l'existence de cet étage : ce que les
      // prestations rapportent, à côté du revenu récurrent des abonnements.
      const revenus = await client.query(`
        SELECT s.categorie,
               count(*) FILTER (WHERE c.statut = 'realisee')                AS realisees,
               COALESCE(sum(c.montant_total) FILTER (WHERE c.statut = 'realisee'), 0) AS encaisse,
               count(*) FILTER (WHERE c.statut IN ('demandee','confirmee','planifiee','en_cours')) AS en_cours,
               COALESCE(sum(c.montant_total) FILTER (WHERE c.statut IN ('demandee','confirmee','planifiee','en_cours')), 0) AS carnet
          FROM commandes_services c
          JOIN services_complementaires s ON s.id = c.service_id
         GROUP BY s.categorie`);

      return { commandes: commandes.rows, revenus_par_categorie: revenus.rows };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur liste commandes services:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /super-admin/services/commandes/:id
 * body: { statut?, date_planifiee?, note? }
 */
async function majCommandeAdmin(req, res) {
  const { id } = req.params;
  const b = req.body || {};
  const STATUTS = ['demandee', 'confirmee', 'planifiee', 'en_cours', 'realisee', 'annulee'];

  if (b.statut && !STATUTS.includes(b.statut)) {
    return res.status(400).json({
      message: `Statut inconnu. Valeurs acceptées : ${STATUTS.join(', ')}.` });
  }

  try {
    const commande = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query(
        'SELECT * FROM commandes_services WHERE id = $1 FOR UPDATE', [id]);
      if (avant.rows.length === 0) {
        throw Object.assign(new Error('Demande introuvable.'), { statusCode: 404 });
      }

      const colonnes = [];
      const params = [];
      if (b.statut) { params.push(b.statut); colonnes.push(`statut = $${params.length}`); }
      if (b.date_planifiee !== undefined) {
        params.push(dateOuNull(b.date_planifiee));
        colonnes.push(`date_planifiee = $${params.length}`);
      }
      if (b.note !== undefined) {
        params.push(texte(b.note, 1000)); colonnes.push(`note = $${params.length}`);
      }
      // La date de réalisation se pose toute seule au passage à « realisee » :
      // la laisser à la main garantissait qu'elle serait oubliée, et les
      // délais d'intervention deviennent alors incalculables.
      if (b.statut === 'realisee') colonnes.push('date_realisation = now()');

      params.push(req.auth.userId); colonnes.push(`traite_par = $${params.length}`);

      if (colonnes.length === 1) {
        throw Object.assign(new Error('Rien à modifier.'), { statusCode: 400 });
      }

      params.push(id);
      const apres = await client.query(
        `UPDATE commandes_services SET ${colonnes.join(', ')}
          WHERE id = $${params.length} RETURNING *`, params);

      await client.query(`
        INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
        VALUES ($1, $2, 'service.statut_modifie', 'commande_service', $3, $4::jsonb)`,
        [avant.rows[0].ecole_id, req.auth.userId, id,
         JSON.stringify({ avant: avant.rows[0].statut, apres: apres.rows[0].statut })]);

      return apres.rows[0];
    });

    return res.json({ message: 'Demande mise à jour.', commande });
  } catch (err) {
    console.error('Erreur maj commande service:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ------------------------------------------------------------------ outils */

function texte(v, max) {
  const s = String(v === undefined || v === null ? '' : v).trim();
  return s ? s.slice(0, max) : null;
}

function dateOuNull(v) {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
}

module.exports = {
  listerCatalogue, commander, annuler, estimer,
  listerCommandesAdmin, majCommandeAdmin
};
