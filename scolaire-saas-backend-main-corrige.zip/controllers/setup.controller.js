const { runWithTenant } = require('../config/db');
const { hashPassword } = require('../utils/password.utils');

/**
 * POST /jobs/reset-superadmin
 * Protégé par le même secret que le job d'abonnements (header x-cron-secret),
 * pour ne pas avoir besoin du Shell Render (fonctionnalité payante).
 * Crée le Super Admin s'il n'existe pas, ou réinitialise son mot de passe
 * avec les valeurs actuelles de SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD.
 *
 * Passe par runWithTenant({isSuperAdmin:true}) : la table "utilisateurs" a RLS
 * activé, donc un accès direct au pool ne verrait plus aucune ligne depuis
 * qu'on utilise un rôle de base de données qui respecte réellement RLS.
 */
async function executerResetSuperAdmin(req, res) {
  const secretRecu = req.headers['x-cron-secret'];
  if (!secretRecu || secretRecu !== process.env.CRON_SECRET) {
    return res.status(403).json({ message: 'Non autorisé.' });
  }

  const email = process.env.SUPERADMIN_EMAIL;
  const password = process.env.SUPERADMIN_PASSWORD;

  if (!email || !password) {
    return res.status(500).json({ message: 'SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD non configurés.' });
  }

  try {
    const hash = await hashPassword(password);

    const message = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const existant = await client.query(
        'SELECT id FROM utilisateurs WHERE email = $1 AND ecole_id IS NULL',
        [email]
      );

      if (existant.rows.length > 0) {
        await client.query(
          `UPDATE utilisateurs SET mot_de_passe_hash = $1, statut = 'actif' WHERE id = $2`,
          [hash, existant.rows[0].id]
        );
        return `Mot de passe réinitialisé pour ${email}.`;
      }

      const userResult = await client.query(
        `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, mot_de_passe_hash)
         VALUES (NULL, 'Super', 'Admin', $1, $2) RETURNING id`,
        [email, hash]
      );
      await client.query(
        `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, 'super_admin')`,
        [userResult.rows[0].id]
      );

      return `Super Admin créé : ${email}.`;
    });

    return res.json({ message });
  } catch (err) {
    console.error('Erreur reset super admin:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { executerResetSuperAdmin };
