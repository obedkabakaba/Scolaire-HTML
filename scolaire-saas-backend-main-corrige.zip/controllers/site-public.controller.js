const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const crypto = require('crypto');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

// Alphabet volontairement amputé de I, O, 0, 1 et des lettres qui se
// confondent à l'écrit : ces codes seront recopiés à la main par des parents.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function genererCode(longueur = 6) {
  const octets = crypto.randomBytes(longueur);
  let code = '';
  for (let i = 0; i < longueur; i++) code += ALPHABET[octets[i] % ALPHABET.length];
  return code;
}

/**
 * GET /site-public/parametres
 * État du site public de l'école et adresse à communiquer.
 */
async function obtenirParametres(req, res) {
  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const ecoleResult = await client.query(
        `SELECT code, nom, logo_url, site_public_actif, site_description,
                site_message_accueil, site_config
         FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const codesResult = await client.query(
        `SELECT count(*) FILTER (WHERE code_acces IS NOT NULL) AS avec_code,
                count(*) AS total
         FROM eleves WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif'`
      );
      return {
        ecole: ecoleResult.rows[0],
        codes_acces: {
          attribues: Number(codesResult.rows[0].avec_code),
          total: Number(codesResult.rows[0].total)
        }
      };
    });
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur paramètres site public:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PUT /site-public/parametres */
const THEMES_SITE = ['classique', 'moderne', 'chaleureux'];
const BLOCS_SITE = ['resultats', 'presentation', 'sections', 'annonces', 'equipe', 'galerie', 'infos', 'contact'];

/**
 * Nettoie la configuration reçue : on ne stocke jamais tel quel un objet venu
 * du navigateur. Chaque champ est vérifié et borné, tout le reste est écarté.
 * Les URL doivent être absolues et en http(s) — sans ce filtre, un « javascript: »
 * dans un lien de réseau social deviendrait une faille sur la page publique.
 */
function assainirConfigSite(brut) {
  const entree = (brut && typeof brut === 'object') ? brut : {};
  const texte = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
  const url = (v) => (typeof v === 'string' && /^https?:\/\//i.test(v.trim()) ? v.trim().slice(0, 600) : null);

  const blocs = {};
  for (const nom of BLOCS_SITE) {
    blocs[nom] = entree.blocs ? entree.blocs[nom] !== false : true;
  }

  const couleur = typeof entree.couleur === 'string' && /^#[0-9A-Fa-f]{6}$/.test(entree.couleur.trim())
    ? entree.couleur.trim() : '#C98A3E';

  return {
    theme: THEMES_SITE.includes(entree.theme) ? entree.theme : 'classique',
    couleur,
    couverture_url: url(entree.couverture_url),
    slogan: texte(entree.slogan, 160),
    blocs,
    mission: texte(entree.mission, 1500),
    valeurs: Array.isArray(entree.valeurs)
      ? entree.valeurs.filter((v) => typeof v === 'string' && v.trim()).slice(0, 8)
          .map((v) => v.trim().slice(0, 120))
      : [],
    horaires: texte(entree.horaires, 600),
    admission: texte(entree.admission, 1500),
    equipe: Array.isArray(entree.equipe)
      ? entree.equipe.filter((m) => m && typeof m.nom === 'string' && m.nom.trim()).slice(0, 12)
          .map((m) => ({ nom: texte(m.nom, 90), fonction: texte(m.fonction, 90), photo_url: url(m.photo_url) }))
      : [],
    galerie: Array.isArray(entree.galerie)
      ? entree.galerie.filter((g) => g && url(g.url)).slice(0, 16)
          .map((g) => ({ url: url(g.url), legende: texte(g.legende, 120) }))
      : [],
    reseaux: {
      facebook: url(entree.reseaux && entree.reseaux.facebook),
      whatsapp: texte(entree.reseaux && entree.reseaux.whatsapp, 30),
      site: url(entree.reseaux && entree.reseaux.site)
    }
  };
}

async function enregistrerParametres(req, res) {
  const { site_public_actif, site_description, site_message_accueil, site_config } = req.body;

  if (site_description && String(site_description).length > 4000) {
    return res.status(400).json({ message: 'La présentation ne peut pas dépasser 4000 caractères.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE ecoles SET
           site_public_actif = COALESCE($1, site_public_actif),
           site_description = $2,
           site_message_accueil = $3,
           site_config = COALESCE($4::jsonb, site_config),
           updated_at = now()
         WHERE id = ${CURRENT_ECOLE}`,
        [
          typeof site_public_actif === 'boolean' ? site_public_actif : null,
          site_description || null,
          site_message_accueil || null,
          site_config ? JSON.stringify(assainirConfigSite(site_config)) : null
        ]
      )
    );
    return res.json({ message: 'Site public mis à jour.' });
  } catch (err) {
    console.error('Erreur enregistrement site public:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /site-public/annonces — y compris les brouillons, réservé à l'école. */
async function listerAnnonces(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT id, titre, contenu, publiee, date_publication
         FROM annonces WHERE ecole_id = ${CURRENT_ECOLE}
         ORDER BY date_publication DESC`
      )
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste annonces:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /site-public/annonces */
async function creerAnnonce(req, res) {
  const { titre, contenu, publiee } = req.body;
  if (!titre || !String(titre).trim()) {
    return res.status(400).json({ message: 'Le titre est requis.' });
  }
  if (!contenu || !String(contenu).trim()) {
    return res.status(400).json({ message: 'Le contenu est requis.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `INSERT INTO annonces (ecole_id, titre, contenu, publiee, cree_par)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4)`,
        [String(titre).trim(), String(contenu).trim(), publiee !== false, req.auth.userId]
      )
    );
    return res.json({ message: publiee !== false ? 'Annonce publiée.' : 'Annonce enregistrée en brouillon.' });
  } catch (err) {
    console.error('Erreur création annonce:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /site-public/annonces/:id */
async function modifierAnnonce(req, res) {
  const { id } = req.params;
  const { titre, contenu, publiee } = req.body;

  try {
    const modifiees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `UPDATE annonces SET
           titre = COALESCE($1, titre),
           contenu = COALESCE($2, contenu),
           publiee = COALESCE($3, publiee)
         WHERE id = $4 AND ecole_id = ${CURRENT_ECOLE}`,
        [titre || null, contenu || null, typeof publiee === 'boolean' ? publiee : null, id]
      );
      return r.rowCount;
    });
    if (modifiees === 0) return res.status(404).json({ message: 'Annonce introuvable.' });
    return res.json({ message: 'Annonce mise à jour.' });
  } catch (err) {
    console.error('Erreur modification annonce:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** DELETE /site-public/annonces/:id */
async function supprimerAnnonce(req, res) {
  const { id } = req.params;
  try {
    const supprimees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `DELETE FROM annonces WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      return r.rowCount;
    });
    if (supprimees === 0) return res.status(404).json({ message: 'Annonce introuvable.' });
    return res.json({ message: 'Annonce supprimée.' });
  } catch (err) {
    console.error('Erreur suppression annonce:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /site-public/codes-acces
 * Attribue un code aux élèves qui n'en ont pas encore. Les codes déjà
 * distribués aux familles ne sont jamais réécrits.
 */
async function genererCodesAcces(req, res) {
  try {
    const nombre = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const sansCode = await client.query(
        `SELECT id FROM eleves
         WHERE ecole_id = ${CURRENT_ECOLE} AND statut = 'actif' AND code_acces IS NULL`
      );

      let attribues = 0;
      for (const eleve of sansCode.rows) {
        // Nouvelle tentative en cas de collision : l'unicité est garantie
        // par un index, pas par la chance.
        for (let essai = 0; essai < 6; essai++) {
          try {
            await client.query(
              `UPDATE eleves SET code_acces = $1 WHERE id = $2`,
              [genererCode(), eleve.id]
            );
            attribues++;
            break;
          } catch (e) {
            if (essai === 5) throw e;
          }
        }
      }
      return attribues;
    });

    return res.json({
      message: nombre === 0
        ? 'Tous les élèves ont déjà un code d\'accès.'
        : `${nombre} code(s) d'accès attribué(s).`,
      attribues: nombre
    });
  } catch (err) {
    console.error('Erreur génération codes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /site-public/codes-acces?classeId=
 * Liste à imprimer et à remettre aux familles.
 */
async function listerCodesAcces(req, res) {
  const { classeId } = req.query;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT e.matricule, e.nom, e.postnom, e.prenom, e.code_acces, c.nom AS classe_nom
         FROM eleves e
         LEFT JOIN classes c ON c.id = e.classe_id
         WHERE e.ecole_id = ${CURRENT_ECOLE} AND e.statut = 'actif'
           AND ($1::uuid IS NULL OR e.classe_id = $1::uuid)
         ORDER BY c.nom, e.nom, e.postnom`,
        [classeId || null]
      )
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste codes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /site-public/codes-acces/reinitialiser
 * Régénère le code d'un élève précis, par exemple s'il a été divulgué.
 */
async function reinitialiserCode(req, res) {
  const { eleve_id } = req.body;
  if (!eleve_id) return res.status(400).json({ message: 'eleve_id est requis.' });

  try {
    const code = await runWithTenant(tenantContextFromReq(req), async (client) => {
      for (let essai = 0; essai < 6; essai++) {
        const nouveau = genererCode();
        try {
          const r = await client.query(
            `UPDATE eleves SET code_acces = $1 WHERE id = $2 AND ecole_id = ${CURRENT_ECOLE}`,
            [nouveau, eleve_id]
          );
          if (r.rowCount === 0) {
            throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });
          }
          return nouveau;
        } catch (e) {
          if (e.statusCode || essai === 5) throw e;
        }
      }
    });
    return res.json({ message: 'Nouveau code attribué.', code_acces: code });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur réinitialisation code:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  obtenirParametres,
  enregistrerParametres,
  listerAnnonces,
  creerAnnonce,
  modifierAnnonce,
  supprimerAnnonce,
  genererCodesAcces,
  listerCodesAcces,
  reinitialiserCode
};
