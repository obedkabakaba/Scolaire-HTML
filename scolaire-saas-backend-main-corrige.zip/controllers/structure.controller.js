const { runWithTenant } = require('../config/db');
const { cycleDemande, conditionCycle } = require('../utils/cycle.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const {
  anneeActive, exigerAnnee, resoudreAnneeConsultable, resoudreAnneeGestion, calculerAnneeSuivante
} = require('../utils/annee.utils');
const { COURS_PRIMAIRE_OFFICIELS } = require('../utils/cours-primaire-officiels');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

// ---------- Années scolaires ----------
async function listerAnnees(req, res) {
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `SELECT * FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE}
       ORDER BY date_debut DESC NULLS LAST, libelle DESC`
    )
  );
  res.json(result.rows);
}

/**
 * Bascule le pivot de l'école sur une année donnée, dans la transaction en cours.
 *
 * Les deux UPDATE sont indissociables : c'est le seul endroit où le pivot change,
 * pour qu'il n'existe jamais deux années actives ni aucune. Auparavant, la création
 * d'une année pouvait la marquer active SANS désactiver les autres — deux pivots
 * simultanés, et `anneeActive()` en choisissait un au hasard. C'est ce qui faisait
 * remonter les classes et les notes de l'année révolue chez les professeurs.
 */
async function basculerPivot(client, anneeId) {
  const annee = await client.query(
    `SELECT id, libelle, cloturee FROM annees_scolaires
      WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
    [anneeId]
  );
  if (annee.rows.length === 0) {
    throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
  }
  if (annee.rows[0].cloturee) {
    throw Object.assign(
      new Error(`L'année « ${annee.rows[0].libelle} » est clôturée : elle ne peut plus redevenir l'année active. Consultez-la via le module Archives.`),
      { statusCode: 409 }
    );
  }

  await client.query(
    `UPDATE annees_scolaires SET active = false WHERE ecole_id = ${CURRENT_ECOLE} AND active = true`
  );
  await client.query(`UPDATE annees_scolaires SET active = true WHERE id = $1`, [anneeId]);
  return annee.rows[0];
}

async function creerAnnee(req, res) {
  const { libelle, date_debut, date_fin, active } = req.body;
  if (!libelle || !String(libelle).trim()) {
    return res.status(400).json({ message: 'libelle requis.' });
  }
  const libelleNet = String(libelle).trim();

  if (date_debut && date_fin && new Date(date_debut) >= new Date(date_fin)) {
    return res.status(400).json({ message: 'La date de fin doit être postérieure à la date de début.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const doublon = await client.query(
        `SELECT id FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND lower(btrim(libelle)) = lower($1)`,
        [libelleNet]
      );
      if (doublon.rows.length > 0) {
        throw Object.assign(
          new Error(`L'année « ${libelleNet} » existe déjà.`),
          { statusCode: 409 }
        );
      }

      // Une année est TOUJOURS créée inactive. L'activation est un acte distinct
      // et explicite du Directeur : créer l'année 2026-2027 pendant que 2025-2026
      // est encore en cours ne doit surtout pas déplacer le pivot sous les pieds
      // des professeurs en pleine saisie de notes.
      const insere = await client.query(
        `INSERT INTO annees_scolaires (ecole_id, libelle, date_debut, date_fin, active)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, false) RETURNING id`,
        [libelleNet, date_debut || null, date_fin || null]
      );
      const id = insere.rows[0].id;

      // Cas particulier : l'école n'a aucun pivot (première année, ou année
      // précédente clôturée). Laisser la plateforme sans pivot bloque tout le
      // monde, on active donc d'office. Sinon, on respecte le choix du client.
      const pivotActuel = await anneeActive(client);
      const doitActiver = active === true || !pivotActuel;
      if (doitActiver) await basculerPivot(client, id);

      return { id, activee: doitActiver };
    });

    return res.status(201).json({
      id: resultat.id,
      active: resultat.activee,
      message: resultat.activee
        ? `Année « ${libelleNet} » créée et activée comme pivot de la plateforme.`
        : `Année « ${libelleNet} » créée. Activez-la comme pivot quand vous serez prêt.`
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création année:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /annees-scolaires/proposition-suivante  (Directeur / Préfet)
 * Propose le libellé et les dates de l'année qui suit la dernière année connue,
 * pour préremplir le formulaire de création. Ne crée rien.
 */
async function proposerAnneeSuivante(req, res) {
  try {
    const proposition = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // On part de l'année la plus avancée dans le temps, clôturée ou non :
      // c'est elle qui détermine « la suivante », même si le pivot est ailleurs.
      const derniere = await client.query(
        `SELECT id, libelle, date_debut, date_fin, cloturee, active
           FROM annees_scolaires WHERE ecole_id = ${CURRENT_ECOLE}
          ORDER BY date_debut DESC NULLS LAST, libelle DESC LIMIT 1`
      );
      if (derniere.rows.length === 0) return { existe_deja: false, proposition: null, source: null };

      const source = derniere.rows[0];
      const suivante = calculerAnneeSuivante(source);
      if (!suivante) return { existe_deja: false, proposition: null, source };

      const deja = await client.query(
        `SELECT id, active, cloturee FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND lower(btrim(libelle)) = lower($1)`,
        [suivante.libelle]
      );

      return {
        source,
        proposition: suivante,
        existe_deja: deja.rows.length > 0,
        annee_existante: deja.rows[0] || null
      };
    });

    return res.json(proposition);
  } catch (err) {
    console.error('Erreur proposition année suivante:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /annees-scolaires/:id/activer  (Directeur)
 * Fait de cette année LA référence courante pour toute la plateforme
 * (une seule année active à la fois par école, garantie en base).
 */
async function activerAnnee(req, res) {
  const { id } = req.params;
  try {
    const annee = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const basculee = await basculerPivot(client, id);
      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'annee.activee', 'annee_scolaire', $2, $3)`,
        [req.auth.userId, id, JSON.stringify({ libelle: basculee.libelle })]
      );
      return basculee;
    });
    return res.json({ message: `Année « ${annee.libelle} » activée : toute la plateforme s'aligne dessus.` });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur activation année:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /annees-scolaires/:id/cloturer  (Directeur)
 * Verrouille définitivement l'année : elle devient consultable/imprimable
 * uniquement, plus aucune modification possible (notes, élèves, structure).
 */
const CYCLES = ['primaire', 'secondaire'];

/**
 * Vérifie qu'un cycle est cohérent avec le type d'enseignement de l'école.
 * Une école déclarée « primaire » ne doit pas se retrouver avec des classes
 * de secondaire par une saisie hâtive — c'est ensuite tout le bulletin qui
 * partirait sur le mauvais format.
 */
async function verifierCycle(client, cycle) {
  if (!cycle) return null;
  if (!CYCLES.includes(cycle)) {
    throw Object.assign(new Error('Cycle inconnu.'), { statusCode: 400 });
  }
  const r = await client.query(`SELECT type_enseignement FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
  const type = r.rows[0]?.type_enseignement;
  if (type === 'les_deux') return cycle;
  if (type && type !== cycle) {
    throw Object.assign(
      new Error(`Cette école est déclarée « ${type} » : elle ne peut pas accueillir de classe du ${cycle}. Modifiez le type d'enseignement dans Paramètres.`),
      { statusCode: 400 }
    );
  }
  return cycle;
}

/**
 * Une vacation réservée à un cycle ne peut pas accueillir une classe d'un
 * autre cycle. Une vacation sans cycle est commune : c'est le cas des écoles
 * où primaire et secondaire suivent les mêmes horaires.
 */
async function verifierVacation(client, vacationId, cycle) {
  if (!vacationId) return null;
  const r = await client.query(
    `SELECT id, nom, cycle FROM vacations WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
    [vacationId]
  );
  if (r.rows.length === 0) {
    throw Object.assign(new Error('Vacation introuvable.'), { statusCode: 400 });
  }
  const vacation = r.rows[0];
  if (vacation.cycle && cycle && vacation.cycle !== cycle) {
    throw Object.assign(
      new Error(`La vacation « ${vacation.nom} » est réservée au ${vacation.cycle}.`),
      { statusCode: 400 }
    );
  }
  return vacationId;
}

/**
 * Une classe suivante d'une autre option n'a pas de sens : ce serait faire
 * suivre une classe de Scientifique par une classe de Commerciale. Le
 * formulaire (classes.html) filtre déjà la liste proposée sur la même
 * option — ce contrôle est le filet de sécurité côté serveur, pour le cas où
 * l'appelant contourne le formulaire (appel API direct, ancienne version du
 * frontend en cache…).
 *
 * EXCEPTION VOLONTAIRE, identique à celle du moteur de promotion
 * (`promotion.controller.js`) : une classe d'orientation existe précisément
 * pour disperser ses élèves vers plusieurs options différentes l'année
 * suivante. Lui imposer la même option que sa classe suivante irait contre
 * son rôle — elle est donc exemptée de ce contrôle.
 */
async function verifierClasseSuivante(client, { classeSuivanteId, optionId, estOrientation }) {
  if (!classeSuivanteId || estOrientation) return classeSuivanteId || null;

  const r = await client.query(
    `SELECT option_id FROM classes WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
    [classeSuivanteId]
  );
  if (r.rows.length === 0) {
    throw Object.assign(new Error('Classe suivante introuvable.'), { statusCode: 400 });
  }
  const optionCible = r.rows[0].option_id || null;
  if (optionCible !== (optionId || null)) {
    throw Object.assign(
      new Error("La classe suivante doit être de la même option que cette classe (une classe d'orientation fait exception)."),
      { statusCode: 400 }
    );
  }
  return classeSuivanteId;
}

async function cloturerAnnee(req, res) {
  const { id } = req.params;

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const anneeResult = await client.query(
        `SELECT id, libelle, cloturee, active, date_debut, date_fin
           FROM annees_scolaires WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
        [id]
      );
      if (anneeResult.rows.length === 0) {
        throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
      }
      if (anneeResult.rows[0].cloturee) {
        throw Object.assign(new Error('Cette année est déjà clôturée.'), { statusCode: 409 });
      }
      const anneeClose = anneeResult.rows[0];

      // ---------- Photographie des inscriptions ----------
      // L'historique de classe n'était alimenté que par la promotion. Une
      // école qui clôture sans promouvoir — dernière année, arrêt en cours
      // de route — ne laissait aucune trace de qui était dans quelle classe,
      // et son archive se retrouvait vide pour toujours. On fige donc ici
      // les inscriptions manquantes, avant que l'année ne devienne
      // définitivement non modifiable.
      const photo = await client.query(
        `INSERT INTO eleve_classe_historique (ecole_id, eleve_id, classe_id, annee_scolaire_id, resultat_final)
         SELECT ${CURRENT_ECOLE}, e.id, e.classe_id, $1, NULL
         FROM eleves e
         JOIN classes c ON c.id = e.classe_id
         WHERE c.annee_scolaire_id = $1
           AND NOT EXISTS (
             SELECT 1 FROM eleve_classe_historique h
             WHERE h.eleve_id = e.id AND h.annee_scolaire_id = $1
           )`,
        [id]
      );

      await client.query(
        `UPDATE annees_scolaires SET cloturee = true, active = false WHERE id = $1`, [id]
      );

      // ---------- Enchaînement sur l'année suivante ----------
      // Clôturer le pivot laissait l'école SANS année active. Dans cet état, les
      // écrans qui retombaient sur « pas de filtre d'année » affichaient les
      // classes et les périodes de toutes les années confondues : c'est ainsi que
      // les notes d'une année révolue réapparaissaient chez un professeur.
      // On ne laisse donc plus jamais ce trou : la suite est créée et activée.
      //
      // Si l'année clôturée n'était pas le pivot (clôture tardive d'une vieille
      // année), on ne touche à rien : le pivot en cours reste en place.
      let anneeSuivante = null;
      if (anneeClose.active) {
        const proposition = calculerAnneeSuivante(anneeClose);

        if (proposition) {
          const existante = await client.query(
            `SELECT id, libelle, cloturee FROM annees_scolaires
              WHERE ecole_id = ${CURRENT_ECOLE} AND lower(btrim(libelle)) = lower($1)`,
            [proposition.libelle]
          );

          if (existante.rows.length > 0 && !existante.rows[0].cloturee) {
            anneeSuivante = { ...existante.rows[0], creee: false };
          } else if (existante.rows.length === 0) {
            const creee = await client.query(
              `INSERT INTO annees_scolaires (ecole_id, libelle, date_debut, date_fin, active)
               VALUES (${CURRENT_ECOLE}, $1, $2, $3, false) RETURNING id, libelle`,
              [proposition.libelle, proposition.date_debut, proposition.date_fin]
            );
            anneeSuivante = { ...creee.rows[0], creee: true };
          }

          if (anneeSuivante) await basculerPivot(client, anneeSuivante.id);
        }
      }

      return {
        libelle: anneeClose.libelle,
        figes: photo.rowCount,
        etait_pivot: anneeClose.active === true,
        annee_suivante: anneeSuivante
      };
    });

    const complement = bilan.figes > 0
      ? ` ${bilan.figes} inscription(s) ont été figée(s) pour l'archive.`
      : '';

    let suite = '';
    if (bilan.annee_suivante) {
      suite = bilan.annee_suivante.creee
        ? ` L'année ${bilan.annee_suivante.libelle} a été créée et activée : reportez-y votre structure, puis créez ses périodes.`
        : ` L'année ${bilan.annee_suivante.libelle} est désormais l'année active.`;
    } else if (bilan.etait_pivot) {
      // Libellé non interprétable (« Année A », « Session 1 »…) : on ne devine pas
      // le nom de l'année suivante, mais il faut prévenir que le pivot est vide.
      suite = " Attention : aucune année suivante n'a pu être déduite du libellé. Créez-la et activez-la sans tarder, la plateforme est sans année active.";
    }

    return res.json({
      message: `Année ${bilan.libelle} clôturée : elle passe en lecture seule et rejoint les archives.${complement}${suite}`,
      annee_suivante: bilan.annee_suivante
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur clôture année:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------- Options ----------
async function listerOptions(req, res) {
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(`SELECT * FROM options WHERE ecole_id = ${CURRENT_ECOLE} ORDER BY nom`)
  );
  res.json(result.rows);
}

async function creerOption(req, res) {
  const { nom } = req.body;
  if (!nom) return res.status(400).json({ message: 'nom requis.' });
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `INSERT INTO options (ecole_id, nom) VALUES (${CURRENT_ECOLE}, $1) RETURNING id`,
      [nom]
    )
  );
  res.status(201).json({ id: result.rows[0].id });
}

// ---------- Classes ----------
async function listerClasses(req, res) {
  const { anneeScolaireId } = req.query;
  // Le cycle demandé par l'écran. C'est LE filtre le plus structurant de la
  // plateforme : presque toutes les listes déroulantes de classes sont
  // construites à partir de cette route.
  const cycle = cycleDemande(req);
  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Rien ne doit "revenir" d'une autre année : sans paramètre explicite on se
      // cale sur l'année pivot, et un `anneeScolaireId` différent du pivot n'est
      // accepté que des rôles exemptés (comptable, pour les dettes antérieures).
      //
      // Le filtre d'année est désormais INCONDITIONNEL. L'ancienne condition
      // « ($1::uuid IS NULL OR c.annee_scolaire_id = $1) » était vraie pour toutes
      // les lignes dès que le paramètre valait NULL : une école sans pivot — l'état
      // dans lequel la clôture la laissait — voyait donc remonter les classes de
      // TOUTES ses années d'un coup, avec leurs élèves et leurs notes.
      const anneeId = await resoudreAnneeGestion(client, req, anneeScolaireId);

      const params = [anneeId];
      let filtreCycle = '';
      if (cycle) { params.push(cycle); filtreCycle = ` AND ${conditionCycle('c', params.length)}`; }

      return client.query(
        `SELECT c.*, o.nom AS option_nom,
                u.nom AS titulaire_nom, u.prenom AS titulaire_prenom,
                v.nom AS vacation_nom,
                (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS nb_eleves
         FROM classes c
         LEFT JOIN options o ON o.id = c.option_id
         LEFT JOIN utilisateurs u ON u.id = c.titulaire_id
         LEFT JOIN vacations v ON v.id = c.vacation_id
         WHERE c.ecole_id = ${CURRENT_ECOLE} AND c.annee_scolaire_id = $1${filtreCycle}
         ORDER BY c.nom`,
        params
      );
    });
    return res.json(result.rows);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste classes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Applique le socle officiel des branches du primaire à une classe.
 *
 * Les cours sont créés une seule fois par école : si « Lecture » existe déjà
 * (parce qu'une autre classe de primaire a été créée avant), on réutilise le
 * cours existant au lieu d'en créer un second. Sans cette réutilisation, une
 * école à six classes de primaire se retrouverait avec six « Lecture »
 * distincts, impossibles à distinguer dans les écrans de gestion des cours.
 *
 * Idempotent : relancer sur une classe déjà pourvue ne crée pas de doublon.
 */
async function appliquerSocleCoursPrimaire(client, classeId) {
  const bilan = { cours_crees: 0, cours_reutilises: 0, rattachements: 0 };

  for (const modele of COURS_PRIMAIRE_OFFICIELS) {
    const existant = await client.query(
      `SELECT id FROM cours
        WHERE ecole_id = ${CURRENT_ECOLE} AND lower(btrim(nom)) = lower(btrim($1))
        LIMIT 1`,
      [modele.nom]
    );

    let coursId;
    if (existant.rows.length > 0) {
      coursId = existant.rows[0].id;
      bilan.cours_reutilises++;
    } else {
      const cree = await client.query(
        `INSERT INTO cours (ecole_id, nom, maximum_points, domaine, groupe_domaine)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3, $4) RETURNING id`,
        [modele.nom, modele.maximum, modele.domaine, modele.groupe]
      );
      coursId = cree.rows[0].id;
      bilan.cours_crees++;
    }

    const rattache = await client.query(
      `INSERT INTO classe_cours (ecole_id, classe_id, cours_id)
       SELECT ${CURRENT_ECOLE}, $1, $2
        WHERE NOT EXISTS (SELECT 1 FROM classe_cours WHERE classe_id = $1 AND cours_id = $2)
       RETURNING id`,
      [classeId, coursId]
    );
    if (rattache.rows.length > 0) bilan.rattachements++;
  }

  return bilan;
}

/**
 * Assigne le titulaire à tous les cours de sa classe.
 *
 * Au primaire, le titulaire enseigne l'ensemble des branches : l'assigner cours
 * par cours à la main serait 23 clics pour rien. On matérialise donc les
 * affectations dans `enseignant_cours`, comme pour n'importe quel professeur —
 * ce qui les rend visibles et surtout MODIFIABLES : le directeur peut ensuite
 * retirer le titulaire d'une branche et y mettre un intervenant (religion,
 * éducation physique), sans que rien de spécial ne soit à prévoir.
 *
 * On n'écrase jamais une affectation existante : si un cours a déjà un
 * enseignant, il le garde. Réassigner un titulaire ne défait donc pas les
 * exceptions déjà configurées.
 */
async function assignerTitulaireAuxCours(client, classeId, titulaireId) {
  if (!titulaireId) return { affectations: 0 };

  const r = await client.query(
    `INSERT INTO enseignant_cours (ecole_id, utilisateur_id, classe_cours_id)
     SELECT ${CURRENT_ECOLE}, $2, cc.id
       FROM classe_cours cc
      WHERE cc.classe_id = $1
        AND NOT EXISTS (SELECT 1 FROM enseignant_cours ec WHERE ec.classe_cours_id = cc.id)
     RETURNING id`,
    [classeId, titulaireId]
  );
  return { affectations: r.rows.length };
}

async function creerClasse(req, res) {
  const { nom, option_id, titulaire_id, annee_scolaire_id, cycle, vacation_id,
          classe_orientation, capacite, niveau, division, classe_terminale,
          classe_suivante_id } = req.body;
  if (!nom) return res.status(400).json({ message: 'nom requis.' });

  let niveauValide = null;
  if (niveau !== undefined && niveau !== null && niveau !== '') {
    niveauValide = Number(niveau);
    if (!Number.isInteger(niveauValide) || niveauValide < 1 || niveauValide > 6) {
      return res.status(400).json({ message: "Le niveau doit être un entier entre 1 et 6 (rang de l'année d'études : le primaire comme le secondaire/humanités comptent chacun six années)." });
    }
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const cycleValide = await verifierCycle(client, cycle);
      const vacationValide = await verifierVacation(client, vacation_id, cycleValide);

      // L'option structure l'humanité, pas le primaire : l'accepter ici
      // produirait des bulletins incohérents.
      const optionRetenue = cycleValide === 'primaire' ? null : (option_id || null);

      const classeSuivanteValidee = await verifierClasseSuivante(client, {
        classeSuivanteId: classe_suivante_id,
        optionId: optionRetenue,
        estOrientation: classe_orientation === true
      });

      // La division n'a de sens que face à d'autres classes parallèles ; on la
      // normalise en majuscule pour que « a » et « A » ne créent pas deux
      // divisions distinctes du même niveau.
      const divisionRetenue = division ? String(division).trim().toUpperCase() : null;

      const insere = await client.query(
        `INSERT INTO classes (ecole_id, nom, option_id, titulaire_id,
                              annee_scolaire_id, cycle, vacation_id, classe_orientation, capacite,
                              niveau, division, classe_terminale, classe_suivante_id)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [nom, optionRetenue, titulaire_id || null,
         annee_scolaire_id || null, cycleValide, vacationValide,
         classe_orientation === true, capacite ? Number(capacite) : null,
         niveauValide, divisionRetenue,
         // Classe de fin de parcours : ses élèves ne montent pas, ils sortent
         // diplômés. Sans ce drapeau, la promotion cherche une classe
         // supérieure inexistante et les élèves restent bloqués, occupant des
         // places dont la promotion montante a besoin.
         classe_terminale === true, classeSuivanteValidee]
      );
      const classeId = insere.rows[0].id;

      // Le programme du primaire est national et identique de la 1ʳᵉ à la 6ᵉ :
      // il n'y a rien à faire configurer à l'école, on applique le socle.
      // Modifiable ensuite comme n'importe quel cours.
      let socle = null;
      if (cycleValide === 'primaire') {
        socle = await appliquerSocleCoursPrimaire(client, classeId);
      }

      const affectations = await assignerTitulaireAuxCours(client, classeId, titulaire_id);

      return { id: classeId, socle, affectations: affectations.affectations };
    });

    const messages = [];
    if (resultat.socle) {
      messages.push(`${resultat.socle.rattachements} branches du programme officiel du primaire ajoutées`);
    }
    if (resultat.affectations > 0) {
      messages.push(`titulaire assigné à ${resultat.affectations} cours`);
    }

    return res.status(201).json({
      id: resultat.id,
      message: messages.length ? `Classe créée : ${messages.join(', ')}.` : 'Classe créée.'
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Une classe de ce niveau, cette option et cette division existe déjà pour cette année.' });
    }
    console.error('Erreur création classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function modifierClasse(req, res) {
  const { id } = req.params;
  const { nom, option_id, titulaire_id, classe_suivante_id, cycle, vacation_id,
          classe_orientation, capacite, annee_scolaire_id, niveau, division,
          classe_terminale } = req.body;

  let niveauValide = null;
  if (niveau !== undefined && niveau !== null && niveau !== '') {
    niveauValide = Number(niveau);
    if (!Number.isInteger(niveauValide) || niveauValide < 1 || niveauValide > 6) {
      return res.status(400).json({ message: "Le niveau doit être un entier entre 1 et 6 (rang de l'année d'études : le primaire comme le secondaire/humanités comptent chacun six années)." });
    }
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Nécessaire pour valider la classe suivante : `classe_orientation` peut
      // ne pas être envoyé (auquel cas la valeur en base fait foi, comme pour
      // le reste du formulaire — voir COALESCE plus bas).
      const orientationEffective = typeof classe_orientation === 'boolean'
        ? classe_orientation
        : (await client.query(`SELECT classe_orientation FROM classes WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id])).rows[0]?.classe_orientation === true;

      const classeSuivanteValidee = await verifierClasseSuivante(client, {
        classeSuivanteId: classe_suivante_id,
        optionId: option_id || null,
        estOrientation: orientationEffective
      });

      if (titulaire_id) {
        const ecoleResult = await client.query(`SELECT autoriser_titulaire_multi_classes FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
        const multiClassesAutorise = ecoleResult.rows[0]?.autoriser_titulaire_multi_classes === true;

        if (!multiClassesAutorise) {
          const dejaClasseResult = await client.query(
            `SELECT id, nom FROM classes WHERE titulaire_id = $1 AND id != $2`,
            [titulaire_id, id]
          );
          if (dejaClasseResult.rows.length > 0) {
            throw Object.assign(new Error(
              `Non autorisé : ce titulaire est déjà assigné à "${dejaClasseResult.rows[0].nom}". Un titulaire ne peut gérer qu'une seule classe (modifiable dans Paramètres).`
            ), { statusCode: 409 });
          }
        }
      }

      const cycleValide = cycle ? await verifierCycle(client, cycle) : null;

      // Le cycle effectif après modification sert à valider la vacation :
      // sans cela, on pourrait rattacher une classe de primaire à une
      // vacation réservée au secondaire en deux étapes successives.
      const cycleEffectif = cycleValide
        || (await client.query(`SELECT cycle FROM classes WHERE id = $1`, [id])).rows[0]?.cycle
        || null;
      const vacationValide = vacation_id !== undefined
        ? await verifierVacation(client, vacation_id, cycleEffectif)
        : undefined;

      // option_id, titulaire_id et classe_suivante_id sont affectés
      // directement (pas de COALESCE) : le formulaire envoie toujours ces
      // clés, y compris à null quand l'utilisateur retire une sélection —
      // COALESCE aurait alors silencieusement gardé l'ancienne valeur et
      // donné l'impression que la modification n'a aucun effet.
      await client.query(
        `UPDATE classes SET nom = COALESCE(NULLIF($1, ''), nom),
         option_id = $2, titulaire_id = $3, classe_suivante_id = $4,
         cycle = COALESCE($5, cycle),
         vacation_id = CASE WHEN $7::bool THEN $6::uuid ELSE vacation_id END,
         classe_orientation = COALESCE($9, classe_orientation),
         capacite = CASE WHEN $11::bool THEN $10::int ELSE capacite END,
         annee_scolaire_id = COALESCE($12, annee_scolaire_id),
         niveau = COALESCE($13, niveau),
         division = CASE WHEN $15::bool THEN $14 ELSE division END,
         classe_terminale = COALESCE($16, classe_terminale)
         WHERE id = $8`,
        [nom, option_id || null, titulaire_id || null, classeSuivanteValidee || null,
         cycleValide, vacationValide || null, vacation_id !== undefined, id,
         typeof classe_orientation === 'boolean' ? classe_orientation : null,
         capacite ? Number(capacite) : null, capacite !== undefined,
         annee_scolaire_id || null,
         niveauValide,
         division ? String(division).trim().toUpperCase() : null, division !== undefined,
         typeof classe_terminale === 'boolean' ? classe_terminale : null]
      );

      // Assigner un titulaire APRÈS la création de la classe doit produire le
      // même effet qu'à la création : sans cela, une classe créée sans
      // titulaire puis complétée resterait sans aucun enseignant sur ses cours,
      // et personne ne pourrait y saisir de notes.
      return assignerTitulaireAuxCours(client, id, titulaire_id || null);
    });

    res.json({
      message: bilan.affectations > 0
        ? `Classe mise à jour : titulaire assigné à ${bilan.affectations} cours sans enseignant.`
        : 'Classe mise à jour.'
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification classe:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /classes/dupliquer-pour-nouvelle-annee
 * body: { anneeSourceId, anneeCibleId }
 * Crée, pour l'année cible, une copie de chaque classe de l'année source
 * (même nom/section/option/titulaire), et relie automatiquement chaque
 * ancienne classe à sa copie via classe_suivante_id — point de départ pratique
 * que le Directeur peut ensuite ajuster (fusionner, renommer, etc.) avant la promotion.
 */
/**
 * POST /annees-scolaires/:anneeCibleId/reporter-structure   (Directeur / Préfet)
 * (alias historique : POST /classes/dupliquer-pour-nouvelle-annee)
 * body: { anneeSourceId }
 *
 * Reporte la STRUCTURE d'une année sur une autre. Certaines choses n'ont aucune
 * raison d'être reconfigurées chaque rentrée : une école a les mêmes classes, les
 * mêmes cours par classe et souvent les mêmes professeurs d'une année à l'autre.
 * Ce qui change, ce sont les données DANS cette structure (élèves, notes, frais).
 *
 * Sont reportés :
 *   - les classes (nom, option, titulaire, cycle, vacation, capacité, orientation) ;
 *   - les cours de chaque classe, avec leur maximum de points personnalisé ;
 *   - les affectations des professeurs à ces cours.
 *
 * Ne sont PAS reportés, parce qu'ils sont propres à l'année :
 *   - les périodes, semestres et examens ;
 *   - le calendrier scolaire ;
 *   - les frais scolaires (montants revus chaque année) ;
 *   - les élèves (c'est le rôle de la promotion), les notes, les présences.
 *
 * Le catalogue des cours, les options, les vacations, les créneaux, les mentions et
 * les modèles de bulletins sont déjà rattachés à l'école et non à l'année : ils
 * traversent les années sans rien avoir à faire.
 *
 * L'opération est IDEMPOTENTE : relancée, elle complète sans dupliquer. C'est
 * indispensable — un Directeur qui ajoute une classe après un premier report doit
 * pouvoir relancer sans se retrouver avec deux « 5ème A ». Modifier ou ajouter une
 * classe dans l'année cible n'altère jamais l'année source : ce sont des lignes
 * distinctes, chacune rattachée à son année.
 */
async function reporterStructureAnnee(req, res) {
  const anneeCibleId = req.params.anneeCibleId || req.body.anneeCibleId;
  const { anneeSourceId } = req.body;
  if (!anneeSourceId || !anneeCibleId) {
    return res.status(400).json({ message: 'anneeSourceId et anneeCibleId sont requis.' });
  }
  if (String(anneeSourceId) === String(anneeCibleId)) {
    return res.status(400).json({ message: "L'année source et l'année cible sont identiques." });
  }

  try {
    const bilan = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const annees = await client.query(
        `SELECT id, libelle, cloturee FROM annees_scolaires
          WHERE ecole_id = ${CURRENT_ECOLE} AND id = ANY($1::uuid[])`,
        [[anneeSourceId, anneeCibleId]]
      );
      const source = annees.rows.find((a) => String(a.id) === String(anneeSourceId));
      const cible = annees.rows.find((a) => String(a.id) === String(anneeCibleId));
      if (!source || !cible) {
        throw Object.assign(new Error('Année source ou cible introuvable.'), { statusCode: 404 });
      }
      // Écrire dans une année clôturée reviendrait à réécrire l'histoire.
      if (cible.cloturee) {
        throw Object.assign(
          new Error(`L'année « ${cible.libelle} » est clôturée : on ne peut plus y reporter de structure.`),
          { statusCode: 409 }
        );
      }

      const classesSource = await client.query(
        `SELECT * FROM classes WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1 ORDER BY nom`,
        [anneeSourceId]
      );
      if (classesSource.rows.length === 0) {
        throw Object.assign(
          new Error(`Aucune classe à reporter : l'année « ${source.libelle} » n'en contient aucune.`),
          { statusCode: 400 }
        );
      }

      const bilan = {
        annee_source: source.libelle,
        annee_cible: cible.libelle,
        classes_creees: 0, classes_existantes: 0,
        cours_rattaches: 0, professeurs_affectes: 0,
        seances_reportees: 0,
        titulaires_ignores: []
      };

      for (const classe of classesSource.rows) {
        // Rapprochement par nom : c'est le seul identifiant stable d'une classe
        // aux yeux de l'école (« 5ème A » reste « 5ème A » d'une année sur l'autre).
        const existante = await client.query(
          `SELECT id FROM classes
            WHERE ecole_id = ${CURRENT_ECOLE} AND annee_scolaire_id = $1
              AND lower(btrim(nom)) = lower(btrim($2))`,
          [anneeCibleId, classe.nom]
        );

        let classeCibleId;
        if (existante.rows.length > 0) {
          classeCibleId = existante.rows[0].id;
          bilan.classes_existantes++;
        } else {
          // Le titulaire n'est repris que s'il est toujours en poste : reconduire
          // un professeur parti laisserait une classe avec un titulaire fantôme,
          // incapable de signer les bulletins.
          let titulaireId = null;
          if (classe.titulaire_id) {
            const actif = await client.query(
              `SELECT id FROM utilisateurs
                WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE} AND statut = 'actif'`,
              [classe.titulaire_id]
            );
            if (actif.rows.length > 0) titulaireId = classe.titulaire_id;
            else bilan.titulaires_ignores.push(classe.nom);
          }

          // Le cycle et la vacation DOIVENT être repris. Sans eux, chaque nouvelle
          // année remettrait les classes à zéro : le bulletin retomberait sur le
          // modèle générique et l'emploi du temps perdrait sa grille horaire, sans
          // le moindre message d'erreur.
          // TOUS les attributs de la classe sont repris, pas seulement une
          // partie. Six manquaient, et deux d'entre eux cassaient l'année
          // suivante en silence :
          //   · `niveau` et `division` — sans eux, la promotion ne trouve
          //     aucune classe supérieure et refuse de s'exécuter. Le directeur
          //     découvrait le problème en juin, sans comprendre pourquoi ses
          //     classes reportées étaient « incomplètes » ;
          //   · `section_id`, les deux modèles de bulletin, et le drapeau
          //     terminale, qui retombaient sur leurs valeurs par défaut.
          const creee = await client.query(
            `INSERT INTO classes (ecole_id, nom, section_id, option_id, titulaire_id,
                                  annee_scolaire_id, cycle, vacation_id, classe_orientation,
                                  capacite, niveau, division,
                                  modele_periode_id, modele_annuel_id,
                                  classe_terminale, reconduite_de_id)
             VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING id`,
            [classe.nom, classe.section_id, classe.option_id, titulaireId, anneeCibleId, classe.cycle,
             classe.vacation_id, classe.classe_orientation === true, classe.capacite,
             classe.niveau, classe.division,
             classe.modele_periode_id, classe.modele_annuel_id,
             classe.classe_terminale === true,
             // Trace l'origine : permet de retrouver l'histoire d'une classe à
             // travers les années, au-delà du simple rapprochement par nom.
             classe.id]
          );
          classeCibleId = creee.rows[0].id;
          bilan.classes_creees++;
        }

        // Chaînage utilisé par la promotion pour proposer la classe cible.
        await client.query(
          `UPDATE classes SET classe_suivante_id = $1 WHERE id = $2`,
          [classeCibleId, classe.id]
        );

        // ---------- Cours de la classe ----------
        // C'est ce qui manquait : sans les classe_cours, une classe reportée
        // arrivait vide et il fallait rattacher chaque cours à la main. Et sans
        // cours, aucune note ne peut être saisie.
        const coursSource = await client.query(
          `SELECT cours_id, maximum_points_override, maximum_examen_override
             FROM classe_cours WHERE classe_id = $1`,
          [classe.id]
        );

        for (const cc of coursSource.rows) {
          // NOT EXISTS plutôt que ON CONFLICT : l'index d'unicité est posé par la
          // migration 001, mais le report doit rester correct sur une base pas
          // encore migrée.
          // `maximum_examen_override` était oublié : les barèmes d'examen
          // personnalisés d'une classe disparaissaient à chaque report, et les
          // périodes d'examen de la nouvelle année retombaient silencieusement
          // sur le maximum du catalogue.
          const insere = await client.query(
            `INSERT INTO classe_cours (ecole_id, classe_id, cours_id,
                                       maximum_points_override, maximum_examen_override)
             SELECT ${CURRENT_ECOLE}, $1, $2, $3, $4
              WHERE NOT EXISTS (
                SELECT 1 FROM classe_cours WHERE classe_id = $1 AND cours_id = $2
              )
             RETURNING id`,
            [classeCibleId, cc.cours_id, cc.maximum_points_override, cc.maximum_examen_override]
          );
          if (insere.rows.length > 0) bilan.cours_rattaches++;

          const classeCoursCibleId = insere.rows[0]?.id || (await client.query(
            `SELECT id FROM classe_cours WHERE classe_id = $1 AND cours_id = $2`,
            [classeCibleId, cc.cours_id]
          )).rows[0]?.id;
          if (!classeCoursCibleId) continue;

          // ---------- Professeurs ----------
          const classeCoursSource = await client.query(
            `SELECT id FROM classe_cours WHERE classe_id = $1 AND cours_id = $2`,
            [classe.id, cc.cours_id]
          );
          if (classeCoursSource.rows.length === 0) continue;

          const profs = await client.query(
            `SELECT ec.utilisateur_id FROM enseignant_cours ec
               JOIN utilisateurs u ON u.id = ec.utilisateur_id
              WHERE ec.classe_cours_id = $1 AND u.statut = 'actif'`,
            [classeCoursSource.rows[0].id]
          );

          for (const prof of profs.rows) {
            const affecte = await client.query(
              `INSERT INTO enseignant_cours (ecole_id, utilisateur_id, classe_cours_id)
               SELECT ${CURRENT_ECOLE}, $1, $2
                WHERE NOT EXISTS (
                  SELECT 1 FROM enseignant_cours
                   WHERE utilisateur_id = $1 AND classe_cours_id = $2
                )
               RETURNING id`,
              [prof.utilisateur_id, classeCoursCibleId]
            );
            if (affecte.rows.length > 0) bilan.professeurs_affectes++;
          }
        }

        // ---------- Emploi du temps ----------
        // La grille horaire d'une école ne change pas tous les ans : les mêmes
        // classes ont les mêmes cours aux mêmes heures. La ressaisir chaque
        // rentrée, séance par séance, représente des centaines de manipulations
        // pour un résultat identique.
        //
        // Appariement par (cours, jour, créneau) : les créneaux appartiennent à
        // l'école, pas à l'année, ils sont donc les mêmes des deux côtés.
        const seances = await client.query(
          `INSERT INTO emploi_du_temps
             (ecole_id, classe_id, classe_cours_id, jour, creneau_id, annee_scolaire_id, cree_par)
           SELECT ${CURRENT_ECOLE}, $1, ccn.id, e.jour, e.creneau_id, $3, $4
             FROM emploi_du_temps e
             JOIN classe_cours cca ON cca.id = e.classe_cours_id
             JOIN classe_cours ccn ON ccn.classe_id = $1 AND ccn.cours_id = cca.cours_id
            WHERE e.classe_id = $2 AND e.ecole_id = ${CURRENT_ECOLE}
              AND NOT EXISTS (
                SELECT 1 FROM emploi_du_temps d
                 WHERE d.classe_id = $1 AND d.jour = e.jour AND d.creneau_id = e.creneau_id
              )`,
          [classeCibleId, classe.id, anneeCibleId, req.auth.userId]
        );
        bilan.seances_reportees += seances.rowCount;
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES (${CURRENT_ECOLE}, $1, 'annee.structure_reportee', 'annee_scolaire', $2, $3)`,
        [req.auth.userId, anneeCibleId, JSON.stringify(bilan)]
      );

      return bilan;
    });

    const morceaux = [];
    if (bilan.classes_creees > 0) morceaux.push(`${bilan.classes_creees} classe(s) créée(s)`);
    if (bilan.classes_existantes > 0) morceaux.push(`${bilan.classes_existantes} déjà présente(s)`);
    if (bilan.cours_rattaches > 0) morceaux.push(`${bilan.cours_rattaches} cours rattaché(s)`);
    if (bilan.professeurs_affectes > 0) morceaux.push(`${bilan.professeurs_affectes} affectation(s) de professeur`);

    let message = `Structure reportée de ${bilan.annee_source} vers ${bilan.annee_cible} : `
      + (morceaux.length > 0 ? morceaux.join(', ') + '.' : 'rien à ajouter, tout était déjà en place.');
    if (bilan.titulaires_ignores.length > 0) {
      message += ` Titulaire non reconduit (compte inactif) pour : ${bilan.titulaires_ignores.join(', ')}.`;
    }
    message += " Les périodes et le calendrier restent à créer : ils sont propres à chaque année.";

    return res.json({ message, bilan });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur report de structure:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerClasse(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('DELETE FROM classes WHERE id = $1', [id])
    );
    res.json({ message: 'Classe supprimée.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({
        message: "Impossible de supprimer : cette classe contient encore des élèves (ou des cours/notes). Déplace ou supprime d'abord les élèves de cette classe."
      });
    }
    console.error('Erreur suppression classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------- Cours ----------
/**
 * GET /cours
 * Vue d'ensemble des cours de l'école. Les cours étant créés classe par
 * classe, cette liste est le seul endroit où l'on voit l'ensemble : où
 * chaque cours est utilisé, qui l'enseigne, et s'il est encore supprimable.
 */
async function listerCours(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT c.id, c.nom, c.code, c.maximum_points, c.maximum_examen,
                COALESCE(
                  array_agg(DISTINCT cl.nom ORDER BY cl.nom) FILTER (WHERE cl.nom IS NOT NULL),
                  ARRAY[]::text[]
                ) AS classes,
                COALESCE(
                  array_agg(DISTINCT trim(concat(u.prenom, ' ', u.nom)))
                    FILTER (WHERE u.id IS NOT NULL),
                  ARRAY[]::text[]
                ) AS professeurs,
                count(DISTINCT cc.id) AS nb_classes,
                (SELECT count(*) FROM notes n
                  JOIN classe_cours cc2 ON cc2.id = n.classe_cours_id
                 WHERE cc2.cours_id = c.id) AS nb_notes
         FROM cours c
         LEFT JOIN classe_cours cc ON cc.cours_id = c.id
         LEFT JOIN classes cl ON cl.id = cc.classe_id
         LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
         LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
         WHERE c.ecole_id = ${CURRENT_ECOLE}
         GROUP BY c.id, c.nom, c.code, c.maximum_points
         ORDER BY c.nom`
      )
    );
    return res.json(result.rows.map((l) => ({
      ...l,
      maximum_points: l.maximum_points === null ? null : Number(l.maximum_points),
      nb_classes: Number(l.nb_classes),
      nb_notes: Number(l.nb_notes)
    })));
  } catch (err) {
    console.error('Erreur liste cours:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerCours(req, res) {
  const { nom, code, coefficient, maximum_points } = req.body;
  if (!nom) return res.status(400).json({ message: 'nom requis.' });

  // maximum_examen : NULL tant que l'école ne l'a pas configuré (le gabarit
  // retombe alors sur 2x le maximum de période) ; 0 = pas d'examen pour ce
  // cours, ce qui noircit les cases correspondantes sur le bulletin.
  //
  // ATTENTION à ne jamais écrire `maximum_examen || null` : 0 est une valeur
  // JS falsy, cette écriture transformerait silencieusement un "pas d'examen"
  // volontaire en "non configuré", et le gabarit imprimerait alors 2x0 = 0
  // comme s'il s'agissait d'un vrai barème plutôt que de noircir la case.
  let maximumExamen = null;
  if (req.body.maximum_examen !== undefined && req.body.maximum_examen !== null && req.body.maximum_examen !== '') {
    maximumExamen = Number(req.body.maximum_examen);
    if (!Number.isFinite(maximumExamen) || maximumExamen < 0) {
      return res.status(400).json({ message: "Le maximum de l'examen doit être un nombre positif ou nul (0 = pas d'examen pour ce cours)." });
    }
  }

  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `INSERT INTO cours (ecole_id, nom, code, coefficient, maximum_points, maximum_examen)
       VALUES (${CURRENT_ECOLE}, $1,$2,COALESCE($3,1),COALESCE($4,20),$5) RETURNING id`,
      [nom, code, coefficient, maximum_points, maximumExamen]
    )
  );
  res.status(201).json({ id: result.rows[0].id });
}

async function modifierCours(req, res) {
  const { id } = req.params;
  const { nom, code, maximum_points } = req.body;

  if (nom !== undefined && !String(nom).trim()) {
    return res.status(400).json({ message: 'Le nom du cours ne peut pas être vide.' });
  }
  let maximum = null;
  if (maximum_points !== undefined && maximum_points !== null && maximum_points !== '') {
    maximum = Number(maximum_points);
    if (!Number.isFinite(maximum) || maximum <= 0) {
      return res.status(400).json({ message: 'Le maximum de points doit être un nombre supérieur à 0.' });
    }
  }

  // maximum_examen suit la même convention que maximum_points ci-dessus (champ
  // absent ou vide → COALESCE conserve la valeur actuelle), à une différence
  // près et essentielle : 0 est une valeur LÉGITIME ici (« ce cours n'a pas
  // d'examen »), alors que pour maximum_points 0 serait une erreur de saisie.
  // D'où le test explicite `maximum_examen < 0` et non `<= 0`.
  let maximumExamen = null;
  if (req.body.maximum_examen !== undefined && req.body.maximum_examen !== null && req.body.maximum_examen !== '') {
    maximumExamen = Number(req.body.maximum_examen);
    if (!Number.isFinite(maximumExamen) || maximumExamen < 0) {
      return res.status(400).json({ message: "Le maximum de l'examen doit être un nombre positif ou nul (0 = pas d'examen pour ce cours)." });
    }
  }

  try {
    const modifies = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Baisser le maximum sous une note déjà saisie rendrait cette note
      // invalide au prochain enregistrement : on refuse plutôt que de créer
      // une incohérence silencieuse.
      if (maximum !== null) {
        const trop = await client.query(
          `SELECT max(n.points_obtenus) AS plus_haute
           FROM notes n JOIN classe_cours cc ON cc.id = n.classe_cours_id
           WHERE cc.cours_id = $1 AND cc.maximum_points_override IS NULL`,
          [id]
        );
        const plusHaute = trop.rows[0].plus_haute;
        if (plusHaute !== null && Number(plusHaute) > maximum) {
          throw Object.assign(
            new Error(`Impossible : une note de ${Number(plusHaute)} a déjà été saisie pour ce cours. Le maximum ne peut pas descendre en dessous.`),
            { statusCode: 409 }
          );
        }
      }

      const r = await client.query(
        `UPDATE cours SET nom = COALESCE($1, nom), code = $2,
         maximum_points = COALESCE($3, maximum_points),
         maximum_examen = COALESCE($4, maximum_examen)
         WHERE id = $5 AND ecole_id = ${CURRENT_ECOLE}`,
        [nom ? String(nom).trim() : null, code === undefined ? null : (code || null), maximum, maximumExamen, id]
      );
      return r.rowCount;
    });

    if (modifies === 0) return res.status(404).json({ message: 'Cours introuvable.' });
    return res.json({ message: 'Cours mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification cours:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerCours(req, res) {
  const { id } = req.params;
  try {
    const supprimes = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const r = await client.query(
        `DELETE FROM cours WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      return r.rowCount;
    });
    if (supprimes === 0) return res.status(404).json({ message: 'Cours introuvable.' });
    res.json({ message: 'Cours supprimé.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({ message: 'Impossible de supprimer : ce cours est déjà affecté à une ou plusieurs classes, ou des notes existent pour lui.' });
    }
    console.error('Erreur suppression cours:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------- Affectation cours <-> classe ----------
async function affecterCoursAClasse(req, res) {
  const { classe_id } = req.params;
  const { cours_id, maximum_points_override } = req.body;
  if (!cours_id) return res.status(400).json({ message: 'cours_id requis.' });

  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `INSERT INTO classe_cours (ecole_id, classe_id, cours_id, maximum_points_override)
       VALUES (${CURRENT_ECOLE}, $1,$2,$3)
       ON CONFLICT (classe_id, cours_id) DO UPDATE SET maximum_points_override = EXCLUDED.maximum_points_override
       RETURNING id`,
      [classe_id, cours_id, maximum_points_override || null]
    )
  );
  res.status(201).json({ id: result.rows[0].id });
}

/**
 * POST /classes/:classe_id/nouveau-cours
 * body: { nom, code, maximum_points }
 * Crée un cours ET l'assigne à cette classe en une seule étape — chaque cours
 * est ainsi toujours créé pour une classe précise, jamais depuis un catalogue
 * global partagé entre toutes les classes.
 */
async function creerCoursPourClasse(req, res) {
  const { classe_id } = req.params;
  const { nom, code, maximum_points } = req.body;
  if (!nom) return res.status(400).json({ message: 'nom requis.' });

  // Voir la note détaillée dans creerCours() : null = pas encore configuré
  // (2x le maximum de période par défaut), 0 = explicitement pas d'examen
  // (case noircie sur le bulletin). Ne jamais réduire via `|| null`, 0 est
  // une valeur volontaire à préserver telle quelle.
  let maximumExamen = null;
  if (req.body.maximum_examen !== undefined && req.body.maximum_examen !== null && req.body.maximum_examen !== '') {
    maximumExamen = Number(req.body.maximum_examen);
    if (!Number.isFinite(maximumExamen) || maximumExamen < 0) {
      return res.status(400).json({ message: "Le maximum de l'examen doit être un nombre positif ou nul (0 = pas d'examen pour ce cours)." });
    }
  }

  const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
    const coursResult = await client.query(
      `INSERT INTO cours (ecole_id, nom, code, maximum_points, maximum_examen)
       VALUES (${CURRENT_ECOLE}, $1,$2,COALESCE($3,20),$4) RETURNING id`,
      [nom, code || null, maximum_points, maximumExamen]
    );
    const coursId = coursResult.rows[0].id;

    const classeCoursResult = await client.query(
      `INSERT INTO classe_cours (ecole_id, classe_id, cours_id) VALUES (${CURRENT_ECOLE}, $1,$2) RETURNING id`,
      [classe_id, coursId]
    );

    return { cours_id: coursId, classe_cours_id: classeCoursResult.rows[0].id };
  });

  res.status(201).json(resultat);
}

/**
 * DELETE /classes/:classe_id/cours/:cours_id
 * Retire un cours de cette classe. Comme un cours est propre à une classe
 * (plus de catalogue partagé), on supprime aussi le cours lui-même — sauf
 * s'il a déjà des notes, auquel cas on bloque pour ne rien perdre.
 */
async function retirerCoursDeClasse(req, res) {
  const { classe_id, cours_id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      await client.query(`DELETE FROM classe_cours WHERE classe_id = $1 AND cours_id = $2`, [classe_id, cours_id]);
      await client.query(`DELETE FROM cours WHERE id = $1`, [cours_id]);
    });
    res.json({ message: 'Cours retiré de la classe.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({ message: 'Impossible : des notes existent déjà pour ce cours.' });
    }
    console.error('Erreur retrait cours de classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

// ---------- Affectation professeur <-> cours de classe ----------
async function affecterProfesseur(req, res) {
  const { classe_cours_id } = req.params;
  const { utilisateur_id } = req.body;
  if (!utilisateur_id) return res.status(400).json({ message: 'utilisateur_id requis.' });

  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `INSERT INTO enseignant_cours (ecole_id, utilisateur_id, classe_cours_id)
       VALUES (${CURRENT_ECOLE}, $1,$2)
       ON CONFLICT (utilisateur_id, classe_cours_id) DO NOTHING
       RETURNING id`,
      [utilisateur_id, classe_cours_id]
    )
  );
  res.status(201).json({ id: result.rows[0]?.id || null });
}

// ---------- Cours assignés à une classe (avec professeur éventuel) ----------

async function listerCoursDeClasse(req, res) {
  const { classe_id } = req.params;
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `SELECT cc.id AS classe_cours_id, c.id AS cours_id, c.nom, c.code,
              COALESCE(cc.maximum_points_override, c.maximum_points) AS maximum,
              -- Même logique que le maximum de période : la classe peut ajuster
              -- le barème d'examen du cours (classe_cours.maximum_examen_override),
              -- sans quoi c'est la valeur du cours qui s'applique.
              COALESCE(cc.maximum_examen_override, c.maximum_examen) AS maximum_examen,
              u.id AS professeur_id, u.nom AS professeur_nom, u.prenom AS professeur_prenom
       FROM classe_cours cc
       JOIN cours c ON c.id = cc.cours_id
       LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
       LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id
       WHERE cc.classe_id = $1
       ORDER BY c.nom`,
      [classe_id]
    )
  );
  res.json(result.rows);
}

// ---------- Périodes ----------
async function listerPeriodes(req, res) {
  const { anneeScolaireId, cycle } = req.query;
  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Sans filtre, cette route renvoyait TOUTES les périodes de TOUTES les années
      // de l'école. Un menu déroulant de périodes se retrouvait donc à proposer
      // « 1ère période » de l'année passée à côté de celle en cours, et le professeur
      // n'avait aucun moyen de les distinguer. Le pivot est désormais imposé.
      const anneeId = await resoudreAnneeGestion(client, req, anneeScolaireId);

      // Filtre de cycle : sans lui, une école « les_deux » verrait les semestres
      // du secondaire se mélanger aux trimestres du primaire dans le même menu.
      // `cycle IS NULL` reste accepté pour les périodes créées avant la migration
      // 003 dans une école mono-cycle, où la colonne ne sert à rien.
      const conditions = [`p.ecole_id = ${CURRENT_ECOLE}`, `p.annee_scolaire_id = $1`];
      const params = [anneeId];
      if (cycle) { params.push(cycle); conditions.push(`(p.cycle IS NULL OR p.cycle::text = $${params.length})`); }

      return client.query(
        `SELECT p.*, a.libelle AS annee_libelle FROM periodes p
         JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
         WHERE ${conditions.join(' AND ')}
         ORDER BY p.numero`,
        params
      );
    });
    return res.json(result.rows);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste périodes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Un trimestre est le pendant, pour le primaire, de ce qu'un semestre est pour
 * le secondaire — mais ce sont deux arbres de périodes DIFFÉRENTS, qui doivent
 * coexister sans se mélanger dans une école « les_deux ». `semestre_id` reste
 * le nom de la colonne de rattachement (P1/P2/examen à leur parent) : rien
 * n'empêche qu'elle pointe vers un parent de type 'trimestre' aussi bien que
 * 'semestre', c'est un simple lien générique « rattaché à cette période mère ».
 *
 * Ce que garantit cette fonction : le cycle de la période est cohérent avec
 * son type (un 'trimestre' ne peut être que primaire, un 'semestre' que
 * secondaire), et — point central — une école « les_deux » DOIT préciser le
 * cycle explicitement, faute de quoi les deux arbres ne pourraient plus être
 * distingués nulle part en aval (listage, archives, sélection du bulletin).
 */
async function verifierCyclePeriode(client, { cycle, type }) {
  const ecoleResult = await client.query(`SELECT type_enseignement FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
  const typeEnseignement = ecoleResult.rows[0]?.type_enseignement;

  // Chaque cycle a SON découpage, et les deux ne se mélangent pas :
  //   primaire   → 3 trimestres, chacun = 2 périodes + 1 examen (bulletin
  //                officiel « DEGRÉ ÉLÉMENTAIRE », vérifié sur le document de
  //                l'école : colonnes PREMIER / DEUXIÈME / TROISIÈME TRIMESTRE
  //                puis TOTAL, sans aucun niveau de semestre) ;
  //   secondaire → 2 semestres, chacun = 2 périodes + 1 examen.
  //
  // Un semestre au primaire est donc refusé au même titre qu'un trimestre au
  // secondaire : ni l'un ni l'autre n'a de colonne dans le bulletin de son
  // cycle, et le créer ne produirait qu'une période orpheline dont les notes
  // n'apparaîtraient nulle part.
  const cycleAttendu = { trimestre: 'primaire', semestre: 'secondaire' }[type];
  if (cycleAttendu && cycle && cycle !== cycleAttendu) {
    throw Object.assign(
      new Error(`Une période de type « ${type} » appartient au cycle ${cycleAttendu}, pas ${cycle}.`),
      { statusCode: 400 }
    );
  }

  if (typeEnseignement === 'les_deux') {
    // Les deux arbres coexistent : sans indication explicite, impossible de
    // savoir à quel cycle rattacher cette période. On ne devine pas.
    const cycleResolu = cycle || cycleAttendu;
    if (!cycleResolu) {
      throw Object.assign(
        new Error("Cette école a le primaire et le secondaire : précisez le cycle de cette période (primaire ou secondaire)."),
        { statusCode: 400 }
      );
    }
    return cycleResolu;
  }

  // École mono-cycle : le cycle ne peut être que celui de l'école. On l'impose
  // plutôt que de faire confiance à une valeur envoyée par erreur.
  return typeEnseignement || cycle || null;
}

async function creerPeriode(req, res) {
  const { annee_scolaire_id, type, numero, libelle, date_debut, date_fin, semestre_id, cycle } = req.body;
  if (!annee_scolaire_id || !type || !numero) {
    return res.status(400).json({ message: 'annee_scolaire_id, type et numero sont requis.' });
  }

  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const anneeResult = await client.query(`SELECT cloturee FROM annees_scolaires WHERE id = $1`, [annee_scolaire_id]);
      if (anneeResult.rows[0]?.cloturee) {
        throw Object.assign(new Error('Cette année scolaire est clôturée, elle ne peut plus être modifiée.'), { statusCode: 403 });
      }

      const cycleResolu = await verifierCyclePeriode(client, { cycle, type });

      const inserted = await client.query(
        `INSERT INTO periodes (ecole_id, annee_scolaire_id, type, numero, libelle, date_debut, date_fin, semestre_id, cycle)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [annee_scolaire_id, type, numero, libelle || `${type} ${numero}`, date_debut || null, date_fin || null, semestre_id || null, cycleResolu]
      );
      return inserted.rows[0].id;
    });
    res.status(201).json({ id: result });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création période:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /periodes/:id
 * body: { semestre_id, libelle, date_debut, date_fin }
 * Sert notamment à rattacher (ou détacher) une période/examen déjà existant
 * à un semestre, sans avoir à la recréer.
 */
async function modifierPeriode(req, res) {
  const { id } = req.params;
  const { semestre_id, libelle, date_debut, date_fin } = req.body;

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const anneeResult = await client.query(
        `SELECT a.cloturee FROM periodes p JOIN annees_scolaires a ON a.id = p.annee_scolaire_id WHERE p.id = $1`,
        [id]
      );
      if (anneeResult.rows[0]?.cloturee) {
        throw Object.assign(new Error('Cette année scolaire est clôturée.'), { statusCode: 403 });
      }

      await client.query(
        `UPDATE periodes SET
           semestre_id = COALESCE($1, semestre_id),
           libelle = COALESCE($2, libelle),
           date_debut = COALESCE($3, date_debut),
           date_fin = COALESCE($4, date_fin)
         WHERE id = $5`,
        [semestre_id || null, libelle, date_debut, date_fin, id]
      );
    });
    res.json({ message: 'Période mise à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification période:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerPeriode(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('DELETE FROM periodes WHERE id = $1', [id])
    );
    res.json({ message: 'Période supprimée.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({ message: 'Impossible de supprimer : des notes ou bulletins existent déjà pour cette période.' });
    }
    console.error('Erreur suppression période:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /mes-cours  (Professeur)
 * Liste uniquement les cours/classes réellement assignés au professeur connecté
 * (via enseignant_cours), pour éviter qu'il ne puisse choisir n'importe quel cours
 * de l'école dans les menus déroulants.
 */
async function listerMesCoursAssignes(req, res) {
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `SELECT cc.id AS classe_cours_id, c.id AS classe_id, c.nom AS classe_nom,
              co.id AS cours_id, co.nom AS cours_nom,
              COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum,
              COALESCE((
                SELECT json_agg(json_build_object(
                  'periode_id', p.id, 'libelle', p.libelle, 'numero', p.numero,
                  'soumis', EXISTS(
                    SELECT 1 FROM notes n WHERE n.classe_cours_id = cc.id AND n.periode_id = p.id AND n.valide = true
                  )
                ) ORDER BY p.numero)
                FROM periodes p
                WHERE p.annee_scolaire_id = c.annee_scolaire_id AND p.type IN ('periode', 'examen')
              ), '[]'::json) AS periodes
       FROM enseignant_cours ec
       JOIN classe_cours cc ON cc.id = ec.classe_cours_id
       JOIN classes c ON c.id = cc.classe_id
       JOIN cours co ON co.id = cc.cours_id
       JOIN annees_scolaires a ON a.id = c.annee_scolaire_id AND a.active = true
       WHERE ec.utilisateur_id = $1
       ORDER BY c.nom, co.nom`,
      [req.auth.userId]
    )
  );
  res.json(result.rows);
}

/**
 * GET /ma-classe  (Titulaire)
 * Renvoie la ou les classes dont l'utilisateur connecté est titulaire, avec le
 * nombre d'élèves actifs.
 */
async function obtenirMesClassesTitulaire(req, res) {
  const result = await runWithTenant(tenantContextFromReq(req), (client) =>
    client.query(
      `SELECT c.id, c.nom, o.nom AS option_nom,
              (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS nb_eleves
       FROM classes c
       LEFT JOIN options o ON o.id = c.option_id
       JOIN annees_scolaires a ON a.id = c.annee_scolaire_id AND a.active = true
       WHERE c.titulaire_id = $1
       ORDER BY c.nom`,
      [req.auth.userId]
    )
  );
  res.json(result.rows);
}

/**
 * GET /classes/:classe_id/cours/:cours_id/recap?periodeId=  (Titulaire de cette classe)
 * Pour le cours et la période choisis : moyenne de la classe, nombre d'échecs
 * et de réussites, comparés au seuil de réussite configuré pour l'école.
 */
async function recapCoursPourTitulaire(req, res) {
  const { classe_id, cours_id } = req.params;
  const { periodeId } = req.query;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(`SELECT titulaire_id FROM classes WHERE id = $1`, [classe_id]);
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      if (!req.auth.isSuperAdmin && classeResult.rows[0].titulaire_id !== req.auth.userId
          && !req.auth.roles.includes('directeur') && !req.auth.roles.includes('prefet')) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      const seuilResult = await client.query(`SELECT seuil_promotion_pourcentage FROM ecoles WHERE id = ${CURRENT_ECOLE}`);
      const seuil = Number(seuilResult.rows[0]?.seuil_promotion_pourcentage ?? 50);

      const notesResult = await client.query(
        `SELECT n.eleve_id,
                ROUND((n.points_obtenus / NULLIF(COALESCE(cc.maximum_points_override, c.maximum_points), 0)) * 100, 2) AS pourcentage
         FROM notes n
         JOIN classe_cours cc ON cc.id = n.classe_cours_id
         JOIN cours c ON c.id = cc.cours_id
         WHERE cc.classe_id = $1 AND cc.cours_id = $2 AND n.periode_id = $3 AND n.points_obtenus IS NOT NULL`,
        [classe_id, cours_id, periodeId]
      );

      const pourcentages = notesResult.rows.map(r => Number(r.pourcentage));
      const nbNotes = pourcentages.length;
      const moyenne = nbNotes > 0 ? pourcentages.reduce((a, b) => a + b, 0) / nbNotes : null;
      const reussites = pourcentages.filter(p => p >= seuil).length;
      const echecs = pourcentages.filter(p => p < seuil).length;

      return {
        moyenne_classe: moyenne !== null ? Math.round(moyenne * 100) / 100 : null,
        nb_reussites: reussites, nb_echecs: echecs, nb_notes_saisies: nbNotes, seuil_reussite: seuil
      };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur récap cours titulaire:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /classes/:classe_id/moyenne-generale?periodeId=  (Titulaire de cette classe, ou directeur/préfet)
 * Moyenne réellement globale : tous cours confondus, tous les élèves de la
 * classe, pour la période choisie — ne dépend PAS du cours sélectionné dans
 * l'écran, seulement de la période.
 */
async function moyenneGeneraleClasse(req, res) {
  const { classe_id } = req.params;
  const { periodeId } = req.query;
  if (!periodeId) return res.status(400).json({ message: 'periodeId requis.' });

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(`SELECT titulaire_id FROM classes WHERE id = $1`, [classe_id]);
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      if (!req.auth.isSuperAdmin && classeResult.rows[0].titulaire_id !== req.auth.userId
          && !req.auth.roles.includes('directeur') && !req.auth.roles.includes('prefet')) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      const moyenneResult = await client.query(
        `SELECT AVG(b.pourcentage) AS moyenne
         FROM bulletins b JOIN eleves e ON e.id = b.eleve_id
         WHERE e.classe_id = $1 AND b.periode_id = $2 AND e.statut = 'actif'`,
        [classe_id, periodeId]
      );
      const moyenne = moyenneResult.rows[0].moyenne;
      return { moyenne_generale: moyenne !== null ? Math.round(Number(moyenne) * 100) / 100 : null };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur moyenne générale classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /classes/:classe_id/etat-periodes  (Titulaire de cette classe, ou directeur/préfet)
 * Pour chaque période/examen de l'année active : est-ce que TOUS les cours de
 * cette classe ont été soumis (verrouillés) pour cette période ?
 */
async function etatPeriodesClasse(req, res) {
  const { classe_id } = req.params;

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(`SELECT titulaire_id, annee_scolaire_id, nom FROM classes WHERE id = $1`, [classe_id]);
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      const classe = classeResult.rows[0];
      if (!req.auth.isSuperAdmin && classe.titulaire_id !== req.auth.userId
          && !req.auth.roles.includes('directeur') && !req.auth.roles.includes('prefet')) {
        throw Object.assign(new Error("Vous n'êtes pas titulaire de cette classe."), { statusCode: 403 });
      }

      const result = await client.query(
        `SELECT p.id AS periode_id, p.libelle, p.numero,
                (SELECT count(*) FROM classe_cours cc WHERE cc.classe_id = $1) AS nb_cours,
                (
                  SELECT count(DISTINCT cc.id) FROM classe_cours cc
                  WHERE cc.classe_id = $1
                  AND EXISTS (SELECT 1 FROM notes n WHERE n.classe_cours_id = cc.id AND n.periode_id = p.id AND n.valide = true)
                ) AS nb_cours_soumis
         FROM periodes p
         WHERE p.annee_scolaire_id = $2 AND p.type IN ('periode', 'examen')
         ORDER BY p.numero`,
        [classe_id, classe.annee_scolaire_id]
      );

      // count() PostgreSQL arrive en chaîne de caractères : sans Number(), "9" >= "10"
      // est VRAI en comparaison de texte et une période incomplète serait marquée clôturée.
      const periodes = result.rows.map(r => ({
        ...r,
        nb_cours: Number(r.nb_cours),
        nb_cours_soumis: Number(r.nb_cours_soumis),
        soumis: Number(r.nb_cours) > 0 && Number(r.nb_cours_soumis) >= Number(r.nb_cours)
      }));

      return { classe_nom: classe.nom, periodes, toutes_soumises: periodes.length > 0 && periodes.every(p => p.soumis) };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur état périodes classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Vacations — régimes horaires de l'école
   Une vacation sans cycle est commune aux deux ; avec un cycle, elle est
   réservée à celui-ci. C'est ce qui permet à une école d'avoir des horaires
   communs OU séparés entre primaire et secondaire, selon son organisation.
   ========================================================================== */

async function listerVacations(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Étanchéité primaire / secondaire : une école qui ne fait que le
      // primaire n'a rien à faire d'une vacation déclarée pour le secondaire.
      // Même règle et même formulation que le filtrage des modèles de
      // bulletins (`modeles-bulletins.controller.js`), pour que les deux
      // écrans se comportent pareil.
      //
      // Une vacation SANS cycle reste toujours visible : elle est antérieure à
      // l'introduction du cycle, et la masquer la rendrait impossible à
      // corriger — on ne cache jamais une donnée qui deviendrait inatteignable.
      const ecoleResult = await client.query(
        `SELECT type_enseignement FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const typeEnseignement = ecoleResult.rows[0]?.type_enseignement;

      const params = [];
      let filtreCycle = '';
      if (typeEnseignement && typeEnseignement !== 'les_deux') {
        params.push(typeEnseignement);
        filtreCycle = ` AND (v.cycle IS NULL OR v.cycle::text = $${params.length})`;
      }

      return client.query(
        `SELECT v.id, v.nom, v.cycle::text, v.ordre,
                (SELECT count(*) FROM creneaux cr WHERE cr.vacation_id = v.id) AS nb_creneaux,
                (SELECT count(*) FROM classes c WHERE c.vacation_id = v.id) AS nb_classes
         FROM vacations v
         WHERE v.ecole_id = ${CURRENT_ECOLE}${filtreCycle}
         ORDER BY v.ordre, v.nom`,
        params
      );
    });
    return res.json(result.rows.map((v) => ({
      ...v, nb_creneaux: Number(v.nb_creneaux), nb_classes: Number(v.nb_classes)
    })));
  } catch (err) {
    console.error('Erreur liste vacations:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function creerVacation(req, res) {
  const { nom, cycle } = req.body;
  if (!nom || !String(nom).trim()) {
    return res.status(400).json({ message: 'Le nom de la vacation est requis.' });
  }
  if (cycle && !CYCLES.includes(cycle)) {
    return res.status(400).json({ message: 'Cycle inconnu.' });
  }

  try {
    const id = await runWithTenant(tenantContextFromReq(req), async (client) => {
      if (cycle) await verifierCycle(client, cycle);
      const ordre = await client.query(
        `SELECT COALESCE(max(ordre), 0) + 1 AS suivant FROM vacations WHERE ecole_id = ${CURRENT_ECOLE}`
      );
      const r = await client.query(
        `INSERT INTO vacations (ecole_id, nom, cycle, ordre)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3) RETURNING id`,
        [String(nom).trim(), cycle || null, ordre.rows[0].suivant]
      );
      return r.rows[0].id;
    });
    return res.status(201).json({ id, message: 'Vacation créée.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création vacation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function modifierVacation(req, res) {
  const { id } = req.params;
  const { nom, cycle } = req.body;
  if (cycle !== undefined && cycle !== null && !CYCLES.includes(cycle)) {
    return res.status(400).json({ message: 'Cycle inconnu.' });
  }

  try {
    const modifiees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Restreindre une vacation à un cycle alors qu'elle sert déjà à des
      // classes de l'autre cycle laisserait ces classes dans un état
      // impossible : on refuse plutôt que de les détacher en silence.
      if (cycle) {
        const conflit = await client.query(
          `SELECT c.nom FROM classes c
           WHERE c.vacation_id = $1 AND c.cycle IS NOT NULL AND c.cycle::text <> $2
           LIMIT 3`,
          [id, cycle]
        );
        if (conflit.rows.length > 0) {
          throw Object.assign(
            new Error(`Impossible : ${conflit.rows.map((c) => c.nom).join(', ')} utilisent cette vacation dans l'autre cycle.`),
            { statusCode: 409 }
          );
        }
      }
      const r = await client.query(
        `UPDATE vacations SET nom = COALESCE($1, nom),
                              cycle = CASE WHEN $3::bool THEN $2::cycle_enseignement ELSE cycle END
         WHERE id = $4 AND ecole_id = ${CURRENT_ECOLE}`,
        [nom ? String(nom).trim() : null, cycle || null, cycle !== undefined, id]
      );
      return r.rowCount;
    });
    if (modifiees === 0) return res.status(404).json({ message: 'Vacation introuvable.' });
    return res.json({ message: 'Vacation mise à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification vacation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function supprimerVacation(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classes = await client.query(
        `SELECT nom FROM classes WHERE vacation_id = $1 LIMIT 3`, [id]
      );
      if (classes.rows.length > 0) {
        throw Object.assign(
          new Error(`Impossible : ${classes.rows.map((c) => c.nom).join(', ')} y sont rattachées. Déplacez-les d'abord.`),
          { statusCode: 409 }
        );
      }
      const r = await client.query(
        `DELETE FROM vacations WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`, [id]
      );
      if (r.rowCount === 0) {
        throw Object.assign(new Error('Vacation introuvable.'), { statusCode: 404 });
      }
    });
    return res.json({ message: 'Vacation supprimée.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur suppression vacation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /classes/:classe_id/apercu
 *
 * Fiche de synthèse d'une classe : identité, effectif, cours avec leur
 * professeur, et signalement de ce qui manque.
 *
 * Rassemblée en un seul appel plutôt qu'en trois (classe, cours, effectif) :
 * une fenêtre qui s'ouvre au clic doit s'afficher d'un coup, et non se remplir
 * par morceaux au fil des réponses.
 *
 * Les ANOMALIES sont calculées ici plutôt que laissées à l'oeil du directeur :
 * un cours sans professeur ne se voit pas dans une liste de vingt lignes, et
 * c'est pourtant ce qui bloquera la saisie des notes en fin de période.
 */
async function apercuClasse(req, res) {
  const { classe_id } = req.params;

  try {
    const donnees = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const classeResult = await client.query(
        `SELECT c.id, c.nom, c.cycle::text AS cycle, c.capacite, c.niveau, c.division,
                c.classe_orientation, c.classe_terminale,
                o.nom AS option_nom, s.nom AS section_nom, v.nom AS vacation_nom,
                a.libelle AS annee_libelle, a.active AS annee_active,
                t.id AS titulaire_id,
                trim(concat(t.prenom, ' ', t.nom)) AS titulaire_nom,
                t.email AS titulaire_email, t.telephone AS titulaire_telephone,
                cs.nom AS classe_suivante_nom
           FROM classes c
           LEFT JOIN options o ON o.id = c.option_id
           LEFT JOIN sections s ON s.id = c.section_id
           LEFT JOIN vacations v ON v.id = c.vacation_id
           LEFT JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
           LEFT JOIN utilisateurs t ON t.id = c.titulaire_id
           LEFT JOIN classes cs ON cs.id = c.classe_suivante_id
          WHERE c.id = $1 AND c.ecole_id = ${CURRENT_ECOLE}`,
        [classe_id]
      );
      if (classeResult.rows.length === 0) {
        throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
      }
      const classe = classeResult.rows[0];

      const cours = await client.query(
        `SELECT cc.id AS classe_cours_id, c.id AS cours_id, c.nom, c.code,
                COALESCE(cc.maximum_points_override, c.maximum_points) AS maximum,
                COALESCE(cc.maximum_examen_override, c.maximum_examen) AS maximum_examen,
                c.domaine, c.groupe_domaine,
                u.id AS professeur_id,
                trim(concat(u.prenom, ' ', u.nom)) AS professeur_nom
           FROM classe_cours cc
           JOIN cours c ON c.id = cc.cours_id
           LEFT JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
           LEFT JOIN utilisateurs u ON u.id = ec.utilisateur_id AND u.statut = 'actif'
          WHERE cc.classe_id = $1
          ORDER BY c.nom`,
        [classe_id]
      );

      // Un cours peut avoir plusieurs enseignants : on regroupe pour ne pas
      // afficher la même ligne deux fois.
      const parCours = new Map();
      for (const l of cours.rows) {
        if (!parCours.has(l.cours_id)) {
          parCours.set(l.cours_id, {
            classe_cours_id: l.classe_cours_id, cours_id: l.cours_id,
            nom: l.nom, code: l.code,
            maximum: l.maximum === null ? null : Number(l.maximum),
            maximum_examen: l.maximum_examen === null ? null : Number(l.maximum_examen),
            domaine: l.domaine, groupe_domaine: l.groupe_domaine,
            professeurs: []
          });
        }
        if (l.professeur_id) {
          parCours.get(l.cours_id).professeurs.push({ id: l.professeur_id, nom: l.professeur_nom });
        }
      }
      const listeCours = [...parCours.values()];

      const effectif = await client.query(
        `SELECT count(*)::int AS total,
                count(*) FILTER (WHERE sexe = 'M')::int AS garcons,
                count(*) FILTER (WHERE sexe = 'F')::int AS filles
           FROM eleves WHERE classe_id = $1 AND statut = 'actif'`,
        [classe_id]
      );

      const anomalies = [];
      if (!classe.titulaire_id) {
        anomalies.push({ gravite: 'importante', message: "Aucun titulaire n'est assigné à cette classe." });
      }
      if (listeCours.length === 0) {
        anomalies.push({ gravite: 'importante', message: "Aucun cours n'est rattaché à cette classe : la saisie des notes sera impossible." });
      }
      const sansProfesseur = listeCours.filter((c) => c.professeurs.length === 0);
      if (sansProfesseur.length > 0) {
        anomalies.push({
          gravite: 'importante',
          message: `${sansProfesseur.length} cours sans professeur assigné : ${sansProfesseur.map((c) => c.nom).join(', ')}.`
        });
      }
      // Au primaire, la grille officielle est structurée par domaines : un cours
      // sans domaine serait absent du bulletin, sans avertissement à l'impression.
      if (classe.cycle === 'primaire') {
        const sansDomaine = listeCours.filter((c) => !c.domaine);
        if (sansDomaine.length > 0) {
          anomalies.push({
            gravite: 'importante',
            message: `${sansDomaine.length} cours sans domaine : ils n'apparaîtront pas sur le bulletin du primaire (${sansDomaine.map((c) => c.nom).join(', ')}).`
          });
        }
      }
      const total = effectif.rows[0].total;
      if (classe.capacite && total > Number(classe.capacite)) {
        anomalies.push({
          gravite: 'avertissement',
          message: `Effectif (${total}) supérieur à la capacité déclarée (${classe.capacite}).`
        });
      }

      return {
        classe,
        effectif: effectif.rows[0],
        cours: listeCours,
        // Somme des maximums : c'est le total sur lequel les pourcentages seront
        // calculés. L'afficher permet de repérer un barème incohérent avant que
        // les bulletins ne sortent.
        total_maximum: listeCours.reduce((t, c) => t + (c.maximum || 0), 0),
        anomalies
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur aperçu classe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  apercuClasse,
  listerVacations, creerVacation, modifierVacation, supprimerVacation,
  listerAnnees, creerAnnee, activerAnnee, cloturerAnnee,
  listerOptions, creerOption,
  listerClasses, creerClasse, modifierClasse, supprimerClasse,
  reporterStructureAnnee, dupliquerClassesPourNouvelleAnnee: reporterStructureAnnee,
  proposerAnneeSuivante,
  listerCours, creerCours, modifierCours, supprimerCours,
  affecterCoursAClasse, affecterProfesseur, listerCoursDeClasse, creerCoursPourClasse, retirerCoursDeClasse,
  listerPeriodes, creerPeriode, modifierPeriode, supprimerPeriode, listerMesCoursAssignes,
  obtenirMesClassesTitulaire, recapCoursPourTitulaire, moyenneGeneraleClasse, etatPeriodesClasse
};
