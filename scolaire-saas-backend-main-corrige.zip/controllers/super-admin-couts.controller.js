/**
 * Espace Super Administrateur — Services, coûts, dépenses et budgets.
 * ---------------------------------------------------------------------------
 * Couvre les sections 7 à 11, 20 et 22 de la mission.
 *
 * AUCUN SERVICE N'EST CODÉ EN DUR
 * -------------------------------
 * Supabase, Render, GitHub, Resend, OpenAI ne figurent nulle part dans ce
 * fichier ni dans la migration. Ce sont des lignes de `services_externes`,
 * saisies depuis l'interface, avec leur catégorie. La liste de la mission est
 * un exemple, pas un schéma — et un fournisseur remplacé ne doit pas demander
 * un déploiement.
 *
 * COÛTS FIXES ET COÛTS VARIABLES
 * ------------------------------
 * Deux mécanismes distincts, volontairement :
 *   · `services_externes.cout_mensuel` — l'abonnement qui tombe tous les mois ;
 *   · `services_consommations`         — ce qui dépend de l'usage (tokens,
 *     e-mails, SMS, gigaoctets), une ligne par service et par mois.
 * Les mélanger donnerait un coût mensuel qui varie sans qu'on sache pourquoi.
 *
 * ON N'INVENTE JAMAIS DE CHIFFRE
 * ------------------------------
 * Quand une donnée n'est pas saisie, elle vaut `null` et l'interface affiche
 * « à renseigner ». Aucune valeur par défaut plausible n'est fabriquée : un
 * tableau de bord financier rempli de chiffres inventés est pire qu'un
 * tableau de bord vide, parce qu'on le croit.
 */

const { runWithTenant } = require('../config/db');
const cache = require('../utils/cache.utils');
const { mesurer, lignes, pagination, reponsePaginee, motifRecherche } = require('../utils/super-admin.utils');
const F = require('../utils/finance.utils');
const { deviseReference } = require('./super-admin-offres.controller');

const SUPER = { isSuperAdmin: true };

function invaliderCaches() {
  try { cache.invalider('sa:'); } catch { /* sans conséquence */ }
}

const CATEGORIES_DEPENSE = [
  'infrastructure', 'api', 'hebergement', 'domaine', 'marketing',
  'communication', 'logiciels', 'support', 'autres'
];

/* ==========================================================================
   1. SERVICES & INFRASTRUCTURE
   ========================================================================== */

/**
 * GET /super-admin/services
 *
 * Chaque service arrive avec son coût mensuel équivalent (toutes fréquences
 * de facturation ramenées au mois) et sa dernière consommation connue. Le
 * total est calculé ici et non côté navigateur : un service facturé à l'année
 * pèse un douzième par mois, et cette règle doit vivre à un seul endroit.
 */
async function listerServices(req, res) {
  const { categorie, statut, recherche } = req.query;
  const conditions = ["s.statut <> 'archive'"];
  const params = [];
  if (categorie) { params.push(categorie); conditions.push(`s.categorie = $${params.length}`); }
  if (statut) { params.push(statut); conditions.push(`s.statut = $${params.length}`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(s.nom ILIKE $${params.length} OR s.fournisseur ILIKE $${params.length})`);
  }

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const moisCourant = F.moisCourant();
      const moisPrecedent = F.moisCourant(-1);

      const services = await lignes(client, `
        SELECT s.*,
               (SELECT c.cout_reel FROM services_consommations c
                 WHERE c.service_id = s.id AND c.periode = $${params.length + 1}) AS conso_reelle_mois,
               (SELECT c.cout_estime FROM services_consommations c
                 WHERE c.service_id = s.id AND c.periode = $${params.length + 1}) AS conso_estimee_mois,
               (SELECT COALESCE(c.cout_reel, c.cout_estime) FROM services_consommations c
                 WHERE c.service_id = s.id AND c.periode = $${params.length + 2}) AS conso_mois_precedent,
               (SELECT count(*) FROM depenses d WHERE d.service_id = s.id AND NOT d.archive) AS nb_depenses,
               CASE WHEN s.date_renouvellement IS NOT NULL
                    THEN (s.date_renouvellement - current_date) END AS jours_avant_renouvellement
          FROM services_externes s
         WHERE ${conditions.join(' AND ')}
         ORDER BY s.categorie, s.nom`, [...params, moisCourant, moisPrecedent]);

      let totalFixeMensuel = 0;
      let totalVariableMensuel = 0;

      const enrichis = services.map((s) => {
        const fixe = F.coutMensuelService(s);
        const variable = s.conso_reelle_mois !== null && s.conso_reelle_mois !== undefined
          ? Number(s.conso_reelle_mois)
          : (s.conso_estimee_mois !== null && s.conso_estimee_mois !== undefined
              ? Number(s.conso_estimee_mois) : null);

        if (s.statut === 'actif') {
          totalFixeMensuel += conv.convertir(fixe, s.devise);
          if (variable !== null) totalVariableMensuel += conv.convertir(variable, s.devise);
        }

        return {
          ...s,
          cout_mensuel_equivalent: F.arrondi(fixe),
          cout_variable_mois: variable === null ? null : F.arrondi(variable),
          cout_total_mois: variable === null ? F.arrondi(fixe) : F.arrondi(fixe + variable),
          variation_conso: (variable !== null && s.conso_mois_precedent)
            ? F.arrondi(((variable - Number(s.conso_mois_precedent)) / Number(s.conso_mois_precedent)) * 100, 1)
            : null,
          conso_a_renseigner: !!s.cout_variable && variable === null
        };
      });

      return {
        devise_reference: conv.reference,
        conversion_approximative: conv.approximatif,
        devises_sans_taux: [...conv.devisesInconnues],
        mois: moisCourant,
        services: enrichis,
        totaux: {
          cout_fixe_mensuel: F.arrondi(totalFixeMensuel),
          cout_variable_mensuel: F.arrondi(totalVariableMensuel),
          cout_mensuel_total: F.arrondi(totalFixeMensuel + totalVariableMensuel),
          cout_annuel_projete: F.arrondi((totalFixeMensuel + totalVariableMensuel) * 12),
          services_actifs: enrichis.filter((s) => s.statut === 'actif').length,
          consommations_a_renseigner: enrichis.filter((s) => s.conso_a_renseigner).length
        },
        par_categorie: Object.entries(
          enrichis.filter((s) => s.statut === 'actif').reduce((acc, s) => {
            acc[s.categorie] = (acc[s.categorie] || 0) + conv.convertir(s.cout_total_mois, s.devise);
            return acc;
          }, {})
        ).map(([categorie, montant]) => ({ categorie, montant: F.arrondi(montant) }))
         .sort((a, b) => b.montant - a.montant)
      };
    });

    return res.json({ ...donnees, peut_ecrire: !!(req.finance && req.finance.peutEcrire) });
  } catch (err) {
    console.error('Erreur liste services:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/services/:id — fiche complète. */
async function detailService(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const s = await client.query('SELECT * FROM services_externes WHERE id = $1', [id]);
      if (!s.rows.length) throw Object.assign(new Error('Service introuvable.'), { statusCode: 404 });

      const [consommations, depensesLiees, historique] = await Promise.all([
        lignes(client, `
          SELECT c.*, trim(concat_ws(' ', u.prenom, u.nom)) AS saisi_par
            FROM services_consommations c
            LEFT JOIN utilisateurs u ON u.id = c.created_by
           WHERE c.service_id = $1 ORDER BY c.periode DESC LIMIT 24`, [id]),
        lignes(client, `
          SELECT d.id, d.libelle, d.montant, d.devise, d.date_depense, d.statut, d.justificatif_url
            FROM depenses d
           WHERE d.service_id = $1 AND NOT d.archive
           ORDER BY d.date_depense DESC LIMIT 30`, [id]),
        lignes(client, `
          SELECT j.action, j.ancienne_valeur, j.nouvelle_valeur, j.raison, j.created_at,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS par
            FROM journal_financier j
            LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
           WHERE j.entite = 'services_externes' AND j.entite_id = $1
           ORDER BY j.created_at DESC LIMIT 30`, [id])
      ]);

      return {
        service: {
          ...s.rows[0],
          cout_mensuel_equivalent: F.arrondi(F.coutMensuelService(s.rows[0]))
        },
        consommations,
        depenses: depensesLiees,
        historique
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur détail service:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

const CHAMPS_SERVICE = {
  nom: (v) => F.texte(v, 120),
  categorie: (v) => F.texte(v, 60),
  fournisseur: (v) => F.texte(v, 120),
  plan: (v) => F.texte(v, 60),
  devise: (v) => F.texte(v, 8),
  unite: (v) => F.texte(v, 40),
  url: (v) => F.texte(v, 500),
  notes: (v) => F.texte(v, 3000),
  cout_mensuel: (v) => F.nombrePositif(v) ?? 0,
  cout_annuel: (v) => F.nombrePositif(v),
  prix_unitaire: (v) => F.nombrePositif(v),
  limite_incluse: (v) => F.nombrePositif(v),
  jour_facturation: (v) => F.entier(v, 1, 31),
  date_renouvellement: (v) => F.dateIso(v)
};

/** POST /super-admin/services */
async function creerService(req, res) {
  const b = req.body || {};
  const nom = F.texte(b.nom, 120);
  if (!nom) return res.status(400).json({ message: 'Le nom du service est requis.' });

  try {
    const service = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO services_externes
           (nom, categorie, fournisseur, plan, cout_mensuel, cout_annuel, devise,
            cout_variable, prix_unitaire, unite, limite_incluse, jour_facturation,
            frequence_facturation, date_renouvellement, statut, critique, url, notes, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
         RETURNING *`,
        [
          nom,
          F.texte(b.categorie, 60) || 'autre',
          F.texte(b.fournisseur, 120),
          F.texte(b.plan, 60),
          F.nombrePositif(b.cout_mensuel) ?? 0,
          F.nombrePositif(b.cout_annuel),
          F.texte(b.devise, 8) || 'USD',
          b.cout_variable === true,
          F.nombrePositif(b.prix_unitaire),
          F.texte(b.unite, 40),
          F.nombrePositif(b.limite_incluse),
          F.entier(b.jour_facturation, 1, 31),
          ['mensuelle', 'annuelle', 'trimestrielle', 'a_l_usage', 'ponctuelle'].includes(b.frequence_facturation)
            ? b.frequence_facturation : 'mensuelle',
          F.dateIso(b.date_renouvellement),
          ['actif', 'suspendu', 'resilie'].includes(b.statut) ? b.statut : 'actif',
          b.critique === true,
          F.texte(b.url, 500),
          F.texte(b.notes, 3000),
          req.auth.userId
        ]
      );

      await F.journaliser(client, req, {
        action: 'service.cree', entite: 'services_externes', entiteId: r.rows[0].id,
        libelle: nom,
        nouvelleValeur: { cout_mensuel: r.rows[0].cout_mensuel, devise: r.rows[0].devise, categorie: r.rows[0].categorie },
        montant: r.rows[0].cout_mensuel, devise: r.rows[0].devise
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Service enregistré.', service });
  } catch (err) {
    console.error('Erreur création service:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/services/:id */
async function modifierService(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const colonnes = [];
  const params = [];
  const modifications = {};

  for (const [champ, nettoyer] of Object.entries(CHAMPS_SERVICE)) {
    if (!(champ in b)) continue;
    const valeur = nettoyer(b[champ]);
    params.push(valeur);
    colonnes.push(`${champ} = $${params.length}`);
    modifications[champ] = valeur;
  }
  for (const [champ, valeurs] of [
    ['statut', ['actif', 'suspendu', 'resilie', 'archive']],
    ['frequence_facturation', ['mensuelle', 'annuelle', 'trimestrielle', 'a_l_usage', 'ponctuelle']]
  ]) {
    if (champ in b && valeurs.includes(b[champ])) {
      params.push(b[champ]);
      colonnes.push(`${champ} = $${params.length}`);
      modifications[champ] = b[champ];
    }
  }
  for (const champ of ['cout_variable', 'critique']) {
    if (champ in b) {
      params.push(b[champ] === true);
      colonnes.push(`${champ} = $${params.length}`);
      modifications[champ] = b[champ] === true;
    }
  }

  if (!colonnes.length) return res.status(400).json({ message: 'Aucune modification transmise.' });
  params.push(id);

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM services_externes WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Service introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE services_externes SET ${colonnes.join(', ')} WHERE id = $${params.length} RETURNING *`,
        params);

      const ancien = {};
      for (const cle of Object.keys(modifications)) ancien[cle] = avant.rows[0][cle];

      await F.journaliser(client, req, {
        action: 'service.modifie', entite: 'services_externes', entiteId: id,
        libelle: r.rows[0].nom, ancienneValeur: ancien, nouvelleValeur: modifications,
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Service mis à jour.', service: resultat });
  } catch (err) {
    console.error('Erreur modification service:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   2. CONSOMMATIONS VARIABLES
   ========================================================================== */

/**
 * PUT /super-admin/services/:id/consommations
 * body: { periode: 'YYYY-MM', quantite, prix_unitaire?, cout_reel?, note? }
 *
 * En PUT et non POST : une consommation est identifiée par (service, mois).
 * La saisir deux fois pour le même mois doit corriger, pas empiler — sinon
 * un mois compté deux fois double silencieusement le coût.
 */
async function enregistrerConsommation(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const periode = F.texte(b.periode, 7) || F.moisCourant();
  if (!F.periodeValide(periode)) {
    return res.status(400).json({ message: 'La période doit être au format AAAA-MM.' });
  }

  const quantite = F.nombrePositif(b.quantite);
  if (quantite === null) return res.status(400).json({ message: 'La quantité consommée est requise.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const s = await client.query('SELECT * FROM services_externes WHERE id = $1', [id]);
      if (!s.rows.length) throw Object.assign(new Error('Service introuvable.'), { statusCode: 404 });
      const service = s.rows[0];

      const prixUnitaire = F.nombrePositif(b.prix_unitaire) ?? (service.prix_unitaire !== null ? Number(service.prix_unitaire) : null);

      // Coût estimé : seule la part au-delà de la limite incluse est facturée.
      // Sans cette soustraction, un forfait « 100 000 e-mails inclus » ferait
      // apparaître un coût dès le premier e-mail.
      let coutEstime = null;
      if (prixUnitaire !== null) {
        const incluse = service.limite_incluse !== null ? Number(service.limite_incluse) : 0;
        const facturable = Math.max(0, quantite - incluse);
        coutEstime = F.arrondi(facturable * prixUnitaire);
      }

      const ancienne = await client.query(
        'SELECT * FROM services_consommations WHERE service_id = $1 AND periode = $2', [id, periode]);

      const r = await client.query(
        `INSERT INTO services_consommations
           (service_id, periode, quantite, unite, prix_unitaire, cout_estime, cout_reel,
            devise, source, note, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
         ON CONFLICT (service_id, periode) DO UPDATE SET
           quantite = EXCLUDED.quantite,
           unite = EXCLUDED.unite,
           prix_unitaire = EXCLUDED.prix_unitaire,
           cout_estime = EXCLUDED.cout_estime,
           cout_reel = COALESCE(EXCLUDED.cout_reel, services_consommations.cout_reel),
           note = EXCLUDED.note,
           source = EXCLUDED.source
         RETURNING *`,
        [id, periode, quantite,
         F.texte(b.unite, 40) || service.unite,
         prixUnitaire, coutEstime,
         F.nombrePositif(b.cout_reel),
         F.texte(b.devise, 8) || service.devise,
         ['manuel', 'automatique', 'facture'].includes(b.source) ? b.source : 'manuel',
         F.texte(b.note, 500),
         req.auth.userId]
      );

      await F.journaliser(client, req, {
        action: 'consommation.enregistree', entite: 'services_consommations', entiteId: r.rows[0].id,
        libelle: `${service.nom} — ${periode}`,
        ancienneValeur: ancienne.rows[0]
          ? { quantite: ancienne.rows[0].quantite, cout_reel: ancienne.rows[0].cout_reel }
          : null,
        nouvelleValeur: { quantite, cout_estime: coutEstime, cout_reel: r.rows[0].cout_reel },
        montant: r.rows[0].cout_reel ?? coutEstime, devise: r.rows[0].devise
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Consommation enregistrée.', consommation: resultat });
  } catch (err) {
    console.error('Erreur consommation:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   3. DÉPENSES
   ========================================================================== */

/** GET /super-admin/depenses */
async function listerDepenses(req, res) {
  const { page, taille, decalage } = pagination(req, 30);
  const { categorie, statut, service_id, depuis, jusqu, recherche, archivees } = req.query;

  const conditions = [];
  const params = [];
  if (String(archivees || '') !== 'oui') conditions.push('NOT d.archive');
  if (categorie) { params.push(categorie); conditions.push(`d.categorie = $${params.length}`); }
  if (statut) { params.push(statut); conditions.push(`d.statut = $${params.length}`); }
  if (service_id) { params.push(service_id); conditions.push(`d.service_id = $${params.length}::uuid`); }
  if (F.dateIso(depuis)) { params.push(F.dateIso(depuis)); conditions.push(`d.date_depense >= $${params.length}::date`); }
  if (F.dateIso(jusqu)) { params.push(F.dateIso(jusqu)); conditions.push(`d.date_depense <= $${params.length}::date`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(d.libelle ILIKE $${params.length} OR d.fournisseur ILIKE $${params.length})`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));

      const base = `FROM depenses d LEFT JOIN services_externes s ON s.id = d.service_id ${filtre}`;
      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT d.*, s.nom AS service_nom,
               trim(concat_ws(' ', u.prenom, u.nom)) AS cree_par_nom
          FROM depenses d
          LEFT JOIN services_externes s ON s.id = d.service_id
          LEFT JOIN utilisateurs u ON u.id = d.created_by
          ${filtre}
         ORDER BY d.date_depense DESC, d.created_at DESC
         LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      // Totaux sur l'ENSEMBLE du filtre, pas seulement la page affichée :
      // un total qui change quand on tourne la page ne sert à rien.
      const parDevise = await lignes(client,
        `SELECT d.devise, COALESCE(sum(d.montant),0) AS total ${base} GROUP BY d.devise`, params);
      const totalConverti = parDevise.reduce((s, l) => s + conv.convertir(l.total, l.devise), 0);

      const parCategorie = await lignes(client,
        `SELECT d.categorie, d.devise, COALESCE(sum(d.montant),0) AS total ${base} GROUP BY d.categorie, d.devise`, params);
      const categoriesConsolidees = {};
      for (const l of parCategorie) {
        categoriesConsolidees[l.categorie] = (categoriesConsolidees[l.categorie] || 0) + conv.convertir(l.total, l.devise);
      }

      return {
        total, donnees,
        synthese: {
          devise_reference: conv.reference,
          total_filtre: F.arrondi(totalConverti),
          par_categorie: Object.entries(categoriesConsolidees)
            .map(([categorie, montant]) => ({ categorie, montant: F.arrondi(montant) }))
            .sort((a, b) => b.montant - a.montant)
        }
      };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      synthese: resultat.synthese,
      categories: CATEGORIES_DEPENSE
    }));
  } catch (err) {
    console.error('Erreur liste dépenses:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/depenses */
async function creerDepense(req, res) {
  const b = req.body || {};
  const libelle = F.texte(b.libelle, 200);
  if (!libelle) return res.status(400).json({ message: 'Le libellé de la dépense est requis.' });

  const montant = F.nombrePositif(b.montant);
  if (montant === null) return res.status(400).json({ message: 'Le montant est requis et doit être positif.' });

  const categorie = CATEGORIES_DEPENSE.includes(b.categorie) ? b.categorie : 'autres';

  try {
    const depense = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO depenses
           (service_id, fournisseur, libelle, montant, devise, date_depense, categorie,
            description, recurrence, statut, justificatif_url, justificatif_nom, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
         RETURNING *`,
        [b.service_id || null,
         F.texte(b.fournisseur, 120),
         libelle, montant,
         F.texte(b.devise, 8) || 'USD',
         F.dateIso(b.date_depense) || new Date().toISOString().slice(0, 10),
         categorie,
         F.texte(b.description, 2000),
         ['ponctuelle', 'mensuelle', 'trimestrielle', 'annuelle'].includes(b.recurrence) ? b.recurrence : 'ponctuelle',
         ['prevue', 'payee', 'annulee'].includes(b.statut) ? b.statut : 'payee',
         F.texte(b.justificatif_url, 800),
         F.texte(b.justificatif_nom, 200),
         req.auth.userId]
      );

      await F.journaliser(client, req, {
        action: 'depense.enregistree', entite: 'depenses', entiteId: r.rows[0].id,
        libelle, nouvelleValeur: { montant, devise: r.rows[0].devise, categorie },
        montant, devise: r.rows[0].devise, raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Dépense enregistrée.', depense });
  } catch (err) {
    console.error('Erreur création dépense:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/depenses/:id */
async function modifierDepense(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const colonnes = [];
  const params = [];
  const modifications = {};

  const champs = {
    libelle: (v) => F.texte(v, 200),
    fournisseur: (v) => F.texte(v, 120),
    montant: (v) => F.nombrePositif(v),
    devise: (v) => F.texte(v, 8),
    date_depense: (v) => F.dateIso(v),
    description: (v) => F.texte(v, 2000),
    justificatif_url: (v) => F.texte(v, 800),
    justificatif_nom: (v) => F.texte(v, 200)
  };
  for (const [champ, nettoyer] of Object.entries(champs)) {
    if (!(champ in b)) continue;
    const valeur = nettoyer(b[champ]);
    params.push(valeur);
    colonnes.push(`${champ} = $${params.length}`);
    modifications[champ] = valeur;
  }
  if ('categorie' in b && CATEGORIES_DEPENSE.includes(b.categorie)) {
    params.push(b.categorie); colonnes.push(`categorie = $${params.length}`); modifications.categorie = b.categorie;
  }
  if ('statut' in b && ['prevue', 'payee', 'annulee'].includes(b.statut)) {
    params.push(b.statut); colonnes.push(`statut = $${params.length}`); modifications.statut = b.statut;
  }
  if ('recurrence' in b && ['ponctuelle', 'mensuelle', 'trimestrielle', 'annuelle'].includes(b.recurrence)) {
    params.push(b.recurrence); colonnes.push(`recurrence = $${params.length}`); modifications.recurrence = b.recurrence;
  }

  if (!colonnes.length) return res.status(400).json({ message: 'Aucune modification transmise.' });
  params.push(id);

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM depenses WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Dépense introuvable.'), { statusCode: 404 });
      if (avant.rows[0].archive) {
        throw Object.assign(new Error('Cette dépense est archivée et ne peut plus être modifiée.'), { statusCode: 409 });
      }

      const r = await client.query(
        `UPDATE depenses SET ${colonnes.join(', ')} WHERE id = $${params.length} RETURNING *`, params);

      const ancien = {};
      for (const cle of Object.keys(modifications)) ancien[cle] = avant.rows[0][cle];

      await F.journaliser(client, req, {
        action: 'depense.modifiee', entite: 'depenses', entiteId: id,
        libelle: r.rows[0].libelle, ancienneValeur: ancien, nouvelleValeur: modifications,
        montant: r.rows[0].montant, devise: r.rows[0].devise, raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Dépense mise à jour.', depense: resultat });
  } catch (err) {
    console.error('Erreur modification dépense:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/depenses/:id/archiver
 *
 * Il n'existe volontairement AUCUNE route de suppression. Une dépense
 * supprimée fausse rétroactivement une marge déjà consultée, déjà commentée,
 * peut-être déjà exportée — sans qu'aucune trace n'explique l'écart. On
 * archive, avec un motif obligatoire, et les calculs excluent l'archivé.
 */
async function archiverDepense(req, res) {
  const { id } = req.params;
  const raison = F.texte((req.body || {}).raison, 500);
  if (!raison) return res.status(400).json({ message: 'Un motif est requis pour archiver une dépense.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM depenses WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Dépense introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE depenses
            SET archive = true, archive_par = $2, archive_at = now(), archive_raison = $3
          WHERE id = $1 RETURNING *`,
        [id, req.auth.userId, raison]);

      await F.journaliser(client, req, {
        action: 'depense.archivee', entite: 'depenses', entiteId: id,
        libelle: avant.rows[0].libelle,
        ancienneValeur: { archive: false },
        nouvelleValeur: { archive: true },
        montant: avant.rows[0].montant, devise: avant.rows[0].devise, raison
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Dépense archivée. Elle reste consultable et n\'entre plus dans les calculs.', depense: resultat });
  } catch (err) {
    console.error('Erreur archivage dépense:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. BUDGETS
   ========================================================================== */

/**
 * GET /super-admin/budgets?periode=YYYY-MM
 *
 * Confronte le prévu au réel. Les dépenses réelles sont lues sur la même
 * période, catégorie par catégorie, et la ligne « global » agrège tout.
 */
async function listerBudgets(req, res) {
  const periode = F.texte(req.query.periode, 7) || F.moisCourant();
  if (!F.periodeValide(periode, true)) {
    return res.status(400).json({ message: 'periode doit être au format AAAA-MM ou AAAA.' });
  }
  const annuel = /^\d{4}$/.test(periode);

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const seuil = await reglageNumerique(client, 'finance_budget_seuil_alerte', 90);

      const budgets = await lignes(client,
        'SELECT * FROM budgets WHERE periode = $1 ORDER BY categorie', [periode]);

      const reelles = await lignes(client, `
        SELECT categorie, devise, COALESCE(sum(montant),0) AS total
          FROM depenses
         WHERE NOT archive AND statut <> 'annulee'
           AND to_char(date_depense, $2) = $1
         GROUP BY categorie, devise`, [periode, annuel ? 'YYYY' : 'YYYY-MM']);

      const reelParCategorie = {};
      for (const l of reelles) {
        reelParCategorie[l.categorie] = (reelParCategorie[l.categorie] || 0) + conv.convertir(l.total, l.devise);
      }
      const reelTotal = Object.values(reelParCategorie).reduce((s, v) => s + v, 0);

      const lignesBudget = budgets.map((b) => {
        const reel = b.categorie === 'global' ? reelTotal : (reelParCategorie[b.categorie] || 0);
        const prevu = conv.convertir(b.montant_prevu, b.devise);
        const consomme = prevu > 0 ? (reel / prevu) * 100 : null;
        return {
          ...b,
          depense_reelle: F.arrondi(reel),
          reste: F.arrondi(prevu - reel),
          pourcentage_consomme: consomme === null ? null : F.arrondi(consomme, 1),
          depassement: prevu > 0 && reel > prevu,
          alerte: consomme !== null && consomme >= seuil
        };
      });

      // Catégories dépensées sans budget défini : elles n'apparaîtraient nulle
      // part, alors que ce sont précisément celles qu'on oublie de piloter.
      const sansBudget = Object.entries(reelParCategorie)
        .filter(([c]) => !budgets.some((b) => b.categorie === c))
        .map(([categorie, montant]) => ({ categorie, depense_reelle: F.arrondi(montant) }));

      return {
        periode,
        devise_reference: conv.reference,
        seuil_alerte: seuil,
        budgets: lignesBudget,
        categories_sans_budget: sansBudget,
        categories_disponibles: [...CATEGORIES_DEPENSE, 'global'],
        totaux: {
          prevu: F.arrondi(budgets.filter((b) => b.categorie !== 'global')
            .reduce((s, b) => s + conv.convertir(b.montant_prevu, b.devise), 0)),
          reel: F.arrondi(reelTotal)
        }
      };
    });

    return res.json({ ...donnees, peut_ecrire: !!(req.finance && req.finance.peutEcrire) });
  } catch (err) {
    console.error('Erreur budgets:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function reglageNumerique(client, cle, defaut) {
  try {
    const r = await client.query('SELECT valeur FROM configuration_plateforme WHERE cle = $1', [cle]);
    if (!r.rows.length) return defaut;
    const n = Number(String(r.rows[0].valeur).replace(/"/g, ''));
    return Number.isFinite(n) ? n : defaut;
  } catch { return defaut; }
}

/** PUT /super-admin/budgets — création ou mise à jour (periode, categorie). */
async function definirBudget(req, res) {
  const b = req.body || {};
  const periode = F.texte(b.periode, 7);
  if (!F.periodeValide(periode, true)) {
    return res.status(400).json({ message: 'periode doit être au format AAAA-MM ou AAAA.' });
  }
  const categorie = [...CATEGORIES_DEPENSE, 'global'].includes(b.categorie) ? b.categorie : null;
  if (!categorie) {
    return res.status(400).json({ message: `categorie doit faire partie de : ${[...CATEGORIES_DEPENSE, 'global'].join(', ')}.` });
  }
  const montant = F.nombrePositif(b.montant_prevu);
  if (montant === null) return res.status(400).json({ message: 'montant_prevu est requis.' });

  try {
    const budget = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query(
        'SELECT * FROM budgets WHERE periode = $1 AND categorie = $2', [periode, categorie]);

      const r = await client.query(
        `INSERT INTO budgets (periode, categorie, montant_prevu, devise, note, created_by)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (periode, categorie) DO UPDATE SET
           montant_prevu = EXCLUDED.montant_prevu,
           devise = EXCLUDED.devise,
           note = EXCLUDED.note
         RETURNING *`,
        [periode, categorie, montant, F.texte(b.devise, 8) || 'USD', F.texte(b.note, 500), req.auth.userId]);

      await F.journaliser(client, req, {
        action: avant.rows.length ? 'budget.modifie' : 'budget.defini',
        entite: 'budgets', entiteId: r.rows[0].id,
        libelle: `${categorie} — ${periode}`,
        ancienneValeur: avant.rows[0] ? { montant_prevu: avant.rows[0].montant_prevu } : null,
        nouvelleValeur: { montant_prevu: montant },
        montant, devise: r.rows[0].devise, raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Budget enregistré.', budget });
  } catch (err) {
    console.error('Erreur budget:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. TAUX DE CHANGE
   ========================================================================== */

/** GET /super-admin/taux-change */
async function listerTauxChange(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const reference = await deviseReference(client);

      const taux = await lignes(client, `
        SELECT t.*, trim(concat_ws(' ', u.prenom, u.nom)) AS saisi_par_nom
          FROM finance_taux_change t
          LEFT JOIN utilisateurs u ON u.id = t.saisi_par
         ORDER BY t.devise, t.date_effet DESC
         LIMIT 200`);

      // Devises réellement rencontrées dans les encaissements : c'est la
      // liste des taux qu'il FAUT saisir, pas une liste théorique.
      const devisesUtilisees = await lignes(client, `
        SELECT DISTINCT upper(devise) AS devise FROM paiements WHERE devise IS NOT NULL
        UNION
        SELECT DISTINCT upper(devise) FROM plans_abonnement WHERE devise IS NOT NULL
        UNION
        SELECT DISTINCT upper(devise) FROM services_externes WHERE devise IS NOT NULL
        UNION
        SELECT DISTINCT upper(devise) FROM depenses WHERE devise IS NOT NULL`);

      const conv = await F.convertisseur(client, reference);
      const manquantes = devisesUtilisees
        .map((d) => d.devise)
        .filter((d) => d && d !== reference && conv.taux[d] === undefined);

      return { devise_reference: reference, taux, devises_utilisees: devisesUtilisees.map((d) => d.devise), devises_sans_taux: manquantes };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur taux de change:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/taux-change */
async function enregistrerTauxChange(req, res) {
  const b = req.body || {};
  const devise = F.texte(b.devise, 8);
  if (!devise) return res.status(400).json({ message: 'devise est requise.' });

  const taux = F.nombrePositif(b.taux_vers_reference, { zeroAutorise: false });
  if (taux === null) return res.status(400).json({ message: 'taux_vers_reference doit être un nombre strictement positif.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const reference = await deviseReference(client);
      const r = await client.query(
        `INSERT INTO finance_taux_change (devise, devise_reference, taux_vers_reference, date_effet, saisi_par, note)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (devise, devise_reference, date_effet)
         DO UPDATE SET taux_vers_reference = EXCLUDED.taux_vers_reference,
                       saisi_par = EXCLUDED.saisi_par, note = EXCLUDED.note
         RETURNING *`,
        [devise.toUpperCase(), reference, taux,
         F.dateIso(b.date_effet) || new Date().toISOString().slice(0, 10),
         req.auth.userId, F.texte(b.note, 300)]);

      await F.journaliser(client, req, {
        action: 'taux_change.enregistre', entite: 'finance_taux_change', entiteId: r.rows[0].id,
        libelle: `1 ${devise.toUpperCase()} = ${taux} ${reference}`,
        nouvelleValeur: { taux }, raison: F.texte(b.note, 300)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Taux enregistré.', taux: resultat });
  } catch (err) {
    console.error('Erreur enregistrement taux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   6. CALENDRIER DES FACTURATIONS
   ========================================================================== */

/**
 * GET /super-admin/calendrier-facturation
 *
 * Deux flux dans un seul calendrier : ce qui va être PRÉLEVÉ (renouvellements
 * de services) et ce qui va être ENCAISSÉ (échéances d'abonnements clients).
 * Les séparer en deux écrans obligerait à faire la soustraction de tête.
 */
async function calendrierFacturation(req, res) {
  const jours = F.entier(req.query.jours, 1, 365) || 60;

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));

      const sorties = await lignes(client, `
        SELECT s.id, s.nom, s.fournisseur, s.categorie, s.devise,
               s.cout_mensuel, s.cout_annuel, s.frequence_facturation,
               s.date_renouvellement, s.jour_facturation,
               (s.date_renouvellement - current_date) AS jours_restants
          FROM services_externes s
         WHERE s.statut = 'actif'
           AND s.date_renouvellement IS NOT NULL
           AND s.date_renouvellement BETWEEN current_date - interval '7 days'
                                         AND current_date + ($1 || ' days')::interval
         ORDER BY s.date_renouvellement`, [jours]);

      const entrees = await lignes(client, `
        SELECT a.id, e.nom AS ecole_nom, e.id AS ecole_id,
               p.nom AS plan_nom,
               COALESCE(t.prix_personnalise, a.prix_applique, p.prix) AS montant,
               COALESCE(t.devise, a.devise_appliquee, p.devise) AS devise,
               a.date_expiration,
               (a.date_expiration::date - current_date) AS jours_restants,
               a.statut
          FROM abonnements a
          JOIN ecoles e ON e.id = a.ecole_id
          LEFT JOIN plans_abonnement p ON p.id = a.plan_id
          LEFT JOIN tarifs_personnalises t ON t.ecole_id = a.ecole_id AND t.statut = 'actif'
         WHERE a.date_expiration IS NOT NULL
           AND a.date_expiration BETWEEN current_date - interval '7 days'
                                     AND current_date + ($1 || ' days')::interval
         ORDER BY a.date_expiration`, [jours]);

      const sansDateRenouvellement = await lignes(client, `
        SELECT id, nom, fournisseur FROM services_externes
         WHERE statut = 'actif' AND date_renouvellement IS NULL
         ORDER BY nom`);

      return {
        fenetre_jours: jours,
        devise_reference: conv.reference,
        sorties: sorties.map((s) => ({
          ...s,
          montant_attendu: F.arrondi(
            s.frequence_facturation === 'annuelle' && s.cout_annuel
              ? Number(s.cout_annuel) : Number(s.cout_mensuel || 0))
        })),
        entrees,
        total_sorties: F.arrondi(sorties.reduce((somme, s) => somme + conv.convertir(
          s.frequence_facturation === 'annuelle' && s.cout_annuel ? s.cout_annuel : s.cout_mensuel, s.devise), 0)),
        total_entrees_attendues: F.arrondi(entrees
          .filter((e) => e.statut === 'actif')
          .reduce((somme, e) => somme + conv.convertir(e.montant, e.devise), 0)),
        services_sans_date_renouvellement: sansDateRenouvellement
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur calendrier facturation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  listerServices, detailService, creerService, modifierService,
  enregistrerConsommation,
  listerDepenses, creerDepense, modifierDepense, archiverDepense,
  listerBudgets, definirBudget,
  listerTauxChange, enregistrerTauxChange,
  calendrierFacturation,
  CATEGORIES_DEPENSE
};
