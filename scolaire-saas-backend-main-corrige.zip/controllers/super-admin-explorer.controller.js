const { runWithTenant } = require('../config/db');
const { generateObservationToken } = require('../utils/jwt.utils');
const { mesurer, lignes, pagination, reponsePaginee, motifRecherche } = require('../utils/super-admin.utils');

/*
 * Explorateur de plateforme — lecture seule stricte.
 * ---------------------------------------------------------------------------
 * Le Super Admin parcourt une école comme le ferait son Directeur. La
 * différence tient en une phrase : il ne peut rien changer.
 *
 * Cette garantie ne repose pas sur la discipline de l'interface (masquer les
 * boutons), qui ne protège de rien. Elle repose sur trois barrières
 * indépendantes :
 *
 *   1. `lectureSeule` sur la branche /super-admin/explorer — aucune méthode
 *      d'écriture n'est routée ;
 *   2. ce fichier ne contient aucun INSERT/UPDATE/DELETE — rien à appeler ;
 *   3. le catalogue RESSOURCES ci-dessous est une liste fermée de requêtes
 *      SELECT écrites à la main. Le nom de ressource venu de l'URL sert de clé
 *      dans un objet, jamais de fragment de SQL.
 *
 * Ce troisième point est le cœur du dispositif. La tentation, pour couvrir
 * douze ressources, est d'écrire `SELECT * FROM ${req.params.ressource}`. Cela
 * marcherait — et offrirait à quiconque atteint cette route la lecture de la
 * table `sessions`, `utilisateurs`, ou n'importe quelle autre.
 */

const SUPER = { isSuperAdmin: true };

/**
 * Catalogue des ressources explorables.
 *
 * `colonnes`   : projection SQL (jamais SELECT *, les hash de mots de passe
 *                n'ont rien à faire dans une réponse HTTP).
 * `depuis`     : clause FROM + jointures.
 * `recherche`  : colonnes balayées par la recherche libre.
 * `tri`        : ordre par défaut.
 * `filtres`    : filtres facultatifs autorisés, avec leur expression SQL.
 */
const RESSOURCES = {
  classes: {
    libelle: 'Classes',
    colonnes: `c.id, c.nom, c.niveau, c.division,
               an.libelle AS annee, o.nom AS option, s.nom AS section,
               (SELECT count(*) FROM eleves x WHERE x.classe_id = c.id AND x.statut = 'actif') AS effectif,
               (SELECT count(*) FROM classe_cours cc WHERE cc.classe_id = c.id) AS nb_cours`,
    depuis: `FROM classes c
             LEFT JOIN annees_scolaires an ON an.id = c.annee_scolaire_id
             LEFT JOIN options o ON o.id = c.option_id
             LEFT JOIN sections s ON s.id = c.section_id`,
    cle: 'c.ecole_id',
    recherche: ['c.nom'],
    tri: 'c.nom ASC',
    filtres: { annee_scolaire_id: 'c.annee_scolaire_id = {}::uuid' }
  },

  eleves: {
    libelle: 'Élèves',
    colonnes: `el.id, el.matricule, el.nom, el.postnom, el.prenom, el.sexe,
               el.date_naissance, el.statut, el.created_at,
               c.id AS classe_id, c.nom AS classe`,
    depuis: `FROM eleves el LEFT JOIN classes c ON c.id = el.classe_id`,
    cle: 'el.ecole_id',
    recherche: ['el.nom', 'el.postnom', 'el.prenom', 'el.matricule'],
    tri: 'el.nom ASC',
    filtres: { classe_id: 'el.classe_id = {}::uuid', statut: 'el.statut = {}' }
  },

  enseignants: {
    libelle: 'Enseignants',
    colonnes: `u.id, u.nom, u.prenom, u.email, u.telephone, u.statut, u.created_at,
               (SELECT array_agg(DISTINCT r.role::text) FROM utilisateur_roles r
                WHERE r.utilisateur_id = u.id) AS roles,
               (SELECT count(*) FROM enseignant_cours ec WHERE ec.utilisateur_id = u.id) AS nb_affectations`,
    depuis: `FROM utilisateurs u`,
    cle: 'u.ecole_id',
    conditionSupplementaire: `EXISTS (SELECT 1 FROM utilisateur_roles r
                                      WHERE r.utilisateur_id = u.id
                                        AND r.role::text IN ('professeur','titulaire'))`,
    recherche: ['u.nom', 'u.prenom', 'u.email'],
    tri: 'u.nom ASC'
  },

  parents: {
    libelle: 'Parents',
    colonnes: `u.id, u.nom, u.prenom, u.email, u.telephone, u.statut, u.created_at`,
    depuis: `FROM utilisateurs u`,
    cle: 'u.ecole_id',
    conditionSupplementaire: `EXISTS (SELECT 1 FROM utilisateur_roles r
                                      WHERE r.utilisateur_id = u.id AND r.role::text = 'parent')`,
    recherche: ['u.nom', 'u.prenom', 'u.email', 'u.telephone'],
    tri: 'u.nom ASC'
  },

  cours: {
    libelle: 'Cours',
    colonnes: `co.id, co.nom, co.maximum_points AS maximum, co.coefficient,
               co.domaine, co.groupe_domaine,
               (SELECT count(*) FROM classe_cours cc WHERE cc.cours_id = co.id) AS nb_classes`,
    depuis: `FROM cours co`,
    cle: 'co.ecole_id',
    recherche: ['co.nom', 'co.domaine'],
    tri: 'co.nom ASC'
  },

  horaires: {
    libelle: 'Emploi du temps',
    // `emploi_du_temps` ne porte pas d'enseignant : une séance désigne une
    // classe, un cours et un créneau. C'est `enseignant_cours` qui dit qui
    // assure ce cours dans cette classe. Un cours peut être partagé entre
    // plusieurs enseignants ; on les rassemble donc en une seule cellule
    // plutôt que de dupliquer la ligne d'emploi du temps.
    colonnes: `edt.id, edt.jour, cr.libelle AS creneau, cr.heure_debut, cr.heure_fin,
               c.nom AS classe, co.nom AS cours,
               (SELECT string_agg(trim(concat_ws(' ', u.prenom, u.nom)), ', ')
                  FROM enseignant_cours ec
                  JOIN utilisateurs u ON u.id = ec.utilisateur_id
                 WHERE ec.classe_cours_id = edt.classe_cours_id) AS enseignant`,
    depuis: `FROM emploi_du_temps edt
             LEFT JOIN creneaux cr ON cr.id = edt.creneau_id
             LEFT JOIN classes c ON c.id = edt.classe_id
             LEFT JOIN classe_cours cc ON cc.id = edt.classe_cours_id
             LEFT JOIN cours co ON co.id = cc.cours_id`,
    cle: 'edt.ecole_id',
    recherche: ['c.nom', 'co.nom'],
    tri: 'edt.jour ASC, cr.heure_debut ASC',
    filtres: { classe_id: 'edt.classe_id = {}::uuid' }
  },

  presences: {
    libelle: 'Présences',
    colonnes: `pr.id, pr.date_jour AS date, pr.statut::text AS statut, pr.motif,
               trim(concat_ws(' ', el.nom, el.prenom)) AS eleve,
               el.matricule, c.nom AS classe`,
    depuis: `FROM presences pr
             LEFT JOIN eleves el ON el.id = pr.eleve_id
             LEFT JOIN classes c ON c.id = pr.classe_id`,
    cle: 'pr.ecole_id',
    recherche: ['el.nom', 'el.matricule', 'c.nom'],
    tri: 'pr.date_jour DESC',
    filtres: {
      classe_id: 'pr.classe_id = {}::uuid',
      depuis: 'pr.date_jour >= {}::date',
      jusqu: 'pr.date_jour <= {}::date'
    }
  },

  notes: {
    libelle: 'Notes',
    colonnes: `n.id, n.points_obtenus, n.valide, n.updated_at AS created_at,
               trim(concat_ws(' ', el.nom, el.prenom)) AS eleve, el.matricule,
               co.nom AS cours, c.nom AS classe, p.libelle AS periode`,
    depuis: `FROM notes n
             LEFT JOIN eleves el ON el.id = n.eleve_id
             LEFT JOIN classe_cours cc ON cc.id = n.classe_cours_id
             LEFT JOIN cours co ON co.id = cc.cours_id
             LEFT JOIN classes c ON c.id = cc.classe_id
             LEFT JOIN periodes p ON p.id = n.periode_id`,
    cle: 'n.ecole_id',
    recherche: ['el.nom', 'el.matricule', 'co.nom'],
    tri: 'n.updated_at DESC',
    filtres: { periode_id: 'n.periode_id = {}::uuid', classe_id: 'cc.classe_id = {}::uuid' }
  },

  bulletins: {
    libelle: 'Bulletins',
    colonnes: `b.id, b.total, b.pourcentage, b.classement, b.mention, b.created_at,
               trim(concat_ws(' ', el.nom, el.prenom)) AS eleve, el.matricule,
               c.nom AS classe, p.libelle AS periode`,
    // La table `bulletins` ne porte pas de classe : elle stocke ecole_id,
    // eleve_id, periode_id et les valeurs calculées. La classe se lit donc sur
    // l'élève. Conséquence assumée : c'est sa classe ACTUELLE qui s'affiche,
    // pas nécessairement celle qu'il occupait à l'émission du bulletin. Pour
    // l'historique exact, c'est `eleve_classe_historique` qui fait foi, et
    // l'onglet « Parcours » du dossier élève l'expose.
    depuis: `FROM bulletins b
             LEFT JOIN eleves el ON el.id = b.eleve_id
             LEFT JOIN classes c ON c.id = el.classe_id
             LEFT JOIN periodes p ON p.id = b.periode_id`,
    cle: 'b.ecole_id',
    recherche: ['el.nom', 'el.matricule', 'c.nom'],
    tri: 'b.created_at DESC',
    filtres: { periode_id: 'b.periode_id = {}::uuid', classe_id: 'el.classe_id = {}::uuid' }
  },

  paiements: {
    libelle: 'Paiements scolaires',
    // `paiements_frais` (frais encaissés par l'école auprès des familles) et
    // `paiements` (abonnement que l'école règle à Ardoise) sont deux tables
    // distinctes qu'il ne faut pas confondre. Ici, c'est bien la première :
    // on explore la vie de l'établissement, pas sa facturation.
    // La colonne s'appelle `methode`, et non `mode_paiement`.
    colonnes: `pf.id, pf.montant, pf.devise, pf.date_paiement,
               pf.methode AS mode_paiement, pf.reference, pf.libelle,
               trim(concat_ws(' ', el.nom, el.prenom)) AS eleve, el.matricule,
               c.nom AS classe`,
    depuis: `FROM paiements_frais pf
             LEFT JOIN eleves el ON el.id = pf.eleve_id
             LEFT JOIN classes c ON c.id = el.classe_id`,
    cle: 'pf.ecole_id',
    recherche: ['el.nom', 'el.matricule', 'pf.reference'],
    tri: 'pf.date_paiement DESC'
  },

  messages: {
    libelle: 'Messages',
    colonnes: `m.id, m.sujet, m.contenu, m.canal, m.statut, m.created_at`,
    depuis: `FROM notifications m`,
    cle: 'm.ecole_id',
    recherche: ['m.sujet', 'm.contenu'],
    tri: 'm.created_at DESC'
  },

  archives: {
    libelle: 'Archives (parcours des élèves)',
    colonnes: `h.id, an.libelle AS annee, c.nom AS classe,
               trim(concat_ws(' ', el.nom, el.prenom)) AS eleve, el.matricule`,
    depuis: `FROM eleve_classe_historique h
             LEFT JOIN eleves el ON el.id = h.eleve_id
             LEFT JOIN classes c ON c.id = h.classe_id
             LEFT JOIN annees_scolaires an ON an.id = h.annee_scolaire_id`,
    cle: 'h.ecole_id',
    recherche: ['el.nom', 'el.matricule', 'c.nom'],
    tri: 'an.libelle DESC'
  }
};

/** GET /super-admin/explorer/ressources — catalogue exposé à l'interface. */
function catalogueRessources(req, res) {
  return res.json({
    ressources: Object.entries(RESSOURCES).map(([cle, def]) => ({
      cle,
      libelle: def.libelle,
      filtres: Object.keys(def.filtres || {}),
      recherche: Boolean(def.recherche?.length)
    }))
  });
}

/**
 * GET /super-admin/explorer/:ecoleId/apercu
 * Vue d'entrée dans une école : ce qu'un Directeur voit en arrivant.
 */
async function apercuEcole(req, res) {
  const { ecoleId } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const ecole = await lignes(client, `SELECT * FROM ecoles WHERE id = $1`, [ecoleId]);
      if (!ecole.length) throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });

      const [annees, compteurs, classes, periodes, activite] = await Promise.all([
        lignes(client, `SELECT id, libelle, active, cloturee FROM annees_scolaires
                        WHERE ecole_id = $1 ORDER BY libelle DESC`, [ecoleId]),
        lignes(client, `
          SELECT
            (SELECT count(*) FROM eleves WHERE ecole_id = $1 AND statut = 'actif') AS eleves,
            (SELECT count(*) FROM classes WHERE ecole_id = $1) AS classes,
            (SELECT count(*) FROM cours WHERE ecole_id = $1) AS cours,
            (SELECT count(*) FROM utilisateurs WHERE ecole_id = $1) AS utilisateurs,
            (SELECT count(*) FROM bulletins WHERE ecole_id = $1) AS bulletins,
            (SELECT count(*) FROM notes WHERE ecole_id = $1) AS notes,
            (SELECT count(*) FROM presences WHERE ecole_id = $1) AS presences,
            (SELECT count(*) FROM documents WHERE ecole_id = $1) AS documents`, [ecoleId]),
        lignes(client, `
          SELECT c.id, c.nom,
                 (SELECT count(*) FROM eleves x WHERE x.classe_id = c.id AND x.statut = 'actif') AS effectif
          FROM classes c WHERE c.ecole_id = $1 ORDER BY c.nom LIMIT 60`, [ecoleId]),
        lignes(client, `SELECT id, libelle, numero, date_debut, date_fin FROM periodes
                        WHERE ecole_id = $1 ORDER BY date_debut DESC LIMIT 20`, [ecoleId]),
        lignes(client, `
          SELECT j.action, j.created_at,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur
          FROM journal_activite j LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
          WHERE j.ecole_id = $1 ORDER BY j.created_at DESC LIMIT 25`, [ecoleId])
      ]);

      return {
        ecole: ecole[0],
        annees_scolaires: annees,
        compteurs: compteurs[0] || {},
        classes: classes.map((c) => ({ ...c, effectif: Number(c.effectif) })),
        periodes,
        activite_recente: activite,
        lecture_seule: true
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur aperçu école:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /super-admin/explorer/:ecoleId/:ressource
 * Lecture paginée d'une ressource du catalogue.
 */
async function listerRessource(req, res) {
  const { ecoleId, ressource } = req.params;
  const definition = RESSOURCES[ressource];

  if (!definition) {
    return res.status(404).json({
      message: `Ressource inconnue. Ressources disponibles : ${Object.keys(RESSOURCES).join(', ')}.`
    });
  }

  const { page, taille, decalage } = pagination(req, 30, 200);
  const conditions = [`${definition.cle} = $1::uuid`];
  const params = [ecoleId];

  if (definition.conditionSupplementaire) conditions.push(definition.conditionSupplementaire);

  if (req.query.recherche && definition.recherche?.length) {
    params.push(motifRecherche(req.query.recherche));
    const p = `$${params.length}`;
    conditions.push(`(${definition.recherche.map((c) => `COALESCE(${c}::text,'') ILIKE ${p}`).join(' OR ')})`);
  }

  for (const [nom, gabarit] of Object.entries(definition.filtres || {})) {
    const valeur = req.query[nom];
    if (valeur === undefined || valeur === '') continue;
    params.push(valeur);
    conditions.push(gabarit.replace('{}', `$${params.length}`));
  }

  const filtre = `WHERE ${conditions.join(' AND ')}`;

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client,
        `SELECT count(*) ${definition.depuis} ${filtre}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT ${definition.colonnes}
        ${definition.depuis} ${filtre}
        ORDER BY ${definition.tri}
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      return { total, donnees };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      ressource,
      libelle: definition.libelle,
      lecture_seule: true
    }));
  } catch (err) {
    console.error(`Erreur exploration ${ressource}:`, err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /super-admin/explorer/eleve/:eleveId
 * Dossier complet d'un élève, verrouillé.
 *
 * Renvoyé en un seul appel plutôt qu'en neuf : la fiche est consultée depuis
 * une recherche, l'utilisateur attend une page, pas neuf requêtes qui
 * s'affichent l'une après l'autre.
 */
async function dossierEleve(req, res) {
  const { eleveId } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const identite = await lignes(client, `
        SELECT el.*, c.nom AS classe_nom, c.id AS classe_id,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code,
               an.libelle AS annee_courante
        FROM eleves el
        LEFT JOIN classes c ON c.id = el.classe_id
        LEFT JOIN ecoles e ON e.id = el.ecole_id
        LEFT JOIN annees_scolaires an ON an.id = c.annee_scolaire_id
        WHERE el.id = $1`, [eleveId]);

      if (!identite.length) throw Object.assign(new Error('Élève introuvable.'), { statusCode: 404 });

      const [parcours, notes, bulletins, absences, sanctions, paiements, historique] =
        await Promise.all([
          lignes(client, `
            SELECT an.libelle AS annee, c.nom AS classe, h.resultat_final, h.resultat
            FROM eleve_classe_historique h
            LEFT JOIN classes c ON c.id = h.classe_id
            LEFT JOIN annees_scolaires an ON an.id = h.annee_scolaire_id
            WHERE h.eleve_id = $1 ORDER BY an.libelle DESC`, [eleveId]),

          lignes(client, `
            SELECT n.points_obtenus, co.nom AS cours, p.libelle AS periode, n.valide,
                   COALESCE(cc.maximum_points_override, co.maximum_points) AS maximum,
                   n.updated_at AS created_at
            FROM notes n
            LEFT JOIN classe_cours cc ON cc.id = n.classe_cours_id
            LEFT JOIN cours co ON co.id = cc.cours_id
            LEFT JOIN periodes p ON p.id = n.periode_id
            WHERE n.eleve_id = $1 ORDER BY n.updated_at DESC LIMIT 300`, [eleveId]),

          lignes(client, `
            SELECT b.id, b.total, b.pourcentage, b.classement, b.mention, b.conduite,
                   b.application, b.observation, b.pdf_url, b.signe_at,
                   p.libelle AS periode, c.nom AS classe, b.created_at
            FROM bulletins b
            LEFT JOIN periodes p ON p.id = b.periode_id
            LEFT JOIN eleves el ON el.id = b.eleve_id
            LEFT JOIN classes c ON c.id = el.classe_id
            WHERE b.eleve_id = $1 ORDER BY b.created_at DESC`, [eleveId]),

          lignes(client, `
            SELECT pr.date_jour AS date, pr.statut::text AS statut, pr.motif
            FROM presences pr WHERE pr.eleve_id = $1
            ORDER BY pr.date_jour DESC LIMIT 200`, [eleveId]),

          // `incidents_discipline` ne porte ni « gravite » ni « points_retires ».
          // Le schéma réel décrit un fait par son `type`, son `sens` (positif ou
          // négatif — la table sert aussi à noter les mérites, pas seulement les
          // sanctions), les `points` engagés, la `mesure` prise et sa date.
          lignes(client, `
            SELECT i.id, i.description, i.type, i.sens, i.points, i.mesure,
                   i.date_incident, i.created_at
            FROM incidents_discipline i WHERE i.eleve_id = $1
            ORDER BY i.date_incident DESC NULLS LAST, i.created_at DESC LIMIT 100`, [eleveId]),

          lignes(client, `
            SELECT pf.montant, pf.devise, pf.date_paiement, pf.libelle,
                   pf.methode AS mode_paiement, pf.reference
            FROM paiements_frais pf WHERE pf.eleve_id = $1
            ORDER BY pf.date_paiement DESC LIMIT 100`, [eleveId]),

          lignes(client, `
            SELECT j.action, j.created_at, trim(concat_ws(' ', u.prenom, u.nom)) AS par
            FROM journal_activite j LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
            WHERE j.cible_id = $1 ORDER BY j.created_at DESC LIMIT 50`, [eleveId])
        ]);

      const totalAbsences = absences.filter((a) => a.statut === 'absent').length;

      return {
        identite: identite[0],
        parcours,
        notes,
        bulletins,
        moyennes: {
          nombre_bulletins: bulletins.length,
          moyenne_generale: bulletins.length
            ? Math.round(
                (bulletins.reduce((s, b) => s + (Number(b.pourcentage) || 0), 0) /
                  bulletins.filter((b) => b.pourcentage !== null).length) * 100
              ) / 100
            : null
        },
        absences,
        resume_absences: {
          total_releves: absences.length,
          absences: totalAbsences,
          retards: absences.filter((a) => a.statut === 'retard').length
        },
        sanctions,
        paiements,
        historique,
        lecture_seule: true
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur dossier élève:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   Mode « Voir comme »
   ========================================================================== */

const ROLES_OBSERVABLES = [
  'directeur', 'prefet', 'professeur', 'titulaire',
  'parent', 'comptable', 'secretaire', 'charge_presences', 'directeur_discipline'
];
const DUREE_OBSERVATION_MINUTES = 30;

/**
 * POST /super-admin/observation
 * body: { ecole_id, role, motif? }
 *
 * Délivre un jeton d'observation : un JWT ordinaire du point de vue de
 * l'application, portant l'école visée et le rôle voulu — mais marqué
 * `observation: true` et `is_superadmin: false`.
 *
 * Les deux drapeaux comptent autant l'un que l'autre :
 *   · `is_superadmin: false` fait retomber les policies RLS sur l'école visée.
 *     L'observateur voit exactement ce que voit un directeur de cette école,
 *     ni plus (les autres écoles lui sont invisibles), ni moins.
 *   · `observation: true` est lu par `verrouObservation` et interdit toute
 *     écriture, quelle que soit la route atteinte.
 *
 * Le jeton est court (30 min) et ne se rafraîchit pas : aucune session n'est
 * créée en base, donc `/auth/refresh` n'a rien à quoi le rattacher. Une
 * observation oubliée s'éteint d'elle-même.
 */
async function demarrerObservation(req, res) {
  const { ecole_id, role, motif } = req.body || {};

  if (!ecole_id || !role) {
    return res.status(400).json({ message: 'ecole_id et role sont requis.' });
  }
  if (!ROLES_OBSERVABLES.includes(role)) {
    return res.status(400).json({
      message: `Rôle non observable. Rôles autorisés : ${ROLES_OBSERVABLES.join(', ')}.`
    });
  }

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const ecole = await lignes(client, `SELECT id, nom, code FROM ecoles WHERE id = $1`, [ecole_id]);
      if (!ecole.length) throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });

      const expire = new Date(Date.now() + DUREE_OBSERVATION_MINUTES * 60 * 1000);

      const trace = await lignes(client, `
        INSERT INTO observations_super_admin
          (super_admin_id, ecole_id, role_observe, motif, ip, user_agent, expire_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, demarree_at, expire_at`,
        [req.auth.userId, ecole_id, role, motif || null,
         req.ip || null, req.headers['user-agent'] || null, expire]);

      // Le journal d'audit ordinaire doit aussi porter la trace : c'est là que
      // le directeur de l'école la trouvera, et il a le droit de savoir.
      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES ($1, $2, 'super_admin.observation_demarree', 'ecole', $1, $3::jsonb)`,
        [ecole_id, req.auth.userId, JSON.stringify({ role, motif: motif || null, source: 'super_admin' })]
      );

      const jeton = generateObservationToken({
        observateurId: req.auth.userId,
        ecoleId: ecole_id,
        role,
        dureeMinutes: DUREE_OBSERVATION_MINUTES
      });

      return {
        jeton_observation: jeton,
        observation_id: trace[0]?.id || null,
        ecole: ecole[0],
        role,
        expire_at: expire.toISOString(),
        duree_minutes: DUREE_OBSERVATION_MINUTES,
        lecture_seule: true,
        avertissement: "Toute action de modification est refusée par le serveur pendant l'observation."
      };
    });

    return res.status(201).json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur démarrage observation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/observation/:id/fin — clôt la trace (le jeton expire seul). */
async function terminerObservation(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(SUPER, (client) =>
      client.query(
        `UPDATE observations_super_admin SET terminee_at = now()
         WHERE id = $1 AND super_admin_id = $2 AND terminee_at IS NULL`,
        [id, req.auth.userId]
      )
    );
    return res.json({ message: 'Observation terminée.' });
  } catch (err) {
    console.error('Erreur fin observation:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/observation — historique des observations. */
async function historiqueObservations(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client, `SELECT count(*) FROM observations_super_admin`, [], 0);
      const donnees = await lignes(client, `
        SELECT o.id, o.role_observe, o.motif, o.ip, o.user_agent,
               o.demarree_at, o.expire_at, o.terminee_at,
               e.nom AS ecole_nom, e.code AS ecole_code,
               trim(concat_ws(' ', u.prenom, u.nom)) AS super_admin
        FROM observations_super_admin o
        LEFT JOIN ecoles e ON e.id = o.ecole_id
        LEFT JOIN utilisateurs u ON u.id = o.super_admin_id
        ORDER BY o.demarree_at DESC LIMIT $1 OFFSET $2`, [taille, decalage]);
      return { total, donnees };
    });
    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees));
  } catch (err) {
    console.error('Erreur historique observations:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  catalogueRessources,
  apercuEcole,
  listerRessource,
  dossierEleve,
  demarrerObservation,
  terminerObservation,
  historiqueObservations,
  ROLES_OBSERVABLES
};
