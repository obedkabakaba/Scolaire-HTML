/**
 * Espace Super Administrateur — Centre Finance.
 * ---------------------------------------------------------------------------
 * Couvre les sections 1, 12 à 16, 18 à 21, 23 à 25 de la mission : tableau de
 * bord financier, rentabilité, seuil de rentabilité, prévisions, coût par
 * école, alertes, journal financier, permissions et exports.
 *
 * RÈGLE ABSOLUE DE CE FICHIER : AUCUNE DONNÉE INVENTÉE
 * ----------------------------------------------------
 * Chaque indicateur porte sa `source`. Quand la donnée n'existe pas encore
 * dans Ardoise, l'indicateur vaut `null` et une entrée apparaît dans
 * `donnees_manquantes` avec la marche à suivre. Un tableau de bord financier
 * garni de valeurs plausibles mais fausses est plus dangereux qu'un tableau
 * de bord vide : on prend des décisions dessus.
 *
 * DEUX FAÇONS DE MESURER LE REVENU, ET ELLES NE DISENT PAS LA MÊME CHOSE
 * ---------------------------------------------------------------------
 *   · Le CHIFFRE D'AFFAIRES est ce qui a été ENCAISSÉ (table `paiements`).
 *     C'est un fait comptable, daté, vérifiable.
 *   · Le MRR est ce que les abonnements actifs RAPPORTERONT par mois s'ils
 *     se poursuivent. C'est une projection contractuelle, pas un encaissement.
 * En RDC, où beaucoup d'écoles paient en espèces et par à-coups, l'écart
 * entre les deux est structurel — d'où l'affichage systématique des deux.
 */

const XLSX = require('xlsx');
const { runWithTenant } = require('../config/db');
const cache = require('../utils/cache.utils');
const { mesurer, lignes, pagination, reponsePaginee } = require('../utils/super-admin.utils');
const F = require('../utils/finance.utils');
const { deviseReference } = require('./super-admin-offres.controller');
const { oublier: oublierAcces } = require('../middleware/finance.middleware');

const SUPER = { isSuperAdmin: true };

/* ==========================================================================
   Briques de calcul partagées
   ========================================================================== */

/** Réglage numérique de `configuration_plateforme`, avec repli. */
async function reglage(client, cle, defaut) {
  try {
    const r = await client.query('SELECT valeur FROM configuration_plateforme WHERE cle = $1', [cle]);
    if (!r.rows.length) return defaut;
    const n = Number(String(r.rows[0].valeur).replace(/"/g, ''));
    return Number.isFinite(n) ? n : defaut;
  } catch { return defaut; }
}

/**
 * MRR courant, calculé au prix RÉELLEMENT appliqué.
 *
 * Ordre de priorité du prix : tarif négocié actif > prix figé sur
 * l'abonnement > prix catalogue de l'offre. C'est l'ordre dans lequel l'argent
 * arrive réellement, et non l'ordre théorique de la grille tarifaire.
 */
async function calculerMrr(client, conv) {
  const rows = await lignes(client, `
    SELECT a.ecole_id,
           a.plan_id,
           COALESCE(t.prix_personnalise, a.prix_applique, p.prix) AS prix,
           COALESCE(t.devise, a.devise_appliquee, p.devise)       AS devise,
           COALESCE(t.periodicite, a.periodicite, 'mensuel')      AS periodicite,
           p.prix        AS prix_catalogue,
           p.duree_jours,
           a.en_periode_essai
      FROM abonnements a
      JOIN plans_abonnement p ON p.id = a.plan_id
      LEFT JOIN tarifs_personnalises t ON t.ecole_id = a.ecole_id AND t.statut = 'actif'
     WHERE a.statut = 'actif'`);

  let mrr = 0;
  let mrrCatalogue = 0;
  let ecolesPayantes = 0;
  let ecolesEnEssai = 0;

  for (const l of rows) {
    const mensuel = l.periodicite !== 'mensuel'
      ? F.mensualiserPeriodicite(l.prix, l.periodicite)
      : F.mensualiser(l.prix, l.duree_jours);
    const catalogue = F.mensualiser(l.prix_catalogue, l.duree_jours);

    // Une école en période d'essai ne paie rien : la compter dans le MRR
    // gonflerait le revenu récurrent d'un montant qui n'existe pas encore.
    if (l.en_periode_essai) { ecolesEnEssai++; continue; }

    mrr += conv.convertir(mensuel, l.devise);
    mrrCatalogue += conv.convertir(catalogue, l.devise);
    ecolesPayantes++;
  }

  return {
    mrr: F.arrondi(mrr),
    arr: F.arrondi(mrr * 12),
    mrr_catalogue: F.arrondi(mrrCatalogue),
    remises_mensuelles: F.arrondi(mrrCatalogue - mrr),
    ecoles_payantes: ecolesPayantes,
    ecoles_en_essai: ecolesEnEssai,
    arpu: ecolesPayantes ? F.arrondi(mrr / ecolesPayantes) : null
  };
}

/**
 * Coûts d'un mois donné ('YYYY-MM'), ventilés par nature.
 *
 * Trois sources, additionnées une seule fois chacune :
 *   1. abonnements fixes des services actifs (ramenés au mois) ;
 *   2. consommations variables saisies pour ce mois (coût réel s'il est
 *      connu, estimation sinon) ;
 *   3. dépenses ponctuelles datées de ce mois et NON rattachées à un service
 *      déjà compté — sans ce filtre, une facture Render saisie en dépense
 *      ET portée par la fiche du service serait comptée deux fois.
 */
async function calculerCouts(client, conv, mois) {
  const services = await lignes(client, `
    SELECT s.id, s.nom, s.categorie, s.devise, s.cout_mensuel, s.cout_annuel,
           s.frequence_facturation, s.cout_variable
      FROM services_externes s
     WHERE s.statut = 'actif'`);

  const consommations = await lignes(client, `
    SELECT c.service_id, c.cout_reel, c.cout_estime, c.devise, s.categorie, s.nom
      FROM services_consommations c
      JOIN services_externes s ON s.id = c.service_id
     WHERE c.periode = $1 AND s.statut = 'actif'`, [mois]);

  const depenses = await lignes(client, `
    SELECT d.categorie, d.montant, d.devise, d.service_id
      FROM depenses d
     WHERE NOT d.archive AND d.statut <> 'annulee'
       AND to_char(d.date_depense, 'YYYY-MM') = $1`, [mois]);

  const parCategorie = {};
  const ajouter = (categorie, montant) => {
    const c = categorie || 'autres';
    parCategorie[c] = (parCategorie[c] || 0) + montant;
  };

  let coutsFixes = 0;
  for (const s of services) {
    const montant = conv.convertir(F.coutMensuelService(s), s.devise);
    coutsFixes += montant;
    ajouter(s.categorie, montant);
  }

  let coutsVariables = 0;
  for (const c of consommations) {
    const brut = c.cout_reel !== null && c.cout_reel !== undefined ? c.cout_reel : c.cout_estime;
    if (brut === null || brut === undefined) continue;
    const montant = conv.convertir(brut, c.devise);
    coutsVariables += montant;
    ajouter(c.categorie, montant);
  }

  let coutsPonctuels = 0;
  for (const d of depenses) {
    if (d.service_id) continue;              // déjà porté par la fiche du service
    const montant = conv.convertir(d.montant, d.devise);
    coutsPonctuels += montant;
    ajouter(d.categorie, montant);
  }

  const total = coutsFixes + coutsVariables + coutsPonctuels;

  return {
    total: F.arrondi(total),
    fixes: F.arrondi(coutsFixes),
    variables: F.arrondi(coutsVariables),
    ponctuels: F.arrondi(coutsPonctuels),
    par_categorie: Object.entries(parCategorie)
      .map(([categorie, montant]) => ({ categorie, montant: F.arrondi(montant) }))
      .sort((a, b) => b.montant - a.montant),
    // Ventilations nommées, utilisées par le tableau de bord global.
    infrastructure: F.arrondi((parCategorie.infrastructure || 0) + (parCategorie.hebergement || 0)),
    api: F.arrondi(parCategorie.api || 0),
    logiciels: F.arrondi(parCategorie.logiciels || 0),
    marketing: F.arrondi(parCategorie.marketing || 0),
    nb_services_actifs: services.length,
    nb_consommations_saisies: consommations.length
  };
}

/** Revenu encaissé d'un mois ('YYYY-MM'), toutes devises consolidées. */
async function revenuEncaisse(client, conv, mois) {
  const rows = await lignes(client, `
    SELECT COALESCE(sum(montant),0) AS total, devise
      FROM paiements
     WHERE statut = 'confirme' AND to_char(date_paiement, 'YYYY-MM') = $1
     GROUP BY devise`, [mois]);
  return F.arrondi(rows.reduce((s, r) => s + conv.convertir(r.total, r.devise), 0));
}

/* ==========================================================================
   1. TABLEAU DE BORD FINANCIER
   ========================================================================== */

/**
 * GET /super-admin/finance/tableau-de-bord
 *
 * Mis en cache 60 secondes : une quinzaine de requêtes d'agrégation, et un
 * exploitant qui rafraîchit trois fois de suite n'a besoin que d'une seule
 * exécution. Le bouton « Actualiser » de l'interface force le recalcul.
 */
async function tableauDeBordFinancier(req, res) {
  const forcer = String(req.query.forcer || '') === 'oui';
  if (forcer) { try { cache.invalider('sa:finance'); } catch { /* rien */ } }

  try {
    const donnees = await cache.memoiser('sa:finance:tdb', 60, () =>
      runWithTenant(SUPER, async (client) => {
        const reference = await deviseReference(client);
        const conv = await F.convertisseur(client, reference);
        const mois = F.moisCourant();
        const anneeCourante = mois.slice(0, 4);
        const donneesManquantes = [];

        const [
          mrrBloc, coutsMois, caMois,
          caAnnee, caTotal,
          abosActifs, abosExpires, abosAttente, abosEssai,
          paiementsReussis, paiementsEchoues, paiementsAttente,
          remisesActives, montantRemises,
          nbEcoles, nbEleves
        ] = await Promise.all([
          calculerMrr(client, conv),
          calculerCouts(client, conv, mois),
          revenuEncaisse(client, conv, mois),

          lignes(client, `SELECT COALESCE(sum(montant),0) AS total, devise FROM paiements
                           WHERE statut = 'confirme' AND to_char(date_paiement,'YYYY') = $1
                           GROUP BY devise`, [anneeCourante]),
          lignes(client, `SELECT COALESCE(sum(montant),0) AS total, devise FROM paiements
                           WHERE statut = 'confirme' GROUP BY devise`),

          mesurer(client, `SELECT count(*) FROM abonnements WHERE statut = 'actif'`, [], 0),
          mesurer(client, `SELECT count(*) FROM abonnements WHERE statut IN ('expire','suspendu')`, [], 0),
          mesurer(client, `SELECT count(*) FROM abonnements a
                            WHERE a.statut = 'actif' AND a.date_expiration < now()`, [], 0),
          mesurer(client, `SELECT count(*) FROM abonnements WHERE en_periode_essai = true AND statut <> 'expire'`, [], 0),

          mesurer(client, `SELECT count(*) FROM paiements WHERE statut = 'confirme'
                            AND to_char(date_paiement,'YYYY-MM') = $1`, [mois], 0),
          mesurer(client, `SELECT count(*) FROM paiements WHERE statut = 'echoue'
                            AND to_char(date_paiement,'YYYY-MM') = $1`, [mois], null),
          mesurer(client, `SELECT count(*) FROM paiements WHERE statut = 'en_attente'`, [], null),

          mesurer(client, `SELECT count(*) FROM tarifs_personnalises WHERE statut = 'actif'`, [], 0),
          lignes(client, `SELECT COALESCE(sum(prix_catalogue - prix_personnalise),0) AS total, devise
                            FROM tarifs_personnalises WHERE statut = 'actif' GROUP BY devise`),

          mesurer(client, `SELECT count(*) FROM ecoles`, [], 0),
          mesurer(client, `SELECT count(*) FROM eleves WHERE statut = 'actif'`, [], 0)
        ]);

        const caAnnuel = F.arrondi(caAnnee.reduce((s, r) => s + conv.convertir(r.total, r.devise), 0));
        const caCumule = F.arrondi(caTotal.reduce((s, r) => s + conv.convertir(r.total, r.devise), 0));
        const remises = F.arrondi(montantRemises.reduce((s, r) => s + conv.convertir(r.total, r.devise), 0));

        // Coûts annuels : somme des coûts réellement constatés depuis janvier,
        // et non le coût du mois × 12 — l'un est une mesure, l'autre une
        // projection, et les confondre fausse la marge annuelle.
        const moisEcoules = F.derniersMois(12).filter((m) => m.startsWith(anneeCourante));
        const coutsParMois = [];
        for (const m of F.derniersMois(12)) {
          coutsParMois.push({ mois: m, ...(await calculerCouts(client, conv, m)) });
        }
        const coutsAnnee = F.arrondi(coutsParMois
          .filter((c) => moisEcoules.includes(c.mois))
          .reduce((s, c) => s + c.total, 0));

        const beneficeMois = F.arrondi(caMois - coutsMois.total);
        const margeMois = caMois > 0 ? F.arrondi((beneficeMois / caMois) * 100, 1) : null;
        const beneficeAnnee = F.arrondi(caAnnuel - coutsAnnee);

        // ---- Courbes sur 12 mois ------------------------------------------
        const revenusParMois = await lignes(client, `
          WITH mois AS (
            SELECT to_char(generate_series(
              date_trunc('month', now()) - interval '11 months',
              date_trunc('month', now()), interval '1 month'), 'YYYY-MM') AS m
          )
          SELECT mois.m AS mois, p.devise, COALESCE(sum(p.montant),0) AS total
            FROM mois
            LEFT JOIN paiements p
              ON to_char(p.date_paiement,'YYYY-MM') = mois.m AND p.statut = 'confirme'
           GROUP BY mois.m, p.devise ORDER BY mois.m`);

        const revenus = {};
        for (const r of revenusParMois) {
          revenus[r.mois] = (revenus[r.mois] || 0) + conv.convertir(r.total, r.devise);
        }

        const ecolesPayantesParMois = await lignes(client, `
          WITH mois AS (
            SELECT generate_series(
              date_trunc('month', now()) - interval '11 months',
              date_trunc('month', now()), interval '1 month') AS d
          )
          SELECT to_char(mois.d,'YYYY-MM') AS mois,
                 (SELECT count(DISTINCT a.ecole_id) FROM abonnements a
                   WHERE a.date_debut <= (mois.d + interval '1 month' - interval '1 day')
                     AND (a.date_expiration IS NULL OR a.date_expiration >= mois.d)
                     AND a.en_periode_essai = false) AS valeur
            FROM mois ORDER BY mois.d`);

        const courbes = {
          revenus: F.derniersMois(12).map((m) => ({ mois: m, valeur: F.arrondi(revenus[m] || 0) })),
          depenses: coutsParMois.map((c) => ({ mois: c.mois, valeur: c.total })),
          benefice: coutsParMois.map((c) => ({
            mois: c.mois, valeur: F.arrondi((revenus[c.mois] || 0) - c.total)
          })),
          ecoles_payantes: ecolesPayantesParMois.map((l) => ({ mois: l.mois, valeur: Number(l.valeur) || 0 })),
          // MRR historique : RECONSTITUÉ à partir des abonnements et des prix
          // ACTUELS. Ardoise ne prend pas d'instantané mensuel du MRR, donc un
          // changement de prix passé se répercute rétroactivement sur toute la
          // courbe. Signalé comme tel plutôt que présenté comme une mesure.
          mrr_reconstitue: ecolesPayantesParMois.map((l) => ({
            mois: l.mois,
            valeur: mrrBloc.ecoles_payantes
              ? F.arrondi((Number(l.valeur) || 0) * (mrrBloc.mrr / mrrBloc.ecoles_payantes))
              : 0
          }))
        };

        if (paiementsEchoues === null) {
          donneesManquantes.push({
            indicateur: 'Paiements échoués',
            raison: "Le statut « echoue » n'est pas présent dans la table paiements sur cette base.",
            action: 'Aucun paiement en échec enregistré à ce jour, ou statut nommé différemment.'
          });
        }
        if (!coutsMois.nb_services_actifs) {
          donneesManquantes.push({
            indicateur: 'Coûts d\'infrastructure',
            raison: 'Aucun service externe enregistré.',
            action: 'Renseignez vos services dans « Services & Infrastructure » (Supabase, Render, OpenAI…).'
          });
        }
        if (conv.approximatif) {
          donneesManquantes.push({
            indicateur: 'Consolidation multidevise',
            raison: `Aucun taux de change saisi pour : ${[...conv.devisesInconnues].join(', ')}.`,
            action: 'Saisissez un taux dans « Taux de change ». En attendant, ces montants sont additionnés tels quels.'
          });
        }

        return {
          genere_a: new Date().toISOString(),
          devise_reference: conv.reference,
          conversion_approximative: conv.approximatif,
          devises_sans_taux: [...conv.devisesInconnues],
          mois,

          revenus: {
            chiffre_affaires_mensuel: caMois,
            chiffre_affaires_annuel: caAnnuel,
            chiffre_affaires_cumule: caCumule,
            mrr: mrrBloc.mrr,
            arr: mrrBloc.arr,
            mrr_catalogue: mrrBloc.mrr_catalogue,
            revenus_nets: beneficeMois,
            source: 'paiements confirmés (CA) et abonnements actifs (MRR/ARR)'
          },

          abonnements: {
            actifs: abosActifs,
            expires: abosExpires,
            en_attente_paiement: abosAttente,
            en_essai: abosEssai,
            ecoles_payantes: mrrBloc.ecoles_payantes
          },

          paiements: {
            reussis_ce_mois: paiementsReussis,
            echoues_ce_mois: paiementsEchoues,
            en_attente: paiementsAttente,
            remboursements: null   // voir donnees_manquantes
          },

          remises: {
            tarifs_negocies_actifs: remisesActives,
            manque_a_gagner_mensuel: remises,
            taux_remise_global: mrrBloc.mrr_catalogue > 0
              ? F.arrondi((mrrBloc.remises_mensuelles / mrrBloc.mrr_catalogue) * 100, 1) : 0
          },

          couts: {
            mensuel: coutsMois.total,
            annuel_constate: coutsAnnee,
            annuel_projete: F.arrondi(coutsMois.total * 12),
            fixes: coutsMois.fixes,
            variables: coutsMois.variables,
            ponctuels: coutsMois.ponctuels,
            infrastructure: coutsMois.infrastructure,
            api: coutsMois.api,
            par_categorie: coutsMois.par_categorie
          },

          resultat: {
            benefice_mensuel: beneficeMois,
            benefice_annuel: beneficeAnnee,
            marge_mensuelle: margeMois,
            marge_annuelle: caAnnuel > 0 ? F.arrondi((beneficeAnnee / caAnnuel) * 100, 1) : null,
            arpu: mrrBloc.arpu,
            revenu_moyen_par_eleve: nbEleves ? F.arrondi(mrrBloc.mrr / nbEleves) : null,
            cout_moyen_par_ecole: mrrBloc.ecoles_payantes
              ? F.arrondi(coutsMois.total / mrrBloc.ecoles_payantes) : null,
            cout_moyen_par_eleve: nbEleves ? F.arrondi(coutsMois.total / nbEleves) : null
          },

          volumes: { ecoles: nbEcoles, eleves: nbEleves },
          courbes,
          donnees_manquantes: donneesManquantes,
          avertissement_mrr_historique:
            'La courbe MRR est reconstituée à partir des prix actuels : elle ne conserve pas la mémoire des prix passés.'
        };
      })
    );

    return res.json({ ...donnees, peut_ecrire: !!(req.finance && req.finance.peutEcrire) });
  } catch (err) {
    console.error('Erreur tableau de bord financier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   2. RENTABILITÉ
   ========================================================================== */

/**
 * GET /super-admin/finance/rentabilite
 *
 * Rentabilité par offre ET par école. La première répond à « quelle offre
 * fait vivre Ardoise », la seconde à « quel client me coûte plus qu'il ne me
 * rapporte » — deux questions distinctes qu'un seul chiffre global masque.
 *
 * RÉPARTITION DES COÛTS : la clé retenue est le nombre d'élèves, pas le
 * nombre d'écoles. Une école de 1 200 élèves consomme davantage de base de
 * données, de stockage et d'e-mails qu'une école de 80. Répartir à parts
 * égales ferait apparaître les petites écoles comme non rentables et les
 * grandes comme très rentables — l'inverse de la réalité.
 * Les appels IA, eux, sont attribués nominativement : `ia_utilisations`
 * porte l'école.
 */
async function rentabilite(req, res) {
  const mois = F.periodeValide(req.query.mois) ? req.query.mois : F.moisCourant();

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const couts = await calculerCouts(client, conv, mois);

      const ecoles = await lignes(client, `
        SELECT e.id, e.nom, e.code, e.statut,
               (SELECT count(*) FROM eleves x WHERE x.ecole_id = e.id AND x.statut = 'actif') AS nb_eleves,
               p.nom AS plan_nom, p.id AS plan_id,
               COALESCE(t.prix_personnalise, a.prix_applique, p.prix) AS prix,
               COALESCE(t.devise, a.devise_appliquee, p.devise)       AS devise,
               p.duree_jours,
               a.statut AS statut_abonnement, a.en_periode_essai,
               COALESCE((SELECT sum(i.nb_appels) FROM ia_utilisations i
                          WHERE i.ecole_id = e.id AND i.mois = $1), 0) AS appels_ia
          FROM ecoles e
          LEFT JOIN abonnements a ON a.ecole_id = e.id AND a.statut = 'actif'
          LEFT JOIN plans_abonnement p ON p.id = a.plan_id
          LEFT JOIN tarifs_personnalises t ON t.ecole_id = e.id AND t.statut = 'actif'
         ORDER BY e.nom`, [mois]);

      const totalEleves = ecoles.reduce((s, e) => s + Number(e.nb_eleves || 0), 0);
      const totalAppelsIa = ecoles.reduce((s, e) => s + Number(e.appels_ia || 0), 0);

      // Les coûts API sont attribués à l'usage constaté ; le reste est réparti
      // au prorata des élèves.
      const coutApi = couts.api;
      const coutRepartissable = couts.total - coutApi;

      const detail = ecoles.map((e) => {
        const nbEleves = Number(e.nb_eleves || 0);
        const revenu = e.prix && !e.en_periode_essai
          ? conv.convertir(F.mensualiser(e.prix, e.duree_jours), e.devise) : 0;

        const partEleves = totalEleves > 0 ? nbEleves / totalEleves : 0;
        const coutInfra = coutRepartissable * partEleves;
        const coutIa = totalAppelsIa > 0 ? coutApi * (Number(e.appels_ia || 0) / totalAppelsIa) : 0;
        const coutTotal = coutInfra + coutIa;

        return {
          ecole_id: e.id, ecole_nom: e.nom, ecole_code: e.code, statut: e.statut,
          plan_nom: e.plan_nom, plan_id: e.plan_id,
          nb_eleves: nbEleves,
          en_periode_essai: e.en_periode_essai,
          revenu_mensuel: F.arrondi(revenu),
          cout_infrastructure: F.arrondi(coutInfra),
          cout_api: F.arrondi(coutIa),
          cout_total: F.arrondi(coutTotal),
          marge: F.arrondi(revenu - coutTotal),
          marge_pourcentage: revenu > 0 ? F.arrondi(((revenu - coutTotal) / revenu) * 100, 1) : null,
          appels_ia: Number(e.appels_ia || 0),
          revenu_par_eleve: nbEleves ? F.arrondi(revenu / nbEleves) : null,
          cout_par_eleve: nbEleves ? F.arrondi(coutTotal / nbEleves) : null
        };
      });

      // Rentabilité par offre : somme des écoles rattachées.
      const parOffre = {};
      for (const d of detail) {
        if (!d.plan_id) continue;
        const cle = String(d.plan_id);
        parOffre[cle] = parOffre[cle] || {
          plan_id: d.plan_id, plan_nom: d.plan_nom,
          nb_ecoles: 0, nb_eleves: 0, revenu: 0, cout: 0
        };
        parOffre[cle].nb_ecoles++;
        parOffre[cle].nb_eleves += d.nb_eleves;
        parOffre[cle].revenu += d.revenu_mensuel;
        parOffre[cle].cout += d.cout_total;
      }

      const offres = Object.values(parOffre).map((o) => ({
        ...o,
        revenu: F.arrondi(o.revenu),
        cout: F.arrondi(o.cout),
        marge: F.arrondi(o.revenu - o.cout),
        marge_pourcentage: o.revenu > 0 ? F.arrondi(((o.revenu - o.cout) / o.revenu) * 100, 1) : null,
        revenu_moyen_par_ecole: o.nb_ecoles ? F.arrondi(o.revenu / o.nb_ecoles) : null
      })).sort((a, b) => b.marge - a.marge);

      const revenuTotal = detail.reduce((s, d) => s + d.revenu_mensuel, 0);

      // Coût d'acquisition : dépenses marketing du mois ÷ écoles créées le
      // même mois. Sans dépense marketing saisie, l'indicateur n'existe pas —
      // on le dit au lieu d'afficher zéro, qui se lirait « acquisition
      // gratuite ».
      const marketing = couts.marketing;
      const nouvellesEcoles = await mesurer(client,
        `SELECT count(*) FROM ecoles WHERE to_char(created_at,'YYYY-MM') = $1`, [mois], 0);
      const cac = (marketing > 0 && Number(nouvellesEcoles) > 0)
        ? F.arrondi(marketing / Number(nouvellesEcoles)) : null;

      const churn = await calculerChurn(client, mois);
      const arpu = detail.filter((d) => d.revenu_mensuel > 0).length
        ? revenuTotal / detail.filter((d) => d.revenu_mensuel > 0).length : 0;
      const ltv = (churn.taux_mensuel && churn.taux_mensuel > 0)
        ? F.arrondi(arpu / (churn.taux_mensuel / 100)) : null;

      return {
        mois,
        devise_reference: conv.reference,
        synthese: {
          revenu_total: F.arrondi(revenuTotal),
          cout_total: couts.total,
          benefice_brut: F.arrondi(revenuTotal - couts.total),
          marge: revenuTotal > 0 ? F.arrondi(((revenuTotal - couts.total) / revenuTotal) * 100, 1) : null,
          revenu_moyen_par_ecole: F.arrondi(arpu),
          cout_moyen_par_ecole: detail.length ? F.arrondi(couts.total / detail.length) : null,
          revenu_moyen_par_eleve: totalEleves ? F.arrondi(revenuTotal / totalEleves) : null,
          cout_moyen_par_eleve: totalEleves ? F.arrondi(couts.total / totalEleves) : null,
          cout_acquisition_client: cac,
          lifetime_value: ltv,
          ratio_ltv_cac: (ltv && cac) ? F.arrondi(ltv / cac, 2) : null
        },
        churn,
        par_offre: offres,
        par_ecole: detail.sort((a, b) => a.marge - b.marge),
        couts_du_mois: couts,
        methode: {
          repartition: 'Les coûts non attribuables sont répartis au prorata du nombre d\'élèves actifs.',
          api: totalAppelsIa > 0
            ? 'Les coûts API sont attribués selon les appels IA réellement enregistrés par école.'
            : 'Aucun appel IA enregistré ce mois : les coûts API sont répartis comme les autres coûts.',
          limites: [
            cac === null ? 'Coût d\'acquisition indisponible : aucune dépense marketing saisie pour ce mois, ou aucune école créée.' : null,
            ltv === null ? 'Lifetime value indisponible : le churn ne peut pas encore être mesuré (historique trop court).' : null
          ].filter(Boolean)
        }
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur rentabilité:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Taux de résiliation mensuel, mesuré sur les faits.
 *
 * Numérateur : abonnements passés en 'expire'/'suspendu' ce mois-ci.
 * Dénominateur : abonnements actifs au début du mois.
 * Si le dénominateur est trop faible (moins de 5 écoles), le taux n'est pas
 * publié : sur 3 écoles, un départ affiche 33 % de churn, ce qui n'a aucune
 * valeur statistique et fausserait toutes les prévisions.
 */
async function calculerChurn(client, mois) {
  const debutMois = `${mois}-01`;

  const [actifsDebut, perdus] = await Promise.all([
    mesurer(client, `
      SELECT count(DISTINCT ecole_id) FROM abonnements
       WHERE date_debut < $1::date
         AND (date_expiration IS NULL OR date_expiration >= $1::date)`, [debutMois], 0),
    mesurer(client, `
      SELECT count(DISTINCT ecole_id) FROM abonnements
       WHERE statut IN ('expire','suspendu')
         AND to_char(COALESCE(updated_at, date_expiration), 'YYYY-MM') = $1`, [mois], 0)
  ]);

  const base = Number(actifsDebut || 0);
  const partis = Number(perdus || 0);

  if (base < 5) {
    return {
      mesurable: false,
      raison: `Base trop faible (${base} école(s) en début de mois) : un taux calculé ici serait trompeur.`,
      taux_mensuel: null, ecoles_perdues: partis, base
    };
  }

  const taux = (partis / base) * 100;
  return {
    mesurable: true,
    taux_mensuel: F.arrondi(taux, 2),
    taux_annualise: F.arrondi((1 - Math.pow(1 - taux / 100, 12)) * 100, 2),
    taux_retention: F.arrondi(100 - taux, 2),
    ecoles_perdues: partis,
    base
  };
}

/* ==========================================================================
   3. SEUIL DE RENTABILITÉ
   ========================================================================== */

/**
 * GET /super-admin/finance/seuil-rentabilite
 *
 * Paramètres facultatifs (`prix_moyen`, `cout_fixe`, `cout_variable_ecole`)
 * pour simuler. Sans eux, tout est mesuré sur les données réelles.
 *
 * La formule est celle du point mort classique :
 *     écoles nécessaires = coûts fixes / (prix moyen − coût variable/école)
 * Elle n'a de sens que si la marge unitaire est positive : dans le cas
 * contraire, aucun nombre d'écoles ne suffit, et le répondre en donnant un
 * chiffre astronomique serait une réponse fausse à une bonne question.
 */
async function seuilRentabilite(req, res) {
  const mois = F.periodeValide(req.query.mois) ? req.query.mois : F.moisCourant();

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const couts = await calculerCouts(client, conv, mois);
      const mrrBloc = await calculerMrr(client, conv);

      const coutFixe = F.nombrePositif(req.query.cout_fixe) ?? couts.fixes;
      const prixMoyen = F.nombrePositif(req.query.prix_moyen) ?? (mrrBloc.arpu || 0);

      // Coût variable par école : la part des coûts qui suit le nombre de
      // clients (consommations + ponctuels), divisée par les écoles payantes.
      const coutVariableTotal = couts.variables + couts.ponctuels;
      const coutVariableEcole = F.nombrePositif(req.query.cout_variable_ecole)
        ?? (mrrBloc.ecoles_payantes ? F.arrondi(coutVariableTotal / mrrBloc.ecoles_payantes) : 0);

      const margeUnitaire = prixMoyen - coutVariableEcole;
      const atteignable = margeUnitaire > 0;

      const ecolesNecessaires = atteignable ? Math.ceil(coutFixe / margeUnitaire) : null;
      const ecart = atteignable ? ecolesNecessaires - mrrBloc.ecoles_payantes : null;

      return {
        mois,
        devise_reference: conv.reference,
        parametres: {
          cout_fixe_mensuel: F.arrondi(coutFixe),
          prix_moyen_par_ecole: F.arrondi(prixMoyen),
          cout_variable_par_ecole: F.arrondi(coutVariableEcole),
          simulation: !!(req.query.cout_fixe || req.query.prix_moyen || req.query.cout_variable_ecole)
        },
        resultat: {
          marge_unitaire: F.arrondi(margeUnitaire),
          atteignable,
          ecoles_necessaires: ecolesNecessaires,
          ecoles_actuelles: mrrBloc.ecoles_payantes,
          ecart: ecart,
          seuil_atteint: atteignable && mrrBloc.ecoles_payantes >= ecolesNecessaires,
          chiffre_affaires_au_seuil: ecolesNecessaires ? F.arrondi(ecolesNecessaires * prixMoyen) : null,
          taux_couverture: (coutFixe + coutVariableTotal) > 0
            ? F.arrondi((mrrBloc.mrr / (coutFixe + coutVariableTotal)) * 100, 1) : null
        },
        explication: atteignable
          ? `Chaque école rapporte ${F.arrondi(margeUnitaire)} ${conv.reference} nets par mois après ses coûts variables. `
            + `Il en faut ${ecolesNecessaires} pour couvrir ${F.arrondi(coutFixe)} ${conv.reference} de coûts fixes.`
          : 'Le prix moyen ne couvre pas le coût variable par école : le seuil de rentabilité est hors d\'atteinte '
            + 'à ce tarif. Augmenter le nombre d\'écoles augmenterait la perte. Il faut relever le prix ou baisser '
            + 'le coût variable avant de raisonner en volume.',
        sources: {
          cout_fixe: 'Somme des abonnements de services actifs, ramenés au mois.',
          prix_moyen: 'MRR ÷ nombre d\'écoles payantes (tarifs négociés inclus).',
          cout_variable: 'Consommations variables + dépenses ponctuelles du mois ÷ écoles payantes.'
        }
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur seuil de rentabilité:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. PRÉVISIONS
   ========================================================================== */

/**
 * GET /super-admin/finance/previsions
 *
 * Trois scénarios (prudent, normal, optimiste) projetés à 3, 6, 12 et 24 mois.
 *
 * Les hypothèses sont EXPLICITES et renvoyées dans la réponse. Une prévision
 * dont on ne voit pas les hypothèses est un horoscope : on ne peut ni la
 * contester, ni la corriger quand la réalité s'en écarte.
 *
 * Le point de départ (écoles, prix moyen, coûts) est mesuré, pas paramétré.
 * Seuls la croissance et le churn sont des hypothèses, parce qu'ils portent
 * sur l'avenir et que rien dans la base ne peut les connaître.
 */
async function previsions(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const mois = F.moisCourant();
      const couts = await calculerCouts(client, conv, mois);
      const mrrBloc = await calculerMrr(client, conv);
      const churn = await calculerChurn(client, mois);

      const croissanceDefaut = await reglage(client, 'finance_croissance_mensuelle_defaut', 5);
      const churnDefaut = await reglage(client, 'finance_churn_mensuel_defaut', 3);

      const churnMesure = churn.mesurable ? churn.taux_mensuel : null;
      const churnBase = churnMesure !== null ? churnMesure : churnDefaut;

      const croissanceParam = F.nombrePositif(req.query.croissance);
      const croissanceBase = croissanceParam !== null ? croissanceParam : croissanceDefaut;

      const scenarios = {
        prudent:   { croissance: croissanceBase * 0.5, churn: churnBase * 1.5, inflation_couts: 3 },
        normal:    { croissance: croissanceBase,       churn: churnBase,       inflation_couts: 2 },
        optimiste: { croissance: croissanceBase * 1.8, churn: churnBase * 0.6, inflation_couts: 1.5 }
      };

      const horizons = [3, 6, 12, 24];
      const prixMoyen = mrrBloc.arpu || 0;
      const resultats = {};

      for (const [nom, hypothese] of Object.entries(scenarios)) {
        let ecoles = mrrBloc.ecoles_payantes;
        let coutMensuel = couts.total;
        const trajectoire = [];

        for (let m = 1; m <= 24; m++) {
          // Croissance et churn s'appliquent au même stock : de nouvelles
          // écoles arrivent, une part du stock part. Appliquer la croissance
          // au stock d'avant churn surestime systématiquement.
          const arrivees = ecoles * (hypothese.croissance / 100);
          const departs = ecoles * (hypothese.churn / 100);
          ecoles = Math.max(0, ecoles + arrivees - departs);
          coutMensuel = coutMensuel * (1 + (hypothese.inflation_couts / 100) / 12);

          const mrrProjete = ecoles * prixMoyen;
          if (horizons.includes(m)) {
            trajectoire.push({
              horizon_mois: m,
              ecoles: Math.round(ecoles),
              mrr: F.arrondi(mrrProjete),
              arr: F.arrondi(mrrProjete * 12),
              couts_mensuels: F.arrondi(coutMensuel),
              benefice_mensuel: F.arrondi(mrrProjete - coutMensuel),
              marge: mrrProjete > 0 ? F.arrondi(((mrrProjete - coutMensuel) / mrrProjete) * 100, 1) : null
            });
          }
        }

        resultats[nom] = { hypotheses: {
          croissance_mensuelle_pourcent: F.arrondi(hypothese.croissance, 2),
          churn_mensuel_pourcent: F.arrondi(hypothese.churn, 2),
          inflation_couts_annuelle_pourcent: hypothese.inflation_couts
        }, projections: trajectoire };
      }

      return {
        devise_reference: conv.reference,
        point_de_depart: {
          mois,
          ecoles_payantes: mrrBloc.ecoles_payantes,
          prix_moyen: F.arrondi(prixMoyen),
          mrr: mrrBloc.mrr,
          couts_mensuels: couts.total,
          benefice_mensuel: F.arrondi(mrrBloc.mrr - couts.total)
        },
        scenarios: resultats,
        fiabilite: {
          churn_mesure: churnMesure,
          churn_utilise: F.arrondi(churnBase, 2),
          origine_churn: churnMesure !== null
            ? 'Mesuré sur les abonnements du mois écoulé.'
            : `Non mesurable (${churn.raison}). Valeur de configuration utilisée : ${churnDefaut} %.`,
          origine_croissance: croissanceParam !== null
            ? 'Valeur fournie dans la requête.'
            : `Valeur de configuration : ${croissanceDefaut} % par mois. Ardoise ne dispose pas encore d'un historique `
              + 'suffisant pour la mesurer. Ajustez-la dans Configuration → finance.',
          avertissement:
            'Ces projections supposent un prix moyen constant et une structure de coûts stable. '
            + 'Elles ne remplacent pas un plan de trésorerie.'
        }
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur prévisions:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. ALERTES FINANCIÈRES
   ========================================================================== */

/**
 * GET /super-admin/finance/alertes
 *
 * Les seuils viennent de `configuration_plateforme` (catégorie finance), pas
 * du code : un seuil de marge « trop faible » dépend du modèle économique et
 * change avec lui.
 */
async function alertes(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));
      const mois = F.moisCourant();
      const moisPrecedent = F.moisCourant(-1);

      const [seuilMarge, seuilHausseApi, prealerteJours, seuilBudget] = await Promise.all([
        reglage(client, 'finance_seuil_marge_faible', 20),
        reglage(client, 'finance_seuil_hausse_cout_api', 50),
        reglage(client, 'finance_prealerte_renouvellement_jours', 14),
        reglage(client, 'finance_budget_seuil_alerte', 90)
      ]);

      const liste = [];
      const ajouter = (niveau, type, titre, detail, lien) =>
        liste.push({ niveau, type, titre, detail, lien });

      // ---- Marge ---------------------------------------------------------
      const couts = await calculerCouts(client, conv, mois);
      const ca = await revenuEncaisse(client, conv, mois);
      const mrrBloc = await calculerMrr(client, conv);
      const marge = mrrBloc.mrr > 0 ? ((mrrBloc.mrr - couts.total) / mrrBloc.mrr) * 100 : null;

      if (marge !== null && marge < seuilMarge) {
        ajouter(marge < 0 ? 'critique' : 'avertissement', 'marge',
          marge < 0 ? 'Marge négative' : 'Marge faible',
          `Marge estimée à ${F.arrondi(marge, 1)} % (seuil d'alerte : ${seuilMarge} %). `
          + `MRR ${mrrBloc.mrr} ${conv.reference} pour ${couts.total} ${conv.reference} de coûts.`,
          'finance/rentabilite');
      }

      // ---- Coûts API ------------------------------------------------------
      const apiMois = couts.api;
      const coutsPrecedent = await calculerCouts(client, conv, moisPrecedent);
      if (coutsPrecedent.api > 0) {
        const hausse = ((apiMois - coutsPrecedent.api) / coutsPrecedent.api) * 100;
        if (hausse > seuilHausseApi) {
          ajouter('critique', 'cout_api', 'Coûts API en forte hausse',
            `+${F.arrondi(hausse, 1)} % par rapport au mois précédent `
            + `(${coutsPrecedent.api} → ${apiMois} ${conv.reference}). Seuil : ${seuilHausseApi} %.`,
            'couts/services');
        }
      }

      // ---- Renouvellements de services ------------------------------------
      const renouvellements = await lignes(client, `
        SELECT nom, fournisseur, date_renouvellement, cout_mensuel, cout_annuel, devise,
               (date_renouvellement - current_date) AS jours
          FROM services_externes
         WHERE statut = 'actif' AND date_renouvellement IS NOT NULL
           AND date_renouvellement BETWEEN current_date AND current_date + ($1 || ' days')::interval
         ORDER BY date_renouvellement`, [prealerteJours]);

      for (const r of renouvellements) {
        ajouter('avertissement', 'renouvellement', `Renouvellement : ${r.nom}`,
          `${r.fournisseur || 'Fournisseur non renseigné'} — dans ${r.jours} jour(s), `
          + `le ${new Date(r.date_renouvellement).toLocaleDateString('fr-FR')}.`,
          'couts/services');
      }

      // ---- Abonnements clients --------------------------------------------
      const abosExpirants = await lignes(client, `
        SELECT e.nom AS ecole, a.date_expiration,
               (a.date_expiration::date - current_date) AS jours
          FROM abonnements a JOIN ecoles e ON e.id = a.ecole_id
         WHERE a.statut = 'actif'
           AND a.date_expiration BETWEEN now() AND now() + ($1 || ' days')::interval
         ORDER BY a.date_expiration LIMIT 30`, [prealerteJours]);

      for (const a of abosExpirants) {
        ajouter('avertissement', 'abonnement', `Abonnement bientôt expiré : ${a.ecole}`,
          `Échéance dans ${a.jours} jour(s).`, 'offres/abonnements');
      }

      const abosExpires = await mesurer(client,
        `SELECT count(*) FROM abonnements WHERE statut = 'actif' AND date_expiration < now()`, [], 0);
      if (Number(abosExpires) > 0) {
        ajouter('critique', 'impaye', 'Abonnements échus non réglés',
          `${abosExpires} abonnement(s) affichent le statut « actif » alors que leur échéance est dépassée.`,
          'offres/abonnements');
      }

      // ---- Paiements échoués ----------------------------------------------
      const echecs = await mesurer(client, `
        SELECT count(*) FROM paiements
         WHERE statut = 'echoue' AND date_paiement >= now() - interval '30 days'`, [], null);
      if (echecs !== null && Number(echecs) > 0) {
        ajouter('critique', 'paiement', 'Paiements en échec',
          `${echecs} paiement(s) ont échoué sur les 30 derniers jours.`, 'finance/journal');
      }

      // ---- Budgets ---------------------------------------------------------
      const budgets = await lignes(client, 'SELECT * FROM budgets WHERE periode = $1', [mois]);
      for (const b of budgets) {
        const reelRows = await lignes(client, `
          SELECT COALESCE(sum(montant),0) AS total, devise FROM depenses
           WHERE NOT archive AND statut <> 'annulee'
             AND to_char(date_depense,'YYYY-MM') = $1
             ${b.categorie === 'global' ? '' : 'AND categorie = $2'}`,
          b.categorie === 'global' ? [mois] : [mois, b.categorie]);
        const reel = reelRows.reduce((s, r) => s + conv.convertir(r.total, r.devise), 0);
        const prevu = conv.convertir(b.montant_prevu, b.devise);
        if (prevu > 0 && (reel / prevu) * 100 >= seuilBudget) {
          ajouter(reel > prevu ? 'critique' : 'avertissement', 'budget',
            `Budget ${b.categorie} : ${F.arrondi((reel / prevu) * 100, 0)} % consommé`,
            `${F.arrondi(reel)} ${conv.reference} dépensés sur ${F.arrondi(prevu)} ${conv.reference} prévus.`,
            'couts/budgets');
        }
      }

      // ---- Consommations non renseignées -----------------------------------
      const consoManquantes = await lignes(client, `
        SELECT s.nom FROM services_externes s
         WHERE s.statut = 'actif' AND s.cout_variable = true
           AND NOT EXISTS (SELECT 1 FROM services_consommations c
                            WHERE c.service_id = s.id AND c.periode = $1)`, [mois]);
      if (consoManquantes.length) {
        ajouter('info', 'donnee_manquante', 'Consommations à renseigner',
          `${consoManquantes.length} service(s) à coût variable sans consommation saisie pour ${mois} : `
          + `${consoManquantes.map((s) => s.nom).join(', ')}. Les coûts du mois sont sous-estimés.`,
          'couts/services');
      }

      // ---- Devises sans taux ------------------------------------------------
      if (conv.approximatif) {
        ajouter('avertissement', 'taux_change', 'Taux de change manquant',
          `Aucun taux vers ${conv.reference} pour : ${[...conv.devisesInconnues].join(', ')}. `
          + 'Les montants concernés sont additionnés sans conversion.', 'couts/taux-change');
      }

      const ordre = { critique: 0, avertissement: 1, info: 2 };
      liste.sort((a, b) => ordre[a.niveau] - ordre[b.niveau]);

      return {
        genere_a: new Date().toISOString(),
        seuils: {
          marge_faible: seuilMarge, hausse_cout_api: seuilHausseApi,
          prealerte_renouvellement_jours: prealerteJours, budget: seuilBudget
        },
        compteurs: {
          critiques: liste.filter((a) => a.niveau === 'critique').length,
          avertissements: liste.filter((a) => a.niveau === 'avertissement').length,
          informations: liste.filter((a) => a.niveau === 'info').length
        },
        alertes: liste
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur alertes financières:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   6. COÛT DES FONCTIONNALITÉS
   ========================================================================== */

/**
 * GET /super-admin/finance/cout-fonctionnalites
 *
 * Estimation du coût des grandes fonctionnalités d'Ardoise.
 *
 * Ce que la base permet réellement de mesurer aujourd'hui :
 *   · les appels IA, comptés par `ia_utilisations` ;
 *   · les bulletins générés, comptés par `bulletins` ;
 *   · les notifications émises, comptées par `notifications`.
 * Le coût unitaire, lui, N'EST PAS déductible : il faut le rapprocher du
 * service correspondant. On renvoie donc le VOLUME mesuré et le coût du
 * service associé quand l'exploitant l'a rattaché, et l'on dit franchement ce
 * qui manque quand ce n'est pas le cas.
 */
async function coutFonctionnalites(req, res) {
  const mois = F.periodeValide(req.query.mois) ? req.query.mois : F.moisCourant();

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));

      const [appelsIa, bulletins, notifications, documents] = await Promise.all([
        mesurer(client, `SELECT COALESCE(sum(nb_appels),0) FROM ia_utilisations WHERE mois = $1`, [mois], 0),
        mesurer(client, `SELECT count(*) FROM bulletins WHERE to_char(created_at,'YYYY-MM') = $1`, [mois], null),
        mesurer(client, `SELECT count(*) FROM notifications WHERE to_char(created_at,'YYYY-MM') = $1`, [mois], null),
        mesurer(client, `SELECT count(*) FROM documents WHERE to_char(created_at,'YYYY-MM') = $1`, [mois], null)
      ]);

      // Services à coût variable, par catégorie : ce sont eux qui portent le
      // coût de ces usages.
      const servicesVariables = await lignes(client, `
        SELECT s.id, s.nom, s.categorie, s.devise, s.prix_unitaire, s.unite,
               c.quantite, c.cout_reel, c.cout_estime
          FROM services_externes s
          LEFT JOIN services_consommations c ON c.service_id = s.id AND c.periode = $1
         WHERE s.statut = 'actif' AND s.cout_variable = true`, [mois]);

      const coutParCategorie = {};
      for (const s of servicesVariables) {
        const brut = s.cout_reel ?? s.cout_estime;
        if (brut === null || brut === undefined) continue;
        coutParCategorie[s.categorie] = (coutParCategorie[s.categorie] || 0) + conv.convertir(brut, s.devise);
      }

      const fonctionnalites = [
        {
          cle: 'ia',
          libelle: 'Assistant et fonctions IA',
          volume: Number(appelsIa || 0),
          unite: 'appels',
          cout_estime: coutParCategorie.api !== undefined ? F.arrondi(coutParCategorie.api) : null,
          cout_unitaire: (coutParCategorie.api !== undefined && Number(appelsIa) > 0)
            ? F.arrondi(coutParCategorie.api / Number(appelsIa), 4) : null,
          source: 'ia_utilisations (volume) × services de catégorie « api » (coût)',
          manquant: coutParCategorie.api === undefined
            ? 'Aucun service de catégorie « api » avec consommation saisie pour ce mois.' : null
        },
        {
          cle: 'communication',
          libelle: 'E-mails, SMS et notifications',
          volume: notifications,
          unite: 'notifications',
          cout_estime: coutParCategorie.communication !== undefined ? F.arrondi(coutParCategorie.communication) : null,
          cout_unitaire: (coutParCategorie.communication !== undefined && notifications > 0)
            ? F.arrondi(coutParCategorie.communication / notifications, 4) : null,
          source: 'notifications (volume) × services de catégorie « communication » (coût)',
          manquant: coutParCategorie.communication === undefined
            ? 'Aucun service de catégorie « communication » avec consommation saisie (Resend, SMS, WhatsApp…).' : null
        },
        {
          cle: 'bulletins',
          libelle: 'Génération de bulletins',
          volume: bulletins,
          unite: 'bulletins',
          cout_estime: null,
          cout_unitaire: null,
          source: 'bulletins (volume)',
          manquant: 'Le coût de génération est porté par le serveur applicatif (Render), '
                  + 'qui est un coût fixe : il ne se répartit pas par bulletin sans instrumentation dédiée.'
        },
        {
          cle: 'stockage',
          libelle: 'Stockage de fichiers',
          volume: documents,
          unite: 'documents',
          cout_estime: coutParCategorie.infrastructure !== undefined ? F.arrondi(coutParCategorie.infrastructure) : null,
          cout_unitaire: null,
          source: 'documents (volume) × services de catégorie « infrastructure » (coût)',
          manquant: 'Le volume en octets n\'est pas suivi : Ardoise compte les fichiers, pas leur taille cumulée.'
        }
      ];

      return {
        mois,
        devise_reference: conv.reference,
        fonctionnalites,
        note: 'Ces estimations reposent sur le rattachement des services à une catégorie. '
            + 'Plus le catalogue de services est renseigné finement, plus elles sont justes.'
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur coût fonctionnalités:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   7. JOURNAL FINANCIER
   ========================================================================== */

/** GET /super-admin/finance/journal */
async function journal(req, res) {
  const { page, taille, decalage } = pagination(req, 40);
  const { entite, action, depuis, jusqu } = req.query;

  const conditions = [];
  const params = [];
  if (entite) { params.push(entite); conditions.push(`j.entite = $${params.length}`); }
  if (action) { params.push(`${action}%`); conditions.push(`j.action LIKE $${params.length}`); }
  if (F.dateIso(depuis)) { params.push(F.dateIso(depuis)); conditions.push(`j.created_at >= $${params.length}::date`); }
  if (F.dateIso(jusqu)) { params.push(F.dateIso(jusqu)); conditions.push(`j.created_at < ($${params.length}::date + interval '1 day')`); }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client, `SELECT count(*) FROM journal_financier j ${filtre}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT j.*, trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur_nom,
               u.email AS utilisateur_email, e.nom AS ecole_nom
          FROM journal_financier j
          LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
          LEFT JOIN ecoles e ON e.id = j.ecole_id
          ${filtre}
         ORDER BY j.created_at DESC
         LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      const typesAction = await lignes(client,
        `SELECT DISTINCT split_part(action, '.', 1) AS famille FROM journal_financier ORDER BY 1`);

      return { total, donnees, familles: typesAction.map((t) => t.famille) };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      familles: resultat.familles
    }));
  } catch (err) {
    console.error('Erreur journal financier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   8. PERMISSIONS FINANCIÈRES
   ========================================================================== */

/** GET /super-admin/finance/permissions */
async function listerPermissions(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, `
      SELECT u.id AS utilisateur_id, u.email,
             trim(concat_ws(' ', u.prenom, u.nom)) AS nom,
             u.statut,
             COALESCE(fa.niveau, 'complet') AS niveau,
             fa.note, fa.updated_at,
             trim(concat_ws(' ', ap.prenom, ap.nom)) AS accorde_par_nom
        FROM utilisateurs u
        JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id AND ur.role::text = 'super_admin'
        LEFT JOIN finance_acces fa ON fa.utilisateur_id = u.id
        LEFT JOIN utilisateurs ap ON ap.id = fa.accorde_par
       ORDER BY nom`));

    return res.json({
      donnees,
      niveaux: [
        { cle: 'complet', libelle: 'Accès complet', description: 'Lecture et écriture sur toute la gestion commerciale et financière.' },
        { cle: 'lecture', libelle: 'Lecture seule', description: 'Consultation uniquement. Aucune création, modification ou archivage.' }
      ],
      note: "Sans réglage explicite, un Super Administrateur dispose de l'accès complet."
    });
  } catch (err) {
    console.error('Erreur permissions finance:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PUT /super-admin/finance/permissions/:utilisateurId
 *
 * Un Super Admin ne peut pas se restreindre lui-même : il se retrouverait
 * enfermé hors de son propre outil sans personne pour l'y remettre si c'est
 * le seul compte. Le refus est explicite plutôt que silencieux.
 */
async function definirPermission(req, res) {
  const { utilisateurId } = req.params;
  const niveau = ['complet', 'lecture'].includes((req.body || {}).niveau) ? req.body.niveau : null;
  if (!niveau) return res.status(400).json({ message: 'niveau doit valoir « complet » ou « lecture ».' });

  if (String(utilisateurId) === String(req.auth.userId) && niveau === 'lecture') {
    return res.status(409).json({
      message: 'Vous ne pouvez pas restreindre votre propre accès financier. '
             + 'Demandez à un autre Super Administrateur de le faire.'
    });
  }

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const cible = await client.query(`
        SELECT u.id, u.email, trim(concat_ws(' ', u.prenom, u.nom)) AS nom
          FROM utilisateurs u
          JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id AND ur.role::text = 'super_admin'
         WHERE u.id = $1`, [utilisateurId]);

      if (!cible.rows.length) {
        throw Object.assign(new Error('Utilisateur introuvable ou non Super Administrateur.'), { statusCode: 404 });
      }

      const avant = await client.query('SELECT niveau FROM finance_acces WHERE utilisateur_id = $1', [utilisateurId]);

      const r = await client.query(
        `INSERT INTO finance_acces (utilisateur_id, niveau, note, accorde_par)
         VALUES ($1,$2,$3,$4)
         ON CONFLICT (utilisateur_id) DO UPDATE SET
           niveau = EXCLUDED.niveau, note = EXCLUDED.note, accorde_par = EXCLUDED.accorde_par
         RETURNING *`,
        [utilisateurId, niveau, F.texte((req.body || {}).note, 300), req.auth.userId]);

      await F.journaliser(client, req, {
        action: 'permission.modifiee', entite: 'finance_acces', entiteId: utilisateurId,
        libelle: cible.rows[0].nom || cible.rows[0].email,
        ancienneValeur: { niveau: avant.rows[0] ? avant.rows[0].niveau : 'complet' },
        nouvelleValeur: { niveau },
        raison: F.texte((req.body || {}).note, 300)
      });

      return { acces: r.rows[0], utilisateur: cible.rows[0] };
    });

    oublierAcces(utilisateurId);
    return res.json({ message: 'Niveau d\'accès financier mis à jour.', ...resultat });
  } catch (err) {
    console.error('Erreur permission finance:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   9. EXPORTS
   ========================================================================== */

/**
 * Catalogue des exports financiers.
 * Écrit en SQL déclaratif plutôt qu'en code : ajouter un rapport = ajouter
 * une entrée, sans toucher à la mécanique d'export.
 */
const RAPPORTS_FINANCE = {
  revenus: {
    libelle: 'Revenus par mois',
    sql: `SELECT to_char(p.date_paiement,'YYYY-MM') AS mois,
                 p.devise AS devise,
                 count(*) AS nb_paiements,
                 sum(p.montant) AS montant_total
            FROM paiements p
           WHERE p.statut = 'confirme'
           GROUP BY 1, 2 ORDER BY 1 DESC`
  },
  abonnements: {
    libelle: 'Abonnements et prix appliqués',
    sql: `SELECT e.nom AS ecole, e.code, pl.nom AS offre,
                 pl.prix AS prix_catalogue,
                 COALESCE(t.prix_personnalise, a.prix_applique, pl.prix) AS prix_paye,
                 COALESCE(pl.prix,0) - COALESCE(t.prix_personnalise, a.prix_applique, pl.prix) AS remise,
                 pl.devise, a.statut, a.date_debut, a.date_expiration,
                 a.en_periode_essai, t.raison AS motif_remise
            FROM abonnements a
            JOIN ecoles e ON e.id = a.ecole_id
            LEFT JOIN plans_abonnement pl ON pl.id = a.plan_id
            LEFT JOIN tarifs_personnalises t ON t.ecole_id = a.ecole_id AND t.statut = 'actif'
           ORDER BY e.nom`
  },
  depenses: {
    libelle: 'Dépenses',
    sql: `SELECT d.date_depense, d.libelle, d.fournisseur, s.nom AS service,
                 d.categorie, d.montant, d.devise, d.recurrence, d.statut,
                 d.justificatif_url, d.archive
            FROM depenses d
            LEFT JOIN services_externes s ON s.id = d.service_id
           ORDER BY d.date_depense DESC`
  },
  services: {
    libelle: 'Services et coûts',
    sql: `SELECT s.nom, s.categorie, s.fournisseur, s.plan, s.cout_mensuel, s.cout_annuel,
                 s.devise, s.cout_variable, s.prix_unitaire, s.unite, s.limite_incluse,
                 s.frequence_facturation, s.jour_facturation, s.date_renouvellement, s.statut
            FROM services_externes s
           WHERE s.statut <> 'archive'
           ORDER BY s.categorie, s.nom`
  },
  consommations: {
    libelle: 'Consommations variables',
    sql: `SELECT s.nom AS service, c.periode, c.quantite, c.unite,
                 c.prix_unitaire, c.cout_estime, c.cout_reel, c.devise, c.source
            FROM services_consommations c
            JOIN services_externes s ON s.id = c.service_id
           ORDER BY c.periode DESC, s.nom`
  },
  historique_prix: {
    libelle: 'Historique des prix',
    sql: `SELECT pl.nom AS offre, h.ancien_prix, h.nouveau_prix, h.devise,
                 h.raison, h.date_application, h.ecoles_impactees, h.impact_mrr_estime,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS modifie_par, h.created_at
            FROM plan_prix_historique h
            JOIN plans_abonnement pl ON pl.id = h.plan_id
            LEFT JOIN utilisateurs u ON u.id = h.modifie_par
           ORDER BY h.created_at DESC`
  },
  remises: {
    libelle: 'Remises accordées',
    sql: `SELECT e.nom AS ecole, pl.nom AS offre, t.prix_catalogue, t.prix_personnalise,
                 (t.prix_catalogue - t.prix_personnalise) AS remise, t.devise,
                 t.raison, t.date_debut, t.date_fin, t.statut,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS accorde_par
            FROM tarifs_personnalises t
            JOIN ecoles e ON e.id = t.ecole_id
            LEFT JOIN plans_abonnement pl ON pl.id = t.plan_id
            LEFT JOIN utilisateurs u ON u.id = t.accorde_par
           ORDER BY t.created_at DESC`
  },
  journal_financier: {
    libelle: 'Journal financier',
    sql: `SELECT j.created_at, j.action, j.entite, j.libelle, j.montant, j.devise, j.raison,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS par, e.nom AS ecole
            FROM journal_financier j
            LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
            LEFT JOIN ecoles e ON e.id = j.ecole_id
           ORDER BY j.created_at DESC LIMIT 5000`
  }
};

/** GET /super-admin/finance/exports */
function catalogueExports(req, res) {
  return res.json({
    rapports: Object.entries(RAPPORTS_FINANCE).map(([cle, r]) => ({ cle, libelle: r.libelle })),
    formats: ['xlsx', 'csv', 'pdf', 'json']
  });
}

/**
 * GET /super-admin/finance/exports/:rapport?format=xlsx|csv|pdf|json
 *
 * Le « PDF » est une page HTML imprimable, exactement comme les rapports
 * existants (`super-admin-support.controller.js`) : lancer un navigateur
 * headless pour un tableau consommerait plusieurs centaines de mégaoctets sur
 * une instance déjà contrainte, quand le navigateur du poste le fait mieux.
 */
async function exporterRapportFinance(req, res) {
  const definition = RAPPORTS_FINANCE[req.params.rapport];
  if (!definition) {
    return res.status(404).json({
      message: `Rapport inconnu. Disponibles : ${Object.keys(RAPPORTS_FINANCE).join(', ')}.`
    });
  }

  const format = ['xlsx', 'csv', 'pdf', 'json'].includes(req.query.format) ? req.query.format : 'xlsx';
  const horodatage = new Date().toISOString().slice(0, 10);
  const nomFichier = `ardoise-finance-${req.params.rapport}-${horodatage}`;

  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, definition.sql));

    // Toute extraction financière est tracée : savoir qui a sorti la liste des
    // remises, et quand, fait partie de la sécurité financière (mission § 25).
    await runWithTenant(SUPER, (client) => F.journaliser(client, req, {
      action: 'export.effectue', entite: 'rapport', libelle: definition.libelle,
      nouvelleValeur: { format, lignes: donnees.length }
    }));

    if (format === 'json') {
      return res.json({ rapport: definition.libelle, genere_a: new Date().toISOString(), donnees });
    }

    if (format === 'csv') {
      const feuille = XLSX.utils.json_to_sheet(donnees.length ? donnees : [{ Information: 'Aucune donnée' }]);
      // BOM UTF-8 : sans lui, Excel sous Windows affiche « École » en « Ã‰cole ».
      const csv = '\uFEFF' + XLSX.utils.sheet_to_csv(feuille, { FS: ';' });
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${nomFichier}.csv"`);
      return res.send(csv);
    }

    if (format === 'pdf') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.send(pageImprimable(definition.libelle, donnees));
    }

    const classeur = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      classeur,
      XLSX.utils.json_to_sheet(donnees.length ? donnees : [{ Information: 'Aucune donnée' }]),
      definition.libelle.slice(0, 31)
    );
    const tampon = XLSX.write(classeur, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${nomFichier}.xlsx"`);
    return res.send(tampon);
  } catch (err) {
    console.error('Erreur export financier:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

function echapperHtml(v) {
  return String(v ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function pageImprimable(titre, donnees) {
  const colonnes = donnees.length ? Object.keys(donnees[0]) : ['Information'];
  const corps = donnees.length
    ? donnees.map((l) => `<tr>${colonnes.map((c) => `<td>${echapperHtml(l[c])}</td>`).join('')}</tr>`).join('')
    : '<tr><td>Aucune donnée</td></tr>';

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8" />
<title>Ardoise — ${echapperHtml(titre)}</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; margin: 28px; color: #2B2A26; }
  h1 { font-size: 1.3rem; margin: 0 0 4px; }
  p.meta { color: #7A7466; font-size: .8rem; margin: 0 0 18px; }
  table { border-collapse: collapse; width: 100%; font-size: .78rem; }
  th, td { border: 1px solid #E2DACA; padding: 6px 8px; text-align: left; }
  th { background: #F6F1E7; font-weight: 600; }
  tr:nth-child(even) td { background: #FFFDF8; }
  @media print { body { margin: 8mm; } }
</style></head><body>
<h1>${echapperHtml(titre)}</h1>
<p class="meta">Ardoise — généré le ${new Date().toLocaleString('fr-FR')} — ${donnees.length} ligne(s)</p>
<table><thead><tr>${colonnes.map((c) => `<th>${echapperHtml(c)}</th>`).join('')}</tr></thead>
<tbody>${corps}</tbody></table>
<script>window.print&&setTimeout(function(){window.print();},350);</script>
</body></html>`;
}

module.exports = {
  tableauDeBordFinancier, rentabilite, seuilRentabilite, previsions,
  alertes, coutFonctionnalites, journal,
  listerPermissions, definirPermission,
  catalogueExports, exporterRapportFinance,
  calculerMrr, calculerCouts, calculerChurn
};
