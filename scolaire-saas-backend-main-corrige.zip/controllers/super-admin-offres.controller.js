/**
 * Espace Super Administrateur — Offres, tarification et gestion commerciale.
 * ---------------------------------------------------------------------------
 * Couvre les sections 2 à 6 et 17 de la mission : offres configurables,
 * changement de prix tracé, promotions, offres spéciales, tarifs négociés,
 * et vue « prix catalogue vs prix réellement payé ».
 *
 * PRINCIPE DIRECTEUR
 * ------------------
 * Aucun nom d'offre n'apparaît dans ce fichier. « Ardoise Prime », « Pilote »,
 * « Infinite » sont des LIGNES de `plans_abonnement`, créées depuis
 * l'interface. Chercher ces mots dans le code ne donne aucun résultat, et
 * c'est le but : renommer une offre ne doit jamais demander un déploiement.
 *
 * SUR LES SUPPRESSIONS
 * --------------------
 * Il n'y a pas de DELETE dans ce fichier. Une offre se désactive puis
 * s'archive ; une promotion s'archive ; un tarif négocié se termine. Une
 * suppression physique effacerait le passé financier d'écoles qui, elles,
 * s'en souviennent — et rendrait le MRR historique impossible à reconstituer.
 */

const { runWithTenant } = require('../config/db');
const cache = require('../utils/cache.utils');
const { mesurer, lignes, pagination, reponsePaginee, motifRecherche } = require('../utils/super-admin.utils');
const F = require('../utils/finance.utils');

const SUPER = { isSuperAdmin: true };

/**
 * Invalide les caches après toute écriture commerciale.
 *
 * Deux préfixes, et il faut les deux : `sa:` pour les écrans du Super Admin,
 * `catalogue:` pour ce que voient les écoles et le site public. N'invalider
 * que le premier donnait un résultat déroutant — le Super Admin constatait sa
 * baisse de prix immédiatement, le site public continuait d'afficher l'ancien
 * tarif pendant une minute, et l'écart passait pour un bug d'affichage.
 */
function invaliderCaches() {
  try { cache.invalider('sa:'); } catch { /* cache absent : sans conséquence */ }
  try { require('../utils/catalogue.utils').invaliderCache(); } catch { /* idem */ }
}

/* ==========================================================================
   1. OFFRES (plans d'abonnement)
   ========================================================================== */

/**
 * GET /super-admin/offres
 *
 * Chaque offre est renvoyée avec ce qu'elle pèse réellement : nombre d'écoles
 * abonnées, MRR généré, remises accordées. Une grille tarifaire sans ces
 * chiffres ne dit pas laquelle des offres fait vivre la plateforme.
 */
async function listerOffres(req, res) {
  const inclureArchivees = String(req.query.archivees || '') === 'oui';

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));

      const offres = await lignes(client, `
        SELECT p.*,
               (SELECT count(*) FROM abonnements a
                 WHERE a.plan_id = p.id AND a.statut = 'actif')     AS abonnements_actifs,
               (SELECT count(*) FROM abonnements a
                 WHERE a.plan_id = p.id)                            AS abonnements_total,
               (SELECT count(*) FROM abonnements a
                 WHERE a.plan_id = p.id AND a.en_periode_essai)     AS en_essai,
               (SELECT count(*) FROM tarifs_personnalises t
                 WHERE t.plan_id = p.id AND t.statut = 'actif')     AS tarifs_negocies
          FROM plans_abonnement p
         ${inclureArchivees ? '' : "WHERE COALESCE(p.statut,'actif') <> 'archive'"}
         ORDER BY COALESCE(p.ordre_affichage, 0), p.prix NULLS LAST, p.nom`);

      // Revenu réellement encaissé par offre : la seule mesure qui ne suppose
      // rien. `paiements` est rattaché à une facture, elle-même à un
      // abonnement, lui-même à un plan.
      const revenus = await lignes(client, `
        SELECT a.plan_id,
               COALESCE(sum(pa.montant), 0) AS encaisse,
               pa.devise
          FROM paiements pa
          JOIN factures f    ON f.id = pa.facture_id
          JOIN abonnements a ON a.id = f.abonnement_id
         WHERE pa.statut = 'confirme'
         GROUP BY a.plan_id, pa.devise`);

      const encaisseParPlan = {};
      for (const r of revenus) {
        const cle = String(r.plan_id);
        encaisseParPlan[cle] = (encaisseParPlan[cle] || 0) + conv.convertir(r.encaisse, r.devise);
      }

      // MRR par offre, au prix RÉELLEMENT appliqué (tarif négocié compris).
      const mrrLignes = await lignes(client, `
        SELECT a.plan_id,
               COALESCE(t.prix_personnalise, a.prix_applique, p.prix)      AS prix,
               COALESCE(t.devise, a.devise_appliquee, p.devise)            AS devise,
               COALESCE(t.periodicite, a.periodicite, 'mensuel')           AS periodicite,
               p.duree_jours,
               a.prix_applique IS NOT NULL OR t.id IS NOT NULL             AS prix_specifique,
               p.prix                                                      AS prix_catalogue
          FROM abonnements a
          JOIN plans_abonnement p ON p.id = a.plan_id
          LEFT JOIN tarifs_personnalises t
                 ON t.ecole_id = a.ecole_id AND t.statut = 'actif'
         WHERE a.statut = 'actif'`);

      const mrrParPlan = {};
      const remiseParPlan = {};
      for (const l of mrrLignes) {
        const cle = String(l.plan_id);
        const base = l.periodicite && l.periodicite !== 'mensuel'
          ? F.mensualiserPeriodicite(l.prix, l.periodicite)
          : F.mensualiser(l.prix, l.duree_jours);
        mrrParPlan[cle] = (mrrParPlan[cle] || 0) + conv.convertir(base, l.devise);

        if (l.prix_specifique && l.prix_catalogue !== null) {
          const catalogue = F.mensualiser(l.prix_catalogue, l.duree_jours);
          const remise = conv.convertir(catalogue, l.devise) - conv.convertir(base, l.devise);
          if (remise > 0) remiseParPlan[cle] = (remiseParPlan[cle] || 0) + remise;
        }
      }

      return {
        devise_reference: conv.reference,
        conversion_approximative: conv.approximatif,
        devises_sans_taux: [...conv.devisesInconnues],
        offres: offres.map((o) => ({
          ...o,
          statut: o.statut || 'actif',
          mrr: F.arrondi(mrrParPlan[String(o.id)] || 0),
          arr: F.arrondi((mrrParPlan[String(o.id)] || 0) * 12),
          revenu_encaisse: F.arrondi(encaisseParPlan[String(o.id)] || 0),
          remises_mensuelles: F.arrondi(remiseParPlan[String(o.id)] || 0),
          prix_mensuel_equivalent: F.arrondi(F.mensualiser(o.prix, o.duree_jours))
        }))
      };
    });

    return res.json({ ...donnees, peut_ecrire: !!(req.finance && req.finance.peutEcrire) });
  } catch (err) {
    console.error('Erreur liste offres:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** Lit la devise de référence dans la configuration, avec repli sur USD. */
async function deviseReference(client) {
  try {
    const r = await client.query(
      `SELECT valeur FROM configuration_plateforme WHERE cle = 'finance_devise_reference'`);
    if (r.rows.length && r.rows[0].valeur) {
      const v = r.rows[0].valeur;
      return String(typeof v === 'string' ? v.replace(/"/g, '') : v).toUpperCase();
    }
  } catch { /* configuration absente */ }
  return 'USD';
}

/** Lit un réglage numérique de `configuration_plateforme`. */
async function reglage(client, cle, defaut) {
  try {
    const r = await client.query('SELECT valeur FROM configuration_plateforme WHERE cle = $1', [cle]);
    if (!r.rows.length) return defaut;
    const n = Number(String(r.rows[0].valeur).replace(/"/g, ''));
    return Number.isFinite(n) ? n : defaut;
  } catch { return defaut; }
}

/**
 * POST /super-admin/offres
 *
 * Le prix n'est pas modifiable par cette route ensuite : il passe par
 * `/offres/:id/prix`, qui exige un motif et écrit l'historique. Séparer les
 * deux est délibéré — un changement de prix n'est pas une modification de
 * fiche produit, il a des conséquences sur des factures.
 */
async function creerOffre(req, res) {
  const b = req.body || {};
  const nom = F.texte(b.nom, 120);
  if (!nom) return res.status(400).json({ message: 'Le nom de l\'offre est requis.' });

  const prix = F.nombrePositif(b.prix);
  if (prix === null) return res.status(400).json({ message: 'Le prix mensuel doit être un nombre positif ou nul.' });

  const dureeJours = F.entier(b.duree_jours, 1, 3660) || 30;

  try {
    const offre = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO plans_abonnement
           (nom, code, description, prix, prix_annuel, devise, duree_jours,
            max_eleves, max_utilisateurs, fonctionnalites_incluses, fonctionnalites_exclues,
            statut, ordre_affichage, badge, couleur, texte_marketing, visible_public, updated_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11::jsonb,$12,$13,$14,$15,$16,$17,$18)
         RETURNING *`,
        [
          nom,
          F.texte(b.code, 40),
          F.texte(b.description, 2000),
          prix,
          F.nombrePositif(b.prix_annuel),
          F.texte(b.devise, 8) || 'USD',
          dureeJours,
          F.entier(b.max_eleves, 0, 1000000),
          F.entier(b.max_utilisateurs, 0, 100000),
          JSON.stringify(Array.isArray(b.fonctionnalites_incluses) ? b.fonctionnalites_incluses.map((x) => F.texte(x, 160)).filter(Boolean) : []),
          JSON.stringify(Array.isArray(b.fonctionnalites_exclues) ? b.fonctionnalites_exclues.map((x) => F.texte(x, 160)).filter(Boolean) : []),
          ['actif', 'inactif'].includes(b.statut) ? b.statut : 'actif',
          F.entier(b.ordre_affichage, 0, 999) || 0,
          F.texte(b.badge, 40),
          F.texte(b.couleur, 24),
          F.texte(b.texte_marketing, 2000),
          b.visible_public !== false,
          req.auth.userId
        ]
      );
      const creee = r.rows[0];

      // Première ligne d'historique : le prix d'origine. Sans elle, le
      // premier changement de prix afficherait « ancien prix : — ».
      await client.query(
        `INSERT INTO plan_prix_historique
           (plan_id, ancien_prix, nouveau_prix, ancien_prix_annuel, nouveau_prix_annuel,
            devise, raison, modifie_par)
         VALUES ($1, NULL, $2, NULL, $3, $4, 'Création de l''offre', $5)`,
        [creee.id, creee.prix, creee.prix_annuel, creee.devise, req.auth.userId]
      );

      await F.journaliser(client, req, {
        action: 'offre.creee', entite: 'plans_abonnement', entiteId: creee.id,
        libelle: creee.nom, nouvelleValeur: { prix: creee.prix, devise: creee.devise, duree_jours: creee.duree_jours },
        montant: creee.prix, devise: creee.devise
      });

      return creee;
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Offre créée.', offre });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Ce code d\'offre est déjà utilisé.' });
    }
    console.error('Erreur création offre:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** Champs modifiables sans conséquence tarifaire. */
const CHAMPS_OFFRE = {
  nom: (v) => F.texte(v, 120),
  code: (v) => F.texte(v, 40),
  description: (v) => F.texte(v, 2000),
  devise: (v) => F.texte(v, 8),
  duree_jours: (v) => F.entier(v, 1, 3660),
  max_eleves: (v) => F.entier(v, 0, 1000000),
  max_utilisateurs: (v) => F.entier(v, 0, 100000),
  ordre_affichage: (v) => F.entier(v, 0, 999),
  badge: (v) => F.texte(v, 40),
  couleur: (v) => F.texte(v, 24),
  texte_marketing: (v) => F.texte(v, 2000),
  // Ajoutés par la refonte commerciale (migration 028). Sans eux, le
  // positionnement affiché sur le site public n'était modifiable que par une
  // requête SQL — c'est-à-dire, en pratique, jamais.
  positionnement: (v) => F.texte(v, 160),
  cible: (v) => F.texte(v, 400)
};

/**
 * Limites d'une offre.
 *
 * Traitées à part des champs simples pour trois raisons :
 *   · elles vivent dans une colonne jsonb, pas dans une colonne par limite ;
 *   · `null` y signifie « sans limite » et doit être distingué de « absent » ;
 *   · une clé inconnue doit être REFUSÉE et non enregistrée. Sinon l'interface
 *     laisse saisir `max_classe` (sans s), la valeur est stockée, aucun code ne
 *     la lit jamais, et l'offre paraît configurée alors qu'elle ne l'est pas.
 */
const LIMITES_CONNUES = {
  max_eleves:               [0, 1000000],
  max_utilisateurs:         [0, 100000],
  max_classes:              [0, 10000],
  ia_quota_mensuel:         [0, 1000000],
  historique_annees:        [0, 100],
  stockage_mo:              [0, 10000000],
  notifications_email_mois: [0, 10000000]
};

function nettoyerLimites(brut) {
  if (!brut || typeof brut !== 'object' || Array.isArray(brut)) {
    throw Object.assign(new Error('Les limites doivent être un objet.'), { statusCode: 400 });
  }

  const inconnues = Object.keys(brut).filter((c) => !(c in LIMITES_CONNUES));
  if (inconnues.length) {
    throw Object.assign(new Error(
      `Limite${inconnues.length > 1 ? 's' : ''} inconnue${inconnues.length > 1 ? 's' : ''} : `
      + `${inconnues.join(', ')}. Clés acceptées : ${Object.keys(LIMITES_CONNUES).join(', ')}.`
    ), { statusCode: 400 });
  }

  const sortie = {};
  for (const [cle, [mini, maxi]] of Object.entries(LIMITES_CONNUES)) {
    if (!(cle in brut)) continue;
    const v = brut[cle];
    // Vide ou null = sans limite. C'est une valeur, pas une absence de valeur.
    sortie[cle] = (v === null || v === '' || v === undefined) ? null : F.entier(v, mini, maxi);
  }
  return sortie;
}

/** PATCH /super-admin/offres/:id */
async function modifierOffre(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const colonnes = [];
  const params = [];
  const modifications = {};

  for (const [champ, nettoyer] of Object.entries(CHAMPS_OFFRE)) {
    if (!(champ in b)) continue;
    const valeur = nettoyer(b[champ]);
    params.push(valeur);
    colonnes.push(`${champ} = $${params.length}`);
    modifications[champ] = valeur;
  }

  for (const champ of ['fonctionnalites_incluses', 'fonctionnalites_exclues']) {
    if (!(champ in b)) continue;
    const liste = Array.isArray(b[champ]) ? b[champ].map((x) => F.texte(x, 160)).filter(Boolean) : [];
    params.push(JSON.stringify(liste));
    colonnes.push(`${champ} = $${params.length}::jsonb`);
    modifications[champ] = liste;
  }

  if ('visible_public' in b) {
    params.push(b.visible_public !== false);
    colonnes.push(`visible_public = $${params.length}`);
    modifications.visible_public = b.visible_public !== false;
  }

  // Limites (jsonb). Fusionnées avec l'existant plutôt que remplacées : une
  // interface qui n'envoie que le champ modifié ne doit pas effacer les six
  // autres limites au passage.
  if ('limites' in b) {
    let limites;
    try {
      limites = nettoyerLimites(b.limites);
    } catch (err) {
      return res.status(err.statusCode || 400).json({ message: err.message });
    }
    params.push(JSON.stringify(limites));
    colonnes.push(`limites = COALESCE(limites, '{}'::jsonb) || $${params.length}::jsonb`);
    modifications.limites = limites;
  }

  // Drapeaux de fonctionnalités (jsonb). Même logique de fusion. Les codes ne
  // sont PAS validés ici mais dans utils/catalogue.utils.js, seule liste de
  // référence — la dupliquer garantirait qu'elles divergent.
  if ('fonctionnalites' in b) {
    const source = (b.fonctionnalites && typeof b.fonctionnalites === 'object'
                    && !Array.isArray(b.fonctionnalites)) ? b.fonctionnalites : {};
    const connues = require('../utils/catalogue.utils').FONCTIONNALITES;
    const inconnues = Object.keys(source).filter((c) => !(c in connues));
    if (inconnues.length) {
      return res.status(400).json({
        message: `Fonctionnalité${inconnues.length > 1 ? 's' : ''} inconnue${inconnues.length > 1 ? 's' : ''} : `
               + `${inconnues.join(', ')}. Une fonctionnalité doit d'abord exister dans le code `
               + `(utils/catalogue.utils.js) pour pouvoir être vendue.`
      });
    }
    const drapeaux = {};
    for (const cle of Object.keys(source)) drapeaux[cle] = source[cle] === true;
    params.push(JSON.stringify(drapeaux));
    colonnes.push(`fonctionnalites = COALESCE(fonctionnalites, '{}'::jsonb) || $${params.length}::jsonb`);
    modifications.fonctionnalites = drapeaux;
  }

  if (!colonnes.length) return res.status(400).json({ message: 'Aucune modification transmise.' });

  params.push(req.auth.userId);
  colonnes.push(`updated_by = $${params.length}`);
  params.push(id);

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM plans_abonnement WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Offre introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE plans_abonnement SET ${colonnes.join(', ')} WHERE id = $${params.length} RETURNING *`,
        params
      );

      const ancien = {};
      for (const cle of Object.keys(modifications)) ancien[cle] = avant.rows[0][cle];

      await F.journaliser(client, req, {
        action: 'offre.modifiee', entite: 'plans_abonnement', entiteId: id,
        libelle: r.rows[0].nom, ancienneValeur: ancien, nouvelleValeur: modifications,
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Offre mise à jour.', offre: resultat });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ message: 'Ce code d\'offre est déjà utilisé.' });
    console.error('Erreur modification offre:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/offres/:id/impact-prix
 *
 * Simulation SANS écriture : combien d'écoles seraient concernées, et de
 * combien le MRR bougerait. Appelée par l'interface avant d'afficher l'écran
 * de confirmation. Séparer la simulation de l'application permet de montrer
 * l'impact réel — calculé en base — plutôt qu'une estimation faite côté
 * navigateur avec des chiffres approximatifs.
 */
async function simulerChangementPrix(req, res) {
  const { id } = req.params;
  const nouveauPrix = F.nombrePositif((req.body || {}).nouveau_prix);
  if (nouveauPrix === null) return res.status(400).json({ message: 'nouveau_prix est requis.' });

  try {
    const impact = await runWithTenant(SUPER, async (client) => {
      const plan = await client.query('SELECT * FROM plans_abonnement WHERE id = $1', [id]);
      if (!plan.rows.length) throw Object.assign(new Error('Offre introuvable.'), { statusCode: 404 });
      const p = plan.rows[0];

      // Les écoles au tarif négocié ne sont PAS impactées : leur prix est
      // fixé par contrat, pas par la grille. Les compter serait annoncer un
      // gain qui n'arrivera jamais.
      const concernees = await mesurer(client, `
        SELECT count(*) FROM abonnements a
         WHERE a.plan_id = $1 AND a.statut = 'actif'
           AND a.prix_applique IS NULL
           AND NOT EXISTS (SELECT 1 FROM tarifs_personnalises t
                            WHERE t.ecole_id = a.ecole_id AND t.statut = 'actif')`, [id], 0);

      const protegees = await mesurer(client, `
        SELECT count(*) FROM abonnements a
         WHERE a.plan_id = $1 AND a.statut = 'actif'
           AND (a.prix_applique IS NOT NULL
                OR EXISTS (SELECT 1 FROM tarifs_personnalises t
                            WHERE t.ecole_id = a.ecole_id AND t.statut = 'actif'))`, [id], 0);

      const ancienMensuel = F.mensualiser(p.prix, p.duree_jours);
      const nouveauMensuel = F.mensualiser(nouveauPrix, p.duree_jours);
      const deltaMrr = (nouveauMensuel - ancienMensuel) * Number(concernees || 0);

      return {
        offre: { id: p.id, nom: p.nom, devise: p.devise, duree_jours: p.duree_jours },
        ancien_prix: Number(p.prix),
        nouveau_prix: nouveauPrix,
        variation_absolue: F.arrondi(nouveauPrix - Number(p.prix)),
        variation_pourcentage: Number(p.prix) ? F.arrondi(((nouveauPrix - Number(p.prix)) / Number(p.prix)) * 100, 1) : null,
        ecoles_impactees: Number(concernees || 0),
        ecoles_au_tarif_negocie: Number(protegees || 0),
        impact_mrr: F.arrondi(deltaMrr),
        impact_arr: F.arrondi(deltaMrr * 12),
        note: 'Les écoles au tarif négocié conservent leur prix contractuel et ne sont pas comptées dans l\'impact.'
      };
    });

    return res.json(impact);
  } catch (err) {
    console.error('Erreur simulation prix:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/offres/:id/prix
 * body: { nouveau_prix, nouveau_prix_annuel?, raison, date_application?, confirmation: true }
 *
 * Le motif est OBLIGATOIRE. Un historique de prix sans motif répond à
 * « quand » et « combien », jamais à « pourquoi » — qui est la seule question
 * qu'on se pose six mois plus tard.
 */
async function changerPrix(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const nouveauPrix = F.nombrePositif(b.nouveau_prix);
  if (nouveauPrix === null) return res.status(400).json({ message: 'nouveau_prix est requis et doit être positif.' });

  const raison = F.texte(b.raison, 500);
  if (!raison) return res.status(400).json({ message: 'Un motif est requis pour tout changement de prix.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const plan = await client.query('SELECT * FROM plans_abonnement WHERE id = $1 FOR UPDATE', [id]);
      if (!plan.rows.length) throw Object.assign(new Error('Offre introuvable.'), { statusCode: 404 });
      const p = plan.rows[0];

      const nouveauAnnuel = 'nouveau_prix_annuel' in b ? F.nombrePositif(b.nouveau_prix_annuel) : p.prix_annuel;

      // Le prix semestriel suit le même chemin que l'annuel.
      //
      // Sans cette ligne, changer le prix mensuel d'une offre laissait son
      // tarif semestriel figé à l'ancienne valeur : le site public affichait
      // alors une « économie » calculée sur deux grilles différentes, parfois
      // supérieure au prix lui-même. Une remise fausse est pire qu'une remise
      // absente — elle se découvre à la facture.
      const nouveauSemestriel = 'nouveau_prix_semestriel' in b
        ? F.nombrePositif(b.nouveau_prix_semestriel) : p.prix_semestriel;

      const concernees = await mesurer(client, `
        SELECT count(*) FROM abonnements a
         WHERE a.plan_id = $1 AND a.statut = 'actif' AND a.prix_applique IS NULL
           AND NOT EXISTS (SELECT 1 FROM tarifs_personnalises t
                            WHERE t.ecole_id = a.ecole_id AND t.statut = 'actif')`, [id], 0);

      const deltaMrr = (F.mensualiser(nouveauPrix, p.duree_jours) - F.mensualiser(p.prix, p.duree_jours))
                     * Number(concernees || 0);

      // Les deux colonnes de prix semestriel sont ajoutées par la migration 029.
      // Sans elles, la trace dirait « Infinite : 199 → 159 » sans mentionner que
      // le semestriel est passé de 1 110 à 875, soit la plus grosse variation en
      // valeur absolue — et l'historique servirait alors surtout à rassurer.
      await client.query(
        `INSERT INTO plan_prix_historique
           (plan_id, ancien_prix, nouveau_prix,
            ancien_prix_semestriel, nouveau_prix_semestriel,
            ancien_prix_annuel, nouveau_prix_annuel,
            devise, raison, date_application, ecoles_impactees, impact_mrr_estime, modifie_par)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
        [id, p.prix, nouveauPrix,
         p.prix_semestriel, nouveauSemestriel,
         p.prix_annuel, nouveauAnnuel, p.devise, raison,
         F.dateIso(b.date_application) || new Date().toISOString().slice(0, 10),
         Number(concernees || 0), F.arrondi(deltaMrr), req.auth.userId]
      );

      const maj = await client.query(
        `UPDATE plans_abonnement
            SET prix = $2, prix_annuel = $3, prix_semestriel = $5, updated_by = $4
          WHERE id = $1 RETURNING *`,
        [id, nouveauPrix, nouveauAnnuel, req.auth.userId, nouveauSemestriel]
      );

      await F.journaliser(client, req, {
        action: 'prix.modifie', entite: 'plans_abonnement', entiteId: id,
        libelle: p.nom,
        ancienneValeur: { prix: Number(p.prix), prix_semestriel: p.prix_semestriel,
                          prix_annuel: p.prix_annuel },
        nouvelleValeur: { prix: nouveauPrix, prix_semestriel: nouveauSemestriel,
                          prix_annuel: nouveauAnnuel },
        montant: nouveauPrix, devise: p.devise, raison
      });

      return {
        offre: maj.rows[0],
        ancien_prix: Number(p.prix),
        nouveau_prix: nouveauPrix,
        ecoles_impactees: Number(concernees || 0),
        impact_mrr: F.arrondi(deltaMrr)
      };
    });

    invaliderCaches();
    return res.json({
      message: `Prix mis à jour. ${resultat.ecoles_impactees} école(s) concernée(s) au prochain renouvellement.`,
      ...resultat
    });
  } catch (err) {
    console.error('Erreur changement de prix:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/** GET /super-admin/offres/:id/historique-prix */
async function historiquePrix(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, `
      SELECT h.*, trim(concat_ws(' ', u.prenom, u.nom)) AS modifie_par_nom
        FROM plan_prix_historique h
        LEFT JOIN utilisateurs u ON u.id = h.modifie_par
       WHERE h.plan_id = $1
       ORDER BY h.created_at DESC`, [req.params.id]));
    return res.json({ donnees });
  } catch (err) {
    console.error('Erreur historique prix:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/offres/:id/statut
 * body: { statut: 'actif'|'inactif'|'archive', raison?, confirmation: true }
 *
 * Archiver une offre encore souscrite est refusé. Ce n'est pas de la
 * prudence excessive : le plan reste la source du prix facturé, et une offre
 * archivée disparaît des écrans de choix. On se retrouverait avec des écoles
 * rattachées à une offre que plus personne ne voit — invisible dans les
 * grilles, bien présente dans les factures.
 */
async function changerStatutOffre(req, res) {
  const { id } = req.params;
  const b = req.body || {};
  const statut = ['actif', 'inactif', 'archive'].includes(b.statut) ? b.statut : null;
  if (!statut) return res.status(400).json({ message: 'statut doit valoir actif, inactif ou archive.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const plan = await client.query('SELECT * FROM plans_abonnement WHERE id = $1', [id]);
      if (!plan.rows.length) throw Object.assign(new Error('Offre introuvable.'), { statusCode: 404 });

      if (statut === 'archive') {
        const actifs = await mesurer(client,
          `SELECT count(*) FROM abonnements WHERE plan_id = $1 AND statut = 'actif'`, [id], 0);
        if (Number(actifs) > 0) {
          throw Object.assign(
            new Error(`Impossible d'archiver : ${actifs} école(s) sont encore abonnées à cette offre. `
                    + `Migrez-les vers une autre offre, ou désactivez celle-ci (elle disparaît des nouvelles souscriptions sans toucher aux abonnements en cours).`),
            { statusCode: 409 }
          );
        }
      }

      const r = await client.query(
        `UPDATE plans_abonnement
            SET statut = $2,
                archive_at  = CASE WHEN $2 = 'archive' THEN now() ELSE NULL END,
                archive_par = CASE WHEN $2 = 'archive' THEN $3::uuid ELSE NULL END,
                updated_by = $3
          WHERE id = $1 RETURNING *`,
        [id, statut, req.auth.userId]
      );

      await F.journaliser(client, req, {
        action: `offre.${statut === 'archive' ? 'archivee' : statut === 'actif' ? 'reactivee' : 'desactivee'}`,
        entite: 'plans_abonnement', entiteId: id, libelle: plan.rows[0].nom,
        ancienneValeur: { statut: plan.rows[0].statut || 'actif' }, nouvelleValeur: { statut },
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Statut de l\'offre mis à jour.', offre: resultat });
  } catch (err) {
    console.error('Erreur statut offre:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   2. PROMOTIONS
   ========================================================================== */

/** GET /super-admin/promotions */
async function listerPromotions(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { statut, recherche } = req.query;

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`p.statut = $${params.length}`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(p.nom ILIKE $${params.length} OR p.code ILIKE $${params.length})`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client,
        `SELECT count(*) FROM promotions_commerciales p ${filtre}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT p.*,
               trim(concat_ws(' ', u.prenom, u.nom)) AS cree_par_nom,
               (p.date_fin IS NOT NULL AND p.date_fin < current_date) AS echue,
               (p.max_utilisations IS NOT NULL AND p.nb_utilisations >= p.max_utilisations) AS epuisee
          FROM promotions_commerciales p
          LEFT JOIN utilisateurs u ON u.id = p.created_by
          ${filtre}
         ORDER BY p.created_at DESC
         LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      return { total, donnees };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees));
  } catch (err) {
    console.error('Erreur liste promotions:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/promotions */
async function creerPromotion(req, res) {
  const b = req.body || {};
  const nom = F.texte(b.nom, 120);
  if (!nom) return res.status(400).json({ message: 'Le nom de la promotion est requis.' });

  const type = ['pourcentage', 'montant_fixe', 'mois_offerts'].includes(b.type_reduction)
    ? b.type_reduction : 'pourcentage';
  const valeur = F.nombrePositif(b.valeur);
  if (valeur === null) return res.status(400).json({ message: 'La valeur de la réduction est requise.' });
  if (type === 'pourcentage' && valeur > 100) {
    return res.status(400).json({ message: 'Une réduction en pourcentage ne peut pas dépasser 100 %.' });
  }

  const debut = F.dateIso(b.date_debut);
  const fin = F.dateIso(b.date_fin);
  if (debut && fin && fin < debut) {
    return res.status(400).json({ message: 'La date de fin précède la date de début.' });
  }

  try {
    const promo = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO promotions_commerciales
           (nom, code, description, type_reduction, valeur, devise, duree_mois,
            date_debut, date_fin, plans_concernes, ecoles_concernees, cible,
            max_utilisations, statut, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::uuid[],$11::uuid[],$12,$13,$14,$15)
         RETURNING *`,
        [
          nom,
          F.texte(b.code, 40) ? F.texte(b.code, 40).toUpperCase() : null,
          F.texte(b.description, 1000),
          type, valeur,
          F.texte(b.devise, 8),
          F.entier(b.duree_mois, 1, 120),
          debut, fin,
          F.listeUuid(b.plans_concernes),
          F.listeUuid(b.ecoles_concernees),
          ['tous', 'nouveaux', 'anciens'].includes(b.cible) ? b.cible : 'tous',
          F.entier(b.max_utilisations, 1, 1000000),
          ['active', 'inactive'].includes(b.statut) ? b.statut : 'active',
          req.auth.userId
        ]
      );

      await F.journaliser(client, req, {
        action: 'promotion.creee', entite: 'promotions_commerciales', entiteId: r.rows[0].id,
        libelle: `${nom}${r.rows[0].code ? ' (' + r.rows[0].code + ')' : ''}`,
        nouvelleValeur: { type_reduction: type, valeur, duree_mois: r.rows[0].duree_mois, cible: r.rows[0].cible },
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Promotion créée.', promotion: promo });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ message: 'Ce code promo existe déjà.' });
    console.error('Erreur création promotion:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/promotions/:id */
async function modifierPromotion(req, res) {
  const { id } = req.params;
  const b = req.body || {};

  const colonnes = [];
  const params = [];
  const modifications = {};

  const champs = {
    nom: (v) => F.texte(v, 120),
    description: (v) => F.texte(v, 1000),
    valeur: (v) => F.nombrePositif(v),
    duree_mois: (v) => F.entier(v, 1, 120),
    date_debut: (v) => F.dateIso(v),
    date_fin: (v) => F.dateIso(v),
    max_utilisations: (v) => F.entier(v, 1, 1000000)
  };

  for (const [champ, nettoyer] of Object.entries(champs)) {
    if (!(champ in b)) continue;
    const valeur = nettoyer(b[champ]);
    params.push(valeur);
    colonnes.push(`${champ} = $${params.length}`);
    modifications[champ] = valeur;
  }

  if ('statut' in b && ['active', 'inactive', 'expiree', 'archivee'].includes(b.statut)) {
    params.push(b.statut);
    colonnes.push(`statut = $${params.length}`);
    modifications.statut = b.statut;
  }
  if ('cible' in b && ['tous', 'nouveaux', 'anciens'].includes(b.cible)) {
    params.push(b.cible);
    colonnes.push(`cible = $${params.length}`);
    modifications.cible = b.cible;
  }
  for (const champ of ['plans_concernes', 'ecoles_concernees']) {
    if (!(champ in b)) continue;
    params.push(F.listeUuid(b[champ]));
    colonnes.push(`${champ} = $${params.length}::uuid[]`);
    modifications[champ] = F.listeUuid(b[champ]);
  }

  if (!colonnes.length) return res.status(400).json({ message: 'Aucune modification transmise.' });
  params.push(id);

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM promotions_commerciales WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Promotion introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE promotions_commerciales SET ${colonnes.join(', ')} WHERE id = $${params.length} RETURNING *`,
        params
      );

      const ancien = {};
      for (const cle of Object.keys(modifications)) ancien[cle] = avant.rows[0][cle];

      await F.journaliser(client, req, {
        action: 'promotion.modifiee', entite: 'promotions_commerciales', entiteId: id,
        libelle: r.rows[0].nom, ancienneValeur: ancien, nouvelleValeur: modifications,
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Promotion mise à jour.', promotion: resultat });
  } catch (err) {
    console.error('Erreur modification promotion:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   3. OFFRES SPÉCIALES
   ========================================================================== */

/** GET /super-admin/offres-speciales */
async function listerOffresSpeciales(req, res) {
  const { statut, ecole_id } = req.query;
  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`o.statut = $${params.length}`); }
  if (ecole_id) { params.push(ecole_id); conditions.push(`o.ecole_id = $${params.length}::uuid`); }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, `
      SELECT o.*, e.nom AS ecole_nom, p.nom AS plan_nom,
             trim(concat_ws(' ', u.prenom, u.nom)) AS cree_par_nom,
             (o.date_fin IS NOT NULL AND o.date_fin < current_date) AS echue
        FROM offres_speciales o
        LEFT JOIN ecoles e ON e.id = o.ecole_id
        LEFT JOIN plans_abonnement p ON p.id = o.plan_id
        LEFT JOIN utilisateurs u ON u.id = o.created_by
        ${filtre}
       ORDER BY o.created_at DESC
       LIMIT 300`, params));
    return res.json({ donnees });
  } catch (err) {
    console.error('Erreur liste offres spéciales:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

const TYPES_OFFRE_SPECIALE = [
  'premier_mois_gratuit', 'mois_reduits', 'reduction_annuelle', 'lancement',
  'ecole_specifique', 'partenaire', 'exceptionnelle', 'autre'
];

/** POST /super-admin/offres-speciales */
async function creerOffreSpeciale(req, res) {
  const b = req.body || {};
  const nom = F.texte(b.nom, 120);
  if (!nom) return res.status(400).json({ message: 'Le nom de l\'offre spéciale est requis.' });

  const type = TYPES_OFFRE_SPECIALE.includes(b.type_offre) ? b.type_offre : 'exceptionnelle';
  const debut = F.dateIso(b.date_debut);
  const fin = F.dateIso(b.date_fin);
  if (debut && fin && fin < debut) {
    return res.status(400).json({ message: 'La date de fin précède la date de début.' });
  }

  try {
    const offre = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO offres_speciales
           (nom, type_offre, description, valeur, unite, duree_mois, plan_id, ecole_id,
            date_debut, date_fin, conditions, statut, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12,$13)
         RETURNING *`,
        [nom, type, F.texte(b.description, 1000), F.nombrePositif(b.valeur),
         F.texte(b.unite, 24), F.entier(b.duree_mois, 1, 120),
         b.plan_id || null, b.ecole_id || null, debut, fin,
         JSON.stringify(b.conditions && typeof b.conditions === 'object' ? b.conditions : {}),
         ['active', 'inactive'].includes(b.statut) ? b.statut : 'active',
         req.auth.userId]
      );

      await F.journaliser(client, req, {
        action: 'offre_speciale.creee', entite: 'offres_speciales', entiteId: r.rows[0].id,
        libelle: nom, nouvelleValeur: { type_offre: type, valeur: r.rows[0].valeur, duree_mois: r.rows[0].duree_mois },
        ecoleId: b.ecole_id || null, raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.status(201).json({ message: 'Offre spéciale créée.', offre });
  } catch (err) {
    console.error('Erreur création offre spéciale:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/offres-speciales/:id */
async function modifierOffreSpeciale(req, res) {
  const { id } = req.params;
  const b = req.body || {};
  const statut = ['active', 'inactive', 'expiree', 'archivee'].includes(b.statut) ? b.statut : null;
  const nom = 'nom' in b ? F.texte(b.nom, 120) : undefined;
  const fin = 'date_fin' in b ? F.dateIso(b.date_fin) : undefined;

  if (!statut && nom === undefined && fin === undefined) {
    return res.status(400).json({ message: 'Aucune modification transmise.' });
  }

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query('SELECT * FROM offres_speciales WHERE id = $1', [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Offre spéciale introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE offres_speciales
            SET statut = COALESCE($2, statut),
                nom = COALESCE($3, nom),
                date_fin = CASE WHEN $4::boolean THEN $5::date ELSE date_fin END
          WHERE id = $1 RETURNING *`,
        [id, statut, nom === undefined ? null : nom, fin !== undefined, fin || null]
      );

      await F.journaliser(client, req, {
        action: 'offre_speciale.modifiee', entite: 'offres_speciales', entiteId: id,
        libelle: r.rows[0].nom,
        ancienneValeur: { statut: avant.rows[0].statut, date_fin: avant.rows[0].date_fin },
        nouvelleValeur: { statut: r.rows[0].statut, date_fin: r.rows[0].date_fin },
        raison: F.texte(b.raison, 500)
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Offre spéciale mise à jour.', offre: resultat });
  } catch (err) {
    console.error('Erreur modification offre spéciale:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. TARIFICATION PERSONNALISÉE
   ========================================================================== */

/** GET /super-admin/tarifs-personnalises */
async function listerTarifsPersonnalises(req, res) {
  const { statut, ecole_id } = req.query;
  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`t.statut = $${params.length}`); }
  if (ecole_id) { params.push(ecole_id); conditions.push(`t.ecole_id = $${params.length}::uuid`); }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, `
      SELECT t.*, e.nom AS ecole_nom, e.code AS ecole_code, p.nom AS plan_nom,
             trim(concat_ws(' ', u.prenom, u.nom)) AS accorde_par_nom,
             CASE WHEN t.prix_catalogue > 0
                  THEN round(((t.prix_catalogue - t.prix_personnalise) / t.prix_catalogue) * 100, 1)
             END AS remise_pourcentage,
             (t.prix_catalogue - t.prix_personnalise) AS remise_montant
        FROM tarifs_personnalises t
        JOIN ecoles e ON e.id = t.ecole_id
        LEFT JOIN plans_abonnement p ON p.id = t.plan_id
        LEFT JOIN utilisateurs u ON u.id = t.accorde_par
        ${filtre}
       ORDER BY t.created_at DESC
       LIMIT 300`, params));
    return res.json({ donnees });
  } catch (err) {
    console.error('Erreur liste tarifs personnalisés:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/tarifs-personnalises
 * body: { ecole_id, prix_personnalise, raison, plan_id?, date_debut?, date_fin?, confirmation: true }
 *
 * Le prix catalogue n'est PAS transmis par le client : il est relu en base au
 * moment de l'écriture. Un client qui l'enverrait pourrait, par erreur ou par
 * rejeu d'un vieux formulaire, figer une remise calculée sur un prix qui n'a
 * plus cours.
 */
async function creerTarifPersonnalise(req, res) {
  const b = req.body || {};
  if (!b.ecole_id) return res.status(400).json({ message: 'ecole_id est requis.' });

  const prix = F.nombrePositif(b.prix_personnalise);
  if (prix === null) return res.status(400).json({ message: 'prix_personnalise est requis et doit être positif ou nul.' });

  const raison = F.texte(b.raison, 500);
  if (!raison) return res.status(400).json({ message: 'Un motif est requis pour accorder un tarif négocié.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const ecole = await client.query('SELECT id, nom FROM ecoles WHERE id = $1', [b.ecole_id]);
      if (!ecole.rows.length) throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });

      // Abonnement courant de l'école → prix catalogue de référence.
      const abo = await client.query(
        `SELECT a.id, a.plan_id, p.prix, p.devise, p.nom AS plan_nom, p.duree_jours
           FROM abonnements a
           JOIN plans_abonnement p ON p.id = a.plan_id
          WHERE a.ecole_id = $1
          ORDER BY a.created_at DESC LIMIT 1`, [b.ecole_id]);

      const planId = b.plan_id || (abo.rows[0] ? abo.rows[0].plan_id : null);
      const prixCatalogue = abo.rows[0] ? Number(abo.rows[0].prix) : null;
      const devise = abo.rows[0] ? abo.rows[0].devise : F.texte(b.devise, 8);

      // Un tarif actif existant est TERMINÉ, pas écrasé : l'index unique
      // partiel l'interdirait de toute façon, mais surtout l'ancien tarif est
      // une pièce du dossier commercial de cette école.
      await client.query(
        `UPDATE tarifs_personnalises
            SET statut = 'termine', termine_par = $2, termine_at = now()
          WHERE ecole_id = $1 AND statut = 'actif'`,
        [b.ecole_id, req.auth.userId]
      );

      const r = await client.query(
        `INSERT INTO tarifs_personnalises
           (ecole_id, plan_id, prix_catalogue, prix_personnalise, devise, periodicite,
            raison, date_debut, date_fin, accorde_par)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
         RETURNING *`,
        [b.ecole_id, planId, prixCatalogue, prix, devise,
         ['mensuel', 'annuel', 'trimestriel'].includes(b.periodicite) ? b.periodicite : 'mensuel',
         raison,
         F.dateIso(b.date_debut) || new Date().toISOString().slice(0, 10),
         F.dateIso(b.date_fin),
         req.auth.userId]
      );

      // L'abonnement courant porte le prix appliqué : c'est lui que lisent le
      // calcul du MRR et l'écran « prix payé ».
      if (abo.rows[0]) {
        await client.query(
          `UPDATE abonnements
              SET prix_applique = $2, devise_appliquee = $3, tarif_personnalise_id = $4, updated_at = now()
            WHERE id = $1`,
          [abo.rows[0].id, prix, devise, r.rows[0].id]
        );
      }

      await F.journaliser(client, req, {
        action: 'tarif_personnalise.accorde', entite: 'tarifs_personnalises', entiteId: r.rows[0].id,
        libelle: ecole.rows[0].nom,
        ancienneValeur: { prix: prixCatalogue },
        nouvelleValeur: { prix: prix },
        montant: prix, devise, raison, ecoleId: b.ecole_id
      });

      return { tarif: r.rows[0], ecole_nom: ecole.rows[0].nom, abonnement_mis_a_jour: !!abo.rows[0] };
    });

    invaliderCaches();
    return res.status(201).json({
      message: resultat.abonnement_mis_a_jour
        ? 'Tarif négocié appliqué et abonnement mis à jour.'
        : "Tarif négocié enregistré. L'école n'a pas encore d'abonnement : il s'appliquera à la souscription.",
      ...resultat
    });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Cette école a déjà un tarif négocié actif.' });
    }
    console.error('Erreur tarif personnalisé:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/** POST /super-admin/tarifs-personnalises/:id/terminer */
async function terminerTarifPersonnalise(req, res) {
  const { id } = req.params;
  const raison = F.texte((req.body || {}).raison, 500);

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const avant = await client.query(
        `SELECT t.*, e.nom AS ecole_nom FROM tarifs_personnalises t
          JOIN ecoles e ON e.id = t.ecole_id WHERE t.id = $1`, [id]);
      if (!avant.rows.length) throw Object.assign(new Error('Tarif introuvable.'), { statusCode: 404 });

      const r = await client.query(
        `UPDATE tarifs_personnalises
            SET statut = 'termine', termine_par = $2, termine_at = now()
          WHERE id = $1 AND statut = 'actif' RETURNING *`,
        [id, req.auth.userId]);

      if (!r.rows.length) throw Object.assign(new Error('Ce tarif n\'est plus actif.'), { statusCode: 409 });

      // Retour au prix catalogue : on efface le prix appliqué, qui redevient
      // celui du plan.
      await client.query(
        `UPDATE abonnements
            SET prix_applique = NULL, devise_appliquee = NULL,
                tarif_personnalise_id = NULL, updated_at = now()
          WHERE tarif_personnalise_id = $1`, [id]);

      await F.journaliser(client, req, {
        action: 'tarif_personnalise.termine', entite: 'tarifs_personnalises', entiteId: id,
        libelle: avant.rows[0].ecole_nom,
        ancienneValeur: { prix: Number(avant.rows[0].prix_personnalise) },
        nouvelleValeur: { prix: avant.rows[0].prix_catalogue },
        raison, ecoleId: avant.rows[0].ecole_id
      });

      return r.rows[0];
    });

    invaliderCaches();
    return res.json({ message: 'Tarif négocié terminé. L\'école revient au prix catalogue.', tarif: resultat });
  } catch (err) {
    console.error('Erreur fin de tarif personnalisé:', err);
    return res.status(err.statusCode || 500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. ABONNEMENTS CLIENTS — prix catalogue vs prix réellement payé
   ========================================================================== */

/**
 * GET /super-admin/abonnements-detail
 *
 * Complète — et ne remplace pas — `/super-admin/abonnements`, qui reste tel
 * quel et continue d'alimenter l'écran existant. Cette vue-ci ajoute les
 * colonnes commerciales que l'autre n'a pas : prix théorique, prix réel,
 * remise, revenu encaissé, dernier paiement.
 */
async function abonnementsDetail(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { statut, plan_id, recherche, avec_remise } = req.query;

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`a.statut = $${params.length}`); }
  if (plan_id) { params.push(plan_id); conditions.push(`a.plan_id = $${params.length}::uuid`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(e.nom ILIKE $${params.length} OR e.code ILIKE $${params.length})`);
  }
  if (String(avec_remise || '') === 'oui') {
    conditions.push(`(t.id IS NOT NULL OR a.prix_applique IS NOT NULL)`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const conv = await F.convertisseur(client, await deviseReference(client));

      const base = `
        FROM abonnements a
        JOIN ecoles e ON e.id = a.ecole_id
        LEFT JOIN plans_abonnement p ON p.id = a.plan_id
        LEFT JOIN tarifs_personnalises t ON t.ecole_id = a.ecole_id AND t.statut = 'actif'
        ${filtre}`;

      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT a.id, a.statut, a.date_debut, a.date_expiration, a.en_periode_essai,
               a.periodicite,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code, e.statut AS ecole_statut,
               p.id AS plan_id, p.nom AS plan_nom, p.prix AS prix_catalogue,
               p.devise, p.duree_jours,
               COALESCE(t.prix_personnalise, a.prix_applique, p.prix) AS prix_paye,
               t.id AS tarif_personnalise_id, t.raison AS raison_remise,
               (a.date_expiration::date - current_date) AS jours_restants,
               (SELECT count(*) FROM eleves x WHERE x.ecole_id = e.id AND x.statut = 'actif') AS nb_eleves,
               (SELECT COALESCE(sum(pa.montant),0) FROM paiements pa
                 WHERE pa.ecole_id = e.id AND pa.statut = 'confirme')     AS revenu_cumule,
               (SELECT max(pa.date_paiement) FROM paiements pa
                 WHERE pa.ecole_id = e.id AND pa.statut = 'confirme')     AS dernier_paiement
        ${base}
        ORDER BY a.date_expiration ASC NULLS LAST
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      let totalCatalogue = 0;
      let totalPaye = 0;

      const enrichies = donnees.map((l) => {
        const catalogue = F.mensualiser(l.prix_catalogue, l.duree_jours);
        const paye = l.periodicite && l.periodicite !== 'mensuel'
          ? F.mensualiserPeriodicite(l.prix_paye, l.periodicite)
          : F.mensualiser(l.prix_paye, l.duree_jours);

        if (l.statut === 'actif') {
          totalCatalogue += conv.convertir(catalogue, l.devise);
          totalPaye += conv.convertir(paye, l.devise);
        }

        return {
          ...l,
          prix_catalogue_mensuel: F.arrondi(catalogue),
          prix_paye_mensuel: F.arrondi(paye),
          remise_mensuelle: F.arrondi(catalogue - paye),
          remise_pourcentage: catalogue > 0 ? F.arrondi(((catalogue - paye) / catalogue) * 100, 1) : null
        };
      });

      return {
        total, donnees: enrichies,
        synthese: {
          devise_reference: conv.reference,
          mrr_catalogue: F.arrondi(totalCatalogue),
          mrr_reel: F.arrondi(totalPaye),
          remises_mensuelles: F.arrondi(totalCatalogue - totalPaye),
          taux_remise: totalCatalogue > 0 ? F.arrondi(((totalCatalogue - totalPaye) / totalCatalogue) * 100, 1) : 0,
          note_page: 'La synthèse porte sur les abonnements actifs de la page affichée.'
        }
      };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      synthese: resultat.synthese
    }));
  } catch (err) {
    console.error('Erreur abonnements détaillés:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  listerOffres, creerOffre, modifierOffre,
  simulerChangementPrix, changerPrix, historiquePrix, changerStatutOffre,
  listerPromotions, creerPromotion, modifierPromotion,
  listerOffresSpeciales, creerOffreSpeciale, modifierOffreSpeciale,
  listerTarifsPersonnalises, creerTarifPersonnalise, terminerTarifPersonnalise,
  abonnementsDetail,
  deviseReference, reglage
};
