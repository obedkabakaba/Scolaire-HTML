const crypto = require('crypto');
const XLSX = require('xlsx');
const { runWithTenant } = require('../config/db');
const { envoyerEmail } = require('../utils/email.utils');
const { emailWrapper } = require('../utils/email-template');
const {
  mesurer, lignes, pagination, reponsePaginee, motifRecherche
} = require('../utils/super-admin.utils');

/*
 * Bugs, tickets de support, notifications système, exports.
 * ---------------------------------------------------------------------------
 * Contrairement au reste de l'espace, ce fichier écrit — mais uniquement dans
 * les tables de supervision créées par la migration 020. Aucune table
 * pédagogique n'y apparaît.
 */

const SUPER = { isSuperAdmin: true };

/* ==========================================================================
   1. Centre de bugs
   ========================================================================== */

const GRAVITES = ['basse', 'moyenne', 'haute', 'critique'];
const STATUTS_BUG = ['ouvert', 'en_cours', 'resolu', 'ignore'];

/**
 * Empreinte de regroupement : message + page, normalisés.
 *
 * Les identifiants, nombres et adresses sont neutralisés avant hachage. Sans
 * cela, « Élève 8c1f-… introuvable » et « Élève 4b2a-… introuvable » seraient
 * deux bugs distincts, alors que c'est manifestement le même défaut. Le centre
 * afficherait des centaines de lignes au lieu d'une seule à 300 occurrences.
 */
function empreinteBug({ message, page, origine }) {
  const normalise = String(message || '')
    .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, ':id')
    .replace(/\d+/g, ':n')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 300)
    .toLowerCase();

  const contexte = String(page || '')
    .split('?')[0]
    .replace(/[0-9a-f-]{20,}/gi, ':id')
    .toLowerCase();

  return crypto.createHash('sha256')
    .update(`${origine || 'frontend'}|${contexte}|${normalise}`)
    .digest('hex')
    .slice(0, 40);
}

/**
 * POST /super-admin/bugs/signaler  (aussi utilisable par le front applicatif)
 * body: { message, stack?, page?, navigateur?, systeme?, gravite?, ecole_id?, origine? }
 *
 * Idempotent par empreinte : la même erreur incrémente un compteur au lieu de
 * créer une ligne. `ON CONFLICT` fait ce travail en base, ce qui évite la
 * course entre deux signalements simultanés du même défaut.
 */
async function signalerBug(req, res) {
  const {
    message, stack, page, navigateur, systeme, gravite, origine,
    methode, chemin, code_http, metadata
  } = req.body || {};

  if (!message || !String(message).trim()) {
    return res.status(400).json({ message: 'Le message d\'erreur est requis.' });
  }

  const graviteRetenue = GRAVITES.includes(gravite) ? gravite : 'moyenne';

  /* L'ÉCOLE NE VIENT PLUS DU CORPS DE REQUÊTE — SAUF POUR LE SUPER ADMIN.

     La version précédente lisait `req.body.ecole_id` EN PREMIER, avec repli
     sur le jeton. N'importe quel appelant pouvait donc déposer un incident au
     nom de l'école de son choix, et polluer le dossier de supervision d'un
     concurrent ou d'un client mécontent. Le fait que la route soit aujourd'hui
     réservée au Super Admin limitait la portée du défaut, mais son commentaire
     affirmait qu'elle était ouverte au front applicatif : le jour où quelqu'un
     l'aurait effectivement ouverte, l'usurpation serait devenue accessible à
     tout utilisateur authentifié.

     Le Super Admin, lui, n'appartient à aucune école et a une raison
     légitime de rattacher un incident qu'il observe à l'établissement
     concerné. C'est la SEULE dérogation, et elle est explicite.

     Les utilisateurs ordinaires passent désormais par `POST /incidents/signaler`
     (routes/incidents.routes.js), où l'école est lue du jeton et rien d'autre. */
  const ecoleId = req.auth?.isSuperAdmin
    ? (req.body?.ecole_id || null)
    : (req.auth?.ecoleId || null);

  const empreinte = empreinteBug({ message, page, origine });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(`
        INSERT INTO bugs_plateforme
          (ecole_id, utilisateur_id, empreinte, origine, page, methode, chemin, code_http,
           navigateur, systeme, message, stack, gravite, metadata)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14::jsonb)
        ON CONFLICT (empreinte) DO UPDATE SET
          occurrences = bugs_plateforme.occurrences + 1,
          derniere_occurrence = now(),
          -- Un bug marqué résolu qui réapparaît doit rouvrir : le masquer
          -- reviendrait à perdre l'information la plus utile du centre.
          statut = CASE WHEN bugs_plateforme.statut IN ('resolu','ignore')
                        THEN 'ouvert' ELSE bugs_plateforme.statut END
        RETURNING id, occurrences, statut`,
        [ecoleId, req.auth?.userId || null, empreinte, origine || 'frontend',
         page || null, methode || null, chemin || null, code_http || null,
         navigateur || req.headers['user-agent'] || null, systeme || null,
         String(message).slice(0, 2000), stack ? String(stack).slice(0, 8000) : null,
         graviteRetenue, JSON.stringify(metadata || {})]);
      return r.rows[0];
    });

    return res.status(201).json({ message: 'Signalement enregistré.', ...resultat });
  } catch (err) {
    // Un échec d'enregistrement de bug ne doit jamais casser le flux appelant.
    console.error('Erreur signalement bug:', err);
    return res.status(202).json({ message: 'Signalement non enregistré.', enregistre: false });
  }
}

/** GET /super-admin/bugs */
async function listerBugs(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { statut, gravite, ecole_id, origine, recherche } = req.query;

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`b.statut = $${params.length}`); }
  if (gravite) { params.push(gravite); conditions.push(`b.gravite = $${params.length}`); }
  if (origine) { params.push(origine); conditions.push(`b.origine = $${params.length}`); }
  if (ecole_id) { params.push(ecole_id); conditions.push(`b.ecole_id = $${params.length}::uuid`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    const p = `$${params.length}`;
    conditions.push(`(b.message ILIKE ${p} OR COALESCE(b.page,'') ILIKE ${p} OR COALESCE(b.stack,'') ILIKE ${p})`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const base = `FROM bugs_plateforme b
                    LEFT JOIN ecoles e ON e.id = b.ecole_id
                    LEFT JOIN utilisateurs u ON u.id = b.utilisateur_id ${filtre}`;
      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT b.id, b.origine, b.page, b.methode, b.chemin, b.code_http,
               b.navigateur, b.systeme, b.message, b.gravite, b.statut, b.occurrences,
               b.premiere_occurrence, b.derniere_occurrence,
               e.nom AS ecole_nom, trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur,
               (SELECT count(*) FROM bugs_commentaires c WHERE c.bug_id = b.id) AS nb_commentaires
        ${base}
        ORDER BY
          CASE b.gravite WHEN 'critique' THEN 0 WHEN 'haute' THEN 1
                         WHEN 'moyenne' THEN 2 ELSE 3 END,
          b.derniere_occurrence DESC
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      const stats = await lignes(client, `
        SELECT count(*) FILTER (WHERE statut = 'ouvert') AS ouverts,
               count(*) FILTER (WHERE statut = 'en_cours') AS en_cours,
               count(*) FILTER (WHERE statut = 'resolu') AS resolus,
               count(*) FILTER (WHERE gravite = 'critique' AND statut <> 'resolu') AS critiques,
               COALESCE(sum(occurrences), 0) AS occurrences_totales
        FROM bugs_plateforme`);

      return { total, donnees, stats: stats[0] || {} };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      statistiques: resultat.stats
    }));
  } catch (err) {
    console.error('Erreur liste bugs:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/bugs/:id */
async function detailBug(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const bug = await lignes(client, `
        SELECT b.*, e.nom AS ecole_nom, e.code AS ecole_code,
               trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur, u.email AS utilisateur_email
        FROM bugs_plateforme b
        LEFT JOIN ecoles e ON e.id = b.ecole_id
        LEFT JOIN utilisateurs u ON u.id = b.utilisateur_id
        WHERE b.id = $1`, [id]);

      if (!bug.length) throw Object.assign(new Error('Bug introuvable.'), { statusCode: 404 });

      const commentaires = await lignes(client, `
        SELECT c.id, c.contenu, c.created_at,
               trim(concat_ws(' ', u.prenom, u.nom)) AS auteur
        FROM bugs_commentaires c LEFT JOIN utilisateurs u ON u.id = c.auteur_id
        WHERE c.bug_id = $1 ORDER BY c.created_at ASC`, [id]);

      return { bug: bug[0], commentaires };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détail bug:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/bugs/:id  body: { statut?, gravite? } */
async function modifierBug(req, res) {
  const { id } = req.params;
  const { statut, gravite } = req.body || {};

  if (statut && !STATUTS_BUG.includes(statut)) {
    return res.status(400).json({ message: `Statut invalide. Valeurs : ${STATUTS_BUG.join(', ')}.` });
  }
  if (gravite && !GRAVITES.includes(gravite)) {
    return res.status(400).json({ message: `Gravité invalide. Valeurs : ${GRAVITES.join(', ')}.` });
  }

  try {
    await runWithTenant(SUPER, (client) =>
      client.query(`
        UPDATE bugs_plateforme SET
          statut = COALESCE($2, statut),
          gravite = COALESCE($3, gravite),
          resolu_par = CASE WHEN $2 = 'resolu' THEN $4 ELSE resolu_par END,
          resolu_at  = CASE WHEN $2 = 'resolu' THEN now() ELSE resolu_at END
        WHERE id = $1`, [id, statut || null, gravite || null, req.auth.userId])
    );
    return res.json({ message: 'Bug mis à jour.' });
  } catch (err) {
    console.error('Erreur modification bug:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/bugs/:id/commentaires  body: { contenu } */
async function commenterBug(req, res) {
  const { id } = req.params;
  const contenu = String(req.body?.contenu || '').trim();
  if (!contenu) return res.status(400).json({ message: 'Le commentaire est vide.' });

  try {
    const commentaire = await runWithTenant(SUPER, async (client) => {
      const r = await client.query(
        `INSERT INTO bugs_commentaires (bug_id, auteur_id, contenu)
         VALUES ($1, $2, $3) RETURNING id, contenu, created_at`,
        [id, req.auth.userId, contenu]);
      return r.rows[0];
    });
    return res.status(201).json(commentaire);
  } catch (err) {
    console.error('Erreur commentaire bug:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   2. Tickets de support
   ========================================================================== */

const PRIORITES = ['basse', 'normale', 'haute', 'urgente'];
const STATUTS_TICKET = ['ouvert', 'en_cours', 'attente_client', 'resolu', 'ferme'];

/** GET /super-admin/tickets */
async function listerTickets(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { statut, priorite, ecole_id, recherche } = req.query;

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`t.statut = $${params.length}`); }
  if (priorite) { params.push(priorite); conditions.push(`t.priorite = $${params.length}`); }
  if (ecole_id) { params.push(ecole_id); conditions.push(`t.ecole_id = $${params.length}::uuid`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    const p = `$${params.length}`;
    conditions.push(`(t.sujet ILIKE ${p} OR COALESCE(t.description,'') ILIKE ${p}
                      OR COALESCE(t.reference,'') ILIKE ${p} OR e.nom ILIKE ${p})`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const base = `FROM tickets_support t
                    LEFT JOIN ecoles e ON e.id = t.ecole_id
                    LEFT JOIN utilisateurs r ON r.id = t.responsable_id ${filtre}`;
      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT t.id, t.reference, t.sujet, t.categorie, t.priorite, t.statut,
               t.created_at, t.updated_at, t.ferme_at, t.premiere_reponse_at,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code,
               trim(concat_ws(' ', r.prenom, r.nom)) AS responsable,
               (SELECT count(*) FROM tickets_messages m WHERE m.ticket_id = t.id) AS nb_messages,
               EXTRACT(EPOCH FROM (now() - t.created_at))/3600 AS age_heures
        ${base}
        ORDER BY
          CASE t.statut WHEN 'ouvert' THEN 0 WHEN 'en_cours' THEN 1
                        WHEN 'attente_client' THEN 2 ELSE 3 END,
          CASE t.priorite WHEN 'urgente' THEN 0 WHEN 'haute' THEN 1
                          WHEN 'normale' THEN 2 ELSE 3 END,
          t.created_at DESC
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      const stats = await lignes(client, `
        SELECT count(*) FILTER (WHERE statut = 'ouvert') AS ouverts,
               count(*) FILTER (WHERE statut = 'en_cours') AS en_cours,
               count(*) FILTER (WHERE priorite = 'urgente' AND statut NOT IN ('resolu','ferme')) AS urgents,
               count(*) FILTER (WHERE statut IN ('resolu','ferme')) AS clos,
               round(avg(EXTRACT(EPOCH FROM (premiere_reponse_at - created_at))/3600)
                     FILTER (WHERE premiere_reponse_at IS NOT NULL)::numeric, 1) AS delai_reponse_moyen_h
        FROM tickets_support`);

      return { total, donnees, stats: stats[0] || {} };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      statistiques: resultat.stats
    }));
  } catch (err) {
    console.error('Erreur liste tickets:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/tickets/:id */
async function detailTicket(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const ticket = await lignes(client, `
        SELECT t.*, e.nom AS ecole_nom, e.code AS ecole_code, e.email AS ecole_email,
               trim(concat_ws(' ', o.prenom, o.nom)) AS ouvert_par_nom, o.email AS ouvert_par_email,
               trim(concat_ws(' ', r.prenom, r.nom)) AS responsable
        FROM tickets_support t
        LEFT JOIN ecoles e ON e.id = t.ecole_id
        LEFT JOIN utilisateurs o ON o.id = t.ouvert_par
        LEFT JOIN utilisateurs r ON r.id = t.responsable_id
        WHERE t.id = $1`, [id]);

      if (!ticket.length) throw Object.assign(new Error('Ticket introuvable.'), { statusCode: 404 });

      const messages = await lignes(client, `
        SELECT m.id, m.cote, m.contenu, m.created_at,
               trim(concat_ws(' ', u.prenom, u.nom)) AS auteur
        FROM tickets_messages m LEFT JOIN utilisateurs u ON u.id = m.auteur_id
        WHERE m.ticket_id = $1 ORDER BY m.created_at ASC`, [id]);

      return { ticket: ticket[0], messages };
    });
    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détail ticket:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/tickets */
async function creerTicket(req, res) {
  const { ecole_id, sujet, description, priorite, categorie } = req.body || {};
  if (!sujet || !String(sujet).trim()) {
    return res.status(400).json({ message: 'Le sujet est requis.' });
  }

  try {
    const ticket = await runWithTenant(SUPER, async (client) => {
      const numero = await client.query(`SELECT nextval('tickets_support_numero_seq') AS n`);
      const reference = `TCK-${new Date().getFullYear()}-${String(numero.rows[0].n).padStart(5, '0')}`;

      const r = await client.query(`
        INSERT INTO tickets_support
          (reference, ecole_id, ouvert_par, sujet, description, priorite, categorie, responsable_id)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        RETURNING id, reference, statut, created_at`,
        [reference, ecole_id || null, req.auth.userId, String(sujet).slice(0, 300),
         description || null, PRIORITES.includes(priorite) ? priorite : 'normale',
         categorie || 'autre', req.auth.userId]);
      return r.rows[0];
    });
    return res.status(201).json(ticket);
  } catch (err) {
    console.error('Erreur création ticket:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** PATCH /super-admin/tickets/:id  body: { statut?, priorite?, responsable_id? } */
async function modifierTicket(req, res) {
  const { id } = req.params;
  const { statut, priorite, responsable_id, categorie } = req.body || {};

  if (statut && !STATUTS_TICKET.includes(statut)) {
    return res.status(400).json({ message: `Statut invalide. Valeurs : ${STATUTS_TICKET.join(', ')}.` });
  }
  if (priorite && !PRIORITES.includes(priorite)) {
    return res.status(400).json({ message: `Priorité invalide. Valeurs : ${PRIORITES.join(', ')}.` });
  }

  try {
    await runWithTenant(SUPER, (client) =>
      client.query(`
        UPDATE tickets_support SET
          statut = COALESCE($2, statut),
          priorite = COALESCE($3, priorite),
          categorie = COALESCE($4, categorie),
          responsable_id = COALESCE($5::uuid, responsable_id),
          ferme_at = CASE WHEN $2 IN ('resolu','ferme') AND ferme_at IS NULL THEN now() ELSE ferme_at END,
          updated_at = now()
        WHERE id = $1`,
        [id, statut || null, priorite || null, categorie || null, responsable_id || null])
    );
    return res.json({ message: 'Ticket mis à jour.' });
  } catch (err) {
    console.error('Erreur modification ticket:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** POST /super-admin/tickets/:id/messages  body: { contenu, notifier? } */
async function repondreTicket(req, res) {
  const { id } = req.params;
  const contenu = String(req.body?.contenu || '').trim();
  if (!contenu) return res.status(400).json({ message: 'La réponse est vide.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const message = await client.query(`
        INSERT INTO tickets_messages (ticket_id, auteur_id, cote, contenu)
        VALUES ($1, $2, 'support', $3) RETURNING id, contenu, created_at`,
        [id, req.auth.userId, contenu]);

      // La date de première réponse ne se pose qu'une fois : elle sert à
      // mesurer le délai de prise en charge, qui n'aurait plus de sens s'il
      // était réécrit à chaque message.
      await client.query(`
        UPDATE tickets_support
        SET premiere_reponse_at = COALESCE(premiere_reponse_at, now()),
            statut = CASE WHEN statut = 'ouvert' THEN 'en_cours' ELSE statut END,
            updated_at = now()
        WHERE id = $1`, [id]);

      const contexte = await lignes(client, `
        SELECT t.reference, t.sujet, e.email AS ecole_email, e.nom AS ecole_nom,
               o.email AS demandeur_email
        FROM tickets_support t
        LEFT JOIN ecoles e ON e.id = t.ecole_id
        LEFT JOIN utilisateurs o ON o.id = t.ouvert_par
        WHERE t.id = $1`, [id]);

      return { message: message.rows[0], contexte: contexte[0] || null };
    });

    if (req.body?.notifier && resultat.contexte) {
      const destinataire = resultat.contexte.demandeur_email || resultat.contexte.ecole_email;
      if (destinataire) {
        envoyerEmail({
          to: destinataire,
          subject: `${resultat.contexte.reference || 'Support Ardoise'} — ${resultat.contexte.sujet}`,
          html: emailWrapper({
            type: 'message',
            titre: 'Réponse du support Ardoise',
            contenuHtml: `<p>${contenu.replace(/</g, '&lt;').replace(/\n/g, '<br>')}</p>`
          })
        }).catch((e) => console.error('Notification ticket non envoyée:', e.message));
      }
    }

    return res.status(201).json(resultat.message);
  } catch (err) {
    console.error('Erreur réponse ticket:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   3. Notifications système
   ========================================================================== */

/** GET /super-admin/notifications */
async function listerNotifications(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client, `SELECT count(*) FROM notifications_plateforme`, [], 0);
      const donnees = await lignes(client, `
        SELECT n.*, e.nom AS ecole_nom,
               trim(concat_ws(' ', u.prenom, u.nom)) AS cree_par_nom
        FROM notifications_plateforme n
        LEFT JOIN ecoles e ON e.id = n.ecole_id
        LEFT JOIN utilisateurs u ON u.id = n.cree_par
        ORDER BY n.created_at DESC LIMIT $1 OFFSET $2`, [taille, decalage]);
      return { total, donnees };
    });
    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees));
  } catch (err) {
    console.error('Erreur liste notifications:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/notifications
 * body: { titre, contenu, niveau?, cible?, ecole_id?, role_cible?, canal?, publier? }
 *
 * La diffusion écrit une notification par école dans la table `notifications`
 * existante — celle que les écoles consultent déjà dans leur interface. Créer
 * un second canal que personne ne regarde n'aurait aucun intérêt.
 */
async function creerNotification(req, res) {
  const { titre, contenu, niveau, cible, ecole_id, role_cible, canal, publier } = req.body || {};

  if (!titre || !contenu) {
    return res.status(400).json({ message: 'Titre et contenu sont requis.' });
  }
  if (cible === 'ecole' && !ecole_id) {
    return res.status(400).json({ message: 'ecole_id est requis pour une notification ciblée.' });
  }

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const creation = await client.query(`
        INSERT INTO notifications_plateforme
          (titre, contenu, niveau, cible, ecole_id, role_cible, canal, cree_par)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [String(titre).slice(0, 300), contenu,
         ['info', 'succes', 'avertissement', 'critique'].includes(niveau) ? niveau : 'info',
         ['toutes', 'ecole', 'role'].includes(cible) ? cible : 'toutes',
         ecole_id || null, role_cible || null,
         ['interne', 'email', 'interne_email'].includes(canal) ? canal : 'interne',
         req.auth.userId]);

      const id = creation.rows[0].id;
      if (!publier) return { id, statut: 'brouillon', destinataires: 0 };

      // Une notification sans `utilisateur_id` n'est lue par personne : les
      // espaces des écoles interrogent `notifications` par destinataire, pas
      // par école. Une annonce déposée avec le seul `ecole_id` resterait donc
      // en base sans jamais s'afficher — un envoi silencieusement perdu, le
      // pire des résultats pour une annonce qu'on croit passée.
      //
      // On l'adresse donc nominativement. Par défaut aux directeurs et préfets,
      // qui sont les interlocuteurs de la plateforme ; `role_cible` permet de
      // viser un autre rôle quand l'annonce s'adresse à d'autres (une nouveauté
      // du carnet de notes concerne les professeurs, pas la direction).
      const roles = role_cible
        ? [role_cible]
        : ['directeur', 'prefet'];

      const conditions = ["u.statut = 'actif'"];
      const params = [String(titre).slice(0, 200), contenu, req.auth.userId, roles];
      conditions.push(`EXISTS (SELECT 1 FROM utilisateur_roles ur
                                WHERE ur.utilisateur_id = u.id
                                  AND ur.role::text = ANY($4))`);

      if (ecole_id) {
        params.push(ecole_id);
        conditions.push(`u.ecole_id = $${params.length}::uuid`);
      } else {
        conditions.push(`EXISTS (SELECT 1 FROM ecoles e
                                  WHERE e.id = u.ecole_id AND e.statut = 'actif')`);
      }

      // Une seule requête ensembliste plutôt qu'une boucle : sur cent écoles,
      // cent allers-retours suffisent à faire expirer la requête HTTP.
      // `cle_unicite` empêche le doublon si l'annonce est republiée.
      const depot = await client.query(`
        INSERT INTO notifications
          (ecole_id, utilisateur_id, canal, sujet, contenu, statut, lu, expediteur_id, cle_unicite)
        SELECT u.ecole_id, u.id, 'interne', $1, $2, 'envoye', false, $3,
               'plateforme:' || $5::text || ':' || u.id::text
        FROM utilisateurs u
        WHERE ${conditions.join(' AND ')}
        ON CONFLICT DO NOTHING
        RETURNING id`,
        [...params, id]);

      const envoyees = depot.rowCount;
      const ecolesTouchees = await mesurer(client, `
        SELECT count(DISTINCT ecole_id) FROM notifications
        WHERE cle_unicite LIKE $1`, [`plateforme:${id}:%`], 0);

      await client.query(`
        UPDATE notifications_plateforme
        SET statut = 'envoyee', publiee_at = now(), nb_destinataires = $2, nb_echecs = 0
        WHERE id = $1`, [id, envoyees]);

      return {
        id,
        statut: 'envoyee',
        destinataires: envoyees,
        ecoles_touchees: ecolesTouchees,
        roles_vises: roles
      };
    });

    return res.status(201).json({ message: 'Notification enregistrée.', ...resultat });
  } catch (err) {
    console.error('Erreur création notification:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. Rapports et exports
   ========================================================================== */

/**
 * Jeux de données exportables. Liste fermée, pour la même raison que le
 * catalogue de l'Explorateur : le nom vient de l'URL, il ne doit jamais
 * atteindre le SQL.
 */
const RAPPORTS = {
  ecoles: {
    libelle: 'Écoles et abonnements',
    sql: `
      SELECT e.nom AS "École", e.code AS "Code", e.ville AS "Ville", e.province AS "Province",
             e.statut AS "Statut", p.nom AS "Plan", a.statut AS "Statut abonnement",
             to_char(a.date_expiration, 'DD/MM/YYYY') AS "Expiration",
             (SELECT count(*) FROM eleves x WHERE x.ecole_id = e.id AND x.statut='actif') AS "Élèves",
             (SELECT count(*) FROM utilisateurs x WHERE x.ecole_id = e.id) AS "Utilisateurs",
             to_char(e.created_at, 'DD/MM/YYYY') AS "Créée le"
      FROM ecoles e
      LEFT JOIN LATERAL (SELECT * FROM abonnements WHERE ecole_id = e.id ORDER BY created_at DESC LIMIT 1) a ON true
      LEFT JOIN plans_abonnement p ON p.id = a.plan_id
      ORDER BY e.nom`
  },
  utilisateurs: {
    libelle: 'Comptes utilisateurs',
    sql: `
      SELECT trim(concat_ws(' ', u.prenom, u.nom)) AS "Nom", u.email AS "Email",
             u.telephone AS "Téléphone", e.nom AS "École", u.statut AS "Statut",
             (SELECT string_agg(r.role::text, ', ') FROM utilisateur_roles r
              WHERE r.utilisateur_id = u.id) AS "Rôles",
             to_char(u.created_at, 'DD/MM/YYYY') AS "Créé le"
      FROM utilisateurs u LEFT JOIN ecoles e ON e.id = u.ecole_id
      ORDER BY e.nom, u.nom`
  },
  paiements: {
    libelle: 'Paiements de la plateforme',
    sql: `
      SELECT e.nom AS "École", pa.montant AS "Montant", pa.methode AS "Méthode",
             pa.statut AS "Statut", pa.reference_externe AS "Référence",
             to_char(pa.date_paiement, 'DD/MM/YYYY') AS "Date"
      FROM paiements pa LEFT JOIN ecoles e ON e.id = pa.ecole_id
      ORDER BY pa.date_paiement DESC`
  },
  activite: {
    libelle: "Journal d'activité (90 jours)",
    sql: `
      SELECT to_char(j.created_at, 'DD/MM/YYYY HH24:MI') AS "Horodatage",
             j.action AS "Action", j.cible_type AS "Cible",
             e.nom AS "École", trim(concat_ws(' ', u.prenom, u.nom)) AS "Utilisateur"
      FROM journal_activite j
      LEFT JOIN ecoles e ON e.id = j.ecole_id
      LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
      WHERE j.created_at >= now() - interval '90 days'
      ORDER BY j.created_at DESC LIMIT 20000`
  },
  bugs: {
    libelle: 'Bugs et erreurs',
    sql: `
      SELECT b.gravite AS "Gravité", b.statut AS "Statut", b.occurrences AS "Occurrences",
             b.message AS "Message", b.page AS "Page", b.navigateur AS "Navigateur",
             b.systeme AS "Système", e.nom AS "École",
             to_char(b.derniere_occurrence, 'DD/MM/YYYY HH24:MI') AS "Dernière occurrence"
      FROM bugs_plateforme b LEFT JOIN ecoles e ON e.id = b.ecole_id
      ORDER BY b.derniere_occurrence DESC`
  },
  tickets: {
    libelle: 'Tickets de support',
    sql: `
      SELECT t.reference AS "Référence", t.sujet AS "Sujet", e.nom AS "École",
             t.priorite AS "Priorité", t.statut AS "Statut", t.categorie AS "Catégorie",
             to_char(t.created_at, 'DD/MM/YYYY') AS "Ouvert le",
             to_char(t.ferme_at, 'DD/MM/YYYY') AS "Clos le"
      FROM tickets_support t LEFT JOIN ecoles e ON e.id = t.ecole_id
      ORDER BY t.created_at DESC`
  }
};

/** GET /super-admin/rapports — catalogue. */
function catalogueRapports(req, res) {
  return res.json({
    rapports: Object.entries(RAPPORTS).map(([cle, r]) => ({ cle, libelle: r.libelle })),
    formats: ['xlsx', 'csv', 'pdf', 'json']
  });
}

/**
 * GET /super-admin/rapports/:rapport?format=xlsx|csv|pdf|json
 *
 * Le PDF est produit en HTML imprimable plutôt qu'en binaire : le projet
 * dispose de puppeteer-core pour les bulletins, mais lancer un navigateur
 * headless pour un tableau de 20 000 lignes consommerait plusieurs centaines
 * de mégaoctets sur une instance déjà contrainte. Le navigateur du poste le
 * fait mieux, et gratuitement.
 */
async function exporterRapport(req, res) {
  const definition = RAPPORTS[req.params.rapport];
  if (!definition) {
    return res.status(404).json({ message: `Rapport inconnu. Disponibles : ${Object.keys(RAPPORTS).join(', ')}.` });
  }

  const format = ['xlsx', 'csv', 'pdf', 'json'].includes(req.query.format) ? req.query.format : 'xlsx';
  const horodatage = new Date().toISOString().slice(0, 10);
  const nomFichier = `ardoise-${req.params.rapport}-${horodatage}`;

  try {
    const donnees = await runWithTenant(SUPER, (client) => lignes(client, definition.sql));

    if (format === 'json') {
      return res.json({ rapport: definition.libelle, genere_a: new Date().toISOString(), donnees });
    }

    if (format === 'csv') {
      const feuille = XLSX.utils.json_to_sheet(donnees.length ? donnees : [{ Information: 'Aucune donnée' }]);
      // BOM UTF-8 : sans lui, Excel sous Windows affiche « École » en « Ã‰cole ».
      const csv = '\uFEFF' + XLSX.utils.sheet_to_csv(feuille, { FS: ';' });
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${nomFichier}.csv"`);
      return res.send(csv);
    }

    if (format === 'pdf') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.send(pageImprimable(definition.libelle, donnees));
    }

    const classeur = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      classeur,
      XLSX.utils.json_to_sheet(donnees.length ? donnees : [{ Information: 'Aucune donnée' }]),
      definition.libelle.slice(0, 31)
    );
    const tampon = XLSX.write(classeur, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${nomFichier}.xlsx"`);
    return res.send(tampon);
  } catch (err) {
    console.error('Erreur export rapport:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

function echapperHtml(v) {
  return String(v ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function pageImprimable(titre, donnees) {
  const colonnes = donnees.length ? Object.keys(donnees[0]) : ['Information'];
  const corps = donnees.length
    ? donnees.map((l) => `<tr>${colonnes.map((c) => `<td>${echapperHtml(l[c])}</td>`).join('')}</tr>`).join('')
    : `<tr><td>Aucune donnée</td></tr>`;

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<title>Ardoise — ${echapperHtml(titre)}</title>
<style>
  @page { size: A4 landscape; margin: 14mm; }
  body { font-family: 'Inter', system-ui, sans-serif; color: #1F2B24; font-size: 11px; }
  h1 { font-family: Georgia, serif; font-size: 20px; margin: 0 0 4px; }
  .meta { color: #6B7269; font-size: 11px; margin-bottom: 18px; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #F6F2E7; text-align: left; padding: 7px 9px; font-size: 10px;
       text-transform: uppercase; letter-spacing: .04em; border-bottom: 1.5px solid #E4DFCF; }
  td { padding: 6px 9px; border-bottom: 1px solid #EFEADC; }
  tr:nth-child(even) td { background: #FBF9F3; }
  .imprimer { position: fixed; top: 14px; right: 14px; padding: 9px 16px; background: #C98A3E;
              color: #FBF9F3; border: 0; border-radius: 7px; font: inherit; cursor: pointer; }
  @media print { .imprimer { display: none; } }
</style></head>
<body>
  <button class="imprimer" onclick="window.print()">Imprimer / Enregistrer en PDF</button>
  <h1>${echapperHtml(titre)}</h1>
  <p class="meta">Ardoise — généré le ${new Date().toLocaleString('fr-FR')} · ${donnees.length} ligne(s)</p>
  <table>
    <thead><tr>${colonnes.map((c) => `<th>${echapperHtml(c)}</th>`).join('')}</tr></thead>
    <tbody>${corps}</tbody>
  </table>
</body></html>`;
}

module.exports = {
  signalerBug, listerBugs, detailBug, modifierBug, commenterBug,
  listerTickets, detailTicket, creerTicket, modifierTicket, repondreTicket,
  listerNotifications, creerNotification,
  catalogueRapports, exporterRapport
};
