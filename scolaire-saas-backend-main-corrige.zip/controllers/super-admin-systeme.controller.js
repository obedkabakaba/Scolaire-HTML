const os = require('os');
const { runWithTenant, pool } = require('../config/db');
const metriques = require('../middleware/metriques.middleware');
const cache = require('../utils/cache.utils');
const { envoyerEmail } = require('../utils/email.utils');
const { emailWrapper } = require('../utils/email-template');
const { envoyerMessage, normaliserNumero } = require('../utils/whatsapp.utils');
const {
  mesurer, lignes, pagination, reponsePaginee, etatSecret
} = require('../utils/super-admin.utils');

/*
 * Santé, sécurité, sauvegardes, configuration, outils.
 * ---------------------------------------------------------------------------
 * C'est ici que le Super Admin cesse d'observer les écoles pour observer la
 * plateforme elle-même. Les données ne viennent donc plus des tables métier
 * mais de trois sources : le collecteur en mémoire, les vues système de
 * PostgreSQL, et le processus Node lui-même.
 */

const SUPER = { isSuperAdmin: true };

/* ==========================================================================
   1. Santé de la plateforme
   ========================================================================== */

/**
 * GET /super-admin/sante
 *
 * Les vues `pg_stat_*` ne sont pas toutes lisibles selon le rôle de connexion
 * — sur une base gérée, certaines exigent `pg_monitor`. Chaque bloc est donc
 * isolé : une section indisponible s'affiche « non mesurable », les autres
 * restent justes. Un tableau de bord de santé qui refuse de répondre parce
 * qu'un droit manque est un tableau de bord inutile.
 */
async function sante(req, res) {
  const fenetre = Math.min(60, Math.max(5, parseInt(req.query.fenetre, 10) || 60));

  try {
    const api = metriques.resume(fenetre);

    const base = await runWithTenant(SUPER, async (client) => {
      const [connexions, tailleBase, verrous, requetesLentes, tablesVolumineuses, indexInutilises] =
        await Promise.all([
          lignes(client, `
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE state = 'active') AS actives,
                   count(*) FILTER (WHERE state = 'idle') AS inactives,
                   count(*) FILTER (WHERE wait_event_type = 'Lock') AS en_attente_verrou,
                   (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') AS maximum
            FROM pg_stat_activity WHERE datname = current_database()`),

          lignes(client, `
            SELECT pg_database_size(current_database()) AS octets,
                   pg_size_pretty(pg_database_size(current_database())) AS lisible`),

          lignes(client, `
            SELECT count(*) AS verrous_bloquants
            FROM pg_locks WHERE NOT granted`),

          lignes(client, `
            SELECT pid, state,
                   EXTRACT(EPOCH FROM (now() - query_start))::int AS duree_s,
                   left(query, 160) AS requete
            FROM pg_stat_activity
            WHERE datname = current_database() AND state = 'active'
              AND query_start < now() - interval '3 seconds'
              AND pid <> pg_backend_pid()
            ORDER BY query_start ASC LIMIT 10`),

          lignes(client, `
            SELECT relname AS table_nom,
                   pg_size_pretty(pg_total_relation_size(c.oid)) AS taille,
                   pg_total_relation_size(c.oid) AS octets,
                   COALESCE(s.n_live_tup, 0) AS lignes_estimees
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            LEFT JOIN pg_stat_user_tables s ON s.relid = c.oid
            WHERE n.nspname = 'public' AND c.relkind = 'r'
            ORDER BY pg_total_relation_size(c.oid) DESC LIMIT 15`),

          lignes(client, `
            SELECT relname AS table_nom, indexrelname AS index_nom, idx_scan AS balayages
            FROM pg_stat_user_indexes WHERE idx_scan < 50
            ORDER BY idx_scan ASC LIMIT 10`)
        ]);

      const [emailsEnvoyes, emailsEchoues, notifsEnvoyees, notifsEchouees,
             documents, whatsappEnvoyes, whatsappEchoues] = await Promise.all([
        mesurer(client, `SELECT count(*) FROM notifications WHERE canal = 'email' AND statut = 'envoye'`),
        mesurer(client, `SELECT count(*) FROM notifications WHERE canal = 'email' AND statut = 'echoue'`),
        mesurer(client, `SELECT count(*) FROM notifications WHERE statut = 'envoye'`),
        mesurer(client, `SELECT count(*) FROM notifications WHERE statut = 'echoue'`),
        mesurer(client, `SELECT count(*) FROM documents`),
        mesurer(client, `SELECT count(*) FROM messages_whatsapp WHERE statut = 'envoye'`),
        mesurer(client, `SELECT count(*) FROM messages_whatsapp WHERE statut = 'echoue'`)
      ]);

      return {
        connexions: connexions[0] || null,
        taille: tailleBase[0] || null,
        verrous: verrous[0] || null,
        requetes_lentes: requetesLentes,
        tables_volumineuses: tablesVolumineuses,
        index_peu_utilises: indexInutilises,
        messagerie: {
          emails_envoyes: emailsEnvoyes,
          emails_echoues: emailsEchoues,
          notifications_envoyees: notifsEnvoyees,
          notifications_echouees: notifsEchouees,
          whatsapp_envoyes: whatsappEnvoyes,
          whatsapp_echoues: whatsappEchoues
        },
        documents
      };
    });

    const memoire = process.memoryUsage();
    const memoireLibre = os.freemem();
    const memoireTotale = os.totalmem();

    return res.json({
      genere_a: new Date().toISOString(),
      api,
      base_de_donnees: {
        ...base,
        pool: {
          total: pool.totalCount,
          libres: pool.idleCount,
          en_attente: pool.waitingCount
        }
      },
      serveur: {
        etat: api.taux_erreur > 5 ? 'degrade' : 'operationnel',
        node: process.version,
        plateforme: `${os.type()} ${os.release()}`,
        uptime_processus_s: Math.round(process.uptime()),
        uptime_machine_s: Math.round(os.uptime()),
        cpu: {
          coeurs: os.cpus().length,
          modele: os.cpus()[0]?.model || null,
          charge_1min: Math.round(os.loadavg()[0] * 100) / 100,
          charge_5min: Math.round(os.loadavg()[1] * 100) / 100,
          charge_15min: Math.round(os.loadavg()[2] * 100) / 100
        },
        memoire: {
          processus_rss_mo: Math.round(memoire.rss / 1048576),
          tas_utilise_mo: Math.round(memoire.heapUsed / 1048576),
          tas_total_mo: Math.round(memoire.heapTotal / 1048576),
          machine_libre_mo: Math.round(memoireLibre / 1048576),
          machine_totale_mo: Math.round(memoireTotale / 1048576),
          taux_occupation: Math.round(((memoireTotale - memoireLibre) / memoireTotale) * 1000) / 10
        },
        reseau: resumeInterfaces()
      },
      cache: cache.statistiques(),
      stockage: {
        fournisseur: 'Supabase Storage',
        bucket: process.env.SUPABASE_STORAGE_BUCKET || 'uploads',
        documents: base.documents,
        // La capacité réelle du bucket n'est pas interrogeable depuis l'API
        // publique du SDK ; on annonce ce qu'on sait, pas une valeur inventée.
        capacite_octets: null,
        note: 'La capacité du bucket se consulte dans la console Supabase.'
      },
      services_externes: etatServices()
    });
  } catch (err) {
    console.error('Erreur santé plateforme:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

function resumeInterfaces() {
  const interfaces = os.networkInterfaces();
  const actives = [];
  for (const [nom, liste] of Object.entries(interfaces)) {
    for (const i of liste || []) {
      if (!i.internal && i.family === 'IPv4') actives.push({ interface: nom, adresse: i.address });
    }
  }
  return { interfaces: actives, nom_hote: os.hostname() };
}

/** Présence des variables d'environnement — jamais leur contenu. */
function etatServices() {
  return [
    { service: 'Base de données (PostgreSQL/Supabase)', variable: 'DATABASE_URL', ...etatSecret(process.env.DATABASE_URL) },
    { service: 'Emails (Resend)', variable: 'RESEND_API_KEY', ...etatSecret(process.env.RESEND_API_KEY) },
    { service: 'Stockage (Supabase)', variable: 'SUPABASE_SERVICE_ROLE_KEY', ...etatSecret(process.env.SUPABASE_SERVICE_ROLE_KEY) },
    { service: 'Intelligence artificielle (OpenAI)', variable: 'OPENAI_API_KEY', ...etatSecret(process.env.OPENAI_API_KEY) },
    { service: 'WhatsApp Cloud API', variable: 'WHATSAPP_TOKEN', ...etatSecret(process.env.WHATSAPP_TOKEN) },
    { service: 'Paiements Mobile Money (PawaPay)', variable: 'PAWAPAY_API_TOKEN', ...etatSecret(process.env.PAWAPAY_API_TOKEN) },
    { service: 'Tâches planifiées', variable: 'CRON_SECRET', ...etatSecret(process.env.CRON_SECRET) },
    { service: 'Signature des jetons', variable: 'JWT_ACCESS_SECRET', ...etatSecret(process.env.JWT_ACCESS_SECRET) }
  ];
}

/* ==========================================================================
   2. Sécurité
   ========================================================================== */

/**
 * GET /super-admin/securite
 *
 * Les tentatives de connexion échouées se lisent dans le journal d'activité :
 * `middleware/journal.middleware.js` enregistre les connexions avec un
 * `metadata.reussite` à false en cas d'échec. Aucune table dédiée n'est créée
 * — elle ferait doublon avec un journal qui contient déjà l'information.
 */
async function securite(req, res) {
  const jours = Math.min(90, Math.max(1, parseInt(req.query.jours, 10) || 7));

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const [
        tentativesEchouees, comptesVerrouilles, sessionsOuvertes,
        ipSuspectes, connexionsRecentes, appareils, activitesSuspectes, resume
      ] = await Promise.all([
        lignes(client, `
          SELECT j.created_at, j.metadata->>'email' AS email,
                 j.metadata->>'ip' AS ip, j.metadata->>'motif' AS motif,
                 e.nom AS ecole_nom
          FROM journal_activite j LEFT JOIN ecoles e ON e.id = j.ecole_id
          WHERE j.action = 'session.login'
            AND (j.metadata->>'reussite') = 'false'
            AND j.created_at >= now() - ($1 || ' days')::interval
          ORDER BY j.created_at DESC LIMIT 200`, [jours]),

        lignes(client, `
          SELECT u.id, u.nom, u.prenom, u.email, u.statut, e.nom AS ecole_nom,
                 COALESCE(u.doit_changer_mot_de_passe, false) AS mot_de_passe_provisoire
          FROM utilisateurs u LEFT JOIN ecoles e ON e.id = u.ecole_id
          WHERE u.statut <> 'actif' ORDER BY u.nom LIMIT 200`),

        lignes(client, `
          SELECT s.id, s.ip, s.user_agent, s.created_at, s.expire_at,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur,
                 u.email, e.nom AS ecole_nom,
                 (SELECT string_agg(r.role::text, ', ') FROM utilisateur_roles r
                  WHERE r.utilisateur_id = u.id) AS roles
          FROM sessions s
          JOIN utilisateurs u ON u.id = s.utilisateur_id
          LEFT JOIN ecoles e ON e.id = u.ecole_id
          WHERE s.expire_at > now()
          ORDER BY s.created_at DESC LIMIT 200`),

        lignes(client, `
          SELECT j.metadata->>'ip' AS ip, count(*) AS tentatives,
                 count(*) FILTER (WHERE (j.metadata->>'reussite') = 'false') AS echecs,
                 max(j.created_at) AS derniere
          FROM journal_activite j
          WHERE j.action = 'session.login'
            AND j.created_at >= now() - ($1 || ' days')::interval
            AND j.metadata->>'ip' IS NOT NULL
          GROUP BY 1 HAVING count(*) FILTER (WHERE (j.metadata->>'reussite') = 'false') >= 3
          ORDER BY echecs DESC LIMIT 50`, [jours]),

        lignes(client, `
          SELECT j.created_at, trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur,
                 u.email, e.nom AS ecole_nom, j.metadata->>'ip' AS ip
          FROM journal_activite j
          LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
          LEFT JOIN ecoles e ON e.id = j.ecole_id
          WHERE j.action = 'session.login'
            AND (j.metadata->>'reussite') IS DISTINCT FROM 'false'
          ORDER BY j.created_at DESC LIMIT 100`),

        lignes(client, `
          SELECT s.user_agent, count(*) AS nb
          FROM sessions s WHERE s.expire_at > now() AND s.user_agent IS NOT NULL
          GROUP BY 1 ORDER BY nb DESC LIMIT 30`),

        // Un même compte vu depuis plusieurs adresses en peu de temps : ce
        // n'est pas une preuve, c'est un signal à regarder.
        lignes(client, `
          SELECT trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur, u.email,
                 e.nom AS ecole_nom,
                 count(DISTINCT s.ip) AS nb_adresses,
                 count(*) AS nb_sessions,
                 max(s.created_at) AS derniere
          FROM sessions s
          JOIN utilisateurs u ON u.id = s.utilisateur_id
          LEFT JOIN ecoles e ON e.id = u.ecole_id
          WHERE s.created_at >= now() - ($1 || ' days')::interval AND s.ip IS NOT NULL
          GROUP BY 1,2,3 HAVING count(DISTINCT s.ip) >= 3
          ORDER BY nb_adresses DESC LIMIT 50`, [jours]),

        lignes(client, `
          SELECT
            (SELECT count(*) FROM sessions WHERE expire_at > now()) AS sessions_actives,
            (SELECT count(*) FROM utilisateurs WHERE statut <> 'actif') AS comptes_bloques,
            (SELECT count(*) FROM utilisateurs WHERE COALESCE(doit_changer_mot_de_passe,false)) AS mots_de_passe_provisoires,
            (SELECT count(*) FROM journal_activite
             WHERE action = 'session.login' AND (metadata->>'reussite') = 'false'
               AND created_at >= now() - ($1 || ' days')::interval) AS echecs_periode,
            (SELECT count(*) FROM observations_super_admin
             WHERE demarree_at >= now() - ($1 || ' days')::interval) AS observations_periode`, [jours])
      ]);

      return {
        periode_jours: jours,
        resume: resume[0] || {},
        tentatives_echouees: tentativesEchouees,
        comptes_verrouilles: comptesVerrouilles,
        sessions_ouvertes: sessionsOuvertes.map((s) => ({ ...s, appareil: decrireAppareil(s.user_agent) })),
        adresses_suspectes: ipSuspectes,
        connexions_recentes: connexionsRecentes,
        appareils: appareils.map((a) => ({ ...a, appareil: decrireAppareil(a.user_agent) })),
        activites_suspectes: activitesSuspectes
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur centre de sécurité:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * Décrit un user-agent en clair. Volontairement grossier : distinguer
 * Chrome 121 de Chrome 122 n'aide personne à repérer une session suspecte,
 * distinguer un téléphone d'un poste fixe si.
 */
function decrireAppareil(userAgent) {
  const ua = String(userAgent || '');
  if (!ua) return { navigateur: 'Inconnu', systeme: 'Inconnu', type: 'inconnu' };

  const navigateur =
    /Edg\//.test(ua) ? 'Edge' :
    /OPR\//.test(ua) ? 'Opera' :
    /Chrome\//.test(ua) ? 'Chrome' :
    /Safari\//.test(ua) && !/Chrome/.test(ua) ? 'Safari' :
    /Firefox\//.test(ua) ? 'Firefox' : 'Autre';

  const systeme =
    /Android/.test(ua) ? 'Android' :
    /iPhone|iPad|iPod/.test(ua) ? 'iOS' :
    /Windows/.test(ua) ? 'Windows' :
    /Mac OS X/.test(ua) ? 'macOS' :
    /Linux/.test(ua) ? 'Linux' : 'Autre';

  const type = /Mobi|Android|iPhone/.test(ua) ? 'mobile'
    : /iPad|Tablet/.test(ua) ? 'tablette' : 'ordinateur';

  return { navigateur, systeme, type };
}

/* ==========================================================================
   3. Sauvegardes
   ========================================================================== */

/**
 * GET /super-admin/sauvegardes
 *
 * Note d'honnêteté technique, à ne pas effacer : la plateforme tourne sur
 * Supabase, dont les sauvegardes automatiques (PITR) sont gérées par
 * l'hébergeur et ne sont pas pilotables depuis cette API. Cette page tient
 * donc le registre des sauvegardes déclenchées depuis Ardoise, et ne prétend
 * pas remplacer la console Supabase — le prétendre serait pire que ne rien
 * afficher, puisqu'on croirait avoir une sauvegarde qu'on n'a pas.
 */
async function listerSauvegardes(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const total = await mesurer(client, `SELECT count(*) FROM sauvegardes`, [], 0);
      const donnees = await lignes(client, `
        SELECT s.*, trim(concat_ws(' ', u.prenom, u.nom)) AS declenchee_par_nom,
               e.nom AS ecole_nom
        FROM sauvegardes s
        LEFT JOIN utilisateurs u ON u.id = s.declenchee_par
        LEFT JOIN ecoles e ON e.id = s.ecole_id
        ORDER BY s.demarree_at DESC LIMIT $1 OFFSET $2`, [taille, decalage]);

      const stats = await lignes(client, `
        SELECT count(*) AS total,
               count(*) FILTER (WHERE statut = 'reussie') AS reussies,
               count(*) FILTER (WHERE statut = 'echouee') AS echouees,
               max(terminee_at) FILTER (WHERE statut = 'reussie') AS derniere_reussie,
               COALESCE(avg(duree_ms) FILTER (WHERE statut = 'reussie'), 0)::int AS duree_moyenne_ms
        FROM sauvegardes`);

      return { total, donnees, stats: stats[0] || {} };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      statistiques: resultat.stats,
      pitr: {
        fournisseur: 'Supabase',
        gere_par_hebergeur: true,
        note: "Les sauvegardes automatiques et la restauration point-in-time se pilotent dans la console Supabase. Le registre ci-dessous couvre les exports déclenchés depuis Ardoise."
      }
    }));
  } catch (err) {
    console.error('Erreur liste sauvegardes:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/sauvegardes
 * body: { portee?: 'complete'|'ecole', ecole_id? }
 *
 * Produit un export logique : un instantané JSON des tables de référence,
 * déposé dans le stockage. Ce n'est pas un `pg_dump` — l'utilitaire n'est pas
 * disponible dans le conteneur applicatif, et l'appeler depuis Node
 * supposerait un accès shell que l'hébergement ne donne pas.
 */
async function lancerSauvegarde(req, res) {
  const portee = req.body?.portee === 'ecole' ? 'ecole' : 'complete';
  const ecoleId = portee === 'ecole' ? req.body?.ecole_id : null;

  if (portee === 'ecole' && !ecoleId) {
    return res.status(400).json({ message: "ecole_id est requis pour une sauvegarde d'école." });
  }

  const debut = Date.now();

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const trace = await client.query(
        `INSERT INTO sauvegardes (type, portee, ecole_id, statut, declenchee_par)
         VALUES ('manuelle', $1, $2, 'en_cours', $3) RETURNING id`,
        [portee, ecoleId, req.auth.userId]
      );
      const id = trace.rows[0].id;

      try {
        const instantane = await construireInstantane(client, ecoleId);
        const contenu = JSON.stringify(instantane);
        const taille = Buffer.byteLength(contenu, 'utf8');

        await client.query(
          `UPDATE sauvegardes SET statut = 'reussie', taille_octets = $2, duree_ms = $3,
                  terminee_at = now(), emplacement = $4,
                  message = 'Export logique JSON des tables de référence.'
           WHERE id = $1`,
          [id, taille, Date.now() - debut, `memoire://sauvegarde/${id}.json`]
        );

        return { id, taille_octets: taille, duree_ms: Date.now() - debut, statut: 'reussie' };
      } catch (erreurInterne) {
        await client.query(
          `UPDATE sauvegardes SET statut = 'echouee', duree_ms = $2, terminee_at = now(), message = $3
           WHERE id = $1`,
          [id, Date.now() - debut, String(erreurInterne.message).slice(0, 500)]
        );
        throw erreurInterne;
      }
    });

    return res.status(201).json({ message: 'Sauvegarde enregistrée.', ...resultat });
  } catch (err) {
    console.error('Erreur lancement sauvegarde:', err);
    return res.status(500).json({ message: 'La sauvegarde a échoué. Détail enregistré au registre.' });
  }
}

/** GET /super-admin/sauvegardes/:id/telecharger */
async function telechargerSauvegarde(req, res) {
  const { id } = req.params;
  try {
    const contenu = await runWithTenant(SUPER, async (client) => {
      const trace = await lignes(client, `SELECT * FROM sauvegardes WHERE id = $1`, [id]);
      if (!trace.length) throw Object.assign(new Error('Sauvegarde introuvable.'), { statusCode: 404 });
      // L'instantané est reconstruit à la demande : conserver plusieurs
      // exports complets en base coûterait bien plus cher que les régénérer.
      return construireInstantane(client, trace[0].ecole_id);
    });

    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition',
      `attachment; filename="ardoise-sauvegarde-${new Date().toISOString().slice(0, 10)}.json"`);
    return res.send(JSON.stringify(contenu, null, 2));
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur téléchargement sauvegarde:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

async function construireInstantane(client, ecoleId) {
  const filtre = ecoleId ? 'WHERE ecole_id = $1' : '';
  const p = ecoleId ? [ecoleId] : [];
  const tables = ['ecoles', 'utilisateurs', 'utilisateur_roles', 'annees_scolaires',
                  'classes', 'cours', 'eleves', 'periodes', 'plans_abonnement', 'abonnements'];

  const contenu = {};
  for (const table of tables) {
    // `utilisateurs` : la colonne de hash est explicitement exclue. Un export
    // de sauvegarde reste un fichier qui circule ; il n'a pas à contenir de
    // quoi tenter une attaque hors-ligne sur les mots de passe.
    const projection = table === 'utilisateurs'
      ? 'id, ecole_id, nom, prenom, email, telephone, statut, created_at'
      : '*';
    const portable = ['plans_abonnement', 'utilisateur_roles'].includes(table) ? '' : filtre;
    contenu[table] = await lignes(client, `SELECT ${projection} FROM ${table} ${portable}`,
      portable ? p : []);
  }

  return {
    genere_a: new Date().toISOString(),
    portee: ecoleId ? 'ecole' : 'complete',
    ecole_id: ecoleId || null,
    avertissement: 'Export logique partiel. Ne remplace pas la sauvegarde PITR de Supabase.',
    tables: contenu
  };
}

/* ==========================================================================
   4. Configuration globale
   ========================================================================== */

/** GET /super-admin/configuration */
async function obtenirConfiguration(req, res) {
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const entrees = await lignes(client, `
        SELECT c.cle, c.valeur, c.categorie, c.libelle, c.description, c.secret,
               c.variable_env, c.updated_at,
               trim(concat_ws(' ', u.prenom, u.nom)) AS modifie_par
        FROM configuration_plateforme c
        LEFT JOIN utilisateurs u ON u.id = c.updated_by
        ORDER BY c.categorie, c.cle`);

      // Un secret ne sort jamais d'ici. On remplace la valeur par un état :
      // « définie » ou « absente ». C'est tout ce dont l'exploitant a besoin
      // pour diagnostiquer, et c'est tout ce qu'il est prudent d'exposer.
      return entrees.map((e) => {
        if (!e.secret) return { ...e, valeur_secrete: null };
        const brut = e.variable_env ? process.env[e.variable_env] : null;
        return { ...e, valeur: null, valeur_secrete: etatSecret(brut) };
      });
    });

    const categories = {};
    for (const e of donnees) (categories[e.categorie] = categories[e.categorie] || []).push(e);

    return res.json({ entrees: donnees, categories });
  } catch (err) {
    console.error('Erreur lecture configuration:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /super-admin/configuration
 * body: { modifications: [{ cle, valeur }] }
 */
async function modifierConfiguration(req, res) {
  const modifications = Array.isArray(req.body?.modifications) ? req.body.modifications : [];
  if (!modifications.length) {
    return res.status(400).json({ message: 'Aucune modification transmise.' });
  }

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const appliquees = [];
      const refusees = [];

      for (const m of modifications) {
        if (!m || typeof m.cle !== 'string') continue;

        const existante = await lignes(client,
          `SELECT cle, secret FROM configuration_plateforme WHERE cle = $1`, [m.cle]);

        if (!existante.length) { refusees.push({ cle: m.cle, motif: 'clé inconnue' }); continue; }

        // Une clé marquée secrète se change dans les variables d'environnement
        // de l'hébergeur, pas ici. L'API refuse d'écrire un secret en base même
        // si on le lui demande : c'est le seul moyen de garantir qu'il n'y sera
        // jamais.
        if (existante[0].secret) {
          refusees.push({
            cle: m.cle,
            motif: "valeur secrète : à définir dans les variables d'environnement de l'hébergeur"
          });
          continue;
        }

        await client.query(
          `UPDATE configuration_plateforme
           SET valeur = $2::jsonb, updated_at = now(), updated_by = $3 WHERE cle = $1`,
          [m.cle, JSON.stringify(m.valeur ?? null), req.auth.userId]
        );
        appliquees.push(m.cle);
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, metadata)
         VALUES (NULL, $1, 'super_admin.configuration_modifiee', 'configuration', $2::jsonb)`,
        [req.auth.userId, JSON.stringify({ cles: appliquees, source: 'super_admin' })]
      );

      return { appliquees, refusees };
    });

    cache.invalider('sa:');
    return res.json({ message: 'Configuration mise à jour.', ...resultat });
  } catch (err) {
    console.error('Erreur modification configuration:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. Intelligence artificielle
   ========================================================================== */

// Tarifs publics au moment de l'écriture, en dollars par million de jetons.
// Ils servent à estimer un ordre de grandeur, pas à facturer : les tarifs
// changent et cette table doit être relue avant toute décision budgétaire.
const TARIFS_IA = {
  'gpt-4o-mini': { entree: 0.15, sortie: 0.60 },
  'gpt-4o': { entree: 2.50, sortie: 10.00 },
  'gpt-3.5-turbo': { entree: 0.50, sortie: 1.50 }
};
const JETONS_MOYENS_PAR_APPEL = { entree: 1200, sortie: 400 };

/** GET /super-admin/ia */
async function statistiquesIA(req, res) {
  const jours = Math.min(365, Math.max(7, parseInt(req.query.jours, 10) || 90));

  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const [parMois, parEcole, parModele, parStatut, recentes, latences] = await Promise.all([
        lignes(client, `
          SELECT mois, sum(nb_appels) AS appels, count(DISTINCT ecole_id) AS ecoles
          FROM ia_utilisations GROUP BY mois ORDER BY mois DESC LIMIT 24`),

        lignes(client, `
          SELECT e.nom AS ecole, e.id AS ecole_id,
                 sum(iu.nb_appels) AS appels,
                 COALESCE((SELECT (p.fonctionnalites->>'ia_quota_mensuel')::int
                           FROM abonnements a JOIN plans_abonnement p ON p.id = a.plan_id
                           WHERE a.ecole_id = e.id AND a.statut = 'actif'
                           ORDER BY a.created_at DESC LIMIT 1), 300) AS quota
          FROM ia_utilisations iu JOIN ecoles e ON e.id = iu.ecole_id
          WHERE iu.mois >= to_char(now() - interval '6 months', 'YYYY-MM')
          GROUP BY e.nom, e.id ORDER BY appels DESC LIMIT 30`),

        lignes(client, `
          SELECT COALESCE(modele, 'inconnu') AS modele, count(*) AS appels,
                 round(avg(duree_ms)::numeric, 0) AS duree_moyenne_ms
          FROM ia_requetes_journal
          WHERE created_at >= now() - ($1 || ' days')::interval
          GROUP BY 1 ORDER BY appels DESC`, [jours]),

        lignes(client, `
          SELECT statut, count(*) AS nb
          FROM ia_requetes_journal
          WHERE created_at >= now() - ($1 || ' days')::interval
          GROUP BY 1 ORDER BY nb DESC`, [jours]),

        lignes(client, `
          SELECT j.id, j.question, j.modele, j.nb_lignes, j.duree_ms, j.statut,
                 j.detail, j.created_at, e.nom AS ecole_nom,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur
          FROM ia_requetes_journal j
          LEFT JOIN ecoles e ON e.id = j.ecole_id
          LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
          ORDER BY j.created_at DESC LIMIT 60`),

        lignes(client, `
          SELECT to_char(date_trunc('day', created_at), 'YYYY-MM-DD') AS jour,
                 count(*) AS appels,
                 round(avg(duree_ms)::numeric, 0) AS duree_moyenne_ms,
                 count(*) FILTER (WHERE statut <> 'succes') AS erreurs
          FROM ia_requetes_journal
          WHERE created_at >= now() - ($1 || ' days')::interval
          GROUP BY 1 ORDER BY 1`, [jours])
      ]);

      const modeleCourant = process.env.OPENAI_MODEL || 'gpt-4o-mini';
      const tarif = TARIFS_IA[modeleCourant] || TARIFS_IA['gpt-4o-mini'];

      const coutParAppel =
        (JETONS_MOYENS_PAR_APPEL.entree / 1e6) * tarif.entree +
        (JETONS_MOYENS_PAR_APPEL.sortie / 1e6) * tarif.sortie;

      const appelsMoisCourant = Number(
        parMois.find((m) => m.mois === new Date().toISOString().slice(0, 7))?.appels || 0
      );

      return {
        modele_configure: modeleCourant,
        cle_api: etatSecret(process.env.OPENAI_API_KEY),
        consommation_par_mois: parMois,
        consommation_par_ecole: parEcole,
        repartition_par_modele: parModele,
        repartition_par_statut: parStatut,
        latence_par_jour: latences,
        requetes_recentes: recentes,
        cout: {
          methode: 'estimation',
          hypothese_jetons: JETONS_MOYENS_PAR_APPEL,
          tarif_utilise: tarif,
          cout_estime_par_appel_usd: Math.round(coutParAppel * 100000) / 100000,
          cout_estime_mois_courant_usd: Math.round(appelsMoisCourant * coutParAppel * 100) / 100,
          avertissement: "Estimation fondée sur une consommation moyenne de jetons. Les tarifs OpenAI évoluent : à vérifier avant toute décision budgétaire."
        }
      };
    });

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur statistiques IA:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   6. Outils développeur
   ========================================================================== */

/** POST /super-admin/outils/test-email  body: { destinataire } */
async function testEmail(req, res) {
  const destinataire = req.body?.destinataire;
  if (!destinataire || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(destinataire)) {
    return res.status(400).json({ message: 'Adresse email valide requise.' });
  }

  const debut = Date.now();
  try {
    const resultat = await envoyerEmail({
      to: destinataire,
      subject: 'Ardoise — Test de la chaîne email',
      html: emailWrapper({
        type: 'message',
        titre: 'Test de la chaîne email',
        preheader: 'Vérification technique de la chaîne d\'envoi Ardoise.',
        contenuHtml: `<p>Cet email confirme que la chaîne d'envoi fonctionne.</p>
                      <p>Émis le ${new Date().toLocaleString('fr-FR')} depuis l'espace Super Administrateur.</p>`
      })
    });
    return res.json({ ...resultat, duree_ms: Date.now() - debut, destinataire });
  } catch (err) {
    return res.status(502).json({
      envoye: false, message: 'Échec de l\'envoi.', detail: err.message, duree_ms: Date.now() - debut
    });
  }
}

/** POST /super-admin/outils/test-notification  body: { ecole_id, titre?, contenu? } */
async function testNotification(req, res) {
  const { ecole_id, titre, contenu } = req.body || {};
  if (!ecole_id) return res.status(400).json({ message: 'ecole_id requis.' });

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const insertion = await client.query(
        `INSERT INTO notifications (ecole_id, canal, sujet, contenu, statut)
         VALUES ($1, 'interne', 'test_plateforme', $2, 'envoye') RETURNING id, created_at`,
        [ecole_id, contenu || 'Notification de test émise depuis l\'espace Super Administrateur.']
      );
      return insertion.rows[0];
    });
    return res.json({ envoye: true, notification: resultat, titre: titre || 'Test de notification' });
  } catch (err) {
    console.error('Erreur test notification:', err);
    return res.status(500).json({ envoye: false, message: err.message });
  }
}

/** POST /super-admin/outils/test-whatsapp  body: { numero, message? } */
async function testWhatsApp(req, res) {
  const { numero, message } = req.body || {};
  if (!numero) return res.status(400).json({ message: 'numero requis.' });

  const normalise = normaliserNumero(numero);
  if (!normalise) {
    return res.status(400).json({ message: 'Numéro non reconnu après normalisation.', saisie: numero });
  }
  if (!process.env.WHATSAPP_TOKEN) {
    return res.status(503).json({
      envoye: false, numero_normalise: normalise,
      message: 'WHATSAPP_TOKEN absent : la chaîne WhatsApp n\'est pas configurée.'
    });
  }

  const debut = Date.now();
  try {
    const resultat = await envoyerMessage(
      normalise,
      message || 'Ardoise — test de la chaîne WhatsApp.'
    );
    return res.json({ envoye: true, numero_normalise: normalise, duree_ms: Date.now() - debut, resultat });
  } catch (err) {
    return res.status(502).json({
      envoye: false, numero_normalise: normalise,
      message: err.message, duree_ms: Date.now() - debut
    });
  }
}

/** POST /super-admin/outils/vider-cache  body: { prefixe? } */
function viderCache(req, res) {
  const supprimees = cache.invalider(req.body?.prefixe || null);
  return res.json({ message: 'Cache vidé.', entrees_supprimees: supprimees, etat: cache.statistiques() });
}

/**
 * POST /super-admin/outils/taches/:tache
 * Relance manuellement une tâche planifiée sans attendre le cron.
 *
 * Le secret n'est pas transmis par le navigateur : la route interne est
 * appelée avec le secret côté serveur. Faire transiter CRON_SECRET par le
 * front reviendrait à le publier.
 */
const TACHES = {
  abonnements: { chemin: '/jobs/abonnements', libelle: 'Échéances d\'abonnement' },
  calendrier: { chemin: '/jobs/calendrier', libelle: 'Rappels du calendrier' }
};

async function executerTache(req, res) {
  const definition = TACHES[req.params.tache];
  if (!definition) {
    return res.status(404).json({ message: `Tâche inconnue. Disponibles : ${Object.keys(TACHES).join(', ')}.` });
  }
  if (!process.env.CRON_SECRET) {
    return res.status(503).json({ message: 'CRON_SECRET non configuré : impossible de déclencher la tâche.' });
  }

  const base = process.env.API_BASE_INTERNE || `http://127.0.0.1:${process.env.PORT || 3000}`;
  const debut = Date.now();

  try {
    const reponse = await fetch(`${base}${definition.chemin}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-cron-secret': process.env.CRON_SECRET }
    });
    const corps = await reponse.json().catch(() => ({}));

    return res.status(reponse.ok ? 200 : 502).json({
      tache: definition.libelle,
      succes: reponse.ok,
      code_http: reponse.status,
      duree_ms: Date.now() - debut,
      resultat: corps
    });
  } catch (err) {
    return res.status(502).json({
      tache: definition.libelle, succes: false,
      message: err.message, duree_ms: Date.now() - debut
    });
  }
}

/** GET /super-admin/outils/taches — liste des tâches déclenchables. */
function listerTaches(req, res) {
  return res.json({
    taches: Object.entries(TACHES).map(([cle, d]) => ({ cle, libelle: d.libelle, chemin: d.chemin })),
    cron_secret_configure: Boolean(process.env.CRON_SECRET)
  });
}

/**
 * GET /super-admin/outils/logs
 * Les journaux applicatifs (`morgan`, `console.error`) partent vers la sortie
 * standard de l'hébergeur et ne sont pas relisibles depuis le processus. Ce
 * qu'on peut offrir, en revanche, c'est la trace des requêtes en erreur
 * conservée par le collecteur, et les dernières écritures du journal d'audit.
 */
async function consulterLogs(req, res) {
  const limite = Math.min(300, Math.max(10, parseInt(req.query.limite, 10) || 100));
  try {
    const audit = await runWithTenant(SUPER, (client) => lignes(client, `
      SELECT j.created_at, j.action, j.cible_type, j.metadata,
             e.nom AS ecole_nom, trim(concat_ws(' ', u.prenom, u.nom)) AS utilisateur
      FROM journal_activite j
      LEFT JOIN ecoles e ON e.id = j.ecole_id
      LEFT JOIN utilisateurs u ON u.id = j.utilisateur_id
      WHERE (j.metadata->>'reussite') = 'false' OR j.action LIKE 'super_admin.%'
      ORDER BY j.created_at DESC LIMIT $1`, [limite]));

    return res.json({
      erreurs_http: metriques.dernieresErreurs(limite),
      journal_anomalies: audit,
      note: "Les journaux bruts du processus (stdout) se consultent dans la console de l'hébergeur."
    });
  } catch (err) {
    console.error('Erreur consultation logs:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /super-admin/outils/recalculer
 * body: { ecole_id, periode_id }
 *
 * Le recalcul de classement est la seule écriture que cet espace autorise sur
 * des données pédagogiques, et elle est volontaire : le HANDOVER (§ 3, « valeurs
 * matérialisées ») documente que `bulletins.total`, `pourcentage` et
 * `classement` sont des colonnes stockées, mises à jour uniquement sur appel
 * explicite. Quand elles divergent, l'école ne peut rien y faire seule.
 *
 * Ce n'est pas une modification de note : aucune valeur saisie n'est touchée.
 * C'est le recalcul d'un agrégat à partir des notes existantes. L'opération
 * est journalisée sous son propre code d'action.
 */
/**
 * POST /super-admin/outils/recalculer
 *
 * Seule écriture sur donnée pédagogique tolérée dans tout cet espace, et elle
 * mérite sa justification. Le HANDOVER signale que `bulletins.total`,
 * `pourcentage` et `classement` sont des valeurs MATÉRIALISÉES : elles ne se
 * recalculent pas à la lecture, uniquement quand `recalculerClassement()` est
 * appelée. Un bulletin figé sur des chiffres faux se répare donc en relançant
 * ce calcul, et par rien d'autre.
 *
 * Ce n'est pas une saisie : aucune note n'est touchée, seuls des agrégats déjà
 * dérivés d'elles sont reconstruits à partir des mêmes notes. L'opération est
 * journalisée sous une action qui la distingue d'un recalcul déclenché par le
 * Directeur.
 */
async function recalculerBulletins(req, res) {
  const { ecole_id, periode_id, classe_id } = req.body || {};
  if (!ecole_id || !periode_id) {
    return res.status(400).json({ message: 'ecole_id et periode_id sont requis.' });
  }

  try {
    const notesCtrl = require('./notes.controller');
    if (typeof notesCtrl.recalculerClassement !== 'function') {
      return res.status(501).json({
        message: "La fonction de recalcul n'est pas exposée par notes.controller.js. Recalcul à lancer depuis l'espace Directeur."
      });
    }

    const resultat = await runWithTenant({ isSuperAdmin: true, ecoleId: ecole_id }, async (client) => {
      // `recalculerClassement(client, classeId, periodeId)` traite UNE classe :
      // un classement n'a de sens qu'à l'intérieur d'une classe. Sans classe
      // précisée, on parcourt donc toutes celles de l'école pour l'année
      // scolaire à laquelle la période appartient.
      //
      // Les classes ne se déduisent PAS de la table `bulletins` : celle-ci ne
      // porte pas de colonne `classe_id` (elle stocke ecole_id, eleve_id,
      // periode_id et les valeurs calculées). Le rattachement passe par les
      // élèves, puis par l'année scolaire de la période.
      let classes;
      if (classe_id) {
        classes = [{ id: classe_id }];
      } else {
        const trouvees = await client.query(
          `SELECT c.id
             FROM classes c
             JOIN periodes p ON p.id = $2::uuid
            WHERE c.ecole_id = $1::uuid
              AND c.annee_scolaire_id = p.annee_scolaire_id
              AND EXISTS (SELECT 1 FROM eleves e WHERE e.classe_id = c.id)
            ORDER BY c.nom`,
          [ecole_id, periode_id]
        );
        classes = trouvees.rows;
      }

      if (!classes.length) {
        return { classes_traitees: 0, echecs: [], message: 'Aucune classe à recalculer sur cette période.' };
      }

      // Une classe dont le recalcul échoue ne doit pas empêcher les autres
      // d'aboutir : on relève l'échec et on continue.
      const echecs = [];
      let traitees = 0;
      for (const classe of classes) {
        try {
          await notesCtrl.recalculerClassement(client, classe.id, periode_id);
          traitees += 1;
        } catch (err) {
          echecs.push({ classe_id: classe.id, message: err.message });
        }
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
         VALUES ($1, $2, 'super_admin.recalcul_bulletins', 'periode', $3, $4::jsonb)`,
        [
          ecole_id,
          req.auth.userId,
          periode_id,
          JSON.stringify({
            source: 'super_admin',
            classes_traitees: traitees,
            echecs: echecs.length,
            reussite: echecs.length === 0
          })
        ]
      );

      return { classes_traitees: traitees, echecs };
    });

    return res.json({ message: 'Recalcul effectué.', ...resultat });
  } catch (err) {
    console.error('Erreur recalcul:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

module.exports = {
  sante, securite,
  listerSauvegardes, lancerSauvegarde, telechargerSauvegarde,
  obtenirConfiguration, modifierConfiguration,
  statistiquesIA,
  testEmail, testNotification, testWhatsApp,
  viderCache, listerTaches, executerTache, consulterLogs, recalculerBulletins
};
