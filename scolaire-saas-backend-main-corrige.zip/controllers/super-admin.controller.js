const os = require('os');
const { runWithTenant } = require('../config/db');
const cache = require('../utils/cache.utils');
const metriques = require('../middleware/metriques.middleware');
const {
  mesurer, lignes, pagination, trierParmi,
  reponsePaginee, periode, motifRecherche
} = require('../utils/super-admin.utils');

/*
 * Espace Super Administrateur — pilotage.
 * ---------------------------------------------------------------------------
 * Tout ce fichier s'exécute sous `runWithTenant({ isSuperAdmin: true })` :
 * c'est le seul contexte où les policies RLS laissent voir plusieurs écoles à
 * la fois. Aucune requête d'écriture sur les données pédagogiques n'y figure,
 * et c'est vérifiable à la lecture : ce fichier ne contient ni INSERT, ni
 * UPDATE, ni DELETE sur une table métier.
 */

const SUPER = { isSuperAdmin: true };

/* ==========================================================================
   1. Tableau de bord
   ========================================================================== */

/**
 * GET /super-admin/tableau-de-bord
 *
 * Une trentaine d'indicateurs hétérogènes. Chacun passe par `mesurer()` : un
 * indicateur en échec vaut `null` et l'interface affiche « — », le reste du
 * tableau de bord s'affiche normalement. C'est délibéré — un tableau de bord
 * de supervision qui tombe entièrement parce qu'une table manque est
 * exactement l'outil dont on ne dispose plus le jour où on en a besoin.
 */
async function tableauDeBord(req, res) {
  try {
    const donnees = await cache.memoiser('sa:tdb', 45, () =>
      runWithTenant(SUPER, async (client) => {
        const [
          nbEcoles, ecolesActives, ecolesSuspendues, ecolesEssai,
          nbEleves, nbProfesseurs, nbParents, nbUtilisateurs,
          sessionsOuvertes, connexionsAujourdhui, connexions7j,
          bulletinsGeneres, bulletinsMois,
          paiementsConfirmes, revenuTotal, revenuMois,
          nbDocuments, nbClasses, nbNotes,
          abonnementsExpirantBientot, abonnementsExpires,
          bugsOuverts, ticketsOuverts, derniereSauvegarde,
          appelsIaMois
        ] = await Promise.all([
          mesurer(client, `SELECT count(*) FROM ecoles`),
          mesurer(client, `SELECT count(*) FROM ecoles WHERE statut = 'actif'`),
          mesurer(client, `SELECT count(*) FROM ecoles WHERE statut = 'suspendu'`),
          mesurer(client, `SELECT count(*) FROM abonnements WHERE en_periode_essai = true AND statut <> 'expire'`),

          mesurer(client, `SELECT count(*) FROM eleves WHERE statut = 'actif'`),
          mesurer(client, `SELECT count(DISTINCT ur.utilisateur_id) FROM utilisateur_roles ur
                           WHERE ur.role::text IN ('professeur','titulaire')`),
          mesurer(client, `SELECT count(DISTINCT ur.utilisateur_id) FROM utilisateur_roles ur
                           WHERE ur.role::text = 'parent'`),
          mesurer(client, `SELECT count(*) FROM utilisateurs WHERE ecole_id IS NOT NULL`),

          mesurer(client, `SELECT count(*) FROM sessions WHERE expire_at > now()`),
          mesurer(client, `SELECT count(*) FROM journal_activite
                           WHERE action = 'session.login' AND created_at::date = now()::date`),
          mesurer(client, `SELECT count(*) FROM journal_activite
                           WHERE action = 'session.login' AND created_at >= now() - interval '7 days'`),

          mesurer(client, `SELECT count(*) FROM bulletins`),
          mesurer(client, `SELECT count(*) FROM bulletins WHERE created_at >= date_trunc('month', now())`),

          mesurer(client, `SELECT count(*) FROM paiements WHERE statut = 'confirme'`),
          mesurer(client, `SELECT COALESCE(sum(montant),0) FROM paiements WHERE statut = 'confirme'`),
          mesurer(client, `SELECT COALESCE(sum(montant),0) FROM paiements
                           WHERE statut = 'confirme' AND date_paiement >= date_trunc('month', now())`),

          mesurer(client, `SELECT count(*) FROM documents`),
          mesurer(client, `SELECT count(*) FROM classes`),
          mesurer(client, `SELECT count(*) FROM notes`),

          mesurer(client, `SELECT count(*) FROM abonnements
                           WHERE statut = 'actif' AND date_expiration BETWEEN now() AND now() + interval '14 days'`),
          mesurer(client, `SELECT count(*) FROM abonnements WHERE statut IN ('expire','suspendu')`),

          mesurer(client, `SELECT count(*) FROM bugs_plateforme WHERE statut IN ('ouvert','en_cours')`),
          mesurer(client, `SELECT count(*) FROM tickets_support WHERE statut NOT IN ('resolu','ferme')`),
          mesurer(client, `SELECT max(terminee_at) FROM sauvegardes WHERE statut = 'reussie'`),

          mesurer(client, `SELECT COALESCE(sum(nb_appels),0) FROM ia_utilisations
                           WHERE mois = to_char(now(), 'YYYY-MM')`)
        ]);

        // Courbes d'évolution sur 30 jours. `generate_series` garantit une
        // valeur par jour, y compris les jours sans activité : sans lui, un
        // graphe sauterait les week-ends et donnerait une croissance fausse.
        const [evolutionEcoles, evolutionConnexions, evolutionPaiements, evolutionEleves] = await Promise.all([
          lignes(client, `
            WITH jours AS (
              SELECT generate_series(now()::date - interval '29 days', now()::date, interval '1 day')::date AS jour
            )
            SELECT j.jour,
                   (SELECT count(*) FROM ecoles e WHERE e.created_at::date <= j.jour) AS valeur
            FROM jours j ORDER BY j.jour`),
          lignes(client, `
            WITH jours AS (
              SELECT generate_series(now()::date - interval '29 days', now()::date, interval '1 day')::date AS jour
            )
            SELECT j.jour, COALESCE(count(a.id), 0) AS valeur
            FROM jours j
            LEFT JOIN journal_activite a
              ON a.created_at::date = j.jour AND a.action = 'session.login'
            GROUP BY j.jour ORDER BY j.jour`),
          lignes(client, `
            WITH jours AS (
              SELECT generate_series(now()::date - interval '29 days', now()::date, interval '1 day')::date AS jour
            )
            SELECT j.jour, COALESCE(sum(p.montant), 0) AS valeur
            FROM jours j
            LEFT JOIN paiements p
              ON p.date_paiement::date = j.jour AND p.statut = 'confirme'
            GROUP BY j.jour ORDER BY j.jour`),
          lignes(client, `
            WITH jours AS (
              SELECT generate_series(now()::date - interval '29 days', now()::date, interval '1 day')::date AS jour
            )
            SELECT j.jour,
                   (SELECT count(*) FROM eleves e WHERE e.created_at::date <= j.jour) AS valeur
            FROM jours j ORDER BY j.jour`)
        ]);

        const alertes = await lignes(client, `
          SELECT 'abonnement' AS type, 'avertissement' AS niveau,
                 e.nom AS libelle,
                 'Abonnement expire le ' || to_char(a.date_expiration, 'DD/MM/YYYY') AS detail,
                 e.id AS ecole_id
          FROM abonnements a JOIN ecoles e ON e.id = a.ecole_id
          WHERE a.statut = 'actif' AND a.date_expiration BETWEEN now() AND now() + interval '14 days'
          UNION ALL
          SELECT 'ecole', 'critique', e.nom, 'École suspendue', e.id
          FROM ecoles e WHERE e.statut = 'suspendu'
          UNION ALL
          SELECT 'inactivite', 'info', e.nom, 'Aucune connexion depuis 30 jours', e.id
          FROM ecoles e
          WHERE e.statut = 'actif'
            AND NOT EXISTS (
              SELECT 1 FROM journal_activite j
              WHERE j.ecole_id = e.id AND j.action = 'session.login'
                AND j.created_at >= now() - interval '30 days'
            )
          LIMIT 40`);

        return {
          ecoles: {
            total: nbEcoles, actives: ecolesActives, suspendues: ecolesSuspendues,
            en_essai: ecolesEssai,
            abonnements_expirant: abonnementsExpirantBientot,
            abonnements_expires: abonnementsExpires
          },
          personnes: {
            eleves: nbEleves, professeurs: nbProfesseurs,
            parents: nbParents, utilisateurs: nbUtilisateurs
          },
          activite: {
            sessions_ouvertes: sessionsOuvertes,
            connexions_aujourdhui: connexionsAujourdhui,
            connexions_7_jours: connexions7j,
            bulletins_generes: bulletinsGeneres,
            bulletins_ce_mois: bulletinsMois,
            classes: nbClasses,
            notes: nbNotes,
            appels_ia_ce_mois: appelsIaMois
          },
          finances: {
            paiements_confirmes: paiementsConfirmes,
            revenu_total: revenuTotal,
            revenu_ce_mois: revenuMois
          },
          systeme: etatSysteme(nbDocuments, derniereSauvegarde),
          supervision: { bugs_ouverts: bugsOuverts, tickets_ouverts: ticketsOuverts },
          courbes: {
            ecoles: normaliserCourbe(evolutionEcoles),
            connexions: normaliserCourbe(evolutionConnexions),
            paiements: normaliserCourbe(evolutionPaiements),
            eleves: normaliserCourbe(evolutionEleves)
          },
          alertes,
          genere_a: new Date().toISOString()
        };
      })
    );

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur tableau de bord super admin:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

function normaliserCourbe(rows) {
  return rows.map((r) => ({
    jour: r.jour instanceof Date ? r.jour.toISOString().slice(0, 10) : String(r.jour).slice(0, 10),
    valeur: Number(r.valeur) || 0
  }));
}

function etatSysteme(nbDocuments, derniereSauvegarde) {
  const api = metriques.resume(15);
  const memoire = process.memoryUsage();
  return {
    serveur: {
      etat: api.taux_erreur > 5 ? 'degrade' : 'operationnel',
      uptime_secondes: Math.round(process.uptime()),
      charge_1min: os.loadavg()[0],
      cpus: os.cpus().length,
      memoire_utilisee_mo: Math.round(memoire.rss / 1024 / 1024),
      memoire_totale_mo: Math.round(os.totalmem() / 1024 / 1024),
      node: process.version
    },
    api: {
      latence_moyenne_ms: api.latence_moyenne_ms,
      taux_erreur: api.taux_erreur,
      requetes_par_minute: api.requetes_par_minute
    },
    stockage: { documents: nbDocuments },
    derniere_sauvegarde: derniereSauvegarde
  };
}

/* ==========================================================================
   2. Écoles
   ========================================================================== */

const TRI_ECOLES = {
  nom: 'e.nom',
  creation: 'e.created_at',
  eleves: 'nb_eleves',
  utilisateurs: 'nb_utilisateurs',
  derniere_connexion: 'derniere_connexion',
  expiration: 'a.date_expiration',
  statut: 'e.statut'
};

/**
 * GET /super-admin/ecoles
 * Recherche, filtres (statut, plan, statut d'abonnement, cycle), tri, pagination.
 *
 * Les compteurs passent par des sous-requêtes latérales plutôt que par des
 * JOIN + GROUP BY : avec quatre agrégats sur quatre tables, le GROUP BY
 * multiplierait les lignes entre elles et gonflerait tous les totaux.
 */
async function listerEcoles(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { expression, sens, cle } = trierParmi(req, TRI_ECOLES, 'creation');
  const { recherche, statut, plan_id, statut_abonnement, type_enseignement } = req.query;

  const conditions = [];
  const params = [];

  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(e.nom ILIKE $${params.length} OR e.code ILIKE $${params.length}
                      OR COALESCE(e.ville,'') ILIKE $${params.length}
                      OR COALESCE(e.email,'') ILIKE $${params.length})`);
  }
  if (statut) { params.push(statut); conditions.push(`e.statut = $${params.length}`); }
  if (type_enseignement) {
    params.push(type_enseignement);
    conditions.push(`e.type_enseignement::text = $${params.length}`);
  }
  if (plan_id) { params.push(plan_id); conditions.push(`a.plan_id = $${params.length}::uuid`); }
  if (statut_abonnement) { params.push(statut_abonnement); conditions.push(`a.statut = $${params.length}`); }

  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const base = `
        FROM ecoles e
        LEFT JOIN LATERAL (
          SELECT ab.plan_id, ab.statut, ab.date_expiration, ab.en_periode_essai
          FROM abonnements ab WHERE ab.ecole_id = e.id
          ORDER BY ab.created_at DESC LIMIT 1
        ) a ON true
        LEFT JOIN plans_abonnement p ON p.id = a.plan_id
        ${filtre}`;

      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT e.id, e.nom, e.code, e.ville, e.province, e.email, e.telephone,
               e.statut, e.type_enseignement::text AS type_enseignement, e.created_at,
               a.statut AS statut_abonnement, a.date_expiration, a.en_periode_essai,
               p.id AS plan_id, p.nom AS plan_nom, p.prix AS plan_prix, p.devise AS plan_devise,
               (SELECT count(*) FROM eleves x WHERE x.ecole_id = e.id AND x.statut = 'actif') AS nb_eleves,
               (SELECT count(*) FROM utilisateurs x WHERE x.ecole_id = e.id) AS nb_utilisateurs,
               (SELECT count(*) FROM classes x WHERE x.ecole_id = e.id) AS nb_classes,
               (SELECT count(*) FROM documents x WHERE x.ecole_id = e.id) AS nb_documents,
               (SELECT max(j.created_at) FROM journal_activite j
                WHERE j.ecole_id = e.id AND j.action = 'session.login') AS derniere_connexion
        ${base}
        ORDER BY ${expression} ${sens} NULLS LAST
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      return { total, donnees };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      tri: { cle, sens: sens.toLowerCase() }
    }));
  } catch (err) {
    console.error('Erreur liste écoles super admin:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /super-admin/ecoles/:id/statistiques
 * Fiche statistique complète d'une école, sans aucune donnée nominative
 * d'élève : ce sont des agrégats de pilotage, pas un dossier scolaire.
 */
async function statistiquesEcole(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const [general, effectifs, activite, finances, assiduite, reussite] = await Promise.all([
        lignes(client, `
          SELECT e.*, a.statut AS statut_abonnement, a.date_expiration, a.en_periode_essai,
                 p.nom AS plan_nom, p.prix AS plan_prix, p.devise AS plan_devise
          FROM ecoles e
          LEFT JOIN LATERAL (SELECT * FROM abonnements WHERE ecole_id = e.id ORDER BY created_at DESC LIMIT 1) a ON true
          LEFT JOIN plans_abonnement p ON p.id = a.plan_id
          WHERE e.id = $1`, [id]),

        lignes(client, `
          SELECT c.id, c.nom,
                 (SELECT count(*) FROM eleves x WHERE x.classe_id = c.id AND x.statut = 'actif') AS effectif
          FROM classes c WHERE c.ecole_id = $1 ORDER BY c.nom LIMIT 100`, [id]),

        lignes(client, `
          WITH jours AS (
            SELECT generate_series(now()::date - interval '29 days', now()::date, interval '1 day')::date AS jour
          )
          SELECT j.jour, COALESCE(count(a.id), 0) AS valeur
          FROM jours j
          LEFT JOIN journal_activite a ON a.created_at::date = j.jour AND a.ecole_id = $1
          GROUP BY j.jour ORDER BY j.jour`, [id]),

        // Les frais encaissés par l'école auprès des familles — et non les
        // paiements d'abonnement qu'elle verse à Ardoise. C'est l'activité de
        // l'établissement qu'on regarde ici, pas sa facturation ; les revenus
        // de la plateforme ont leur place dans « Abonnements ».
        lignes(client, `
          SELECT to_char(date_trunc('month', pf.date_paiement), 'YYYY-MM') AS mois,
                 sum(pf.montant) AS montant, count(*) AS nb
          FROM paiements_frais pf
          WHERE pf.ecole_id = $1
          GROUP BY 1 ORDER BY 1 DESC LIMIT 12`, [id]),

        lignes(client, `
          SELECT count(*) FILTER (WHERE statut::text = 'present') AS presents,
                 count(*) FILTER (WHERE statut::text = 'absent')  AS absents,
                 count(*) FILTER (WHERE statut::text = 'retard')  AS retards,
                 count(*) AS total
          FROM presences WHERE ecole_id = $1 AND date >= now()::date - interval '90 days'`, [id]),

        lignes(client, `
          SELECT count(*) AS total,
                 count(*) FILTER (WHERE pourcentage >= 50) AS reussites,
                 round(avg(pourcentage)::numeric, 2) AS moyenne
          FROM bulletins WHERE ecole_id = $1 AND pourcentage IS NOT NULL`, [id])
      ]);

      if (!general.length) {
        throw Object.assign(new Error('École introuvable.'), { statusCode: 404 });
      }

      const a = assiduite[0] || {};
      const r = reussite[0] || {};
      const totalPresences = Number(a.total) || 0;
      const totalBulletins = Number(r.total) || 0;

      return {
        ecole: general[0],
        classes: effectifs.map((c) => ({ ...c, effectif: Number(c.effectif) })),
        activite_30_jours: normaliserCourbe(activite),
        finances_par_mois: finances.map((f) => ({ ...f, montant: Number(f.montant), nb: Number(f.nb) })),
        assiduite: {
          ...a,
          taux_presence: totalPresences ? Math.round((Number(a.presents) / totalPresences) * 1000) / 10 : null,
          taux_absence: totalPresences ? Math.round((Number(a.absents) / totalPresences) * 1000) / 10 : null
        },
        reussite: {
          ...r,
          taux_reussite: totalBulletins ? Math.round((Number(r.reussites) / totalBulletins) * 1000) / 10 : null
        }
      };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur statistiques école:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /super-admin/abonnements
 * Vue transversale : quel plan, quelle échéance, quel revenu, quelle école.
 */
async function abonnements(req, res) {
  const { page, taille, decalage } = pagination(req, 25);
  const { statut, plan_id, recherche } = req.query;

  const conditions = [];
  const params = [];
  if (statut) { params.push(statut); conditions.push(`a.statut = $${params.length}`); }
  if (plan_id) { params.push(plan_id); conditions.push(`a.plan_id = $${params.length}::uuid`); }
  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    conditions.push(`(e.nom ILIKE $${params.length} OR e.code ILIKE $${params.length})`);
  }
  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const base = `FROM abonnements a
                    JOIN ecoles e ON e.id = a.ecole_id
                    LEFT JOIN plans_abonnement p ON p.id = a.plan_id
                    ${filtre}`;
      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT a.id, a.statut, a.date_debut, a.date_expiration, a.en_periode_essai,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code, e.statut AS ecole_statut,
               p.id AS plan_id, p.nom AS plan_nom, p.prix, p.devise, p.duree_jours,
               (a.date_expiration::date - now()::date) AS jours_restants,
               (SELECT COALESCE(sum(x.montant),0) FROM paiements x
                WHERE x.ecole_id = e.id AND x.statut = 'confirme') AS revenu_cumule
        ${base}
        ORDER BY a.date_expiration ASC NULLS LAST
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      const repartition = await lignes(client, `
        SELECT p.nom AS plan_nom, count(*) AS nb,
               COALESCE(sum(p.prix), 0) AS revenu_theorique
        FROM abonnements a
        LEFT JOIN plans_abonnement p ON p.id = a.plan_id
        WHERE a.statut = 'actif'
        GROUP BY p.nom ORDER BY nb DESC`);

      return { total, donnees, repartition };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      repartition_par_plan: resultat.repartition
    }));
  } catch (err) {
    console.error('Erreur abonnements:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   3. Utilisateurs (tous comptes, toutes écoles)
   ========================================================================== */

const TRI_UTILISATEURS = {
  nom: `trim(concat(u.prenom, ' ', u.nom))`,
  creation: 'u.created_at',
  ecole: 'e.nom',
  derniere_connexion: 'derniere_connexion',
  statut: 'u.statut'
};

/**
 * GET /super-admin/utilisateurs
 *
 * `array_agg` sur les rôles plutôt qu'un JOIN simple : un utilisateur
 * Professeur + Titulaire apparaîtrait deux fois dans la liste, et la
 * pagination compterait deux personnes là où il n'y en a qu'une.
 */
async function listerUtilisateurs(req, res) {
  const { page, taille, decalage } = pagination(req, 30);
  const { expression, sens, cle } = trierParmi(req, TRI_UTILISATEURS, 'creation');
  const { recherche, role, ecole_id, statut, bloques } = req.query;

  const conditions = [];
  const params = [];

  if (recherche && String(recherche).trim()) {
    params.push(motifRecherche(recherche));
    const p = `$${params.length}`;
    conditions.push(`(u.nom ILIKE ${p} OR u.prenom ILIKE ${p} OR u.email ILIKE ${p}
                      OR COALESCE(u.telephone,'') ILIKE ${p})`);
  }
  if (ecole_id) { params.push(ecole_id); conditions.push(`u.ecole_id = $${params.length}::uuid`); }
  if (statut) { params.push(statut); conditions.push(`u.statut = $${params.length}`); }
  if (role) {
    params.push(role);
    conditions.push(`EXISTS (SELECT 1 FROM utilisateur_roles r
                             WHERE r.utilisateur_id = u.id AND r.role::text = $${params.length})`);
  }
  if (bloques === 'oui') conditions.push(`u.statut <> 'actif'`);

  const filtre = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const resultat = await runWithTenant(SUPER, async (client) => {
      const base = `FROM utilisateurs u LEFT JOIN ecoles e ON e.id = u.ecole_id ${filtre}`;
      const total = await mesurer(client, `SELECT count(*) ${base}`, params, 0);

      const params2 = [...params, taille, decalage];
      const donnees = await lignes(client, `
        SELECT u.id, u.nom, u.prenom, u.email, u.telephone, u.statut, u.created_at,
               COALESCE(u.doit_changer_mot_de_passe, false) AS mot_de_passe_provisoire,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code,
               COALESCE(
                 (SELECT array_agg(DISTINCT r.role::text) FROM utilisateur_roles r
                  WHERE r.utilisateur_id = u.id),
                 ARRAY[]::text[]
               ) AS roles,
               (SELECT max(j.created_at) FROM journal_activite j
                WHERE j.utilisateur_id = u.id AND j.action = 'session.login') AS derniere_connexion,
               (SELECT count(*) FROM sessions s
                WHERE s.utilisateur_id = u.id AND s.expire_at > now()) AS sessions_actives
        ${base}
        ORDER BY ${expression} ${sens} NULLS LAST
        LIMIT $${params2.length - 1} OFFSET $${params2.length}`, params2);

      const repartition = await lignes(client, `
        SELECT r.role::text AS role, count(DISTINCT r.utilisateur_id) AS nb
        FROM utilisateur_roles r GROUP BY 1 ORDER BY nb DESC`);

      return { total, donnees, repartition };
    });

    return res.json(reponsePaginee({ page, taille }, resultat.total, resultat.donnees, {
      tri: { cle, sens: sens.toLowerCase() },
      repartition_par_role: resultat.repartition
    }));
  } catch (err) {
    console.error('Erreur liste utilisateurs super admin:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/** GET /super-admin/utilisateurs/:id — fiche compte, en lecture seule. */
async function detailUtilisateur(req, res) {
  const { id } = req.params;
  try {
    const donnees = await runWithTenant(SUPER, async (client) => {
      const compte = await lignes(client, `
        SELECT u.id, u.nom, u.prenom, u.email, u.telephone, u.statut, u.created_at,
               COALESCE(u.doit_changer_mot_de_passe, false) AS mot_de_passe_provisoire,
               e.id AS ecole_id, e.nom AS ecole_nom, e.code AS ecole_code,
               COALESCE((SELECT array_agg(DISTINCT r.role::text) FROM utilisateur_roles r
                         WHERE r.utilisateur_id = u.id), ARRAY[]::text[]) AS roles
        FROM utilisateurs u LEFT JOIN ecoles e ON e.id = u.ecole_id
        WHERE u.id = $1`, [id]);

      if (!compte.length) throw Object.assign(new Error('Compte introuvable.'), { statusCode: 404 });

      const [sessions, actionsRecentes] = await Promise.all([
        lignes(client, `
          SELECT id, user_agent, ip, created_at, expire_at,
                 (expire_at > now()) AS active
          FROM sessions WHERE utilisateur_id = $1
          ORDER BY created_at DESC LIMIT 20`, [id]),
        lignes(client, `
          SELECT action, cible_type, created_at, metadata
          FROM journal_activite WHERE utilisateur_id = $1
          ORDER BY created_at DESC LIMIT 50`, [id])
      ]);

      return { compte: compte[0], sessions, actions_recentes: actionsRecentes };
    });

    return res.json(donnees);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur détail utilisateur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   4. Recherche globale
   ========================================================================== */

/**
 * GET /super-admin/recherche?q=…
 *
 * Chaque famille est interrogée séparément avec sa propre LIMIT, puis les
 * résultats sont fusionnés côté application. Un vrai UNION SQL obligerait à
 * aligner sept structures de colonnes différentes et rendrait l'ajout d'une
 * huitième famille pénible — pour un gain nul, les sept requêtes partant en
 * parallèle sur la même connexion transactionnelle.
 *
 * Les recherches courtes sont refusées : « a » ramènerait la plateforme
 * entière et coûterait sept balayages complets.
 */
const FAMILLES_RECHERCHE = ['ecole', 'eleve', 'utilisateur', 'classe', 'bulletin', 'paiement'];

async function rechercheGlobale(req, res) {
  const q = String(req.query.q || '').trim();
  const familles = String(req.query.familles || '')
    .split(',').map((f) => f.trim()).filter((f) => FAMILLES_RECHERCHE.includes(f));
  const cibles = familles.length ? familles : FAMILLES_RECHERCHE;
  const limite = Math.min(25, Math.max(3, parseInt(req.query.limite, 10) || 8));

  if (q.length < 2) {
    return res.json({ resultats: [], total: 0, message: 'Saisissez au moins 2 caractères.' });
  }

  const motif = motifRecherche(q);

  try {
    const debut = Date.now();
    const resultats = await runWithTenant(SUPER, async (client) => {
      const requetes = {
        ecole: () => lignes(client, `
          SELECT 'ecole' AS famille, e.id, e.nom AS titre,
                 concat_ws(' · ', e.code, e.ville, e.statut) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM ecoles e
          WHERE e.nom ILIKE $1 OR e.code ILIKE $1 OR COALESCE(e.ville,'') ILIKE $1
          ORDER BY e.nom LIMIT $2`, [motif, limite]),

        eleve: () => lignes(client, `
          SELECT 'eleve' AS famille, el.id,
                 trim(concat_ws(' ', el.nom, el.postnom, el.prenom)) AS titre,
                 concat_ws(' · ', el.matricule, c.nom) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM eleves el
          JOIN ecoles e ON e.id = el.ecole_id
          LEFT JOIN classes c ON c.id = el.classe_id
          WHERE el.nom ILIKE $1 OR COALESCE(el.postnom,'') ILIKE $1
             OR COALESCE(el.prenom,'') ILIKE $1 OR COALESCE(el.matricule,'') ILIKE $1
          ORDER BY el.nom LIMIT $2`, [motif, limite]),

        utilisateur: () => lignes(client, `
          SELECT 'utilisateur' AS famille, u.id,
                 trim(concat_ws(' ', u.prenom, u.nom)) AS titre,
                 concat_ws(' · ', u.email,
                   (SELECT string_agg(r.role::text, ', ') FROM utilisateur_roles r
                    WHERE r.utilisateur_id = u.id)) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM utilisateurs u LEFT JOIN ecoles e ON e.id = u.ecole_id
          WHERE u.nom ILIKE $1 OR COALESCE(u.prenom,'') ILIKE $1 OR u.email ILIKE $1
             OR COALESCE(u.telephone,'') ILIKE $1
          ORDER BY u.nom LIMIT $2`, [motif, limite]),

        classe: () => lignes(client, `
          SELECT 'classe' AS famille, c.id, c.nom AS titre,
                 concat_ws(' · ', an.libelle,
                   (SELECT count(*)::text || ' élèves' FROM eleves x
                    WHERE x.classe_id = c.id AND x.statut = 'actif')) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM classes c
          JOIN ecoles e ON e.id = c.ecole_id
          LEFT JOIN annees_scolaires an ON an.id = c.annee_scolaire_id
          WHERE c.nom ILIKE $1
          ORDER BY c.nom LIMIT $2`, [motif, limite]),

        bulletin: () => lignes(client, `
          SELECT 'bulletin' AS famille, b.id,
                 trim(concat_ws(' ', el.nom, el.prenom)) AS titre,
                 concat_ws(' · ', p.libelle,
                   COALESCE(round(b.pourcentage::numeric, 1)::text || ' %', 'non calculé')) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM bulletins b
          JOIN eleves el ON el.id = b.eleve_id
          JOIN ecoles e ON e.id = b.ecole_id
          LEFT JOIN periodes p ON p.id = b.periode_id
          WHERE el.nom ILIKE $1 OR COALESCE(el.matricule,'') ILIKE $1
          ORDER BY b.created_at DESC LIMIT $2`, [motif, limite]),

        paiement: () => lignes(client, `
          SELECT 'paiement' AS famille, pa.id,
                 concat(pa.montant::text, ' ', COALESCE(pa.methode, '')) AS titre,
                 concat_ws(' · ', pa.statut, to_char(pa.date_paiement, 'DD/MM/YYYY'),
                           COALESCE(pa.reference_externe, '')) AS sous_titre,
                 e.id AS ecole_id, e.nom AS ecole_nom
          FROM paiements pa JOIN ecoles e ON e.id = pa.ecole_id
          WHERE COALESCE(pa.reference_externe,'') ILIKE $1
             OR e.nom ILIKE $1 OR COALESCE(pa.methode,'') ILIKE $1
          ORDER BY pa.date_paiement DESC LIMIT $2`, [motif, limite])
      };

      const listes = await Promise.all(cibles.map((f) => requetes[f]()));
      return listes.flat();
    });

    const groupes = {};
    for (const r of resultats) {
      (groupes[r.famille] = groupes[r.famille] || []).push(r);
    }

    return res.json({
      requete: q,
      total: resultats.length,
      duree_ms: Date.now() - debut,
      groupes,
      resultats
    });
  } catch (err) {
    console.error('Erreur recherche globale:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   5. Analyses
   ========================================================================== */

/**
 * GET /super-admin/analyses?jours=90
 *
 * Toutes les séries sont mensuelles ou journalières selon la profondeur
 * demandée : au-delà de 120 jours, un point par jour produit un graphe
 * illisible et un transfert inutilement lourd.
 */
async function analyses(req, res) {
  const { jours } = periode(req, 90);
  const parMois = jours > 120;
  const ecoleId = req.query.ecole_id || null;

  try {
    const donnees = await cache.memoiser(`sa:analyses:${jours}:${ecoleId || 'toutes'}`, 120, () =>
      runWithTenant(SUPER, async (client) => {
        const grain = parMois ? 'month' : 'day';
        const format = parMois ? 'YYYY-MM' : 'YYYY-MM-DD';

        // Deux jeux de paramètres, et non un seul. PostgreSQL refuse une
        // requête à laquelle on fournit plus de paramètres qu'elle n'en
        // référence : passer [jours, ecoleId] à une requête qui n'utilise que
        // $1 la ferait échouer. Les séries filtrables par école reçoivent
        // `pFiltre`, les séries globales `pGlobal`.
        const pGlobal = [jours];
        const pFiltre = ecoleId ? [jours, ecoleId] : [jours];
        const clauseEcole = (colonne) => (ecoleId ? `AND ${colonne} = $2::uuid` : '');

        const serie = (sql, params) => lignes(client, sql, params || pGlobal);

        const [
          croissanceEcoles, inscriptions, paiementsSerie, activiteQuotidienne,
          connexionsParRole, frequentation, reussiteParEcole, absenceParEcole,
          utilisationModules, topEcoles
        ] = await Promise.all([
          serie(`
            SELECT to_char(date_trunc('${grain}', d.jour), '${format}') AS periode,
                   (SELECT count(*) FROM ecoles e WHERE e.created_at <= d.jour + interval '1 ${grain}') AS valeur
            FROM (SELECT generate_series(now() - ($1 || ' days')::interval, now(), '1 ${grain}'::interval) AS jour) d
            GROUP BY d.jour ORDER BY d.jour`),

          serie(`
            SELECT to_char(date_trunc('${grain}', el.created_at), '${format}') AS periode, count(*) AS valeur
            FROM eleves el
            WHERE el.created_at >= now() - ($1 || ' days')::interval
              ${clauseEcole('el.ecole_id')}
            GROUP BY 1 ORDER BY 1`, pFiltre),

          serie(`
            SELECT to_char(date_trunc('${grain}', pa.date_paiement), '${format}') AS periode,
                   COALESCE(sum(pa.montant), 0) AS valeur, count(*) AS nb
            FROM paiements pa
            WHERE pa.statut = 'confirme' AND pa.date_paiement >= now() - ($1 || ' days')::interval
              ${clauseEcole('pa.ecole_id')}
            GROUP BY 1 ORDER BY 1`, pFiltre),

          serie(`
            SELECT to_char(date_trunc('${grain}', j.created_at), '${format}') AS periode,
                   count(*) AS valeur,
                   count(*) FILTER (WHERE j.action = 'session.login') AS connexions,
                   count(DISTINCT j.utilisateur_id) AS utilisateurs_distincts
            FROM journal_activite j
            WHERE j.created_at >= now() - ($1 || ' days')::interval
              ${clauseEcole('j.ecole_id')}
            GROUP BY 1 ORDER BY 1`, pFiltre),

          serie(`
            SELECT r.role::text AS libelle, count(*) AS valeur
            FROM journal_activite j
            JOIN utilisateur_roles r ON r.utilisateur_id = j.utilisateur_id
            WHERE j.action = 'session.login' AND j.created_at >= now() - ($1 || ' days')::interval
              ${clauseEcole('j.ecole_id')}
            GROUP BY 1 ORDER BY valeur DESC`, pFiltre),

          serie(`
            SELECT to_char(date_trunc('${grain}', pr.date_jour), '${format}') AS periode,
                   count(*) FILTER (WHERE pr.statut::text = 'present') AS presents,
                   count(*) FILTER (WHERE pr.statut::text = 'absent') AS absents,
                   count(*) AS total
            FROM presences pr
            WHERE pr.date_jour >= (now() - ($1 || ' days')::interval)::date
              ${clauseEcole('pr.ecole_id')}
            GROUP BY 1 ORDER BY 1`, pFiltre),

          lignes(client, `
            SELECT e.nom AS ecole, count(*) AS bulletins,
                   count(*) FILTER (WHERE b.pourcentage >= 50) AS reussites,
                   round(avg(b.pourcentage)::numeric, 2) AS moyenne
            FROM bulletins b JOIN ecoles e ON e.id = b.ecole_id
            WHERE b.pourcentage IS NOT NULL
            GROUP BY e.nom HAVING count(*) >= 5
            ORDER BY moyenne DESC NULLS LAST LIMIT 20`),

          lignes(client, `
            SELECT e.nom AS ecole,
                   count(*) FILTER (WHERE pr.statut::text = 'absent') AS absences,
                   count(*) AS total,
                   round(100.0 * count(*) FILTER (WHERE pr.statut::text = 'absent')
                         / NULLIF(count(*), 0), 1) AS taux_absence
            FROM presences pr JOIN ecoles e ON e.id = pr.ecole_id
            WHERE pr.date_jour >= now()::date - interval '90 days'
            GROUP BY e.nom HAVING count(*) >= 20
            ORDER BY taux_absence DESC NULLS LAST LIMIT 20`),

          lignes(client, `
            SELECT split_part(j.action, '.', 1) AS module, count(*) AS valeur
            FROM journal_activite j
            WHERE j.created_at >= now() - interval '30 days'
            GROUP BY 1 ORDER BY valeur DESC LIMIT 15`),

          lignes(client, `
            SELECT e.nom AS ecole, e.id AS ecole_id,
                   (SELECT count(*) FROM eleves x WHERE x.ecole_id = e.id AND x.statut = 'actif') AS eleves,
                   (SELECT count(*) FROM journal_activite j
                    WHERE j.ecole_id = e.id AND j.created_at >= now() - interval '30 days') AS actions
            FROM ecoles e WHERE e.statut = 'actif'
            ORDER BY actions DESC LIMIT 15`)
        ]);

        return {
          profondeur_jours: jours,
          grain: parMois ? 'mois' : 'jour',
          croissance_ecoles: croissanceEcoles,
          inscriptions,
          paiements: paiementsSerie,
          activite_quotidienne: activiteQuotidienne,
          connexions_par_role: connexionsParRole,
          frequentation: frequentation.map((f) => ({
            ...f,
            taux_presence: Number(f.total)
              ? Math.round((Number(f.presents) / Number(f.total)) * 1000) / 10 : null
          })),
          taux_reussite_par_ecole: reussiteParEcole.map((r) => ({
            ...r,
            taux_reussite: Number(r.bulletins)
              ? Math.round((Number(r.reussites) / Number(r.bulletins)) * 1000) / 10 : null
          })),
          taux_absence_par_ecole: absenceParEcole,
          utilisation_modules: utilisationModules,
          ecoles_les_plus_actives: topEcoles
        };
      })
    );

    return res.json(donnees);
  } catch (err) {
    console.error('Erreur analyses:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/* ==========================================================================
   6. Référentiels (alimentent les filtres de l'interface)
   ========================================================================== */

/** GET /super-admin/referentiels */
async function referentiels(req, res) {
  try {
    const donnees = await cache.memoiser('sa:referentiels', 300, () =>
      runWithTenant(SUPER, async (client) => {
        const [ecoles, plans, roles, actions] = await Promise.all([
          lignes(client, `SELECT id, nom, code, statut FROM ecoles ORDER BY nom`),
          lignes(client, `SELECT id, nom, prix, devise, duree_jours FROM plans_abonnement ORDER BY prix`),
          lignes(client, `SELECT DISTINCT role::text AS role FROM utilisateur_roles ORDER BY 1`),
          lignes(client, `SELECT DISTINCT action FROM journal_activite ORDER BY 1 LIMIT 200`)
        ]);

        // Méthodes de paiement d'abonnement. Lues depuis le contrôleur qui
        // fait autorité plutôt que recopiées ici : une seule liste, donc
        // aucune divergence possible entre ce que l'interface propose et ce
        // que le serveur accepte.
        const { METHODES_PAIEMENT, METHODES_MANUELLES } = require('./abonnements.controller');
        const libelles = {
          especes: 'Espèces',
          virement_bancaire: 'Virement bancaire',
          cheque: 'Chèque',
          orange_money: 'Orange Money',
          airtel_money: 'Airtel Money',
          mpesa: 'M-Pesa'
        };
        const methodes_paiement = METHODES_PAIEMENT.map((cle) => ({
          cle,
          libelle: libelles[cle] || cle,
          // « manuel » signale à l'interface qu'une référence est exigée :
          // ces règlements ne laissent aucune trace ailleurs qu'ici.
          manuel: METHODES_MANUELLES.includes(cle)
        }));

        return { ecoles, plans, roles, actions, methodes_paiement };
      })
    );
    return res.json(donnees);
  } catch (err) {
    console.error('Erreur référentiels:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  tableauDeBord,
  listerEcoles,
  statistiquesEcole,
  abonnements,
  listerUtilisateurs,
  detailUtilisateur,
  rechercheGlobale,
  analyses,
  referentiels
};
