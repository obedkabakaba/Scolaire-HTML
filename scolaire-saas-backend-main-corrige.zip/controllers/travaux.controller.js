const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

async function professeurOuDirectionAutorise(client, req, classeCoursId) {
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r))) return true;
  const result = await client.query(
    `SELECT 1 FROM enseignant_cours WHERE utilisateur_id = $1 AND classe_cours_id = $2`,
    [req.auth.userId, classeCoursId]
  );
  return result.rows.length > 0;
}

/**
 * GET /travaux?classeCoursId=&periodeId=
 * Liste les travaux (interrogations/devoirs) déjà créés pour ce cours+période,
 * avec le total de leurs maximums et le maximum du cours pour comparaison.
 */
async function lister(req, res) {
  const { classeCoursId, periodeId } = req.query;
  if (!classeCoursId || !periodeId) {
    return res.status(400).json({ message: 'classeCoursId et periodeId sont requis.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const autorise = await professeurOuDirectionAutorise(client, req, classeCoursId);
      if (!autorise) throw Object.assign(new Error("Vous n'êtes pas affecté à ce cours."), { statusCode: 403 });

      const maxCoursResult = await client.query(
        `SELECT COALESCE(cc.maximum_points_override, c.maximum_points) AS maximum
         FROM classe_cours cc JOIN cours c ON c.id = cc.cours_id WHERE cc.id = $1`,
        [classeCoursId]
      );
      const maximumCours = Number(maxCoursResult.rows[0]?.maximum || 0);

      const travauxResult = await client.query(
        `SELECT id, nom, maximum_points, ordre FROM travaux
         WHERE classe_cours_id = $1 AND periode_id = $2 ORDER BY ordre, created_at`,
        [classeCoursId, periodeId]
      );

      const sommeMaximums = travauxResult.rows.reduce((acc, t) => acc + Number(t.maximum_points), 0);

      return { travaux: travauxResult.rows, maximum_cours: maximumCours, somme_maximums: sommeMaximums };
    });

    return res.json(resultat);
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur liste travaux:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /travaux
 * body: { classe_cours_id, periode_id, nom, maximum_points }
 */
async function creer(req, res) {
  const { classe_cours_id, periode_id, nom, maximum_points } = req.body;
  if (!classe_cours_id || !periode_id || !nom || maximum_points === undefined || maximum_points === null || maximum_points === '') {
    return res.status(400).json({ message: 'classe_cours_id, periode_id, nom et maximum_points sont requis.' });
  }
  const maximumNum = Number(maximum_points);
  if (Number.isNaN(maximumNum) || maximumNum <= 0) {
    return res.status(400).json({ message: 'Le maximum du travail doit être un nombre strictement supérieur à 0.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const autorise = await professeurOuDirectionAutorise(client, req, classe_cours_id);
      if (!autorise) throw Object.assign(new Error("Vous n'êtes pas affecté à ce cours."), { statusCode: 403 });

      // Un cours déjà verrouillé (soumis) pour cette période ne peut plus recevoir de nouveaux travaux
      const verrouResult = await client.query(
        `SELECT 1 FROM notes WHERE classe_cours_id = $1 AND periode_id = $2 AND valide = true LIMIT 1`,
        [classe_cours_id, periode_id]
      );
      if (verrouResult.rows.length > 0) {
        throw Object.assign(new Error('Ces notes sont déjà soumises et verrouillées.'), { statusCode: 403 });
      }

      const ordreResult = await client.query(
        `SELECT COALESCE(MAX(ordre), -1) + 1 AS prochain FROM travaux WHERE classe_cours_id = $1 AND periode_id = $2`,
        [classe_cours_id, periode_id]
      );

      const inserted = await client.query(
        `INSERT INTO travaux (ecole_id, classe_cours_id, periode_id, nom, maximum_points, ordre)
         VALUES (${CURRENT_ECOLE}, $1,$2,$3,$4,$5) RETURNING id`,
        [classe_cours_id, periode_id, nom, maximumNum, ordreResult.rows[0].prochain]
      );
      return inserted.rows[0].id;
    });

    return res.status(201).json({ id: resultat });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur création travail:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /travaux/:id
 */
async function supprimer(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      const travailResult = await client.query(`SELECT classe_cours_id, periode_id FROM travaux WHERE id = $1`, [id]);
      if (travailResult.rows.length === 0) return;
      const travail = travailResult.rows[0];
      const autorise = await professeurOuDirectionAutorise(client, req, travail.classe_cours_id);
      if (!autorise) throw Object.assign(new Error("Vous n'êtes pas affecté à ce cours."), { statusCode: 403 });

      // Même verrou qu'à la création : une fois les notes soumises/verrouillées pour
      // cette période, la structure des travaux ne doit plus bouger (sinon les totaux
      // verrouillés ne correspondraient plus à rien). Directeur/Préfet gardent la main.
      const estDirection = req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet'].includes(r));
      if (!estDirection) {
        const verrouResult = await client.query(
          `SELECT 1 FROM notes WHERE classe_cours_id = $1 AND periode_id = $2 AND valide = true LIMIT 1`,
          [travail.classe_cours_id, travail.periode_id]
        );
        if (verrouResult.rows.length > 0) {
          throw Object.assign(new Error('Ces notes sont déjà soumises et verrouillées : ce travail ne peut plus être supprimé.'), { statusCode: 403 });
        }
      }

      await client.query(`DELETE FROM travaux WHERE id = $1`, [id]);
    });
    res.json({ message: 'Travail supprimé.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur suppression travail:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { lister, creer, supprimer };
