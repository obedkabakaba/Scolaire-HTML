const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { uploaderVersStorage } = require('../utils/supabase-storage.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Nettoie strictement un segment de chemin (lettres, chiffres, tiret, underscore
 * uniquement) — élimine toute possibilité de caractère qui ferait échouer
 * Supabase Storage avec "Invalid path specified in request URL", quelle que
 * soit son origine exacte (espace, accent, caractère spécial, valeur vide...).
 */
function nettoyerSegmentChemin(valeur) {
  return String(valeur || 'inconnu').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]/g, '-').replace(/-+/g, '-').slice(0, 80) || 'inconnu';
}

function nomFichierUnique(nomOriginal) {
  const partie = String(nomOriginal || '').split('.');
  const extensionBrute = partie.length > 1 ? partie.pop() : 'bin';
  const extension = extensionBrute.replace(/[^a-zA-Z0-9]/g, '').slice(0, 10) || 'bin';
  return `${Date.now()}-${Math.round(Math.random() * 1e6)}.${extension}`;
}

/**
 * POST /uploads/logo-ecole   (multipart, champ "fichier")
 * Upload le logo et met à jour ecoles.logo_url pour l'école courante.
 */
async function uploaderLogoEcole(req, res) {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu (champ "fichier").' });

  try {
    const chemin = `ecoles/${nettoyerSegmentChemin(req.auth.ecoleId)}/logo/${nomFichierUnique(req.file.originalname)}`;
    const url = await uploaderVersStorage(req.file.buffer, chemin, req.file.mimetype);

    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(`UPDATE ecoles SET logo_url = $1 WHERE id = ${CURRENT_ECOLE}`, [url])
    );

    return res.json({ url });
  } catch (err) {
    console.error('Erreur upload logo école:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /uploads/image-site   (multipart, champ "fichier")
 * Image destinée à la vitrine publique : couverture, galerie, portrait
 * d'un membre de l'équipe. L'URL est renvoyée, l'appelant décide où la ranger
 * dans la configuration du site.
 */
async function uploaderImageSite(req, res) {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu (champ "fichier").' });

  if (!/^image\//.test(req.file.mimetype || '')) {
    return res.status(400).json({ message: 'Seules les images sont acceptées.' });
  }

  try {
    const chemin = `ecoles/${nettoyerSegmentChemin(req.auth.ecoleId)}/site/${nomFichierUnique(req.file.originalname)}`;
    const url = await uploaderVersStorage(req.file.buffer, chemin, req.file.mimetype);
    return res.json({ url });
  } catch (err) {
    console.error('Erreur upload image site:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /uploads/photo-eleve/:eleveId   (multipart, champ "fichier")
 */
async function uploaderPhotoEleve(req, res) {
  const { eleveId } = req.params;
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu (champ "fichier").' });

  try {
    const chemin = `ecoles/${nettoyerSegmentChemin(req.auth.ecoleId)}/eleves/${nettoyerSegmentChemin(eleveId)}/${nomFichierUnique(req.file.originalname)}`;
    const url = await uploaderVersStorage(req.file.buffer, chemin, req.file.mimetype);

    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('UPDATE eleves SET photo_url = $1 WHERE id = $2', [url, eleveId])
    );

    return res.json({ url });
  } catch (err) {
    console.error('Erreur upload photo élève:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /uploads/photo-utilisateur/:utilisateurId   (multipart, champ "fichier")
 */
async function uploaderPhotoUtilisateur(req, res) {
  const { utilisateurId } = req.params;
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu (champ "fichier").' });

  const estSoiMeme = req.auth.userId === utilisateurId;
  const estDirecteur = req.auth.roles.includes('directeur') || req.auth.isSuperAdmin;
  if (!estSoiMeme && !estDirecteur) {
    return res.status(403).json({ message: "Tu ne peux modifier que ta propre photo." });
  }

  try {
    const chemin = `ecoles/${nettoyerSegmentChemin(req.auth.ecoleId)}/utilisateurs/${nettoyerSegmentChemin(utilisateurId)}/${nomFichierUnique(req.file.originalname)}`;
    const url = await uploaderVersStorage(req.file.buffer, chemin, req.file.mimetype);

    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('UPDATE utilisateurs SET photo_url = $1 WHERE id = $2', [url, utilisateurId])
    );

    return res.json({ url });
  } catch (err) {
    console.error('Erreur upload photo utilisateur:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * POST /uploads/document   (multipart, champ "fichier" + champ texte "type")
 * Usage générique : cachet de l'école, signature scannée, modèle de bulletin importé, etc.
 * Enregistre une ligne dans `documents` et renvoie son URL.
 */
async function uploaderDocument(req, res) {
  const { type } = req.body;
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier reçu (champ "fichier").' });
  if (!type) return res.status(400).json({ message: 'Le champ "type" est requis (ex: cachet, signature, modele_bulletin).' });

  const estDirecteurOuAdmin = req.auth.isSuperAdmin || req.auth.roles.includes('directeur');
  if (!estDirecteurOuAdmin && type !== 'signature') {
    return res.status(403).json({ message: 'Seul le directeur peut téléverser ce type de document.' });
  }

  try {
    const chemin = `ecoles/${nettoyerSegmentChemin(req.auth.ecoleId)}/documents/${nettoyerSegmentChemin(type)}/${nomFichierUnique(req.file.originalname)}`;
    const url = await uploaderVersStorage(req.file.buffer, chemin, req.file.mimetype);

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `INSERT INTO documents (ecole_id, type, url, uploaded_by)
         VALUES (${CURRENT_ECOLE}, $1, $2, $3) RETURNING id`,
        [type, url, req.auth.userId]
      )
    );

    return res.status(201).json({ id: result.rows[0].id, url });
  } catch (err) {
    console.error('Erreur upload document:', err);
    return res.status(500).json({ message: err.message || 'Erreur serveur.' });
  }
}

/**
 * GET /uploads/documents?type=cachet
 * Renvoie le document le plus récent d'un type donné (ex: cachet, signature)
 * pour l'école courante, pour afficher un aperçu côté frontend.
 */
async function obtenirDernierDocument(req, res) {
  const { type, mine } = req.query;
  if (!type) return res.status(400).json({ message: 'type requis.' });

  try {
    const conditions = [`ecole_id = ${CURRENT_ECOLE}`, `type = $1`];
    const params = [type];
    if (mine === 'true') {
      params.push(req.auth.userId);
      conditions.push(`uploaded_by = $${params.length}`);
    }

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT url FROM documents WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT 1`,
        params
      )
    );
    return res.json(result.rows[0] || null);
  } catch (err) {
    console.error('Erreur lecture document:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /uploads/document?type=signature&mine=true
 * Supprime le(s) document(s) de ce type. Avec mine=true, ne supprime que ceux
 * de l'utilisateur connecté (ex: sa propre signature) ; sinon (Directeur),
 * supprime le document générique de l'école pour ce type.
 */
async function supprimerDocument(req, res) {
  const { type, mine } = req.query;
  if (!type) return res.status(400).json({ message: 'type requis.' });

  try {
    const conditions = [`ecole_id = ${CURRENT_ECOLE}`, `type = $1`];
    const params = [type];
    if (mine === 'true') {
      params.push(req.auth.userId);
      conditions.push(`uploaded_by = $${params.length}`);
    } else if (!req.auth.roles.includes('directeur') && !req.auth.isSuperAdmin) {
      return res.status(403).json({ message: 'Seul le directeur peut supprimer ce document générique.' });
    }

    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(`DELETE FROM documents WHERE ${conditions.join(' AND ')}`, params)
    );
    return res.json({ message: 'Document supprimé.' });
  } catch (err) {
    console.error('Erreur suppression document:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  uploaderLogoEcole,
  uploaderImageSite, uploaderPhotoEleve, uploaderPhotoUtilisateur, uploaderDocument, obtenirDernierDocument, supprimerDocument
};
