const XLSX = require('xlsx');
const { runWithTenant } = require('../config/db');
const { hashPassword, comparePassword } = require('../utils/password.utils');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const { validerCombinaisonRoles } = require('../utils/role.utils');
const { notifierEvenement, planifierVidage } = require('../utils/notifications.service');

const MOT_DE_PASSE_PROVISOIRE = 'ChangeMoi123!';
const THEMES_AUTORISES = ['ardoise', 'pure', 'nuit', 'kivu', 'studio'];

/**
 * GET /utilisateurs?q=&role=
 */
async function lister(req, res) {
  const { q, role } = req.query;
  try {
    const conditions = [`u.ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid`];
    const params = [];
    if (q) {
      params.push(`%${q}%`);
      conditions.push(`(u.nom ILIKE $${params.length} OR u.prenom ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
    }

    let clauseAyant = '';
    if (role) {
      params.push(role);
      clauseAyant = `HAVING $${params.length} = ANY(array_agg(ur.role::text))`;
    }

    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(`
        SELECT u.id, u.nom, u.prenom, u.email, u.telephone, u.photo_url, u.statut,
               array_agg(ur.role::text) FILTER (WHERE ur.role IS NOT NULL) AS roles
        FROM utilisateurs u
        LEFT JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
        WHERE ${conditions.join(' AND ')}
        GROUP BY u.id
        ${clauseAyant}
        ORDER BY u.nom
      `, params)
    );
    return res.json(result.rows);
  } catch (err) {
    console.error('Erreur liste utilisateurs:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /utilisateurs
 */
async function creer(req, res) {
  const { nom, prenom, email, telephone, password, roles } = req.body;

  if (!nom || !email || !Array.isArray(roles) || roles.length === 0) {
    return res.status(400).json({ message: 'nom, email et roles (tableau non vide) sont requis.' });
  }

  const erreurRoles = validerCombinaisonRoles(roles);
  if (erreurRoles) return res.status(400).json({ message: erreurRoles });

  try {
    const motDePasseInitial = password || MOT_DE_PASSE_PROVISOIRE;
    const motDePasseHash = await hashPassword(motDePasseInitial);

    const result = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const userResult = await client.query(
        `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, telephone, mot_de_passe_hash,
                                   doit_changer_mot_de_passe)
         VALUES (NULLIF(current_setting('app.current_ecole_id', true), '')::uuid, $1,$2,$3,$4,$5, true)
         RETURNING id`,
        [nom, prenom, email, telephone, motDePasseHash]
      );
      const userId = userResult.rows[0].id;

      for (const role of roles) {
        await client.query(
          `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, $2)`,
          [userId, role]
        );
      }

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id)
         VALUES (NULLIF(current_setting('app.current_ecole_id', true), '')::uuid, $1, 'utilisateur.cree', 'utilisateur', $2)`,
        [req.auth.userId, userId]
      );

      // Ses identifiants, à lui, par e-mail. Jusqu'ici ils s'affichaient dans
      // la réponse HTTP : celui qui créait le compte devait les recopier et
      // les transmettre de la main à la main. Un mot de passe qui transite par
      // WhatsApp ou par un bout de papier n'est plus un mot de passe.
      //
      // L'écriture est ici, DANS la transaction : si l'insertion des rôles
      // échoue trois lignes plus haut, la notification est annulée avec elle.
      // Aucun e-mail ne peut annoncer un compte qui n'existe pas.
      const ecole = await client.query(
        `SELECT nom FROM ecoles WHERE id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid`
      );

      await notifierEvenement(client, {
        evenement: 'compte.cree',
        destinataires: [{ utilisateurId: userId }],
        expediteurId: req.auth.userId,
        donnees: {
          prenom, nom, email,
          ecole: ecole.rows[0]?.nom || null,
          roles: roles.join(', '),
          // Un mot de passe choisi par l'administrateur ne lui est pas renvoyé :
          // il le connaît déjà, et l'archiver en clair dans la file n'apporte
          // rien. Seul le mot de passe provisoire généré par la plateforme,
          // que le destinataire ignore, est transmis — puis effacé de la base
          // dès l'envoi réussi (voir `effacerDonnees` au catalogue).
          motDePasse: password ? null : MOT_DE_PASSE_PROVISOIRE
        }
      });

      return userId;
    });

    // Hors transaction, après le commit : la réponse part sans attendre Resend.
    planifierVidage();

    return res.status(201).json({
      id: result,
      mot_de_passe_provisoire: password ? null : MOT_DE_PASSE_PROVISOIRE,
      message: password
        ? 'Utilisateur créé. Il devra changer son mot de passe à la première connexion.'
        : `Utilisateur créé. Mot de passe provisoire : ${MOT_DE_PASSE_PROVISOIRE} — il devra le changer à sa première connexion.`
    });
  } catch (err) {
    console.error('Erreur création utilisateur:', err);
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Cet email est déjà utilisé dans cette école.' });
    }
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /utilisateurs/:id
 * Étendu pour gérer la mise à jour des rôles.
 */
async function modifier(req, res) {
  const { id } = req.params;
  const { nom, prenom, telephone, statut, photo_url, roles } = req.body;

  try {
    await runWithTenant(tenantContextFromReq(req), async (client) => {
      // Mise à jour des informations de base
      await client.query(
        `UPDATE utilisateurs
         SET nom = COALESCE($1, nom), prenom = COALESCE($2, prenom),
             telephone = COALESCE($3, telephone), statut = COALESCE($4, statut),
             photo_url = COALESCE($5, photo_url), updated_at = now()
         WHERE id = $6`,
        [nom, prenom, telephone, statut, photo_url, id]
      );

      // Si des rôles sont fournis, les mettre à jour
      if (Array.isArray(roles)) {
        const erreurRoles = validerCombinaisonRoles(roles);
        if (erreurRoles) {
          throw Object.assign(new Error(erreurRoles), { statusCode: 400 });
        }
        // Supprimer les anciens rôles
        await client.query(`DELETE FROM utilisateur_roles WHERE utilisateur_id = $1`, [id]);
        // Insérer les nouveaux
        for (const role of roles) {
          await client.query(
            `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, $2)`,
            [id, role]
          );
        }
      }
    });
    return res.json({ message: 'Utilisateur mis à jour.' });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur modification utilisateur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * DELETE /utilisateurs/:id
 */
async function supprimer(req, res) {
  const { id } = req.params;
  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query('DELETE FROM utilisateurs WHERE id = $1', [id])
    );
    return res.json({ message: 'Utilisateur supprimé.' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({
        message: "Impossible de supprimer : ce compte a déjà des actions liées (cours enseignés, signatures, historique...). Désactive-le plutôt via son statut."
      });
    }
    console.error('Erreur suppression utilisateur:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * GET /utilisateurs/moi
 */
async function obtenirMonProfil(req, res) {
  try {
    const result = await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `SELECT u.id, u.nom, u.prenom, u.email, u.telephone, u.photo_url, u.theme,
                array_agg(ur.role::text) FILTER (WHERE ur.role IS NOT NULL) AS roles
         FROM utilisateurs u
         LEFT JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
         WHERE u.id = $1
         GROUP BY u.id`,
        [req.auth.userId]
      )
    );
    return res.json(result.rows[0] || null);
  } catch (err) {
    console.error('Erreur lecture profil:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * PATCH /utilisateurs/moi
 */
async function modifierMonProfil(req, res) {
  const { nom, prenom, telephone, theme } = req.body;

  if (theme !== undefined && theme !== null && !THEMES_AUTORISES.includes(theme)) {
    return res.status(400).json({ message: 'Thème inconnu.' });
  }

  try {
    await runWithTenant(tenantContextFromReq(req), (client) =>
      client.query(
        `UPDATE utilisateurs SET
           nom = COALESCE($1, nom), prenom = COALESCE($2, prenom), telephone = COALESCE($3, telephone),
           theme = COALESCE($4, theme),
           updated_at = now()
         WHERE id = $5`,
        [nom, prenom, telephone, theme || null, req.auth.userId]
      )
    );
    return res.json({ message: 'Profil mis à jour.' });
  } catch (err) {
    console.error('Erreur modification profil:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /utilisateurs/moi/changer-mot-de-passe
 */
async function changerMonMotDePasse(req, res) {
  const { ancien_mot_de_passe, nouveau_mot_de_passe } = req.body;
  if (!ancien_mot_de_passe || !nouveau_mot_de_passe) {
    return res.status(400).json({ message: "L'ancien et le nouveau mot de passe sont requis." });
  }
  if (nouveau_mot_de_passe.length < 6) {
    return res.status(400).json({ message: 'Le nouveau mot de passe doit contenir au moins 6 caractères.' });
  }

  try {
    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const userResult = await client.query(
        `SELECT mot_de_passe_hash FROM utilisateurs WHERE id = $1`,
        [req.auth.userId]
      );
      if (userResult.rows.length === 0) return 'introuvable';

      const motDePasseValide = await comparePassword(ancien_mot_de_passe, userResult.rows[0].mot_de_passe_hash);
      if (!motDePasseValide) return 'incorrect';

      const nouveauHash = await hashPassword(nouveau_mot_de_passe);
      await client.query(`UPDATE utilisateurs SET mot_de_passe_hash = $1, doit_changer_mot_de_passe = false WHERE id = $2`, [nouveauHash, req.auth.userId]);
      return 'ok';
    });

    if (resultat === 'introuvable') return res.status(404).json({ message: 'Utilisateur introuvable.' });
    if (resultat === 'incorrect') return res.status(400).json({ message: 'Ancien mot de passe incorrect.' });

    return res.json({ message: 'Mot de passe mis à jour.' });
  } catch (err) {
    console.error('Erreur changement mot de passe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

/**
 * POST /utilisateurs/import
 */
async function importerUtilisateurs(req, res) {
  if (!req.file) {
    return res.status(400).json({ message: 'Aucun fichier reçu (champ attendu : "fichier").' });
  }

  // Liste alignée sur ce que l'écran propose ET sur ce que les routes
  // reconnaissent. Elle en omettait deux : un import contenant « comptable » ou
  // « directeur_discipline » — pourtant valides partout ailleurs — rejetait la
  // ligne avec « rôle invalide », ce qui est incompréhensible pour l'école.
  const rolesValides = ['professeur', 'titulaire', 'secretaire', 'prefet',
                        'directeur', 'comptable', 'directeur_discipline',
                        'charge_presences'];

  try {
    const classeur = XLSX.read(req.file.buffer, { type: 'buffer' });
    const premiereFeuille = classeur.Sheets[classeur.SheetNames[0]];
    const lignes = XLSX.utils.sheet_to_json(premiereFeuille, { defval: null });

    const resultat = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const bilan = { crees: 0, erreurs: [] };

      for (let i = 0; i < lignes.length; i++) {
        const ligne = lignes[i];
        const numeroLigne = i + 2;

        const nom = ligne.Nom?.toString().trim();
        const email = ligne.Email?.toString().trim();
        const motDePasse = ligne.MotDePasse?.toString().trim();
        const rolesBruts = ligne.Roles?.toString().trim();

        if (!nom || !email || !motDePasse || !rolesBruts) {
          bilan.erreurs.push(`Ligne ${numeroLigne} : Nom, Email, MotDePasse et Roles sont obligatoires — ignorée.`);
          continue;
        }

        const roles = rolesBruts.split(',').map(r => r.trim().toLowerCase()).filter(Boolean);
        const rolesInvalides = roles.filter(r => !rolesValides.includes(r));
        if (rolesInvalides.length > 0) {
          bilan.erreurs.push(`Ligne ${numeroLigne} : rôle(s) invalide(s) "${rolesInvalides.join(', ')}" — ignorée.`);
          continue;
        }
        const erreurCombinaison = validerCombinaisonRoles(roles);
        if (erreurCombinaison) {
          bilan.erreurs.push(`Ligne ${numeroLigne} : ${erreurCombinaison} — ignorée.`);
          continue;
        }

        try {
          const motDePasseHash = await hashPassword(motDePasse);
          const userResult = await client.query(
            `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, telephone, mot_de_passe_hash)
             VALUES (NULLIF(current_setting('app.current_ecole_id', true), '')::uuid, $1,$2,$3,$4,$5)
             RETURNING id`,
            [nom, ligne.Prenom, email, ligne.Telephone, motDePasseHash]
          );
          const userId = userResult.rows[0].id;

          for (const role of roles) {
            await client.query(`INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, $2)`, [userId, role]);
          }
          bilan.crees++;
        } catch (err) {
          if (err.code === '23505') {
            bilan.erreurs.push(`Ligne ${numeroLigne} : l'email "${email}" existe déjà dans cette école — ignorée.`);
          } else {
            bilan.erreurs.push(`Ligne ${numeroLigne} : erreur inattendue — ignorée.`);
          }
        }
      }

      return bilan;
    });

    return res.json({ message: 'Import terminé.', bilan: resultat });
  } catch (err) {
    console.error('Erreur import utilisateurs:', err);
    return res.status(500).json({ message: 'Erreur serveur lors de la lecture du fichier.' });
  }
}

/**
 * POST /utilisateurs/:id/reinitialiser-mot-de-passe
 */
async function reinitialiserMotDePasse(req, res) {
  const { id } = req.params;
  try {
    const nom = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const hash = await hashPassword(MOT_DE_PASSE_PROVISOIRE);
      const r = await client.query(
        `UPDATE utilisateurs
         SET mot_de_passe_hash = $2, doit_changer_mot_de_passe = true
         WHERE id = $1 AND ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid
         RETURNING trim(concat(prenom, ' ', nom)) AS nom_complet`,
        [id, hash]
      );
      if (r.rows.length === 0) {
        throw Object.assign(new Error('Utilisateur introuvable.'), { statusCode: 404 });
      }

      await client.query(`DELETE FROM sessions WHERE utilisateur_id = $1`, [id]);

      await client.query(
        `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id)
         VALUES (NULLIF(current_setting('app.current_ecole_id', true), '')::uuid, $1,
                 'utilisateur.mot_de_passe_reinitialise', 'utilisateur', $2)`,
        [req.auth.userId, id]
      );

      // Prévenir la personne n'est pas une politesse, c'est un signal de
      // sécurité : ses sessions viennent d'être fermées de force. Si elle
      // n'a rien demandé, elle doit pouvoir s'en alarmer tout de suite.
      const contexte = await client.query(
        `SELECT trim(concat(a.prenom, ' ', a.nom)) AS auteur, e.nom AS ecole
           FROM ecoles e
           LEFT JOIN utilisateurs a ON a.id = $1
          WHERE e.id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid`,
        [req.auth.userId]
      );

      await notifierEvenement(client, {
        evenement: 'compte.mot_de_passe_reinitialise',
        destinataires: [{ utilisateurId: id }],
        expediteurId: req.auth.userId,
        donnees: {
          motDePasse: MOT_DE_PASSE_PROVISOIRE,
          auteur: contexte.rows[0]?.auteur || null,
          ecole: contexte.rows[0]?.ecole || null
        }
      });

      return r.rows[0].nom_complet;
    });

    planifierVidage();

    return res.json({
      message: `Mot de passe de ${nom} réinitialisé à « ${MOT_DE_PASSE_PROVISOIRE} ». `
        + `Toutes ses sessions ont été fermées et il devra le changer à sa prochaine connexion.`,
      mot_de_passe_provisoire: MOT_DE_PASSE_PROVISOIRE
    });
  } catch (err) {
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
    console.error('Erreur réinitialisation mot de passe:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = {
  reinitialiserMotDePasse,
  lister, creer, modifier, supprimer, obtenirMonProfil, modifierMonProfil, changerMonMotDePasse, importerUtilisateurs
};
