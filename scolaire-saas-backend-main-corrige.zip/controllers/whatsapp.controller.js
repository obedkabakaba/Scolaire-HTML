const { runWithTenant } = require('../config/db');
const { conversationAvecOutils, consommerQuota } = require('../utils/ia.utils');
const { normaliserNumero, signatureValide, envoyerMessage, marquerLu } = require('../utils/whatsapp.utils');
const { OUTILS_PARENT, OUTILS_PERSONNEL, creerExecuteur, nomComplet } = require('../utils/assistant-outils.utils');

/*
 * Assistant WhatsApp — Ardoise
 * --------------------------------------------------------------------------
 * Ce webhook est public : Meta l'appelle sans jeton d'authentification.
 * La sécurité repose sur trois choses, dans cet ordre :
 *
 *   1. La signature Meta, vérifiée sur chaque appel. Sans elle, n'importe qui
 *      pourrait se faire passer pour un parent.
 *   2. Le numéro de téléphone, authentifié par WhatsApp lui-même, qui sert
 *      d'identité. Il est comparé aux numéros enregistrés dans les fiches.
 *   3. Le périmètre des outils : l'assistant ne peut lire que les données des
 *      élèves rattachés à ce numéro précis.
 *
 * Un numéro inconnu ne reçoit jamais la moindre donnée scolaire.
 */

const MESSAGES_MAX_HISTORIQUE = 8;
const DELAI_RELANCE_MS = 3000;

/** GET /whatsapp/webhook — vérification initiale demandée par Meta. */
function verifierWebhook(req, res) {
  const mode = req.query['hub.mode'];
  const jeton = req.query['hub.verify_token'];
  const defi = req.query['hub.challenge'];

  if (mode === 'subscribe' && jeton && jeton === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(defi);
  }
  return res.sendStatus(403);
}

/**
 * Identifie l'expéditeur à partir de son numéro.
 * Recherche menée en contexte super-admin car aucune école n'est encore
 * connue — c'est précisément ce que la recherche doit déterminer.
 */
async function identifier(numero) {
  return runWithTenant({ isSuperAdmin: true }, async (client) => {
    // ---------- Parent ? ----------
    // Pré-filtre en SQL sur les huit derniers chiffres : c'est la partie
    // stable d'un numéro congolais, quelle que soit la façon dont il a été
    // saisi. La normalisation exacte se fait ensuite en JavaScript, sur une
    // poignée de lignes seulement — jamais sur toute la base.
    const finNumero = numero.slice(-8);
    const enfants = await client.query(
      `SELECT e.id, e.nom, e.postnom, e.prenom, e.matricule, e.classe_id,
              e.responsable_telephone, c.nom AS classe_nom,
              e.ecole_id, ec.nom AS ecole_nom
       FROM eleves e
       JOIN ecoles ec ON ec.id = e.ecole_id
       LEFT JOIN classes c ON c.id = e.classe_id
       WHERE e.statut = 'actif' AND ec.statut = 'actif'
         AND right(regexp_replace(COALESCE(e.responsable_telephone, ''), '[^0-9]', '', 'g'), 8) = $1
       ORDER BY e.nom
       LIMIT 40`,
      [finNumero]
    );

    const parentEnfants = enfants.rows
      .filter((l) => normaliserNumero(l.responsable_telephone) === numero)
      .map((l) => ({
        id: l.id, nom: l.nom, postnom: l.postnom, prenom: l.prenom,
        nom_complet: nomComplet(l), matricule: l.matricule,
        classe_id: l.classe_id, classe_nom: l.classe_nom,
        ecole_id: l.ecole_id, ecole_nom: l.ecole_nom
      }));

    if (parentEnfants.length > 0) {
      const ecoles = [...new Set(parentEnfants.map((e) => e.ecole_id))];
      if (ecoles.length > 1) {
        return { type: 'ambigu', ecoles: [...new Set(parentEnfants.map((e) => e.ecole_nom))] };
      }
      return {
        type: 'parent',
        ecoleId: ecoles[0],
        ecoleNom: parentEnfants[0].ecole_nom,
        enfants: parentEnfants
      };
    }

    // ---------- Membre du personnel ? ----------
    const agents = await client.query(
      `SELECT u.id, u.nom, u.prenom, u.telephone, u.ecole_id, ec.nom AS ecole_nom,
              array_agg(ur.role::text) AS roles
       FROM utilisateurs u
       JOIN ecoles ec ON ec.id = u.ecole_id
       LEFT JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
       WHERE u.statut = 'actif' AND ec.statut = 'actif'
         AND right(regexp_replace(COALESCE(u.telephone, ''), '[^0-9]', '', 'g'), 8) = $1
       GROUP BY u.id, u.nom, u.prenom, u.telephone, u.ecole_id, ec.nom
       LIMIT 20`,
      [finNumero]
    );
    const trouve = agents.rows.find((u) => normaliserNumero(u.telephone) === numero);
    if (trouve) {
      return {
        type: 'personnel',
        ecoleId: trouve.ecole_id,
        ecoleNom: trouve.ecole_nom,
        utilisateurId: trouve.id,
        nom: [trouve.prenom, trouve.nom].filter(Boolean).join(' '),
        roles: (trouve.roles || []).filter(Boolean)
      };
    }

    return { type: 'inconnu' };
  });
}

/** Historique récent d'une conversation, pour garder le fil. */
async function chargerConversation(numero) {
  return runWithTenant({ isSuperAdmin: true }, async (client) => {
    const r = await client.query(
      `SELECT historique FROM conversations_whatsapp WHERE telephone = $1`, [numero]
    );
    const brut = r.rows[0]?.historique;
    return Array.isArray(brut) ? brut.slice(-MESSAGES_MAX_HISTORIQUE) : [];
  });
}

async function enregistrerConversation(numero, ecoleId, historique) {
  return runWithTenant({ isSuperAdmin: true }, (client) =>
    client.query(
      `INSERT INTO conversations_whatsapp (telephone, ecole_id, historique, updated_at)
       VALUES ($1, $2, $3::jsonb, now())
       ON CONFLICT (telephone)
       DO UPDATE SET ecole_id = EXCLUDED.ecole_id, historique = EXCLUDED.historique, updated_at = now()`,
      [numero, ecoleId, JSON.stringify(historique.slice(-MESSAGES_MAX_HISTORIQUE))]
    )
  );
}

async function journaliserEchange(numero, ecoleId, entrant, sortant, identite, outils) {
  try {
    await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query(
        `INSERT INTO messages_whatsapp (telephone, ecole_id, type_expediteur, message_recu, message_envoye, outils_utilises)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [numero, ecoleId, identite, entrant, sortant, (outils || []).join(',') || null]
      )
    );
  } catch (e) {
    console.error('Journalisation WhatsApp impossible:', e.message);
  }
}

function construireSysteme(identite) {
  const commun = `Tu es l'assistant d'une école en République démocratique du Congo, joignable sur WhatsApp.

Règles impératives :
- Réponds en français, brièvement : trois à six lignes, jamais de long discours.
  On te lit sur un téléphone, souvent avec peu de connexion.
- N'invente AUCUN chiffre, AUCUNE date, AUCUN nom. Utilise uniquement ce que
  les outils te renvoient. Si un outil ne renvoie rien, dis-le simplement.
- Ne donne aucun conseil médical, juridique ou financier.
- Si la demande dépasse ce que tu peux faire — inscription, réclamation sur une
  note, rendez-vous — invite poliment à contacter directement l'école.
- Pas de mise en forme Markdown : WhatsApp ne l'affiche pas. Tu peux utiliser
  des tirets pour les listes.
- Vouvoiement systématique.`;

  if (identite.type === 'parent') {
    const liste = identite.enfants
      .map((e, i) => `${i + 1}. ${e.nom_complet} — ${e.classe_nom || 'classe non renseignée'}`)
      .join('\n');
    return `${commun}

Tu parles à un parent d'élève de l'école ${identite.ecoleNom}.
Enfants rattachés à ce numéro :
${liste}

- Pour appeler un outil, indique le numéro de l'enfant dans cette liste.
- Tu ne peux consulter QUE ces enfants. Toute question sur un autre élève doit
  être refusée poliment, sans expliquer le fonctionnement interne.
- Si le parent a plusieurs enfants et ne précise pas lequel, demande-le.`;
  }

  return `${commun}

Tu parles à ${identite.nom}, membre du personnel de l'école ${identite.ecoleNom}
(rôles : ${identite.roles.join(', ') || 'non précisé'}).
Tu peux consulter son emploi du temps du jour, l'effectif de ses classes,
les annonces et le calendrier. Rien d'autre.`;
}

/** POST /whatsapp/webhook */
async function recevoirMessage(req, res) {
  // Meta réessaie si la réponse tarde : on accuse réception immédiatement,
  // puis on traite. Sans cela, un message lent produirait des doublons.
  if (!signatureValide(req.rawBody || '', req.get('x-hub-signature-256'))) {
    console.warn('Webhook WhatsApp : signature invalide, appel ignoré.');
    return res.sendStatus(403);
  }
  res.sendStatus(200);

  try {
    const entree = req.body?.entry?.[0]?.changes?.[0]?.value;
    const message = entree?.messages?.[0];
    if (!message) return;                       // accusé de lecture, statut… : rien à faire
    if (message.type !== 'text') {
      await envoyerMessage(message.from,
        "Je ne sais lire que les messages écrits. Envoyez-moi votre question en texte.");
      return;
    }

    const numero = normaliserNumero(message.from);
    const texte = String(message.text?.body || '').trim().slice(0, 800);
    if (!numero || !texte) return;

    await marquerLu(message.id);

    const identite = await identifier(numero);

    if (identite.type === 'inconnu') {
      await envoyerMessage(numero,
        "Bonjour. Ce numéro n'est rattaché à aucun élève ni à aucun membre du personnel.\n\n"
        + "Si vous êtes parent, demandez au secrétariat d'enregistrer ce numéro sur la fiche de votre enfant.");
      await journaliserEchange(numero, null, texte, '(numéro inconnu)', 'inconnu', []);
      return;
    }

    if (identite.type === 'ambigu') {
      await envoyerMessage(numero,
        `Ce numéro est enregistré dans plusieurs écoles (${identite.ecoles.join(', ')}).\n\n`
        + "Pour des raisons de confidentialité, contactez directement l'école concernée.");
      await journaliserEchange(numero, null, texte, '(numéro multi-écoles)', 'ambigu', []);
      return;
    }

    // ---------- Quota, décompté sur l'école concernée ----------
    try {
      await runWithTenant({ ecoleId: identite.ecoleId, isSuperAdmin: false }, (client) =>
        consommerQuota(client, identite.ecoleId, 1)
      );
    } catch (e) {
      await envoyerMessage(numero,
        "Le service de messagerie automatique de l'école est momentanément indisponible. "
        + "Contactez le secrétariat, il pourra vous répondre directement.");
      await journaliserEchange(numero, identite.ecoleId, texte, '(quota atteint)', identite.type, []);
      return;
    }

    const historique = await chargerConversation(numero);
    historique.push({ role: 'user', content: texte });

    const outils = identite.type === 'parent' ? OUTILS_PARENT : OUTILS_PERSONNEL;
    const executer = creerExecuteur(identite);

    let reponse;
    try {
      reponse = await conversationAvecOutils({
        systeme: construireSysteme(identite),
        messages: historique,
        outils,
        executerOutil: executer,
        toursMax: 4,
        maxTokens: 900
      });
    } catch (e) {
      console.error('Assistant WhatsApp en échec:', e.message);
      await envoyerMessage(numero,
        "Je rencontre une difficulté technique. Réessayez dans quelques instants, "
        + "ou contactez directement l'école.");
      await journaliserEchange(numero, identite.ecoleId, texte, '(erreur technique)', identite.type, []);
      return;
    }

    await envoyerMessage(numero, reponse.texte);

    // On ne conserve que le texte : rejouer des blocs d'outils d'une
    // conversation à l'autre produirait des références invalides.
    historique.push({ role: 'assistant', content: reponse.texte });
    await enregistrerConversation(numero, identite.ecoleId, historique);
    await journaliserEchange(numero, identite.ecoleId, texte, reponse.texte, identite.type, reponse.outilsAppeles);

  } catch (err) {
    console.error('Erreur traitement message WhatsApp:', err);
  }
}

/** GET /whatsapp/journal — consultation par l'école de ses propres échanges. */
async function journalEcole(req, res) {
  const limite = Math.min(Math.max(Number(req.query.limite) || 50, 1), 200);
  try {
    const lignes = await runWithTenant({ ecoleId: req.auth.ecoleId, isSuperAdmin: false }, (client) =>
      client.query(
        `SELECT telephone, type_expediteur, message_recu, message_envoye,
                outils_utilises, created_at
         FROM messages_whatsapp
         WHERE ecole_id = $1
         ORDER BY created_at DESC LIMIT $2`,
        [req.auth.ecoleId, limite]
      )
    );
    // Le numéro est partiellement masqué : le personnel n'a pas besoin de
    // l'annuaire complet des parents pour lire un échange.
    return res.json(lignes.rows.map((l) => ({
      ...l,
      telephone: l.telephone ? l.telephone.slice(0, 6) + '••••' + l.telephone.slice(-2) : null
    })));
  } catch (err) {
    console.error('Erreur journal WhatsApp:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { verifierWebhook, recevoirMessage, journalEcole };
