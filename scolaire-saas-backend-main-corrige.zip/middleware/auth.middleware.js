const { verifyAccessToken } = require('../utils/jwt.utils');

/**
 * Vérifie le token JWT d'accès envoyé dans l'en-tête Authorization: Bearer <token>
 * et attache le contexte utilisateur/tenant à la requête (req.auth).
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Token manquant.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = verifyAccessToken(token);
    req.auth = {
      userId: payload.sub,
      ecoleId: payload.ecole_id || null,
      roles: payload.roles || [],
      isSuperAdmin: payload.is_superadmin === true,
      // Mode « Voir comme » du Super Admin. Recopié tel quel : c'est
      // `middleware/super-admin.middleware.js` qui décide de ce qu'on en fait,
      // pas ce fichier, dont le seul rôle est de traduire le jeton.
      observation: payload.observation === true,
      observateur: payload.observateur || null
    };
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token invalide ou expiré.' });
  }
}

module.exports = authMiddleware;
