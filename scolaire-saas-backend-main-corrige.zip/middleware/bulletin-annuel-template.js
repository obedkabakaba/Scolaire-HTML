/**
 * Construit le HTML du bulletin annuel : A4 portrait, 1 page complète par élève,
 * récapitulant le résultat de chaque période/trimestre/semestre + la moyenne
 * annuelle, le classement annuel et la mention finale.
 * Modèle totalement indépendant du bulletin de période (4 colonnes paysage).
 */
function construireHtmlBulletinAnnuel({ ecole, anneeLibelle, classe, eleves }) {
  const styles = `
    @page { size: A4 portrait; margin: 15mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 11px; margin: 0; }
    .page { page-break-after: always; }
    .page:last-child { page-break-after: auto; }
    .entete { text-align: center; margin-bottom: 6mm; }
    .entete img { max-height: 20mm; margin-bottom: 2mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 15px; }
    .entete .annee { font-size: 11px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; font-size: 14px; margin: 4mm 0; }
    .identite { margin-bottom: 5mm; font-size: 11px; }
    .identite div { margin-bottom: 1mm; }
    table.periodes { width: 100%; border-collapse: collapse; font-size: 10.5px; margin-bottom: 5mm; }
    table.periodes th, table.periodes td { border: 0.5px solid #666; padding: 2mm; text-align: center; }
    table.periodes th { background: #eee; }
    .synthese-annuelle { border: 1px solid #333; padding: 4mm; font-size: 12px; margin-bottom: 6mm; }
    .synthese-annuelle div { display: flex; justify-content: space-between; padding: 1mm 0; border-bottom: 0.5px dotted #999; }
    .signatures { margin-top: 15mm; display: flex; justify-content: space-around; font-size: 10px; }
    .signatures .case { border-top: 0.5px solid #333; width: 40%; text-align: center; padding-top: 2mm; }
  `;

  function pageEleve(eleve) {
    const lignesPeriodes = eleve.periodes.map((p) => `
      <tr>
        <td>${p.libelle}</td>
        <td>${p.total ?? '-'}</td>
        <td>${p.pourcentage ?? '-'}%</td>
        <td>${p.classement ?? '-'}</td>
        <td>${p.mention ?? '-'}</td>
      </tr>
    `).join('');

    return `
      <div class="page">
        <div class="entete">
          ${ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${ecole.nom}</div>
          <div class="annee">Année scolaire ${anneeLibelle || ''}</div>
        </div>
        <div class="titre-bulletin">Bulletin Annuel</div>
        <div class="identite">
          <div><strong>Nom :</strong> ${eleve.nom} ${eleve.postnom || ''} ${eleve.prenom || ''}</div>
          <div><strong>Matricule :</strong> ${eleve.matricule}</div>
          <div><strong>Classe :</strong> ${classe.nom} ${classe.option_nom ? '(' + classe.option_nom + ')' : ''}</div>
        </div>
        <table class="periodes">
          <thead>
            <tr><th>Période</th><th>Total</th><th>Pourcentage</th><th>Classement</th><th>Mention</th></tr>
          </thead>
          <tbody>${lignesPeriodes}</tbody>
        </table>
        <div class="synthese-annuelle">
          <div><span>Moyenne annuelle</span><span>${eleve.moyenne_annuelle ?? '-'}%</span></div>
          <div><span>Classement annuel</span><span>${eleve.classement_annuel ?? '-'} / ${eleves.length}</span></div>
          <div><span>Mention annuelle</span><span>${eleve.mention_annuelle ?? '-'}</span></div>
        </div>
        <div class="signatures">
          <div class="case">Signature du titulaire</div>
          <div class="case">Signature du directeur</div>
          <div class="case">Cachet de l'école</div>
        </div>
      </div>
    `;
  }

  const pagesHtml = eleves.map(pageEleve).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletinAnnuel };
