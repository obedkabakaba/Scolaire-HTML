/**
 * Transforme un texte en "slug" simple (minuscules, sans accents, underscores)
 * pour faire correspondre une clé de zone comme "note_mathematiques" au cours "Mathématiques".
 */
function slugifier(texte) {
  return (texte || '')
    .toString()
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

/**
 * Résout la valeur à afficher pour une clé de zone donnée, pour un élève précis.
 */
function resoudreValeurZone(cle, eleve, communes) {
  const valeursDirectes = {
    nom_eleve: eleve.nom,
    postnom_eleve: eleve.postnom || '',
    prenom_eleve: eleve.prenom || '',
    matricule: eleve.matricule,
    classe: communes.classeNom || '',
    section: communes.sectionNom || '',
    option: communes.optionNom || '',
    annee_scolaire: communes.anneeLibelle || '',
    periode: communes.periodeLibelle || '',
    total: eleve.total ?? '',
    pourcentage: eleve.pourcentage != null ? `${eleve.pourcentage}%` : '',
    classement: eleve.classement ?? '',
    mention: eleve.mention || '',
    conduite: eleve.conduite || '',
    application: eleve.application || '',
    observation: eleve.observation || '',
    date: communes.dateEdition,
    // « Fait à Kinshasa, le 30 juillet 2026 » : la date d'édition atteste du
    // moment où la pièce a été délivrée. Sans elle, un bulletin réimprimé six
    // mois plus tard est indiscernable de l'original.
    fait_a: communes.villeEcole || '',
    fait_le: communes.dateEditionLongue,
    fait_a_le: communes.villeEcole
      ? `Fait à ${communes.villeEcole}, le ${communes.dateEditionLongue}`
      : `Fait le ${communes.dateEditionLongue}`,
    // Ces deux zones existaient déjà comme clés reconnues, mais renvoyaient
    // toujours une chaîne vide : une école qui plaçait une zone « signature »
    // sur son modèle n'obtenait rien, sans le moindre message.
    signature: communes.signatureUrl
      ? `<img src="${communes.signatureUrl}" style="max-width:100%;max-height:100%;object-fit:contain;" />`
      : '',
    cachet: communes.cachetUrl
      ? `<img src="${communes.cachetUrl}" style="max-width:100%;max-height:100%;object-fit:contain;" />`
      : '',
    logo_ecole: communes.logoUrl ? `<img src="${communes.logoUrl}" style="max-width:100%;max-height:100%;object-fit:contain;" />` : ''
  };

  if (cle in valeursDirectes) return valeursDirectes[cle];

  if (cle.startsWith('note_')) {
    const slugRecherche = cle.slice(5);
    const note = eleve.notesParSlug ? eleve.notesParSlug[slugRecherche] : undefined;
    return note !== undefined && note !== null ? note : '';
  }

  return '';
}

/**
 * Construit le HTML des bulletins en utilisant le modèle importé par l'école
 * (image en fond) avec les zones positionnées en % remplies par les vraies données.
 * Un élève = une page (le modèle représente un bulletin individuel complet).
 */
function construireHtmlBulletinPersonnalise({ modele, zones, eleves, classe, periodeLibelle, anneeLibelle, ecole, signatureUrl, cachetUrl, mentionDuplicata }) {
  const maintenant = new Date();
  const communes = {
    signatureUrl, cachetUrl, mentionDuplicata,
    villeEcole: ecole && ecole.ville ? ecole.ville : '',
    dateEdition: maintenant.toLocaleDateString('fr-FR'),
    dateEditionLongue: maintenant.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }),
    classeNom: classe.nom,
    sectionNom: classe.section_nom,
    optionNom: classe.option_nom,
    anneeLibelle,
    periodeLibelle,
    logoUrl: ecole.logo_url
  };

  const styles = `
    @page { size: A4 portrait; margin: 0; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, Helvetica, sans-serif; }
    .page { position: relative; width: 100%; height: 100vh; page-break-after: always; overflow: hidden; }
    .page:last-child { page-break-after: auto; }
    .page img.fond { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: contain; }
    .zone { position: absolute; overflow: hidden; line-height: 1.15; }
  `;

  const pagesHtml = eleves.map((eleve) => {
    const zonesHtml = zones.map((zone) => {
      const valeur = resoudreValeurZone(zone.cle, eleve, communes);
      const style = [
        `left:${zone.x}%`, `top:${zone.y}%`,
        `width:${zone.largeur || 15}%`, `height:${zone.hauteur || 6}%`,
        `font-size:${zone.taille || 10}px`,
        zone.police ? `font-family:${zone.police}` : '',
        `text-align:${zone.alignement || 'left'}`
      ].filter(Boolean).join(';');
      return `<div class="zone" style="${style}">${valeur}</div>`;
    }).join('');

    return `<div class="page">
      <img class="fond" src="${modele.fichier_source_url}" />
      ${zonesHtml}
    </div>`;
  }).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletinPersonnalise, slugifier };
