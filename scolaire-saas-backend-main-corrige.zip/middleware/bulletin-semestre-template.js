/**
 * Construit le HTML du bulletin de semestre : A4 portrait, 1 page complète par élève,
 * récapitulant les 2 périodes + l'examen qui composent ce semestre, plus la moyenne,
 * le classement et la mention du semestre. Même mécanique que le bulletin annuel,
 * à l'échelle du semestre.
 */
function construireHtmlBulletinSemestre({ ecole, classe, semestreLibelle, eleves }) {
  const styles = `
    @page { size: A4 portrait; margin: 15mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 11px; margin: 0; }
    .page { page-break-after: always; }
    .page:last-child { page-break-after: auto; }
    .entete { text-align: center; margin-bottom: 6mm; }
    .entete img { max-height: 20mm; margin-bottom: 2mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 15px; }
    .entete .semestre { font-size: 11px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; font-size: 14px; margin: 4mm 0; }
    .identite { margin-bottom: 5mm; font-size: 11px; }
    .identite div { margin-bottom: 1mm; }
    table.composantes { width: 100%; border-collapse: collapse; font-size: 10.5px; margin-bottom: 5mm; }
    table.composantes th, table.composantes td { border: 0.5px solid #666; padding: 2mm; text-align: center; }
    table.composantes th { background: #eee; }
    .synthese { border: 1px solid #333; padding: 4mm; font-size: 12px; margin-bottom: 6mm; }
    .synthese div { display: flex; justify-content: space-between; padding: 1mm 0; border-bottom: 0.5px dotted #999; }
    .signatures { margin-top: 15mm; display: flex; justify-content: space-around; font-size: 10px; }
    .signatures .case { border-top: 0.5px solid #333; width: 40%; text-align: center; padding-top: 2mm; }
  `;

  function pageEleve(eleve) {
    const lignesComposantes = eleve.composantes.map((c) => `
      <tr>
        <td>${c.libelle}</td>
        <td>${c.total ?? '-'}</td>
        <td>${c.pourcentage ?? '-'}%</td>
        <td>${c.classement ?? '-'}</td>
        <td>${c.mention ?? '-'}</td>
      </tr>
    `).join('');

    return `
      <div class="page">
        <div class="entete">
          ${ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${ecole.nom}</div>
          <div class="semestre">${semestreLibelle}</div>
        </div>
        <div class="titre-bulletin">Bulletin du semestre</div>
        <div class="identite">
          <div><strong>Nom :</strong> ${eleve.nom} ${eleve.postnom || ''} ${eleve.prenom || ''}</div>
          <div><strong>Matricule :</strong> ${eleve.matricule}</div>
          <div><strong>Classe :</strong> ${classe.nom} ${classe.option_nom ? '(' + classe.option_nom + ')' : ''}</div>
        </div>
        <table class="composantes">
          <thead>
            <tr><th>Composante</th><th>Total</th><th>Pourcentage</th><th>Classement</th><th>Mention</th></tr>
          </thead>
          <tbody>${lignesComposantes}</tbody>
        </table>
        <div class="synthese">
          <div><span>Moyenne du semestre</span><span>${eleve.moyenne_semestre ?? '-'}%</span></div>
          <div><span>Classement du semestre</span><span>${eleve.classement_semestre ?? '-'} / ${eleves.length}</span></div>
          <div><span>Mention</span><span>${eleve.mention_semestre ?? '-'}</span></div>
        </div>
        <div class="signatures">
          <div class="case">Signature du titulaire</div>
          <div class="case">Signature du directeur</div>
          <div class="case">Cachet de l'école</div>
        </div>
      </div>
    `;
  }

  const pagesHtml = eleves.map(pageEleve).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletinSemestre };
