/**
 * Construit le HTML complet des bulletins d'une classe pour une période,
 * en respectant la mise en page officielle : A4 paysage, 4 colonnes par page,
 * une nouvelle page dès que 4 élèves ont été placés.
 */
function construireHtmlBulletins({ ecole, anneeLibelle, periodeLibelle, classe, cours, eleves, signatureUrl, cachetUrl, mentionDuplicata, effectif }) {
  // Dénominateur du classement. Il vaut le nombre d'élèves imprimés dans le cas
  // courant (toute la classe), mais doit pouvoir être forcé : sur un duplicata
  // individuel, on imprime UN élève alors que son rang se lit sur l'effectif de
  // la classe à l'époque — sans quoi le bulletin afficherait « 3 / 1 ».
  const effectifClasse = effectif || eleves.length;

  // Date d'édition. Elle atteste du moment où la pièce a été délivrée : sans
  // elle, un bulletin réimprimé six mois plus tard ne se distingue pas de
  // l'original, et personne ne peut dire lequel fait foi.
  const maintenant = new Date();
  const dateEdition = maintenant.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  const lieuEdition = (ecole && ecole.ville) ? `Fait à ${ecole.ville}, le` : 'Fait le';
  const colonnesParPage = 4;
  const pages = [];
  for (let i = 0; i < eleves.length; i += colonnesParPage) {
    pages.push(eleves.slice(i, i + colonnesParPage));
  }

  const styles = `
    @page { size: A4 landscape; margin: 8mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 9px; margin: 0; }
    .page {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 0;
      width: 100%;
      height: 190mm;
      page-break-after: always;
    }
    .page:last-child { page-break-after: auto; }
    .colonne {
      border-right: 1px dashed #999;
      padding: 4mm 3mm;
      display: flex;
      flex-direction: column;
    }
    .colonne:last-child { border-right: none; }
    .entete { text-align: center; margin-bottom: 3mm; }
    .entete img { max-height: 14mm; margin-bottom: 1mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 10px; }
    .entete .annee { font-size: 8px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; margin: 2mm 0; font-size: 9.5px; }
    .identite { margin-bottom: 2mm; font-size: 8.5px; }
    .identite div { margin-bottom: 0.5mm; }
    table.notes { width: 100%; border-collapse: collapse; font-size: 8px; margin-bottom: 2mm; }
    table.notes th, table.notes td { border: 0.3px solid #666; padding: 1mm; text-align: center; }
    table.notes th { background: #eee; }
    table.notes td.cours-nom { text-align: left; }
    .synthese { font-size: 8.5px; margin-bottom: 2mm; }
    .synthese div { display: flex; justify-content: space-between; border-bottom: 0.3px dotted #999; }
    .appreciations { font-size: 8px; margin-bottom: 2mm; flex-grow: 1; }
    .appreciations div { margin-bottom: 1mm; }
    .signatures { font-size: 8px; margin-top: auto; }
    .fait-le { font-size: 8px; text-align: right; margin-top: 4mm; font-style: italic; }
    .signatures .ligne { display: flex; justify-content: space-between; margin-top: 6mm; }
    .signatures .case { border-top: 0.3px solid #333; width: 45%; text-align: center; padding-top: 1mm; }
    .signatures .case img { max-height: 10mm; max-width: 100%; display: block; margin: 0 auto 1mm auto; }

    /* Mention de réédition. Un duplicata doit être identifiable comme tel :
       sans elle, une réimpression tardive est indiscernable de l'original et
       peut être présentée comme une pièce délivrée à l'époque. */
    .mention-duplicata {
      text-align: center; font-size: 7.5px; letter-spacing: 0.06em;
      text-transform: uppercase; color: #8a2b2b;
      border: 0.4px solid #8a2b2b; border-radius: 1mm;
      padding: 0.6mm 1mm; margin-bottom: 2mm;
    }
  `;

  function colonneEleve(eleve) {
    const lignesNotes = cours.map((c) => {
      const note = eleve.notes.find((n) => n.classe_cours_id === c.classe_cours_id);
      const points = note && note.points_obtenus !== null && note.points_obtenus !== undefined
        ? note.points_obtenus
        : '-';
      return `<tr>
        <td class="cours-nom">${c.nom}</td>
        <td>${c.maximum}</td>
        <td>${points}</td>
      </tr>`;
    }).join('');

    return `
      <div class="colonne">
        <div class="entete">
          ${ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${ecole.nom}</div>
          <div class="annee">Année scolaire ${anneeLibelle || ''}</div>
        </div>
        <div class="titre-bulletin">Bulletin — ${periodeLibelle || ''}</div>
        ${mentionDuplicata ? `<div class="mention-duplicata">${mentionDuplicata}</div>` : ''}
        <div class="identite">
          <div><strong>Nom :</strong> ${eleve.nom} ${eleve.postnom || ''} ${eleve.prenom || ''}</div>
          <div><strong>Matricule :</strong> ${eleve.matricule}</div>
          <div><strong>Classe :</strong> ${classe.nom} ${classe.section_nom ? '— ' + classe.section_nom : ''} ${classe.option_nom ? '(' + classe.option_nom + ')' : ''}</div>
        </div>
        <table class="notes">
          <thead>
            <tr><th class="cours-nom">Cours</th><th>Max</th><th>Points</th></tr>
          </thead>
          <tbody>${lignesNotes}</tbody>
        </table>
        <div class="synthese">
          <div><span>Total</span><span>${eleve.total ?? '-'} / ${eleve.total_maximum ?? '-'}</span></div>
          <div><span>Pourcentage</span><span>${eleve.pourcentage ?? '-'}%</span></div>
          <div><span>Classement</span><span>${eleve.classement ?? '-'} / ${effectifClasse}</span></div>
          <div><span>Mention</span><span>${eleve.mention ?? '-'}</span></div>
        </div>
        <div class="appreciations">
          <div><strong>Conduite :</strong> ${eleve.conduite || ''}</div>
          <div><strong>Application :</strong> ${eleve.application || ''}</div>
          <div><strong>Observation :</strong> ${eleve.observation || ''}</div>
        </div>
        <div class="signatures">
          <div class="fait-le">${lieuEdition} ${dateEdition}</div>
          <div class="ligne">
            <div class="case">${signatureUrl ? `<img src="${signatureUrl}" />` : ''}Signature du titulaire</div>
            <div class="case">${cachetUrl ? `<img src="${cachetUrl}" />` : ''}Cachet de l'école</div>
          </div>
        </div>
      </div>
    `;
  }

  const pagesHtml = pages.map((groupe) => {
    const colonnes = groupe.map(colonneEleve).join('');
    return `<div class="page">${colonnes}</div>`;
  }).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletins };
