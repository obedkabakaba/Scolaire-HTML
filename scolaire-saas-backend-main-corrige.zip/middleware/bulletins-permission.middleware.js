const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * À placer sur les endpoints de génération de bulletins (impression PDF).
 * Directeur/Préfet/Secrétaire passent toujours. Un Titulaire ne passe que si
 * l'école l'autorise explicitement dans ses paramètres pédagogiques
 * (tous les titulaires, ou seulement certains nommément).
 */
async function autoriserGenerationBulletinsTitulaire(req, res, next) {
  if (req.auth.isSuperAdmin || req.auth.roles.some((r) => ['directeur', 'prefet', 'secretaire'].includes(r))) {
    return next();
  }
  if (!req.auth.roles.includes('titulaire')) {
    return res.status(403).json({ message: 'Accès refusé : rôle insuffisant.' });
  }

  try {
    const autorise = await runWithTenant(tenantContextFromReq(req), async (client) => {
      const ecoleResult = await client.query(
        `SELECT autoriser_bulletins_titulaires, bulletins_titulaires_mode FROM ecoles WHERE id = ${CURRENT_ECOLE}`
      );
      const ecole = ecoleResult.rows[0];
      if (!ecole || !ecole.autoriser_bulletins_titulaires) return false;
      if (ecole.bulletins_titulaires_mode === 'tous') return true;

      const autorisationResult = await client.query(
        `SELECT 1 FROM titulaires_generation_autorises WHERE ecole_id = ${CURRENT_ECOLE} AND utilisateur_id = $1`,
        [req.auth.userId]
      );
      return autorisationResult.rows.length > 0;
    });

    if (!autorise) {
      return res.status(403).json({ message: "La génération des bulletins n'a pas été autorisée pour les titulaires par ton établissement." });
    }
    return next();
  } catch (err) {
    console.error('Erreur vérification autorisation bulletins titulaire:', err);
    return res.status(500).json({ message: 'Erreur serveur.' });
  }
}

module.exports = { autoriserGenerationBulletinsTitulaire };
