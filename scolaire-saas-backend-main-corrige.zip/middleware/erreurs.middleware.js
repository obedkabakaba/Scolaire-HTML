/**
 * ARDOISE — CAPTURE PERSISTANTE DES ERREURS SERVEUR
 * ===========================================================================
 *
 * CE QU'IL AJOUTE À `metriques.middleware.js`
 * -------------------------------------------
 * Le collecteur de métriques répond à « combien » et « à quelle vitesse ». Il
 * garde tout en mémoire, ce qui est le bon choix pour une courbe rafraîchie
 * toutes les trente secondes — et le mauvais pour un diagnostic : un
 * redéploiement Render efface la seule trace du défaut qu'on cherchait, et la
 * CAUSE n'y a de toute façon jamais figuré.
 *
 * Ce middleware-ci répond à « pourquoi ». Il écrit en base, il écrit peu, et
 * il n'écrit que ce qui mérite d'être relu.
 *
 * DEUX PIÈCES, DEUX RÔLES
 * -----------------------
 *   `capteur`            observe les réponses 5xx, y compris celles produites
 *                        par un `catch` qui a répondu poliment
 *                        « Erreur serveur. » sans rien conserver.
 *   `gestionnaireFinal`  remplace le gestionnaire d'erreurs d'Express, qui se
 *                        contentait d'un `console.error(err)` — perdu au
 *                        prochain déploiement.
 *
 * POURQUOI LES DEUX SONT NÉCESSAIRES
 * ----------------------------------
 * Une exception non rattrapée passe par le gestionnaire final. Un contrôleur
 * qui répond lui-même `res.status(500).json({ message: 'Erreur serveur.' })`
 * n'y passe JAMAIS — et c'est la forme la plus fréquente dans ce dépôt. Le
 * capteur est le seul moyen de voir ces cas-là.
 *
 * CE QU'IL NE FAIT PAS
 * --------------------
 * Changer ce que l'utilisateur voit. Le message sûr reste le message sûr :
 * « Erreur serveur. » est ce qu'il faut afficher, et la pile d'appels est ce
 * qu'il faut conserver. Les deux, pas l'un à la place de l'autre.
 */

const journal = require('../utils/journal-erreurs.utils');
const { normaliserChemin } = require('./metriques.middleware');

/** Identifiant d'école porté par le jeton — jamais par le corps de requête. */
function ecoleDe(req) {
  return (req.auth && (req.auth.ecoleId || req.auth.ecole_id)) || null;
}

/**
 * Identifiant de corrélation.
 *
 * Posé sur chaque requête et renvoyé dans l'en-tête `X-Correlation-Id`. C'est
 * ce qui permet de relier « le directeur dit que ça a planté à 14 h 32 » à une
 * ligne précise du centre de bugs, sans avoir à fouiller par horodatage. Le
 * frontend le renvoie dans ses propres signalements.
 */
function correlation(req, res, suite) {
  const fourni = req.headers['x-correlation-id'];
  // Un identifiant fourni par le client est accepté mais BORNÉ et NETTOYÉ :
  // il finit dans une colonne de métadonnées, et rien n'empêche un client mal
  // intentionné d'y placer autre chose qu'un identifiant.
  req.correlationId = (typeof fourni === 'string' && /^[A-Za-z0-9_-]{6,64}$/.test(fourni))
    ? fourni
    : Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  res.setHeader('X-Correlation-Id', req.correlationId);
  suite();
}

/**
 * Observe les réponses en erreur serveur et les conserve.
 *
 * Rien n'est écrit avant `finish` : le coût est nul pour les requêtes qui se
 * passent bien, c'est-à-dire pour la quasi-totalité d'entre elles.
 */
function capteur(req, res, suite) {
  res.on('finish', () => {
    if (res.statusCode < 500) return;

    // Si le gestionnaire final a déjà consigné cette requête, on ne la compte
    // pas deux fois : le message qu'il détient est plus riche (il a l'objet
    // d'erreur), et deux empreintes différentes pour un même incident
    // dédoubleraient la ligne du centre de bugs.
    if (res.locals && res.locals.__erreurConsignee) return;

    journal.enregistrer({
      origine: 'backend',
      message: `HTTP ${res.statusCode} sur ${req.method} ${normaliserChemin(req.originalUrl)}`,
      methode: req.method,
      chemin: normaliserChemin(req.originalUrl),
      codeHttp: res.statusCode,
      ecoleId: ecoleDe(req),
      utilisateurId: (req.auth && req.auth.userId) || null,
      navigateur: req.headers['user-agent'] || null,
      gravite: journal.graviteDepuisStatut(res.statusCode),
      metadata: {
        correlation: req.correlationId || null,
        // Le corps N'EST PAS conservé : il contient des notes, des noms
        // d'élèves et parfois un mot de passe en cours de changement. Seules
        // ses CLÉS le sont — elles suffisent à reproduire l'appel, et elles
        // ne révèlent aucune donnée.
        champs_recus: req.body && typeof req.body === 'object'
          ? Object.keys(req.body).slice(0, 20) : [],
        deploiement: process.env.RENDER_GIT_COMMIT || process.env.VERSION_DEPLOIEMENT || null
      }
    });
  });
  suite();
}

/**
 * Gestionnaire d'erreurs final d'Express.
 *
 * Signature à quatre arguments obligatoire : c'est elle, et rien d'autre, qui
 * dit à Express qu'il s'agit d'un gestionnaire d'erreurs. `next` est donc
 * conservé même s'il n'est pas appelé.
 */
function gestionnaireFinal(err, req, res, next) {   // eslint-disable-line no-unused-vars
  if (res.locals) res.locals.__erreurConsignee = true;

  const statut = Number(err && err.statusCode) || 500;

  // Une erreur PORTANT un statut métier (402 d'offre, 403 de rôle) remontée
  // jusqu'ici n'est pas un défaut : on la sert telle quelle, sans l'inscrire
  // au centre de bugs. C'est exactement la règle demandée — un refus attendu
  // ne doit pas devenir un faux bug critique.
  if (journal.estRefusAttendu(statut)) {
    return res.status(statut).json({
      message: err.message || 'Requête refusée.',
      ...(err.code ? { code: err.code } : {})
    });
  }

  journal.enregistrer({
    origine: 'backend',
    message: (err && err.message) || 'Exception sans message',
    stack: err && err.stack,
    methode: req.method,
    chemin: normaliserChemin(req.originalUrl),
    codeHttp: statut,
    ecoleId: ecoleDe(req),
    utilisateurId: (req.auth && req.auth.userId) || null,
    navigateur: req.headers['user-agent'] || null,
    gravite: 'haute',
    metadata: {
      correlation: req.correlationId || null,
      // Utile et non sensible : `23505` dit « doublon », `42703` dit
      // « colonne inexistante ». C'est souvent la moitié du diagnostic.
      code_pg: (err && err.code) || null,
      contrainte: (err && err.constraint) || null,
      table: (err && err.table) || null,
      deploiement: process.env.RENDER_GIT_COMMIT || process.env.VERSION_DEPLOIEMENT || null
    }
  });

  // Le journal console reste : il sert au diagnostic à chaud, quand la base
  // est précisément ce qui ne répond pas.
  console.error('[erreur]', req.method, req.originalUrl, '—', err && err.message);

  // Le message rendu à l'utilisateur ne change pas d'un caractère. La cause
  // technique va au Super Admin, jamais à l'écran.
  return res.status(500).json({
    message: 'Erreur interne du serveur.',
    correlation: req.correlationId || null
  });
}

/**
 * À appeler depuis un `catch` qui répond lui-même un message sûr.
 *
 *   } catch (err) {
 *     signalerErreur(req, err, { ou: 'génération du bulletin annuel' });
 *     return res.status(500).json({ message: 'Erreur serveur.' });
 *   }
 *
 * Volontairement SYNCHRONE du point de vue de l'appelant : elle ne renvoie pas
 * de promesse à attendre. Un contrôleur ne doit jamais retarder sa réponse
 * pour écrire un journal.
 */
function signalerErreur(req, err, contexte = {}) {
  journal.enregistrer({
    origine: contexte.origine || 'backend',
    message: (err && err.message) || String(err) || 'Erreur sans message',
    stack: err && err.stack,
    methode: req && req.method,
    chemin: req ? normaliserChemin(req.originalUrl) : (contexte.chemin || null),
    codeHttp: contexte.codeHttp || 500,
    ecoleId: req ? ecoleDe(req) : (contexte.ecoleId || null),
    utilisateurId: (req && req.auth && req.auth.userId) || null,
    gravite: contexte.gravite || 'haute',
    metadata: {
      ou: contexte.ou || null,
      correlation: (req && req.correlationId) || null,
      code_pg: (err && err.code) || null
    }
  }).catch(() => { /* déjà géré dans le journal : jamais de seconde erreur */ });
}

/**
 * Échec d'une tâche planifiée ou d'un service externe.
 *
 * Ces échecs n'ont AUCUNE requête HTTP derrière eux : ni route, ni école, ni
 * utilisateur. Sans point d'entrée dédié, ils ne laissaient qu'un
 * `console.warn` que le prochain déploiement effaçait — et une file de
 * notifications qui ne partait plus depuis trois jours ne se voyait nulle part.
 */
function signalerTache(nomTache, err, contexte = {}) {
  journal.enregistrer({
    origine: contexte.origine || 'tache',
    message: `Tâche « ${nomTache} » en échec : ${(err && err.message) || err}`,
    stack: err && err.stack,
    chemin: `tache:${nomTache}`,
    gravite: contexte.gravite || 'haute',
    metadata: {
      tache: nomTache,
      service: contexte.service || null,
      code_pg: (err && err.code) || null
    }
  }).catch(() => { /* idem */ });
}

module.exports = {
  correlation,
  capteur,
  gestionnaireFinal,
  signalerErreur,
  signalerTache
};
