/**
 * Permissions du centre Finance.
 * ---------------------------------------------------------------------------
 * La mission (§ 24) demande deux profils :
 *
 *   · Super Admin          → accès complet à la gestion commerciale et financière
 *   · Super Admin Support  → lecture seule sur les données financières sensibles
 *
 * CE QUE CE FICHIER NE FAIT PAS
 * -----------------------------
 * Il ne touche NI à `superAdminSeul`, NI à l'ENUM `role_utilisateur`, NI au
 * middleware d'authentification. Le verrou d'entrée reste exactement celui
 * d'avant : il faut être Super Admin pour arriver ici. Ce middleware se pose
 * PAR-DESSUS et ne fait que retirer le droit d'écrire.
 *
 * POURQUOI PAS UN RÔLE ?
 * ----------------------
 * Trois raisons, dans l'ordre d'importance :
 *   1. `superAdminSeul` filtre sur `req.auth.isSuperAdmin`, dérivé du rôle
 *      `super_admin`. Un rôle `super_admin_support` n'entrerait pas dans
 *      l'espace — il faudrait modifier le middleware d'entrée, c'est-à-dire
 *      toucher au verrou le plus sensible de l'application pour une question
 *      de finances.
 *   2. Ajouter une valeur à un ENUM PostgreSQL est IRRÉVERSIBLE. Le HANDOVER
 *      raconte déjà l'histoire de la migration 008 où deux valeurs ont dû être
 *      ajoutées d'un coup pour cette raison.
 *   3. Un niveau d'accès se révoque. Une ligne dans `finance_acces` se change
 *      en une seconde, sans migration.
 *
 * PAR DÉFAUT : ACCÈS COMPLET
 * --------------------------
 * Absence de ligne = 'complet'. C'est exactement le comportement d'avant cette
 * extension : le Super Admin en place ne perd rien du jour au lendemain, ce
 * qui serait la pire façon de livrer une fonctionnalité de sécurité. La
 * restriction est un acte explicite, posé depuis l'écran Permissions.
 */

const { runWithTenant } = require('../config/db');

const METHODES_LECTURE = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * Cache court du niveau d'accès.
 *
 * Sans lui, chaque écriture financière ajoute un aller-retour en base pour
 * relire une ligne qui ne change presque jamais. 60 secondes est un compromis
 * assumé : une révocation met au plus une minute à prendre effet, ce qui est
 * acceptable pour un changement décidé et annoncé, et inacceptable seulement
 * si l'on imaginait révoquer un accès en urgence pendant une fraude en cours
 * — cas où l'on désactive le compte, ce qui coupe l'accès immédiatement par
 * un autre chemin.
 */
const cacheNiveaux = new Map();
const DUREE_CACHE_MS = 60 * 1000;

function oublier(utilisateurId) {
  if (utilisateurId) cacheNiveaux.delete(String(utilisateurId));
  else cacheNiveaux.clear();
}

async function niveauAcces(utilisateurId) {
  if (!utilisateurId) return 'complet';
  const cle = String(utilisateurId);

  const memorise = cacheNiveaux.get(cle);
  if (memorise && memorise.expire > Date.now()) return memorise.niveau;

  let niveau = 'complet';
  try {
    const r = await runWithTenant({ isSuperAdmin: true }, (client) =>
      client.query('SELECT niveau FROM finance_acces WHERE utilisateur_id = $1', [utilisateurId])
    );
    if (r.rows.length && r.rows[0].niveau === 'lecture') niveau = 'lecture';
  } catch (err) {
    // Table absente (migration 027 non jouée) : on retombe sur le
    // comportement historique — accès complet — plutôt que de bloquer
    // l'exploitant hors de son propre outil.
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[finance] niveau d\'accès indéterminé :', err.message);
    }
  }

  cacheNiveaux.set(cle, { niveau, expire: Date.now() + DUREE_CACHE_MS });
  return niveau;
}

/**
 * Renseigne `req.finance = { niveau, peutEcrire }` sans rien bloquer.
 * Posé sur toute la branche : les contrôleurs de lecture s'en servent pour
 * masquer ce qui doit l'être, et l'interface pour griser les boutons.
 */
async function contexteFinance(req, res, next) {
  try {
    const niveau = await niveauAcces(req.auth ? req.auth.userId : null);
    req.finance = { niveau, peutEcrire: niveau === 'complet' };
  } catch {
    req.finance = { niveau: 'complet', peutEcrire: true };
  }
  next();
}

/**
 * Refuse toute méthode d'écriture à un accès « lecture ».
 *
 * Le filtre porte sur la MÉTHODE HTTP et non sur une liste de chemins :
 * une route d'écriture ajoutée plus tard sera couverte sans qu'on ait à y
 * penser, ce qui est précisément la propriété qu'on veut d'un garde-fou.
 */
function financeEcriture(req, res, next) {
  if (METHODES_LECTURE.has(req.method)) return next();

  if (req.finance && req.finance.peutEcrire === false) {
    return res.status(403).json({
      message: 'Accès financier en lecture seule : cette action est réservée au Super Administrateur.',
      code: 'FINANCE_LECTURE_SEULE'
    });
  }
  next();
}

/**
 * Garde des actions particulièrement sensibles (mission § 25) : elles exigent
 * une confirmation explicite transmise par le client, en plus des droits.
 *
 * Le client envoie `{ confirmation: true }` (ou `confirmer: true`) dans le
 * corps. Ce n'est pas une sécurité contre un attaquant — il lui suffirait
 * d'ajouter le champ — mais contre l'accident : un appel de script, un
 * rejeu de requête, un bouton cliqué deux fois. La vraie barrière contre
 * l'attaquant, c'est `superAdminSeul` plus haut dans la chaîne.
 */
function exigerConfirmation(req, res, next) {
  const corps = req.body || {};
  if (corps.confirmation === true || corps.confirmer === true) return next();
  return res.status(400).json({
    message: 'Action sensible : confirmation explicite requise.',
    code: 'CONFIRMATION_REQUISE',
    detail: 'Renvoyez la requête avec { "confirmation": true } après validation de l\'utilisateur.'
  });
}

module.exports = {
  contexteFinance, financeEcriture, exigerConfirmation,
  niveauAcces, oublier, METHODES_LECTURE
};
