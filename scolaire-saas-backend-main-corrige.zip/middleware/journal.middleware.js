const { runWithTenant } = require('../config/db');

/**
 * ============================================================================
 *  JOURNALISATION AUTOMATIQUE
 * ============================================================================
 *
 * POURQUOI CE MIDDLEWARE
 * ----------------------
 * Le journal était alimenté par des `INSERT INTO journal_activite` écrits à la
 * main dans les contrôleurs : une quinzaine d'appels répartis sur 11 des 37
 * contrôleurs. Tout le reste — modification d'une classe, suppression d'un
 * cours, changement du taux de change, correction d'une orientation, retrait
 * d'un rôle — ne laissait aucune trace. Et chaque nouvelle fonctionnalité
 * repartait avec la même dette : il fallait penser à journaliser.
 *
 * La demande était « TOUT, de tout le monde, sans exception ». Une exigence
 * d'exhaustivité ne se satisfait pas d'une discipline de développeur : elle
 * se satisfait d'un point de passage obligé. Ce middleware est ce point.
 *
 * CE QUI EST JOURNALISÉ
 * ---------------------
 * · TOUTE requête qui modifie l'état (POST, PUT, PATCH, DELETE), qu'elle
 *   réussisse OU qu'elle échoue. Un 403 répété sur un écran sensible est une
 *   information au moins aussi utile qu'une réussite.
 * · Les connexions et déconnexions.
 * · Une liste courte de LECTURES sensibles (exports, PDF de bulletins, états
 *   financiers) : consulter la situation financière de toutes les familles
 *   est un acte qui mérite une trace, même s'il ne modifie rien.
 *
 * CE QUI NE L'EST PAS, ET POURQUOI
 * --------------------------------
 * Les lectures ordinaires. Journaliser chaque affichage d'écran ferait entrer
 * plusieurs centaines de lignes par utilisateur et par jour : le journal
 * deviendrait illisible, et donc inutile — l'exhaustivité qui noie
 * l'information la détruit aussi sûrement que l'oubli. On trace les actes,
 * pas les regards, sauf là où le regard est lui-même un acte.
 *
 * GARANTIES
 * ---------
 * · Aucun mot de passe, jeton, ni hash n'est jamais écrit dans le journal.
 * · L'écriture a lieu APRÈS la réponse au client : elle n'ajoute aucune
 *   latence perçue.
 * · Un échec de journalisation ne fait JAMAIS échouer l'action de
 *   l'utilisateur. Le directeur doit pouvoir inscrire un élève même si la
 *   table de journal est indisponible ; l'incident part dans les logs serveur.
 */

// ---------------------------------------------------------------------------
//  Confidentialité
// ---------------------------------------------------------------------------

/**
 * Champs dont la valeur ne doit jamais entrer dans le journal. Le motif est
 * remplacé par une balise plutôt que supprimé : savoir QU'UN mot de passe a
 * été transmis fait partie de la trace, connaître sa valeur non.
 */
const CHAMPS_SENSIBLES = /(mot_de_passe|password|passe|token|secret|hash|cle_api|api_key|authorization)/i;

const LONGUEUR_MAX_VALEUR = 300;
const LONGUEUR_MAX_METADATA = 4000;

function assainir(valeur, profondeur = 0) {
  if (valeur === null || valeur === undefined) return valeur;
  if (profondeur > 4) return '[…]';

  if (Array.isArray(valeur)) {
    // Les envois en lot (une classe entière de notes) sont résumés : on garde
    // le volume, qui est l'information utile, pas les 40 lignes de détail.
    if (valeur.length > 10) {
      return `[${valeur.length} éléments]`;
    }
    return valeur.map((v) => assainir(v, profondeur + 1));
  }

  if (typeof valeur === 'object') {
    const sortie = {};
    for (const [cle, v] of Object.entries(valeur)) {
      sortie[cle] = CHAMPS_SENSIBLES.test(cle) ? '[masqué]' : assainir(v, profondeur + 1);
    }
    return sortie;
  }

  if (typeof valeur === 'string' && valeur.length > LONGUEUR_MAX_VALEUR) {
    return valeur.slice(0, LONGUEUR_MAX_VALEUR) + '…';
  }
  return valeur;
}

// ---------------------------------------------------------------------------
//  Lecture du chemin : quelle ressource, quel identifiant ?
// ---------------------------------------------------------------------------

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Traduit le premier segment d'URL en nom de ressource au singulier. Ce
 * dictionnaire n'a pas besoin d'être exhaustif : un segment inconnu est
 * conservé tel quel, ce qui reste lisible dans le journal.
 */
const RESSOURCES = {
  'eleves': 'eleve', 'utilisateurs': 'utilisateur', 'classes': 'classe',
  'cours': 'cours', 'notes': 'note', 'travaux': 'travail',
  'bulletins': 'bulletin', 'frais': 'frais', 'paiements': 'paiement',
  'presences': 'presence', 'discipline': 'discipline', 'orientation': 'orientation',
  'inscriptions': 'inscription', 'promotion': 'promotion', 'archives': 'archive',
  'annees-scolaires': 'annee_scolaire', 'periodes': 'periode', 'options': 'option',
  'sections': 'section', 'vacations': 'vacation', 'classe-cours': 'classe_cours',
  'emploi-du-temps': 'emploi_du_temps', 'evenements': 'calendrier',
  'modeles-bulletins': 'modele_bulletin', 'mentions': 'mention',
  'notifications': 'notification', 'communication': 'communication',
  'site-public': 'site_public', 'ecole': 'ecole', 'admin': 'ecole',
  'abonnements': 'abonnement', 'uploads': 'fichier', 'ia': 'ia',
  'auth': 'session', 'jobs': 'job', 'rapports': 'rapport'
};

/**
 * Verbe métier lisible. On préfère « créé / modifié / supprimé » au verbe HTTP :
 * le journal est lu par un directeur, pas par un développeur.
 */
const VERBES = {
  POST: 'cree', PUT: 'modifie', PATCH: 'modifie', DELETE: 'supprime'
};

function analyserChemin(req) {
  const chemin = (req.originalUrl || req.url || '').split('?')[0];
  const segments = chemin.split('/').filter(Boolean);

  const ressource = RESSOURCES[segments[0]] || segments[0] || 'inconnu';

  // Premier identifiant rencontré dans le chemin : c'est la cible de l'action.
  let cibleId = null;
  for (const s of segments) {
    if (UUID.test(s)) { cibleId = s; break; }
  }

  // Un sous-chemin nommé précise l'action : /discipline/conduite/appliquer
  // devient « discipline.conduite_appliquer », plus parlant que
  // « discipline.cree ».
  const precisions = segments.slice(1).filter((s) => !UUID.test(s));
  const suffixe = precisions.length
    ? precisions.join('_')
    : VERBES[req.method] || req.method.toLowerCase();

  return { action: `${ressource}.${suffixe}`, cibleType: ressource, cibleId, chemin };
}

// ---------------------------------------------------------------------------
//  Périmètre
// ---------------------------------------------------------------------------

const METHODES_ECRITURE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/**
 * Lectures qui laissent une trace malgré tout. Consulter la liste nominative
 * des impayés d'une école, ou télécharger le bulletin d'un élève, sont des
 * actes de consultation de données personnelles : savoir qui l'a fait a une
 * valeur, y compris pour protéger l'agent qui l'a fait légitimement.
 */
const LECTURES_TRACEES = [
  /^\/rapports\/finances/, /^\/frais\/.*\/(export|recu)/, /^\/archives\//,
  /^\/bulletins\/.*\/(pdf|generer)/, /^\/bulletin-annuel/, /^\/ia\//,
  /^\/discipline\/eleves\/.*\/historique/, /^\/journal-activite/
];

/**
 * Routes dont la journalisation systématique n'apporterait rien et polluerait
 * le journal : les tâches planifiées écrivent déjà leurs propres entrées
 * métier, et le rafraîchissement de jeton se produit toutes les 15 minutes
 * pour chaque utilisateur connecté.
 */
const IGNOREES = [/^\/auth\/refresh/, /^\/jobs\//, /^\/uploads\/temporaire/];

function doitJournaliser(req) {
  const chemin = (req.originalUrl || req.url || '').split('?')[0];
  if (IGNOREES.some((motif) => motif.test(chemin))) return false;
  if (METHODES_ECRITURE.has(req.method)) return true;
  if (req.method === 'GET') return LECTURES_TRACEES.some((motif) => motif.test(chemin));
  return false;
}

// ---------------------------------------------------------------------------
//  Le middleware
// ---------------------------------------------------------------------------

function journaliserRequetes(req, res, next) {
  if (!doitJournaliser(req)) return next();

  // La réponse est interceptée pour deux raisons : récupérer l'identifiant
  // d'une ressource qui vient d'être créée (il n'existe pas encore dans
  // l'URL), et retrouver l'école lors d'une connexion, moment où `req.auth`
  // n'existe pas encore.
  let corpsReponse = null;
  const jsonOriginal = res.json.bind(res);
  res.json = function (donnees) {
    corpsReponse = donnees;
    return jsonOriginal(donnees);
  };

  // 'finish' plutôt qu'un await : l'utilisateur a déjà sa réponse quand nous
  // écrivons. Le journal ne doit ralentir personne.
  res.on('finish', () => {
    ecrireEntree(req, res, corpsReponse).catch((err) => {
      // Volontairement silencieux côté utilisateur : l'action a réussi, seule
      // sa trace a échoué. On alerte l'exploitant, pas l'école.
      console.error('Journalisation impossible:', err.message);
    });
  });

  next();
}

async function ecrireEntree(req, res, corpsReponse) {
  const { action, cibleType, cibleId, chemin } = analyserChemin(req);

  // Contexte : utilisateur authentifié, ou connexion en cours d'établissement
  // (auquel cas l'identité se lit dans la réponse et non dans le jeton).
  let ecoleId = req.auth?.ecoleId || null;
  let utilisateurId = req.auth?.userId || null;
  const estSuperAdmin = req.auth?.isSuperAdmin === true;

  const utilisateurReponse = corpsReponse && corpsReponse.user;
  if (!utilisateurId && utilisateurReponse && utilisateurReponse.id) {
    utilisateurId = utilisateurReponse.id;
    ecoleId = ecoleId || utilisateurReponse.ecole_id || null;
  }

  // Un super-admin agit sur une école désignée dans l'URL ou le corps.
  if (!ecoleId) {
    ecoleId = req.body?.ecole_id || req.params?.ecoleId || req.query?.ecoleId || null;
  }

  // Sans contexte d'école NI super-admin, l'écriture serait de toute façon
  // refusée par la RLS : on renonce plutôt que de lever une erreur inutile.
  if (!ecoleId && !estSuperAdmin) return;

  const reussite = res.statusCode < 400;

  const metadata = {
    // `source` distingue cette trace automatique des entrées métier écrites
    // explicitement par les contrôleurs (« notes.validees »…), qui restent en
    // place car elles portent un sens qu'une URL ne dit pas.
    source: 'automatique',
    methode: req.method,
    chemin,
    statut: res.statusCode,
    reussite,
    ip: req.ip || null,
    agent: (req.headers['user-agent'] || '').slice(0, 200) || null
  };

  if (req.body && Object.keys(req.body).length > 0) {
    metadata.donnees = assainir(req.body);
  }
  if (!reussite && corpsReponse && corpsReponse.message) {
    metadata.refus = String(corpsReponse.message).slice(0, LONGUEUR_MAX_VALEUR);
  }

  // Identifiant de la ressource fraîchement créée, absent de l'URL.
  const idCree = cibleId
    || (corpsReponse && (corpsReponse.id || (corpsReponse.user && corpsReponse.user.id)))
    || null;

  let metadataJson = JSON.stringify(metadata);
  if (metadataJson.length > LONGUEUR_MAX_METADATA) {
    metadataJson = JSON.stringify({
      ...metadata,
      donnees: '[volumineux — détail non conservé]'
    });
  }

  await runWithTenant({ ecoleId, isSuperAdmin: estSuperAdmin }, (client) =>
    client.query(
      `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
      [ecoleId, utilisateurId, action, cibleType, UUID.test(String(idCree || '')) ? idCree : null, metadataJson]
    )
  );
}

module.exports = journaliserRequetes;
