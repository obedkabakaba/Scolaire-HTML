/**
 * Collecteur de métriques d'API — en mémoire, sans dépendance.
 * ---------------------------------------------------------------------------
 * La page « Santé de la plateforme » réclame un temps de réponse, un taux
 * d'erreur et un débit en temps réel. Les écrire en base à chaque requête
 * coûterait une écriture par requête — soit doubler la charge de la base pour
 * mesurer la charge de la base.
 *
 * Ce collecteur garde donc tout en mémoire du processus :
 *   · un anneau des 2 000 dernières requêtes (détail, latences, erreurs) ;
 *   · 60 seaux d'une minute (courbe de la dernière heure).
 *
 * Conséquence assumée : un redéploiement Render remet les compteurs à zéro.
 * C'est pour cela que `controllers/super-admin-systeme.controller.js` relève
 * périodiquement ces valeurs dans `metriques_plateforme` — la mémoire donne
 * l'instantané, la base donne l'historique.
 *
 * Coût : quelques dizaines de kilo-octets, aucune E/S.
 */

const TAILLE_ANNEAU = 2000;
const NB_SEAUX = 60;              // 60 minutes glissantes
const DUREE_SEAU_MS = 60 * 1000;
const SEUIL_LENTEUR_MS = 1500;

const anneau = new Array(TAILLE_ANNEAU);
let curseur = 0;
let total = 0;

const seaux = new Array(NB_SEAUX).fill(null).map(() => seauVide());
const demarrage = Date.now();

function seauVide() {
  return { minute: null, nb: 0, erreurs: 0, sommeMs: 0, maxMs: 0, lentes: 0 };
}

function indexSeau(horodatage) {
  return Math.floor(horodatage / DUREE_SEAU_MS) % NB_SEAUX;
}

/**
 * Réduit un chemin à sa forme générique : /eleves/8c1f-… devient /eleves/:id.
 * Sans cette normalisation, chaque identifiant produirait sa propre ligne et
 * le classement des routes les plus lentes n'aurait aucun sens.
 */
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function normaliserChemin(chemin) {
  return (
    '/' +
    String(chemin || '')
      .split('?')[0]
      .split('/')
      .filter(Boolean)
      .map((segment) => {
        if (UUID.test(segment)) return ':id';
        if (/^\d+$/.test(segment)) return ':n';
        return segment;
      })
      .slice(0, 4)
      .join('/')
  );
}

function collecteur(req, res, suite) {
  const debut = process.hrtime.bigint();

  res.on('finish', () => {
    const dureeMs = Number(process.hrtime.bigint() - debut) / 1e6;
    const maintenant = Date.now();
    const enErreur = res.statusCode >= 500;

    anneau[curseur] = {
      at: maintenant,
      methode: req.method,
      chemin: normaliserChemin(req.originalUrl),
      statut: res.statusCode,
      dureeMs: Math.round(dureeMs),
      ecoleId: req.auth?.ecoleId || null
    };
    curseur = (curseur + 1) % TAILLE_ANNEAU;
    total++;

    const i = indexSeau(maintenant);
    const minute = Math.floor(maintenant / DUREE_SEAU_MS);
    if (seaux[i].minute !== minute) seaux[i] = { ...seauVide(), minute };
    const seau = seaux[i];
    seau.nb++;
    seau.sommeMs += dureeMs;
    if (dureeMs > seau.maxMs) seau.maxMs = dureeMs;
    if (dureeMs > SEUIL_LENTEUR_MS) seau.lentes++;
    if (enErreur) seau.erreurs++;
  });

  suite();
}

function echantillon() {
  return anneau.filter(Boolean);
}

function percentile(valeurs, p) {
  if (!valeurs.length) return 0;
  const tri = [...valeurs].sort((a, b) => a - b);
  const rang = Math.min(tri.length - 1, Math.floor((p / 100) * tri.length));
  return Math.round(tri[rang]);
}

/**
 * Instantané destiné à la page Santé.
 * @param {number} fenetreMinutes - profondeur d'analyse (défaut : 60)
 */
function resume(fenetreMinutes = 60) {
  const depuis = Date.now() - fenetreMinutes * DUREE_SEAU_MS;
  const recentes = echantillon().filter((l) => l.at >= depuis);
  const latences = recentes.map((l) => l.dureeMs);

  const parChemin = new Map();
  for (const ligne of recentes) {
    const cle = `${ligne.methode} ${ligne.chemin}`;
    const e = parChemin.get(cle) || { route: cle, nb: 0, sommeMs: 0, maxMs: 0, erreurs: 0 };
    e.nb++;
    e.sommeMs += ligne.dureeMs;
    if (ligne.dureeMs > e.maxMs) e.maxMs = ligne.dureeMs;
    if (ligne.statut >= 500) e.erreurs++;
    parChemin.set(cle, e);
  }

  const routes = [...parChemin.values()]
    .map((e) => ({ route: e.route, nb: e.nb, moyenne_ms: Math.round(e.sommeMs / e.nb), max_ms: e.maxMs, erreurs: e.erreurs }))
    .sort((a, b) => b.moyenne_ms - a.moyenne_ms);

  const parStatut = {};
  for (const ligne of recentes) {
    const famille = `${Math.floor(ligne.statut / 100)}xx`;
    parStatut[famille] = (parStatut[famille] || 0) + 1;
  }

  // Courbe : on réordonne les seaux du plus ancien au plus récent.
  const minuteCourante = Math.floor(Date.now() / DUREE_SEAU_MS);
  const courbe = [];
  for (let decalage = fenetreMinutes - 1; decalage >= 0; decalage--) {
    const minute = minuteCourante - decalage;
    const seau = seaux[((minute % NB_SEAUX) + NB_SEAUX) % NB_SEAUX];
    const valide = seau.minute === minute;
    courbe.push({
      horodatage: new Date(minute * DUREE_SEAU_MS).toISOString(),
      requetes: valide ? seau.nb : 0,
      erreurs: valide ? seau.erreurs : 0,
      moyenne_ms: valide && seau.nb ? Math.round(seau.sommeMs / seau.nb) : 0,
      lentes: valide ? seau.lentes : 0
    });
  }

  const nb = recentes.length;
  const erreurs = recentes.filter((l) => l.statut >= 500).length;

  return {
    fenetre_minutes: fenetreMinutes,
    total_depuis_demarrage: total,
    uptime_secondes: Math.round((Date.now() - demarrage) / 1000),
    requetes: nb,
    requetes_par_minute: Math.round((nb / fenetreMinutes) * 10) / 10,
    erreurs,
    taux_erreur: nb ? Math.round((erreurs / nb) * 1000) / 10 : 0,
    latence_moyenne_ms: nb ? Math.round(latences.reduce((s, v) => s + v, 0) / nb) : 0,
    latence_p50_ms: percentile(latences, 50),
    latence_p95_ms: percentile(latences, 95),
    latence_p99_ms: percentile(latences, 99),
    requetes_lentes: recentes.filter((l) => l.dureeMs > SEUIL_LENTEUR_MS).length,
    par_statut: parStatut,
    routes_les_plus_lentes: routes.slice(0, 12),
    routes_les_plus_appelees: [...routes].sort((a, b) => b.nb - a.nb).slice(0, 12),
    courbe
  };
}

/** Dernières erreurs 5xx observées — alimente le recoupement du centre de bugs. */
function dernieresErreurs(limite = 50) {
  return echantillon()
    .filter((l) => l.statut >= 500)
    .sort((a, b) => b.at - a.at)
    .slice(0, limite);
}

module.exports = { collecteur, resume, dernieresErreurs, normaliserChemin, SEUIL_LENTEUR_MS };
