const { runWithTenant } = require('../config/db');

/**
 * Verrou du mot de passe provisoire — Ardoise
 * --------------------------------------------------------------------------
 * Tant qu'un utilisateur n'a pas remplacé son mot de passe provisoire, il ne
 * peut RIEN faire d'autre que le changer.
 *
 * Ce contrôle est fait ici, côté serveur, et non par une redirection dans la
 * page : une redirection se contourne en tapant une adresse à la main, ce qui
 * laisserait un compte entier accessible avec un mot de passe connu de toute
 * l'école.
 *
 * Quatre chemins restent ouverts, sans quoi la personne serait enfermée :
 *   · changer son mot de passe, évidemment ;
 *   · lire son propre profil, dont la page a besoin pour s'afficher ;
 *   · rafraîchir son jeton, qui expire au bout de quinze minutes ;
 *   · se déconnecter.
 */

const CHEMINS_AUTORISES = [
  { methode: 'POST', motif: /^\/utilisateurs\/moi\/changer-mot-de-passe$/ },
  { methode: 'GET', motif: /^\/utilisateurs\/moi$/ },
  { methode: 'POST', motif: /^\/auth\/refresh$/ },
  { methode: 'POST', motif: /^\/auth\/logout$/ }
];

// L'état est relu en base à chaque requête plutôt que porté par le jeton :
// un jeton reste valable quinze minutes, et l'utilisateur doit retrouver ses
// accès dès la seconde qui suit son changement de mot de passe.
async function motDePasseProvisoireMiddleware(req, res, next) {
  if (!req.auth || !req.auth.userId) return next();
  if (req.method === 'OPTIONS') return next();

  const chemin = req.baseUrl + (req.path === '/' ? '' : req.path);
  const autorise = CHEMINS_AUTORISES.some(
    (c) => c.methode === req.method && c.motif.test(chemin)
  );
  if (autorise) return next();

  try {
    const doitChanger = await runWithTenant({ isSuperAdmin: true }, async (client) => {
      const r = await client.query(
        `SELECT COALESCE(doit_changer_mot_de_passe, false) AS doit FROM utilisateurs WHERE id = $1`,
        [req.auth.userId]
      );
      return r.rows[0] ? r.rows[0].doit === true : false;
    });

    if (!doitChanger) return next();

    // Le code 428 dit exactement cela : une condition préalable est requise.
    // Le frontend s'en sert pour rediriger sans avoir à lire le message.
    return res.status(428).json({
      code: 'MOT_DE_PASSE_A_CHANGER',
      message: "Vous devez d'abord remplacer votre mot de passe provisoire avant d'utiliser la plateforme."
    });
  } catch (err) {
    // Une panne de vérification ne doit pas bloquer toute la plateforme :
    // on laisse passer et on journalise. Le risque est très inférieur à celui
    // d'une école entière hors service.
    console.error('Vérification du mot de passe provisoire impossible:', err.message);
    return next();
  }
}

module.exports = motDePasseProvisoireMiddleware;
