/**
 * Tests du verrou d'offre.
 *
 * `catalogue.test.js` vérifie les CALCULS ; celui-ci vérifie les DÉCISIONS :
 * qui passe, qui est refusé, et avec quel message. C'est le fichier qui
 * empêche une refonte future de rouvrir la comptabilité à tout le monde, ou —
 * plus grave — de fermer la saisie des notes à une école qui a payé.
 *
 * La base est simulée : ces tests n'ont besoin d'aucune connexion, et doivent
 * pouvoir tourner sur un poste de développement en une seconde. Ce qui est
 * simulé, c'est UNIQUEMENT la ligne renvoyée par PostgreSQL ; toute la logique
 * de décision est celle du vrai middleware.
 *
 *   node --test test/offre-middleware.test.js
 */

const test = require('node:test');
const assert = require('node:assert');
const Module = require('module');

/* ------------------------------------------------------- Base simulée */

let planSimule = null;      // la ligne que renverrait `plans_abonnement`
let effectifSimule = 240;   // ce que compte la requête de plafond

const requireOrigine = Module.prototype.require;
Module.prototype.require = function (chemin) {
  if (chemin === '../config/db' || chemin === './config/db') {
    return {
      runWithTenant: (contexte, travail) => travail({
        query: async (sql) => {
          if (/FROM abonnements/.test(sql) && /plans_abonnement/.test(sql)) {
            return { rows: planSimule ? [planSimule] : [] };
          }
          if (/count\(\*\)/.test(sql)) return { rows: [{ total: effectifSimule }] };
          return { rows: [] };
        }
      })
    };
  }
  return requireOrigine.apply(this, arguments);
};

const catalogue = require('../utils/catalogue.utils');
const { exigeFonctionnalite, verifierPlafond, COMPTAGES } =
  require('../middleware/offre.middleware');

/* ------------------------------------------------------------ Outillage */

function plan(limites, fonctionnalites) {
  return {
    id: 'p1', code: 'test', nom: 'Offre de test', prix: 35, devise: 'USD',
    duree_jours: 30, limites, fonctionnalites,
    fonctionnalites_incluses: [], fonctionnalites_exclues: [],
    abonnement_statut: 'actif', periodicite: 'mensuel'
  };
}

const DIRECTEUR = { userId: 'u1', ecoleId: 'e1', roles: ['directeur'], isSuperAdmin: false };

/**
 * Fait passer une requête dans un middleware et rapporte ce qui s'est produit.
 * Le cache est vidé à chaque appel : sans cela, on testerait la mémoire d'une
 * minute et non la règle.
 */
function traverser(middleware, auth = DIRECTEUR, corps = {}) {
  catalogue.invaliderCache();
  return new Promise((resoudre) => {
    const req = { auth, body: corps };
    const res = { code: 200 };
    let fini = false;
    const conclure = (passe) => {
      if (fini) return;
      fini = true;
      resoudre({ passe, code: res.code, corps: res.corps });
    };
    res.status = (c) => { res.code = c; return res; };
    res.json = (o) => { res.corps = o; conclure(false); return res; };
    Promise.resolve(middleware(req, res, () => conclure(true))).catch(() => conclure(false));
    setTimeout(() => conclure(false), 1000);
  });
}

const ASCENSION = plan(
  { max_eleves: 250, max_utilisateurs: 15, max_classes: 12, ia_quota_mensuel: 100 },
  { assistant_aide: true, ia_appreciations: true });

const PILOTE = plan(
  { max_eleves: 1500, max_utilisateurs: 120, max_classes: null, ia_quota_mensuel: 1500 },
  { assistant_aide: true, ia_appreciations: true, comptabilite: true, paie: true,
    concours_admission: true, orientation: true, repechage: true,
    rapports_avances: true, ia_analyse_donnees: true, emploi_du_temps: true,
    discipline: true, communication_masse: true, site_public: true,
    modeles_personnalises: true, ia_reglement_discipline: true });

/* =========================================================================
   DROITS
   ========================================================================= */

test('un module non souscrit est refusé, avec 402 et un code exploitable', async () => {
  planSimule = ASCENSION;
  const r = await traverser(exigeFonctionnalite('comptabilite'));

  assert.strictEqual(r.passe, false, 'la comptabilité ne doit pas passer en Ascension');
  assert.strictEqual(r.code, 402, '402 et non 403 : le directeur A le droit, il n\'a pas souscrit');
  assert.strictEqual(r.corps.code, 'offre_insuffisante');
  assert.strictEqual(r.corps.fonctionnalite, 'comptabilite',
    'le frontend doit pouvoir nommer ce qui manque sans lire le message français');
  assert.ok(r.corps.message && r.corps.action, 'un refus dit toujours quoi faire ensuite');
});

test('un module souscrit passe', async () => {
  planSimule = PILOTE;
  for (const code of ['comptabilite', 'paie', 'concours_admission', 'orientation',
                      'repechage', 'rapports_avances', 'emploi_du_temps', 'discipline']) {
    const r = await traverser(exigeFonctionnalite(code));
    assert.strictEqual(r.passe, true, `${code} devrait passer en Pilote`);
  }
});

test('ce que Pilote ne comprend pas reste fermé', async () => {
  planSimule = PILOTE;
  const r = await traverser(exigeFonctionnalite('whatsapp'));
  assert.strictEqual(r.passe, false);
  assert.strictEqual(r.corps.code, 'offre_insuffisante');
});

test("l'assistance IA passe dans l'offre la plus modeste", async () => {
  // La règle commerciale la plus importante du projet : l'IA d'assistance
  // n'est pas un argument de montée en gamme.
  planSimule = ASCENSION;
  for (const code of ['assistant_aide', 'ia_appreciations']) {
    const r = await traverser(exigeFonctionnalite(code));
    assert.strictEqual(r.passe, true, `${code} doit être ouvert dès Ascension`);
  }
});

test('sans abonnement actif, on laisse passer plutôt que de fermer une école', async () => {
  planSimule = null;
  const r = await traverser(exigeFonctionnalite('comptabilite'));
  assert.strictEqual(r.passe, true,
    'une panne de facturation ne doit pas couper les modules la veille des bulletins');
});

test('le Super Admin sans école n\'est jamais arrêté par un verrou d\'offre', async () => {
  planSimule = ASCENSION;
  const r = await traverser(exigeFonctionnalite('comptabilite'),
    { userId: 's1', ecoleId: null, roles: [], isSuperAdmin: true });
  assert.strictEqual(r.passe, true);
});

test('un code de fonctionnalité inconnu fait échouer le DÉMARRAGE, pas la requête', async () => {
  // Une faute de frappe doit casser le déploiement. Si elle ne se voyait qu'à
  // l'exécution, elle s'installerait comme un « toujours refusé » silencieux.
  assert.throws(() => exigeFonctionnalite('comptabilitee'), /code inconnu/);
  assert.throws(() => exigeFonctionnalite('notes'), /code inconnu/,
    'les fonctionnalités essentielles ne sont pas verrouillables, donc pas de code');
});

/* =========================================================================
   PLAFONDS
   ========================================================================= */

test('sous le plafond, la création passe', async () => {
  planSimule = ASCENSION; effectifSimule = 240;
  const r = await traverser(verifierPlafond('max_eleves', 1));
  assert.strictEqual(r.passe, true, '241 élèves sur un plafond de 250');
});

test('un import qui ferait franchir le plafond est refusé AVANT d\'écrire', async () => {
  planSimule = ASCENSION; effectifSimule = 240;
  const r = await traverser(verifierPlafond('max_eleves', 20));

  assert.strictEqual(r.passe, false, '240 + 20 dépasse 250');
  assert.strictEqual(r.code, 402);
  assert.strictEqual(r.corps.code, 'plafond_atteint');
  assert.strictEqual(r.corps.plafond, 250);
  assert.strictEqual(r.corps.utilise, 240);
  assert.strictEqual(r.corps.restant, 10);
  assert.match(r.corps.message, /reste 10/,
    'le message doit chiffrer ce qui reste : « plafond atteint » seul n\'aide personne');
});

test('un import compté à l\'unité laisserait passer un fichier entier', async () => {
  // Le défaut que le comptage par lot évite : sans lui, un fichier de 400
  // élèves franchit un plafond de 250 sans que rien ne s'y oppose.
  planSimule = ASCENSION; effectifSimule = 240;
  const auLot = await traverser(verifierPlafond('max_eleves', 400));
  assert.strictEqual(auLot.passe, false, 'compté au lot : refusé');
});

test('un plafond nul signifie « sans limite », pas « zéro »', async () => {
  planSimule = plan({ max_eleves: null, max_utilisateurs: null }, {});
  effectifSimule = 50000;
  const r = await traverser(verifierPlafond('max_eleves', 1000));
  assert.strictEqual(r.passe, true, 'null = illimité, y compris à 50 000 élèves');
});

test('sans abonnement, le repli plafonne sans fermer', async () => {
  planSimule = null;
  effectifSimule = 240;
  const sous = await traverser(verifierPlafond('max_eleves', 1));
  assert.strictEqual(sous.passe, true, '240 < repli de 250');

  effectifSimule = 260;
  const dessus = await traverser(verifierPlafond('max_eleves', 1));
  assert.strictEqual(dessus.passe, false, 'le repli reste un plafond, pas une porte ouverte');
});

test('chaque plafond déclaré a sa requête de comptage', async () => {
  // Sans cette correspondance, `verifierPlafond('max_classes')` lèverait une
  // exception au démarrage — ce qui est le comportement voulu, et ce test
  // documente la contrainte.
  for (const cle of Object.keys(COMPTAGES)) {
    assert.ok(cle in catalogue.LIMITES, `${cle} compté mais absent des limites`);
    assert.doesNotThrow(() => verifierPlafond(cle));
  }
  assert.throws(() => verifierPlafond('stockage_mo'), /aucune requête de comptage/,
    'une limite sans comptage doit être refusée explicitement, pas ignorée');
});

/* =========================================================================
   COHÉRENCE D'ENSEMBLE
   ========================================================================= */

test('aucun verrou de route ne référence un code inexistant', async () => {
  const fs = require('fs');
  const path = require('path');
  const dossier = path.join(__dirname, '..', 'routes');

  let source = '';
  for (const fichier of fs.readdirSync(dossier)) {
    if (fichier.endsWith('.js')) source += fs.readFileSync(path.join(dossier, fichier), 'utf8');
  }

  const utilises = [...source.matchAll(/exigeFonctionnalite\('([a-z_]+)'\)/g)].map((m) => m[1]);
  assert.ok(utilises.length >= 10,
    `seulement ${utilises.length} verrou(x) trouvé(s) : les restrictions ne sont pas branchées`);

  for (const code of new Set(utilises)) {
    assert.ok(code in catalogue.FONCTIONNALITES,
      `routes : exigeFonctionnalite('${code}') ne correspond à aucune fonctionnalité déclarée`);
  }
});

test('toute fonctionnalité déclarée est soit ouverte partout, soit verrouillée quelque part', async () => {
  // Un drapeau déclaré mais jamais appliqué décrit une fonctionnalité vendue
  // et non tenue. Les seules exceptions admises sont listées ici, avec leur
  // raison — et cette liste doit rester courte.
  const SANS_ROUTE = {
    assistant_aide:     'ouvert dans les quatre offres : rien à verrouiller',
    ia_appreciations:   'ouvert dans les quatre offres : rien à verrouiller',
    support_prioritaire:'engagement humain, pas une route'
  };

  const fs = require('fs');
  const path = require('path');
  const dossier = path.join(__dirname, '..', 'routes');
  let source = '';
  for (const fichier of fs.readdirSync(dossier)) {
    if (fichier.endsWith('.js')) source += fs.readFileSync(path.join(dossier, fichier), 'utf8');
  }
  const utilises = new Set([...source.matchAll(/exigeFonctionnalite\('([a-z_]+)'\)/g)].map((m) => m[1]));

  for (const code of Object.keys(catalogue.FONCTIONNALITES)) {
    if (utilises.has(code) || code in SANS_ROUTE) continue;
    assert.fail(
      `« ${code} » est déclarée vendable mais n'est verrouillée nulle part. `
      + `Soit elle correspond à une route et il faut y poser le verrou, soit elle `
      + `ne correspond à rien et il faut cesser de l'annoncer sur la page des tarifs.`);
  }
});
