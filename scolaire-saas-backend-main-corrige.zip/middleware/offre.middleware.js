/**
 * ARDOISE — DROITS ET PLAFONDS LIÉS À L'OFFRE
 * ===========================================================================
 *
 * `role.middleware.js` répond à « cette PERSONNE a-t-elle le droit ? ».
 * Celui-ci répond à « cette ÉCOLE a-t-elle souscrit ce qu'il faut ? ».
 * Deux questions distinctes : un directeur a tous les droits de son rôle et
 * peut tout de même ne pas avoir souscrit la comptabilité.
 *
 * DEUX GARDES, DEUX USAGES
 * ------------------------
 *   exigeFonctionnalite('comptabilite')  → 402 si l'offre ne la comprend pas
 *   verifierPlafond('max_eleves', …)     → 402 si le plafond serait dépassé
 *
 * POURQUOI 402 ET PAS 403
 * -----------------------
 * 403 dit « vous n'avez pas le droit », ce qui est faux et vexant : le
 * directeur A le droit, il n'a simplement pas souscrit le niveau qui l'ouvre.
 * 402 « Payment Required » dit exactement cela, et permet au frontend de
 * distinguer sans ambiguïté un refus de rôle d'une invitation à changer
 * d'offre. La réponse porte toujours `{ code: 'offre_insuffisante' }` pour que
 * l'interface n'ait pas à interpréter un message en français.
 *
 * CE QU'IL NE FAIT JAMAIS
 * -----------------------
 * Bloquer en cas de doute. Si l'école n'a aucun abonnement actif — panne de
 * facturation, migration en cours, école créée à la main — on laisse passer
 * (voir `plafondsParDefaut()`). Suspendre une école est une décision
 * commerciale explicite, pas l'effet de bord d'une requête qui n'a rien
 * trouvé.
 */

const { runWithTenant } = require('../config/db');
const { tenantContextFromReq } = require('../utils/tenant.utils');
const catalogue = require('../utils/catalogue.utils');

/** Identifiant d'école porté par le jeton, quel que soit son nom. */
function ecoleDe(req) {
  return (req.auth && (req.auth.ecoleId || req.auth.ecole_id)) || null;
}

/**
 * Exige que l'offre de l'école comprenne la fonctionnalité donnée.
 *
 *   router.use('/comptabilite', exigeFonctionnalite('comptabilite'));
 */
function exigeFonctionnalite(code) {
  // Vérification au CHARGEMENT du module, pas à la première requête : une
  // faute de frappe dans le code de fonctionnalité doit faire échouer le
  // démarrage, pas s'installer silencieusement comme un « toujours refusé ».
  if (!Object.prototype.hasOwnProperty.call(catalogue.FONCTIONNALITES, code)) {
    throw new Error(
      `exigeFonctionnalite('${code}') : code inconnu. `
      + `Codes valides : ${Object.keys(catalogue.FONCTIONNALITES).join(', ')}.`);
  }

  return async function (req, res, next) {
    const ecoleId = ecoleDe(req);

    // Super Admin : il inspecte les écoles, il n'en consomme pas l'abonnement.
    if (req.auth && req.auth.isSuperAdmin && !ecoleId) return next();
    if (!ecoleId) return next();

    try {
      const autorise = await runWithTenant(tenantContextFromReq(req), (client) =>
        catalogue.aDroitA(client, ecoleId, code));

      if (autorise) return next();

      return res.status(402).json({
        code: 'offre_insuffisante',
        fonctionnalite: code,
        message: `${catalogue.FONCTIONNALITES[code]} n'est pas comprise dans votre offre actuelle.`,
        action: "Consultez les offres depuis Paramètres → Abonnement pour voir celle qui l'inclut."
      });
    } catch (err) {
      // Une panne de lecture du catalogue ne doit pas fermer l'école.
      console.error('Contrôle d\'offre impossible, requête laissée passer :', err.message);
      return next();
    }
  };
}

/**
 * Requêtes de comptage associées à chaque plafond.
 *
 * Elles vivent ICI et non dans les contrôleurs pour une raison simple : le
 * jour où « élève actif » cessera de vouloir dire `statut = 'actif'`, une
 * seule ligne changera, et le compteur de la page Abonnement dira toujours la
 * même chose que le garde-fou qui refuse la création.
 */
const COMPTAGES = {
  max_eleves: `SELECT count(*)::int AS total FROM eleves
                WHERE ecole_id = $1 AND statut = 'actif'`,
  max_utilisateurs: `SELECT count(*)::int AS total FROM utilisateurs
                      WHERE ecole_id = $1 AND statut = 'actif'`,
  max_classes: `SELECT count(*)::int AS total FROM classes c
                 JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
                WHERE c.ecole_id = $1 AND a.active = true`
};

/**
 * Refuse la création si le plafond de l'offre serait franchi.
 *
 * `ajout` peut être une fonction de `req` : l'import d'un fichier de 300
 * élèves doit être compté pour 300, pas pour 1. C'est précisément le cas où
 * un contrôle « une unité à la fois » ne sert à rien.
 */
function verifierPlafond(cleLimite, ajout = 1) {
  if (!COMPTAGES[cleLimite]) {
    throw new Error(`verifierPlafond('${cleLimite}') : aucune requête de comptage définie.`);
  }

  return async function (req, res, next) {
    const ecoleId = ecoleDe(req);
    if (!ecoleId) return next();

    const nombre = typeof ajout === 'function' ? Number(ajout(req)) || 1 : ajout;

    try {
      const etat = await runWithTenant(tenantContextFromReq(req), (client) =>
        catalogue.verifierPlafond(client, ecoleId, cleLimite, COMPTAGES[cleLimite], nombre));

      if (etat.autorise) return next();

      const libelle = catalogue.LIMITES[cleLimite].libelle.toLowerCase();
      return res.status(402).json({
        code: 'plafond_atteint',
        limite: cleLimite,
        plafond: etat.limite,
        utilise: etat.utilise,
        restant: etat.restant,
        message: etat.restant === 0
          ? `Votre offre est limitée à ${etat.limite} ${libelle}, et ce plafond est atteint.`
          : `Votre offre est limitée à ${etat.limite} ${libelle}. `
            + `Il en reste ${etat.restant}, vous en demandez ${nombre}.`,
        action: 'Une offre supérieure relève ce plafond immédiatement, sans perte de données.'
      });
    } catch (err) {
      console.error('Contrôle de plafond impossible, requête laissée passer :', err.message);
      return next();
    }
  };
}

/**
 * Ne bloque rien : renseigne `req.offre` pour que le contrôleur puisse
 * adapter sa réponse (masquer un onglet, réduire une profondeur d'historique)
 * sans refaire la requête lui-même.
 */
async function chargerOffre(req, res, next) {
  const ecoleId = ecoleDe(req);
  if (!ecoleId) return next();
  try {
    req.offre = await runWithTenant(tenantContextFromReq(req), (client) =>
      catalogue.offreDeLEcole(client, ecoleId));
  } catch (err) {
    req.offre = null;
  }
  return next();
}

module.exports = { exigeFonctionnalite, verifierPlafond, chargerOffre, COMPTAGES };
