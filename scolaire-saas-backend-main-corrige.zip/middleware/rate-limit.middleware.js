const rateLimit = require('express-rate-limit');

/**
 * Limite les tentatives de connexion : 10 essais par IP toutes les 15 minutes.
 * Protège contre le brute-force sur les mots de passe.
 */
const limiteurConnexion = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS', // ne jamais bloquer les requêtes techniques "preflight" CORS
  message: { message: 'Trop de tentatives de connexion. Réessayez dans quelques minutes.' }
});

/**
 * Limite plus large pour l'ensemble de l'API (protection générale contre les abus).
 */
const limiteurGeneral = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS', // idem : le préflight ne doit jamais être bloqué
  message: { message: 'Trop de requêtes. Réessayez dans quelques minutes.' }
});

/**
 * Consultation publique des résultats : 15 essais par IP toutes les 15 minutes.
 * Ces routes ne demandent aucune authentification ; sans cette limite, on
 * pourrait balayer les matricules d'une école jusqu'à trouver un code valide.
 */
const limiteurResultatsPublics = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de tentatives. Réessayez dans quelques minutes.' }
});

/**
 * Pages publiques des écoles : plus permissif, il s'agit de simple lecture.
 */
const limiteurSitePublic = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de requêtes. Réessayez dans quelques minutes.' }
});

module.exports = { limiteurConnexion, limiteurGeneral, limiteurResultatsPublics, limiteurSitePublic };
