/**
 * Vérifie que l'utilisateur connecté possède au moins un des rôles autorisés.
 * Usage : router.post('/eleves', authMiddleware, requireRole('directeur', 'secretaire'), handler)
 */
function requireRole(...rolesAutorises) {
  return (req, res, next) => {
    if (!req.auth) {
      return res.status(401).json({ message: 'Non authentifié.' });
    }

    const aLeDroit = req.auth.isSuperAdmin || req.auth.roles.some((r) => rolesAutorises.includes(r));

    if (!aLeDroit) {
      return res.status(403).json({ message: "Accès refusé : rôle insuffisant." });
    }

    next();
  };
}

module.exports = requireRole;
