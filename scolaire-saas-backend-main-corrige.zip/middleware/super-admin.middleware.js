/**
 * Gardes propres à l'espace Super Administrateur.
 * ---------------------------------------------------------------------------
 * Trois verrous distincts, volontairement séparés :
 *
 *   1. `superAdminSeul`    — qui a le droit d'entrer.
 *   2. `lectureSeule`      — ce qu'il a le droit de faire une fois entré.
 *   3. `verrouObservation` — ce qu'il a le droit de faire pendant qu'il porte
 *                            l'identité d'un directeur ou d'un professeur.
 *
 * Le troisième est le plus important et le moins évident. Le mode « Voir
 * comme » délivre un jeton dont les rôles sont ceux de l'observé : de ce
 * jeton, l'application entière ne voit qu'un directeur ordinaire. Rien dans
 * `requireRole()` ne le distinguerait du vrai. Sans verrou global, un Super
 * Admin en observation pourrait donc publier des notes ou supprimer un élève
 * — exactement ce que la mission interdit.
 *
 * Le verrou est posé une fois pour toutes dans server.js, juste après
 * l'authentification, AVANT toute route métier. Aucune route n'a besoin de le
 * savoir, aucune route future ne peut l'oublier.
 */

const METHODES_LECTURE = new Set(['GET', 'HEAD', 'OPTIONS']);

/** Réserve l'accès au Super Administrateur. */
function superAdminSeul(req, res, next) {
  if (!req.auth) {
    return res.status(401).json({ message: 'Non authentifié.' });
  }
  if (!req.auth.isSuperAdmin) {
    return res.status(403).json({ message: 'Accès réservé au Super Administrateur.' });
  }
  next();
}

/**
 * Interdit toute écriture sur la branche de routes où il est posé.
 * Utilisé sur l'Explorateur : le Super Admin y parcourt les données
 * pédagogiques des écoles, jamais il ne les modifie.
 */
function lectureSeule(req, res, next) {
  if (!METHODES_LECTURE.has(req.method)) {
    return res.status(403).json({
      message: "Consultation en lecture seule : cette section n'autorise aucune modification."
    });
  }
  next();
}

/**
 * Verrou global du mode observation.
 *
 * Posé dans server.js pour TOUTES les routes. Un jeton d'observation ne peut
 * qu'écouter : il ne peut ni écrire, ni prolonger sa propre durée de vie, ni
 * se transformer en jeton normal (`/auth/refresh` refuse les jetons portant
 * le drapeau, puisqu'ils n'ont pas de session en base).
 */
function verrouObservation(req, res, next) {
  if (!req.auth || req.auth.observation !== true) return next();

  if (!METHODES_LECTURE.has(req.method)) {
    return res.status(403).json({
      message: "Mode observation : lecture seule. Quittez l'observation pour agir sur vos propres données.",
      code: 'OBSERVATION_LECTURE_SEULE'
    });
  }

  // Un observateur n'a rien à faire dans l'espace d'administration : il y
  // entrerait avec les droits d'un directeur, ce qui n'a aucun sens et
  // brouillerait le journal d'audit.
  if (req.path.startsWith('/super-admin') || req.path.startsWith('/admin/')) {
    return res.status(403).json({
      message: "Mode observation : l'espace d'administration n'est pas accessible sous une identité observée.",
      code: 'OBSERVATION_HORS_PERIMETRE'
    });
  }

  next();
}

module.exports = { superAdminSeul, lectureSeule, verrouObservation, METHODES_LECTURE };
