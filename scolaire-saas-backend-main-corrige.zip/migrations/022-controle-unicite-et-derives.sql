-- ===========================================================================
-- 022 — CONTRÔLE DES INDEX D'UNICITÉ ET DES DÉRIVES DE SCHÉMA
-- ===========================================================================
--
-- CE FICHIER SE LIT AVANT DE S'EXÉCUTER.
--
-- Il a été écrit à partir du schéma exporté de la base réelle, jamais exécuté
-- contre elle. L'export fourni ne contient QUE les tables, les clés et les
-- contraintes CHECK : aucun `CREATE INDEX`, aucun index d'unicité partiel.
-- Impossible, donc, de savoir depuis cet export si les index dont le code
-- dépend existent.
--
-- Or le code dépend de treize d'entre eux, et pas accessoirement : une clause
-- `ON CONFLICT (a, b)` sans index correspondant ne dégrade rien, elle ÉCHOUE,
-- avec l'erreur 42P10 « there is no unique or exclusion constraint matching
-- the ON CONFLICT specification ». Toute la fonctionnalité tombe.
--
-- La partie 1 ne modifie rien : elle DIT ce qui manque.
-- La partie 2 ne s'exécute que si vous décidez de créer ce qui manque.
--
-- ---------------------------------------------------------------------------
-- PARTIE 1 — DIAGNOSTIC (aucune écriture)
-- ---------------------------------------------------------------------------
-- Exécutez ce bloc seul. Chaque ligne dont `existe` vaut `false` correspond à
-- une fonctionnalité qui échoue en production.

WITH attendus(table_cible, colonnes, employe_par) AS (
  VALUES
    ('notes',             'eleve_id, classe_cours_id, periode_id', 'saisie des cotes (notes.controller)'),
    ('bulletins',         'eleve_id, periode_id',                  'recalcul du classement, bulletins de période et de semestre'),
    ('notes_travaux',     'travail_id, eleve_id',                  'saisie par travaux'),
    ('presences',         'eleve_id, date_jour',                   'appel journalier'),
    ('classe_cours',      'classe_id, cours_id',                   'affectation d''un cours à une classe'),
    ('enseignant_cours',  'utilisateur_id, classe_cours_id',       'affectation d''un professeur'),
    ('orientations',      'eleve_id, annee_scolaire_id',           'vœux et affectation d''option'),
    ('emploi_du_temps',   'classe_id, jour, creneau_id, annee_scolaire_id', 'placement d''une séance'),
    ('notes_candidats',   'epreuve_id, candidat_id',               'correction des concours d''admission'),
    ('regles_discipline', 'ecole_id, code',                        'import du règlement de discipline'),
    ('repechages',        'session_id, eleve_id, classe_cours_id', 'ouverture d''une session de repêchage'),
    ('decisions_repechage','session_id, eleve_id',                 'clôture d''une session de repêchage'),
    ('bugs_plateforme',   'empreinte',                             'regroupement des bugs signalés')
)
SELECT a.table_cible,
       a.colonnes,
       a.employe_par,
       EXISTS (
         SELECT 1
           FROM pg_index i
           JOIN pg_class c ON c.oid = i.indrelid
          WHERE c.relname = a.table_cible
            AND i.indisunique
            AND (
              SELECT string_agg(att.attname, ', ' ORDER BY k.ord)
                FROM unnest(i.indkey) WITH ORDINALITY AS k(attnum, ord)
                JOIN pg_attribute att
                  ON att.attrelid = i.indrelid AND att.attnum = k.attnum
            ) = a.colonnes
       ) AS existe
  FROM attendus a
 ORDER BY existe, a.table_cible;

-- Index PARTIELS employés par le code (ils ne remontent pas tels quels
-- ci-dessus, leur prédicat fait partie de leur identité) :
--
--   bulletins            (eleve_id, annee_scolaire_id) WHERE periode_id IS NULL
--   creneaux_exceptions  (creneau_id, jour, classe_id) WHERE classe_id IS NOT NULL
--   creneaux_exceptions  (creneau_id, jour)            WHERE classe_id IS NULL
--   annees_scolaires     (ecole_id)                    WHERE active
--   notifications        (ecole_id, utilisateur_id, cle_unicite)
--                                                      WHERE cle_unicite IS NOT NULL
--
-- Ce dernier mérite une mention particulière : c'est LUI, et lui seul, qui
-- empêche les tâches cron de créer des doublons. `notification.utils.js`
-- s'appuie dessus via `ON CONFLICT (ecole_id, utilisateur_id, cle_unicite)`,
-- et la diffusion d'annonces plateforme via un `ON CONFLICT DO NOTHING`.
--
-- S'il manque, les deux échouent de manières DIFFÉRENTES, ce qui rend le
-- diagnostic trompeur :
--   · `notification.utils.js` lève 42P10 et l'envoi tombe en erreur ;
--   · `ON CONFLICT DO NOTHING` sans cible ne lève RIEN — il ne déduplique
--     simplement pas. Republier une annonce trois fois la dépose trois fois
--     dans la boîte de chaque utilisateur, en silence.
--
-- Pour les inspecter :
--   SELECT indexrelid::regclass AS index, pg_get_indexdef(indexrelid)
--     FROM pg_index
--    WHERE indrelid IN ('bulletins'::regclass, 'creneaux_exceptions'::regclass,
--                       'annees_scolaires'::regclass, 'notifications'::regclass)
--      AND indpred IS NOT NULL;


-- ---------------------------------------------------------------------------
-- PARTIE 2 — UNICITÉ DE L'IDENTIFIANT DE CONNEXION
-- ---------------------------------------------------------------------------
-- CECI EST UN DÉFAUT CONSTATÉ, PAS UNE PRÉCAUTION.
--
-- `utilisateurs` ne porte aucune unicité sur (email, ecole_id). Or
-- `auth.controller.js` authentifie ainsi :
--
--     WHERE u.email = $1 AND u.ecole_id IS NOT DISTINCT FROM $2
--     ...
--     const user = userResult.rows[0];
--
-- Deux comptes de même adresse dans la même école, et c'est PostgreSQL qui
-- choisit lequel se connecte — sans ORDER BY, l'ordre n'est pas garanti et
-- peut changer d'une exécution à l'autre. Le mot de passe comparé, les rôles
-- accordés et l'identité journalisée sont alors ceux d'un compte tiré au sort.
-- Le même défaut vaut pour la réinitialisation de mot de passe.
--
-- Le cas se produit sans malveillance : un secrétaire crée un compte, la
-- direction en recrée un pour la même personne, et l'un des deux garde
-- l'ancien mot de passe.
--
-- ÉTAPE 2a — chercher les doublons AVANT de créer l'index.
-- S'il en existe, l'index échouera : c'est voulu, il faut trancher à la main
-- lequel des comptes conserver.

SELECT ecole_id, lower(email) AS email, count(*) AS nb,
       array_agg(id) AS comptes,
       array_agg(statut) AS statuts
  FROM utilisateurs
 GROUP BY ecole_id, lower(email)
HAVING count(*) > 1;

-- ÉTAPE 2b — n'exécuter QUE si la requête ci-dessus ne renvoie rien.
--
-- `lower(email)` : les adresses ne sont pas sensibles à la casse dans la vraie
-- vie, et le code compare déjà sans normaliser. Sans `lower()`, « Directeur@ »
-- et « directeur@ » resteraient deux comptes distincts.
--
-- `COALESCE(ecole_id, uuid_nul)` : un index d'unicité traite deux NULL comme
-- distincts. Sans ce COALESCE, rien n'empêcherait deux Super Admins de partager
-- la même adresse.

-- CREATE UNIQUE INDEX IF NOT EXISTS utilisateurs_email_par_ecole
--   ON utilisateurs (COALESCE(ecole_id, '00000000-0000-0000-0000-000000000000'::uuid),
--                    lower(email));


-- ---------------------------------------------------------------------------
-- PARTIE 3 — DÉRIVES DE SCHÉMA CONSTATÉES (aucune action automatique)
-- ---------------------------------------------------------------------------
--
-- 3a. `annees_scolaires` porte TROIS drapeaux pour deux états :
--        active   (boolean)  — écrit par le code
--        cloturee (boolean)  — écrit par le code
--        statut   (text, CHECK active|cloturee) — ÉCRIT PAR PERSONNE
--
--     Aucun `.js` du projet ne met `statut` à jour. Il vaut donc « active »
--     sur toutes les années, y compris celles clôturées depuis des années.
--     Toute requête future qui s'y fierait — un rapport, un export, une
--     migration — lirait le contraire de la vérité.
--
--     Deux issues, à trancher par le propriétaire :
--       · supprimer la colonne (elle n'est lue nulle part aujourd'hui) ;
--       · ou la remettre en cohérence et la maintenir par trigger.
--
--     Pour mesurer l'écart actuel :
SELECT statut, cloturee, active, count(*)
  FROM annees_scolaires
 GROUP BY statut, cloturee, active
 ORDER BY 1, 2, 3;

-- 3b. `eleve_classe_historique` porte `resultat_final` ET `resultat`.
--     Vérifier laquelle est réellement alimentée avant d'écrire du code neuf :
SELECT count(*) FILTER (WHERE resultat_final IS NOT NULL) AS avec_resultat_final,
       count(*) FILTER (WHERE resultat IS NOT NULL)       AS avec_resultat,
       count(*)                                           AS total
  FROM eleve_classe_historique;

-- 3c. `frais_scolaires.montant_usd` et `.montant_fc` ne sont lues ni écrites
--     par aucun fichier du projet — la double devise passe par `montant` +
--     `devise` + `taux_change` depuis la migration 001. Colonnes mortes.
SELECT count(*) FILTER (WHERE montant_usd IS NOT NULL) AS montant_usd_renseigne,
       count(*) FILTER (WHERE montant_fc IS NOT NULL)  AS montant_fc_renseigne
  FROM frais_scolaires;

-- 3d. `regles_classement` (colonne `regle_egalite`) n'apparaît dans AUCUN
--     fichier `.js`. La règle d'égalité au classement est écrite en dur dans
--     le code (ordre alphabétique). La table promet un réglage qui n'existe
--     pas : soit la brancher, soit la retirer.

-- 3e. `paiements.methode` — VÉRIFIÉ le 7 août 2026 sur la base réelle.
--
--     Valeurs présentes :
--       orange_money, airtel_money, mpesa, cash, stripe, virement,
--       especes, virement_bancaire, cheque
--
--     RÉSULTAT : les trois valeurs dont AUD-07 a besoin (especes,
--     virement_bancaire, cheque) EXISTENT. L'encaissement d'abonnement en
--     espèces fonctionnera. Aucune action requise de ce côté.
--
--     EN REVANCHE, l'énumération porte trois valeurs qu'AUCUNE ligne de code
--     n'écrit ni ne lit : `cash`, `stripe`, `virement`. Ce sont des vestiges,
--     et deux d'entre eux font DOUBLON avec les valeurs actuelles :
--
--         cash      ≡ especes
--         virement  ≡ virement_bancaire
--
--     Un même règlement peut donc exister sous deux étiquettes selon l'époque
--     où il a été saisi. Tout regroupement `GROUP BY methode` — un état de
--     caisse, un export comptable, un futur tableau de bord — coupera la même
--     réalité en deux colonnes, sans que rien ne le signale.
--
--     Combien de lignes portent encore les anciennes valeurs :
SELECT methode::text, count(*)
  FROM paiements
 GROUP BY methode
 ORDER BY 2 DESC;

--     Si `cash` / `virement` sont à zéro : les retirer de l'énumération
--     (opération lourde en PostgreSQL, à planifier).
--     S'ils portent des lignes : les normaliser d'abord vers `especes` /
--     `virement_bancaire`, PUIS retirer les vestiges. Ne jamais retirer une
--     valeur d'énumération encore référencée.
--
--     Requête d'origine, conservée pour relecture ultérieure :
SELECT enumlabel
  FROM pg_enum
  JOIN pg_type ON pg_type.oid = pg_enum.enumtypid
 WHERE pg_type.typname = (
   SELECT udt_name FROM information_schema.columns
    WHERE table_name = 'paiements' AND column_name = 'methode'
 )
 ORDER BY enumsortorder;


-- ===========================================================================
-- PARTIE 4 — COUVERTURE RLS  (ajoutee le 7 aout 2026)
-- ===========================================================================
--
-- POUR EXECUTER : utiliser plutot `022b-verification-rls.sql`.
-- Les commentaires « -- » de ce fichier perdent parfois un tiret au collage
-- dans certains editeurs SQL, et « - PARTIE 4 » devient une soustraction :
--     ERROR: 42601: syntax error at or near "-"
-- Le fichier 022b contient les memes requetes, en commentaires bloc, separees
-- pour se lancer une par une.
-- ===========================================================================
--
-- POURQUOI CETTE PARTIE EXISTE
-- ----------------------------
-- Un décompte a été fait sur le code : **236 requêtes** filtrent sur un
-- identifiant venu du client (`WHERE id = $1`, `WHERE eleve_id = $1`…) SANS
-- mentionner l'école dans la même requête. Elles ne sont donc pas
-- « tenant-aware » par elles-mêmes : leur isolation repose ENTIÈREMENT sur la
-- Row Level Security.
--
-- Ce n'est pas un défaut en soi — c'est même le bon design, puisqu'il rend
-- l'oubli impossible. Mais il transfère toute la sécurité multi-écoles sur
-- trois faits de base de données, dont AUCUN n'est visible dans un export de
-- schéma :
--
--   1. RLS activée sur chaque table portant `ecole_id` ;
--   2. une policy effectivement posée sur chacune ;
--   3. le rôle de connexion n'est ni propriétaire de la table, ni SUPERUSER,
--      ni BYPASSRLS — sinon RLS ne s'applique tout simplement pas à lui.
--
-- Le point 3 est le plus traître. **Le propriétaire d'une table ignore RLS par
-- défaut**, sans erreur ni avertissement : les policies existent, elles sont
-- correctes, et elles ne s'appliquent pas. C'est précisément le piège dont
-- parle le commentaire d'`auth.controller.js` (« au lieu du rôle postgres qui
-- le contournait »). `FORCE ROW LEVEL SECURITY` est la seule protection.
--
-- Si l'une des trois conditions manque, un utilisateur peut lire les données
-- d'une autre école en remplaçant un UUID dans l'URL, sur 236 requêtes.
--
-- ---------------------------------------------------------------------------
-- 4a. Rôle de connexion : RLS s'applique-t-elle seulement à lui ?
-- ---------------------------------------------------------------------------
-- À exécuter AVEC LES MÊMES IDENTIFIANTS QUE L'APPLICATION (le DATABASE_URL de
-- Render), pas avec le compte d'administration — sinon la réponse ne veut rien
-- dire.
--
-- Les trois colonnes doivent valoir false. Une seule à true, et toute la RLS
-- du projet est décorative.

SELECT current_user                AS role_de_connexion,
       rolsuper                    AS est_superuser,
       rolbypassrls                AS contourne_rls
  FROM pg_roles
 WHERE rolname = current_user;

-- ---------------------------------------------------------------------------
-- 4b. Tables à `ecole_id` : RLS activée, forcée, et combien de policies ?
-- ---------------------------------------------------------------------------
-- Lecture des colonnes :
--   rls_activee  = false            → table EXPOSÉE, aucune isolation
--   nb_policies  = 0 avec RLS       → table INACCESSIBLE (refus par défaut)
--   rls_forcee   = false            → isolation contournée si l'application se
--                                     connecte avec le propriétaire de la table

SELECT c.relname                                   AS  "table",
       c.relrowsecurity                            AS  rls_activee,
       c.relforcerowsecurity                       AS  rls_forcee,
       pg_get_userbyid(c.relowner)                 AS  proprietaire,
       (SELECT count(*) FROM pg_policy p WHERE p.polrelid = c.oid) AS nb_policies
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'public'
   AND c.relkind = 'r'
   AND EXISTS (
     SELECT 1 FROM pg_attribute a
      WHERE a.attrelid = c.oid AND a.attname = 'ecole_id' AND NOT a.attisdropped
   )
 ORDER BY c.relrowsecurity, c.relforcerowsecurity, c.relname;

-- ---------------------------------------------------------------------------
-- 4c. Tables SANS `ecole_id` : sont-elles légitimement globales ?
-- ---------------------------------------------------------------------------
-- Attendues ici, et seulement elles :
--   plans_abonnement, configuration_plateforme, metriques_plateforme,
--   utilisateur_roles, sessions, reinitialisations_mot_de_passe,
--   zones_modele, bugs_commentaires, tickets_messages,
--   observations_super_admin, conversations_whatsapp, messages_whatsapp
--
-- Toute AUTRE table dans ce résultat porte des données d'école sans colonne
-- pour les rattacher : c'est une fuite par construction, que la RLS ne peut
-- pas rattraper.
--
-- Cas particuliers à surveiller dans cette liste :
--   · `utilisateur_roles` — pas d'ecole_id, mais rattachée via utilisateur_id.
--     Vérifier qu'une policy passe bien par la jointure.
--   · `zones_modele` — rattachée via modele_id. Idem.

SELECT c.relname AS "table_sans_ecole_id",
       c.relrowsecurity AS rls_activee
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'public'
   AND c.relkind = 'r'
   AND NOT EXISTS (
     SELECT 1 FROM pg_attribute a
      WHERE a.attrelid = c.oid AND a.attname = 'ecole_id' AND NOT a.attisdropped
   )
 ORDER BY c.relname;

-- ---------------------------------------------------------------------------
-- 4d. Vérification VIVANTE — le seul test qui prouve vraiment quelque chose
-- ---------------------------------------------------------------------------
-- Les requêtes ci-dessus décrivent la configuration. Celle-ci la met à
-- l'épreuve, exactement comme le fait `runWithTenant()`.
--
-- À exécuter AVEC LES IDENTIFIANTS DE L'APPLICATION. Remplacer l'UUID par une
-- école réelle.

-- BEGIN;
--   SELECT set_config('app.current_ecole_id', 'UUID-DE-L-ECOLE-A', true);
--
--   -- Doit ne renvoyer QUE l'école A :
--   SELECT DISTINCT ecole_id FROM eleves;
--
--   -- Doit renvoyer 0 :
--   SELECT count(*) FROM eleves WHERE ecole_id <> 'UUID-DE-L-ECOLE-A'::uuid;
--
--   -- Doit renvoyer 0 lignes, pour chacune des tables sensibles :
--   SELECT 'paiements_frais' AS t, count(*) FROM paiements_frais
--    WHERE ecole_id <> 'UUID-DE-L-ECOLE-A'::uuid
--   UNION ALL SELECT 'notes',     count(*) FROM notes
--    WHERE ecole_id <> 'UUID-DE-L-ECOLE-A'::uuid
--   UNION ALL SELECT 'bulletins', count(*) FROM bulletins
--    WHERE ecole_id <> 'UUID-DE-L-ECOLE-A'::uuid
--   UNION ALL SELECT 'utilisateurs', count(*) FROM utilisateurs
--    WHERE ecole_id IS NOT NULL AND ecole_id <> 'UUID-DE-L-ECOLE-A'::uuid;
-- ROLLBACK;

-- Un compte non nul sur l'une de ces lignes = fuite inter-écoles CONFIRMÉE,
-- sur les 236 requêtes concernées. C'est le seul résultat de tout ce fichier
-- qui justifie d'arrêter la production.
