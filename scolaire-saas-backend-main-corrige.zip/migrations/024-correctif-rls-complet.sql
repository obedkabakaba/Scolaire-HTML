/* =========================================================================
   NOTE — 7 aout 2026
   =========================================================================
   Le tout premier essai de ce script echouait avec :
       ERROR: 42501: permission denied to alter role
       Only roles with the SUPERUSER attribute may alter roles with the
       SUPERUSER attribute.

   Cela signifie qu'un role nomme `ardoise_app` existait deja dans la base,
   avec un statut de super-utilisateur, et que le compte utilise pour lancer
   ce script n'a pas le droit d'y toucher (c'est une restriction normale de
   PostgreSQL, frequente sur les bases gerees comme Supabase).

   Plutot que de se battre avec ce role existant, ce script en cree un
   NOUVEAU, sous un autre nom : `ardoise_svc`. Le nom n'a aucune importance,
   c'est juste un identifiant.

   Le role `ardoise_app` d'origine n'est PAS touche par ce script. Il peut
   rester sans consequence — l'application ne s'en servira jamais, puisque
   DATABASE_URL pointera vers `ardoise_svc`. Si vous voulez comprendre d'ou
   il vient, cette requete l'affiche (sans rien modifier) :

       SELECT rolname, rolsuper, rolbypassrls, rolcanlogin
         FROM pg_roles WHERE rolname = 'ardoise_app';
   ========================================================================= */


/* =========================================================================
   ARDOISE — CORRECTIF RLS EN UN SEUL SCRIPT
   =========================================================================

   CE QU'IL FAIT
   -------------
     1. cree les 3 policies manquantes (sans quoi WhatsApp tomberait)
     2. cree le role applicatif `ardoise_svc`, sans BYPASSRLS
     3. lui donne les droits, presents et futurs
     4. le rattache au role `ia_lecture` s'il existe
     5. pose FORCE ROW LEVEL SECURITY sur toutes les tables
     6. affiche un controle final

   IL EST SANS DANGER A LANCER MAINTENANT
   --------------------------------------
   Tant que l'application se connecte encore en `postgres`, RIEN NE CHANGE
   pour elle : l'attribut BYPASSRLS de `postgres` prime sur tout, y compris
   sur FORCE. Le script prepare le terrain, il ne bascule pas.

   Tout est dans UNE transaction : si une seule instruction echoue, rien
   n'est applique.

   AVANT DE LANCER : UNE SEULE LIGNE A MODIFIER
   -------------------------------------------
   Chercher   MOT_DE_PASSE_A_CHANGER   plus bas et mettre un vrai mot de
   passe. C'est le seul endroit.

   APRES AVOIR LANCE : UNE SEULE ACTION MANUELLE
   ---------------------------------------------
   Aucun SQL ne peut la faire a votre place, parce qu'elle n'est pas dans la
   base : il faut changer DATABASE_URL sur Render pour que l'application se
   connecte avec `ardoise_svc` au lieu de `postgres`.

       postgresql://ardoise_svc:VOTRE_MOT_DE_PASSE@<hote>:5432/postgres

   Puis redemarrer le service. C'est CE moment-la qui corrige la fuite.

   POUR REVENIR EN ARRIERE
   -----------------------
   Remettre l'ancien DATABASE_URL et redemarrer. Immediat, aucune donnee
   touchee. Le script ne detruit rien et ne modifie aucune ligne.
   ========================================================================= */

BEGIN;

/* -------------------------------------------------------------------------
   ETAPE 1 — LES 3 POLICIES MANQUANTES
   -------------------------------------------------------------------------
   RLS est activee sur ces tables, mais aucune policy n'y est posee. Sans
   policy, PostgreSQL refuse TOUTES les lignes — Super Admin compris, puisque
   aucune expression n'est evaluee. Le jour de la bascule, WhatsApp cesserait
   entierement de fonctionner et le journal IA se viderait.

   `ecole_id IS NULL` n'est pas une facilite : ces trois colonnes sont
   nullables, et le webhook WhatsApp ecrit sa premiere reponse AVANT d'avoir
   reconnu le numero. Sans cette clause, Ardoise resterait muet face a chaque
   nouveau parent.

   DROP ... IF EXISTS d'abord : le script peut ainsi etre relance sans erreur.
   ------------------------------------------------------------------------- */

DROP POLICY IF EXISTS tenant_isolation ON conversations_whatsapp;
CREATE POLICY tenant_isolation ON conversations_whatsapp
  USING (
    ecole_id IS NULL
    OR ecole_id = (NULLIF(current_setting('app.current_ecole_id'::text, true), ''::text))::uuid
    OR current_setting('app.is_superadmin'::text, true) = 'true'::text
  );

DROP POLICY IF EXISTS tenant_isolation ON messages_whatsapp;
CREATE POLICY tenant_isolation ON messages_whatsapp
  USING (
    ecole_id IS NULL
    OR ecole_id = (NULLIF(current_setting('app.current_ecole_id'::text, true), ''::text))::uuid
    OR current_setting('app.is_superadmin'::text, true) = 'true'::text
  );

DROP POLICY IF EXISTS tenant_isolation ON ia_requetes_journal;
CREATE POLICY tenant_isolation ON ia_requetes_journal
  USING (
    ecole_id IS NULL
    OR ecole_id = (NULLIF(current_setting('app.current_ecole_id'::text, true), ''::text))::uuid
    OR current_setting('app.is_superadmin'::text, true) = 'true'::text
  );


/* -------------------------------------------------------------------------
   ETAPE 2 — LE ROLE APPLICATIF
   -------------------------------------------------------------------------
   NOBYPASSRLS est le mot qui compte : c'est l'attribut de `postgres` qui
   annulait les 66 policies du projet.

   >>> REMPLACER MOT_DE_PASSE_A_CHANGER CI-DESSOUS <<<
   ------------------------------------------------------------------------- */

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ardoise_svc') THEN
    CREATE ROLE ardoise_svc LOGIN PASSWORD 'MOT_DE_PASSE_A_CHANGER'
      NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
  ELSE
    -- Le role existe deja. On ne tente PAS de modifier ses attributs : sur
    -- certaines bases geree (Supabase notamment), le compte de connexion n'a
    -- pas le droit de toucher un role qui aurait par erreur ou par heritage
    -- l'attribut SUPERUSER, meme pour le lui retirer. Tenter quand meme
    -- produirait :
    --   ERROR: 42501: permission denied to alter role
    --   Only roles with the SUPERUSER attribute may alter roles with the
    --   SUPERUSER attribute.
    -- On avertit simplement, et on continue : les etapes suivantes (droits,
    -- FORCE ROW LEVEL SECURITY) fonctionnent quel que soit l'etat de ce role.
    RAISE NOTICE 'Le role ardoise_svc existe deja - ses attributs n''ont PAS ete modifies. Verifiez-le avec : SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = ''ardoise_svc'';';
  END IF;
END
$$;


/* -------------------------------------------------------------------------
   ETAPE 3 — LES DROITS
   -------------------------------------------------------------------------
   Lecture et ecriture sur toutes les tables, et sur celles qui seront creees
   plus tard. Sans ALTER DEFAULT PRIVILEGES, la prochaine migration ajouterait
   une table invisible pour l'application, et la panne serait difficile a
   relier a sa cause.

   Aucun droit DDL : `ardoise_svc` ne peut ni creer, ni modifier, ni supprimer
   une table. Les migrations continuent de passer par `postgres`.
   ------------------------------------------------------------------------- */

GRANT USAGE ON SCHEMA public TO ardoise_svc;

GRANT SELECT, INSERT, UPDATE, DELETE
  ON ALL TABLES IN SCHEMA public TO ardoise_svc;

GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ardoise_svc;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ardoise_svc;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO ardoise_svc;


/* -------------------------------------------------------------------------
   ETAPE 4 — RATTACHEMENT AU ROLE DE LECTURE DE L'IA
   -------------------------------------------------------------------------
   `utils/ia.utils.js` execute `SET LOCAL ROLE ia_lecture` avant chaque
   requete generee par l'IA. Pour en avoir le droit, `ardoise_svc` doit etre
   membre de ce role.

   S'il n'existe pas, la fonctionnalite IA echoue DEJA aujourd'hui : le script
   ne cree rien a l'aveugle, il le signale dans le controle final.
   ------------------------------------------------------------------------- */

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ia_lecture') THEN
    GRANT ia_lecture TO ardoise_svc;
  END IF;
END
$$;


/* -------------------------------------------------------------------------
   ETAPE 5 — FORCE ROW LEVEL SECURITY
   -------------------------------------------------------------------------
   Ceinture et bretelles. L'etape 2 suffit en theorie : un non-proprietaire
   subit RLS. FORCE protege du jour ou quelqu'un relancera l'application avec
   le compte d'administration « juste pour depanner » — ce qui finit toujours
   par arriver.

   Boucle plutot que 72 lignes collees : la liste reste juste apres l'ajout
   d'une table.
   ------------------------------------------------------------------------- */

DO $$
DECLARE
  t record;
BEGIN
  FOR t IN
    SELECT c.relname
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = 'public'
       AND c.relkind = 'r'
       AND c.relrowsecurity
       AND NOT c.relforcerowsecurity
  LOOP
    EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t.relname);
  END LOOP;
END
$$;

COMMIT;


/* -------------------------------------------------------------------------
   CONTROLE FINAL
   -------------------------------------------------------------------------
   Les quatre lignes doivent afficher OK. Sinon, ne pas basculer.
   ------------------------------------------------------------------------- */

SELECT '1. role ardoise_svc cree, sans BYPASSRLS' AS controle,
       CASE WHEN EXISTS (SELECT 1 FROM pg_roles
                          WHERE rolname = 'ardoise_svc'
                            AND NOT rolbypassrls AND NOT rolsuper)
            THEN 'OK' ELSE 'ECHEC' END AS resultat
UNION ALL
SELECT '2. mot de passe modifie',
       CASE WHEN EXISTS (SELECT 1 FROM pg_authid
                          WHERE rolname = 'ardoise_svc'
                            AND rolpassword IS NOT NULL)
            THEN 'OK — verifiez qu''il n''est pas reste MOT_DE_PASSE_A_CHANGER'
            ELSE 'ECHEC' END
UNION ALL
SELECT '3. tables RLS sans FORCE (doit valoir 0)',
       (SELECT count(*)::text FROM pg_class c
          JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = 'public' AND c.relkind = 'r'
           AND c.relrowsecurity AND NOT c.relforcerowsecurity)
UNION ALL
SELECT '4. tables RLS sans aucune policy (doit valoir 0)',
       (SELECT count(*)::text FROM pg_class c
          JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = 'public' AND c.relkind = 'r'
           AND c.relrowsecurity
           AND NOT EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid = c.oid))
UNION ALL
SELECT '5. role ia_lecture (necessaire au module IA)',
       CASE WHEN EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ia_lecture')
            THEN 'present' ELSE 'ABSENT — le module IA echoue deja aujourd''hui' END;


/* =========================================================================
   ET MAINTENANT ? DEUX ETAPES, DANS CET ORDRE
   =========================================================================

   A. Changer DATABASE_URL sur Render :
        postgresql://ardoise_svc:VOTRE_MOT_DE_PASSE@<hote>:5432/postgres
      Puis redemarrer le service.

   B. Relancer le test vivant, AVEC LES NOUVEAUX IDENTIFIANTS.
      Remplacer l'UUID par une ecole reelle. Les quatre comptes doivent
      valoir 0. Tant qu'ils ne valent pas 0, la fuite n'est pas corrigee.

        BEGIN;
          SELECT set_config('app.current_ecole_id', 'UUID-REEL', true);
          SELECT 'eleves' AS t, count(*) FROM eleves
            WHERE ecole_id <> 'UUID-REEL'::uuid
          UNION ALL SELECT 'notes', count(*) FROM notes
            WHERE ecole_id <> 'UUID-REEL'::uuid
          UNION ALL SELECT 'bulletins', count(*) FROM bulletins
            WHERE ecole_id <> 'UUID-REEL'::uuid
          UNION ALL SELECT 'paiements_frais', count(*) FROM paiements_frais
            WHERE ecole_id <> 'UUID-REEL'::uuid;
        ROLLBACK;

   C. Puis parcourir ces six chemins dans l'application. Ce sont ceux qui
      dependent d'une echappatoire, donc ceux qui cassent en premier si
      quelque chose cloche :

        1. connexion d'un utilisateur normal
        2. console Super Admin, liste des ecoles
        3. mode observation d'une ecole
        4. WhatsApp depuis un numero INCONNU
        5. une question posee a l'IA
        6. une tache cron (/jobs)

      Si l'un d'eux echoue : remettre l'ancien DATABASE_URL, redemarrer, et
      regarder le message d'erreur. Aucune donnee n'aura ete perdue.
   ========================================================================= */
