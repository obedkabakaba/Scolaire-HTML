-- ===========================================================================
-- 025 — LA FILE D'ENVOI DES NOTIFICATIONS
-- ===========================================================================
--
-- POURQUOI UNE FILE, ET PAS UN `await envoyerEmail()` DANS LE CONTRÔLEUR
-- ---------------------------------------------------------------------
-- Tout le code écrit passe par `runWithTenant`, qui ouvre une TRANSACTION.
-- Appeler Resend à l'intérieur de cette transaction pose deux problèmes que
-- personne ne voit en développement et que tout le monde subit en production :
--
--   1. L'e-mail part avant le COMMIT. Si la transaction échoue trois lignes
--      plus bas, la base revient en arrière — pas l'e-mail. Un parent reçoit
--      « paiement enregistré » pour un paiement qui n'existe pas.
--
--   2. Un appel réseau dure 200 à 2000 ms. Pendant ce temps la transaction
--      tient ses verrous. `payerSalaire` verrouille explicitement la ligne de
--      paie (`FOR UPDATE OF s`) : y ajouter un appel HTTP, c'est garder ce
--      verrou le temps que Resend réponde. Sur une signature de bulletins de
--      classe (300 élèves), c'est 300 appels HTTP dans UNE transaction — la
--      requête expire avant la fin, et tout est annulé.
--
-- La file résout les deux : l'écriture en base est instantanée et
-- transactionnelle (elle est annulée avec le reste si le reste est annulé),
-- l'envoi a lieu APRÈS le commit, hors transaction, et peut être réessayé.
--
-- UNE LIGNE = UN DESTINATAIRE
-- --------------------------
-- `canal` dit comment la notification est délivrée, pas où elle s'affiche :
--   'interne' → visible dans la plateforme uniquement ;
--   'email'   → visible dans la plateforme ET envoyée par e-mail.
-- C'est la convention qui existait déjà dans le code ; on la garde.
-- ===========================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. Ce que la file a besoin de savoir
-- ---------------------------------------------------------------------------

-- Clé de l'événement au catalogue (utils/notifications-catalogue.js).
-- Le HTML n'est PAS stocké : il est rendu au moment de l'envoi à partir de
-- `evenement` + `donnees`. Stocker le HTML rendu, c'est ~15 Ko par ligne —
-- 300 bulletins signés feraient 4,5 Mo d'e-mails figés en base, impossibles à
-- corriger si le gabarit change.
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS evenement text;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS donnees jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Destinataire hors plateforme : un parent n'a pas de compte `utilisateurs`,
-- son adresse vit dans `eleves.responsable_email`. On la fige à la création
-- de la notification plutôt que de la relire à l'envoi : si la fiche élève
-- change entre-temps, l'e-mail doit partir à l'adresse qui était valable au
-- moment du fait.
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS destinataire_email text;

-- SANS CETTE COLONNE, LA BOÎTE DU DIRECTEUR EXPLOSE.
-- `notifications.controller.js` affiche à la direction toute ligne dont
-- `utilisateur_id` est NULL. Or les notifications aux parents ont
-- précisément `utilisateur_id` NULL (ils n'ont pas de compte). Sans filtre,
-- signer 300 bulletins déverserait 300 lignes dans la boîte du directeur.
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS visible_interface boolean NOT NULL DEFAULT true;

-- Mécanique de réessai.
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS essais integer NOT NULL DEFAULT 0;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS derniere_tentative_at timestamp with time zone;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS derniere_erreur text;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS envoye_at timestamp with time zone;

-- ---------------------------------------------------------------------------
-- 2. Index
-- ---------------------------------------------------------------------------

-- Le vidage de file cherche toujours la même chose : les e-mails pas encore
-- partis, les plus anciens d'abord. Index partiel : il ne contient que la
-- file d'attente, pas l'historique des notifications déjà délivrées — qui
-- représentera 99 % de la table au bout de six mois.
CREATE INDEX IF NOT EXISTS idx_notifications_file_envoi
  ON public.notifications (created_at)
  WHERE canal = 'email' AND statut IN ('en_attente', 'echoue', 'en_cours');

-- Lecture de la boîte de réception (un utilisateur, ses non-lues d'abord).
CREATE INDEX IF NOT EXISTS idx_notifications_destinataire
  ON public.notifications (ecole_id, utilisateur_id, created_at DESC)
  WHERE visible_interface = true;

-- Déduplication. Le code s'appuie déjà dessus via
-- `ON CONFLICT (ecole_id, utilisateur_id, cle_unicite)` : sans cet index,
-- l'instruction ne dégrade pas, elle ÉCHOUE (erreur 42P10).
-- Voir migration 022, qui posait déjà le diagnostic.
CREATE UNIQUE INDEX IF NOT EXISTS idx_notifications_cle_unicite
  ON public.notifications (ecole_id, utilisateur_id, cle_unicite)
  WHERE cle_unicite IS NOT NULL;

-- Les notifications aux parents n'ont pas d'utilisateur_id : leur unicité se
-- joue sur l'adresse e-mail. Un index séparé, car PostgreSQL traite NULL
-- comme distinct de NULL — deux rappels au même parent passeraient tous deux
-- l'index ci-dessus.
CREATE UNIQUE INDEX IF NOT EXISTS idx_notifications_cle_unicite_externe
  ON public.notifications (ecole_id, destinataire_email, cle_unicite)
  WHERE cle_unicite IS NOT NULL AND utilisateur_id IS NULL;

COMMIT;

-- ===========================================================================
-- 3. VÉRIFICATION (à exécuter après, ne modifie rien)
-- ===========================================================================
-- Doit renvoyer 8 lignes de colonnes et 4 lignes d'index.
--
-- SELECT column_name FROM information_schema.columns
--  WHERE table_name = 'notifications'
--    AND column_name IN ('evenement','donnees','destinataire_email',
--                        'visible_interface','essais','derniere_tentative_at',
--                        'derniere_erreur','envoye_at');
--
-- SELECT indexname FROM pg_indexes
--  WHERE tablename = 'notifications' AND indexname LIKE 'idx_notifications%';

-- ===========================================================================
-- 4. ENTRETIEN — à programmer, pas à oublier
-- ===========================================================================
-- `notifications` grossit sans fin : une école de 500 élèves génère environ
-- 3 000 lignes par mois (appel quotidien + bulletins + frais). Au bout de deux
-- ans, la table pèse plus que `notes`. Purge conseillée, mensuelle :
--
--   DELETE FROM notifications
--    WHERE created_at < now() - interval '12 months'
--      AND (lu = true OR statut IN ('envoye', 'abandonne'));
--
-- On garde 12 mois : c'est la durée d'une année scolaire complète, donc la
-- fenêtre pendant laquelle une école peut avoir besoin de prouver qu'un
-- parent a bien été prévenu.
