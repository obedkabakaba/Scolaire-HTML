-- ============================================================================
--  026 — PROGRESSION D'ONBOARDING
-- ============================================================================
--
--  POURQUOI UNE COLONNE ET NON UNE TABLE
--  -------------------------------------
--  Presque tout ce qu'on voudrait « mémoriser » est DÉJÀ dans la base, et de
--  façon plus fiable qu'un enregistrement de progression : l'école a-t-elle des
--  classes ? des élèves ? des enseignants attribués ? La réponse se compte, elle
--  ne se déclare pas. Une table `onboarding_etapes` dupliquerait cette vérité et
--  divergerait au premier import massif fait hors du parcours guidé.
--
--  Ne reste à conserver que ce que la base NE PEUT PAS déduire :
--    · l'utilisateur a-t-il déjà vu l'écran de bienvenue ;
--    · a-t-il explicitement demandé à passer une étape (différent de « pas
--      encore faite ») ;
--    · quels mini-tutoriels contextuels lui ont déjà été montrés ;
--    · quels écrans il a découverts (les étapes de découverte n'ont pas de
--      trace en base : ouvrir « Rapports » ne crée aucune ligne) ;
--    · les dates de début et de fin.
--
--  C'est peu, c'est propre à une personne, et c'est lu à chaque chargement de
--  page en même temps que son profil. Une colonne JSONB sur `utilisateurs` est
--  la forme la plus économique : pas de jointure, pas de politique RLS
--  supplémentaire à écrire et à maintenir, pas de ligne orpheline quand un
--  compte est supprimé.
--
--  FORME DU DOCUMENT
--  -----------------
--    {
--      "version": 1,
--      "vu_bienvenue": true,
--      "statut": "en_cours" | "reporte" | "termine",
--      "etapes_ignorees": ["discipline_bareme"],
--      "tutoriels_vus": ["notes", "bulletins"],
--      "ecrans_visites": ["rapports.html"],
--      "demarre_at": "2026-08-08T09:12:00.000Z",
--      "termine_at": null,
--      "maj_at": "2026-08-08T09:40:00.000Z"
--    }
--
--  Le document par défaut est l'objet vide : un compte qui n'a jamais ouvert la
--  plateforme n'a rien à dire, et `{}` se lit correctement partout côté
--  application (voir `utils/onboarding.utils.js`, fonction `lireProgression`).
--
--  IDEMPOTENTE : peut être rejouée sans effet de bord.
-- ============================================================================

BEGIN;

ALTER TABLE utilisateurs
  ADD COLUMN IF NOT EXISTS onboarding jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Garde-fou : la colonne doit rester un OBJET. Un tableau ou un scalaire y
-- passerait sans erreur de type et casserait toutes les lectures de clés.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'utilisateurs_onboarding_objet'
  ) THEN
    ALTER TABLE utilisateurs
      ADD CONSTRAINT utilisateurs_onboarding_objet
      CHECK (jsonb_typeof(onboarding) = 'object');
  END IF;
END $$;

-- Index GIN : sert aux relevés d'adoption côté Super Admin
-- (« combien de directeurs ont terminé leur onboarding ce mois-ci »).
-- Sans lui, ces requêtes feraient un balayage complet de la table.
CREATE INDEX IF NOT EXISTS utilisateurs_onboarding_idx
  ON utilisateurs USING gin (onboarding jsonb_path_ops);

COMMENT ON COLUMN utilisateurs.onboarding IS
  'Progression d''accompagnement propre à la personne. Ne contient QUE ce que '
  'la base ne peut pas déduire (bienvenue vue, étapes explicitement ignorées, '
  'tutoriels contextuels vus, écrans découverts, dates). L''état réel de la '
  'configuration de l''école est recalculé à chaque appel — voir '
  'controllers/assistant.controller.js, fonction collecterFaits().';

COMMIT;
