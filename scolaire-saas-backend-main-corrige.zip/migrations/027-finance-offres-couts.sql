/* =========================================================================
   ARDOISE — MIGRATION 027
   Centre Finance, Offres, Coûts et Gestion commerciale du Super Admin
   =========================================================================

   CE QU'ELLE FAIT
   ---------------
     1. ÉTEND `plans_abonnement` (les offres commerciales existent déjà —
        on ne recrée pas la table, on lui ajoute ce qui manquait).
     2. ÉTEND `abonnements` pour distinguer prix catalogue et prix réellement
        appliqué.
     3. CRÉE les tables nouvelles : historique des prix, promotions, offres
        spéciales, tarifs personnalisés, services externes, consommations,
        dépenses, budgets, taux de change, journal financier, accès finance.
     4. POSE la RLS sur chacune (réservée au Super Admin) et les droits pour
        le rôle applicatif `ardoise_svc` s'il existe (voir migration 024).
     5. SÈME quelques clés de configuration dans `configuration_plateforme`
        plutôt que de créer une table de réglages de plus.

   ELLE EST IDEMPOTENTE
   --------------------
   Tout est en IF NOT EXISTS / ON CONFLICT DO NOTHING. La rejouer ne casse
   rien et ne duplique rien.

   ELLE NE SUPPRIME RIEN
   ---------------------
   Aucun DROP, aucun ALTER destructif, aucune colonne renommée. Les tables
   `plans_abonnement`, `abonnements`, `factures`, `paiements` conservent
   exactement leur forme actuelle ; on ne fait qu'ajouter.

   AVERTISSEMENT
   -------------
   Le HANDOVER (§3) signale que l'état réel de la base n'est pas connu du
   code avec certitude. Chaque ajout de colonne est donc écrit en
   `ADD COLUMN IF NOT EXISTS`, et les contraintes sont posées via des blocs
   DO qui vérifient d'abord leur absence.

   Tout tient dans UNE transaction : en cas d'échec, rien n'est appliqué.
   ========================================================================= */

BEGIN;

/* =========================================================================
   0. Fonction utilitaire : `updated_at` tenu à jour sans y penser
   ========================================================================= */

CREATE OR REPLACE FUNCTION finance_touch_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


/* =========================================================================
   1. OFFRES — extension de `plans_abonnement`
   -------------------------------------------------------------------------
   Les noms d'offres (Ardoise Ascension, Prime, Pilote, Infinite) ne sont
   codés NULLE PART : ce sont des lignes de cette table, créées depuis
   l'interface. Cette migration n'en insère aucune.
   ========================================================================= */

ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS code               text;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS description        text;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS prix_annuel        numeric(12,2);
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS max_eleves         integer;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS max_utilisateurs   integer;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS fonctionnalites_incluses jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS fonctionnalites_exclues  jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS statut             text NOT NULL DEFAULT 'actif';
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS ordre_affichage    integer NOT NULL DEFAULT 0;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS badge              text;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS couleur            text;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS texte_marketing    text;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS visible_public     boolean NOT NULL DEFAULT true;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS archive_at         timestamptz;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS archive_par        uuid;
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS created_at         timestamptz NOT NULL DEFAULT now();
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS updated_at         timestamptz NOT NULL DEFAULT now();
ALTER TABLE plans_abonnement ADD COLUMN IF NOT EXISTS updated_by         uuid;

/* `statut` en texte contrôlé plutôt qu'en ENUM : un ENUM PostgreSQL ne se
   modifie pas sans migration, et la mission demande explicitement de pouvoir
   activer / désactiver / archiver sans toucher au code. */
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'plans_abonnement_statut_valide') THEN
    ALTER TABLE plans_abonnement
      ADD CONSTRAINT plans_abonnement_statut_valide
      CHECK (statut IN ('actif', 'inactif', 'archive'));
  END IF;
END $$;

/* Le code d'offre sert de repère stable côté marketing et côté export.
   Unique quand il est renseigné, libre de rester NULL sur les offres
   historiques. */
CREATE UNIQUE INDEX IF NOT EXISTS plans_abonnement_code_unique
  ON plans_abonnement (lower(code)) WHERE code IS NOT NULL;

DROP TRIGGER IF EXISTS trg_plans_abonnement_touch ON plans_abonnement;
CREATE TRIGGER trg_plans_abonnement_touch
  BEFORE UPDATE ON plans_abonnement
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   2. ABONNEMENTS — prix catalogue vs prix réellement payé
   -------------------------------------------------------------------------
   Sans ces colonnes, le MRR ne peut être calculé qu'au prix catalogue : une
   école à qui l'on a accordé 30 % de remise comptait pour son prix plein.
   ========================================================================= */

ALTER TABLE abonnements ADD COLUMN IF NOT EXISTS prix_applique          numeric(12,2);
ALTER TABLE abonnements ADD COLUMN IF NOT EXISTS devise_appliquee       text;
ALTER TABLE abonnements ADD COLUMN IF NOT EXISTS periodicite            text NOT NULL DEFAULT 'mensuel';
ALTER TABLE abonnements ADD COLUMN IF NOT EXISTS promotion_id           uuid;
ALTER TABLE abonnements ADD COLUMN IF NOT EXISTS tarif_personnalise_id  uuid;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'abonnements_periodicite_valide') THEN
    ALTER TABLE abonnements
      ADD CONSTRAINT abonnements_periodicite_valide
      CHECK (periodicite IN ('mensuel', 'annuel', 'trimestriel', 'personnalise'));
  END IF;
END $$;


/* =========================================================================
   3. HISTORIQUE DES PRIX — jamais purgé
   ========================================================================= */

CREATE TABLE IF NOT EXISTS plan_prix_historique (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id             uuid NOT NULL REFERENCES plans_abonnement(id) ON DELETE CASCADE,
  ancien_prix         numeric(12,2),
  nouveau_prix        numeric(12,2),
  ancien_prix_annuel  numeric(12,2),
  nouveau_prix_annuel numeric(12,2),
  devise              text,
  raison              text,
  date_application    date NOT NULL DEFAULT current_date,
  ecoles_impactees    integer,
  impact_mrr_estime   numeric(12,2),
  modifie_par         uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_plan_prix_historique_plan ON plan_prix_historique (plan_id, created_at DESC);


/* =========================================================================
   4. PROMOTIONS
   -------------------------------------------------------------------------
   Nommée `promotions_commerciales` et non `promotions` : dans Ardoise, le
   mot « promotion » désigne déjà le passage de classe d'un élève
   (promotion.controller.js). Deux sens dans un même schéma, c'est un
   contresens garanti à la première requête écrite par quelqu'un d'autre.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS promotions_commerciales (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nom                text NOT NULL,
  code               text,
  description        text,
  type_reduction     text NOT NULL DEFAULT 'pourcentage',
  valeur             numeric(12,2) NOT NULL DEFAULT 0,
  devise             text,
  duree_mois         integer,
  date_debut         date,
  date_fin           date,
  plans_concernes    uuid[] NOT NULL DEFAULT '{}',
  ecoles_concernees  uuid[] NOT NULL DEFAULT '{}',
  cible              text NOT NULL DEFAULT 'tous',
  max_utilisations   integer,
  nb_utilisations    integer NOT NULL DEFAULT 0,
  statut             text NOT NULL DEFAULT 'active',
  created_by         uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT promotions_type_valide
    CHECK (type_reduction IN ('pourcentage', 'montant_fixe', 'mois_offerts')),
  CONSTRAINT promotions_cible_valide
    CHECK (cible IN ('tous', 'nouveaux', 'anciens')),
  CONSTRAINT promotions_statut_valide
    CHECK (statut IN ('active', 'inactive', 'expiree', 'archivee')),
  CONSTRAINT promotions_dates_coherentes
    CHECK (date_fin IS NULL OR date_debut IS NULL OR date_fin >= date_debut),
  /* Un pourcentage au-delà de 100 n'est pas une remise, c'est un versement.
     Le refuser en base évite d'avoir à y penser dans chaque contrôleur. */
  CONSTRAINT promotions_pourcentage_borne
    CHECK (type_reduction <> 'pourcentage' OR (valeur >= 0 AND valeur <= 100))
);

CREATE UNIQUE INDEX IF NOT EXISTS promotions_code_unique
  ON promotions_commerciales (upper(code)) WHERE code IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_promotions_statut ON promotions_commerciales (statut, date_fin);

DROP TRIGGER IF EXISTS trg_promotions_touch ON promotions_commerciales;
CREATE TRIGGER trg_promotions_touch
  BEFORE UPDATE ON promotions_commerciales
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   5. OFFRES SPÉCIALES
   ========================================================================= */

CREATE TABLE IF NOT EXISTS offres_speciales (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nom           text NOT NULL,
  type_offre    text NOT NULL DEFAULT 'exceptionnelle',
  description   text,
  valeur        numeric(12,2),
  unite         text,
  duree_mois    integer,
  plan_id       uuid REFERENCES plans_abonnement(id) ON DELETE SET NULL,
  ecole_id      uuid REFERENCES ecoles(id) ON DELETE CASCADE,
  date_debut    date,
  date_fin      date,
  conditions    jsonb NOT NULL DEFAULT '{}'::jsonb,
  statut        text NOT NULL DEFAULT 'active',
  created_by    uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT offres_speciales_type_valide CHECK (type_offre IN (
    'premier_mois_gratuit', 'mois_reduits', 'reduction_annuelle',
    'lancement', 'ecole_specifique', 'partenaire', 'exceptionnelle', 'autre')),
  CONSTRAINT offres_speciales_statut_valide
    CHECK (statut IN ('active', 'inactive', 'expiree', 'archivee')),
  CONSTRAINT offres_speciales_dates_coherentes
    CHECK (date_fin IS NULL OR date_debut IS NULL OR date_fin >= date_debut)
);
CREATE INDEX IF NOT EXISTS idx_offres_speciales_statut ON offres_speciales (statut, date_fin);
CREATE INDEX IF NOT EXISTS idx_offres_speciales_ecole  ON offres_speciales (ecole_id);

DROP TRIGGER IF EXISTS trg_offres_speciales_touch ON offres_speciales;
CREATE TRIGGER trg_offres_speciales_touch
  BEFORE UPDATE ON offres_speciales
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   6. TARIFICATION PERSONNALISÉE (prix négocié par école)
   ========================================================================= */

CREATE TABLE IF NOT EXISTS tarifs_personnalises (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ecole_id           uuid NOT NULL REFERENCES ecoles(id) ON DELETE CASCADE,
  plan_id            uuid REFERENCES plans_abonnement(id) ON DELETE SET NULL,
  prix_catalogue     numeric(12,2),
  prix_personnalise  numeric(12,2) NOT NULL,
  devise             text,
  periodicite        text NOT NULL DEFAULT 'mensuel',
  raison             text NOT NULL,
  date_debut         date NOT NULL DEFAULT current_date,
  date_fin           date,
  statut             text NOT NULL DEFAULT 'actif',
  accorde_par        uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  termine_par        uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  termine_at         timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT tarifs_personnalises_statut_valide
    CHECK (statut IN ('actif', 'termine', 'annule')),
  CONSTRAINT tarifs_personnalises_periodicite_valide
    CHECK (periodicite IN ('mensuel', 'annuel', 'trimestriel')),
  CONSTRAINT tarifs_personnalises_prix_positif
    CHECK (prix_personnalise >= 0),
  CONSTRAINT tarifs_personnalises_dates_coherentes
    CHECK (date_fin IS NULL OR date_fin >= date_debut)
);

/* Une école ne peut pas avoir deux tarifs négociés actifs en même temps :
   lequel des deux facturer ? La contrainte tranche à l'écriture plutôt que
   de laisser le calcul du MRR choisir arbitrairement. */
CREATE UNIQUE INDEX IF NOT EXISTS tarifs_personnalises_un_seul_actif
  ON tarifs_personnalises (ecole_id) WHERE statut = 'actif';
CREATE INDEX IF NOT EXISTS idx_tarifs_personnalises_ecole ON tarifs_personnalises (ecole_id, created_at DESC);

DROP TRIGGER IF EXISTS trg_tarifs_personnalises_touch ON tarifs_personnalises;
CREATE TRIGGER trg_tarifs_personnalises_touch
  BEFORE UPDATE ON tarifs_personnalises
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   7. SERVICES & INFRASTRUCTURE
   -------------------------------------------------------------------------
   La liste des services (Supabase, Render, GitHub, Resend, OpenAI…) n'est
   PAS codée en dur : cette migration ne sème aucun service. Ils se créent
   depuis l'interface, catégorie comprise.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS services_externes (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nom                    text NOT NULL,
  categorie              text NOT NULL DEFAULT 'autre',
  fournisseur            text,
  plan                   text,
  cout_mensuel           numeric(12,2) NOT NULL DEFAULT 0,
  cout_annuel            numeric(12,2),
  devise                 text NOT NULL DEFAULT 'USD',
  cout_variable          boolean NOT NULL DEFAULT false,
  prix_unitaire          numeric(14,6),
  unite                  text,
  limite_incluse         numeric(16,2),
  jour_facturation       integer,
  frequence_facturation  text NOT NULL DEFAULT 'mensuelle',
  date_renouvellement    date,
  statut                 text NOT NULL DEFAULT 'actif',
  critique               boolean NOT NULL DEFAULT false,
  url                    text,
  notes                  text,
  created_by             uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT services_statut_valide
    CHECK (statut IN ('actif', 'suspendu', 'resilie', 'archive')),
  CONSTRAINT services_frequence_valide
    CHECK (frequence_facturation IN ('mensuelle', 'annuelle', 'trimestrielle', 'a_l_usage', 'ponctuelle')),
  CONSTRAINT services_jour_facturation_valide
    CHECK (jour_facturation IS NULL OR (jour_facturation BETWEEN 1 AND 31))
);
CREATE INDEX IF NOT EXISTS idx_services_statut    ON services_externes (statut);
CREATE INDEX IF NOT EXISTS idx_services_categorie ON services_externes (categorie);
CREATE INDEX IF NOT EXISTS idx_services_renouvellement ON services_externes (date_renouvellement)
  WHERE date_renouvellement IS NOT NULL;

DROP TRIGGER IF EXISTS trg_services_touch ON services_externes;
CREATE TRIGGER trg_services_touch
  BEFORE UPDATE ON services_externes
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   8. CONSOMMATIONS VARIABLES (OpenAI, Resend, SMS, stockage…)
   -------------------------------------------------------------------------
   Une ligne par service et par mois. Le coût estimé se calcule, le coût réel
   se saisit depuis la facture reçue : l'écart entre les deux est la seule
   façon honnête de savoir si l'estimation vaut quelque chose.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS services_consommations (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id     uuid NOT NULL REFERENCES services_externes(id) ON DELETE CASCADE,
  periode        text NOT NULL,                     -- 'YYYY-MM'
  quantite       numeric(18,4) NOT NULL DEFAULT 0,
  unite          text,
  prix_unitaire  numeric(14,6),
  cout_estime    numeric(12,2),
  cout_reel      numeric(12,2),
  devise         text NOT NULL DEFAULT 'USD',
  source         text NOT NULL DEFAULT 'manuel',
  note           text,
  created_by     uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT consommations_periode_forme CHECK (periode ~ '^\d{4}-\d{2}$'),
  CONSTRAINT consommations_source_valide CHECK (source IN ('manuel', 'automatique', 'facture'))
);
CREATE UNIQUE INDEX IF NOT EXISTS services_consommations_unique
  ON services_consommations (service_id, periode);
CREATE INDEX IF NOT EXISTS idx_consommations_periode ON services_consommations (periode);

DROP TRIGGER IF EXISTS trg_consommations_touch ON services_consommations;
CREATE TRIGGER trg_consommations_touch
  BEFORE UPDATE ON services_consommations
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   9. DÉPENSES
   -------------------------------------------------------------------------
   Archivage plutôt que suppression (mission § 25) : `archive` + qui, quand,
   pourquoi. Aucune route ne fait de DELETE sur cette table.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS depenses (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id     uuid REFERENCES services_externes(id) ON DELETE SET NULL,
  fournisseur    text,
  libelle        text NOT NULL,
  montant        numeric(12,2) NOT NULL,
  devise         text NOT NULL DEFAULT 'USD',
  date_depense   date NOT NULL DEFAULT current_date,
  categorie      text NOT NULL DEFAULT 'autres',
  description    text,
  recurrence     text NOT NULL DEFAULT 'ponctuelle',
  statut         text NOT NULL DEFAULT 'payee',
  justificatif_url        text,
  justificatif_nom        text,
  justificatif_document_id uuid,
  archive        boolean NOT NULL DEFAULT false,
  archive_par    uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  archive_at     timestamptz,
  archive_raison text,
  created_by     uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT depenses_categorie_valide CHECK (categorie IN (
    'infrastructure', 'api', 'hebergement', 'domaine', 'marketing',
    'communication', 'logiciels', 'support', 'autres')),
  CONSTRAINT depenses_recurrence_valide
    CHECK (recurrence IN ('ponctuelle', 'mensuelle', 'trimestrielle', 'annuelle')),
  CONSTRAINT depenses_statut_valide
    CHECK (statut IN ('prevue', 'payee', 'annulee')),
  CONSTRAINT depenses_montant_positif CHECK (montant >= 0)
);
CREATE INDEX IF NOT EXISTS idx_depenses_date      ON depenses (date_depense DESC) WHERE NOT archive;
CREATE INDEX IF NOT EXISTS idx_depenses_categorie ON depenses (categorie)         WHERE NOT archive;
CREATE INDEX IF NOT EXISTS idx_depenses_service   ON depenses (service_id);

DROP TRIGGER IF EXISTS trg_depenses_touch ON depenses;
CREATE TRIGGER trg_depenses_touch
  BEFORE UPDATE ON depenses
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   10. BUDGETS
   ========================================================================= */

CREATE TABLE IF NOT EXISTS budgets (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  periode        text NOT NULL,                     -- 'YYYY-MM' ou 'YYYY'
  categorie      text NOT NULL,                     -- catégorie de dépense, ou 'global'
  montant_prevu  numeric(12,2) NOT NULL DEFAULT 0,
  devise         text NOT NULL DEFAULT 'USD',
  note           text,
  created_by     uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT budgets_periode_forme CHECK (periode ~ '^\d{4}(-\d{2})?$'),
  CONSTRAINT budgets_montant_positif CHECK (montant_prevu >= 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS budgets_unique ON budgets (periode, categorie);

DROP TRIGGER IF EXISTS trg_budgets_touch ON budgets;
CREATE TRIGGER trg_budgets_touch
  BEFORE UPDATE ON budgets
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   11. TAUX DE CHANGE DE LA PLATEFORME
   -------------------------------------------------------------------------
   Ardoise encaisse en USD et en FC (`ecoles.taux_change_usd_fc` sert au
   niveau d'une école, pas au niveau plateforme). Additionner des montants de
   devises différentes sans conversion produit un chiffre d'affaires faux.
   Cette table donne un taux daté, saisi et traçable — jamais deviné.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS finance_taux_change (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  devise              text NOT NULL,
  devise_reference    text NOT NULL DEFAULT 'USD',
  taux_vers_reference numeric(18,8) NOT NULL,
  date_effet          date NOT NULL DEFAULT current_date,
  saisi_par           uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  note                text,
  created_at          timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT taux_positif CHECK (taux_vers_reference > 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS finance_taux_change_unique
  ON finance_taux_change (devise, devise_reference, date_effet);


/* =========================================================================
   12. JOURNAL FINANCIER
   -------------------------------------------------------------------------
   `journal_activite` existe et continue d'être alimenté (il reste la trace
   transversale). Ce second journal lui est COMPLÉMENTAIRE, pas concurrent :
   il porte des colonnes que `journal_activite` n'a pas — ancienne valeur,
   nouvelle valeur, motif, montant — et permet de répondre à « qui a changé
   ce prix, quand, et pourquoi » sans fouiller un JSONB.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS journal_financier (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action           text NOT NULL,
  entite           text NOT NULL,
  entite_id        uuid,
  libelle          text,
  ancienne_valeur  jsonb,
  nouvelle_valeur  jsonb,
  montant          numeric(12,2),
  devise           text,
  raison           text,
  ecole_id         uuid REFERENCES ecoles(id) ON DELETE SET NULL,
  utilisateur_id   uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  adresse_ip       text,
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_journal_financier_date   ON journal_financier (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_journal_financier_entite ON journal_financier (entite, entite_id);


/* =========================================================================
   13. ACCÈS FINANCE — Super Admin complet vs Super Admin Support
   -------------------------------------------------------------------------
   Pourquoi une table et pas un rôle ?
   Ajouter une valeur à l'ENUM `role_utilisateur` est IRRÉVERSIBLE en
   PostgreSQL, et `superAdminSeul` (middleware existant) filtre sur
   `is_superadmin` — un nouveau rôle n'entrerait donc même pas dans l'espace.
   Cette table se pose PAR-DESSUS le verrou existant sans le modifier : on
   reste Super Admin, on est simplement restreint à la lecture sur la partie
   financière. Réversible d'une ligne, auditable, sans migration d'ENUM.

   Absence de ligne = accès complet (comportement d'avant cette migration,
   donc aucune régression pour le Super Admin en place).
   ========================================================================= */

CREATE TABLE IF NOT EXISTS finance_acces (
  utilisateur_id uuid PRIMARY KEY REFERENCES utilisateurs(id) ON DELETE CASCADE,
  niveau         text NOT NULL DEFAULT 'complet',
  note           text,
  accorde_par    uuid REFERENCES utilisateurs(id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT finance_acces_niveau_valide CHECK (niveau IN ('complet', 'lecture'))
);

DROP TRIGGER IF EXISTS trg_finance_acces_touch ON finance_acces;
CREATE TRIGGER trg_finance_acces_touch
  BEFORE UPDATE ON finance_acces
  FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at();


/* =========================================================================
   14. RLS — toutes ces tables sont RÉSERVÉES AU SUPER ADMIN
   -------------------------------------------------------------------------
   Elles n'ont pas de `ecole_id` porteur de sens métier (sauf deux, qui
   restent malgré tout des données de la plateforme et non de l'école) : la
   policy n'est donc pas l'isolation multi-tenant habituelle, mais un refus
   pur et simple pour tout ce qui n'est pas le Super Admin.

   Une école ne doit jamais lire le tarif négocié d'une autre — ni le sien,
   d'ailleurs : c'est une information commerciale, pas une donnée scolaire.
   ========================================================================= */

DO $$
DECLARE
  t text;
  tables_finance text[] := ARRAY[
    'plan_prix_historique', 'promotions_commerciales', 'offres_speciales',
    'tarifs_personnalises', 'services_externes', 'services_consommations',
    'depenses', 'budgets', 'finance_taux_change', 'journal_financier',
    'finance_acces'
  ];
BEGIN
  FOREACH t IN ARRAY tables_finance LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);

    IF NOT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = t AND policyname = 'super_admin_seul'
    ) THEN
      EXECUTE format($f$
        CREATE POLICY super_admin_seul ON %I
          USING (current_setting('app.is_superadmin', true) = 'true')
          WITH CHECK (current_setting('app.is_superadmin', true) = 'true')
      $f$, t);
    END IF;
  END LOOP;
END $$;


/* =========================================================================
   15. DROITS POUR LE RÔLE APPLICATIF
   -------------------------------------------------------------------------
   Migration 024 a créé `ardoise_svc` (sans BYPASSRLS) et lui a donné les
   droits sur les tables d'alors. Les tables créées ici lui sont inconnues :
   sans ce bloc, l'application les verrait comme inexistantes dès que
   DATABASE_URL pointe sur `ardoise_svc`.

   Le bloc ne fait rien si le rôle n'existe pas encore — la base est peut-être
   encore en `postgres`, ce qui est le cas nominal avant bascule.
   ========================================================================= */

DO $$
DECLARE
  t text;
  tables_finance text[] := ARRAY[
    'plan_prix_historique', 'promotions_commerciales', 'offres_speciales',
    'tarifs_personnalises', 'services_externes', 'services_consommations',
    'depenses', 'budgets', 'finance_taux_change', 'journal_financier',
    'finance_acces'
  ];
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ardoise_svc') THEN
    FOREACH t IN ARRAY tables_finance LOOP
      EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON %I TO ardoise_svc', t);
    END LOOP;
    GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO ardoise_svc;
  END IF;

  /* `ia_lecture` (harnais de l'assistant IA) ne doit surtout PAS voir ces
     tables : elles contiennent des marges, des remises et des coûts internes
     qu'aucune école ne doit pouvoir se faire raconter par l'assistant. On
     révoque explicitement, au cas où un GRANT ALL antérieur les couvrirait. */
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ia_lecture') THEN
    FOREACH t IN ARRAY tables_finance LOOP
      EXECUTE format('REVOKE ALL ON %I FROM ia_lecture', t);
    END LOOP;
  END IF;
END $$;


/* =========================================================================
   16. CONFIGURATION — semée dans la table existante, pas dans une nouvelle
   -------------------------------------------------------------------------
   `configuration_plateforme` porte déjà les réglages globaux et son écran
   d'édition existe. Les seuils d'alerte financière y trouvent leur place
   sans qu'on ait à écrire un second écran de réglages.
   ========================================================================= */

INSERT INTO configuration_plateforme (cle, valeur, categorie, libelle, description, secret)
VALUES
  ('finance_devise_reference', '"USD"'::jsonb, 'finance',
   'Devise de référence', 'Devise dans laquelle tous les montants sont consolidés (revenus, coûts, marge).', false),

  ('finance_seuil_marge_faible', '20'::jsonb, 'finance',
   'Seuil de marge faible (%)', 'En dessous de ce pourcentage, une alerte marge est levée.', false),

  ('finance_seuil_hausse_cout_api', '50'::jsonb, 'finance',
   'Seuil de hausse des coûts API (%)', 'Hausse d''un mois sur l''autre au-delà de laquelle une alerte est levée.', false),

  ('finance_prealerte_renouvellement_jours', '14'::jsonb, 'finance',
   'Préavis de renouvellement (jours)', 'Délai avant renouvellement d''un service à partir duquel il est signalé.', false),

  ('finance_budget_seuil_alerte', '90'::jsonb, 'finance',
   'Seuil d''alerte budget (%)', 'Pourcentage de budget consommé à partir duquel une alerte est levée.', false),

  ('finance_churn_mensuel_defaut', '3'::jsonb, 'finance',
   'Churn mensuel par défaut (%)', 'Valeur utilisée dans les prévisions tant que l''historique est trop court pour le mesurer.', false),

  ('finance_croissance_mensuelle_defaut', '5'::jsonb, 'finance',
   'Croissance mensuelle par défaut (%)', 'Nombre de nouvelles écoles par mois, en pourcentage, pour le scénario « normal ».', false)
ON CONFLICT (cle) DO NOTHING;

COMMIT;


/* =========================================================================
   CONTRÔLE APRÈS EXÉCUTION — à lancer séparément, ne modifie rien
   =========================================================================

   SELECT tablename,
          (SELECT count(*) FROM pg_policies p
            WHERE p.schemaname='public' AND p.tablename=t.tablename) AS policies
     FROM (VALUES
       ('plan_prix_historique'),('promotions_commerciales'),('offres_speciales'),
       ('tarifs_personnalises'),('services_externes'),('services_consommations'),
       ('depenses'),('budgets'),('finance_taux_change'),('journal_financier'),
       ('finance_acces')) AS t(tablename);

   -- Chaque ligne doit afficher policies = 1.
   ========================================================================= */
