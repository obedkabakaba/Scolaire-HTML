/* =========================================================================
   ARDOISE — MIGRATION 028
   Catalogue commercial : offres à trois périodicités + services complémentaires
   =========================================================================

   POURQUOI CETTE MIGRATION
   ------------------------
   Le modèle commercial d'Ardoise comporte désormais DEUX ÉTAGES qui ne se
   mélangent pas :

     Étage 1 — L'ABONNEMENT. Ce que l'école paie pour utiliser la plateforme.
               Quatre niveaux, trois périodicités. Récurrent.
               → table `plans_abonnement` (elle existe déjà, on l'étend)

     Étage 2 — LES SERVICES COMPLÉMENTAIRES. Ce que l'école paie pour qu'une
               équipe d'Ardoise l'accompagne : installer, former, capturer les
               données. Ponctuel, optionnel, achetable avec N'IMPORTE QUELLE
               offre — y compris la plus modeste.
               → tables `services_complementaires` et `commandes_services`

   Cette séparation n'est pas cosmétique. Tant que l'installation ou la
   formation vivent comme des « fonctionnalités » d'un plan, deux choses
   deviennent impossibles : vendre une formation à une école en Ascension, et
   savoir combien la prestation humaine rapporte réellement. Deux tables
   distinctes règlent les deux problèmes d'un coup.

   CE QU'ELLE FAIT
   ---------------
     1. Ajoute la périodicité SEMESTRIELLE, absente partout (contrainte CHECK
        de `abonnements` comprise) alors que la grille tarifaire l'annonce.
     2. Ajoute `prix_semestriel` à `plans_abonnement`, à côté de `prix`
        (mensuel) et `prix_annuel` qui existaient déjà.
     3. Ajoute `limites` (jsonb) à `plans_abonnement` : UN SEUL endroit où
        lire le nombre d'élèves, d'utilisateurs, le quota IA, etc.
     4. Crée le catalogue des services et les commandes de services.
     5. Crée `demandes_accompagnement` pour les demandes venues du site
        public (visiteur non connecté).
     6. Sème les quatre offres et les cinq prestations, par `code`, en
        UPSERT — une base déjà peuplée est mise à jour, pas dupliquée.
     7. Pose la RLS sur les tables nouvelles.

   ELLE EST IDEMPOTENTE — tout est en IF NOT EXISTS / ON CONFLICT.
   ELLE NE SUPPRIME RIEN — aucun DROP, aucune colonne renommée.

   Tout tient dans UNE transaction : en cas d'échec, rien n'est appliqué.
   ========================================================================= */

BEGIN;

/* =========================================================================
   1. PÉRIODICITÉ SEMESTRIELLE
   -------------------------------------------------------------------------
   La contrainte actuelle n'accepte que mensuel / annuel / trimestriel /
   personnalise. Un abonnement semestriel était donc REFUSÉ par la base,
   silencieusement pour le commercial et bruyamment pour le serveur (erreur
   23514). On remplace la contrainte plutôt que d'en ajouter une seconde :
   deux CHECK sur la même colonne sont additifs, la nouvelle n'aurait rien
   débloqué.
   ========================================================================= */

/*
 * On supprime TOUTE contrainte CHECK portant sur `periodicite`, quel que soit
 * son nom, avant de poser la nôtre.
 *
 * Cibler le seul nom `abonnements_periodicite_check` ne suffit pas : si la
 * contrainte a été créée sous un autre nom — nommage automatique différent,
 * base restaurée depuis un dump, correctif appliqué à la main — le DROP ne
 * trouve rien, l'ADD réussit, et l'ANCIENNE contrainte continue de refuser
 * « semestriel ». Deux CHECK sur la même colonne sont additifs : le plus
 * strict gagne toujours.
 */
DO $$
DECLARE c record;
BEGIN
  FOR c IN
    SELECT conname FROM pg_constraint
     WHERE conrelid = 'public.abonnements'::regclass
       AND contype = 'c'
       AND pg_get_constraintdef(oid) ILIKE '%periodicite%'
  LOOP
    EXECUTE format('ALTER TABLE public.abonnements DROP CONSTRAINT %I', c.conname);
  END LOOP;

  ALTER TABLE public.abonnements
    ADD CONSTRAINT abonnements_periodicite_check
    CHECK (periodicite = ANY (ARRAY[
      'mensuel'::text, 'semestriel'::text, 'annuel'::text,
      'trimestriel'::text, 'personnalise'::text
    ]));
END $$;

-- Même correction pour les tarifs négociés : un tarif semestriel accordé à
-- une école devait pouvoir s'écrire.
DO $$
DECLARE c record;
BEGIN
  IF to_regclass('public.tarifs_personnalises') IS NULL THEN
    RETURN;   -- migration 027 non passée : sans conséquence ici
  END IF;

  FOR c IN
    SELECT conname FROM pg_constraint
     WHERE conrelid = 'public.tarifs_personnalises'::regclass
       AND contype = 'c'
       AND pg_get_constraintdef(oid) ILIKE '%periodicite%'
  LOOP
    EXECUTE format('ALTER TABLE public.tarifs_personnalises DROP CONSTRAINT %I', c.conname);
  END LOOP;

  ALTER TABLE public.tarifs_personnalises
    ADD CONSTRAINT tarifs_personnalises_periodicite_check
    CHECK (periodicite = ANY (ARRAY[
      'mensuel'::text, 'semestriel'::text, 'annuel'::text, 'trimestriel'::text
    ]));
END $$;


/* =========================================================================
   2. OFFRES — prix semestriel et limites normalisées
   -------------------------------------------------------------------------
   `limites` est un objet jsonb et non une colonne par limite, pour une
   raison précise : ajouter demain « max_classes » ne doit pas demander une
   migration ET un déploiement. Les clés attendues sont documentées ci-dessous
   et lues à UN SEUL endroit dans le code (utils/catalogue.utils.js).

     max_eleves               entier ou null (null = sans limite)
     max_utilisateurs         entier ou null
     max_classes              entier ou null
     ia_quota_mensuel         entier   (générations IA par mois)
     historique_annees        entier ou null (années scolaires consultables)
     stockage_mo              entier ou null
     notifications_email_mois entier ou null

   `fonctionnalites` (déjà présent) garde son rôle : objet de DRAPEAUX
   booléens par code de fonctionnalité. On n'y touche pas — sinon que la
   valeur historique `ia_quota_mensuel` y reste lue en repli par ia.utils.js.
   ========================================================================= */

ALTER TABLE public.plans_abonnement
  ADD COLUMN IF NOT EXISTS prix_semestriel numeric,
  ADD COLUMN IF NOT EXISTS limites jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS positionnement text,
  ADD COLUMN IF NOT EXISTS cible text;

COMMENT ON COLUMN public.plans_abonnement.limites IS
  'Limites quantitatives du plan. Source de vérité unique, lue par utils/catalogue.utils.js.';
COMMENT ON COLUMN public.plans_abonnement.prix_semestriel IS
  'Prix pour six mois. `prix` reste le prix mensuel, `prix_annuel` le prix pour douze mois.';


/* =========================================================================
   3. CATALOGUE DES SERVICES COMPLÉMENTAIRES
   -------------------------------------------------------------------------
   Un service N'EST PAS un plan et ne doit surtout pas vivre dans
   `plans_abonnement` : il n'a ni périodicité, ni renouvellement, ni date
   d'expiration, et il ne donne accès à rien. Il se commande, se réalise,
   se facture une fois.

   `mode_tarification` :
     'forfait'   → prix_unitaire est le prix total (installation, formation)
     'par_eleve' → prix_unitaire × quantité (campagne de capture, 0,50 $/élève)

   Le prix vit ICI et nulle part ailleurs. Le site public le lit par l'API,
   le Super Admin le modifie par l'interface. Aucun montant n'est écrit en
   dur dans un contrôleur ou une page.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS public.services_complementaires (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code              text NOT NULL UNIQUE,
  categorie         text NOT NULL DEFAULT 'autre'
                      CHECK (categorie = ANY (ARRAY['installation','formation','capture','autre'])),
  nom               text NOT NULL,
  accroche          text,
  description       text,
  mode_tarification text NOT NULL DEFAULT 'forfait'
                      CHECK (mode_tarification = ANY (ARRAY['forfait','par_eleve'])),
  prix_unitaire     numeric NOT NULL DEFAULT 0 CHECK (prix_unitaire >= 0),
  devise            text NOT NULL DEFAULT 'USD',
  unite             text,
  quantite_minimum  integer CHECK (quantite_minimum IS NULL OR quantite_minimum > 0),
  duree_indicative  text,
  inclus            jsonb NOT NULL DEFAULT '[]'::jsonb,
  exclus            jsonb NOT NULL DEFAULT '[]'::jsonb,
  prerequis         jsonb NOT NULL DEFAULT '[]'::jsonb,
  cible             text,
  ordre_affichage   integer NOT NULL DEFAULT 0,
  visible_public    boolean NOT NULL DEFAULT true,
  statut            text NOT NULL DEFAULT 'actif'
                      CHECK (statut = ANY (ARRAY['actif','inactif','archive'])),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  updated_by        uuid REFERENCES public.utilisateurs(id)
);

CREATE INDEX IF NOT EXISTS services_complementaires_categorie_idx
  ON public.services_complementaires (categorie, ordre_affichage);


/* =========================================================================
   4. COMMANDES DE SERVICES
   -------------------------------------------------------------------------
   Ce qu'une école a effectivement acheté. Le prix est FIGÉ à la commande
   (`prix_unitaire_applique`) : relever demain la campagne de capture à
   0,60 $ ne doit pas réécrire ce qu'une école a payé l'an dernier. C'est la
   même règle que `abonnements.prix_applique`, pour la même raison.

   `facture_id` relie la prestation à la facturation existante quand elle est
   émise. Il reste nullable : beaucoup de prestations se règlent en espèces et
   sont constatées après coup, exactement comme les abonnements.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS public.commandes_services (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ecole_id               uuid NOT NULL REFERENCES public.ecoles(id),
  service_id             uuid NOT NULL REFERENCES public.services_complementaires(id),
  quantite               numeric NOT NULL DEFAULT 1 CHECK (quantite > 0),
  prix_unitaire_applique numeric NOT NULL CHECK (prix_unitaire_applique >= 0),
  montant_total          numeric NOT NULL CHECK (montant_total >= 0),
  devise                 text NOT NULL DEFAULT 'USD',
  statut                 text NOT NULL DEFAULT 'demandee'
                           CHECK (statut = ANY (ARRAY[
                             'demandee','confirmee','planifiee','en_cours',
                             'realisee','annulee'])),
  date_demande           timestamptz NOT NULL DEFAULT now(),
  date_planifiee         date,
  date_realisation       timestamptz,
  facture_id             uuid REFERENCES public.factures(id),
  demande_par            uuid REFERENCES public.utilisateurs(id),
  traite_par             uuid REFERENCES public.utilisateurs(id),
  contact_nom            text,
  contact_telephone      text,
  contact_email          text,
  note                   text,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS commandes_services_ecole_idx
  ON public.commandes_services (ecole_id, date_demande DESC);
CREATE INDEX IF NOT EXISTS commandes_services_statut_idx
  ON public.commandes_services (statut, date_demande DESC);


/* =========================================================================
   5. DEMANDES VENUES DU SITE PUBLIC
   -------------------------------------------------------------------------
   Un directeur qui découvre Ardoise n'a pas encore d'école dans la base : sa
   demande d'accompagnement ne peut donc pas être une `commandes_services`,
   qui exige un `ecole_id`. Elle atterrit ici, et le Super Admin la convertit
   en commande le jour où l'école est créée.

   Table volontairement pauvre en données personnelles : un nom, un moyen de
   rappel, ce qui intéresse la personne. Rien de plus.
   ========================================================================= */

CREATE TABLE IF NOT EXISTS public.demandes_accompagnement (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ecole_nom         text,
  contact_nom       text NOT NULL,
  contact_telephone text,
  contact_email     text,
  ville             text,
  nb_eleves_estime  integer CHECK (nb_eleves_estime IS NULL OR nb_eleves_estime >= 0),
  offre_envisagee   text,
  services_souhaites jsonb NOT NULL DEFAULT '[]'::jsonb,
  message           text,
  origine           text NOT NULL DEFAULT 'site_public',
  statut            text NOT NULL DEFAULT 'nouvelle'
                      CHECK (statut = ANY (ARRAY['nouvelle','contactee','convertie','sans_suite'])),
  ecole_id          uuid REFERENCES public.ecoles(id),
  traite_par        uuid REFERENCES public.utilisateurs(id),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS demandes_accompagnement_statut_idx
  ON public.demandes_accompagnement (statut, created_at DESC);


/* =========================================================================
   6. `updated_at` tenu à jour
   ========================================================================= */

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['services_complementaires','commandes_services','demandes_accompagnement']
  LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_trigger
       WHERE tgname = t || '_touch'
         AND tgrelid = ('public.' || t)::regclass
    ) THEN
      EXECUTE format(
        'CREATE TRIGGER %I BEFORE UPDATE ON public.%I
           FOR EACH ROW EXECUTE FUNCTION finance_touch_updated_at()',
        t || '_touch', t);
    END IF;
  END LOOP;
EXCEPTION WHEN undefined_function THEN
  -- migration 027 non passée : les triggers sont un confort, pas une condition
  NULL;
END $$;


/* =========================================================================
   7. SÉCURITÉ — RLS
   -------------------------------------------------------------------------
   · `services_complementaires` : catalogue commercial, lisible par toute
     personne authentifiée (le directeur doit voir ce qu'il peut acheter),
     modifiable par le seul Super Admin.
   · `commandes_services` : strictement cloisonné par école, comme toute
     table portant un `ecole_id`.
   · `demandes_accompagnement` : Super Admin uniquement. Les insertions
     venues du site public passent par le contexte super-admin du serveur,
     comme le fait déjà public.controller.js.
   ========================================================================= */

ALTER TABLE public.services_complementaires ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commandes_services       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.demandes_accompagnement  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS services_lecture      ON public.services_complementaires;
DROP POLICY IF EXISTS services_ecriture     ON public.services_complementaires;
DROP POLICY IF EXISTS commandes_par_ecole   ON public.commandes_services;
DROP POLICY IF EXISTS demandes_super_admin  ON public.demandes_accompagnement;

CREATE POLICY services_lecture ON public.services_complementaires
  FOR SELECT USING (true);

CREATE POLICY services_ecriture ON public.services_complementaires
  FOR ALL
  USING      (COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true');

CREATE POLICY commandes_par_ecole ON public.commandes_services
  FOR ALL
  USING (
    COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true'
    OR ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid
  )
  WITH CHECK (
    COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true'
    OR ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid
  );

CREATE POLICY demandes_super_admin ON public.demandes_accompagnement
  FOR ALL
  USING      (COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_super_admin', true), 'false') = 'true');

-- Droits du rôle applicatif (voir migration 024).
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ardoise_svc') THEN
    GRANT SELECT, INSERT, UPDATE ON
      public.services_complementaires,
      public.commandes_services,
      public.demandes_accompagnement
      TO ardoise_svc;
  END IF;
END $$;


/* =========================================================================
   8. SEMIS — LES QUATRE OFFRES
   -------------------------------------------------------------------------
   Les noms restent des DONNÉES, jamais du code : ces quatre lignes se
   renomment depuis l'espace Super Admin sans redéploiement. Le semis se fait
   par `code`, stable, et non par `nom`, qui peut changer.

   `duree_jours` reste 30 : c'est la durée de l'UNITÉ de facturation, pas
   celle de l'engagement. La périodicité choisie (mensuel / semestriel /
   annuel) porte l'engagement, et c'est elle qui pilote désormais la date
   d'expiration (voir controllers/abonnements.controller.js).

   GRILLE APPLIQUÉE
     Ascension   35 $/mois   193 $/6 mois    350 $/an
     Prime       59 $/mois   325 $/6 mois    590 $/an
     Pilote      99 $/mois   545 $/6 mois    990 $/an
     Infinite   159 $/mois   875 $/6 mois  1 590 $/an

   Elle suit une règle unique pour les quatre offres : le semestriel vaut
   5,5 mensualités (un demi-mois offert), l'annuel en vaut 10 (deux mois
   offerts). Soit 8 % et 17 % de remise partout — voir migration 029, qui
   documente pourquoi la grille de départ a été harmonisée. Le semis pose
   directement les valeurs définitives : une installation neuve ne doit pas
   afficher un prix qu'on corrige à la migration suivante.
   ========================================================================= */

/* -------------------------------------------------------------------------
   8.a  PRÉALABLE — garantir que `code` est bien une clé d'unicité.

   C'est ce que l'erreur suivante signale, et elle est due à un ordre :

     ERROR 42P10 : there is no unique or exclusion constraint matching the
                   ON CONFLICT specification

   `ON CONFLICT (code)` exige un index d'unicité SUR L'EXPRESSION EXACTE
   `code`. Or la migration 027 a créé un index d'unicité sur `lower(code)`,
   partiel (`WHERE code IS NOT NULL`) — ce qui est le bon choix, un code de
   plan ne devant pas différer par une majuscule. Mais PostgreSQL ne déduit
   pas seul qu'un index sur `lower(code)` couvre un conflit annoncé sur
   `code` : il faut le lui dire, en reprenant l'expression ET le prédicat.

   Trois choses sont donc faites ici, dans cet ordre :
     · les plans existants sans code se voient attribuer le leur, d'après leur
       nom — sans quoi une base qui contient déjà « Ardoise Prime » verrait
       une SECONDE ligne Prime être créée à côté de la première ;
     · les doublons éventuels sont signalés clairement plutôt que de faire
       échouer la création d'index sur un message illisible ;
     · l'index est créé s'il manque.
   ------------------------------------------------------------------------- */

-- Rattachement des offres déjà présentes sous leur nom commercial.
UPDATE public.plans_abonnement SET code = 'ascension'
 WHERE code IS NULL AND lower(btrim(nom)) IN ('ardoise ascension', 'ascension');
UPDATE public.plans_abonnement SET code = 'prime'
 WHERE code IS NULL AND lower(btrim(nom)) IN ('ardoise prime', 'prime');
UPDATE public.plans_abonnement SET code = 'pilote'
 WHERE code IS NULL AND lower(btrim(nom)) IN ('ardoise pilote', 'pilote');
UPDATE public.plans_abonnement SET code = 'infinite'
 WHERE code IS NULL AND lower(btrim(nom)) IN ('ardoise infinite', 'infinite');

-- Les codes sont normalisés en minuscules : le catalogue les compare tels quels.
UPDATE public.plans_abonnement
   SET code = lower(btrim(code))
 WHERE code IS NOT NULL AND code <> lower(btrim(code));

DO $$
DECLARE doublons text;
BEGIN
  SELECT string_agg(c || ' (' || n || ' lignes)', ', ')
    INTO doublons
    FROM (SELECT lower(code) AS c, count(*) AS n
            FROM public.plans_abonnement
           WHERE code IS NOT NULL
           GROUP BY lower(code) HAVING count(*) > 1) d;

  IF doublons IS NOT NULL THEN
    RAISE EXCEPTION
      'Plusieurs plans partagent le même code : %. Corrigez-les avant de rejouer '
      'cette migration — un abonnement ne doit pouvoir désigner qu''une seule offre. '
      'Requête utile : SELECT id, code, nom, prix FROM plans_abonnement '
      'WHERE code IS NOT NULL ORDER BY lower(code);', doublons;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS plans_abonnement_code_unique
  ON public.plans_abonnement (lower(code)) WHERE code IS NOT NULL;


/* -------------------------------------------------------------------------
   8.b  SEMIS DES QUATRE OFFRES
   ------------------------------------------------------------------------- */

INSERT INTO public.plans_abonnement
  (code, nom, description, positionnement, cible,
   prix, prix_semestriel, prix_annuel, devise, duree_jours,
   max_eleves, max_utilisateurs, limites, fonctionnalites,
   fonctionnalites_incluses, ordre_affichage, badge, couleur,
   texte_marketing, visible_public, statut)
VALUES
  ('ascension', 'Ardoise Ascension',
   'La première vraie étape de digitalisation : élèves, notes, bulletins officiels, présences et frais scolaires, avec un logiciel utilisable professionnellement dès le premier jour.',
   'Digitaliser l''essentiel',
   'Écoles jusqu''à 250 élèves qui tiennent encore leurs registres sur papier ou sur Excel.',
   35, 193, 350, 'USD', 30,
   250, 15,
   '{"max_eleves":250,"max_utilisateurs":15,"max_classes":12,"ia_quota_mensuel":100,"historique_annees":1,"stockage_mo":500,"notifications_email_mois":500}'::jsonb,
   '{"ia_quota_mensuel":100,"assistant_aide":true,"ia_appreciations":true}'::jsonb,
   '["Élèves, classes, sections et options","Notes, travaux et classements automatiques","Bulletins officiels RDC (primaire, secondaire, terminale)","Présences","Frais scolaires, paiements et reçus (FC et USD)","Didacticiel intégré et assistant d''aide","Application installable, consultation hors ligne"]'::jsonb,
   1, NULL, '#3C5A62',
   'Tout le cœur du métier, sans rien retirer d''essentiel.', true, 'actif'),

  ('prime', 'Ardoise Prime',
   'Le niveau de l''école qui veut arrêter de tout faire à la main : emploi du temps, discipline, communication aux parents et présence en ligne de l''établissement.',
   'Automatiser et communiquer',
   'Écoles de 250 à 600 élèves dont l''administration commence à saturer.',
   59, 325, 590, 'USD', 30,
   600, 40,
   '{"max_eleves":600,"max_utilisateurs":40,"max_classes":40,"ia_quota_mensuel":400,"historique_annees":3,"stockage_mo":2000,"notifications_email_mois":3000}'::jsonb,
   '{"ia_quota_mensuel":400,"assistant_aide":true,"ia_appreciations":true,"emploi_du_temps":true,"discipline":true,"communication_masse":true,"site_public":true,"modeles_personnalises":true,"ia_reglement_discipline":true}'::jsonb,
   '["Tout Ascension","Emploi du temps et créneaux","Discipline : incidents, règlement, capital conduite","Messages groupés aux parents et au personnel","Site public de l''école et consultation des résultats en ligne","Éditeur de modèles de bulletins","Lecture du règlement intérieur par l''IA"]'::jsonb,
   2, 'Le plus choisi', '#C98A3E',
   'Le palier où l''administration cesse d''être un travail à plein temps.', true, 'actif'),

  ('pilote', 'Ardoise Pilote',
   'Le niveau du complexe scolaire structuré : comptabilité et paie, concours d''admission, orientation, repêchage, et interrogation des données en langage naturel.',
   'Piloter l''établissement',
   'Établissements de 600 à 1 500 élèves avec une direction, une comptabilité et des procédures d''admission.',
   99, 545, 990, 'USD', 30,
   1500, 120,
   '{"max_eleves":1500,"max_utilisateurs":120,"max_classes":null,"ia_quota_mensuel":1500,"historique_annees":5,"stockage_mo":10000,"notifications_email_mois":15000}'::jsonb,
   '{"ia_quota_mensuel":1500,"assistant_aide":true,"ia_appreciations":true,"emploi_du_temps":true,"discipline":true,"communication_masse":true,"site_public":true,"modeles_personnalises":true,"ia_reglement_discipline":true,"comptabilite":true,"paie":true,"concours_admission":true,"orientation":true,"repechage":true,"rapports_avances":true,"ia_analyse_donnees":true}'::jsonb,
   '["Tout Prime","Comptabilité : caisse, catégories, dépenses","Paie : contrats et salaires du personnel","Concours d''admission et classement des candidats","Orientation des élèves au mérite","Session de repêchage de fin d''année","Rapports avancés et tableaux de bord","Questions sur vos données en langage naturel"]'::jsonb,
   3, NULL, '#1F2B24',
   'Pour diriger sur des chiffres, pas sur des impressions.', true, 'actif'),

  ('infinite', 'Ardoise Infinite',
   'L''exploitation maximale d''Ardoise : aucune limite d''élèves, de comptes ni de classes, assistant WhatsApp pour les parents, le quota IA le plus élevé, archives illimitées et support prioritaire.',
   'Exploiter Ardoise sans limite',
   'Grands établissements et structures multi-vacations de plus de 1 500 élèves.',
   159, 875, 1590, 'USD', 30,
   NULL, NULL,
   '{"max_eleves":null,"max_utilisateurs":null,"max_classes":null,"ia_quota_mensuel":5000,"historique_annees":null,"stockage_mo":50000,"notifications_email_mois":null}'::jsonb,
   '{"ia_quota_mensuel":5000,"assistant_aide":true,"ia_appreciations":true,"emploi_du_temps":true,"discipline":true,"communication_masse":true,"site_public":true,"modeles_personnalises":true,"ia_reglement_discipline":true,"comptabilite":true,"paie":true,"concours_admission":true,"orientation":true,"repechage":true,"rapports_avances":true,"ia_analyse_donnees":true,"whatsapp":true,"support_prioritaire":true}'::jsonb,
   '["Tout Pilote","Élèves et comptes sans limite de nombre","Assistant WhatsApp pour les parents et le personnel","5 000 générations IA par mois","Archives et historique illimités","Support prioritaire"]'::jsonb,
   4, NULL, '#6B4E9E',
   'Quand le nombre d''élèves ne doit plus jamais être un sujet.', true, 'actif')

-- La cible du conflit reprend EXACTEMENT l'expression et le prédicat de
-- l'index `plans_abonnement_code_unique` créé plus haut. Sans le `WHERE`,
-- PostgreSQL ne reconnaît pas l'index partiel et renvoie de nouveau 42P10.
ON CONFLICT (lower(code)) WHERE code IS NOT NULL DO UPDATE SET
  nom                      = EXCLUDED.nom,
  description              = EXCLUDED.description,
  positionnement           = EXCLUDED.positionnement,
  cible                    = EXCLUDED.cible,
  prix                     = EXCLUDED.prix,
  prix_semestriel          = EXCLUDED.prix_semestriel,
  prix_annuel              = EXCLUDED.prix_annuel,
  devise                   = EXCLUDED.devise,
  duree_jours              = EXCLUDED.duree_jours,
  max_eleves               = EXCLUDED.max_eleves,
  max_utilisateurs         = EXCLUDED.max_utilisateurs,
  limites                  = EXCLUDED.limites,
  fonctionnalites          = EXCLUDED.fonctionnalites,
  fonctionnalites_incluses = EXCLUDED.fonctionnalites_incluses,
  ordre_affichage          = EXCLUDED.ordre_affichage,
  badge                    = EXCLUDED.badge,
  couleur                  = EXCLUDED.couleur,
  texte_marketing          = EXCLUDED.texte_marketing,
  visible_public           = EXCLUDED.visible_public,
  statut                   = EXCLUDED.statut,
  updated_at               = now();

/* =========================================================================
   9. SEMIS — LES SERVICES COMPLÉMENTAIRES
   -------------------------------------------------------------------------
   Trois catégories, cinq prestations achetables. Aucune n'est liée à un plan :
   une école en Ascension peut acheter la formation personnalisée à 100 $, et
   c'est délibéré.

   NOTE SUR LE PRIX DE L'INSTALLATION
   ----------------------------------
   Le cahier des charges dit 60 $ en §5 (« montant fixe ») et 50 $ en §16 et
   §21 (« à partir de »). Nous retenons 60 $, seule valeur donnée comme
   ferme, et l'affichons sans « à partir de » puisque le forfait est unique.
   Le corriger tient en un UPDATE d'une ligne, ou deux clics dans l'espace
   Super Admin — aucun déploiement.
   ========================================================================= */

/*
 * Même précaution que pour les offres. La table est créée plus haut AVEC
 * `code text NOT NULL UNIQUE`, donc l'index existe dans le cas normal. Ce
 * bloc couvre le cas où la table aurait été créée à la main lors d'un essai
 * précédent, sans la contrainte : l'UPSERT échouerait alors sur le même
 * 42P10, et le message ne dirait pas d'où il vient.
 */
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_index i
      JOIN pg_class c ON c.oid = i.indexrelid
     WHERE i.indrelid = 'public.services_complementaires'::regclass
       AND i.indisunique
       AND i.indnatts = 1
       AND pg_get_indexdef(i.indexrelid) ILIKE '%(code)%'
  ) THEN
    CREATE UNIQUE INDEX services_complementaires_code_unique
      ON public.services_complementaires (code);
  END IF;
END $$;

INSERT INTO public.services_complementaires
  (code, categorie, nom, accroche, description, mode_tarification, prix_unitaire,
   devise, unite, duree_indicative, inclus, exclus, prerequis, cible,
   ordre_affichage, visible_public, statut)
VALUES
  ('installation', 'installation', 'Installation & configuration',
   'Votre école prête à l''emploi, paramétrée par notre équipe.',
   'Nous créons votre école dans Ardoise et nous la paramétrons entièrement à partir de vos documents : années scolaires, périodes, sections, options, classes, cours et coefficients, système de notation, mentions, seuils de promotion et grille des frais. Vous récupérez une plateforme déjà conforme à votre organisation, pas un formulaire vide.',
   'forfait', 60, 'USD', NULL, 'Une intervention, généralement sous 72 heures',
   '["Création de l''école et du compte Directeur","Années scolaires et périodes (trimestres ou semestres)","Sections, options, classes et cours avec coefficients","Système de notation, mentions et seuils de promotion","Grille des frais scolaires et devise de référence","Création des comptes du personnel","Vérification finale avec la direction"]'::jsonb,
   '["La saisie des élèves un par un (voir la campagne de capture)","La formation du personnel (voir la formation)"]'::jsonb,
   '["Un abonnement Ardoise actif, quel qu''il soit","Vos documents d''organisation : liste des classes, cours et coefficients"]'::jsonb,
   'Toute école qui démarre et préfère ne pas paramétrer elle-même.',
   1, true, 'actif'),

  ('formation_express', 'formation', 'Formation express',
   'Une séance courte pour prendre Ardoise en main.',
   'Une séance de prise en main, sur place ou à distance, centrée sur les gestes quotidiens : se connecter, saisir des notes, faire l''appel, générer un bulletin. De quoi permettre à l''équipe de commencer à travailler dès le lendemain.',
   'forfait', 30, 'USD', NULL, 'Environ 1 h 30, une séance',
   '["Connexion et rôles de chacun","Saisie des notes et des travaux","Appel et présences","Génération d''un bulletin de bout en bout","Questions-réponses"]'::jsonb,
   '["Le paramétrage de l''école (voir installation & configuration)"]'::jsonb,
   '["Un abonnement Ardoise actif","Une école déjà paramétrée"]'::jsonb,
   'Équipes réduites, ou personnel déjà à l''aise avec l''outil informatique.',
   2, true, 'actif'),

  ('formation_complete', 'formation', 'Formation complète',
   'Une formation approfondie sur l''ensemble de la plateforme.',
   'Une formation qui couvre l''usage général d''Ardoise, module par module, du dossier élève jusqu''au bulletin annuel, avec les cas particuliers que rencontre réellement une école : élève arrivé en cours d''année, note contestée, période clôturée, bulletin bloqué pour impayé.',
   'forfait', 60, 'USD', NULL, 'Une demi-journée',
   '["Tout le contenu de la formation express","Dossiers élèves, inscriptions et sorties","Bulletins de période, de semestre et annuels","Frais scolaires, paiements et reçus","Clôture de période et fin d''année","Cas particuliers et erreurs fréquentes","Support écrit remis à l''équipe"]'::jsonb,
   '["L''adaptation aux procédures internes de l''établissement (voir formation personnalisée)"]'::jsonb,
   '["Un abonnement Ardoise actif","Une école déjà paramétrée"]'::jsonb,
   'Écoles qui forment plusieurs profils d''un coup : secrétariat, titulaires, professeurs.',
   3, true, 'actif'),

  ('formation_personnalisee', 'formation', 'Formation personnalisée',
   'Une formation construite sur vos procédures et vos profils d''utilisateurs.',
   'Nous partons de VOTRE organisation : qui saisit les notes, qui les valide, qui encaisse, qui signe les bulletins. La formation est bâtie autour de ces circuits et donnée séparément à chaque profil concerné, avec les cas réels de votre établissement.',
   'forfait', 100, 'USD', NULL, 'Une journée, plusieurs sessions par profil',
   '["Tout le contenu de la formation complète","Étude préalable de vos circuits internes","Sessions séparées par profil (direction, secrétariat, titulaires, professeurs)","Exercices sur vos propres données","Fiches de procédure rédigées à vos noms de rôles","Séance de suivi à distance après quelques semaines"]'::jsonb,
   '[]'::jsonb,
   '["Un abonnement Ardoise actif","Une école déjà paramétrée"]'::jsonb,
   'Établissements structurés, ou écoles dont le personnel est peu familier de l''informatique.',
   4, true, 'actif'),

  ('campagne_capture', 'capture', 'Campagne de capture',
   'Nous constituons votre base d''élèves à partir de vos registres.',
   'La campagne de capture est le travail de saisie qui transforme vos registres papier en base de données exploitable. Notre équipe collecte, saisit, vérifie et charge dans Ardoise les informations de chaque élève : identité, date et lieu de naissance, classe, responsable et coordonnées. Vous passez d''une armoire de fiches à une école consultable en trois clics.',
   'par_eleve', 0.50, 'USD', 'élève', 'Selon le volume : comptez une semaine pour 500 élèves',
   '["Récupération de vos registres ou fiches d''inscription","Saisie de l''identité complète de chaque élève","Saisie du responsable et de ses coordonnées","Affectation de chaque élève à sa classe","Attribution des matricules et des codes d''accès","Contrôle des doublons et des incohérences","Chargement dans Ardoise et restitution d''une liste de vérification"]'::jsonb,
   '["La photographie des élèves","La numérisation des pièces d''état civil","La saisie des notes des années antérieures"]'::jsonb,
   '["Un abonnement Ardoise actif","Une école déjà paramétrée (classes créées)","Des registres lisibles ou des fiches d''inscription"]'::jsonb,
   'Écoles qui démarrent avec un stock d''élèves existant, ou qui n''ont jamais rien informatisé.',
   5, true, 'actif')

ON CONFLICT (code) DO UPDATE SET
  categorie         = EXCLUDED.categorie,
  nom               = EXCLUDED.nom,
  accroche          = EXCLUDED.accroche,
  description       = EXCLUDED.description,
  mode_tarification = EXCLUDED.mode_tarification,
  prix_unitaire     = EXCLUDED.prix_unitaire,
  devise            = EXCLUDED.devise,
  unite             = EXCLUDED.unite,
  duree_indicative  = EXCLUDED.duree_indicative,
  inclus            = EXCLUDED.inclus,
  exclus            = EXCLUDED.exclus,
  prerequis         = EXCLUDED.prerequis,
  cible             = EXCLUDED.cible,
  ordre_affichage   = EXCLUDED.ordre_affichage,
  visible_public    = EXCLUDED.visible_public,
  statut            = EXCLUDED.statut,
  updated_at        = now();


/* =========================================================================
   10. RÉGLAGES DE PLATEFORME
   -------------------------------------------------------------------------
   Deux clés seulement, dans la table de configuration déjà en place plutôt
   que dans une table de réglages de plus.
   ========================================================================= */

INSERT INTO public.configuration_plateforme (cle, valeur, categorie, libelle, description)
VALUES
  ('commercial.devise_affichage', '"USD"'::jsonb, 'commercial',
   'Devise d''affichage du site public',
   'Devise dans laquelle les offres et services sont présentés aux visiteurs.'),
  ('commercial.contact_commercial', '{"telephone":null,"email":null,"whatsapp":null}'::jsonb, 'commercial',
   'Contact commercial affiché publiquement',
   'Coordonnées proposées au visiteur qui demande un accompagnement.')
ON CONFLICT (cle) DO NOTHING;

COMMIT;

/* =========================================================================
   VÉRIFICATION APRÈS APPLICATION
   -------------------------------------------------------------------------
   SELECT code, nom, prix, prix_semestriel, prix_annuel,
          limites->>'max_eleves' AS eleves,
          limites->>'ia_quota_mensuel' AS ia
     FROM plans_abonnement WHERE statut = 'actif' ORDER BY ordre_affichage;

   SELECT code, categorie, nom, mode_tarification, prix_unitaire
     FROM services_complementaires ORDER BY ordre_affichage;
   ========================================================================= */
