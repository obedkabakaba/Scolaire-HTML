/* =============================================================================
   029 — CORRECTIF : NOM DU RÉGLAGE RLS DANS LES POLICIES DU CATALOGUE
   =============================================================================

   LE SYMPTÔME
   -----------
     POST /catalogue/demande-accompagnement → 500
     error: new row violates row-level security policy
            for table "demandes_accompagnement"   (SQLSTATE 42501)

   LA CAUSE
   --------
   Toute la plateforme pose le contexte de super administrateur sous le nom
   `app.is_superadmin`, en un seul mot :

     config/db.js          →  SET LOCAL app.is_superadmin = 'true'
     migration 024         →  current_setting('app.is_superadmin', true)
     migration 027         →  current_setting('app.is_superadmin', true)

   La migration 028 l'a interrogé sous le nom `app.is_super_admin`, avec un
   tiret bas de plus. PostgreSQL ne rapproche pas les deux : `current_setting`
   sur un réglage jamais posé renvoie NULL, le COALESCE le remplace par
   'false', et la policy refuse l'écriture.

   Trois tables portent l'erreur, et elle se manifeste différemment sur
   chacune — ce qui explique qu'elle ait pu passer inaperçue :

     · `services_complementaires` — la lecture reste ouverte (`USING (true)`),
       donc le site public affiche correctement les services. Seule la
       MODIFICATION du catalogue depuis l'espace Super Admin échoue.
     · `commandes_services` — une école qui commande une prestation passe par
       la branche `ecole_id = app.current_ecole_id`, qui, elle, est correcte.
       L'échec ne survient que sur les écritures faites en contexte super
       administrateur.
     · `demandes_accompagnement` — aucune branche de repli : le formulaire
       public échoue à tous les coups. C'est celle qu'on voit.

   CE QU'ELLE FAIT
   ---------------
   Elle recrée les quatre policies concernées à l'identique, au nom du
   réglage près. Aucune donnée n'est touchée, aucune colonne modifiée, aucun
   droit élargi : le comportement voulu par la migration 028 est simplement
   celui qui s'applique enfin.

   ELLE EST IDEMPOTENTE et REJOUABLE. Tout tient dans une transaction.

   POURQUOI PAS UN ALIAS
   ---------------------
   On aurait pu poser `app.is_super_admin` en plus dans `db.js` et ne rien
   changer ici. Ce serait deux noms pour une même notion, dont l'un ne
   servirait qu'à trois policies : la prochaine personne qui écrit une policy
   tirerait à pile ou face. Un seul nom, celui déjà employé partout.
   ============================================================================= */

BEGIN;

/* -------------------------------------------------------------------------
   Garde-fou : la migration 028 doit avoir été appliquée.
   Sans elle, les tables n'existent pas et les DROP POLICY ci-dessous
   échoueraient sur un message qui ne dirait pas pourquoi.
   ------------------------------------------------------------------------- */
DO $$
BEGIN
  IF to_regclass('public.demandes_accompagnement') IS NULL THEN
    RAISE EXCEPTION
      'La migration 028 (catalogue commercial) n''a pas été appliquée : '
      'la table demandes_accompagnement est absente. Appliquez-la d''abord.';
  END IF;
END $$;


/* =========================================================================
   1. services_complementaires — écriture réservée au super administrateur
   ========================================================================= */

DROP POLICY IF EXISTS services_ecriture ON public.services_complementaires;

CREATE POLICY services_ecriture ON public.services_complementaires
  FOR ALL
  USING      (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true');


/* =========================================================================
   2. commandes_services — son école, ou le super administrateur
   ========================================================================= */

DROP POLICY IF EXISTS commandes_par_ecole ON public.commandes_services;

CREATE POLICY commandes_par_ecole ON public.commandes_services
  FOR ALL
  USING (
    COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true'
    OR ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid
  )
  WITH CHECK (
    COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true'
    OR ecole_id = NULLIF(current_setting('app.current_ecole_id', true), '')::uuid
  );


/* =========================================================================
   3. demandes_accompagnement — super administrateur seul
   -------------------------------------------------------------------------
   Le formulaire public écrit ici, mais il n'écrit pas « en tant que
   visiteur » : le contrôleur ouvre volontairement une transaction en
   contexte super administrateur (`SUPER` dans catalogue.controller.js), parce
   qu'un prospect n'appartient à aucune école. La policy reste donc fermée,
   et c'est le code applicatif — validé, limité en débit, filtré contre le
   catalogue — qui constitue la porte.
   ========================================================================= */

DROP POLICY IF EXISTS demandes_super_admin ON public.demandes_accompagnement;

CREATE POLICY demandes_super_admin ON public.demandes_accompagnement
  FOR ALL
  USING      (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true');


/* =========================================================================
   4. VÉRIFICATION IMMÉDIATE
   -------------------------------------------------------------------------
   Une migration de correctif RLS qui se contente de recréer des policies ne
   prouve rien : on peut se tromper deux fois. On rejoue donc ici, dans la
   transaction, exactement ce que fait le contrôleur — puis on annule l'essai.
   Si la policy est encore fausse, la migration échoue MAINTENANT, avec un
   message clair, plutôt qu'au prochain visiteur du site.
   ========================================================================= */

DO $$
DECLARE essai uuid;
BEGIN
  PERFORM set_config('app.is_superadmin', 'true', true);

  INSERT INTO public.demandes_accompagnement (contact_nom, contact_telephone, origine)
  VALUES ('__verification_migration_029', '+000000000', 'verification')
  RETURNING id INTO essai;

  DELETE FROM public.demandes_accompagnement WHERE id = essai;

  RAISE NOTICE 'Migration 029 : écriture en contexte super administrateur vérifiée.';
END $$;

COMMIT;

/* =========================================================================
   APRÈS APPLICATION — contrôle manuel
   -------------------------------------------------------------------------
   Aucune policy du schéma ne doit plus mentionner `is_super_admin` :

     SELECT schemaname, tablename, policyname
       FROM pg_policies
      WHERE qual ILIKE '%is\_super\_admin%' ESCAPE '\'
         OR with_check ILIKE '%is\_super\_admin%' ESCAPE '\';

   Le résultat attendu est zéro ligne.
   ========================================================================= */
