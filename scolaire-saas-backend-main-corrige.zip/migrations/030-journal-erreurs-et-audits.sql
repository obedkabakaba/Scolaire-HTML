-- ============================================================================
--  030 — JOURNAL D'ERREURS PERSISTANT ET EXÉCUTIONS D'AUDIT
-- ============================================================================
--
--  IDEMPOTENTE : peut être rejouée sans effet de bord.
--  À JOUER APRÈS : 029-correctif-rls-catalogue.sql
--
--  ----------------------------------------------------------------------------
--  1. POURQUOI UN INDEX UNIQUE SUR `bugs_plateforme.empreinte`
--  ----------------------------------------------------------------------------
--  `signalerBug` écrit depuis toujours avec `ON CONFLICT (empreinte) DO UPDATE`.
--  Cette clause EXIGE une contrainte d'unicité sur la colonne : sans elle,
--  PostgreSQL répond « there is no unique or exclusion constraint matching the
--  ON CONFLICT specification » et l'insertion échoue.
--
--  Le contrôleur rattrape cette erreur et répond 202 « signalement non
--  enregistré » — silencieusement, en apparence normalement. Autrement dit :
--  si l'index n'existe pas, le centre de bugs reste vide en permanence et
--  personne ne s'en aperçoit, parce que la seule trace est un `console.error`
--  côté serveur. C'est le pire mode de défaillance possible pour un outil de
--  diagnostic.
--
--  L'index est créé ici, explicitement, plutôt que supposé.
--
--  ----------------------------------------------------------------------------
--  2. POURQUOI DEUX TABLES D'AUDIT PLUTÔT QUE DES LIGNES DANS `bugs_plateforme`
--  ----------------------------------------------------------------------------
--  Une exception de production et un avertissement d'analyse statique ne se
--  traitent pas de la même façon et ne se comparent pas :
--
--    · un bug a une école, un utilisateur, un navigateur, un moment ;
--    · une anomalie d'audit a un fichier, une ligne, un commit, et aucune école.
--
--  Les mélanger dans une table unique aurait donné une colonne `page` remplie
--  de chemins de fichiers, une colonne `ecole_id` toujours nulle, et un centre
--  de bugs où « 340 anomalies » ne dirait plus si la plateforme va mal ou si
--  quelqu'un a lancé un audit. Le Super Admin doit pouvoir filtrer par origine
--  sans ambiguïté : deux tables, une relation, et chacune garde son sens.
--
--  Le REGROUPEMENT et la RÉOUVERTURE, en revanche, suivent la même règle que
--  les bugs : une anomalie porte une empreinte, compte ses occurrences, et
--  rouvre si elle réapparaît après avoir été corrigée.
-- ============================================================================

BEGIN;

-- ============================================================================
--  1. UNICITÉ DE L'EMPREINTE DE BUG
-- ============================================================================

-- Dédoublonnage préalable : si des lignes partagent déjà une empreinte (base
-- où l'index n'a jamais existé), on conserve la plus ancienne et on lui
-- reporte la somme des occurrences ainsi que la dernière date observée.
-- Supprimer sans reporter ferait perdre le compteur, qui est l'information la
-- plus utile de la table.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
     WHERE schemaname = 'public' AND indexname = 'bugs_plateforme_empreinte_key'
  ) THEN
    WITH doublons AS (
      SELECT empreinte,
             min(premiere_occurrence)      AS premiere,
             max(derniere_occurrence)      AS derniere,
             sum(occurrences)::int         AS total,
             (array_agg(id ORDER BY premiere_occurrence))[1] AS garde
        FROM bugs_plateforme
       GROUP BY empreinte
      HAVING count(*) > 1
    )
    UPDATE bugs_plateforme b
       SET occurrences         = d.total,
           premiere_occurrence = d.premiere,
           derniere_occurrence = d.derniere
      FROM doublons d
     WHERE b.id = d.garde;

    DELETE FROM bugs_commentaires c
     USING bugs_plateforme b
     WHERE c.bug_id = b.id
       AND b.id <> (SELECT (array_agg(x.id ORDER BY x.premiere_occurrence))[1]
                      FROM bugs_plateforme x WHERE x.empreinte = b.empreinte);

    DELETE FROM bugs_plateforme b
     WHERE b.id <> (SELECT (array_agg(x.id ORDER BY x.premiere_occurrence))[1]
                      FROM bugs_plateforme x WHERE x.empreinte = b.empreinte);
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS bugs_plateforme_empreinte_key
  ON bugs_plateforme (empreinte);

-- Index de consultation du centre de bugs : le tri par défaut est
-- « les plus graves d'abord, puis les plus récents ».
CREATE INDEX IF NOT EXISTS bugs_plateforme_tri_idx
  ON bugs_plateforme (statut, gravite, derniere_occurrence DESC);

CREATE INDEX IF NOT EXISTS bugs_plateforme_origine_idx
  ON bugs_plateforme (origine, derniere_occurrence DESC);

-- ============================================================================
--  2. EXÉCUTIONS D'AUDIT
-- ============================================================================

CREATE TABLE IF NOT EXISTS audit_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Type d'audit : 'frontend', 'responsive', 'mobile', 'sql', 'contrat_api',
  -- 'generateur', ou tout autre outil ajouté plus tard. Volontairement NON
  -- contraint par une énumération : ajouter un audit ne doit pas exiger une
  -- migration, sans quoi personne n'en ajoutera.
  type_audit      text NOT NULL,

  depot           text,                 -- 'Scolaire-HTML-main' | 'scolaire-saas-backend-main'
  commit_sha      text,                 -- version exacte analysée
  branche         text,

  demarre_at      timestamp with time zone NOT NULL DEFAULT now(),
  termine_at      timestamp with time zone,

  -- TROIS statuts, et la distinction entre les deux derniers est le point
  -- central de tout ce dispositif :
  --   'reussi'          l'audit a tourné et n'a rien trouvé
  --   'anomalies'       l'audit a tourné et a trouvé des problèmes PRODUIT
  --   'echec_technique' l'audit n'a pas pu tourner (outil absent, chemin
  --                     introuvable, zéro fichier analysé)
  --
  -- Confondre les deux derniers est exactement ce qui produisait des faux
  -- succès : « 0 fichier HTML analysé — aucun problème détecté ».
  statut          text NOT NULL DEFAULT 'reussi'
                  CHECK (statut = ANY (ARRAY['reussi','anomalies','echec_technique'])),

  -- Zéro fichier examiné avec un statut 'reussi' est interdit par contrainte,
  -- et pas seulement par convention dans les scripts. Un outil mal installé
  -- ne pourra donc jamais se déclarer conforme, même si son code est modifié.
  nb_fichiers     integer NOT NULL DEFAULT 0 CHECK (nb_fichiers >= 0),
  nb_anomalies    integer NOT NULL DEFAULT 0 CHECK (nb_anomalies >= 0),

  message         text,                 -- cause de l'échec technique, le cas échéant
  declenche_par   text NOT NULL DEFAULT 'ci'
                  CHECK (declenche_par = ANY (ARRAY['ci','manuel'])),
  metadata        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamp with time zone NOT NULL DEFAULT now(),

  CONSTRAINT audit_runs_zero_fichier_non_reussi
    CHECK (statut <> 'reussi' OR nb_fichiers > 0),
  CONSTRAINT audit_runs_anomalies_coherentes
    CHECK (statut <> 'anomalies' OR nb_anomalies > 0)
);

CREATE INDEX IF NOT EXISTS audit_runs_type_idx  ON audit_runs (type_audit, demarre_at DESC);
CREATE INDEX IF NOT EXISTS audit_runs_statut_idx ON audit_runs (statut, demarre_at DESC);

-- ============================================================================
--  3. ANOMALIES RELEVÉES
-- ============================================================================

CREATE TABLE IF NOT EXISTS audit_findings (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id        uuid NOT NULL REFERENCES audit_runs(id) ON DELETE CASCADE,

  type_audit    text NOT NULL,          -- recopié : permet de filtrer sans jointure
  fichier       text NOT NULL,
  ligne         integer CHECK (ligne IS NULL OR ligne >= 0),

  gravite       text NOT NULL DEFAULT 'moyenne'
                CHECK (gravite = ANY (ARRAY['info','faible','moyenne','importante','critique'])),
  code          text NOT NULL,          -- 'largeur_fixe', 'appel_api_sans_route', …
  message       text NOT NULL,

  -- Empreinte de regroupement : fichier + code + message normalisé, SANS le
  -- numéro de ligne. Ajouter trois lignes en haut d'un fichier décale tout ce
  -- qui suit ; si la ligne entrait dans l'empreinte, chaque commit rouvrirait
  -- l'intégralité des anomalies du dépôt comme si elles étaient nouvelles.
  empreinte     text NOT NULL,

  statut        text NOT NULL DEFAULT 'ouverte'
                CHECK (statut = ANY (ARRAY['ouverte','corrigee','ignoree'])),
  occurrences   integer NOT NULL DEFAULT 1 CHECK (occurrences >= 1),
  premiere_vue  timestamp with time zone NOT NULL DEFAULT now(),
  derniere_vue  timestamp with time zone NOT NULL DEFAULT now(),

  -- Justification obligatoire côté application pour passer à 'ignoree' :
  -- « ne pas masquer une anomalie en l'ajoutant à une liste d'exceptions ».
  motif_ignore  text,
  traite_par    uuid REFERENCES utilisateurs(id),
  traite_at     timestamp with time zone,

  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at    timestamp with time zone NOT NULL DEFAULT now()
);

-- Une anomalie identique ne crée pas de ligne : elle incrémente un compteur.
CREATE UNIQUE INDEX IF NOT EXISTS audit_findings_empreinte_key
  ON audit_findings (empreinte);

CREATE INDEX IF NOT EXISTS audit_findings_run_idx     ON audit_findings (run_id);
CREATE INDEX IF NOT EXISTS audit_findings_statut_idx  ON audit_findings (statut, gravite, derniere_vue DESC);
CREATE INDEX IF NOT EXISTS audit_findings_fichier_idx ON audit_findings (fichier);

-- ============================================================================
--  4. SÉCURITÉ — ISOLATION ET LECTURE SEULE POUR LES ÉCOLES
-- ============================================================================
--
--  Ces deux tables ne portent AUCUNE donnée d'école : ni `ecole_id`, ni
--  contenu pédagogique. Elles décrivent le CODE de la plateforme.
--
--  La politique RLS est donc la plus simple possible et la plus stricte :
--  personne d'autre que le Super Admin ne les voit. Une école n'a aucune
--  raison de savoir combien d'anomalies traînent dans le dépôt, et un
--  directeur curieux ne doit pas pouvoir cartographier les faiblesses connues
--  du produit.
--
--  ATTENTION AU NOM DU PARAMÈTRE : c'est `app.is_superadmin`, en un seul mot,
--  tel que `config/db.js` le pose (`SET LOCAL app.is_superadmin = 'true'`).
--  Écrit `app.is_super_admin`, `current_setting` renvoie NULL sans lever
--  d'erreur, la politique est donc toujours fausse, et les deux tables
--  deviennent invisibles À TOUT LE MONDE — Super Admin compris. L'ingestion
--  d'audits répondrait alors « 0 anomalie » de façon parfaitement crédible.
-- ============================================================================

ALTER TABLE audit_runs     ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_runs     FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_findings FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS audit_runs_super_admin ON audit_runs;
CREATE POLICY audit_runs_super_admin ON audit_runs
  USING (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true');

DROP POLICY IF EXISTS audit_findings_super_admin ON audit_findings;
CREATE POLICY audit_findings_super_admin ON audit_findings
  USING (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true')
  WITH CHECK (COALESCE(current_setting('app.is_superadmin', true), 'false') = 'true');

COMMIT;

-- ============================================================================
--  APRÈS EXÉCUTION — CONTRÔLE MANUEL SUGGÉRÉ
-- ============================================================================
--
--    SELECT indexname FROM pg_indexes
--     WHERE tablename = 'bugs_plateforme' AND indexname LIKE '%empreinte%';
--    -- doit renvoyer bugs_plateforme_empreinte_key
--
--    INSERT INTO audit_runs (type_audit, statut, nb_fichiers) VALUES ('test','reussi',0);
--    -- doit ÉCHOUER : audit_runs_zero_fichier_non_reussi
-- ============================================================================
