const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/abonnements.controller');
const { initierPaiementMobileMoney } = require('../controllers/paiements.controller');

router.use(authMiddleware);

router.get('/courant', ctrl.courant);
router.post('/:abonnementId/confirmer-paiement', requireRole('super_admin'), ctrl.confirmerPaiement);
router.post('/:abonnementId/payer-mobile-money', requireRole('directeur'), initierPaiementMobileMoney);

module.exports = router;
