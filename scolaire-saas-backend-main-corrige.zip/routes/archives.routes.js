const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/archives.controller');
const ctrlImpression = require('../controllers/archives-impression.controller');

router.use(authMiddleware);

// Les archives servent surtout à délivrer des duplicatas et des attestations :
// la direction et le secrétariat y ont accès, personne d'autre.
const CONSULTATION = requireRole('directeur', 'prefet', 'secretaire');

router.get('/annees', CONSULTATION, ctrl.listerAnnees);
router.get('/annees/:anneeId/classes', CONSULTATION, ctrl.listerClasses);
router.get('/annees/:anneeId/classes/:classeId/periodes', CONSULTATION, ctrl.listerPeriodes);
router.get('/annees/:anneeId/classes/:classeId/eleves', CONSULTATION, ctrl.listerEleves);
router.get('/annees/:anneeId/eleves/:eleveId', CONSULTATION, ctrl.dossierEleve);

// Duplicatas. Ces routes n'écrivent rien : elles restituent les bulletins figés
// à la clôture. Elles refusent les années non clôturées, pour ne pas devenir un
// contournement du cantonnement à l'année active.
router.get(
  '/annees/:anneeId/classes/:classeId/bulletins/imprimer',
  CONSULTATION, ctrlImpression.imprimerBulletinsPeriode
);
router.get(
  '/annees/:anneeId/classes/:classeId/bulletin-annuel/imprimer',
  CONSULTATION, ctrlImpression.imprimerBulletinAnnuel
);

router.get('/export/annee/:anneeId', CONSULTATION, ctrl.exporterAnnee);

// Anonymisation des candidats non admis : décision de la direction seule.
router.post('/purger-candidats', requireRole('directeur', 'prefet'), ctrl.purgerCandidats);
router.get('/export/classe/:anneeId/:classeId', CONSULTATION, ctrl.exporterClasse);

module.exports = router;
