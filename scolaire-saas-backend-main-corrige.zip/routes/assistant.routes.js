const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/assistant.controller');

router.use(authMiddleware);

// Ouvert à TOUS les rôles authentifiés, sans requireRole.
// Ce qui rend cette ouverture possible : l'assistant n'a accès à aucune donnée
// de l'école. Il explique le logiciel, il ne le consulte pas. Les restrictions
// réelles sont dans le contrôleur — cadrage par rôle, quota, fréquence.
router.post('/question', ctrl.question);

// Le manuel de procédure du rôle. Toujours disponible, y compris pour les
// écoles dont l'offre n'inclut pas l'assistant.
router.get('/manuel', ctrl.manuel);

// L'état d'installation révèle indirectement la taille et la maturité de
// l'école : il reste à ceux qui la configurent.
router.get('/etat-installation', requireRole('directeur', 'prefet', 'super_admin'), ctrl.etatInstallation);

/* ---------------------------------------------------------------------------
   ONBOARDING

   POURQUOI CES ROUTES SONT OUVERTES À TOUS, ALORS QUE `etat-installation`
   NE L'EST PAS
   ---------------------------------------------------------------------------
   La restriction posée sur `etat-installation` est fondée : sa réponse liste
   les quatorze étapes de configuration de l'établissement, et cette liste dit
   indirectement où en est l'école.

   `GET /onboarding` ne renvoie pas cette liste. Il renvoie le parcours DE LA
   PERSONNE : un professeur reçoit ses cinq étapes de découverte, aucune
   information sur l'installation, aucun compteur. Le contrôleur retire
   explicitement les alertes et les compteurs pour qui n'est ni directeur ni
   préfet — c'est là, et non dans le middleware, que la distinction peut se
   faire, puisqu'elle dépend du CONTENU de la réponse et non du chemin.

   Poser un `requireRole` ici reviendrait à priver d'accompagnement exactement
   les rôles qui en ont le plus besoin : ceux qui n'ont pas configuré la
   plateforme et la découvrent le jour de la rentrée.
   --------------------------------------------------------------------------- */

// L'état complet du parcours + le mini-tutoriel de l'écran courant.
router.get('/onboarding', ctrl.etatOnboarding);

// Enregistrement de la progression. Aucune action ne permet de déclarer une
// étape de configuration « terminée » : cela reste décidé par la base.
router.patch('/onboarding', ctrl.majOnboarding);

// L'IA en copilote, avec le contexte du parcours. Repli sur l'explication
// écrite de l'étape quand l'IA n'est pas disponible — jamais d'écran vide.
router.post('/aide-contextuelle', ctrl.aideContextuelle);

module.exports = router;
