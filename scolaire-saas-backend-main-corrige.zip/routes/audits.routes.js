/**
 * ARDOISE — INGESTION DES RÉSULTATS D'AUDIT
 * ===========================================================================
 *
 * PUBLIC AU SENS OÙ IL N'EXIGE PAS DE JETON UTILISATEUR — et fermé au sens où
 * il exige un secret technique que seule la CI (ou un développeur) possède.
 *
 * Monté AVANT le verrou d'authentification global de `server.js`, comme le
 * catalogue commercial et le webhook WhatsApp : la CI n'a pas de compte, et
 * lui en créer un reviendrait à faire vivre un utilisateur fantôme avec des
 * droits d'administration.
 *
 * CE QU'IL NE PEUT PAS FAIRE
 * --------------------------
 * Toucher une donnée métier. Le contrôleur n'écrit que dans `audit_runs` et
 * `audit_findings`, deux tables qui ne portent aucun `ecole_id` et aucun
 * contenu pédagogique. Un secret compromis permet de déposer de faux rapports
 * d'audit — un désagrément à corriger, pas une fuite de données.
 */

const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const ctrl = require('../controllers/audits.controller');

/* Limiteur serré. Une exécution d'audit publie UNE fois : douze par heure
   couvrent largement une CI qui relance quelques fois, et ferment la porte à
   qui voudrait remplir la table par force brute. */
const limiteur = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: "Trop de publications d'audit. Réessayez plus tard." }
});

// Corps borné à 2 Mo par `server.js`. Un rapport d'audit qui dépasserait cette
// taille signale un outil déréglé, pas un dépôt en mauvais état.
router.post('/executions', limiteur, ctrl.publierExecution);

module.exports = router;
