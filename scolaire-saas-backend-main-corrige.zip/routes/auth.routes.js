const express = require('express');
const router = express.Router();
const { limiteurConnexion } = require('../middleware/rate-limit.middleware');
const { login, refresh, logout, forgotPassword, resetPassword } = require('../controllers/auth.controller');

router.post('/login', limiteurConnexion, login);
router.post('/refresh', refresh);
router.post('/logout', logout);
// Même limiteur que le login : ces deux routes sont publiques et sensibles
// (énumération d'emails, brute-force de token), donc elles méritent la même protection.
router.post('/forgot-password', limiteurConnexion, forgotPassword);
router.post('/reset-password', limiteurConnexion, resetPassword);

module.exports = router;
