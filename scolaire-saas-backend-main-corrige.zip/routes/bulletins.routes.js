const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/bulletins.controller');
const ctrlAnnuel = require('../controllers/bulletin-annuel.controller');
const ctrlSemestre = require('../controllers/bulletin-semestre.controller');
const { autoriserGenerationBulletinsTitulaire } = require('../middleware/bulletins-permission.middleware');

router.use(authMiddleware);

router.patch('/:eleveId', requireRole('titulaire', 'directeur', 'prefet'), ctrl.mettreAJourAppreciations);
router.get('/:eleveId/detail', requireRole('titulaire', 'directeur', 'prefet'), ctrl.obtenirDetailEleve);
router.post('/:eleveId/signer', requireRole('titulaire', 'directeur', 'prefet'), ctrl.signer);
router.post('/classe/:classeId/signer-tout', requireRole('titulaire', 'directeur', 'prefet'), ctrl.signerToutLaClasse);
router.get(
  '/classe/:classeId/liste',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'),
  ctrl.listerBulletinsClasse
);
// Contrôle AVANT impression : avertit sans jamais bloquer. Ouvert aux mêmes
// rôles que l'impression — celui qui imprime doit savoir ce qui manque.
router.get(
  '/classe/:classeId/verification',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'),
  ctrl.verifierAvantImpression
);

router.get(
  '/classe/:classeId/imprimer',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'), autoriserGenerationBulletinsTitulaire,
  ctrl.genererPdfClasse
);

// Bulletin annuel (modèle indépendant, agrégation automatique des périodes)
router.get(
  '/annuel/recapitulatif',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'),
  ctrlAnnuel.recapitulatif
);
router.get(
  '/annuel/classe/:classeId/imprimer',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'), autoriserGenerationBulletinsTitulaire,
  ctrlAnnuel.genererPdfAnnuelClasse
);

// Bulletin de semestre (agrégation automatique de 2 périodes + 1 examen)
router.get(
  '/semestre/recapitulatif',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'),
  ctrlSemestre.recapitulatif
);
router.get(
  '/semestre/classe/:classeId/imprimer',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'), autoriserGenerationBulletinsTitulaire,
  ctrlSemestre.genererPdfSemestreClasse
);

module.exports = router;
