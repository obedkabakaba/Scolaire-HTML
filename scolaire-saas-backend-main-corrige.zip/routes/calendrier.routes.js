const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/calendrier.controller');

router.use(authMiddleware);

// Les routes LITTÉRALES d'abord : déclarées après '/:id', un chemin comme
// '/jours-speciaux' serait capturé comme un identifiant et ne répondrait jamais.
router.get('/mois', ctrl.vueMensuelle);
router.get('/jour', ctrl.verifierJour);
router.get('/periode-courante', ctrl.obtenirPeriodeCourante);

// Jours non ouvrés : consultation ouverte à toute l'école (un professeur doit
// pouvoir vérifier s'il y a cours), création réservée à la direction.
router.get('/jours-speciaux', ctrl.listerJoursSpeciaux);
router.post('/jours-speciaux', requireRole('directeur', 'prefet'), ctrl.creerJourSpecial);
router.delete('/jours-speciaux/:id', requireRole('directeur', 'prefet'), ctrl.supprimerJourSpecial);

router.get('/', ctrl.lister); // tout le monde dans l'école peut consulter
router.post('/', requireRole('directeur', 'prefet'), ctrl.creer);
router.patch('/:id', requireRole('directeur', 'prefet'), ctrl.modifier);
router.delete('/:id', requireRole('directeur', 'prefet'), ctrl.supprimer);

module.exports = router;
