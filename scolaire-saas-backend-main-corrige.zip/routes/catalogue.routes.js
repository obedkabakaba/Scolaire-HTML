const express = require('express');
const rateLimit = require('express-rate-limit');
const router = express.Router();
const ctrl = require('../controllers/catalogue.controller');

/*
 * ATTENTION — Aucune authentification sur ces routes, volontairement.
 * Elles servent le site public. Trois d'entre elles sont en lecture seule sur
 * un catalogue commercial ; la quatrième écrit une demande de rappel.
 *
 * Toute route ajoutée ici doit être limitée en débit et ne renvoyer que des
 * informations déjà destinées à être publiées.
 */

/** Lecture du catalogue : permissif, c'est la page d'accueil du site. */
const limiteurLecture = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de requêtes. Réessayez dans quelques minutes.' }
});

/**
 * Écriture : 5 demandes par IP et par heure.
 *
 * Un formulaire public sans plafond se remplit de spam en une nuit, et le
 * commercial finit par cesser de lire une file qui ne contient plus rien de
 * vrai. Cinq est large pour un humain, étroit pour un robot.
 */
const limiteurDemande = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de demandes envoyées depuis cet appareil. Réessayez plus tard.' }
});

router.get('/offres', limiteurLecture, ctrl.offres);
router.get('/services', limiteurLecture, ctrl.services);
router.get('/estimation', limiteurLecture, ctrl.estimation);
router.post('/demande-accompagnement', limiteurDemande, ctrl.demandeAccompagnement);

module.exports = router;
