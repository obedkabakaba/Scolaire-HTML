const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/cloture.controller');

router.use(authMiddleware);

// Clôturer une période fige le travail de toute l'école : acte de direction.
// La reconduction annuelle, elle, reste sur POST /annees-scolaires/:id/reporter-structure
// (structure.routes.js) — elle existait avant et a été enrichie, pas dupliquée.
const DIRECTION = requireRole('directeur', 'prefet');

// L'état de clôture est consultable par tous ceux qui saisissent : un
// enseignant doit pouvoir voir ce qu'on attend de lui avant la fermeture.
router.get('/periodes/:id/etat-cloture',
  requireRole('directeur', 'prefet', 'titulaire', 'professeur', 'secretaire'),
  ctrl.etatCloture);

router.post('/periodes/:id/cloturer', DIRECTION, ctrl.cloturerPeriode);
router.post('/periodes/:id/rouvrir', DIRECTION, ctrl.rouvrirPeriode);

module.exports = router;
