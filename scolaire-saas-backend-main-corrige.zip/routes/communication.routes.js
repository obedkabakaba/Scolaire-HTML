const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/communication.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/*
 * Verrou d'offre — diffusion.
 *
 * ATTENTION : ce routeur ne doit PAS être verrouillé en entier.
 *
 * `/envoyer` sert DEUX usages que rien ne distingue dans l'URL :
 *   · un message interne entre membres du personnel — fonctionnalité de base,
 *     comprise dans les quatre offres ;
 *   · une diffusion aux parents, ou un envoi par courriel — c'est cela que
 *     `communication_masse` conditionne, et cela seul, parce que c'est cela
 *     qui a un coût d'envoi réel.
 *
 * Poser `router.use(exigeFonctionnalite('communication_masse'))` aurait coupé
 * la messagerie interne d'une école en Ascension, c'est-à-dire retiré une
 * fonctionnalité essentielle pour vendre l'offre supérieure — exactement ce
 * que la règle commerciale interdit.
 *
 * Le garde ci-dessous lit donc la requête avant de décider.
 */
const CIBLES_PARENTS = ['parents_classe', 'parents_ecole'];

function verrouDiffusion(req, res, next) {
  const corps = req.body || {};
  const type = corps.cible && String(corps.cible.type || '');
  const canaux = Array.isArray(corps.canaux) ? corps.canaux : [];

  const versParents = CIBLES_PARENTS.includes(type);
  const parCourriel = canaux.includes('email');

  // Message interne au personnel : toujours autorisé.
  if (!versParents && !parCourriel) return next();

  return exigeFonctionnalite('communication_masse')(req, res, next);
}


// Diffuser à toute une classe ou à toute l'école engage l'établissement :
// réservé à la direction et au secrétariat, qui assurent déjà cette fonction.
const DIFFUSION = requireRole('directeur', 'prefet', 'secretaire');

// Écrire à une personne précise n'engage pas l'établissement : c'est de la
// communication ordinaire entre collègues. Tout membre du personnel doit
// pouvoir le faire — un enseignant qui ne peut joindre un collègue qu'en
// diffusant à tout le corps enseignant n'écrit tout simplement pas.
// « charge_presences » manquait : ce rôle existe en base, il fait l'appel de
// toutes les classes, et il ne pouvait écrire à personne — pas même au
// titulaire dont il venait de relever quinze absents. Ajouté ici, c'est-à-dire
// au même titre que les autres membres du personnel.
const INTERNE = requireRole('directeur', 'prefet', 'secretaire', 'comptable',
                            'professeur', 'titulaire', 'directeur_discipline',
                            'charge_presences');

/* ---------------------------------------------------------------------------
   POURQUOI `/destinataires` N'EST PLUS RÉSERVÉ À LA DIFFUSION
   ---------------------------------------------------------------------------
   Cette route renvoie les GROUPES disponibles et leur taille. Elle était
   fermée à tous sauf à la direction, ce qui se défendait tant que seule la
   direction pouvait viser un groupe.

   Un titulaire peut désormais écrire aux parents de SA classe, et un
   professeur aux parents des classes où il enseigne. Il leur faut donc la
   liste des classes — mais uniquement les leurs. Le contrôleur s'en charge :
   il ne renvoie à un enseignant que les classes dont il a la charge, et ne
   lui renvoie aucun décompte par rôle. La distinction dépend du CONTENU de la
   réponse, pas du chemin : elle ne peut pas se faire dans un middleware.
   --------------------------------------------------------------------------- */
router.get('/destinataires', INTERNE, ctrl.destinataires);
router.get('/personnel', INTERNE, ctrl.personnel);
router.post('/envoyer', INTERNE, verrouDiffusion, ctrl.envoyer);
router.get('/historique', DIFFUSION, ctrl.historique);   // consultable : c'est l'historique de l'école, pas un envoi

module.exports = router;
