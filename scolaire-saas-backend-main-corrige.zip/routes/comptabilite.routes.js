const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/comptabilite.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/*
 * Verrou d'offre — comptabilité et paie.
 *
 * Posé APRÈS l'authentification et AVANT les contrôles de rôle, parce que
 * l'ordre des messages compte : à un comptable d'une école qui n'a pas
 * souscrit le module, on doit répondre « votre offre ne comprend pas la
 * comptabilité » et non « rôle insuffisant », qui serait faux et vexant.
 *
 * Deux drapeaux plutôt qu'un, alors que les deux modules ouvrent au même
 * palier : le jour où la paie devra être vendue séparément — ou incluse plus
 * tôt — la décision se prendra en base, pas dans ce fichier.
 */

// La comptabilité est le métier du comptable ; le directeur y a accès parce
// qu'il en répond. Le préfet et le secrétariat en sont exclus : la
// rémunération du personnel n'est pas une information de gestion pédagogique.
const COMPTA = requireRole('directeur', 'comptable');

// La paie est plus sensible encore : elle expose le salaire de chacun. Elle
// reste ouverte aux mêmes rôles, mais la distinction est posée ici pour que le
// jour où l'école voudra la restreindre davantage, il n'y ait qu'une ligne à
// changer.
const PAIE = requireRole('directeur', 'comptable');

router.get('/categories', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.listerCategories);
router.post('/categories', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.creerCategorie);
router.put('/categories/:id', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.modifierCategorie);

router.get('/mouvements', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.listerMouvements);
router.post('/mouvements', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.enregistrerMouvement);
router.put('/mouvements/:id', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.modifierMouvement);
router.delete('/mouvements/:id', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.supprimerMouvement);

router.get('/tresorerie', exigeFonctionnalite('comptabilite'), COMPTA, ctrl.tresorerie);

router.get('/contrats', exigeFonctionnalite('paie'), PAIE, ctrl.listerContrats);
router.post('/contrats', exigeFonctionnalite('paie'), PAIE, ctrl.creerContrat);
router.put('/contrats/:id', exigeFonctionnalite('paie'), PAIE, ctrl.modifierContrat);
router.post('/contrats/:id/cloturer', exigeFonctionnalite('paie'), PAIE, ctrl.cloturerContrat);

router.get('/paie', exigeFonctionnalite('paie'), PAIE, ctrl.listerPaie);
router.post('/paie/preparer', exigeFonctionnalite('paie'), PAIE, ctrl.preparerPaie);
router.put('/paie/:id', exigeFonctionnalite('paie'), PAIE, ctrl.modifierSalaire);
router.post('/paie/:id/payer', exigeFonctionnalite('paie'), PAIE, ctrl.payerSalaire);
router.post('/paie/:id/annuler-paiement', exigeFonctionnalite('paie'), PAIE, ctrl.annulerPaiementSalaire);

module.exports = router;
