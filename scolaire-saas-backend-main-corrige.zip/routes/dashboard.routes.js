const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/dashboard.controller');

router.use(authMiddleware);

router.get('/directeur', requireRole('directeur', 'prefet'), ctrl.directeur);

module.exports = router;
