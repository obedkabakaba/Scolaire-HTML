const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/discipline.controller');
const reglement = require('../controllers/discipline-reglement.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');
const multer = require('multer');

// En mémoire : le règlement est analysé puis stocké en base sous forme de
// texte. Aucun intérêt à écrire le fichier d'origine sur le disque d'un
// serveur Render, dont le système de fichiers est éphémère.
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

router.use(authMiddleware);

/*
 * Verrou d'offre — discipline.
 *
 * Le module entier. Il est autonome : le capital conduite qu'il calcule
 * alimente le bulletin, mais une école sans discipline garde une conduite
 * saisie à la main sur le bulletin, comme avant. Rien du cœur du métier n'en
 * dépend.
 *
 * La LECTURE du règlement par l'IA porte en plus son propre drapeau : la
 * discipline peut exister sans elle, et la répartition des capacités IA se
 * décide en base, pas ici.
 */
router.use(exigeFonctionnalite('discipline'));

// `directeur_discipline` existe dans l'ENUM des rôles depuis la migration 008
// mais n'apparaissait dans AUCUNE route : nommer un directeur de discipline
// dans l'école revenait à créer un compte sans accès à la discipline.
//
// Il est ajouté partout où le préfet figure, à une exception près : il ne
// touche pas au capital de conduite de l'école (PUT /parametres). Fixer le
// barème est un acte de politique d'établissement, pas d'application ; c'est
// le directeur qui en répond. Si l'école ne nomme personne à ce poste, tout
// reste chez le directeur — d'où sa présence dans chaque liste.
const AUTORITE = requireRole('directeur', 'prefet', 'directeur_discipline');
const REGLAGES = requireRole('directeur', 'prefet');
const SIGNALEMENT = requireRole('directeur', 'prefet', 'directeur_discipline', 'titulaire');
const CONSULTATION = requireRole('directeur', 'prefet', 'directeur_discipline', 'secretaire', 'titulaire');

router.get('/parametres', CONSULTATION, ctrl.parametres);
router.put('/parametres', REGLAGES, ctrl.enregistrerParametres);

router.get('/resume', AUTORITE, ctrl.resume);
router.get('/conduite', CONSULTATION, ctrl.conduiteClasse);
router.post('/conduite/appliquer', AUTORITE, ctrl.appliquerConduite);

router.get('/incidents', CONSULTATION, ctrl.listerIncidents);
router.post('/incidents', SIGNALEMENT, ctrl.signalerIncident);
router.delete('/incidents/:id', AUTORITE, ctrl.supprimerIncident);

// Historique complet d'un élève. Ouvert au titulaire, mais le contrôleur
// restreint alors la portée à sa classe et à l'année en cours : la route dit
// qui peut frapper à la porte, le contrôleur dit ce qu'il y a derrière.
router.get('/eleves/:eleveId/historique', CONSULTATION, ctrl.historiqueEleve);

// ---------------------------------------------------------------------------
//  Règlement intérieur et barème
// ---------------------------------------------------------------------------
// Consultation ouverte à tous ceux qui saisissent : un titulaire doit pouvoir
// lire le barème sur lequel il sanctionne. La modification est réservée au
// directeur — importer un règlement redéfinit les sanctions de toute l'école,
// ce n'est pas une opération de gestion courante.
const REGLEMENT_LECTURE = requireRole('directeur', 'prefet', 'directeur_discipline', 'secretaire', 'titulaire');
const REGLEMENT_ECRITURE = requireRole('directeur');

router.get('/reglement', REGLEMENT_LECTURE, reglement.etatReglement);
router.post('/reglement/importer', exigeFonctionnalite('ia_reglement_discipline'), REGLEMENT_ECRITURE, upload.single('fichier'), reglement.importerReglement);
router.post('/reglement/generer', exigeFonctionnalite('ia_reglement_discipline'), REGLEMENT_ECRITURE, reglement.genererReglement);
router.post('/reglement/:id/valider', REGLEMENT_ECRITURE, reglement.validerReglement);
router.delete('/reglement/:id', REGLEMENT_ECRITURE, reglement.abandonnerProposition);

router.put('/regles/:id', REGLEMENT_ECRITURE, reglement.modifierRegle);

module.exports = router;
