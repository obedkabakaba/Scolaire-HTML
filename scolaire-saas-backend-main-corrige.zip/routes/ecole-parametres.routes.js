const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/ecole-parametres.controller');

router.use(authMiddleware);

router.get('/moi', ctrl.obtenirEcoleCourante);
router.patch('/moi', requireRole('directeur', 'prefet'), ctrl.modifierEcoleCourante);
router.get('/titulaires', requireRole('directeur', 'prefet'), ctrl.listerTitulairesAvecAutorisation);
router.put('/titulaires-autorises', requireRole('directeur', 'prefet'), ctrl.definirTitulairesAutorises);

module.exports = router;
