const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/ecoles.controller');

router.use(authMiddleware, requireRole('super_admin'));

// Routes statiques déclarées AVANT /:id pour éviter tout conflit de routage
router.get('/plans/liste', ctrl.listerPlans);
router.get('/stats/globales', ctrl.statistiquesGlobales);

router.get('/', ctrl.listerEcoles);
router.post('/', ctrl.creerEcole);
router.get('/:id', ctrl.obtenirEcole);
router.patch('/:id', ctrl.modifierEcole);
router.patch('/:id/abonnement', ctrl.modifierAbonnementEcole);
router.post('/:id/reset-directeur-password', ctrl.reinitialiserMotDePasseDirecteur);

module.exports = router;
