const express = require('express');
const multer = require('multer');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/eleves.controller');
const { verifierPlafond } = require('../middleware/offre.middleware');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } }); // 10 Mo max

router.use(authMiddleware);

const PEUT_GERER = requireRole('directeur', 'prefet', 'secretaire');

router.get('/', requireRole('directeur', 'prefet', 'secretaire', 'titulaire'), ctrl.lister);

// Départ d'un élève, avec son motif. Réservé à ceux qui tiennent le registre :
// c'est un acte administratif, pas pédagogique.
router.get('/motifs-sortie', PEUT_GERER, ctrl.listerMotifsSortie);
router.post('/:id/sortie', PEUT_GERER, ctrl.enregistrerSortie);

// Vue transversale d'un élève : résultats, présences, discipline, frais.
// Ouverte au titulaire, qui suit ses élèves au quotidien. Pas au professeur de
// matière : il n'a pas à connaître la situation financière d'une famille.
router.get('/:id/parcours',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'),
  require('../controllers/parcours.controller').parcoursEleve);
router.get('/export', PEUT_GERER, ctrl.exporter);
router.get('/:id/historique', PEUT_GERER, ctrl.historique);
// Plafond d'élèves de l'offre.
//
// Posé sur la création et sur l'import, et NULLE PART AILLEURS : modifier un
// élève, le faire sortir ou consulter la liste ne doit jamais buter sur un
// plafond. Une école qui a dépassé son quota — reprise de données, changement
// d'offre en cours — garde l'usage complet de ce qu'elle a déjà saisi. Le
// contrôle porte sur ce qu'on AJOUTE, jamais sur ce qui existe.
router.post('/', PEUT_GERER, verifierPlafond('max_eleves'), ctrl.creer);

// L'import est compté pour ce qu'il vaut réellement. Un contrôle « une unité »
// aurait laissé passer un fichier de 400 élèves sur un plafond de 250 : c'est
// exactement le cas où le garde-fou compte, et le seul où il aurait été muet.
// Le fichier n'étant pas encore analysé, on se fie au nombre de lignes annoncé
// par le client s'il l'a transmis, et à 1 sinon — le contrôleur d'import
// vérifie de nouveau ligne par ligne.
router.post('/import', PEUT_GERER, upload.single('fichier'),
  verifierPlafond('max_eleves', (req) => Number(req.body && req.body.nb_lignes) || 1),
  ctrl.importer);
router.patch('/:id', PEUT_GERER, ctrl.modifier);
router.delete('/:id', requireRole('directeur'), ctrl.supprimer);

module.exports = router;
