const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/emploi-du-temps.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

// Bâtir l'emploi du temps relève de la direction ; tout le monde peut le consulter.
const PEUT_MODIFIER = requireRole('directeur', 'prefet');
const PEUT_CONSULTER = requireRole('directeur', 'prefet', 'secretaire', 'titulaire', 'professeur');

/* ---------------------------------------------------------------------------
   VERROU D'OFFRE — ET POURQUOI IL N'EST PAS POSÉ SUR LE ROUTEUR ENTIER

   `emploi_du_temps` était vendu et verrouillé nulle part : c'est le premier
   échec du test de cohérence. La correction évidente aurait été
   `router.use(exigeFonctionnalite('emploi_du_temps'))`. Elle est fausse, et
   pour une raison qu'on ne voit qu'en production.

   `GET /mon-emploi` et `GET /aujourdhui` sont interrogés au CHARGEMENT de
   l'espace professeur et du tableau de bord, sur toutes les offres. Verrouiller
   le routeur entier leur ferait renvoyer 402 — et `ui.js` intercepte tous les
   402 pour ouvrir une modale « votre abonnement ne comprend pas l'emploi du
   temps ». Une école Ascension aurait vu cette fenêtre s'ouvrir seule à chaque
   ouverture de page, sans avoir rien demandé.

   Ces deux routes renvoient naturellement une grille vide quand l'école n'a
   aucune séance : elles restent donc ouvertes. Tout ce qui CONSTRUIT ou
   CONSULTE la grille d'établissement est verrouillé — c'est là qu'est la
   fonctionnalité vendue, et l'accès direct par URL y bute aussi sûrement que
   le menu masqué.
   --------------------------------------------------------------------------- */
const OFFRE_EDT = exigeFonctionnalite('emploi_du_temps');

router.get('/configuration', PEUT_CONSULTER, OFFRE_EDT, ctrl.configuration);
router.put('/configuration', PEUT_MODIFIER, OFFRE_EDT, ctrl.enregistrerConfiguration);

// Ouvertes dans toutes les offres : lecture PERSONNELLE, vide par nature quand
// l'école n'a pas de grille. Voir le bloc ci-dessus.
router.get('/mon-emploi', PEUT_CONSULTER, ctrl.monEmploi);
router.get('/aujourdhui', PEUT_CONSULTER, ctrl.aujourdhui);

router.get('/classe/:classeId', PEUT_CONSULTER, OFFRE_EDT, ctrl.emploiDeClasse);

router.post('/seance', PEUT_MODIFIER, OFFRE_EDT, ctrl.placerSeance);
router.delete('/seance', PEUT_MODIFIER, OFFRE_EDT, ctrl.retirerSeance);

// Horaires exceptionnels (« le mercredi est écourté »). La consultation est
// ouverte à tous ceux qui lisent la grille : un professeur doit connaître
// l'horaire réel de son cours, pas seulement la direction qui l'a décidé.
router.get('/exceptions', PEUT_CONSULTER, OFFRE_EDT, ctrl.listerExceptions);
router.put('/exceptions', PEUT_MODIFIER, OFFRE_EDT, ctrl.definirException);
router.delete('/exceptions/:id', PEUT_MODIFIER, OFFRE_EDT, ctrl.supprimerException);

module.exports = router;
