const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/frais.controller');

// Le préfet est ajouté ici par cohérence : il accède déjà aux rapports
// financiers, et c'est lui qui signe les dérogations avec le directeur.
router.use(authMiddleware, requireRole('directeur', 'prefet', 'comptable', 'secretaire'));

router.get('/stats-globales', ctrl.statsGlobales);
router.get('/config', ctrl.listerConfig);
router.post('/config', requireRole('directeur', 'comptable'), ctrl.creerConfig);
router.delete('/config/:id', requireRole('directeur', 'comptable'), ctrl.supprimerConfig);

// Taux de change. La lecture est ouverte à tous ceux qui voient les montants
// (sinon impossible d'afficher un équivalent) ; la modification appartient au
// comptable, qui est celui qui fixe le taux de son école.
router.get('/taux-change', ctrl.lireTauxChange);
router.put('/taux-change', requireRole('directeur', 'comptable'), ctrl.definirTauxChange);

// Dettes des années antérieures : seule exception assumée à la règle du pivot.
// Une dette ne s'efface pas au changement d'année, et c'est le comptable qui la
// réclame — voir estExempteRestrictionAnnee dans utils/annee.utils.js.
router.get('/dettes-anterieures', requireRole('comptable'), ctrl.dettesAnterieures);

router.get('/eleves', ctrl.listerElevesAvecPaiements);
router.get('/eleves/:eleveId/paiements', ctrl.listerPaiementsEleve);
// Détail des frais dus, ligne par ligne : permet d'encaisser « le minerval »
// plutôt qu'« un montant ».
router.get('/eleves/:eleveId/frais-dus', ctrl.fraisDusEleve);
router.post('/paiements', requireRole('directeur', 'comptable'), ctrl.enregistrerPaiement);
router.delete('/paiements/:id', requireRole('directeur', 'comptable'), ctrl.supprimerPaiement);

// Reçus de paiement
router.get('/paiements/:paiementId/recu', requireRole('directeur', 'prefet', 'comptable', 'secretaire'), ctrl.imprimerRecu);

// Contrôle financier des bulletins
const controle = require('../controllers/controle-financier.controller');
router.get('/controle', requireRole('directeur', 'prefet', 'comptable'), controle.etatControle);
router.put('/controle', requireRole('directeur', 'prefet'), controle.enregistrerControle);
// La dérogation engage celui qui la signe : direction uniquement.
router.post('/derogation', requireRole('directeur', 'prefet'), controle.deroger);

module.exports = router;
