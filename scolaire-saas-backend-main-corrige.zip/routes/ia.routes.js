const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const ctrl = require('../controllers/ia.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } }); // 10 Mo max

router.use(authMiddleware);

// Chaque appel coûte de l'argent réel. Le quota mensuel protège la marge ;
// ce limiteur protège contre le clic répété et les scripts.
const limiteurIA = rateLimit({
  windowMs: 60 * 1000,
  max: 6,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de générations en peu de temps. Patientez une minute.' }
});

/*
 * Verrous d'offre — intelligence artificielle.
 *
 * AUCUN verrou global ici, et c'est une décision commerciale autant que
 * technique : l'IA d'assistance fait partie de l'expérience Ardoise dès la
 * première offre. `/quota`, `/appreciations`, `/question-eleve`,
 * `/conseil-classe`, `/redaction`, `/import/analyser` et `/assistant/question`
 * restent donc ouverts aux quatre offres.
 *
 * Ce qui monte en gamme, ce n'est pas l'accès : c'est le VOLUME — le quota
 * mensuel, lu par utils/ia.utils.js dans les limites du plan — et deux
 * capacités analytiques, verrouillées ci-dessous une par une.
 *
 * Toute route ajoutée ici est ouverte par défaut. C'est le bon défaut : une
 * fonction d'assistance oubliée derrière un verrou se remarque bien plus tard
 * qu'une fonction d'analyse accessible à tort.
 */
const ANALYSE = exigeFonctionnalite('ia_analyse_donnees');

const DIRECTION = requireRole('directeur', 'prefet');
const REDACTION = requireRole('directeur', 'prefet', 'titulaire');

router.get('/quota', requireRole('directeur', 'prefet', 'titulaire', 'secretaire'), ctrl.quota);

router.get('/decrochage', limiteurIA, ANALYSE, DIRECTION, ctrl.decrochage);
router.get('/appreciations', limiteurIA, REDACTION, ctrl.appreciations);
router.post('/appreciations/appliquer', REDACTION, ctrl.appliquerAppreciations);

router.post('/question-eleve', limiteurIA, REDACTION, ctrl.questionEleve);
router.get('/conseil-classe', limiteurIA, REDACTION, ctrl.conseilClasse);
router.post('/redaction', limiteurIA, requireRole('directeur', 'prefet', 'secretaire'), ctrl.redaction);

const GESTION = requireRole('directeur', 'prefet', 'secretaire');
router.post('/import/analyser', limiteurIA, GESTION, upload.single('fichier'), ctrl.analyserImport);
router.post('/import/appliquer', GESTION, upload.single('fichier'), ctrl.appliquerImport);
router.post('/archives/recherche', limiteurIA, ANALYSE, GESTION, ctrl.rechercheArchives);

// Assistant d'aide — questions sur la plateforme (accessible à tous les rôles connectés).
router.post('/assistant/question', limiteurIA, requireRole('directeur', 'prefet', 'secretaire', 'professeur', 'titulaire', 'comptable'), ctrl.questionPlateforme);

// Registre des recherches : outil de diagnostic, réservé au Super Administrateur.
router.get('/journal', requireRole('super_admin'), ctrl.journal);

module.exports = router;
