/**
 * ARDOISE — SIGNALEMENT D'INCIDENT PAR UN UTILISATEUR ORDINAIRE
 * ===========================================================================
 *
 * LA CONTRADICTION CORRIGÉE
 * -------------------------
 * `super-admin.routes.js` déclare, en tête de fichier :
 *
 *     router.use(authMiddleware, superAdminSeul);
 *
 * Toutes les routes qui suivent sont donc réservées au Super Admin — y compris
 * `POST /super-admin/bugs/signaler`, dont le commentaire affirmait pourtant
 * qu'elle était « aussi utilisable par le front applicatif ». Elle ne l'était
 * pas : un directeur qui l'appelait recevait 403.
 *
 * Conséquence mesurable en production : les seules erreurs jamais enregistrées
 * étaient celles du Super Admin lui-même, seul écran à poser des capteurs
 * globaux. Un professeur devant un écran blanc ne laissait aucune trace.
 *
 * CE QUE CETTE ROUTE FAIT, ET CE QU'ELLE NE FAIT PAS
 * -------------------------------------------------
 * Elle ÉCRIT un signalement. Elle ne permet RIEN d'autre : pas de lecture du
 * centre de bugs, pas de liste, pas de statistique. Un directeur ne doit pas
 * apprendre, en signalant un incident, que trois autres écoles ont le même —
 * ni combien elles sont sur la plateforme.
 *
 * L'ÉCOLE VIENT DU JETON, TOUJOURS
 * --------------------------------
 * `signalerBug` acceptait `req.body.ecole_id`. N'importe quel utilisateur
 * pouvait donc déposer un incident au nom d'une autre école, et polluer son
 * dossier de supervision. Ici, `ecole_id` du corps est ignoré — pas rejeté,
 * ignoré : un client qui l'envoie par habitude ne doit pas être cassé, il doit
 * simplement ne pas être cru.
 */

const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');

const authMiddleware = require('../middleware/auth.middleware');
const journal = require('../utils/journal-erreurs.utils');

router.use(authMiddleware);

/* ---------------------------------------------------------------------------
   LIMITATION DE DÉBIT

   Deux limiteurs superposés, parce qu'ils protègent de deux choses
   différentes :

     · par UTILISATEUR — une page qui plante en boucle dans son propre
       gestionnaire d'erreur peut émettre des centaines de signalements par
       minute depuis un seul onglet ;
     · par IP — un dépôt massif volontaire.

   Le plafond est généreux : rater un signalement coûte moins cher que de
   laisser la table grossir sans borne. Le journal applique en plus sa propre
   garde par empreinte (voir `journal-erreurs.utils.js`).
   --------------------------------------------------------------------------- */
const limiteur = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  // Clé par utilisateur authentifié, avec repli sur l'IP.
  keyGenerator: (req) => (req.auth && req.auth.userId) || req.ip,
  message: { message: 'Trop de signalements en peu de temps.', enregistre: false }
});

/* Bornes de taille. Un signalement est un CONSTAT, pas une archive : au-delà,
   on tronque plutôt que de refuser — refuser ferait perdre l'information. */
const MAX_MESSAGE = 1000;
const MAX_STACK = 6000;

const GRAVITES = ['basse', 'moyenne', 'haute', 'critique'];

/**
 * POST /incidents/signaler
 *
 * body : {
 *   message, stack?, page?, chemin?, methode?, code_http?,
 *   navigateur?, systeme?, gravite?, correlation?, deploiement?, contexte?
 * }
 *
 * Réponse toujours 202 : le client n'a pas à savoir si l'écriture a eu lieu,
 * et ne doit surtout pas réessayer en boucle si elle a échoué.
 */
router.post('/signaler', limiteur, async (req, res) => {
  const corps = req.body || {};

  const message = String(corps.message || '').trim();
  if (!message) {
    return res.status(400).json({ message: 'Le message d\'erreur est requis.' });
  }

  const codeHttp = Number(corps.code_http);

  /* UN REFUS MÉTIER N'EST PAS UN BUG.

     Le capteur du navigateur voit passer tous les échecs réseau, y compris les
     401 de jeton expiré et les 402 d'offre insuffisante. Les enregistrer
     ferait deux dégâts : le centre de bugs se remplirait de bruit normal, et
     un directeur verrait sa simple invitation à changer d'offre comptabilisée
     comme un incident critique de la plateforme.

     Le filtre est appliqué ICI en plus du journal, pour répondre au client
     sans même engager d'écriture. */
  if (journal.estRefusAttendu(codeHttp)) {
    return res.status(202).json({
      enregistre: false,
      raison: 'refus_attendu',
      message: 'Réponse métier attendue : aucun incident enregistré.'
    });
  }

  const resultat = await journal.enregistrer({
    origine: 'frontend',

    // ---- Identité : DU JETON, jamais du corps ----
    // `corps.ecole_id` est délibérément absent de cette liste.
    ecoleId: (req.auth && (req.auth.ecoleId || req.auth.ecole_id)) || null,
    utilisateurId: (req.auth && req.auth.userId) || null,

    message: message.slice(0, MAX_MESSAGE),
    stack: corps.stack ? String(corps.stack).slice(0, MAX_STACK) : null,
    page: corps.page ? String(corps.page).slice(0, 200) : null,
    chemin: corps.chemin ? String(corps.chemin).slice(0, 300) : null,
    methode: corps.methode ? String(corps.methode).slice(0, 10) : null,
    codeHttp: Number.isFinite(codeHttp) ? codeHttp : null,

    // L'en-tête fait foi sur le navigateur : c'est la seule source que le
    // client ne peut pas se tromper en recopiant.
    navigateur: req.headers['user-agent'] || corps.navigateur || null,
    systeme: corps.systeme ? String(corps.systeme).slice(0, 120) : null,

    gravite: GRAVITES.includes(corps.gravite) ? corps.gravite : 'moyenne',

    metadata: {
      // Le rôle, pas l'identité : « ça plante chez les titulaires » est une
      // information de diagnostic ; le nom de la personne ne l'est pas.
      roles: (req.auth && req.auth.roles) || [],
      correlation: corps.correlation || req.correlationId || null,
      deploiement: corps.deploiement || null,
      // Contexte technique libre fourni par la page. Masqué et borné par le
      // journal : une page qui y glisserait un jeton par mégarde ne peut pas
      // le faire arriver en base.
      contexte: corps.contexte || null
    }
  });

  /* TOUJOURS 202, MÊME EN CAS D'ÉCHEC D'ÉCRITURE.

     Un signalement refusé ne doit jamais devenir un problème visible pour
     l'utilisateur : il est déjà en train d'en vivre un. Et un 500 renvoyé ici
     déclencherait le capteur du navigateur, qui signalerait l'échec du
     signalement — la boucle exacte qu'il faut éviter. */
  return res.status(202).json({
    enregistre: Boolean(resultat),
    occurrences: resultat ? resultat.occurrences : null
  });
});

module.exports = router;
