const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/inscriptions.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/* Verrou d'offre sur le routeur entier.

   ATTENTION à ne pas confondre deux gestes que le vocabulaire rapproche :
   INSCRIRE un élève dans l'école est essentiel et se fait par `/eleves`, qui
   n'est verrouillé par aucune offre et ne doit jamais l'être. Ce routeur-ci
   gère les SESSIONS D'ADMISSION — concours, épreuves, correction anonyme,
   classement des candidats — qui sont un module distinct et vendu comme tel.

   Aucune de ces routes n'est appelée depuis un autre écran : le verrou global
   ne peut donc pas produire de 402 intempestif. */
router.use(exigeFonctionnalite('concours_admission'));

// Le secrétariat organise les inscriptions ; la direction décide.
const SECRETARIAT = requireRole('directeur', 'prefet', 'secretaire');
const DIRECTION = requireRole('directeur', 'prefet');
// La correction est ouverte aux enseignants : le contrôleur vérifie ensuite
// que l'épreuve leur est bien confiée, et n'expose aucun nom de candidat.
//
// La direction reste dans cette liste, mais le contrôleur ne lui accorde plus
// de dérogation : elle ne peut SAISIR que si l'épreuve lui est attribuée, et ne
// peut CONSULTER les copies qu'après publication. La route dit qui peut frapper
// à la porte, le contrôleur dit ce qu'il y a derrière.
const CORRECTEUR = requireRole('directeur', 'prefet', 'professeur', 'titulaire');

router.get('/sessions', SECRETARIAT, ctrl.listerSessions);
router.post('/sessions', SECRETARIAT, ctrl.creerSession);
router.patch('/sessions/:id', SECRETARIAT, ctrl.modifierSession);

router.get('/sessions/:sessionId/epreuves', SECRETARIAT, ctrl.listerEpreuves);
router.post('/sessions/:sessionId/epreuves', SECRETARIAT, ctrl.creerEpreuve);
router.post('/epreuves/:epreuveId/correcteur', SECRETARIAT, ctrl.assignerCorrecteur);

router.get('/sessions/:sessionId/candidats', SECRETARIAT, ctrl.listerCandidats);
// Résultats du test, filtrables. Ouvert au secrétariat qui reçoit les familles
// et doit pouvoir répondre « votre enfant est 12ᵉ, premier sur liste d'attente ».
router.get('/sessions/:sessionId/resultats', SECRETARIAT, ctrl.resultatsSession);
router.post('/sessions/:sessionId/candidats', SECRETARIAT, ctrl.inscrireCandidat);

// Correction anonyme
router.get('/mes-corrections', CORRECTEUR, ctrl.mesCorrections);
router.get('/epreuves/:epreuveId/copies', CORRECTEUR, ctrl.copiesEpreuve);
router.post('/epreuves/:epreuveId/notes', CORRECTEUR, ctrl.enregistrerNotes);

// Décisions : réservées à la direction, et bornées par le contrôleur.
router.post('/sessions/:id/publier', DIRECTION, ctrl.publierSession);
router.post('/candidats/:id/decision', DIRECTION, ctrl.deciderCandidat);
router.post('/candidats/:id/desister', SECRETARIAT, ctrl.desisterCandidat);
router.post('/sessions/:id/convertir', SECRETARIAT, ctrl.convertirAdmis);

module.exports = router;
