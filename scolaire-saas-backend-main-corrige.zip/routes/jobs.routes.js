const express = require('express');
const router = express.Router();
const {
  executerJobAbonnements,
  executerJobCalendrier,
  executerJobEvenements,
  executerJobNotifications
} = require('../controllers/jobs.controller');
const { executerResetSuperAdmin } = require('../controllers/setup.controller');

// Pas de authMiddleware ici : protégé par le secret x-cron-secret (voir contrôleurs),
// pour être appelable directement par cron-job.org ou depuis une page web ponctuelle.
//
// FRÉQUENCES CONSEILLÉES
// ----------------------
//   /abonnements    1×/jour  (03 h)  — expirations et suspensions
//   /calendrier     1×/jour  (06 h)  — fins de période, notes non soumises
//   /evenements     1×/jour  (06 h)  — rappels J-7 / J-1 / jour même
//   /notifications  toutes les 5 min — filet de sécurité de la file d'e-mails
//
// Les trois tâches quotidiennes sont idempotentes (déduplication par
// `cle_unicite`) : les relancer après un timeout ne crée aucun doublon.
router.post('/abonnements', executerJobAbonnements);
router.post('/calendrier', executerJobCalendrier);
router.post('/evenements', executerJobEvenements);
router.post('/notifications', executerJobNotifications);
router.post('/reset-superadmin', executerResetSuperAdmin);

module.exports = router;
