const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/journal.controller');

// Le journal contient désormais la trace de toutes les actions de tous les
// utilisateurs : c'est une pièce sensible. L'accès reste volontairement
// restreint à la direction, qui répond de l'établissement.
router.use(authMiddleware, requireRole('directeur', 'prefet', 'super_admin'));

// Déclarées AVANT la route racine : Express résout dans l'ordre de déclaration.
router.get('/filtres', ctrl.filtresDisponibles);
// Recherche en langage courant. Réservée au directeur : elle consomme le quota
// IA de l'école, et interroger le journal revient à observer le travail de
// chacun — c'est à celui qui répond de l'établissement de le faire.
router.post('/recherche-ia', requireRole('directeur', 'super_admin'), ctrl.rechercheAssistee);
router.get('/', ctrl.lister);

module.exports = router;
