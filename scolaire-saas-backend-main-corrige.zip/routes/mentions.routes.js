const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/mentions.controller');

router.use(authMiddleware);

router.get('/', ctrl.lister);
router.post('/', requireRole('directeur'), ctrl.creer);
router.delete('/:id', requireRole('directeur'), ctrl.supprimer);

module.exports = router;
