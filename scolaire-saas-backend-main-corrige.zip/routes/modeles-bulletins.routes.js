const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/modeles-bulletins.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/*
 * Verrou d'offre — éditeur de modèles de bulletins.
 *
 * Il porte sur la CRÉATION et la MODIFICATION de maquettes, jamais sur la
 * lecture ni sur l'aperçu. Les modèles officiels de la RDC — primaire,
 * secondaire, terminale — font partie du cœur du métier et restent
 * disponibles dans les quatre offres : les verrouiller reviendrait à vendre
 * un logiciel scolaire congolais qui n'imprime pas de bulletin congolais.
 *
 * Conséquence voulue : une école qui redescend d'offre continue d'imprimer
 * les bulletins avec la maquette qu'elle avait dessinée. Elle ne peut
 * simplement plus en créer de nouvelle.
 */
const PERSONNALISATION = exigeFonctionnalite('modeles_personnalises');

router.get('/', ctrl.lister); // tout utilisateur authentifié peut consulter les modèles disponibles
router.get('/:id/apercu', ctrl.apercu);
router.post('/', PERSONNALISATION, requireRole('directeur', 'super_admin'), ctrl.creer);
router.post('/:id/activer', requireRole('directeur', 'super_admin'), ctrl.activerModele);
router.post('/:id/suggerer-zones', PERSONNALISATION, requireRole('directeur', 'super_admin'), ctrl.suggererZones);
router.delete('/:id', requireRole('directeur', 'super_admin'), ctrl.supprimerModele);

router.get('/:id/zones', ctrl.listerZones);
router.post('/:id/zones', PERSONNALISATION, requireRole('directeur', 'super_admin'), ctrl.ajouterZone);
router.patch('/zones/:zoneId', PERSONNALISATION, requireRole('directeur', 'super_admin'), ctrl.modifierZone);
router.delete('/zones/:zoneId', PERSONNALISATION, requireRole('directeur', 'super_admin'), ctrl.supprimerZone);

module.exports = router;
