const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/notes.controller');

router.use(authMiddleware);

// Le professeur doit pouvoir accéder à la grille de ses propres cours, et le
// titulaire peut consulter (lecture seule) n'importe quel cours de sa classe ;
// la vérification fine (cours bien affecté, ou lecture seule) est faite dans le contrôleur.
router.get('/grille', requireRole('professeur', 'directeur', 'prefet', 'titulaire'), ctrl.grille);
router.post('/grille', requireRole('professeur', 'directeur', 'prefet'), ctrl.enregistrerGrille);
router.get('/grille-travaux', requireRole('professeur', 'directeur', 'prefet', 'titulaire'), ctrl.grilleTravaux);
router.post('/grille-travaux', requireRole('professeur', 'directeur', 'prefet'), ctrl.enregistrerGrilleTravaux);

router.post('/valider', requireRole('directeur', 'prefet', 'professeur'), ctrl.valider);
router.post('/devalider', requireRole('directeur', 'prefet'), ctrl.devalider);

router.post('/recalculer', requireRole('directeur', 'prefet'), ctrl.recalculer);
router.get('/recapitulatif', requireRole('directeur', 'prefet', 'titulaire', 'secretaire'), ctrl.recapitulatif);
router.get('/fiche-cotes', requireRole('professeur', 'directeur', 'prefet'), ctrl.genererFicheCotes);

module.exports = router;
