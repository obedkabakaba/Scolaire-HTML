const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const ctrl = require('../controllers/notifications.controller');

// Ouvert à tous les rôles : chacun consulte SA boîte de réception.
// Le cloisonnement par destinataire est assuré dans le contrôleur.
router.use(authMiddleware);

router.get('/', ctrl.lister);
router.patch('/:id/lu', ctrl.marquerLue);
router.post('/tout-marquer-lu', ctrl.toutMarquerLu);

module.exports = router;
