const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/orientation.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

// Le titulaire recueille les vœux de SA classe, la direction répartit.
// La route dit qui peut entrer ; le contrôleur dit sur quelles classes —
// c'est lui seul qui sait de quelle classe l'utilisateur est titulaire.
const CONSULTATION = requireRole('directeur', 'prefet', 'secretaire', 'titulaire');
// La saisie des vœux est un acte réservé au titulaire : lui seul connaît
// l'élève et sa famille. Ni le directeur ni le préfet ne modifient un vœu,
// même s'ils gardent le droit de consulter (CONSULTATION) et de corriger
// l'AFFECTATION finale une fois la répartition faite (voir /:eleveId
// ci-dessous, qui reste sur DIRECTION — corriger une affectation n'est pas
// modifier un vœu).
const SAISIE = requireRole('titulaire');
const DIRECTION = requireRole('directeur', 'prefet');

/* ---------------------------------------------------------------------------
   VERROU D'OFFRE — UNE EXCEPTION, ET UNE SEULE

   `GET /acces` est interrogé au chargement de TOUTES les pages pour décider
   d'afficher ou non l'entrée de menu. Le verrouiller ferait remonter un 402 à
   chaque changement d'écran d'une école qui n'a pas l'orientation, et `ui.js`
   ouvrirait sa modale « votre abonnement ne comprend pas… » en boucle.

   La route reste donc ouverte. Ce qu'elle expose est exactement un booléen :
   aucune donnée d'élève, aucun vœu, aucune option. C'est le niveau
   d'information que porte déjà la présence ou l'absence d'une entrée de menu.

   TOUT LE RESTE est verrouillé, y compris les lectures : le tableau
   d'orientation expose les vœux nominatifs des élèves de fin de cycle, et
   c'est précisément la fonctionnalité vendue.
   --------------------------------------------------------------------------- */
router.get('/acces', CONSULTATION, ctrl.acces);

const OFFRE_ORIENTATION = exigeFonctionnalite('orientation');

router.get('/', CONSULTATION, OFFRE_ORIENTATION, ctrl.tableau);
router.post('/voeux', SAISIE, OFFRE_ORIENTATION, ctrl.enregistrerVoeux);
router.post('/repartir', DIRECTION, OFFRE_ORIENTATION, ctrl.repartir);

// Critères d'admission par option. Fixer le niveau exigé pour entrer dans une
// option est une décision d'établissement : elle ne se délègue pas au titulaire
// qui accompagne les élèves candidats.
router.put('/options/:optionId/critere', DIRECTION, OFFRE_ORIENTATION, ctrl.definirCritere);

// Déclarée en dernier : « /options/... » ne doit pas être capturé par « /:eleveId ».
router.patch('/:eleveId', DIRECTION, OFFRE_ORIENTATION, ctrl.corrigerAffectation);

module.exports = router;
