const express = require('express');
const router = express.Router();
const { webhookPawaPay } = require('../controllers/paiements.controller');

// PUBLIC — appelé directement par PawaPay, pas de JWT possible ici.
router.post('/webhook-pawapay', webhookPawaPay);

module.exports = router;
