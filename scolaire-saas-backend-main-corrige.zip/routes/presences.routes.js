const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/presences.controller');

router.use(authMiddleware);

// Le titulaire fait l'appel de sa classe ; le secrétariat peut le faire pour
// n'importe quelle classe (remplacement, rattrapage). Le contrôle
// d'appartenance de la classe est fait dans le contrôleur.
// Le filtre de rôle reste large ici : c'est verifierAccesClasse(), dans le
// contrôleur, qui applique la règle réelle — elle dépend du mode choisi par
// l'école (titulaire / professeur / chargé des présences), de la classe
// visée, ET de la nature de l'action (lecture ou écriture), trois
// informations qu'un middleware de rôle ne peut pas connaître. En
// particulier, directeur et préfet restent ici pour la LECTURE (consulter
// une feuille d'appel, des statistiques) mais verifierAccesClasse() leur
// refuse désormais l'ÉCRITURE : ils ne saisissent plus l'appel eux-mêmes,
// sauf s'ils sont par ailleurs professeur d'un cours de cette classe.
//
// 'professeur' et 'charge_presences' doivent donc figurer ici : sans eux, un
// professeur en mode 'professeur' serait rejeté AVANT d'atteindre la logique
// qui l'autorise, et le mode n'aurait aucun effet.
// 'directeur_discipline' y figure aussi : l'assiduité est la matière première
// de son travail, et en mode « chargé » c'est l'un des deux seuls rôles à
// conserver l'écran des présences, en lecture ET en écriture (voir
// acces-presences.js côté front).
const PEUT_APPELER = requireRole(
  'directeur', 'prefet', 'secretaire', 'titulaire', 'professeur',
  'charge_presences', 'directeur_discipline'
);
const VUE_ECOLE = requireRole('directeur', 'prefet', 'secretaire', 'directeur_discipline');

router.get('/resume-jour', VUE_ECOLE, ctrl.resumeJour);
router.get('/statistiques', PEUT_APPELER, ctrl.statistiques);
router.get('/eleve/:eleveId', PEUT_APPELER, ctrl.historiqueEleve);
router.get('/classe/:classeId', PEUT_APPELER, ctrl.feuilleAppel);
router.post('/classe/:classeId', PEUT_APPELER, ctrl.enregistrerAppel);

module.exports = router;
