const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/promotion.controller');

router.use(authMiddleware, requireRole('directeur', 'prefet'));

router.get('/apercu', ctrl.apercu);
router.post('/executer', ctrl.executer);

module.exports = router;
