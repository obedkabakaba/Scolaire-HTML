const express = require('express');
const router = express.Router();
const { limiteurResultatsPublics, limiteurSitePublic } = require('../middleware/rate-limit.middleware');
const ctrl = require('../controllers/public.controller');

// ATTENTION : aucune authentification sur ces routes, volontairement.
// Ce sont les seules du projet dans ce cas. Toute route ajoutée ici doit
// être limitée en débit et ne renvoyer que des données explicitement publiées.

router.get('/ecole/:code', limiteurSitePublic, ctrl.pageEcole);
router.post('/resultats', limiteurResultatsPublics, ctrl.consulterResultats);

module.exports = router;
