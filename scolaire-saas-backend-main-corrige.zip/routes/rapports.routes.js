const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/rapports.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

// Les rapports pilotent l'établissement : direction avant tout.
// Le comptable accède au recouvrement, le secrétariat aux effectifs.
const PILOTAGE = requireRole('directeur', 'prefet');
const EFFECTIFS = requireRole('directeur', 'prefet', 'secretaire');
const FINANCES = requireRole('directeur', 'prefet', 'comptable');

/* ---------------------------------------------------------------------------
   VERROU D'OFFRE — LE DÉCOUPAGE LE PLUS DÉLICAT DU DÉPÔT

   `rapports_avances` est vendu, et n'était verrouillé nulle part. Poser le
   verrou sur le routeur entier aurait été la faute grave : compter ses élèves
   et savoir qui doit combien ne sont pas des « rapports avancés », ce sont des
   gestes de gestion quotidienne. Une école Ascension qui ne peut plus sortir
   son effectif n'a pas une offre limitée, elle a un logiciel cassé.

   Le partage retenu :

     OUVERT partout   effectifs  · combien d'élèves, par classe et par sexe
                      finances   · qui a payé, qui doit — le recouvrement est
                                   le nerf d'une école congolaise, et le
                                   comptable en a besoin dans les quatre offres

     RÉSERVÉ          reussite   · taux de réussite par classe et par branche
                      palmares   · classements d'établissement
                      moyennes   · moyennes croisées toutes classes
                      portees    · portées d'analyse disponibles
                      assiduite  · statistiques d'assiduité agrégées

   Le critère appliqué : un rapport qui répond « où en est mon école ? » sur un
   registre ANALYTIQUE est avancé ; un rapport qui répond « qui est là ? » ou
   « qui doit de l'argent ? » est du socle.
   --------------------------------------------------------------------------- */
const OFFRE_RAPPORTS = exigeFonctionnalite('rapports_avances');

router.get('/effectifs', EFFECTIFS, ctrl.effectifs);
router.get('/finances', FINANCES, ctrl.finances);

router.get('/reussite', PILOTAGE, OFFRE_RAPPORTS, ctrl.reussite);
router.get('/palmares', PILOTAGE, OFFRE_RAPPORTS, ctrl.palmares);
// Mêmes droits que les autres rapports de pilotage : ces deux endpoints
// exposent les résultats de toutes les classes.
router.get('/moyennes', PILOTAGE, OFFRE_RAPPORTS, ctrl.moyennes);
router.get('/portees', PILOTAGE, OFFRE_RAPPORTS, ctrl.porteesDisponibles);
router.get('/assiduite', PILOTAGE, OFFRE_RAPPORTS, ctrl.assiduite);

// Filtre large ici, puis contrôle précis PAR TYPE dans le contrôleur : l'export
// appelle les fonctions de rapport directement, sans repasser par les routes
// ci-dessus, donc leurs droits de RÔLE et d'OFFRE doivent y être revérifiés.
// Sans cela, `/rapports/export?type=palmares` contournerait le verrou posé sur
// `/rapports/palmares` — l'exact contournement par URL que le test interdit.
router.get('/export', requireRole('directeur', 'prefet', 'secretaire', 'comptable'), ctrl.exporter);

module.exports = router;
