const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/repechage.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/* Verrou d'offre sur le routeur entier. Le repêchage est une session de fin
   d'année entièrement autonome : rien d'autre dans l'application n'appelle ces
   routes, et une école qui ne l'a pas souscrit n'a aucune session à consulter.

   Ce que le verrou NE touche PAS, et c'est volontaire : les notes ordinaires,
   les bulletins et la promotion de fin d'année. Une école sans repêchage
   clôture son année normalement. */
router.use(exigeFonctionnalite('repechage'));

// Fixer les conditions et prononcer les décisions engage l'établissement :
// c'est la direction. Le préfet y participe, il tient la pédagogie.
const DIRECTION = requireRole('directeur', 'prefet');

// La SAISIE des notes est le geste du correcteur, comme pour les notes
// ordinaires : elle s'ouvre aux enseignants. Le contrôleur vérifie que la
// session est bien ouverte.
const CORRECTION = requireRole('directeur', 'prefet', 'professeur', 'titulaire');

router.get('/sessions', CORRECTION, ctrl.listerSessions);
router.post('/sessions', DIRECTION, ctrl.creerSession);

router.get('/sessions/:id/eligibles', DIRECTION, ctrl.listerEligibles);
router.post('/sessions/:id/ouvrir', DIRECTION, ctrl.ouvrirSession);

router.get('/sessions/:id/copies', CORRECTION, ctrl.listerCopies);
router.put('/copies/:id', CORRECTION, ctrl.saisirNote);

router.post('/sessions/:id/cloturer', DIRECTION, ctrl.cloturerSession);
router.get('/sessions/:id/resultats', CORRECTION, ctrl.resultats);

module.exports = router;
