const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/services.controller');

router.use(authMiddleware);

/*
 * Aucun contrôle d'offre sur ces routes, et c'est délibéré.
 *
 * Un service complémentaire n'est pas une fonctionnalité : il ne se débloque
 * pas, il s'achète. Poser ici un `exigeFonctionnalite(...)` reviendrait à
 * interdire à une école en Ascension de commander une formation — exactement
 * la confusion que la refonte commerciale a supprimée.
 *
 * Le seul contrôle est donc celui du rôle : engager une dépense pour l'école
 * relève de la direction, pas d'un professeur.
 */

router.get('/', requireRole('directeur', 'prefet'), ctrl.listerCatalogue);
router.get('/estimation', requireRole('directeur', 'prefet'), ctrl.estimer);
router.post('/commander', requireRole('directeur'), ctrl.commander);
router.delete('/commandes/:id', requireRole('directeur'), ctrl.annuler);

module.exports = router;
