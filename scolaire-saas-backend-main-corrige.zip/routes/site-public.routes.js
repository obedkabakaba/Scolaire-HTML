const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/site-public.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

router.use(authMiddleware);

/* Verrou d'offre sur le routeur ENTIER, contrairement à l'emploi du temps.

   Ici, aucune route n'est appelée au chargement d'un autre écran : elles ne
   servent qu'à piloter la vitrine depuis `site-public.html`, page elle-même
   conditionnée par la même fonctionnalité. Un 402 ne peut donc surgir que si
   quelqu'un ouvre l'URL directement — exactement le cas qu'il faut couvrir,
   puisque masquer une entrée de menu n'a jamais été une sécurité.

   Les pages VUES PAR LES FAMILLES ne passent pas ici : elles vivent dans
   `public.routes.js`, sans jeton, et ne sont pas concernées. */
router.use(exigeFonctionnalite('site_public'));

// Le directeur pilote la vitrine ; le secrétariat gère les codes d'accès,
// puisque c'est lui qui les remet aux familles.
const PILOTAGE = requireRole('directeur', 'prefet');
const CODES = requireRole('directeur', 'prefet', 'secretaire');

router.get('/parametres', PILOTAGE, ctrl.obtenirParametres);
router.put('/parametres', PILOTAGE, ctrl.enregistrerParametres);

router.get('/annonces', PILOTAGE, ctrl.listerAnnonces);
router.post('/annonces', PILOTAGE, ctrl.creerAnnonce);
router.patch('/annonces/:id', PILOTAGE, ctrl.modifierAnnonce);
router.delete('/annonces/:id', PILOTAGE, ctrl.supprimerAnnonce);

router.get('/codes-acces', CODES, ctrl.listerCodesAcces);
router.post('/codes-acces', CODES, ctrl.genererCodesAcces);
router.post('/codes-acces/reinitialiser', CODES, ctrl.reinitialiserCode);

module.exports = router;
