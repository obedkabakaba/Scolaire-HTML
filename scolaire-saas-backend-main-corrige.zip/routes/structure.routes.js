const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/structure.controller');

router.use(authMiddleware);

const PEUT_MODIFIER = requireRole('directeur', 'prefet');

// Périodes
router.get('/periodes', ctrl.listerPeriodes);
router.post('/periodes', PEUT_MODIFIER, ctrl.creerPeriode);
router.patch('/periodes/:id', PEUT_MODIFIER, ctrl.modifierPeriode);
router.delete('/periodes/:id', PEUT_MODIFIER, ctrl.supprimerPeriode);

// Classe(s) dont l'utilisateur connecté est titulaire
router.get('/ma-classe', requireRole('titulaire'), ctrl.obtenirMesClassesTitulaire);

// Cours assignés au professeur connecté
router.get('/mes-cours', requireRole('professeur'), ctrl.listerMesCoursAssignes);

// Années scolaires
// La route littérale est déclarée avant les routes paramétrées : sinon
// "proposition-suivante" serait avalé comme un :id.
router.get('/annees-scolaires/proposition-suivante', PEUT_MODIFIER, ctrl.proposerAnneeSuivante);
router.get('/annees-scolaires', ctrl.listerAnnees);
router.post('/annees-scolaires', PEUT_MODIFIER, ctrl.creerAnnee);
router.post('/annees-scolaires/:id/activer', PEUT_MODIFIER, ctrl.activerAnnee);
router.post('/annees-scolaires/:id/cloturer', PEUT_MODIFIER, ctrl.cloturerAnnee);
// Report de la structure (classes, cours par classe, professeurs) d'une année
// vers une autre — ce qui n'a pas à être reconfiguré chaque rentrée.
router.post('/annees-scolaires/:anneeCibleId/reporter-structure', PEUT_MODIFIER, ctrl.reporterStructureAnnee);

// Sections

// Options
router.get('/options', ctrl.listerOptions);
router.post('/options', PEUT_MODIFIER, ctrl.creerOption);

// Classes — la route de duplication doit être déclarée AVANT /:id
router.post('/classes/dupliquer-pour-nouvelle-annee', PEUT_MODIFIER, ctrl.dupliquerClassesPourNouvelleAnnee);
router.get('/classes', ctrl.listerClasses);

// Fiches transversales : lecture seule, agrégats. Ouvertes aux mêmes rôles que
// la consultation de la structure — elles ne révèlent rien de plus que ce que
// ces écrans montrent déjà, seulement rassemblé.
const fiches = require('../controllers/parcours.controller');
router.get('/classes/:id/fiche',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire'), fiches.ficheClasse);
router.post('/classes', PEUT_MODIFIER, ctrl.creerClasse);
router.patch('/classes/:id', PEUT_MODIFIER, ctrl.modifierClasse);
router.delete('/classes/:id', PEUT_MODIFIER, ctrl.supprimerClasse);
router.get('/classes/:classe_id/cours', ctrl.listerCoursDeClasse);
router.get('/classes/:classe_id/cours/:cours_id/recap', requireRole('titulaire', 'directeur', 'prefet'), ctrl.recapCoursPourTitulaire);
router.get('/classes/:classe_id/moyenne-generale', requireRole('titulaire', 'directeur', 'prefet'), ctrl.moyenneGeneraleClasse);
router.get('/classes/:classe_id/etat-periodes', requireRole('titulaire', 'directeur', 'prefet'), ctrl.etatPeriodesClasse);
router.post('/classes/:classe_id/cours', PEUT_MODIFIER, ctrl.affecterCoursAClasse);
router.post('/classes/:classe_id/nouveau-cours', PEUT_MODIFIER, ctrl.creerCoursPourClasse);
router.delete('/classes/:classe_id/cours/:cours_id', PEUT_MODIFIER, ctrl.retirerCoursDeClasse);

// Cours
router.get('/vacations', ctrl.listerVacations);
router.post('/vacations', PEUT_MODIFIER, ctrl.creerVacation);
router.patch('/vacations/:id', PEUT_MODIFIER, ctrl.modifierVacation);
router.delete('/vacations/:id', PEUT_MODIFIER, ctrl.supprimerVacation);

router.get('/cours', ctrl.listerCours);
router.get('/cours/:id/fiche',
  requireRole('directeur', 'prefet', 'secretaire', 'titulaire', 'professeur'), fiches.ficheCours);
router.post('/cours', PEUT_MODIFIER, ctrl.creerCours);
router.patch('/cours/:id', PEUT_MODIFIER, ctrl.modifierCours);
router.delete('/cours/:id', PEUT_MODIFIER, ctrl.supprimerCours);

// Affectation professeur à un cours de classe
router.post('/classe-cours/:classe_cours_id/professeur', PEUT_MODIFIER, ctrl.affecterProfesseur);

module.exports = router;
