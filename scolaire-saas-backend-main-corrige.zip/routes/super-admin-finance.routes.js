const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');

const { contexteFinance, financeEcriture, exigerConfirmation } = require('../middleware/finance.middleware');

const finance = require('../controllers/super-admin-finance.controller');
const offres = require('../controllers/super-admin-offres.controller');
const couts = require('../controllers/super-admin-couts.controller');

/*
 * Centre Finance, Offres et Coûts — /super-admin/…
 * ---------------------------------------------------------------------------
 * Ce routeur est monté DANS `super-admin.routes.js`, après le
 * `router.use(authMiddleware, superAdminSeul)` qui y figure déjà. Il hérite
 * donc du verrou d'entrée sans le redéfinir : une seule porte, comme le
 * commentaire d'en-tête de ce fichier l'exige depuis le premier jour.
 *
 * Deux gardes s'y ajoutent :
 *   · `contexteFinance` — renseigne req.finance.{niveau, peutEcrire} ;
 *   · `financeEcriture` — refuse toute méthode d'écriture aux accès en
 *     lecture seule. Le filtre porte sur la MÉTHODE, pas sur une liste de
 *     chemins : une route ajoutée demain sera protégée sans qu'on y pense.
 *
 * `exigerConfirmation` est posé route par route, uniquement sur les actions
 * que la mission désigne comme sensibles (§ 25). Le poser partout
 * transformerait la confirmation en formalité qu'on remplit sans lire — ce
 * qui la viderait de son sens là où elle compte.
 */

router.use(contexteFinance, financeEcriture);

/* Limiteur des exports : chaque appel balaie plusieurs tables et produit un
   fichier. Un clic répété sur « Exporter » ne doit pas devenir une charge. */
const limiteurExport = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop d\'exports en peu de temps. Patientez une minute.' }
});

/* =========================================================================
   FINANCE — tableau de bord, analyses, alertes, journal
   ========================================================================= */

router.get('/finance/tableau-de-bord',      finance.tableauDeBordFinancier);
router.get('/finance/rentabilite',          finance.rentabilite);
router.get('/finance/seuil-rentabilite',    finance.seuilRentabilite);
router.get('/finance/previsions',           finance.previsions);
router.get('/finance/alertes',              finance.alertes);
router.get('/finance/cout-fonctionnalites', finance.coutFonctionnalites);
router.get('/finance/journal',              finance.journal);

/* Permissions financières (§ 24). */
router.get('/finance/permissions',                  finance.listerPermissions);
router.put('/finance/permissions/:utilisateurId',   exigerConfirmation, finance.definirPermission);

/* Exports (§ 23). */
router.get('/finance/exports',           finance.catalogueExports);
router.get('/finance/exports/:rapport',  limiteurExport, finance.exporterRapportFinance);

/* =========================================================================
   OFFRES & TARIFICATION
   ========================================================================= */

router.get('/offres',        offres.listerOffres);
router.post('/offres',       offres.creerOffre);
router.patch('/offres/:id',  offres.modifierOffre);

/* Simulation AVANT confirmation : ne modifie rien, d'où le POST sans
   `exigerConfirmation` — c'est elle qui alimente l'écran de confirmation. */
router.post('/offres/:id/impact-prix', offres.simulerChangementPrix);
router.post('/offres/:id/prix',        exigerConfirmation, offres.changerPrix);
router.get('/offres/:id/historique-prix', offres.historiquePrix);
router.post('/offres/:id/statut',      exigerConfirmation, offres.changerStatutOffre);

/* Promotions (§ 4). */
router.get('/promotions',        offres.listerPromotions);
router.post('/promotions',       exigerConfirmation, offres.creerPromotion);
router.patch('/promotions/:id',  offres.modifierPromotion);

/* Offres spéciales (§ 5). */
router.get('/offres-speciales',        offres.listerOffresSpeciales);
router.post('/offres-speciales',       offres.creerOffreSpeciale);
router.patch('/offres-speciales/:id',  offres.modifierOffreSpeciale);

/* Tarification personnalisée (§ 6). */
router.get('/tarifs-personnalises',              offres.listerTarifsPersonnalises);
router.post('/tarifs-personnalises',             exigerConfirmation, offres.creerTarifPersonnalise);
router.post('/tarifs-personnalises/:id/terminer', offres.terminerTarifPersonnalise);

/* Abonnements clients enrichis (§ 17). La route historique
   /super-admin/abonnements reste en place et inchangée. */
router.get('/abonnements-detail', offres.abonnementsDetail);

/* =========================================================================
   SERVICES, COÛTS, DÉPENSES, BUDGETS
   ========================================================================= */

router.get('/services',        couts.listerServices);
router.post('/services',       couts.creerService);
router.get('/services/:id',    couts.detailService);
router.patch('/services/:id',  couts.modifierService);
router.put('/services/:id/consommations', couts.enregistrerConsommation);

router.get('/depenses',             couts.listerDepenses);
router.post('/depenses',            couts.creerDepense);
router.patch('/depenses/:id',       couts.modifierDepense);
/* Pas de DELETE : on archive, avec motif obligatoire (§ 25). */
router.post('/depenses/:id/archiver', exigerConfirmation, couts.archiverDepense);

router.get('/budgets', couts.listerBudgets);
router.put('/budgets', couts.definirBudget);

router.get('/taux-change',  couts.listerTauxChange);
router.post('/taux-change', couts.enregistrerTauxChange);

router.get('/calendrier-facturation', couts.calendrierFacturation);

module.exports = router;
