const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');

const authMiddleware = require('../middleware/auth.middleware');
const { superAdminSeul, lectureSeule } = require('../middleware/super-admin.middleware');

const pilotage = require('../controllers/super-admin.controller');
const explorer = require('../controllers/super-admin-explorer.controller');
const systeme = require('../controllers/super-admin-systeme.controller');
const support = require('../controllers/super-admin-support.controller');

/*
 * Espace Super Administrateur — /super-admin
 * ---------------------------------------------------------------------------
 * Une seule porte d'entrée : `superAdminSeul` est appliqué à toute la branche.
 * Les routes existantes ne sont pas dupliquées — création d'école, changement
 * de statut, changement de plan et réinitialisation du mot de passe Directeur
 * restent sur /admin/ecoles (ecoles.controller.js), que l'interface appelle
 * directement. Ce fichier n'ajoute que ce qui n'existait pas.
 */

router.use(authMiddleware, superAdminSeul);

/* ---------- Pilotage ---------- */
router.get('/tableau-de-bord', pilotage.tableauDeBord);
router.get('/referentiels', pilotage.referentiels);
router.get('/analyses', pilotage.analyses);

/* ---------- Écoles ---------- */
router.get('/ecoles', pilotage.listerEcoles);
router.get('/ecoles/:id/statistiques', pilotage.statistiquesEcole);
router.get('/abonnements', pilotage.abonnements);

/* ---------- Utilisateurs ---------- */
router.get('/utilisateurs', pilotage.listerUtilisateurs);
router.get('/utilisateurs/:id', pilotage.detailUtilisateur);

/* ---------- Recherche globale ----------
 * Limiteur dédié : la frappe au clavier déclenche un appel par caractère si le
 * front oublie son anti-rebond, et chaque appel balaie six familles de tables.
 */
const limiteurRecherche = rateLimit({
  windowMs: 60 * 1000,
  max: 90,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de recherches en peu de temps. Patientez quelques secondes.' }
});
router.get('/recherche', limiteurRecherche, pilotage.rechercheGlobale);

/* ---------- Explorateur (lecture seule stricte) ----------
 * `lectureSeule` est posé sur la branche entière : même si une route
 * d'écriture y était ajoutée par distraction, elle serait refusée.
 */
router.use('/explorer', lectureSeule);
router.get('/explorer/ressources', explorer.catalogueRessources);
router.get('/explorer/eleve/:eleveId', explorer.dossierEleve);
router.get('/explorer/:ecoleId/apercu', explorer.apercuEcole);
router.get('/explorer/:ecoleId/:ressource', explorer.listerRessource);

/* ---------- Mode « Voir comme » ---------- */
router.get('/observation', explorer.historiqueObservations);
router.post('/observation', explorer.demarrerObservation);
router.post('/observation/:id/fin', explorer.terminerObservation);

/* ---------- Santé, sécurité, sauvegardes ---------- */
router.get('/sante', systeme.sante);
router.get('/securite', systeme.securite);
router.get('/sauvegardes', systeme.listerSauvegardes);
router.post('/sauvegardes', systeme.lancerSauvegarde);
router.get('/sauvegardes/:id/telecharger', systeme.telechargerSauvegarde);

/* ---------- Configuration ---------- */
router.get('/configuration', systeme.obtenirConfiguration);
router.patch('/configuration', systeme.modifierConfiguration);

/* ---------- Intelligence artificielle ---------- */
router.get('/ia', systeme.statistiquesIA);

/* ---------- Bugs ---------- */
router.post('/bugs/signaler', support.signalerBug);
router.get('/bugs', support.listerBugs);
router.get('/bugs/:id', support.detailBug);
router.patch('/bugs/:id', support.modifierBug);
router.post('/bugs/:id/commentaires', support.commenterBug);

/* ---------- Audits statiques ----------
 * Les résultats des scripts d'audit publiés par la CI ou depuis un terminal.
 * Lecture seule ici : l'ÉCRITURE passe par /audits/executions, authentifié par
 * secret technique. Le Super Admin consulte et statue, il ne dépose pas.
 *
 * Filtrables par origine : une exception de production (centre de bugs) et un
 * avertissement d'analyse statique ne se comparent pas, et les mélanger
 * rendrait les deux illisibles.
 */
const audits = require('../controllers/audits.controller');
router.get('/audits', audits.listerExecutions);
router.get('/audits/anomalies', audits.listerAnomalies);
router.patch('/audits/anomalies/:id', audits.modifierAnomalie);

/* ---------- Support ---------- */
router.get('/tickets', support.listerTickets);
router.post('/tickets', support.creerTicket);
router.get('/tickets/:id', support.detailTicket);
router.patch('/tickets/:id', support.modifierTicket);
router.post('/tickets/:id/messages', support.repondreTicket);

/* ---------- Notifications système ---------- */
router.get('/notifications', support.listerNotifications);
router.post('/notifications', support.creerNotification);

/* ---------- Rapports ---------- */
router.get('/rapports', support.catalogueRapports);
router.get('/rapports/:rapport', support.exporterRapport);

/* ---------- Outils développeur ----------
 * Ces routes déclenchent des envois réels (email, WhatsApp) et des tâches
 * planifiées. Un limiteur serré évite qu'un clic répété ne devienne un envoi
 * en masse involontaire, facturé et signalé comme spam.
 */
const limiteurOutils = rateLimit({
  windowMs: 60 * 1000,
  max: 12,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  message: { message: 'Trop de tests en peu de temps. Patientez une minute.' }
});

router.get('/outils/taches', systeme.listerTaches);
router.get('/outils/logs', systeme.consulterLogs);
router.post('/outils/test-email', limiteurOutils, systeme.testEmail);
router.post('/outils/test-notification', limiteurOutils, systeme.testNotification);
router.post('/outils/test-whatsapp', limiteurOutils, systeme.testWhatsApp);
router.post('/outils/vider-cache', systeme.viderCache);
router.post('/outils/taches/:tache', limiteurOutils, systeme.executerTache);
router.post('/outils/recalculer', limiteurOutils, systeme.recalculerBulletins);

/* ---------- Services complémentaires ----------
 * Le suivi des prestations vendues : demandes reçues, planification,
 * réalisation, et ce qu'elles rapportent par catégorie.
 *
 * Déclaré ici et non dans le routeur Finance, bien que ce soit du revenu :
 * ces routes servent d'abord à FAIRE le travail (confirmer, planifier,
 * clore une intervention), pas à l'analyser. Les mêmes chiffres remontent
 * ensuite dans le centre Finance, agrégés.
 */
const services = require('../controllers/services.controller');
router.get('/services/commandes', services.listerCommandesAdmin);
router.patch('/services/commandes/:id', services.majCommandeAdmin);

/* ---------- Demandes d'accompagnement (prospects) ----------
 * Ce que le formulaire du site public dépose, et le suivi commercial qui
 * s'ensuit. Distinct des commandes de services juste au-dessus : ici l'école
 * n'existe pas encore, et la transformer en client est précisément le travail.
 *
 * POURQUOI CES DEUX LIGNES ARRIVENT SEULEMENT MAINTENANT
 * -----------------------------------------------------
 * Elles existaient depuis le début — dans un fichier `super-admin.routes.EXTRAIT.js`
 * accompagné d'un mode d'emploi expliquant où les coller. Personne ne les a
 * collées. Résultat en production : `controllers/prospects.controller.js`
 * exportait `lister` et `majDemande`, `super-admin-vues-prospects.js` appelait
 * consciencieusement `/super-admin/prospects`, et l'écran renvoyait 404 depuis
 * sa mise en ligne. Le Super Admin ne voyait aucune demande d'accompagnement,
 * et rien ne signalait qu'il en arrivait.
 *
 * L'extrait a été converti en documentation (`.EXTRAIT.js.md`) pour qu'aucun
 * autre morceau de code ne puisse à nouveau se croire monté sans l'être.
 *
 * Les deux routes héritent du `router.use(authMiddleware, superAdminSeul)`
 * posé en haut du fichier, et sont déclarées AVANT le montage du routeur
 * Finance sur '/', qui masquerait tout ce qui le suit.
 */
const prospects = require('../controllers/prospects.controller');
router.get('/prospects', prospects.lister);
router.patch('/prospects/:id', prospects.majDemande);

/* ---------- Centre Finance, Offres et Coûts ----------
 * Ajouté par l'extension commerciale et financière. Monté EN DERNIER et via
 * un routeur séparé, pour deux raisons :
 *   · il hérite du `router.use(authMiddleware, superAdminSeul)` posé en haut
 *     de ce fichier — une seule porte d'entrée, comme pour le reste ;
 *   · aucune de ses routes ne peut masquer une route existante, puisqu'elles
 *     sont toutes déclarées avant lui.
 * Le détail des chemins et des gardes propres à la finance (lecture seule,
 * confirmation des actions sensibles) vit dans le fichier monté.
 */
router.use('/', require('./super-admin-finance.routes'));

module.exports = router;
