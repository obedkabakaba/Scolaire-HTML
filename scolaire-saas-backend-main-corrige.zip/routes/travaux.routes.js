const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/travaux.controller');

router.use(authMiddleware, requireRole('professeur', 'directeur', 'prefet'));

router.get('/', ctrl.lister);
router.post('/', ctrl.creer);
router.delete('/:id', ctrl.supprimer);

module.exports = router;
