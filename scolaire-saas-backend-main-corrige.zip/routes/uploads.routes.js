const express = require('express');
const multer = require('multer');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/uploads.controller');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } }); // 5 Mo max

router.use(authMiddleware);

router.post('/logo-ecole', requireRole('directeur'), upload.single('fichier'), ctrl.uploaderLogoEcole);
router.post('/image-site', requireRole('directeur', 'prefet'), upload.single('fichier'), ctrl.uploaderImageSite);
router.post('/photo-eleve/:eleveId', requireRole('directeur', 'prefet', 'secretaire'), upload.single('fichier'), ctrl.uploaderPhotoEleve);
router.post('/photo-utilisateur/:utilisateurId', upload.single('fichier'), ctrl.uploaderPhotoUtilisateur);
// Le préfet est ajouté ici parce qu'il signe les bulletins au même titre que le
// directeur dans les écoles qui n'ont pas les deux fonctions distinctes : sans
// ce droit, la case « Le Chef d'Établissement » restait vide chez elles, faute
// de pouvoir déposer la signature. Le contrôleur limite de toute façon les
// non-directeurs au seul type « signature ».
router.post('/document', requireRole('directeur', 'prefet', 'titulaire'), upload.single('fichier'), ctrl.uploaderDocument);
router.get('/documents', requireRole('directeur', 'prefet', 'titulaire'), ctrl.obtenirDernierDocument);
router.delete('/document', requireRole('directeur', 'prefet', 'titulaire'), ctrl.supprimerDocument);

module.exports = router;
