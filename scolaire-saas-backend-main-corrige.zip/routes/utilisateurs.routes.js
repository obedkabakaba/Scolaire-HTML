const express = require('express');
const multer = require('multer');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/utilisateurs.controller');
const { verifierPlafond } = require('../middleware/offre.middleware');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

router.use(authMiddleware);

// IMPORTANT : ces routes "moi" doivent être déclarées AVANT /:id, sinon Express
// interpréterait "moi" comme un identifiant d'utilisateur.
router.get('/moi', ctrl.obtenirMonProfil);
router.patch('/moi', ctrl.modifierMonProfil);
router.post('/moi/changer-mot-de-passe', ctrl.changerMonMotDePasse);

// Réinitialisation par la direction : indispensable tant que l'envoi de
// courriels n'est pas opérationnel en production.
router.post('/:id/reinitialiser-mot-de-passe',
  requireRole('directeur', 'prefet'), ctrl.reinitialiserMotDePasse);

router.get('/', requireRole('directeur', 'prefet', 'secretaire'), ctrl.lister);
// Plafond de comptes de l'offre. Comme pour les élèves : uniquement sur la
// création et l'import. Personne ne doit être empêché de se connecter ou de
// changer son mot de passe parce que l'école a atteint son quota — ce serait
// punir l'utilisateur d'une décision commerciale qui ne le concerne pas.
router.post('/', requireRole('directeur'), verifierPlafond('max_utilisateurs'), ctrl.creer);
router.post('/import', requireRole('directeur'), upload.single('fichier'),
  verifierPlafond('max_utilisateurs', (req) => Number(req.body && req.body.nb_lignes) || 1),
  ctrl.importerUtilisateurs);
router.patch('/:id', requireRole('directeur'), ctrl.modifier);
router.delete('/:id', requireRole('directeur'), ctrl.supprimer);

module.exports = router;
