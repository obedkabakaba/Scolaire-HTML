const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const requireRole = require('../middleware/role.middleware');
const ctrl = require('../controllers/whatsapp.controller');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

// ATTENTION : le webhook n'est PAS authentifié — Meta l'appelle sans jeton.
// Sa sécurité repose entièrement sur la vérification de la signature, faite
// dans le contrôleur. Ne jamais ajouter ici une route qui lise ou écrive des
// données sans ce contrôle.
router.get('/webhook', ctrl.verifierWebhook);
router.post('/webhook', ctrl.recevoirMessage);

// Consultation des échanges par l'école, celle-ci authentifiée normalement.
/*
 * Verrou d'offre — assistant WhatsApp.
 *
 * Uniquement sur le journal, consulté par l'école. Le webhook au-dessus reste
 * ouvert : il est appelé par Meta, sans jeton, et vérifie lui-même sa
 * signature HMAC. Y poser un verrou d'offre serait sans effet — il n'y a
 * aucune école dans le contexte de la requête — et casserait la validation
 * de l'abonnement côté Meta.
 *
 * Le vrai verrouillage de l'envoi WhatsApp se fait donc dans le contrôleur,
 * au moment où l'école est identifiée par le numéro de téléphone. Voir la
 * note dans controllers/whatsapp.controller.js.
 */
router.get('/journal', authMiddleware, exigeFonctionnalite('whatsapp'),
  requireRole('directeur', 'prefet', 'secretaire'), ctrl.journalEcole);

module.exports = router;
