#!/usr/bin/env node
/**
 * ARDOISE — RÉGÉNÉRATION DES TARIFS ÉCRITS DANS LES PAGES
 * ===========================================================================
 *
 * LE PROBLÈME QU'IL RÈGLE
 * -----------------------
 * Les prix doivent figurer dans le HTML : un moteur de recherche ne lit pas
 * `catalogue.js`, et une page dont les tarifs n'apparaissent qu'après un appel
 * réseau se référence mal et s'affiche vide sur une connexion lente.
 *
 * Mais les prix vivent en base, où le Super Admin les modifie. Deux vérités,
 * donc — et la seconde diverge de la première dès le premier changement de
 * tarif. Le visiteur voit alors un prix sur le site et un autre sur sa facture.
 *
 * CE QU'IL FAIT
 * -------------
 * Il lit `/catalogue/offres` (donc la base, via l'API, donc la MÊME source que
 * la page en direct), et réécrit dans `index.html` et `tarifs.html` :
 *
 *   · les attributs `data-prix-*`, `data-mois-*`, `data-eco-*`, `data-pct-*`
 *     de chaque carte d'offre ;
 *   · le prix visible et la ligne de facturation, en périodicité mensuelle ;
 *   · les montants du bloc de données structurées JSON-LD.
 *
 * Il ne touche à rien d'autre : ni aux textes, ni aux listes de
 * fonctionnalités, ni à la mise en forme. Si une offre n'est pas trouvée dans
 * l'API, sa carte est laissée telle quelle plutôt que vidée.
 *
 * USAGE
 * -----
 *   node scripts/generer-tarifs-statiques.js ../Scolaire-HTML-main
 *   node scripts/generer-tarifs-statiques.js ../Scolaire-HTML-main --verifier
 *
 * `--verifier` ne modifie aucun fichier : il signale les écarts et sort avec
 * le code 1 s'il en trouve. C'est la forme à brancher dans une intégration
 * continue, pour qu'une baisse de prix oubliée sur le site fasse échouer un
 * déploiement plutôt que de tromper un visiteur pendant six mois.
 */

const fs = require('fs');
const path = require('path');

const API = (process.env.API_BASE_URL || 'https://scolaire-saas-backend.onrender.com')
              .replace(/\/+$/, '');

const PAGES = ['index.html', 'tarifs.html'];
const CODES = ['ascension', 'prime', 'pilote', 'infinite'];

async function principal() {
  const dossier = process.argv[2];
  const verifierSeulement = process.argv.includes('--verifier');

  if (!dossier) {
    console.error('Usage : node scripts/generer-tarifs-statiques.js <dossier-du-site> [--verifier]');
    process.exit(2);
  }

  const reponse = await fetch(`${API}/catalogue/offres`);
  if (!reponse.ok) {
    console.error(`L'API a répondu ${reponse.status}. Aucun fichier modifié.`);
    process.exit(2);
  }
  const { offres } = await reponse.json();

  const parCode = new Map(offres.map((o) => [o.code, o]));
  const manquantes = CODES.filter((c) => !parCode.has(c));
  if (manquantes.length) {
    console.warn(`Offres absentes de l'API, laissées inchangées : ${manquantes.join(', ')}`);
  }

  let ecarts = 0;

  for (const nomFichier of PAGES) {
    const chemin = path.join(dossier, nomFichier);
    if (!fs.existsSync(chemin)) { console.warn(`Ignoré (absent) : ${chemin}`); continue; }

    const avant = fs.readFileSync(chemin, 'utf8');
    let apres = avant;

    for (const code of CODES) {
      const offre = parCode.get(code);
      if (!offre) continue;
      apres = reecrireCarte(apres, code, offre);
    }

    apres = reecrireDonneesStructurees(apres, parCode);

    if (apres === avant) {
      console.log(`À jour : ${nomFichier}`);
      continue;
    }

    ecarts++;
    if (verifierSeulement) {
      console.error(`ÉCART : ${nomFichier} n'affiche pas les tarifs actuels de la base.`);
    } else {
      fs.writeFileSync(chemin, apres, 'utf8');
      console.log(`Réécrit : ${nomFichier}`);
    }
  }

  if (verifierSeulement && ecarts > 0) {
    console.error(`\n${ecarts} page(s) à régénérer. Lancez la commande sans --verifier.`);
    process.exit(1);
  }
  console.log('\nTerminé.');
}

/**
 * Réécrit une carte d'offre.
 *
 * On travaille sur le bloc <article> délimité par `data-offre="<code>"` plutôt
 * que sur le fichier entier : sans cette découpe, une expression régulière
 * cherchant `data-prix-mensuel` remplacerait celui de la première carte dans
 * les quatre.
 */
function reecrireCarte(html, code, offre) {
  const debut = html.indexOf(`data-offre="${code}"`);
  if (debut === -1) return html;

  const ouverture = html.lastIndexOf('<article', debut);
  const fermeture = html.indexOf('</article>', debut);
  if (ouverture === -1 || fermeture === -1) return html;

  let bloc = html.slice(ouverture, fermeture);

  const paires = { mensuel: 'Mensuel', semestriel: 'Semestriel', annuel: 'Annuel' };
  for (const [periode] of Object.entries(paires)) {
    const t = offre.tarifs[periode];
    if (!t) continue;
    bloc = poser(bloc, `data-prix-${periode}`, t.total);
    bloc = poser(bloc, `data-mois-${periode}`, t.par_mois);
    bloc = poser(bloc, `data-eco-${periode}`, t.economie);
    bloc = poser(bloc, `data-pct-${periode}`, t.economie_pourcentage);
  }
  bloc = poser(bloc, 'data-devise', offre.devise);

  // Le prix visible et la ligne de facturation sont écrits en MENSUEL, qui est
  // la période affichée au chargement. Les deux autres périodicités sont
  // portées par les attributs et calculées par catalogue.js.
  const mensuel = offre.tarifs.mensuel;
  if (mensuel) {
    const symbole = offre.devise === 'USD' ? '$' : offre.devise;
    bloc = bloc.replace(
      /(<div class="prix" data-prix>)[\s\S]*?(<\/div>)/,
      `$1<span class="devise">${symbole}</span>${formaterNombre(mensuel.total)}$2`);
    bloc = bloc.replace(
      /(<div class="facturation" data-facturation>)[\s\S]*?(<\/div>)/,
      `$1Facturé ${formaterNombre(mensuel.total)}&nbsp;${symbole} chaque mois.$2`);
  }

  return html.slice(0, ouverture) + bloc + html.slice(fermeture);
}

function poser(bloc, attribut, valeur) {
  const motif = new RegExp(`${attribut}="[^"]*"`);
  const remplacement = `${attribut}="${valeur === null || valeur === undefined ? '' : valeur}"`;
  return motif.test(bloc) ? bloc.replace(motif, remplacement) : bloc;
}

/**
 * Met à jour les montants du JSON-LD.
 *
 * Un balisage qui annonce 35 $ pendant que la page affiche 39 $ est pire que
 * pas de balisage du tout : c'est précisément le genre d'incohérence qui fait
 * perdre l'affichage enrichi, et il passe inaperçu puisque personne ne lit le
 * JSON-LD à l'œil.
 */
function reecrireDonneesStructurees(html, parCode) {
  return html.replace(
    /"@type":\s*"Offer",\s*"name":\s*"Ardoise (Ascension|Prime|Pilote|Infinite)",\s*"price":\s*"([\d.]+)"/g,
    (entier, nom, prix) => {
      const offre = parCode.get(nom.toLowerCase());
      if (!offre || !offre.tarifs.mensuel) return entier;
      return entier.replace(`"price": "${prix}"`, `"price": "${offre.tarifs.mensuel.total}"`);
    }
  );
}

function formaterNombre(n) {
  return Number(n).toLocaleString('fr-FR').replace(/\u202F|\u00A0/g, '\u202F');
}

principal().catch((err) => {
  console.error('Échec :', err.message);
  process.exit(2);
});
