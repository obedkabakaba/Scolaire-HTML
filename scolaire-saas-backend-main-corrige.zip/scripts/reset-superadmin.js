/**
 * Force la création OU la réinitialisation du compte Super Admin avec les
 * valeurs actuelles de SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD.
 *
 * Utile si le mot de passe ne correspond plus (ex: variable changée après
 * la première exécution de seed-superadmin.js, qui elle ne met jamais à jour).
 *
 * Sur Render : Shell > node scripts/reset-superadmin.js
 */
require('dotenv').config();
const { pool } = require('../config/db');
const { hashPassword } = require('../utils/password.utils');

async function reinitialiser() {
  const email = process.env.SUPERADMIN_EMAIL;
  const password = process.env.SUPERADMIN_PASSWORD;

  if (!email || !password) {
    console.error('SUPERADMIN_EMAIL et SUPERADMIN_PASSWORD doivent être définis dans les variables d\'environnement.');
    process.exit(1);
  }

  const hash = await hashPassword(password);

  const existant = await pool.query(
    'SELECT id FROM utilisateurs WHERE email = $1 AND ecole_id IS NULL',
    [email]
  );

  if (existant.rows.length > 0) {
    await pool.query(
      'UPDATE utilisateurs SET mot_de_passe_hash = $1, statut = \'actif\' WHERE id = $2',
      [hash, existant.rows[0].id]
    );
    console.log(`Mot de passe réinitialisé pour le Super Admin existant : ${email}`);
  } else {
    const userResult = await pool.query(
      `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, mot_de_passe_hash)
       VALUES (NULL, 'Super', 'Admin', $1, $2)
       RETURNING id`,
      [email, hash]
    );
    await pool.query(
      `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, 'super_admin')`,
      [userResult.rows[0].id]
    );
    console.log(`Super Admin créé : ${email}`);
  }

  process.exit(0);
}

reinitialiser().catch((err) => {
  console.error('Erreur:', err);
  process.exit(1);
});
