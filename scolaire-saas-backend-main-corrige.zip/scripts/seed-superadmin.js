/**
 * Crée le compte Super Admin s'il n'existe pas encore.
 * Utilise SUPERADMIN_EMAIL et SUPERADMIN_PASSWORD depuis les variables d'environnement.
 *
 * Sur Render : Shell > node scripts/seed-superadmin.js
 * (à exécuter une seule fois après le premier déploiement)
 */
require('dotenv').config();
const { pool } = require('../config/db');
const { hashPassword } = require('../utils/password.utils');

async function seed() {
  const email = process.env.SUPERADMIN_EMAIL;
  const password = process.env.SUPERADMIN_PASSWORD;

  if (!email || !password) {
    console.error('SUPERADMIN_EMAIL et SUPERADMIN_PASSWORD doivent être définis dans .env');
    process.exit(1);
  }

  const existing = await pool.query(
    'SELECT id FROM utilisateurs WHERE email = $1 AND ecole_id IS NULL',
    [email]
  );

  if (existing.rows.length > 0) {
    console.log('Le Super Admin existe déjà.');
    process.exit(0);
  }

  const hash = await hashPassword(password);
  const userResult = await pool.query(
    `INSERT INTO utilisateurs (ecole_id, nom, prenom, email, mot_de_passe_hash)
     VALUES (NULL, 'Super', 'Admin', $1, $2)
     RETURNING id`,
    [email, hash]
  );
  const userId = userResult.rows[0].id;

  await pool.query(
    `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, 'super_admin')`,
    [userId]
  );

  console.log(`Super Admin créé avec succès : ${email}`);
  process.exit(0);
}

seed().catch((err) => {
  console.error('Erreur lors de la création du Super Admin:', err);
  process.exit(1);
});
