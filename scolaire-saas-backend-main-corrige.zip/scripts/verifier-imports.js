#!/usr/bin/env node
/**
 * VÉRIFICATEUR STATIQUE DES IMPORTS INTERNES — Ardoise
 * ===========================================================================
 * `node --check` ne vérifie que la SYNTAXE. Il ne détecte ni un `require`
 * vers un fichier inexistant, ni un nom destructuré que le module cible
 * n'exporte pas. Cette catégorie de bug a déjà été livrée deux fois sur ce
 * projet (voir HANDOVER §11 bis « Méthode : angle mort constaté »).
 *
 * Un vrai `require()` l'attraperait, mais il exige `npm install` — impossible
 * dans un environnement sans réseau. Ce script fait la vérification par
 * analyse statique : il ne charge rien, donc il fonctionne partout.
 *
 * Ce qu'il contrôle :
 *   1. tout require relatif pointe vers un fichier
 *      réellement présent ;
 *   2. tout nom destructuré importé est bien
 *      exporté par `x` ;
 *   3. tout `ctrl.machin` utilisé dans un fichier de routes correspond à un
 *      export du contrôleur — c'est exactement le cas qui produit
 *      « Route.get() requires a callback function but got a [object Undefined] »
 *      au démarrage, en production.
 *
 * Usage : node scripts/verifier-imports.js (aucune dependance)
 * Sortie : code 0 si tout est cohérent, 1 sinon.
 */

const fs = require('fs');
const path = require('path');

const RACINE = path.resolve(__dirname, '..');
const DOSSIERS = ['controllers', 'routes', 'middleware', 'utils', 'config', 'scripts'];

/** Tous les fichiers .js du projet (hors node_modules). */
function fichiersJs() {
  const liste = [];
  for (const dossier of DOSSIERS) {
    const complet = path.join(RACINE, dossier);
    if (!fs.existsSync(complet)) continue;
    for (const nom of fs.readdirSync(complet)) {
      if (nom.endsWith('.js')) liste.push(path.join(complet, nom));
    }
  }
  for (const nom of fs.readdirSync(RACINE)) {
    if (nom.endsWith('.js')) liste.push(path.join(RACINE, nom));
  }
  return liste;
}

/**
 * Noms exportés par un module, par analyse du texte.
 *
 * Trois formes couvrent tout le projet :
 *   module.exports = { a, b, c };
 *   module.exports = { a: f, b };
 *   module.exports.a = ...   /   exports.a = ...
 */
function exportsDe(source) {
  const noms = new Set();

  // `module.exports = { … }` : on équilibre les accolades plutôt que d'espérer
  // un formatage particulier. Une expression non gourmande s'arrête au premier
  // `}` venu — y compris celui d'un objet imbriqué — et une expression exigeant
  // `\n}` rate toutes les listes écrites sur une seule ligne. Les deux erreurs
  // rendent le contrôle inutile en signalant la totalité du projet.
  const debut = source.search(/module\.exports\s*=\s*\{/);
  if (debut !== -1) {
    const ouvrante = source.indexOf('{', debut);
    let profondeur = 0;
    let fin = -1;
    for (let i = ouvrante; i < source.length; i++) {
      if (source[i] === '{') profondeur++;
      else if (source[i] === '}') {
        profondeur--;
        if (profondeur === 0) { fin = i; break; }
      }
    }
    if (fin !== -1) {
      // Les commentaires sont retirés AVANT le découpage : un commentaire de
      // fin de liste contient presque toujours des virgules, et découper
      // d'abord ferait passer le nom qui le suit pour du texte libre. C'est
      // exactement ce qui masquait `recalculerClassement` et `appelerIAVision`,
      // pourtant tous deux bien exportés.
      const corps = source.slice(ouvrante + 1, fin)
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\/\/[^\n]*/g, '');
      // Seules les clés de PREMIER niveau nous intéressent : une valeur qui est
      // elle-même un objet ne doit pas voir ses propres clés remonter.
      let niveau = 0;
      let courant = '';
      const morceaux = [];
      for (const c of corps) {
        if ('{(['.includes(c)) niveau++;
        else if ('})]'.includes(c)) niveau--;
        if (c === ',' && niveau === 0) { morceaux.push(courant); courant = ''; continue; }
        courant += c;
      }
      morceaux.push(courant);

      for (const brut of morceaux) {
        const propre = brut.trim();
        if (!propre) continue;
        const m = propre.match(/^([A-Za-z_$][\w$]*)\s*(?::|$)/);
        if (m) noms.add(m[1]);
      }
    }
  }

  for (const m of source.matchAll(/(?:module\.)?exports\.([A-Za-z_$][\w$]*)\s*=/g)) {
    noms.add(m[1]);
  }

  // module.exports = uneFonction;  → export par défaut, pas de nom à vérifier.
  if (/module\.exports\s*=\s*[A-Za-z_$][\w$]*\s*;/.test(source)) noms.add('*defaut*');

  return noms;
}

/** Résout un chemin de require relatif vers un fichier existant. */
function resoudre(depuis, cible) {
  const base = path.resolve(path.dirname(depuis), cible);
  for (const candidat of [base, base + '.js', path.join(base, 'index.js')]) {
    if (fs.existsSync(candidat) && fs.statSync(candidat).isFile()) return candidat;
  }
  return null;
}

const anomalies = [];
const sources = new Map();
for (const f of fichiersJs()) sources.set(f, fs.readFileSync(f, 'utf8'));

const cacheExports = new Map();
function exportsFichier(f) {
  if (!cacheExports.has(f)) cacheExports.set(f, exportsDe(sources.get(f) || fs.readFileSync(f, 'utf8')));
  return cacheExports.get(f);
}

for (const [fichier, source] of sources) {
  const relatif = path.relative(RACINE, fichier);

  // --- 1 & 2 : requires relatifs et noms destructurés ---
  const motif = /(?:const|let|var)\s+(\{[^}]*\}|[A-Za-z_$][\w$]*)\s*=\s*require\(\s*['"](\.[^'"]+)['"]\s*\)/g;
  for (const m of source.matchAll(motif)) {
    const [, lie, chemin] = m;
    const cible = resoudre(fichier, chemin);
    if (!cible) {
      anomalies.push(`${relatif} : require('${chemin}') → fichier introuvable`);
      continue;
    }
    if (!lie.startsWith('{')) continue;

    const dispo = exportsFichier(cible);
    if (dispo.has('*defaut*') && dispo.size === 1) continue; // export par défaut
    for (const brut of lie.slice(1, -1).split(',')) {
      const propre = brut.split(':')[0].trim();
      if (!propre) continue;
      if (!dispo.has(propre)) {
        anomalies.push(
          `${relatif} : « ${propre} » n'est pas exporté par ${path.relative(RACINE, cible)}`
        );
      }
    }
  }

  // --- 2 bis : constantes de projet employées sans être définies ---
  //
  // `CURRENT_ECOLE` est recopiée en tête de presque tous les contrôleurs. Elle
  // s'emploie DANS des gabarits de chaîne (`${CURRENT_ECOLE}`), donc une copie
  // oubliée ne se voit ni à la lecture ni avec `node --check` : elle produit un
  // `ReferenceError` au premier appel de la route, en production.
  // Le cas s'est produit pendant cet audit même, en portant une requête d'un
  // fichier à un autre.
  if (relatif !== path.join('scripts', 'verifier-imports.js')
      && /\$\{CURRENT_ECOLE\}/.test(source)
      && !/const\s+CURRENT_ECOLE\s*=/.test(source)) {
    anomalies.push(`${relatif} : emploie CURRENT_ECOLE sans la définir`);
  }

  // --- 3 : handlers de routes (ctrl.machin) ---
  if (!relatif.startsWith('routes' + path.sep)) continue;

  /* LES COMMENTAIRES SONT NEUTRALISÉS D'ABORD.

     Sans cela, l'outil se trompait de cible d'une façon particulièrement
     déroutante. Le balayage cherche `router.get(...)` jusqu'au premier `);`.
     Un commentaire qui CITE une ligne de code — « les routes héritent du
     router.use(authMiddleware, superAdminSeul) posé plus haut » — ouvre donc
     une capture qui ne se referme pas dans le commentaire, déborde sur le
     vrai code qui suit, et y ramasse le premier `objet.propriete` venu.

     L'outil annonçait alors « handler prospects.controller absent de
     controllers/prospects.controller.js » : un message qui désigne un fichier
     parfaitement sain, pour un handler qui n'existe pas, à cause d'une phrase
     en français. On perd un temps considérable à chercher un défaut qui n'est
     pas là — et on finit par se méfier de l'outil, ce qui est le vrai coût.

     Les positions sont préservées (chaque caractère devient une espace, les
     retours à la ligne sont conservés) pour que d'éventuels numéros de ligne
     restent justes. */
  const codeSeul = source
    .replace(/\/\*[\s\S]*?\*\//g, (bloc) => bloc.replace(/[^\n]/g, ' '))
    .replace(/(?<!:)\/\/[^\n]*/g, (ligne) => ligne.replace(/[^\n]/g, ' '));

  const alias = new Map();
  for (const m of codeSeul.matchAll(
    /(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*require\(\s*['"](\.[^'"]+)['"]\s*\)/g)) {
    const cible = resoudre(fichier, m[2]);
    if (cible) alias.set(m[1], cible);
  }

  for (const m of codeSeul.matchAll(
    /router\.(?:get|post|put|patch|delete|use)\s*\(([\s\S]*?)\)\s*;/g)) {
    for (const usage of m[1].matchAll(/\b([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)\b/g)) {
      const [, objet, methode] = usage;
      if (!alias.has(objet)) continue;
      const cible = alias.get(objet);
      const dispo = exportsFichier(cible);
      if (dispo.has('*defaut*') && dispo.size === 1) continue;
      if (!dispo.has(methode)) {
        anomalies.push(
          `${relatif} : handler ${objet}.${methode} absent de ${path.relative(RACINE, cible)}`
        );
      }
    }
  }
}

if (anomalies.length === 0) {
  console.log(`✓ ${sources.size} fichiers analysés — aucun import ni handler cassé.`);
  process.exit(0);
}

console.error(`✗ ${anomalies.length} anomalie(s) :\n`);
for (const a of [...new Set(anomalies)].sort()) console.error('  · ' + a);
process.exit(1);
