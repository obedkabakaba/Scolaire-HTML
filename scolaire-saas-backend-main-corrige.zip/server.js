require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const authRoutes = require('./routes/auth.routes');
const ecolesRoutes = require('./routes/ecoles.routes');
const utilisateursRoutes = require('./routes/utilisateurs.routes');
const structureRoutes = require('./routes/structure.routes');
const elevesRoutes = require('./routes/eleves.routes');
const notesRoutes = require('./routes/notes.routes');
const travauxRoutes = require('./routes/travaux.routes');
const bulletinsRoutes = require('./routes/bulletins.routes');
const jobsRoutes = require('./routes/jobs.routes');
const abonnementsRoutes = require('./routes/abonnements.routes');
const calendrierRoutes = require('./routes/calendrier.routes');
const dashboardRoutes = require('./routes/dashboard.routes');
const modelesBulletinsRoutes = require('./routes/modeles-bulletins.routes');
const journalRoutes = require('./routes/journal.routes');
const notificationsRoutes = require('./routes/notifications.routes');
const fraisRoutes = require('./routes/frais.routes');
const promotionRoutes = require('./routes/promotion.routes');
const uploadsRoutes = require('./routes/uploads.routes');
const ecoleParametresRoutes = require('./routes/ecole-parametres.routes');
const mentionsRoutes = require('./routes/mentions.routes');
const paiementsRoutes = require('./routes/paiements.routes');
const presencesRoutes = require('./routes/presences.routes');
const emploiDuTempsRoutes = require('./routes/emploi-du-temps.routes');
const publicRoutes = require('./routes/public.routes');
// Catalogue commercial : offres, services complémentaires, estimation de
// campagne. Public, sans jeton — voir controllers/catalogue.controller.js.
const catalogueRoutes = require('./routes/catalogue.routes');
const sitePublicRoutes = require('./routes/site-public.routes');
const disciplineRoutes = require('./routes/discipline.routes');
const archivesRoutes = require('./routes/archives.routes');
const rapportsRoutes = require('./routes/rapports.routes');
const communicationRoutes = require('./routes/communication.routes');
const iaRoutes = require('./routes/ia.routes');
const whatsappRoutes = require('./routes/whatsapp.routes');
const inscriptionsRoutes = require('./routes/inscriptions.routes');
const orientationRoutes = require('./routes/orientation.routes');

const app = express();

// Render (comme la plupart des hébergeurs) place l'app derrière un proxy inverse.
// Nécessaire pour qu'express-rate-limit identifie correctement l'IP réelle du client.
app.set('trust proxy', 1);

app.use(helmet());

// CORS restreint aux origines déclarées.
//
// `app.use(cors())` acceptait TOUTE origine. Sur une API portée par un jeton
// dans l'en-tête `Authorization`, ce n'est pas une fuite immédiate — un site
// tiers ne possède pas le jeton du visiteur. Mais cela laisse n'importe quel
// site appeler l'API depuis le navigateur d'un utilisateur connecté dès que le
// jeton lui parvient d'une autre manière (extension, script injecté, page de
// hameçonnage qui le demande), et cela supprime le dernier filet en cas de
// bascule future vers un cookie de session.
//
// ORIGINES_AUTORISEES : liste séparée par des virgules dans l'environnement.
// Non renseignée, on retombe sur l'ancien comportement PLUTÔT QUE DE TOUT
// BLOQUER : une école en production ne doit pas se retrouver hors service
// parce qu'une variable manque. L'avertissement au démarrage est là pour que
// ça ne dure pas.
const originesAutorisees = (process.env.ORIGINES_AUTORISEES || '')
  .split(',').map((o) => o.trim()).filter(Boolean);

if (originesAutorisees.length === 0) {
  console.warn(
    '[CORS] ORIGINES_AUTORISEES non renseignée : toutes les origines sont acceptées. '
    + 'À définir avant la mise en production, par exemple : '
    + 'ORIGINES_AUTORISEES=https://ardoise.cd,https://www.ardoise.cd'
  );
  app.use(cors());
} else {
  app.use(cors({
    origin: (origine, retour) => {
      // Origine absente : appel serveur à serveur, cron, ou outil en ligne de
      // commande. Ce ne sont pas des requêtes de navigateur, CORS ne les
      // concerne pas.
      if (!origine) return retour(null, true);
      if (originesAutorisees.includes(origine)) return retour(null, true);
      return retour(new Error(`Origine non autorisée : ${origine}`));
    },
    credentials: true
  }));
}
app.use(morgan('dev'));

// Collecteur de métriques de l'espace Super Admin (page « Santé de la
// plateforme »). Posé en tout premier, avant le limiteur de débit : une
// requête rejetée par le rate-limit reste une requête reçue, et c'est
// précisément le genre d'événement qu'on veut voir sur la courbe.
// Coût : quelques micro-secondes et aucune écriture — tout vit en mémoire.
app.use(require('./middleware/metriques.middleware').collecteur);

/* Identifiant de corrélation, puis capture PERSISTANTE des erreurs serveur.
 *
 * Le collecteur ci-dessus garde route, statut et durée — en mémoire, donc
 * jusqu'au prochain déploiement Render. Ces deux-là conservent la CAUSE, en
 * base, pour le centre de bugs du Super Admin. Ils sont posés au même endroit
 * pour couvrir exactement le même périmètre : toute requête reçue, y compris
 * celles que le limiteur de débit rejettera juste après.
 *
 * Coût : aucune écriture tant qu'aucune réponse ne dépasse 499. */
const erreurs = require('./middleware/erreurs.middleware');
app.use(erreurs.correlation);
app.use(erreurs.capteur);

app.use(require('./middleware/rate-limit.middleware').limiteurGeneral);
// Le corps brut est conservé : la signature Meta du webhook WhatsApp se
// vérifie sur les octets reçus, pas sur l'objet reconstruit après analyse.
app.use(express.json({
  limit: '2mb',
  verify: (req, res, tampon) => { req.rawBody = tampon.toString('utf8'); }
}));

app.get('/', (req, res) => {
  res.json({ status: 'ok', service: 'scolaire-saas-backend' });
});

// Catalogue commercial du site public. Monté ICI, avant le verrou
// d'authentification posé plus bas : la page d'accueil de myardoise.com doit
// pouvoir afficher les tarifs à un visiteur qui n'a évidemment pas de compte.
// Ses quatre routes sont limitées en débit individuellement et ne lisent que
// deux tables de catalogue — aucune donnée d'école n'en sort.
app.use('/catalogue', catalogueRoutes);

/* Ingestion des rapports d'audit statique. Monté ICI, avant le verrou
 * d'authentification, pour la même raison que le catalogue : l'appelant est
 * une intégration continue, pas une personne. Il s'authentifie par le secret
 * technique AUDIT_INGEST_SECRET, vérifié en temps constant dans le contrôleur,
 * et ne peut écrire que dans les deux tables d'audit. Sans ce secret configuré,
 * le point d'entrée est FERMÉ — pas ouvert en attendant. */
app.use('/audits', require('./routes/audits.routes'));

// Journalisation automatique de toute action modifiant l'état, ainsi que des
// connexions et de quelques consultations sensibles.
//
// Posé ICI, avant /auth et avant toutes les routes métier, pour deux raisons :
//   · il couvre les connexions et déconnexions, qui échappent au middleware
//     d'authentification monté plus bas ;
//   · il n'écrit qu'à l'événement 'finish' de la réponse, donc APRÈS que
//     toute la chaîne a tourné : `req.auth` est déjà renseigné à ce moment-là
//     pour les routes authentifiées, bien qu'il ne le soit pas ici.
//
// Il ne peut pas faire échouer une requête : voir middleware/journal.middleware.js.
app.use(require('./middleware/journal.middleware'));

app.use('/auth', authRoutes);

// Verrou du mot de passe provisoire : posé APRÈS /auth pour que la connexion
// reste possible, et AVANT toutes les autres routes pour qu'aucune ne puisse
// être atteinte tant que le mot de passe n'a pas été changé.
const motDePasseProvisoire = require('./middleware/mot-de-passe-provisoire.middleware');
const authMiddlewarePrincipal = require('./middleware/auth.middleware');
const { verrouObservation } = require('./middleware/super-admin.middleware');
app.use(function (req, res, next) {
  // Le webhook WhatsApp est public et vérifie lui-même sa signature HMAC
  // (voir controllers/whatsapp.controller.js). S'il reçoit un en-tête
  // Authorization qui ne lui est pas destiné (Meta, ou tout intermédiaire
  // sur le chemin de l'appel), il ne doit surtout pas être détourné vers la
  // vérification JWT applicative : sans ce garde-fou, un en-tête mal formé
  // renvoie 401 avant même d'atteindre le contrôleur, et l'assistant IA ne
  // répond jamais — alors même que côté WhatsApp le message semble livré.
  if (req.path === '/whatsapp/webhook') return next();
  if (!req.headers.authorization) return next();   // routes publiques
  authMiddlewarePrincipal(req, res, function (err) {
    if (err) return next(err);
    motDePasseProvisoire(req, res, function (err2) {
      if (err2) return next(err2);
      // Verrou du mode « Voir comme » (espace Super Admin).
      //
      // Placé ICI, et nulle part ailleurs, pour une raison précise : le jeton
      // d'observation porte les rôles de la personne observée. Passé ce point,
      // plus rien dans l'application ne peut le distinguer d'un vrai directeur
      // — ni requireRole(), ni les policies RLS, ni les contrôleurs. C'est donc
      // le dernier endroit où la distinction existe encore, et le seul où le
      // verrou couvre toutes les routes, présentes et futures.
      verrouObservation(req, res, next);
    });
  });
});

// Espace Super Administrateur. Monté avant les routes métier : ses chemins ne
// croisent aucun des leurs, et le placer ici évite qu'un futur `app.use('/')`
// ne l'absorbe par accident.
app.use('/super-admin', require('./routes/super-admin.routes'));
app.use('/admin/ecoles', ecolesRoutes);
app.use('/utilisateurs', utilisateursRoutes);
app.use('/eleves', elevesRoutes);
app.use('/notes', notesRoutes);
app.use('/travaux', travauxRoutes);
app.use('/bulletins', bulletinsRoutes);
app.use('/jobs', jobsRoutes);
app.use('/abonnements', abonnementsRoutes);
// Services complémentaires : prestations achetables séparément de
// l'abonnement. Route distincte de /abonnements, volontairement : les deux
// étages commerciaux ne se mélangent pas davantage dans l'API que sur la
// page de tarifs.
app.use('/services', require('./routes/services.routes'));
app.use('/evenements', calendrierRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/modeles-bulletins', modelesBulletinsRoutes);
app.use('/journal-activite', journalRoutes);
// Aide à l'utilisation : ouverte à tous les rôles, sans accès aux données.
app.use('/assistant', require('./routes/assistant.routes'));
/* Signalement d'incident par un utilisateur ORDINAIRE.
 *
 * Monté hors de /super-admin, et c'est tout l'objet du correctif : la route
 * historique `/super-admin/bugs/signaler` est derrière `superAdminSeul`, si
 * bien qu'aucune erreur de directeur, de professeur ou de comptable n'était
 * jamais enregistrée — malgré un commentaire qui prétendait le contraire.
 *
 * Écriture seule. La LECTURE du centre de bugs reste réservée au Super Admin. */
app.use('/incidents', require('./routes/incidents.routes'));
// Reconduction annuelle et clôture de période. Monté à la racine : les chemins
// sont /reconduction/* et /periodes/:id/*, qui touchent deux domaines.
app.use('/', require('./routes/cloture.routes'));
// Comptabilité : caisse, charges, paie.
app.use('/comptabilite', require('./routes/comptabilite.routes'));
// Examen de repêchage de fin d'année.
app.use('/repechage', require('./routes/repechage.routes'));
app.use('/notifications', notificationsRoutes);
app.use('/frais', fraisRoutes);
app.use('/promotion', promotionRoutes);
app.use('/uploads', uploadsRoutes);
app.use('/ecole', ecoleParametresRoutes);
app.use('/mentions', mentionsRoutes);
app.use('/paiements', paiementsRoutes);
app.use('/presences', presencesRoutes);
app.use('/emploi-du-temps', emploiDuTempsRoutes);
app.use('/public', publicRoutes);
app.use('/site-public', sitePublicRoutes);
app.use('/discipline', disciplineRoutes);
app.use('/archives', archivesRoutes);
app.use('/rapports', rapportsRoutes);
app.use('/communication', communicationRoutes);
app.use('/ia', iaRoutes);
app.use('/whatsapp', whatsappRoutes);
app.use('/inscriptions', inscriptionsRoutes);
app.use('/orientation', orientationRoutes);
app.use('/', structureRoutes); // expose /annees-scolaires, /options, /classes, /cours, /classe-cours

/* Gestionnaire d'erreurs final.
 *
 * Il se contentait d'un `console.error(err)` : la pile d'appels partait dans
 * les journaux Render, où elle vivait jusqu'au redéploiement suivant et où
 * personne n'allait la chercher. Elle est désormais conservée en base, avec
 * son empreinte, son compteur d'occurrences et sa réouverture automatique.
 *
 * Le message servi à l'utilisateur est INCHANGÉ : la cause technique va au
 * Super Admin, jamais à l'écran. */
app.use(erreurs.gestionnaireFinal);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend démarré sur le port ${PORT}`);
});

// Relevé périodique des métriques → table `metriques_plateforme`.
//
// Le collecteur vit en mémoire : un redéploiement Render efface la courbe.
// Ce relevé toutes les cinq minutes en conserve l'essentiel, à raison de
// quelques lignes par relevé — négligeable comparé au journal d'activité.
// Désactivable par METRIQUES_HISTORIQUE=non (utile en développement).
if (process.env.METRIQUES_HISTORIQUE !== 'non') {
  const { resume } = require('./middleware/metriques.middleware');
  const { runWithTenant } = require('./config/db');

  const releve = setInterval(async () => {
    try {
      const m = resume(5);
      // Rien ne s'est passé depuis cinq minutes : inutile d'écrire une ligne
      // de zéros, elle ne raconterait rien qu'un trou dans la courbe ne dise.
      if (!m.requetes) return;

      await runWithTenant({ isSuperAdmin: true }, (client) =>
        client.query(
          `INSERT INTO metriques_plateforme (categorie, cle, valeur)
           SELECT * FROM unnest(
             ARRAY['api','api','api','api']::text[],
             ARRAY['requetes','latence_moyenne_ms','latence_p95_ms','taux_erreur']::text[],
             ARRAY[$1,$2,$3,$4]::numeric[]
           )`,
          [m.requetes, m.latence_moyenne_ms, m.latence_p95_ms, m.taux_erreur]
        )
      );
    } catch (err) {
      // Un relevé raté n'a aucune conséquence : on ne bruite pas les journaux.
      if (process.env.NODE_ENV !== 'production') {
        console.warn('Relevé de métriques ignoré :', err.message);
      }
    }
  }, 5 * 60 * 1000);

  releve.unref();
}
