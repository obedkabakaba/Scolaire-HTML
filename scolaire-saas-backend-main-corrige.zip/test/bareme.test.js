/**
 * TESTS — règle du barème et non-régression des défauts trouvés à l'audit
 * ===========================================================================
 * Aucune dépendance, aucune base : `node test/bareme.test.js`.
 *
 * Ces tests ne prouvent PAS que l'application fonctionne contre PostgreSQL.
 * Ils verrouillent trois choses vérifiables sans base :
 *   1. la règle de barème elle-même, en JavaScript ;
 *   2. la FORME du fragment SQL produit (un COALESCE simple y ferait revenir
 *      le bug du repli à 0) ;
 *   3. l'absence, dans le code, des motifs exacts qui ont produit les défauts
 *      corrigés — c'est le seul moyen d'empêcher leur réapparition par
 *      copier-coller, qui est la façon dont ils se sont propagés.
 */

const fs = require('fs');
const path = require('path');
const { maximumApplicable, sqlMaximumApplicable } = require('../utils/bareme.utils');

const RACINE = path.resolve(__dirname, '..');
let reussis = 0;
const echecs = [];

function verifier(intitule, condition, detail) {
  if (condition) { reussis++; return; }
  echecs.push(intitule + (detail ? ` — ${detail}` : ''));
}

function lire(relatif) {
  return fs.readFileSync(path.join(RACINE, relatif), 'utf8');
}

/* ---------------------------------------------------------------- 1. règle */

verifier('période ordinaire : le maximum est celui de la période',
  maximumApplicable(20, null, 'periode') === 20);

verifier('période ordinaire : le maximum d\'examen est ignoré',
  maximumApplicable(20, 40, 'periode') === 20);

verifier('examen sans barème configuré (NULL) : 2 × la période',
  maximumApplicable(20, null, 'examen') === 40);

verifier('examen sans barème configuré (undefined) : 2 × la période',
  maximumApplicable(20, undefined, 'examen') === 40);

verifier('examen à 0 : le cours n\'est pas examiné',
  maximumApplicable(20, 0, 'examen') === 0);

verifier('examen à 0 ne doit PAS être confondu avec NULL',
  maximumApplicable(20, 0, 'examen') !== maximumApplicable(20, null, 'examen'));

verifier('examen avec barème explicite : ce barème',
  maximumApplicable(20, 50, 'examen') === 50);

verifier('cours à maximum 10 en examen : 20',
  maximumApplicable(10, null, 'examen') === 20);

/* ------------------------------------------------------- 2. fragment SQL */

const sql = sqlMaximumApplicable('cc', 'co', 'p.type::text');

verifier('le SQL distingue la période d\'examen', /'examen'/.test(sql));
verifier('le SQL double le maximum de période quand l\'examen est NULL',
  /IS NULL THEN[\s\S]*\* 2/.test(sql));
verifier('le SQL lit les deux overrides de classe_cours',
  sql.includes('cc.maximum_points_override') && sql.includes('cc.maximum_examen_override'));
verifier('le SQL ne replie JAMAIS le maximum d\'examen sur 0',
  !/maximum_examen\s*,\s*0\s*\)/.test(sql),
  'un COALESCE(..., maximum_examen, 0) ferait revenir le bug du repêchage');

/* ------------------------------- 3. motifs interdits, fichier par fichier */

const REPLI_ZERO = /COALESCE\([^)]*maximum_examen[^)]*,\s*0\s*\)/;
for (const f of ['controllers/repechage.controller.js', 'controllers/parcours.controller.js']) {
  verifier(`${f} : plus de repli du maximum d'examen sur 0`, !REPLI_ZERO.test(lire(f)));
}

const notes = lire('controllers/notes.controller.js');
verifier('notes.controller : resoudreClasseCours reçoit la période',
  /resoudreClasseCours\(client, classeId, coursId, periodeId\)/.test(notes));
verifier('notes.controller : le classement emploie la règle de barème',
  notes.includes('sqlMaximumApplicable'));
verifier('notes.controller : plus de dénominateur figé sur le maximum de période',
  !/SUM\(COALESCE\(cc\.maximum_points_override, c\.maximum_points\)\)/.test(notes));

const promotion = lire('controllers/promotion.controller.js');
verifier('promotion : ne lit plus AVG(bulletins.pourcentage)',
  !/AVG\(b\.pourcentage\)/.test(promotion),
  'la décision de passage se prenait sur une valeur matérialisée et moyennée');
verifier('promotion : emploie la source unique des moyennes',
  promotion.includes('pourcentagesParEleve'));

/* ---- LIMIT 1 sur frais_scolaires : le motif qui sous-estimait les dettes ---- */

const FICHIERS_FRAIS = [
  'controllers/rapports.controller.js',
  'controllers/frais.controller.js',
  'controllers/dashboard.controller.js',
  'controllers/public.controller.js',
  'controllers/parcours.controller.js',
];
for (const f of FICHIERS_FRAIS) {
  const contenu = lire(f);
  // Signature exacte du défaut : un LIMIT 1 qui sélectionne un MONTANT.
  //
  // Un LIMIT 1 qui ne ramène que la DEVISE de référence reste légitime — c'est
  // la ligne la plus spécifique qui dit dans quelle monnaie l'école compte — et
  // ne doit pas faire échouer ce test, sans quoi la seule façon de le rendre
  // vert serait de supprimer une requête correcte.
  const suspect = /SELECT[^;]{0,200}montant[\s\S]{0,400}?FROM frais_scolaires[\s\S]{0,400}?ORDER BY[^\n]*classe_id NULLS LAST\s*\n\s*LIMIT 1/.test(contenu);
  verifier(`${f} : plus de LIMIT 1 sur frais_scolaires`, !suspect);
}

const parcours = lire('controllers/parcours.controller.js');
verifier('parcours : les frais dus passent par la règle commune',
  parcours.includes('sqlTotalFraisDus'));
verifier('parcours : les versements sont convertis avant sommation',
  parcours.includes('sqlPaiementConverti'),
  'SUM(montant) brut additionnait des FC et des USD');

/* ------------------------------------- bulletins : pas de rang factice ---- */

// Un élève sans aucune cote n'est plus filtré APRÈS coup : il n'entre pas dans
// le calcul du tout, puisque `pourcentagesParEleve` avec `inclureNonNotes:
// false` ne le renvoie pas. Le test vérifie donc la cause, pas le symptôme.
for (const f of ['controllers/bulletin-semestre.controller.js',
                 'controllers/bulletin-annuel.controller.js']) {
  const contenu = lire(f);
  verifier(`${f} : un élève sans cote n'entre pas dans le classement`,
    /inclureNonNotes: false/.test(contenu),
    'sinon il reçoit un rang factice en fin de liste (§9.3)');
  verifier(`${f} : le rang est compté séparément de l'indice de boucle`,
    /let rang = 0;[\s\S]{0,400}\+\+rang/.test(contenu));
}

/* ------------------ bulletins de regroupement : somme, jamais moyenne ------ */

for (const f of ['controllers/bulletin-semestre.controller.js',
                 'controllers/bulletin-annuel.controller.js']) {
  const contenu = lire(f);
  verifier(`${f} : ne moyenne plus les pourcentages`,
    !/AVG\(b\.pourcentage\)/.test(contenu),
    'le total d\'un semestre est P1 + P2 + examen, pas la moyenne de leurs %');
  verifier(`${f} : emploie la source unique des moyennes`,
    contenu.includes('pourcentagesParEleve'));
  verifier(`${f} : enregistre aussi le total de points`,
    /total = EXCLUDED\.total/.test(contenu),
    'la ligne stockée doit dire d\'où viennent le rang et la mention');
}

const annuel = lire('controllers/bulletin-annuel.controller.js');
verifier('bulletin annuel : les TRIMESTRES du primaire sont pris en compte',
  /IN \('semestre', 'trimestre'\)/.test(annuel),
  'un filtre sur le seul type semestre vidait le bulletin annuel du primaire');

/* ------------------------------------ contrôleur public : année et classe -- */

const pub = lire('controllers/public.controller.js');
verifier('public : les bulletins sont filtrés sur l\'année scolaire',
  /p\.annee_scolaire_id = \$2/.test(pub),
  'sinon les périodes de plusieurs années se mélangent chez le parent');
verifier('public : l\'effectif se compte sur classe_id, pas sur le nom',
  /e\.classe_id = \$1/.test(pub) && !/c\.nom = \$1/.test(pub));

/* ---------------- verrou de période : partagé, pas enfermé ----------------- */

verifier('le verrou de période est un utilitaire partagé',
  fs.existsSync(path.join(RACINE, 'utils/periode.utils.js')),
  'enfermé dans notes.controller, il ne protégeait que la saisie des cotes');

for (const f of ['controllers/notes.controller.js',
                 'controllers/discipline.controller.js',
                 'controllers/ia.controller.js']) {
  const contenu = lire(f);
  verifier(`${f} : applique le verrou de période`,
    contenu.includes("require('../utils/periode.utils')")
      && /await verifierPeriodeModifiable\(/.test(contenu),
    'ce module écrit dans la table bulletins : la clôture doit valoir pour lui aussi');
}

verifier('le verrou n\'est plus redéfini localement dans notes.controller',
  !/^async function verifierPeriodeModifiable/m.test(lire('controllers/notes.controller.js')),
  'deux copies divergeraient dès la première correction');

/* -------------------------------- contrôleurs dupliqués hors de leur place -- */

for (const mort of ['routes/super-admin.controller.js', 'routes/abonnements.controller.js']) {
  verifier(`${mort} : copie égarée supprimée`,
    !fs.existsSync(path.join(RACINE, mort)),
    'la version chargée par server.js était l\'ancienne');
}
const abo = lire('controllers/abonnements.controller.js');
verifier('abonnements : la liste des méthodes de paiement est exportée',
  /METHODES_PAIEMENT/.test(abo),
  'sans elle, l\'encaissement d\'abonnement en espèces reste inutilisable');

/* --------------------------------------------------- assemblage officiel -- */

const assemblage = lire('utils/bulletin-assemblage-officiel.js');
verifier('grouperParDomaine est exportée (bulletin primaire)',
  /grouperParDomaine,/.test(assemblage.slice(assemblage.indexOf('module.exports'))));
verifier('bulletin-semestre importe une fonction qui existe',
  lire('controllers/bulletin-semestre.controller.js').includes('assemblerDonneesSemestre'));

/* ------------------------------------------------------------------ bilan */

console.log(`\n${reussis} vérification(s) réussie(s), ${echecs.length} échec(s).`);
if (echecs.length) {
  for (const e of echecs) console.error('  ✗ ' + e);
  process.exit(1);
}
console.log('✓ Toutes les vérifications passent.');
