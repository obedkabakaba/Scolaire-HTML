/**
 * Tests du catalogue commercial.
 *
 * Ils portent sur ce qui produit un CHIFFRE affiché à un directeur : le prix
 * d'une campagne de capture, l'économie annoncée sur l'annuel, la durée
 * ajoutée à un abonnement. Un défaut à cet endroit ne provoque pas une erreur
 * 500 : il provoque une facture fausse, ce qui se remarque bien plus tard et
 * bien plus mal.
 *
 *   node --test test/catalogue.test.js
 */

const test = require('node:test');
const assert = require('node:assert');
const catalogue = require('../utils/catalogue.utils');

/* ------------------------------------------------------------------ Services */

const CAPTURE = {
  code: 'campagne_capture', mode_tarification: 'par_eleve',
  prix_unitaire: 0.5, devise: 'USD', unite: 'élève', quantite_minimum: null
};
const INSTALLATION = {
  code: 'installation', mode_tarification: 'forfait',
  prix_unitaire: 60, devise: 'USD', unite: null, quantite_minimum: null
};

test('campagne de capture : la grille du cahier des charges au centime près', () => {
  const attendu = [[100, 50], [300, 150], [500, 250], [1000, 500], [2000, 1000]];
  for (const [eleves, prix] of attendu) {
    assert.strictEqual(
      catalogue.calculerMontantService(CAPTURE, eleves).montant_total, prix,
      `${eleves} élèves devraient coûter ${prix} $`);
  }
});

test('campagne de capture : un nombre décimal est ramené à l\'entier inférieur', () => {
  // 250,7 élèves n'existe pas. Arrondir au supérieur ferait payer un élève
  // fantôme ; on tronque, au bénéfice de l'école.
  assert.strictEqual(catalogue.calculerMontantService(CAPTURE, 250.7).montant_total, 125);
});

test('campagne de capture : zéro et négatif sont refusés, pas facturés', () => {
  for (const mauvais of [0, -10, 'beaucoup', null, undefined]) {
    assert.throws(() => catalogue.calculerMontantService(CAPTURE, mauvais),
      /supérieur à zéro/, `${mauvais} aurait dû être refusé`);
  }
});

test('forfait : la quantité envoyée par le client est ignorée', () => {
  // Sans cela, un client bricolé enverrait quantite=0 et obtiendrait une
  // installation à 0 $.
  for (const q of [1, 99, 0, undefined]) {
    assert.strictEqual(catalogue.calculerMontantService(INSTALLATION, q).montant_total, 60);
  }
});

test('quantité minimum : facturée sans jamais fausser la quantité déclarée', () => {
  const avecMinimum = { ...CAPTURE, quantite_minimum: 100 };
  const r = catalogue.calculerMontantService(avecMinimum, 40);
  assert.strictEqual(r.quantite, 40, 'la quantité réelle reste celle demandée');
  assert.strictEqual(r.quantite_facturee, 100);
  assert.strictEqual(r.montant_total, 50);
  assert.strictEqual(r.minimum_applique, 100, 'le minimum appliqué doit être dit, pas caché');
});

/* ------------------------------------------------------------------- Durées */

test('durée : chaque périodicité ajoute sa vraie durée, pas trente jours', () => {
  assert.strictEqual(catalogue.joursDePeriodicite('mensuel', 30), 30);
  assert.strictEqual(catalogue.joursDePeriodicite('semestriel', 30), 182);
  assert.strictEqual(catalogue.joursDePeriodicite('annuel', 30), 365);
});

test('durée : une périodicité inconnue retombe sur le plan, jamais sur zéro', () => {
  assert.strictEqual(catalogue.joursDePeriodicite('personnalise', 45), 45);
  assert.strictEqual(catalogue.joursDePeriodicite(null, null), 30);
});

/* -------------------------------------------------- Économies affichées */

test('économies : elles sont calculées, jamais inventées', () => {
  // On rejoue la grille réelle. Si un jour quelqu'un saisit un prix annuel
  // supérieur à douze mensualités, l'économie doit tomber à 0 — pas devenir
  // négative, et surtout pas s'afficher comme une réduction.
  const grille = [
    { nom: 'Ascension', m: 35,  s: 193, a: 350,  ecoS: 17, ecoA: 70 },
    { nom: 'Prime',     m: 59,  s: 325, a: 590,  ecoS: 29, ecoA: 118 },
    { nom: 'Pilote',    m: 99,  s: 545, a: 990,  ecoS: 49, ecoA: 198 },
    { nom: 'Infinite',  m: 159, s: 875, a: 1590, ecoS: 79, ecoA: 318 }
  ];

  for (const g of grille) {
    assert.strictEqual(g.m * 6 - g.s, g.ecoS, `${g.nom} : économie semestrielle`);
    assert.strictEqual(g.m * 12 - g.a, g.ecoA, `${g.nom} : économie annuelle`);
  }
});

test('remises : la même règle pour les quatre offres, sans exception', () => {
  // C'est le test de la décision commerciale elle-même.
  //
  // L'ancienne grille accordait 16,7 % à l'année sur Ascension et 7,4 % sur
  // Pilote : monter en gamme faisait perdre plus de la moitié de son avantage.
  // Ce test échoue dès qu'une offre reçoit un traitement différent des trois
  // autres — c'est-à-dire dès que l'incohérence revient.
  const grille = [
    { nom: 'Ascension', m: 35,  s: 193, a: 350 },
    { nom: 'Prime',     m: 59,  s: 325, a: 590 },
    { nom: 'Pilote',    m: 99,  s: 545, a: 990 },
    { nom: 'Infinite',  m: 159, s: 875, a: 1590 }
  ];

  for (const g of grille) {
    // L'annuel vaut EXACTEMENT dix mensualités : deux mois offerts.
    assert.strictEqual(g.a, g.m * 10, `${g.nom} : l'annuel doit valoir 10 mensualités`);

    // Le semestriel vaut 5,5 mensualités, le demi-dollar arrondi au supérieur.
    assert.strictEqual(g.s, Math.floor(g.m * 5.5 + 0.5),
      `${g.nom} : le semestriel doit valoir 5,5 mensualités`);

    // Et surtout : les pourcentages AFFICHÉS doivent être identiques partout.
    // C'est ce que lit le directeur, et c'est là que l'incohérence se voyait.
    const pctSem = Math.round((g.m * 6 - g.s) / (g.m * 6) * 100);
    const pctAnn = Math.round((g.m * 12 - g.a) / (g.m * 12) * 100);
    assert.strictEqual(pctSem, 8,  `${g.nom} : le semestriel doit afficher 8 %`);
    assert.strictEqual(pctAnn, 17, `${g.nom} : l'annuel doit afficher 17 %`);
  }
});

test("échelle de montée en gamme : aucun palier ne doit doubler", () => {
  // Pilote → Infinite valait ×2,01 quand les deux autres marches valaient
  // ×1,68 : un établissement de 1 600 élèves payait 100 $ de plus par mois
  // pour 100 élèves de dépassement. Aucune marche ne doit s'écarter
  // franchement des autres, sous peine de rendre la dernière invendable.
  const paliers = [35, 59, 99, 159];
  const marches = paliers.slice(1).map((p, i) => p / paliers[i]);

  for (const marche of marches) {
    assert.ok(marche < 1.85,
      `une marche de ×${marche.toFixed(2)} rend le palier suivant difficile à défendre`);
  }
  const ecart = Math.max(...marches) - Math.min(...marches);
  assert.ok(ecart < 0.15,
    `les marches vont de ×${Math.min(...marches).toFixed(2)} à ×${Math.max(...marches).toFixed(2)} : `
    + `l'échelle doit rester régulière`);
});

test('économies : un prix annuel plus cher que le mensuel n\'affiche aucune remise', () => {
  const mensuel = 35, annuel = 500;                 // saisie fautive volontaire
  const economie = Math.max(mensuel * 12 - annuel, 0);
  assert.strictEqual(economie, 0);
});

/* --------------------------------------------------------------- Vocabulaire */

test('vocabulaire : aucune fonctionnalité essentielle n\'est verrouillable', () => {
  // Le garde-fou de la règle commerciale : si quelqu'un ajoute un jour
  // « notes » ou « bulletins » à la liste des fonctionnalités conditionnées,
  // ce test échoue avant que la décision ne parte en production.
  const essentielles = ['eleves', 'classes', 'cours', 'notes', 'travaux',
    'bulletins', 'presences', 'frais', 'paiements_frais', 'mentions',
    'annees_scolaires', 'periodes', 'journal', 'didacticiel'];

  for (const cle of essentielles) {
    assert.ok(!(cle in catalogue.FONCTIONNALITES),
      `« ${cle} » est une fonctionnalité essentielle : elle ne doit jamais `
      + `dépendre du niveau d'abonnement.`);
  }
});

test('vocabulaire : toute limite déclarée a un libellé et un repli chiffré', () => {
  for (const [cle, def] of Object.entries(catalogue.LIMITES)) {
    assert.ok(def.libelle, `${cle} : libellé manquant`);
    assert.strictEqual(typeof def.repli, 'number', `${cle} : repli non chiffré`);
    assert.ok(def.repli > 0, `${cle} : un repli nul fermerait l'école`);
  }
});

test('repli sans offre : permissif sur les droits, prudent sur les volumes', () => {
  const defaut = catalogue.plafondsParDefaut();
  // Une panne de facturation ne doit fermer aucun écran…
  for (const cle of Object.keys(catalogue.FONCTIONNALITES)) {
    assert.strictEqual(defaut.fonctionnalites[cle], true, `${cle} devrait rester ouvert`);
  }
  // …mais ne doit pas non plus ouvrir un compte illimité.
  assert.strictEqual(defaut.limites.max_eleves, 250);
  assert.ok(defaut.sans_offre);
});

test('périodicités : les trois annoncées commercialement, et dans l\'ordre', () => {
  assert.deepStrictEqual(
    catalogue.PERIODICITES.map((p) => p.code),
    ['mensuel', 'semestriel', 'annuel']);
  assert.deepStrictEqual(catalogue.PERIODICITES.map((p) => p.mois), [1, 6, 12]);
});
