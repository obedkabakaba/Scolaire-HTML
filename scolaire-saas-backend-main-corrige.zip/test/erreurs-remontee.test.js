/**
 * ARDOISE — REMONTÉE DES ERREURS ET AUDITS
 * ===========================================================================
 *
 * CE QUE CE FICHIER PROTÈGE
 * -------------------------
 * Trois propriétés, dans cet ordre d'importance :
 *
 *   1. AUCUN SECRET n'atteint la base. C'est la seule qui, si elle tombe,
 *      transforme l'outil de diagnostic en fuite de données.
 *   2. AUCUNE USURPATION : l'école vient du jeton, jamais du navigateur.
 *   3. LE BRUIT NE NOIE PAS LE SIGNAL : un 402 d'offre insuffisante n'est pas
 *      un bug, une même erreur incrémente au lieu de dupliquer, une erreur
 *      corrigée qui revient rouvre.
 *
 * LA BASE EST SIMULÉE
 * -------------------
 * On intercepte `runWithTenant` et on capture le SQL et les paramètres réels.
 * Ce qui est vérifié, ce sont donc les valeurs que le code enverrait vraiment
 * à PostgreSQL — pas une reconstitution.
 *
 *   node --test test/erreurs-remontee.test.js
 */

const test = require('node:test');
const assert = require('node:assert');
const Module = require('module');

/* ------------------------------------------------------- Base simulée */

const ecritures = [];          // { sql, params }
let reponseInsertion = { id: 'bug-1', occurrences: 1, statut: 'ouvert' };

const requireOrigine = Module.prototype.require;
Module.prototype.require = function (chemin) {
  if (chemin === '../config/db' || chemin === './config/db') {
    return {
      runWithTenant: (contexte, travail) => travail({
        query: async (sql, params) => {
          ecritures.push({ sql, params: params || [] });
          if (/INSERT INTO bugs_plateforme/.test(sql)) return { rows: [reponseInsertion] };
          if (/INSERT INTO audit_runs/.test(sql)) {
            /* Le simulateur RENVOIE CE QU'ON LUI INSÈRE, il n'invente rien.
               Une première version répondait un statut fixe : le test sur la
               requalification d'un rapport vide passait alors ou échouait
               indépendamment du code testé, ce qui en faisait un test
               décoratif. Les positions suivent l'ordre des colonnes de la
               requête INSERT (7 = statut, 8 = nb_fichiers, 9 = nb_anomalies). */
            return { rows: [{ id: 'run-1', statut: params[6],
                              nb_fichiers: params[7], nb_anomalies: params[8] }] };
          }
          return { rows: [] };
        }
      })
    };
  }
  return requireOrigine.apply(this, arguments);
};

const journal = require('../utils/journal-erreurs.utils');
const audits = require('../controllers/audits.controller');

function reinitialiser() {
  ecritures.length = 0;
  reponseInsertion = { id: 'bug-1', occurrences: 1, statut: 'ouvert' };
}

/** Les paramètres du dernier INSERT dans bugs_plateforme. */
function derniereEcritureBug() {
  const e = [...ecritures].reverse().find((x) => /INSERT INTO bugs_plateforme/.test(x.sql));
  if (!e) return null;
  // Ordre des colonnes, tel que déclaré par la requête.
  const [ecoleId, utilisateurId, empreinte, origine, page, methode, chemin,
         codeHttp, navigateur, systeme, message, stack, gravite, metadata] = e.params;
  return { ecoleId, utilisateurId, empreinte, origine, page, methode, chemin,
           codeHttp, navigateur, systeme, message, stack, gravite,
           metadata: JSON.parse(metadata), sql: e.sql };
}

/** Tout ce qui part vers la base, en un seul texte : le filet anti-secret. */
function toutCeQuiEstEcrit() {
  return ecritures
    .map((e) => e.sql + ' ' + JSON.stringify(e.params))
    .join('\n');
}

/* =========================================================================
   18. AUCUN SECRET DANS LES MÉTADONNÉES NI LES PILES
   ========================================================================= */

test('aucun secret n\'apparaît dans le message, la pile ou les métadonnées', async () => {
  reinitialiser();

  const SECRETS = [
    'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJhYmMifQ.SIGNATURE_SECRETE_123',
    'sk-proj-abcdefghijklmnopqrstuvwxyz012345',
    'MonMotDePasse2026!',
    'S3cr3tDeCron',
    'postgres://ardoise:MotDePasseBase@db.interne/scolaire'
  ];

  await journal.enregistrer({
    origine: 'frontend',
    message: `Échec avec Authorization: Bearer ${SECRETS[0]}`,
    stack: `Error: refus\n  at connexion (postgres://ardoise:MotDePasseBase@db.interne/scolaire)\n`
         + `  at appelApi (api_key=${SECRETS[1]})`,
    chemin: '/eleves',
    codeHttp: 500,
    metadata: {
      mot_de_passe: SECRETS[2],
      cron_secret: SECRETS[3],
      entetes: { authorization: `Bearer ${SECRETS[0]}` },
      corps: `{"password":"${SECRETS[2]}","email":"directeur@ecole.cd"}`
    }
  });

  const ecrit = toutCeQuiEstEcrit();
  for (const secret of SECRETS) {
    assert.ok(!ecrit.includes(secret),
      `le secret « ${secret.slice(0, 18)}… » est parti en base : le journal de `
      + `diagnostic est devenu une fuite de données`);
  }

  // Et le journal reste EXPLOITABLE : masquer ne veut pas dire tout effacer.
  const bug = derniereEcritureBug();
  assert.ok(/masqué/.test(bug.message + bug.stack),
    'le Super Admin doit lire « il y avait un jeton ici », pas une ligne vide');
  assert.ok(/Échec avec/.test(bug.message), 'le texte utile est conservé');
});

test('les adresses électroniques et téléphones ne sont pas conservés en clair', async () => {
  reinitialiser();
  await journal.enregistrer({
    message: 'Envoi impossible vers marie.kabongo@ecole-saint-joseph.cd (+243 81 555 4433)',
    codeHttp: 500
  });
  const ecrit = toutCeQuiEstEcrit();
  assert.ok(!ecrit.includes('marie.kabongo'), 'identité personnelle sans valeur de diagnostic');
  assert.ok(!ecrit.includes('555 4433'), 'numéro personnel sans valeur de diagnostic');
  // Le domaine reste : « tous les échecs viennent du même domaine » est utile.
  assert.ok(ecrit.includes('ecole-saint-joseph.cd'));
});

/* =========================================================================
   12. UN REFUS MÉTIER N'EST PAS UN BUG
   ========================================================================= */

test('une réponse 402 d\'offre insuffisante ne crée aucun bug', async () => {
  reinitialiser();
  const r = await journal.enregistrer({
    origine: 'frontend',
    message: "La comptabilité n'est pas comprise dans votre offre actuelle.",
    chemin: '/comptabilite/mouvements',
    codeHttp: 402
  });

  assert.strictEqual(r, null, 'aucun enregistrement');
  assert.strictEqual(ecritures.length, 0,
    "un 402 est une invitation commerciale : le compter comme incident critique "
    + "ferait passer une limite d'offre pour une panne de la plateforme");
});

test('les autres refus attendus sont également écartés', async () => {
  for (const code of [400, 401, 403, 404, 409, 422, 429]) {
    reinitialiser();
    const r = await journal.enregistrer({ message: `refus ${code}`, codeHttp: code });
    assert.strictEqual(r, null, `${code} ne doit pas créer de bug`);
  }
});

test('une vraie erreur serveur, elle, est bien enregistrée', async () => {
  reinitialiser();
  const r = await journal.enregistrer({
    origine: 'backend',
    message: 'null value in column "ecole_id" violates not-null constraint',
    chemin: '/bulletins/generer',
    methode: 'POST',
    codeHttp: 500
  });
  assert.ok(r, 'une 500 doit laisser une trace');
  const bug = derniereEcritureBug();
  assert.strictEqual(bug.codeHttp, 500);
  assert.strictEqual(bug.chemin, '/bulletins/generer');
  assert.strictEqual(bug.methode, 'POST');
});

/* =========================================================================
   11 & 13. EMPREINTE, ROUTE, ET COMPTEUR D'OCCURRENCES
   ========================================================================= */

test('une erreur 500 est enregistrée avec sa route et son empreinte', async () => {
  reinitialiser();
  await journal.enregistrer({
    origine: 'backend', message: 'Erreur serveur.', chemin: '/notes/valider',
    methode: 'POST', codeHttp: 500
  });
  const bug = derniereEcritureBug();
  assert.ok(bug.empreinte && bug.empreinte.length === 40,
    'toute erreur porte une empreinte de regroupement');
  assert.strictEqual(bug.chemin, '/notes/valider');
});

test('la même erreur répétée partage une empreinte et incrémente le compteur', () => {
  const a = journal.empreinte({
    message: "Élève 8c1f2a3b-1111-2222-3333-444455556666 introuvable",
    chemin: '/eleves/8c1f2a3b-1111-2222-3333-444455556666', origine: 'backend'
  });
  const b = journal.empreinte({
    message: "Élève 9d2e3f4c-9999-8888-7777-666655554444 introuvable",
    chemin: '/eleves/9d2e3f4c-9999-8888-7777-666655554444', origine: 'backend'
  });
  assert.strictEqual(a, b,
    "deux identifiants différents pour le même défaut : le centre afficherait "
    + "des centaines de lignes au lieu d'une à 300 occurrences");

  // Un défaut réellement différent doit, lui, se distinguer.
  const c = journal.empreinte({
    message: 'Classe introuvable', chemin: '/classes/x', origine: 'backend'
  });
  assert.notStrictEqual(a, c);
});

test('l\'insertion incrémente au lieu de dupliquer', async () => {
  reinitialiser();
  await journal.enregistrer({ message: 'défaut récurrent', chemin: '/x', codeHttp: 500 });
  const bug = derniereEcritureBug();
  assert.match(bug.sql, /ON CONFLICT \(empreinte\) DO UPDATE/,
    'le regroupement se fait en base, ce qui évite la course entre deux '
    + 'signalements simultanés du même défaut');
  assert.match(bug.sql, /occurrences = bugs_plateforme\.occurrences \+ 1/);
});

/* =========================================================================
   14. UN BUG RÉSOLU QUI RÉAPPARAÎT ROUVRE
   ========================================================================= */

test('un bug résolu qui réapparaît repasse en « ouvert »', async () => {
  reinitialiser();
  await journal.enregistrer({ message: 'régression', chemin: '/y', codeHttp: 500 });
  const bug = derniereEcritureBug();

  assert.match(bug.sql, /statut = CASE WHEN bugs_plateforme\.statut IN \('resolu','ignore'\)/,
    'masquer une régression reviendrait à perdre l\'information la plus utile '
    + 'du centre : « le correctif n\'a pas tenu »');
  assert.match(bug.sql, /THEN 'ouvert'/);
  // La signature de résolution est effacée : elle portait sur un état périmé.
  assert.match(bug.sql, /resolu_par = CASE WHEN/);
});

/* =========================================================================
   17. AUCUNE USURPATION D'ÉCOLE
   ========================================================================= */

test('un utilisateur ne peut pas signaler au nom d\'une autre école', async () => {
  reinitialiser();

  // Ce que la route fait : elle IGNORE `ecole_id` du corps et lit le jeton.
  const corpsMalveillant = { ecole_id: 'ecole-de-la-victime', message: 'plantage' };
  const jeton = { userId: 'u-1', ecoleId: 'ecole-legitime', roles: ['directeur'] };

  await journal.enregistrer({
    origine: 'frontend',
    ecoleId: jeton.ecoleId,               // source unique : le jeton
    utilisateurId: jeton.userId,
    message: corpsMalveillant.message,
    codeHttp: 500
  });

  const bug = derniereEcritureBug();
  assert.strictEqual(bug.ecoleId, 'ecole-legitime');
  assert.notStrictEqual(bug.ecoleId, corpsMalveillant.ecole_id);
  assert.ok(!toutCeQuiEstEcrit().includes('ecole-de-la-victime'),
    "l'identifiant d'école envoyé par le navigateur ne doit jamais atteindre la base");
});

test('la route de signalement ne lit jamais ecole_id du corps de requête', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'routes', 'incidents.routes.js'), 'utf8');

  // Le code (hors commentaires) ne doit contenir aucune lecture de ce champ.
  const codeSeul = source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(?<!:)\/\/[^\n]*/g, '');

  assert.ok(!/corps\.ecole_id|body\.ecole_id|body\?\.ecole_id/.test(codeSeul),
    'incidents.routes.js lit ecole_id du corps : usurpation possible');
  assert.ok(/req\.auth.*ecoleId/.test(codeSeul),
    "l'école doit provenir du jeton authentifié");
});

test('la route Super Admin historique ne fait plus confiance au corps, sauf pour le Super Admin', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'controllers', 'super-admin-support.controller.js'), 'utf8');

  assert.ok(/req\.auth\?\.isSuperAdmin[\s\S]{0,120}req\.body\?\.ecole_id/.test(source),
    "la lecture de body.ecole_id doit être conditionnée à isSuperAdmin — lui seul "
    + "n'appartient à aucune école et a une raison légitime de rattacher un incident");
});

/* =========================================================================
   ANTI-BOUCLE
   ========================================================================= */

test('une rafale du même défaut ne remplit pas la table', async () => {
  reinitialiser();
  let enregistres = 0;
  for (let i = 0; i < 50; i++) {
    const r = await journal.enregistrer({
      message: 'boucle de signalement', chemin: '/z', codeHttp: 500
    });
    if (r) enregistres++;
  }
  assert.ok(enregistres <= 3,
    `${enregistres} écritures pour 50 signalements identiques : une page qui `
    + `plante dans son propre gestionnaire d'erreur ferait tomber la base, et `
    + `l'outil de diagnostic deviendrait la panne`);
  assert.ok(enregistres >= 1, 'le premier signalement doit passer');
});

/* =========================================================================
   15 & 16. AUDITS
   ========================================================================= */

function reponseSimulee() {
  const res = { code: 200, corps: null };
  res.status = (c) => { res.code = c; return res; };
  res.json = (o) => { res.corps = o; return res; };
  return res;
}

test('un rapport d\'audit vide est requalifié en échec technique', async () => {
  reinitialiser();
  process.env.AUDIT_INGEST_SECRET = 'un-secret-technique-suffisamment-long';

  const res = reponseSimulee();
  await audits.publierExecution({
    headers: { 'x-audit-secret': 'un-secret-technique-suffisamment-long' },
    body: {
      type_audit: 'generateur',
      statut: 'reussi',          // ce que le script prétend
      nb_fichiers: 0,            // ce qu'il a réellement examiné
      resultats: []
    }
  }, res);

  assert.strictEqual(res.code, 201);
  assert.strictEqual(res.corps.statut, 'echec_technique',
    '« 0 fichier analysé — aucun problème détecté » n\'est pas un succès : '
    + "un audit qui n'a rien examiné n'a rien prouvé");
  assert.strictEqual(res.corps.requalifie, true,
    'la CI doit savoir qu\'elle a été requalifiée, sinon elle croit avoir publié un succès');
});

test('un audit qui a réellement tourné et trouvé des anomalies est accepté', async () => {
  reinitialiser();
  const res = reponseSimulee();
  await audits.publierExecution({
    headers: { 'x-audit-secret': 'un-secret-technique-suffisamment-long' },
    body: {
      type_audit: 'responsive',
      depot: 'Scolaire-HTML-main',
      commit_sha: 'a1b2c3d4',
      statut: 'anomalies',
      nb_fichiers: 43,
      resultats: [
        { fichier: 'generateur-modeles.html', ligne: 214, gravite: 'importante',
          code: 'largeur_fixe', message: 'largeur fixe 400px' }
      ]
    }
  }, res);

  assert.strictEqual(res.code, 201);
  assert.strictEqual(res.corps.statut, 'anomalies');

  const insertion = ecritures.find((e) => /INSERT INTO audit_findings/.test(e.sql));
  assert.ok(insertion, 'les anomalies doivent être enregistrées une par une');
  // fichier et ligne sont consultables depuis le Super Admin.
  assert.ok(insertion.params.includes('generateur-modeles.html'));
  assert.ok(insertion.params.includes(214));
});

test('l\'empreinte d\'une anomalie ignore le numéro de ligne', () => {
  const a = audits.empreinteAnomalie({
    type_audit: 'responsive', fichier: 'x.html', code: 'largeur_fixe',
    message: 'largeur fixe 400px (ligne 214)'
  });
  const b = audits.empreinteAnomalie({
    type_audit: 'responsive', fichier: 'x.html', code: 'largeur_fixe',
    message: 'largeur fixe 400px (ligne 251)'
  });
  assert.strictEqual(a, b,
    'ajouter trois lignes en tête d\'un fichier rouvrirait sinon toutes les '
    + 'anomalies du dépôt comme si elles étaient neuves');
});

test('une anomalie corrigée qui réapparaît rouvre', async () => {
  reinitialiser();
  const res = reponseSimulee();
  await audits.publierExecution({
    headers: { 'x-audit-secret': 'un-secret-technique-suffisamment-long' },
    body: {
      type_audit: 'sql', statut: 'anomalies', nb_fichiers: 55,
      resultats: [{ fichier: 'notes.controller.js', ligne: 88, code: 'cte_sans_virgule',
                    gravite: 'critique', message: 'virgule manquante avant la CTE' }]
    }
  }, res);

  const insertion = ecritures.find((e) => /INSERT INTO audit_findings/.test(e.sql));
  assert.match(insertion.sql, /statut\s*=\s*CASE WHEN audit_findings\.statut IN \('corrigee','ignoree'\)/);
  assert.match(insertion.sql, /THEN 'ouverte'/);
});

test('l\'ingestion est refusée sans le bon secret', async () => {
  reinitialiser();
  for (const mauvais of [undefined, '', 'court', 'un-secret-technique-suffisamment-LONG']) {
    const res = reponseSimulee();
    await audits.publierExecution(
      { headers: { 'x-audit-secret': mauvais }, body: { type_audit: 'sql', nb_fichiers: 5 } }, res);
    assert.strictEqual(res.code, 401, `« ${mauvais} » ne doit pas passer`);
    assert.strictEqual(res.corps.code, 'ingestion_refusee');
  }
  assert.strictEqual(ecritures.length, 0, 'aucune écriture sur un refus');
});

test('un secret non configuré FERME le point d\'entrée', () => {
  const memoire = process.env.AUDIT_INGEST_SECRET;
  delete process.env.AUDIT_INGEST_SECRET;
  assert.strictEqual(audits.secretValide('n-importe-quoi'), false,
    "laisser l'ingestion ouverte « en attendant la configuration » offrirait à "
    + "n'importe qui le droit d'écrire dans le centre de supervision");
  process.env.AUDIT_INGEST_SECRET = 'court';
  assert.strictEqual(audits.secretValide('court'), false,
    'un secret trop court est refusé, pas accepté avec un avertissement');
  process.env.AUDIT_INGEST_SECRET = memoire;
});

/* =========================================================================
   COUVERTURE DES SOURCES D'ERREUR BACKEND
   ========================================================================= */

test('le middleware expose de quoi consigner les 5xx, les exceptions et les tâches', () => {
  const erreurs = require('../middleware/erreurs.middleware');
  for (const fn of ['correlation', 'capteur', 'gestionnaireFinal', 'signalerErreur', 'signalerTache']) {
    assert.strictEqual(typeof erreurs[fn], 'function', `${fn} doit être exporté`);
  }
});

test('le gestionnaire final ne transforme pas un refus métier en bug', async () => {
  reinitialiser();
  const erreurs = require('../middleware/erreurs.middleware');
  const res = reponseSimulee();
  res.locals = {};

  const refus = Object.assign(new Error('Offre insuffisante.'), {
    statusCode: 402, code: 'offre_insuffisante'
  });
  erreurs.gestionnaireFinal(refus,
    { method: 'GET', originalUrl: '/comptabilite/tresorerie', headers: {} }, res, () => {});

  assert.strictEqual(res.code, 402, 'le statut métier est servi tel quel');
  assert.strictEqual(res.corps.code, 'offre_insuffisante');
  assert.strictEqual(ecritures.length, 0, 'et aucun bug n\'est créé');
});

test('le gestionnaire final conserve la cause sans la montrer à l\'utilisateur', async () => {
  reinitialiser();
  const erreurs = require('../middleware/erreurs.middleware');
  const res = reponseSimulee();
  res.locals = {};

  const panne = new Error('relation "bulletins_2026" does not exist');
  panne.code = '42P01';
  erreurs.gestionnaireFinal(panne,
    { method: 'POST', originalUrl: '/bulletins/generer', headers: {}, correlationId: 'abc123' },
    res, () => {});

  // Ce que l'utilisateur voit.
  assert.strictEqual(res.code, 500);
  assert.strictEqual(res.corps.message, 'Erreur interne du serveur.');
  assert.ok(!/does not exist/.test(JSON.stringify(res.corps)),
    'la structure interne de la base ne doit jamais atteindre l\'écran');

  // Ce que le Super Admin conserve.
  await new Promise((r) => setImmediate(r));
  const bug = derniereEcritureBug();
  assert.ok(bug, 'la cause technique doit être conservée');
  assert.match(bug.message, /does not exist/);
  assert.strictEqual(bug.metadata.code_pg, '42P01',
    '« 42P01 » dit « table inexistante » : c\'est souvent la moitié du diagnostic');
  assert.strictEqual(bug.metadata.correlation, 'abc123');
});
