/**
 * ARDOISE — LA MATRICE DES OFFRES, VÉRIFIÉE PLUTÔT QUE DOCUMENTÉE
 * ===========================================================================
 *
 * CE QUE CE FICHIER EST
 * ---------------------
 * La table `MATRICE` ci-dessous relie, pour chaque fonctionnalité vendue :
 * les pages du frontend, les routes du backend, les étapes du didacticiel,
 * les rôles concernés, et son caractère essentiel ou avancé.
 *
 * Elle n'est pas un commentaire. Chaque colonne est CONFRONTÉE au dépôt : une
 * route déclarée ici doit exister et porter son verrou, une étape déclarée ici
 * doit exister dans le catalogue d'onboarding et exiger la bonne
 * fonctionnalité. Une matrice écrite dans un fichier Markdown aurait cessé
 * d'être vraie au premier renommage, sans que personne s'en aperçoive.
 *
 * POURQUOI ELLE EXISTE
 * --------------------
 * Parce que la chaîne complète — offre active → verrou backend → menu
 * frontend → étape du didacticiel — comptait quatre maillons entretenus
 * séparément, et qu'ils avaient divergé. Six fonctionnalités étaient vendues
 * sans être verrouillées nulle part ; le didacticiel guidait vers des écrans
 * que le menu masquait.
 *
 *   node --test test/matrice-offres.test.js
 */

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const Module = require('module');

/* ------------------------------------------------------- Base simulée */

let planSimule = null;

const requireOrigine = Module.prototype.require;
Module.prototype.require = function (chemin) {
  if (chemin === '../config/db' || chemin === './config/db') {
    return {
      runWithTenant: (contexte, travail) => travail({
        query: async (sql) => {
          if (/FROM abonnements/.test(sql) && /plans_abonnement/.test(sql)) {
            return { rows: planSimule ? [planSimule] : [] };
          }
          if (/count\(\*\)/.test(sql)) return { rows: [{ total: 0 }] };
          return { rows: [] };
        }
      })
    };
  }
  return requireOrigine.apply(this, arguments);
};

const catalogue = require('../utils/catalogue.utils');
const onboarding = require('../utils/onboarding.utils');
const { exigeFonctionnalite } = require('../middleware/offre.middleware');

/* =========================================================================
   LA MATRICE
   =========================================================================

   `niveau` :
     'socle'   fonction essentielle — JAMAIS verrouillable. Élèves, classes,
               notes, bulletins officiels, présences, frais. Les brider pour
               vendre l'offre supérieure reviendrait à livrer un logiciel
               scolaire qui ne gère pas l'école.
     'avance'  fonction vendue — verrouillée dans l'interface ET dans le
               backend. Masquer un menu n'est pas une sécurité.

   `routes_ouvertes` : les chemins qui restent accessibles MALGRÉ le verrou,
   avec la raison. Cette colonne est la plus importante du tableau : c'est
   elle qui empêche de « corriger » le test en verrouillant un routeur entier.
   ========================================================================= */

const MATRICE = [
  {
    fonctionnalite: 'emploi_du_temps',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['emploi-du-temps.html'],
    fichier_routes: 'emploi-du-temps.routes.js',
    routes_verrouillees: ['/configuration', '/classe/:classeId', '/seance', '/exceptions'],
    routes_ouvertes: {
      '/mon-emploi': "lecture personnelle, appelée au chargement de l'espace professeur",
      '/aujourdhui': 'lecture personnelle, appelée au chargement du tableau de bord'
    },
    etapes: ['creneaux', 'emploi_du_temps', 'decouverte_emploi_du_temps'],
    roles: ['directeur', 'prefet']
  },
  {
    fonctionnalite: 'site_public',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['site-public.html'],
    fichier_routes: 'site-public.routes.js',
    routes_verrouillees: ['/parametres', '/annonces', '/codes-acces'],
    routes_ouvertes: {},
    etapes: ['decouverte_site_public'],
    roles: ['directeur', 'secretaire']
  },
  {
    fonctionnalite: 'concours_admission',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['inscriptions.html'],
    fichier_routes: 'inscriptions.routes.js',
    routes_verrouillees: ['/sessions', '/mes-corrections', '/candidats/:id/decision'],
    routes_ouvertes: {},
    etapes: ['decouverte_inscriptions'],
    roles: ['directeur', 'prefet', 'secretaire']
  },
  {
    fonctionnalite: 'orientation',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['orientation.html'],
    fichier_routes: 'orientation.routes.js',
    routes_verrouillees: ['/', '/voeux', '/repartir', '/options/:optionId/critere'],
    routes_ouvertes: {
      '/acces': "sonde de menu appelée sur toutes les pages ; ne renvoie qu'un booléen"
    },
    etapes: ['decouverte_orientation'],
    roles: ['directeur', 'prefet', 'titulaire']
  },
  {
    fonctionnalite: 'repechage',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['repechage.html'],
    fichier_routes: 'repechage.routes.js',
    routes_verrouillees: ['/sessions', '/copies/:id'],
    routes_ouvertes: {},
    etapes: ['decouverte_repechage'],
    roles: ['directeur', 'prefet']
  },
  {
    fonctionnalite: 'rapports_avances',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['rapports.html'],
    fichier_routes: 'rapports.routes.js',
    routes_verrouillees: ['/reussite', '/palmares', '/moyennes', '/portees', '/assiduite'],
    routes_ouvertes: {
      '/effectifs': "compter ses élèves relève de la gestion quotidienne",
      '/finances': 'le recouvrement est vital dans les quatre offres',
      '/export': 'contrôle PAR TYPE dans le contrôleur, pas au niveau de la route'
    },
    etapes: [],
    roles: ['directeur', 'prefet', 'secretaire', 'comptable']
  },
  {
    fonctionnalite: 'comptabilite',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['comptabilite.html'],
    fichier_routes: 'comptabilite.routes.js',
    routes_verrouillees: ['/categories', '/mouvements', '/tresorerie'],
    routes_ouvertes: {},
    etapes: ['decouverte_comptabilite'],
    roles: ['directeur', 'comptable']
  },
  {
    fonctionnalite: 'paie',
    niveau: 'avance',
    pages: ['comptabilite.html'],
    fichier_routes: 'comptabilite.routes.js',
    routes_verrouillees: ['/contrats', '/paie'],
    routes_ouvertes: {},
    etapes: [],
    roles: ['directeur', 'comptable']
  },
  {
    fonctionnalite: 'discipline',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['discipline.html'],
    fichier_routes: 'discipline.routes.js',
    routes_verrouillees: ['/incidents'],
    routes_ouvertes: {},
    etapes: ['discipline_bareme', 'decouverte_discipline'],
    roles: ['directeur', 'titulaire', 'directeur_discipline']
  },
  {
    fonctionnalite: 'modeles_personnalises',
    niveau: 'avance',
    conditionne_la_page: true,
    pages: ['generateur-modeles.html'],
    fichier_routes: 'modeles-bulletins.routes.js',
    routes_verrouillees: [],
    routes_ouvertes: {},
    etapes: ['modeles_personnalises'],
    roles: ['directeur']
  },
  {
    fonctionnalite: 'communication_masse',
    niveau: 'avance',
    pages: ['messages.html'],
    fichier_routes: 'communication.routes.js',
    routes_verrouillees: [],
    routes_ouvertes: {
      '/messages': "écrire à un collègue est ouvert à tous ; seule la DIFFUSION est verrouillée, dans le contrôleur"
    },
    etapes: [],
    roles: ['directeur', 'prefet', 'secretaire']
  },
  {
    fonctionnalite: 'whatsapp',
    niveau: 'avance',
    pages: [],
    fichier_routes: 'whatsapp.routes.js',
    routes_verrouillees: [],
    routes_ouvertes: {},
    etapes: [],
    roles: ['directeur']
  },
  {
    fonctionnalite: 'ia_analyse_donnees',
    niveau: 'avance',
    pages: [],
    fichier_routes: 'ia.routes.js',
    routes_verrouillees: [],
    routes_ouvertes: {},
    etapes: [],
    roles: ['directeur', 'prefet']
  },
  {
    fonctionnalite: 'ia_reglement_discipline',
    niveau: 'avance',
    pages: ['discipline.html'],
    fichier_routes: 'discipline.routes.js',
    routes_verrouillees: [],
    routes_ouvertes: {},
    etapes: [],
    roles: ['directeur']
  }
];

/* Les fonctions du SOCLE. Elles n'ont volontairement AUCUN code de
   fonctionnalité : `exigeFonctionnalite('notes')` doit lever au démarrage.
   Cette liste est le contrat commercial autant que technique. */
const SOCLE = {
  eleves: ['eleves.routes.js'],
  classes: ['structure.routes.js'],
  notes: ['notes.routes.js', 'travaux.routes.js'],
  bulletins: ['bulletins.routes.js'],
  presences: ['presences.routes.js'],
  frais: ['frais.routes.js', 'paiements.routes.js']
};

/* Fonctionnalités admises sans verrou de route, avec leur raison.
   Cette liste doit rester courte, et chaque entrée doit se défendre. */
const SANS_ROUTE = {
  assistant_aide: "ouvert dans les quatre offres : rien à verrouiller",
  ia_appreciations: "ouvert dans les quatre offres : rien à verrouiller",
  support_prioritaire: "engagement humain, pas une route"
};

/* ------------------------------------------------------------- Outillage */

const DOSSIER_ROUTES = path.join(__dirname, '..', 'routes');

function sourceRoutes(fichier) {
  return fs.readFileSync(path.join(DOSSIER_ROUTES, fichier), 'utf8');
}

function toutesLesRoutes() {
  let source = '';
  for (const f of fs.readdirSync(DOSSIER_ROUTES)) {
    // Les fichiers `.EXTRAIT` sont de la documentation, pas du code monté.
    if (f.endsWith('.js') && !f.includes('.EXTRAIT.')) {
      source += sourceRoutes(f) + '\n';
    }
  }
  return source;
}

function plan(fonctionnalites) {
  return {
    id: 'p1', code: 'test', nom: 'Offre de test', prix: 35, devise: 'USD',
    duree_jours: 30, limites: {}, fonctionnalites,
    fonctionnalites_incluses: [], fonctionnalites_exclues: [],
    abonnement_statut: 'actif', periodicite: 'mensuel'
  };
}

const DIRECTEUR = { userId: 'u1', ecoleId: 'e1', roles: ['directeur'], isSuperAdmin: false };

function traverser(middleware, auth = DIRECTEUR) {
  catalogue.invaliderCache();
  return new Promise((resoudre) => {
    const req = { auth, body: {}, query: {} };
    const res = { code: 200 };
    let fini = false;
    const conclure = (passe) => {
      if (fini) return;
      fini = true;
      resoudre({ passe, code: res.code, corps: res.corps });
    };
    res.status = (c) => { res.code = c; return res; };
    res.json = (o) => { res.corps = o; conclure(false); return res; };
    Promise.resolve(middleware(req, res, () => conclure(true))).catch(() => conclure(false));
    setTimeout(() => conclure(false), 1000);
  });
}

/* =========================================================================
   1. LA MATRICE DÉCRIT LE DÉPÔT RÉEL
   ========================================================================= */

test('chaque fonctionnalité de la matrice existe dans le catalogue commercial', () => {
  for (const ligne of MATRICE) {
    assert.ok(ligne.fonctionnalite in catalogue.FONCTIONNALITES,
      `« ${ligne.fonctionnalite} » figure dans la matrice mais pas dans le catalogue`);
  }
});

test('la matrice couvre TOUTE fonctionnalité vendue', () => {
  // Le contrôle qui empêche la matrice de vieillir : ajouter un drapeau au
  // catalogue sans l'inscrire ici fait échouer le test, donc le déploiement.
  const couvertes = new Set(MATRICE.map((l) => l.fonctionnalite));
  for (const code of Object.keys(catalogue.FONCTIONNALITES)) {
    if (code in SANS_ROUTE) continue;
    assert.ok(couvertes.has(code),
      `« ${code} » est vendue mais absente de la matrice : sa chaîne complète `
      + `(page, route, étape, rôle) n'est vérifiée par rien.`);
  }
});

test('chaque fichier de routes déclaré existe et pose le verrou annoncé', () => {
  for (const ligne of MATRICE) {
    const chemin = path.join(DOSSIER_ROUTES, ligne.fichier_routes);
    assert.ok(fs.existsSync(chemin),
      `${ligne.fichier_routes} est déclaré pour « ${ligne.fonctionnalite} » mais n'existe pas`);

    const source = sourceRoutes(ligne.fichier_routes);
    assert.ok(source.includes(`exigeFonctionnalite('${ligne.fonctionnalite}')`),
      `${ligne.fichier_routes} ne pose aucun verrou pour « ${ligne.fonctionnalite} » : `
      + `la fonctionnalité est vendue et le backend la laisse ouverte.`);
  }
});

test('chaque étape du didacticiel citée exige bien la fonctionnalité annoncée', () => {
  for (const ligne of MATRICE) {
    for (const code of ligne.etapes) {
      const etape = onboarding.PAR_CODE[code];
      assert.ok(etape, `l'étape « ${code} » de la matrice n'existe pas dans le catalogue d'onboarding`);
      assert.strictEqual(etape.fonctionnalite, ligne.fonctionnalite,
        `l'étape « ${code} » devrait exiger « ${ligne.fonctionnalite} » et exige `
        + `« ${etape.fonctionnalite || 'rien' } » : le didacticiel guiderait vers un écran fermé`);
    }
  }
});

test('chaque page citée est bien conditionnée par la même fonctionnalité côté onboarding', () => {
  // Les étapes qui mènent à une page conditionnée doivent porter le verrou.
  const pagesParFonction = new Map();
  for (const ligne of MATRICE) {
    for (const page of ligne.pages) {
      if (!pagesParFonction.has(page)) pagesParFonction.set(page, new Set());
      pagesParFonction.get(page).add(ligne.fonctionnalite);
    }
  }

  for (const etape of onboarding.ETAPES) {
    const exigences = pagesParFonction.get(etape.ecran);
    if (!exigences) continue;
    // `classes.html`, `messages.html` et consorts hébergent aussi du socle :
    // seules les étapes qui portent DÉJÀ une fonctionnalité sont contrôlées.
    if (!etape.fonctionnalite) continue;
    assert.ok(exigences.has(etape.fonctionnalite),
      `l'étape « ${etape.code} » mène à ${etape.ecran} en exigeant `
      + `« ${etape.fonctionnalite} », qui n'est pas la fonctionnalité de cette page`);
  }
});

/* =========================================================================
   2. LES FONCTIONS ESSENTIELLES NE SONT PAS BLOQUÉES
   ========================================================================= */

test('aucune route du socle ne porte de verrou d\'offre', () => {
  for (const [domaine, fichiers] of Object.entries(SOCLE)) {
    for (const fichier of fichiers) {
      const chemin = path.join(DOSSIER_ROUTES, fichier);
      assert.ok(fs.existsSync(chemin), `${fichier} (socle « ${domaine} ») est introuvable`);
      const source = fs.readFileSync(chemin, 'utf8');
      assert.ok(!/exigeFonctionnalite\(/.test(source),
        `${fichier} porte un verrou d'offre. « ${domaine} » est une fonction `
        + `essentielle : la brider revient à livrer un logiciel scolaire qui ne `
        + `gère pas l'école.`);
    }
  }
});

test('les codes du socle ne sont pas verrouillables du tout', () => {
  for (const domaine of Object.keys(SOCLE)) {
    assert.throws(() => exigeFonctionnalite(domaine), /code inconnu/,
      `« ${domaine} » ne doit pas exister comme code de fonctionnalité`);
  }
});

/* =========================================================================
   3. LES ROUTES OUVERTES LE RESTENT — ET C'EST INTENTIONNEL
   ========================================================================= */

test('les routes laissées ouvertes le sont explicitement, avec leur raison', () => {
  for (const ligne of MATRICE) {
    for (const [route, raison] of Object.entries(ligne.routes_ouvertes)) {
      assert.ok(raison && raison.length > 20,
        `${ligne.fonctionnalite} laisse « ${route} » ouverte sans justification `
        + `sérieuse. Une exception non motivée est une faille en attente.`);
    }
  }
});

test('la sonde de menu de l\'orientation reste ouverte', () => {
  // Ce test protège une décision fragile : si quelqu'un « corrige » le verrou
  // en le posant sur le routeur entier, une école sans orientation verrait la
  // modale « offre insuffisante » s'ouvrir seule à chaque changement de page.
  const source = sourceRoutes('orientation.routes.js');
  const ligneAcces = source.split('\n').find((l) => l.includes("router.get('/acces'"));
  assert.ok(ligneAcces, "la route /acces doit exister");
  assert.ok(!ligneAcces.includes('OFFRE_ORIENTATION') && !ligneAcces.includes('exigeFonctionnalite'),
    "/acces ne renvoie qu'un booléen et est appelée sur toutes les pages : "
    + "la verrouiller déclencherait une modale 402 en boucle");
});

test('les lectures personnelles de l\'emploi du temps restent ouvertes', () => {
  const source = sourceRoutes('emploi-du-temps.routes.js');
  for (const route of ['/mon-emploi', '/aujourdhui']) {
    const ligne = source.split('\n').find((l) => l.includes(`router.get('${route}'`));
    assert.ok(ligne, `la route ${route} doit exister`);
    assert.ok(!ligne.includes('OFFRE_EDT'),
      `${route} est appelée au chargement d'écrans ouverts à toutes les offres : `
      + `un 402 y ferait surgir une modale non sollicitée`);
  }
  // Et les routes de construction, elles, DOIVENT être verrouillées.
  for (const route of ['/classe/:classeId', '/seance']) {
    const lignes = source.split('\n').filter((l) => l.includes(`'${route}'`));
    assert.ok(lignes.length > 0, `${route} doit exister`);
    for (const l of lignes) {
      assert.ok(l.includes('OFFRE_EDT'),
        `${route} construit ou expose la grille d'établissement : elle doit être verrouillée`);
    }
  }
});

/* =========================================================================
   4. LE VERROU DÉCIDE VRAIMENT — COMPORTEMENT, PAS SEULEMENT PRÉSENCE
   ========================================================================= */

test('une route avancée est refusée avec une offre insuffisante', async () => {
  planSimule = plan({ assistant_aide: true, ia_appreciations: true });   // Ascension

  for (const ligne of MATRICE) {
    if (ligne.niveau !== 'avance') continue;
    const r = await traverser(exigeFonctionnalite(ligne.fonctionnalite));
    assert.strictEqual(r.passe, false,
      `« ${ligne.fonctionnalite} » passe alors qu'Ascension ne la comprend pas`);
    assert.strictEqual(r.code, 402,
      '402 et non 403 : le directeur A le droit, son école n\'a pas souscrit');
    assert.strictEqual(r.corps.code, 'offre_insuffisante',
      'la réponse 402 doit toujours porter un code exploitable par le frontend');
    assert.strictEqual(r.corps.fonctionnalite, ligne.fonctionnalite,
      "le frontend doit pouvoir nommer ce qui manque sans lire un message français");
    assert.ok(r.corps.message && r.corps.action,
      'un refus dit toujours quoi faire ensuite');
  }
});

test('une fonction incluse dans l\'offre passe', async () => {
  const toutes = {};
  for (const code of Object.keys(catalogue.FONCTIONNALITES)) toutes[code] = true;
  planSimule = plan(toutes);

  for (const ligne of MATRICE) {
    const r = await traverser(exigeFonctionnalite(ligne.fonctionnalite));
    assert.strictEqual(r.passe, true,
      `« ${ligne.fonctionnalite} » est souscrite et pourtant refusée`);
  }
});

test('aucune fonctionnalité vendue n\'est sans protection ni sans implémentation', () => {
  const source = toutesLesRoutes();
  const verrouillees = new Set(
    [...source.matchAll(/exigeFonctionnalite\('([a-z_]+)'\)/g)].map((m) => m[1]));

  for (const code of Object.keys(catalogue.FONCTIONNALITES)) {
    if (code in SANS_ROUTE) continue;
    assert.ok(verrouillees.has(code),
      `« ${code} » est déclarée vendable et n'est verrouillée nulle part. `
      + `Soit elle correspond à une route et il faut y poser le verrou, soit elle `
      + `ne correspond à rien et il faut cesser de l'annoncer sur la page des tarifs.`);
  }

  // Et l'inverse : aucun verrou ne référence un code fantôme.
  for (const code of verrouillees) {
    assert.ok(code in catalogue.FONCTIONNALITES,
      `une route pose exigeFonctionnalite('${code}'), inconnue du catalogue`);
  }
});

test('la liste des exceptions sans route reste courte et justifiée', () => {
  assert.ok(Object.keys(SANS_ROUTE).length <= 4,
    'la liste des fonctionnalités sans verrou grossit : chaque entrée doit se défendre');
  for (const [code, raison] of Object.entries(SANS_ROUTE)) {
    assert.ok(code in catalogue.FONCTIONNALITES, `exception « ${code} » inconnue du catalogue`);
    assert.ok(raison && raison.length > 15, `l'exception « ${code} » n'est pas motivée`);
  }
});

/* =========================================================================
   5. L'ACCÈS DIRECT PAR URL NE CONTOURNE PAS L'OFFRE
   ========================================================================= */

test('l\'export de rapports ne contourne pas le verrou par la chaîne de requête', () => {
  // `/rapports/palmares` est verrouillé. `/rapports/export?type=palmares`
  // appelle la MÊME fonction sans repasser par la route : sans contrôle dans
  // le contrôleur, le verrou se contournerait par un paramètre d'URL.
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'controllers', 'rapports.controller.js'), 'utf8');

  assert.ok(/offre:\s*'rapports_avances'/.test(source),
    "exporter() doit associer une fonctionnalité aux rapports avancés");
  assert.ok(/aDroitA\(/.test(source),
    'exporter() doit interroger le catalogue, pas seulement les rôles');
  assert.ok(/402/.test(source),
    'un refus d\'offre à l\'export doit répondre 402, comme partout ailleurs');

  // Les deux rapports du socle doivent y rester sans exigence d'offre.
  assert.ok(/effectifs:.*offre:\s*null/.test(source),
    "l'export des effectifs doit rester ouvert dans toutes les offres");
  assert.ok(/finances:.*offre:\s*null/.test(source),
    "l'export du recouvrement doit rester ouvert dans toutes les offres");
});

/* =========================================================================
   6. FRONTEND ET BACKEND PARLENT LE MÊME VOCABULAIRE
   ========================================================================= */

test('le frontend et le backend utilisent les mêmes codes de fonctionnalités', (t) => {
  /* Les deux dépôts sont séparés. Plutôt que de deviner un dossier frère —
     l'erreur exacte que `audit-contrat-api.py` commettait — on lit une variable
     d'environnement documentée. Absente, le test est SIGNALÉ COMME IGNORÉ et
     non comme réussi : un contrôle qu'on n'a pas pu faire ne doit jamais se
     confondre avec un contrôle qui passe. */
  const racineFront = process.env.ARDOISE_FRONTEND;
  if (!racineFront) {
    return t.skip('ARDOISE_FRONTEND non défini : contrôle inter-dépôts non exécuté. '
      + 'Lancer avec ARDOISE_FRONTEND=/chemin/vers/Scolaire-HTML-main');
  }

  const cheminUi = path.join(racineFront, 'ui.js');
  assert.ok(fs.existsSync(cheminUi),
    `ARDOISE_FRONTEND pointe vers ${racineFront}, où ui.js est introuvable. `
    + `Ce n'est pas une anomalie du produit : c'est un chemin mal renseigné.`);

  const ui = fs.readFileSync(cheminUi, 'utf8');

  // Les codes cités par la table PAGES_CONDITIONNEES et par les libellés.
  const bloc = ui.slice(ui.indexOf('PAGES_CONDITIONNEES'), ui.indexOf('var CLE_CACHE'));
  const codesFront = new Set(
    [...bloc.matchAll(/'([a-z_]{4,})'/g)].map((m) => m[1])
      .filter((c) => !c.endsWith('.html')));

  for (const code of codesFront) {
    assert.ok(code in catalogue.FONCTIONNALITES,
      `ui.js conditionne une page sur « ${code} », inconnue du catalogue backend. `
      + `Le menu masquerait une page que le serveur n'a jamais verrouillée.`);
  }

  // Chaque page conditionnée côté frontend doit l'être côté backend aussi.
  for (const ligne of MATRICE) {
    for (const page of ligne.pages) {
      if (!bloc.includes(`'${page}'`)) continue;

      /* UNE PAGE PEUT HÉBERGER PLUSIEURS FONCTIONNALITÉS.

         `comptabilite.html` porte la caisse ET la paie ; `discipline.html`
         porte les incidents ET la lecture du règlement par l'IA. Le menu ne
         peut être conditionné que sur UNE d'entre elles — la principale, celle
         sans laquelle la page n'a plus d'objet. Les autres sont verrouillées
         bloc par bloc côté serveur, ce qui est le bon niveau : masquer la page
         entière priverait une école Pilote de sa caisse parce qu'elle n'a pas
         souscrit la paie.

         Le test ne vérifie donc l'accord frontend/backend que sur la
         fonctionnalité déclarée `conditionne_la_page`. */
      if (!ligne.conditionne_la_page) continue;
      const attendu = new RegExp(`'${page.replace('.', '\\.')}':\\s*'${ligne.fonctionnalite}'`);
      assert.ok(attendu.test(bloc),
        `${page} devrait être conditionnée sur « ${ligne.fonctionnalite} » dans `
        + `ui.js (table PAGES_CONDITIONNEES) : le menu et le backend ne parlent `
        + `pas du même verrou.`);
    }
  }
});
