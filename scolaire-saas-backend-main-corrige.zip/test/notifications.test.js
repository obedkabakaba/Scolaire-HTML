/**
 * test/notifications.test.js
 * ---------------------------------------------------------------------------
 * Ce que ces tests protègent, et pourquoi ça compte ici en particulier.
 *
 * Les gabarits sont rendus AU MOMENT DE L'ENVOI, pas à l'écriture. Une
 * exception dans un gabarit ne se produit donc pas dans le contrôleur, où
 * elle serait attrapée et visible : elle se produit dans le vidage de file,
 * en arrière-plan, plusieurs secondes plus tard. Le service la rattrape (voir
 * `rendreEmail`, bloc try/catch) et envoie une version dépouillée — l'e-mail
 * part, mais amputé de tout ce qui le rendait utile : le décompte du bulletin
 * de paie, le solde du reçu, le capital de conduite.
 *
 * Autrement dit : un gabarit cassé ne fait pas de bruit. Il dégrade
 * silencieusement, en production, pour tout le monde. D'où ces tests.
 *
 * Exécution : node test/notifications.test.js
 * (aucune dépendance : le catalogue ne touche ni à la base ni au réseau)
 */

const {
  CATALOGUE, rendreInterne, rendreEmail, canalDefaut, doitEffacerDonnees,
  montant, moisFr, dateFr
} = require('../utils/notifications-catalogue');

let reussis = 0;
const echecs = [];

function verifier(intitule, condition, detail) {
  if (condition) {
    reussis++;
  } else {
    echecs.push(`${intitule}${detail ? ` — ${detail}` : ''}`);
  }
}

/* =========================================================================
   1. Aucun gabarit ne doit lever, même privé de toutes ses données
   =========================================================================
   Les données viennent d'une colonne jsonb : un champ peut manquer parce que
   la fiche élève était incomplète, parce qu'une jointure a renvoyé NULL, ou
   parce que la ligne date d'une version antérieure du code. Le gabarit doit
   survivre aux trois.
*/
const CAS_LIMITES = [
  ['objet vide', {}],
  ['tout à null', {
    prenom: null, nom: null, ecole: null, eleve: null, classe: null,
    periode: null, mois: null, net: null, devise: null, montant: null,
    points: null, date: null, titre: null, quand: null, jours: null
  }],
  ['chaînes vides', {
    prenom: '', ecole: '', eleve: '', mois: '', devise: '', titre: ''
  }],
  ['types inattendus', {
    net: 'beaucoup', montant: NaN, points: undefined, pourcentage: 'x',
    dateDebut: 'pas-une-date', mois: '2026-13', primes: null, retenues: null
  }]
];

for (const [evenement, entree] of Object.entries(CATALOGUE)) {
  for (const [nomCas, donnees] of CAS_LIMITES) {
    let interneOk = true;
    let detailInterne = '';
    try {
      const r = rendreInterne(evenement, donnees);
      if (typeof r.titre !== 'string' || r.titre.length === 0) {
        interneOk = false;
        detailInterne = 'titre vide';
      }
    } catch (err) {
      interneOk = false;
      detailInterne = err.message;
    }
    verifier(`interne « ${evenement} » / ${nomCas}`, interneOk, detailInterne);

    // On appelle le gabarit DIRECTEMENT, sans passer par le try/catch de
    // `rendreEmail` : c'est précisément ce filet qu'on veut ne jamais voir
    // se déclencher. Le tester à travers lui reviendrait à vérifier que le
    // filet fonctionne, pas que le gabarit est correct.
    if (entree.html) {
      let htmlOk = true;
      let detailHtml = '';
      try {
        const html = entree.html(donnees);
        if (typeof html !== 'string' || !html.includes('<!DOCTYPE html>')) {
          htmlOk = false;
          detailHtml = 'HTML non conforme';
        }
      } catch (err) {
        htmlOk = false;
        detailHtml = err.message;
      }
      verifier(`html « ${evenement} » / ${nomCas}`, htmlOk, detailHtml);
    }

    if (entree.objet) {
      try {
        entree.objet(donnees);
        verifier(`objet « ${evenement} » / ${nomCas}`, true);
      } catch (err) {
        verifier(`objet « ${evenement} » / ${nomCas}`, false, err.message);
      }
    }
  }
}

/* =========================================================================
   2. Échappement HTML
   =========================================================================
   Le nom d'un élève, le libellé d'un frais et le titre d'un événement sont
   saisis à la main dans la plateforme. Une apostrophe suffit à casser un
   attribut ; un `<script>` dans un nom d'élève partirait dans la boîte de
   plusieurs centaines de familles.
*/
const INJECTION = '<script>alert("x")</script>';

const html = CATALOGUE['bulletin.disponible'].html({
  eleve: INJECTION, classe: 'A', periode: 'T1', ecole: 'E'
});
verifier(
  'le nom d\'élève est échappé dans le bulletin',
  !html.includes('<script>') && html.includes('&lt;script&gt;'),
  'balise script non neutralisée'
);

const htmlFrais = CATALOGUE['frais.paiement_recu'].html({
  eleve: 'X', libelle: INJECTION, reference: 'R1', montant: 10, devise: 'FC'
});
verifier(
  'le libellé de frais est échappé',
  !htmlFrais.includes('<script>'),
  'balise script non neutralisée'
);

/* =========================================================================
   3. Le bulletin de paie dit la vérité
   =========================================================================
   C'est le seul e-mail qui tient lieu de document officiel. S'il affiche un
   net faux, ou s'il omet une retenue, l'école a un litige.
*/
const paie = CATALOGUE['paie.salaire_paye'].html({
  personne: 'Jean Kabeya', prenom: 'Jean', poste: 'Enseignant',
  ecole: 'Institut Lumière', mois: '2026-03',
  base: 250000, primes: 30000, retenues: 15000, net: 265000,
  devise: 'FC', datePaiement: '2026-03-28', modePaiement: 'Espèces'
});

verifier('le net figure au bulletin de paie', paie.includes('265 000 FC'));
verifier('la base figure au bulletin de paie', paie.includes('250 000 FC'));
verifier('les primes figurent', paie.includes('30 000 FC'));
verifier('les retenues figurent', paie.includes('15 000 FC'));
verifier('le mois est lisible', paie.includes('mars 2026'), 'mois non traduit');

// Une prime à zéro ne doit pas s'afficher : une ligne « Primes : 0 FC »
// invite l'employé à demander pourquoi il n'a rien touché.
const paieSansPrime = CATALOGUE['paie.salaire_paye'].html({
  personne: 'X', mois: '2026-03', base: 100000, primes: 0, retenues: 0,
  net: 100000, devise: 'FC'
});
verifier(
  'une prime nulle est omise',
  !paieSansPrime.includes('Primes'),
  'ligne Primes affichée à tort'
);

/* =========================================================================
   4. Le mot de passe provisoire est effacé après envoi
   =========================================================================
   `donnees` est une colonne jsonb que toute personne ayant accès à la base
   peut lire. Un mot de passe provisoire n'a aucune raison d'y rester une fois
   l'e-mail parti.
*/
verifier(
  'compte.cree efface ses données après envoi',
  doitEffacerDonnees('compte.cree') === true
);
verifier(
  'compte.mot_de_passe_reinitialise efface ses données',
  doitEffacerDonnees('compte.mot_de_passe_reinitialise') === true
);
verifier(
  'un reçu de paiement, lui, est conservé',
  doitEffacerDonnees('frais.paiement_recu') === false,
  'un reçu doit rester consultable'
);

/* =========================================================================
   5. Canaux — qui reçoit un e-mail, qui ne reçoit qu'une notification
   =========================================================================
   Se tromper ici ne casse rien visiblement : ça noie simplement les
   destinataires jusqu'à ce qu'ils désactivent tout.
*/
const CANAUX_ATTENDUS = {
  'compte.cree': 'email',
  'paie.salaire_paye': 'email',
  'bulletin.disponible': 'email',
  'frais.paiement_recu': 'email',
  'presence.absence': 'email',
  'discipline.incident': 'email',
  // Interne : signaux de travail entre collègues, pas annonces.
  'notes.soumises': 'interne',
  'paie.preparee': 'interne',
  'calendrier.evenement_ajoute': 'interne',
  'discipline.conduite_critique': 'interne'
};

for (const [evenement, attendu] of Object.entries(CANAUX_ATTENDUS)) {
  verifier(
    `canal de « ${evenement} »`,
    canalDefaut(evenement) === attendu,
    `attendu ${attendu}, obtenu ${canalDefaut(evenement)}`
  );
}

/* =========================================================================
   6. Un événement inconnu ne fait pas tomber la file
   =========================================================================
   Une ligne écrite par une version antérieure — ou par un déploiement
   partiel — porte une clé que le catalogue ne connaît plus. Elle doit partir
   quand même, avec ce qui a été figé en base.
*/
const inconnu = rendreEmail('evenement.qui.nexiste.pas', {}, {
  sujet: 'Titre figé', contenu: 'Contenu figé', lien: '/x.html'
});
verifier('événement inconnu : objet de repli', inconnu.objet === 'Titre figé');
verifier(
  'événement inconnu : HTML de repli valide',
  inconnu.html.includes('<!DOCTYPE html>') && inconnu.html.includes('Contenu figé')
);

/* =========================================================================
   7. Formatage
   =========================================================================
*/
verifier('montant entier sans décimales', montant(125000, 'FC') === '125 000 FC');
// Deux décimales sur un montant fractionnaire : « 12,5 USD » sur un reçu se
// lit comme un chiffre tronqué. C'est « 12,50 USD » qui est attendu.
verifier('montant décimal sur deux chiffres', montant(12.5, 'USD') === '12,50 USD');
// Le séparateur de milliers doit être un espace ORDINAIRE : l'espace fine
// insécable produite par toLocaleString s'affiche en carré dans plusieurs
// clients e-mail (voir le commentaire dans `montant`).
verifier(
  'séparateur de milliers compatible e-mail',
  !/[\u202F\u00A0]/.test(montant(125000, 'FC')),
  'espace insécable présente dans le montant'
);
verifier('montant invalide neutralisé', montant('abc', 'FC') === '—');
verifier('mois traduit', moisFr('2026-01') === 'janvier 2026');
verifier('mois invalide toléré', typeof moisFr('n/a') === 'string');
verifier('date absente tolérée', dateFr(null) === '');

/* =========================================================================
   Résultat
   =========================================================================
*/
console.log(`\n${reussis} vérification(s) réussie(s), ${echecs.length} échec(s).`);
if (echecs.length > 0) {
  console.error('\nÉchecs :');
  for (const e of echecs) console.error(`  ✗ ${e}`);
  process.exit(1);
}
console.log('✓ Catalogue de notifications conforme.\n');
