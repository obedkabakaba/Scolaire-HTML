/**
 * ARDOISE — LE DIDACTICIEL FACE À L'OFFRE
 * ===========================================================================
 *
 * CE QUE CE FICHIER PROTÈGE
 * -------------------------
 * Une règle, et elle tient en une phrase : le didacticiel ne doit JAMAIS
 * envoyer quelqu'un contre une porte fermée.
 *
 * Le défaut corrigé n'était pas cosmétique. `construireParcours()` ne recevait
 * que le rôle et le cycle. Une école en Ardoise Ascension se voyait donc
 * proposer « Emploi du temps » — étape que son menu masque et que la route
 * refuse en 402. Elle ne pouvait ni la faire, ni la passer, ni s'en
 * débarrasser : sa progression plafonnait sous 100 % pour toujours, et le
 * directeur en concluait raisonnablement que la plateforme était cassée.
 *
 * POURQUOI AUCUNE BASE N'EST NÉCESSAIRE
 * -------------------------------------
 * Le moteur est une fonction pure : des rôles, des faits, une progression, un
 * contexte, et rien d'autre. C'est exactement pour cela qu'il a été écrit
 * ainsi. Ce qui est simulé ici, ce sont les FAITS (ce que dirait la base) et
 * les DROITS (ce que dirait le catalogue) — jamais la logique de décision,
 * qui est celle du vrai moteur.
 *
 *   node --test test/onboarding-offre.test.js
 */

const test = require('node:test');
const assert = require('node:assert');

const onboarding = require('../utils/onboarding.utils');
const catalogue = require('../utils/catalogue.utils');

/* =========================================================================
   OUTILLAGE
   ========================================================================= */

/**
 * Les droits d'une offre, à partir de la liste de ce qu'elle comprend.
 *
 * Passe par `normaliserFonctionnalites` du catalogue — indirectement, via un
 * objet à toutes les clés. Écrire `{ comptabilite: true }` à la main ferait
 * lire `undefined` sur les autres codes, et `undefined !== true` donnerait le
 * bon résultat par accident. On veut que le test échoue si le moteur se met à
 * distinguer « absent » de « faux ».
 */
function droits(...incluses) {
  const table = {};
  for (const code of Object.keys(catalogue.FONCTIONNALITES)) table[code] = false;
  for (const code of incluses) {
    assert.ok(code in table, `Fonctionnalité inconnue dans le test : ${code}`);
    table[code] = true;
  }
  return table;
}

/* Les quatre offres, telles que le catalogue commercial les décrit.
   Ascension = le socle : tout le pédagogique, aucun module avancé. */
const ASCENSION = droits('assistant_aide', 'ia_appreciations');

const PRIME = droits('assistant_aide', 'ia_appreciations', 'emploi_du_temps',
  'discipline', 'communication_masse', 'ia_reglement_discipline');

const PILOTE = droits('assistant_aide', 'ia_appreciations', 'emploi_du_temps',
  'discipline', 'communication_masse', 'site_public', 'modeles_personnalises',
  'comptabilite', 'paie', 'concours_admission', 'orientation', 'repechage',
  'rapports_avances', 'ia_reglement_discipline', 'ia_analyse_donnees');

/** Une école entièrement installée : tous les signaux de la base au vert. */
function ecoleInstallee(extra = {}) {
  return {
    profil_complet: true, identite_ecole: true, annee_active: true,
    periodes: true, creneaux: true, sections_options: true, cours: true,
    classes: true, classe_cours: true, enseignants: true,
    attribution_cours: true, titulaires: true, eleves: true,
    modeles_bulletins: true, modele_personnalise: false,
    discipline_bareme: true, frais: true, emploi_du_temps: true,
    _cycle: 'secondaire', _compteurs: {}, ...extra
  };
}

/** Une école neuve : rien n'est fait. */
function ecoleVide(extra = {}) {
  return { _cycle: 'secondaire', _compteurs: {}, ...extra };
}

function progression(extra = {}) {
  return onboarding.lireProgression(extra);
}

/**
 * Une progression de personne qui a DÉJÀ visité tous les écrans.
 *
 * Les étapes de découverte se valident par la visite, pas par la base : c'est
 * la seule trace qui existe pour « j'ai vu l'écran Rapports ». Les tests qui
 * portent sur l'OFFRE doivent donc neutraliser cette dimension, faute de quoi
 * ils échoueraient pour une raison qui n'a rien à voir avec ce qu'ils
 * vérifient — et masqueraient le vrai résultat.
 *
 * Les tests qui portent sur les découvertes elles-mêmes utilisent
 * `progression()` nue, à dessein.
 */
function progressionVisitee(extra = {}) {
  return onboarding.lireProgression({
    ecrans_visites: onboarding.ETAPES.map((e) => e.ecran),
    ...extra
  });
}

function parcours(roles, faits, prog, contexte) {
  return onboarding.construireParcours(roles, faits, prog, contexte);
}

const codes = (liste) => liste.map((e) => e.code);

/* =========================================================================
   1. UNE ÉTAPE HORS OFFRE EST ÉCARTÉE, PAS BLOQUÉE
   ========================================================================= */

test('Directeur Ascension : aucun guidage vers une fonction Prime, Pilote ou Infinite', () => {
  const p = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: ASCENSION });

  const presentes = codes(p.etapes);

  for (const interdite of ['creneaux', 'emploi_du_temps', 'discipline_bareme',
                           'modeles_personnalises', 'decouverte_orientation',
                           'decouverte_repechage', 'decouverte_site_public']) {
    assert.ok(!presentes.includes(interdite),
      `« ${interdite} » ne doit pas figurer dans le parcours d'une école Ascension`);
  }

  // Écartée ≠ masquée en silence : la raison doit être disponible, pour que
  // l'interface puisse dire « comprise dans Prime » ailleurs que dans la
  // liste des choses à faire.
  const ecartee = p.etapes_ecartees.find((e) => e.code === 'emploi_du_temps');
  assert.ok(ecartee, 'une étape écartée doit rester consultable avec sa raison');
  assert.strictEqual(ecartee.raison, 'hors_offre');
  assert.strictEqual(ecartee.fonctionnalite, 'emploi_du_temps');
  assert.ok(ecartee.message, 'une étape écartée dit toujours pourquoi');
});

test("une étape écartée ne compte ni dans la progression, ni dans la prochaine étape", () => {
  const p = parcours(['directeur'], ecoleInstallee({ emploi_du_temps: false, creneaux: false }),
    progressionVisitee(), { cycle: 'secondaire', droits: ASCENSION });

  assert.strictEqual(p.progression_pct, 100,
    "une fonctionnalité exclue par l'offre ne doit jamais empêcher d'atteindre 100 %");
  assert.strictEqual(p.termine, true);
  assert.ok(!p.prochaine || p.prochaine.code !== 'emploi_du_temps');
});

test("aucune étape écartée n'apparaît dans les dépendances bloquantes", () => {
  const p = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: ASCENSION });

  const presentes = new Set(codes(p.etapes));
  for (const e of p.etapes) {
    for (const d of e.bloquee_par) {
      assert.ok(presentes.has(d),
        `« ${e.code} » est bloquée par « ${d} », absente du parcours : branche sans issue`);
    }
  }
});

test('le centre d\'apprentissage ne mène jamais vers une fonction inaccessible', () => {
  const centre = onboarding.centreApprentissage(['directeur'], ASCENSION);
  const etapesCitees = centre
    .reduce((acc, r) => acc.concat(r.articles.map((a) => a.etape)), [])
    .filter(Boolean);

  for (const code of etapesCitees) {
    const def = onboarding.PAR_CODE[code];
    if (!def || !def.fonctionnalite) continue;
    assert.strictEqual(ASCENSION[def.fonctionnalite], true,
      `le centre propose « ${code} », qui exige ${def.fonctionnalite} — absente d'Ascension`);
  }

  // Et le contrôle inverse : en Pilote, l'article existe bien.
  const centrePilote = onboarding.centreApprentissage(['directeur'], PILOTE);
  const tousPilote = centrePilote
    .reduce((acc, r) => acc.concat(r.articles.map((a) => a.etape)), []);
  assert.ok(tousPilote.includes('modeles_personnalises'),
    "l'éditeur de modèles doit être proposé à une école qui l'a souscrit");
});

/* =========================================================================
   2. MODÈLES DE BULLETINS — LE BLOCAGE HISTORIQUE
   ========================================================================= */

test('Directeur Ascension : le parcours se termine sans créer de modèle personnalisé', () => {
  // Tout est fait SAUF qu'aucun modèle propre à l'école n'existe.
  const faits = ecoleInstallee({ modele_personnalise: false });
  const p = parcours(['directeur'], faits, progressionVisitee(),
    { cycle: 'secondaire', droits: ASCENSION });

  assert.strictEqual(p.termine, true,
    "une école qui utilise le gabarit officiel a terminé son installation");
  assert.strictEqual(p.progression_pct, 100);
});

test("le didacticiel n'envoie jamais une école Ascension vers l'éditeur personnalisé", () => {
  const p = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: ASCENSION });

  const versEditeur = p.etapes.filter((e) => e.ecran === 'generateur-modeles.html');
  assert.strictEqual(versEditeur.length, 0,
    "generateur-modeles.html est verrouillé par modeles_personnalises : aucune étape ne doit y mener");

  const base = p.etapes.find((e) => e.code === 'modeles_bulletins');
  assert.ok(base, "l'étape « modèle de bulletin » reste proposée : elle est utile");
  assert.notStrictEqual(base.ecran, 'generateur-modeles.html');
});

test("la création d'un modèle personnalisé est facultative, même quand l'offre l'ouvre", () => {
  const p = parcours(['directeur'], ecoleInstallee(), progressionVisitee(),
    { cycle: 'secondaire', droits: PILOTE });

  const perso = p.etapes.find((e) => e.code === 'modeles_personnalises');
  assert.ok(perso, "l'étape doit exister en Pilote");
  assert.strictEqual(perso.obligatoire, false,
    'créer un modèle propre à son école ne conditionne jamais la fin du parcours');
  assert.strictEqual(perso.fait, false, 'aucun modèle personnalisé dans ce scénario');
  assert.strictEqual(p.termine, true,
    "une étape facultative non faite ne doit pas empêcher de terminer");
});

/* =========================================================================
   3. RÔLES ET OFFRES CROISÉS
   ========================================================================= */

test('Directeur Prime : emploi du temps et discipline disponibles, aucune étape Pilote', () => {
  const p = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: PRIME });
  const presentes = codes(p.etapes);

  assert.ok(presentes.includes('creneaux'), "Prime comprend l'emploi du temps");
  assert.ok(presentes.includes('emploi_du_temps'));
  assert.ok(presentes.includes('discipline_bareme'), 'Prime comprend la discipline');

  for (const pilote of ['decouverte_orientation', 'decouverte_repechage',
                        'decouverte_site_public', 'decouverte_comptabilite',
                        'modeles_personnalises']) {
    assert.ok(!presentes.includes(pilote),
      `« ${pilote} » relève d'une offre supérieure à Prime`);
  }
});

test('Comptable Ascension : aucun blocage sur la comptabilité avancée non incluse', () => {
  const p = parcours(['comptable'], ecoleInstallee(), progressionVisitee(),
    { cycle: 'secondaire', droits: ASCENSION });

  assert.ok(!codes(p.etapes).includes('decouverte_comptabilite'),
    'la caisse et la paie ne sont pas comprises dans Ascension');
  assert.strictEqual(p.termine, true,
    "le comptable d'une école Ascension doit pouvoir terminer son parcours");

  // Ce qui reste doit être ce qui LUI est réellement ouvert.
  const presentes = codes(p.etapes);
  assert.ok(presentes.includes('decouverte_paiements'),
    "l'encaissement des frais est essentiel : jamais verrouillé");
  assert.ok(presentes.includes('decouverte_dettes'),
    'le suivi des impayés fait partie du socle');
});

test('Comptable Pilote : la comptabilité avancée apparaît', () => {
  const p = parcours(['comptable'], ecoleInstallee(), progression(),
    { cycle: 'secondaire', droits: PILOTE });
  assert.ok(codes(p.etapes).includes('decouverte_comptabilite'));
});

test('École primaire : aucune étape sections/options obligatoire', () => {
  const p = parcours(['directeur'], ecoleVide({ _cycle: 'primaire' }), progression(),
    { cycle: 'primaire', droits: PILOTE });

  assert.ok(!codes(p.etapes).includes('sections_options'),
    'le primaire n\'a ni sections ni options : proposer l\'étape la rendrait ineffaçable');

  const ecartee = p.etapes_ecartees.find((e) => e.code === 'sections_options');
  assert.ok(ecartee && ecartee.raison === 'hors_cycle');

  // Et le secondaire, lui, la conserve.
  const q = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: PILOTE });
  assert.ok(codes(q.etapes).includes('sections_options'));
});

/* =========================================================================
   4. ÉTAPES PASSÉES, DÉCLARÉES INUTILISÉES, RÉACTIVÉES
   ========================================================================= */

test('« Passer pour l\'instant » ne laisse aucune dépendance bloquée sans solution', () => {
  // On passe les créneaux. L'emploi du temps en dépend DUREMENT.
  const prog = progression({ etapes_ignorees: ['creneaux'] });
  const p = parcours(['directeur'], ecoleVide(), prog,
    { cycle: 'secondaire', droits: PRIME });

  const edt = p.etapes.find((e) => e.code === 'emploi_du_temps');
  assert.ok(edt, "un report n'écarte pas l'étape enfant : il la remet à plus tard");
  assert.strictEqual(edt.bloquee, false,
    'une dépendance simplement REPORTÉE ne doit pas verrouiller définitivement sa branche');
});

test('« Nous n\'utilisons pas cette fonctionnalité » écarte aussi les étapes qui en dépendent', () => {
  const prog = progression({ etapes_non_utilisees: ['creneaux'] });
  const p = parcours(['directeur'], ecoleVide(), prog,
    { cycle: 'secondaire', droits: PRIME });

  assert.ok(!codes(p.etapes).includes('emploi_du_temps'),
    "placer des séances sans heures de cours n'a pas de sens : l'étape enfant s'écarte");

  const ecartee = p.etapes_ecartees.find((e) => e.code === 'emploi_du_temps');
  assert.ok(ecartee);
  assert.strictEqual(ecartee.raison, 'dependance_non_utilisee');
});

test('une dépendance SOUPLE non faite ne bloque pas', () => {
  // `emploi_du_temps` dépend souplement de `attribution_cours`.
  const faits = ecoleInstallee({ attribution_cours: false, emploi_du_temps: false });
  const p = parcours(['directeur'], faits, progression(),
    { cycle: 'secondaire', droits: PRIME });

  const edt = p.etapes.find((e) => e.code === 'emploi_du_temps');
  assert.ok(edt);
  assert.ok(!edt.bloquee_par.includes('attribution_cours'),
    "on peut placer la séance d'une branche avant de savoir qui l'assurera");
});

test('une étape réactivée revient correctement, avec ses enfants', () => {
  const avant = parcours(['directeur'], ecoleVide(),
    progression({ etapes_non_utilisees: ['creneaux'] }),
    { cycle: 'secondaire', droits: PRIME });
  assert.ok(!codes(avant.etapes).includes('emploi_du_temps'));

  // Réactivation : la liste ne contient plus le code.
  const apres = parcours(['directeur'], ecoleVide(),
    progression({ etapes_non_utilisees: [] }),
    { cycle: 'secondaire', droits: PRIME });

  assert.ok(codes(apres.etapes).includes('creneaux'), "l'étape réactivée revient");
  assert.ok(codes(apres.etapes).includes('emploi_du_temps'),
    'et ses enfants avec elle : rien n\'a été détruit, seule une liste de codes changeait');
});

test('un prérequis reste non passable, une étape facultative est passable', () => {
  const p = parcours(['directeur'], ecoleVide(), progression(),
    { cycle: 'secondaire', droits: PILOTE });

  const parCode = new Map(p.etapes.map((e) => [e.code, e]));
  for (const indispensable of ['identite_ecole', 'annee_scolaire', 'classes', 'eleves']) {
    assert.strictEqual(parCode.get(indispensable).passable, false,
      `« ${indispensable} » conditionne le fonctionnement de l'école : elle ne se passe pas`);
  }
  for (const optionnelle of ['frais', 'discipline_bareme', 'titulaires']) {
    assert.strictEqual(parCode.get(optionnelle).passable, true,
      `« ${optionnelle} » dépend de l'organisation de l'école : elle doit être passable`);
  }
});

/* =========================================================================
   5. CHANGEMENTS D'OFFRE
   ========================================================================= */

test('montée Ascension → Prime : la progression acquise est conservée', () => {
  // École à mi-parcours, tout ce qui la concerne en Ascension étant fait.
  const faits = ecoleInstallee({ emploi_du_temps: false, creneaux: false,
                                 discipline_bareme: false });
  const prog = progressionVisitee({ statut: 'en_cours', demarre_at: '2026-01-05T08:00:00.000Z' });

  const ascension = parcours(['directeur'], faits, prog,
    { cycle: 'secondaire', droits: ASCENSION });
  assert.strictEqual(ascension.termine, true);

  const prime = parcours(['directeur'], faits, prog,
    { cycle: 'secondaire', droits: PRIME });

  // Les étapes déjà faites le restent : la détection lit la base, pas l'offre.
  for (const acquise of ['identite_ecole', 'classes', 'eleves', 'cours']) {
    const e = prime.etapes.find((x) => x.code === acquise);
    assert.strictEqual(e.fait, true, `« ${acquise} » ne doit pas se ré-ouvrir après une montée d'offre`);
  }
  // Le parcours ne recommence pas : le statut et la date de début sont intacts.
  assert.strictEqual(prog.statut, 'en_cours');
  assert.strictEqual(prog.demarre_at, '2026-01-05T08:00:00.000Z');

  // Les nouveautés apparaissent, mais pas comme des prérequis bloquants.
  const edt = prime.etapes.find((e) => e.code === 'emploi_du_temps');
  assert.ok(edt, "l'emploi du temps apparaît avec Prime");
  assert.strictEqual(edt.obligatoire, false,
    'une fonctionnalité nouvellement ouverte se découvre, elle ne se subit pas');
});

test('descente Prime → Ascension : la fonctionnalité est retirée, les données restent', () => {
  // L'école AVAIT un emploi du temps : le fait reste vrai en base.
  const faits = ecoleInstallee({ emploi_du_temps: true, creneaux: true });

  const prime = parcours(['directeur'], faits, progressionVisitee(),
    { cycle: 'secondaire', droits: PRIME });
  assert.ok(codes(prime.etapes).includes('emploi_du_temps'));

  const ascension = parcours(['directeur'], faits, progressionVisitee(),
    { cycle: 'secondaire', droits: ASCENSION });

  assert.ok(!codes(ascension.etapes).includes('emploi_du_temps'),
    "l'étape disparaît du parcours dès que l'offre ne la comprend plus");
  // Le FAIT, lui, n'a pas été effacé : le moteur ne touche à aucune donnée.
  assert.strictEqual(faits.emploi_du_temps, true,
    'écarter une étape ne supprime jamais ce que l\'école a créé');
  assert.strictEqual(ascension.termine, true,
    'une descente d\'offre ne doit pas rendre le parcours infaisable');
});

test('la signature d\'offre change quand les droits changent, et pas autrement', () => {
  const a = catalogue.signatureDroits('ascension', ASCENSION);
  const b = catalogue.signatureDroits('ascension', ASCENSION);
  const c = catalogue.signatureDroits('prime', PRIME);

  assert.strictEqual(a, b, 'même offre, même signature : le cache doit tenir');
  assert.notStrictEqual(a, c, "changement d'offre : le cache client doit être invalidé");
  assert.ok(/^[0-9a-f]{16}$/.test(a), 'la signature est une empreinte courte, pas un secret');
});

/* =========================================================================
   6. INVARIANTS DE STRUCTURE
   ========================================================================= */

test('toute fonctionnalité citée par une étape existe dans le catalogue', () => {
  for (const e of onboarding.ETAPES) {
    if (!e.fonctionnalite) continue;
    assert.ok(e.fonctionnalite in catalogue.FONCTIONNALITES,
      `l'étape « ${e.code} » exige « ${e.fonctionnalite} », inconnue du catalogue commercial`);
  }
});

test('aucune étape ne dépend d\'un code inexistant', () => {
  for (const e of onboarding.ETAPES) {
    for (const d of (e.depend || []).concat(e.depend_souple || [])) {
      assert.ok(onboarding.PAR_CODE[d],
        `l'étape « ${e.code} » dépend de « ${d} », qui n'existe pas`);
    }
  }
});

test('les fonctions essentielles ne sont jamais conditionnées à une offre', () => {
  // Élèves, classes, notes, bulletins officiels, présences et frais forment le
  // socle : les brider pour vendre l'offre supérieure reviendrait à livrer un
  // logiciel scolaire qui ne gère pas l'école.
  const SOCLE = ['eleves', 'classes', 'cours', 'classe_cours', 'periodes',
                 'annee_scolaire', 'identite_ecole', 'personnel', 'frais',
                 'modeles_bulletins', 'decouverte_notes', 'decouverte_presences',
                 'decouverte_bulletins', 'decouverte_paiements', 'decouverte_dettes'];
  for (const code of SOCLE) {
    const e = onboarding.PAR_CODE[code];
    assert.ok(e, `étape « ${code} » introuvable`);
    assert.strictEqual(e.fonctionnalite, undefined,
      `« ${code} » est une fonction essentielle : elle ne doit dépendre d'aucune offre`);
  }
});

test('tous les rôles obtiennent un parcours terminable avec l\'offre la plus modeste', () => {
  // Le contrôle qui aurait attrapé le défaut d'origine sur n'importe quel rôle,
  // et pas seulement sur le directeur.
  for (const role of Object.keys(onboarding.PARCOURS_ROLE)) {
    const faits = ecoleInstallee();
    // Les découvertes se valident par la visite de l'écran : on simule une
    // personne qui a tout ouvert.
    const p = parcours([role], faits, progressionVisitee(),
      { cycle: 'secondaire', droits: ASCENSION });

    assert.strictEqual(p.termine, true,
      `le rôle « ${role} » ne peut pas terminer son parcours en Ascension`);
    assert.strictEqual(p.progression_pct, 100, `« ${role} » plafonne sous 100 %`);
  }
});

test('aucune branche morte, quel que soit le rôle, l\'offre et le cycle', () => {
  const offres = { ASCENSION, PRIME, PILOTE };
  for (const role of Object.keys(onboarding.PARCOURS_ROLE)) {
    for (const [nomOffre, table] of Object.entries(offres)) {
      for (const cycle of ['primaire', 'secondaire', 'les_deux']) {
        const p = parcours([role], ecoleVide({ _cycle: cycle }), progression(),
          { cycle, droits: table });
        const presentes = new Set(codes(p.etapes));

        for (const e of p.etapes) {
          for (const d of e.bloquee_par) {
            assert.ok(presentes.has(d),
              `${role}/${nomOffre}/${cycle} : « ${e.code} » bloquée par « ${d} » absente`);
          }
        }
        // Il doit TOUJOURS rester une action possible tant que le parcours
        // n'est pas terminé. C'est l'invariant qui interdit l'impasse.
        if (!p.termine) {
          assert.ok(p.prochaine,
            `${role}/${nomOffre}/${cycle} : parcours inachevé sans aucune action possible`);
        }
      }
    }
  }
});
