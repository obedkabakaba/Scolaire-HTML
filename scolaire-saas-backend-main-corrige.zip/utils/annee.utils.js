const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Année scolaire "pivot" : celle que le Directeur a activée (annees_scolaires.active = true).
 * TOUTE la plateforme doit s'aligner dessus par défaut — un professeur, un titulaire, un
 * préfet ou un secrétaire ne doit jamais pouvoir agir (ni même lire) sur une autre année
 * via les écrans courants. Seules les archives (module dédié, direction/secrétariat
 * uniquement) permettent de consulter une année révolue, et seul le comptable garde accès
 * aux frais/dettes des années antérieures (voir estExempteRestrictionAnnee ci-dessous).
 *
 * `cloturee = false` est explicite en plus de `active = true` : la contrainte
 * annees_scolaires_pivot_non_cloture le garantit désormais en base, mais une base pas
 * encore migrée ne doit pas pour autant laisser passer une année clôturée comme pivot.
 * L'ORDER BY rend le résultat déterministe : sans lui, un LIMIT 1 posé sur deux lignes
 * actives renvoyait une ligne arbitraire, et le pivot changeait d'un appel à l'autre.
 */
async function anneeActive(client) {
  const r = await client.query(
    `SELECT id, libelle, cloturee, active, date_debut, date_fin
       FROM annees_scolaires
      WHERE ecole_id = ${CURRENT_ECOLE} AND active = true AND cloturee = false
      ORDER BY date_debut DESC NULLS LAST, libelle DESC
      LIMIT 1`
  );
  return r.rows[0] || null;
}

/** Lève une erreur 409 explicite si aucune année n'a été activée par le Directeur. */
function exigerAnnee(annee) {
  if (!annee) {
    throw Object.assign(
      new Error("Aucune année scolaire active. Le Directeur doit d'abord activer une année scolaire."),
      { statusCode: 409 }
    );
  }
  return annee;
}

/**
 * Seul le comptable (et le super admin, pour le support) est autorisé à consulter des
 * données financières d'années antérieures à l'année active. Tous les autres rôles —
 * y compris directeur et préfet — restent cantonnés à l'année pivot pour les écrans
 * opérationnels courants ; la consultation d'une année révolue passe par le module
 * Archives (accès direction/secrétariat, en lecture seule, hors saisie).
 */
function estExempteRestrictionAnnee(req) {
  return req.auth.isSuperAdmin || req.auth.roles.includes('comptable');
}

/**
 * Résout l'année sur laquelle une LECTURE doit réellement porter.
 *
 * Tout point d'entrée qui accepte un `anneeScolaireId` venant du client doit passer
 * par ici. Auparavant chaque contrôleur bricolait sa propre règle — ou n'en avait
 * aucune : `listerClasses` retombait sur « toutes les années confondues » dès qu'aucun
 * pivot n'était défini, et `listerPeriodes` ne filtrait rien du tout. C'est exactement
 * ce qui faisait remonter les données d'une année révolue dans les écrans courants.
 *
 * Règles, dans l'ordre :
 *   - aucune année demandée   → l'année pivot, et rien d'autre ;
 *   - année demandée = pivot  → autorisé pour tous ;
 *   - année demandée ≠ pivot  → réservé aux rôles exemptés (comptable, super admin),
 *                               refus explicite pour tous les autres.
 *
 * @param {object} options.exigerPivot  lève une 409 s'il n'existe aucun pivot (défaut : true)
 */
async function resoudreAnneeConsultable(client, req, anneeDemandee, options = {}) {
  const { exigerPivot = true, message } = options;
  const active = await anneeActive(client);

  if (!anneeDemandee) {
    if (exigerPivot) exigerAnnee(active);
    return active ? active.id : null;
  }

  if (active && String(anneeDemandee) === String(active.id)) {
    return active.id;
  }

  if (estExempteRestrictionAnnee(req)) {
    // On vérifie que l'année appartient bien à l'école courante : la RLS filtre les
    // lignes, mais un identifiant venu d'une autre école renverrait silencieusement
    // un résultat vide plutôt qu'une erreur compréhensible.
    const verif = await client.query(
      `SELECT id FROM annees_scolaires WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
      [anneeDemandee]
    );
    if (verif.rows.length === 0) {
      throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
    }
    return anneeDemandee;
  }

  throw Object.assign(
    new Error(message || "Cette année scolaire n'est pas l'année active : seul le comptable peut consulter les années antérieures. Utilisez le module Archives."),
    { statusCode: 403 }
  );
}

/**
 * Rôles qui pilotent la structure de l'école (classes, périodes, calendrier).
 * Distincts des rôles opérationnels (professeur, titulaire) qui, eux, ne doivent
 * jamais sortir du pivot.
 */
const ROLES_GESTION = ['directeur', 'prefet', 'secretaire'];

/**
 * Variante de resoudreAnneeConsultable pour les ÉCRANS DE GESTION de la structure.
 *
 * Un pivot strict y serait ingérable : pour préparer la rentrée, le Directeur doit
 * pouvoir créer les classes et les périodes de 2026-2027 alors que 2025-2026 est
 * encore l'année active. Interdire cela obligerait à basculer le pivot en pleine
 * année scolaire — exactement ce qu'on cherche à éviter.
 *
 * La règle est donc : la direction peut adresser n'importe quelle année NON CLÔTURÉE
 * de son école (le pivot, ou une année en préparation) ; une année clôturée reste
 * accessible aux seuls rôles exemptés, et passe sinon par le module Archives.
 * Professeurs et titulaires, eux, restent enfermés dans le pivot.
 */
async function resoudreAnneeGestion(client, req, anneeDemandee) {
  const active = await anneeActive(client);

  if (!anneeDemandee) {
    exigerAnnee(active);
    return active.id;
  }
  if (active && String(anneeDemandee) === String(active.id)) return active.id;
  if (estExempteRestrictionAnnee(req)) {
    return resoudreAnneeConsultable(client, req, anneeDemandee);
  }

  const estGestionnaire = req.auth.roles.some((r) => ROLES_GESTION.includes(r));
  if (!estGestionnaire) {
    throw Object.assign(
      new Error("Vous ne pouvez travailler que sur l'année scolaire active."),
      { statusCode: 403 }
    );
  }

  const cible = await client.query(
    `SELECT id, libelle, cloturee FROM annees_scolaires
      WHERE id = $1 AND ecole_id = ${CURRENT_ECOLE}`,
    [anneeDemandee]
  );
  if (cible.rows.length === 0) {
    throw Object.assign(new Error('Année scolaire introuvable.'), { statusCode: 404 });
  }
  if (cible.rows[0].cloturee) {
    throw Object.assign(
      new Error(`L'année « ${cible.rows[0].libelle} » est clôturée : consultez-la via le module Archives.`),
      { statusCode: 403 }
    );
  }
  return cible.rows[0].id;
}

/**
 * Vérifie qu'une action (lecture ou écriture) porte bien sur l'année scolaire active.
 * `anneeScolaireId` doit être l'identifiant de l'année réellement concernée par
 * l'opération (résolu depuis la classe / la période / etc., jamais depuis une valeur
 * envoyée telle quelle par le client sans vérification).
 */
async function verifierAnneeActive(client, anneeScolaireId, { message } = {}) {
  const active = await anneeActive(client);
  if (!active || String(active.id) !== String(anneeScolaireId)) {
    throw Object.assign(
      new Error(message || "Cette opération n'est possible que sur l'année scolaire active. Consultez le module Archives pour les années antérieures."),
      { statusCode: 403 }
    );
  }
  return active;
}

/**
 * Bloque toute écriture (notes, points, présences, discipline...) sur une période dont
 * l'année scolaire n'est PAS l'année active — qu'elle soit clôturée ou simplement une
 * ancienne année encore techniquement ouverte. Une année qui n'est plus l'année pivot
 * du Directeur est déjà définitive pour les écrans du quotidien.
 */
async function verifierPeriodeActive(client, periodeId) {
  const result = await client.query(
    `SELECT a.id AS annee_id, a.libelle, a.cloturee, a.active
     FROM periodes p JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
     WHERE p.id = $1`,
    [periodeId]
  );
  const periode = result.rows[0];
  if (!periode) {
    throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
  }
  if (periode.cloturee || !periode.active) {
    throw Object.assign(
      new Error(`L'année scolaire "${periode.libelle}" n'est plus l'année active : les notes ne peuvent plus être ni consultées, ni modifiées ici (voir Archives).`),
      { statusCode: 403 }
    );
  }
  return periode;
}

/** Même règle que verifierPeriodeActive, mais à partir d'une classe. */
async function verifierClasseActive(client, classeId) {
  const result = await client.query(
    `SELECT a.id AS annee_id, a.libelle, a.cloturee, a.active
     FROM classes c JOIN annees_scolaires a ON a.id = c.annee_scolaire_id
     WHERE c.id = $1`,
    [classeId]
  );
  const classe = result.rows[0];
  if (!classe) {
    throw Object.assign(new Error('Classe introuvable.'), { statusCode: 404 });
  }
  if (classe.cloturee || !classe.active) {
    throw Object.assign(
      new Error(`La classe "${classeId}" appartient à l'année scolaire "${classe.libelle}", qui n'est plus l'année active (voir Archives).`),
      { statusCode: 403 }
    );
  }
  return classe;
}

/* ==========================================================================
   Enchaînement des années scolaires
   ========================================================================== */

/**
 * Extrait le couple d'années d'un libellé, quelle que soit la façon de l'écrire :
 * « 2025-2026 », « 2025 - 2026 », « 2025/2026 », « Année scolaire 2025-2026 ».
 * Renvoie null si rien n'est reconnu : on ne devine pas au hasard, le Directeur
 * saisira alors le libellé lui-même.
 */
function extraireAnnees(libelle) {
  const correspondance = String(libelle || '').match(/(\d{4})\s*[-–\/]\s*(\d{4})/);
  if (!correspondance) return null;
  const debut = Number(correspondance[1]);
  const fin = Number(correspondance[2]);
  if (fin !== debut + 1) return null;
  return { debut, fin };
}

/** Décale une date d'un an, au format ISO attendu par PostgreSQL. */
function decalerUnAn(valeur) {
  if (!valeur) return null;
  const d = new Date(valeur);
  if (Number.isNaN(d.getTime())) return null;
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().slice(0, 10);
}

/**
 * Propose l'année scolaire qui suit celle passée en paramètre.
 * « 2025-2026 » (01/09/2025 → 30/06/2026) devient « 2026-2027 » (01/09/2026 → 30/06/2027).
 *
 * Renvoie null si le libellé source n'est pas interprétable : mieux vaut ne rien
 * proposer qu'un libellé inventé, qui deviendrait le nom officiel de l'année.
 */
function calculerAnneeSuivante(anneeSource) {
  if (!anneeSource) return null;
  const bornes = extraireAnnees(anneeSource.libelle);
  if (!bornes) return null;

  return {
    libelle: `${bornes.debut + 1}-${bornes.fin + 1}`,
    date_debut: decalerUnAn(anneeSource.date_debut),
    date_fin: decalerUnAn(anneeSource.date_fin)
  };
}

/**
 * Préfixe de numérotation des pièces comptables (reçus, références de paiement).
 *
 * Le numéro doit porter l'année SCOLAIRE, pas l'année civile : un reçu émis en
 * janvier 2026 pour l'année 2025-2026 et numéroté « REC-2026-… » est illisible pour
 * le comptable, et surtout deux exercices scolaires se retrouvaient mélangés dans
 * la même série de janvier à juin.
 *
 * On retombe sur l'année civile uniquement si aucune année scolaire exploitable
 * n'existe : un reçu doit pouvoir être émis dans tous les cas.
 */
function prefixeNumerotation(annee) {
  const bornes = annee ? extraireAnnees(annee.libelle) : null;
  if (bornes) return `${bornes.debut}-${bornes.fin}`;

  if (annee && annee.date_debut) {
    const debut = new Date(annee.date_debut).getFullYear();
    if (!Number.isNaN(debut)) {
      const fin = annee.date_fin ? new Date(annee.date_fin).getFullYear() : debut + 1;
      return `${debut}-${Number.isNaN(fin) ? debut + 1 : fin}`;
    }
  }

  return String(new Date().getFullYear());
}

module.exports = {
  anneeActive,
  exigerAnnee,
  estExempteRestrictionAnnee,
  resoudreAnneeConsultable,
  resoudreAnneeGestion,
  ROLES_GESTION,
  verifierAnneeActive,
  verifierPeriodeActive,
  verifierClasseActive,
  calculerAnneeSuivante,
  prefixeNumerotation,
  extraireAnnees,
};
