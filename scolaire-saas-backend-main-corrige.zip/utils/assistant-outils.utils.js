const { runWithTenant } = require('../config/db');
const { sqlTotalFraisDus } = require('./frais.utils');
const { lireConfigMonetaire, sqlPaiementConverti } = require('./devise.utils');

// Même expression que dans les contrôleurs : l'école courante telle que
// `runWithTenant()` l'a posée sur la transaction.
const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Outils de l'assistant — Ardoise
 * --------------------------------------------------------------------------
 * Le modèle ne touche jamais la base. Il demande l'exécution d'un outil, et
 * c'est ce fichier qui décide de ce qui est lu, pour qui, et dans quelles
 * limites. Chaque outil reçoit une identité déjà établie — un parent lié à
 * des élèves précis, ou un membre du personnel — et ne peut pas en sortir.
 *
 * Règle constante : aucun outil n'accepte d'identifiant venu du modèle pour
 * désigner un élève. Le modèle choisit parmi une liste que NOUS avons fournie,
 * par un simple numéro d'ordre.
 */

const OUTILS_PARENT = [
  {
    name: 'resultats_eleve',
    description: "Résultats scolaires d'un des enfants du parent : pourcentage, place, mention, conduite, pour chaque période dont le bulletin a été signé par l'école.",
    input_schema: {
      type: 'object',
      properties: {
        numero_enfant: { type: 'integer', description: "Numéro de l'enfant dans la liste fournie (1 pour le premier)." }
      },
      required: ['numero_enfant']
    }
  },
  {
    name: 'assiduite_eleve',
    description: "Présences et absences d'un des enfants sur les 30 derniers jours.",
    input_schema: {
      type: 'object',
      properties: {
        numero_enfant: { type: 'integer', description: "Numéro de l'enfant dans la liste fournie." }
      },
      required: ['numero_enfant']
    }
  },
  {
    name: 'frais_eleve',
    description: "Situation des frais scolaires d'un des enfants : montant attendu, versé, reste dû.",
    input_schema: {
      type: 'object',
      properties: {
        numero_enfant: { type: 'integer', description: "Numéro de l'enfant dans la liste fournie." }
      },
      required: ['numero_enfant']
    }
  },
  {
    name: 'annonces_ecole',
    description: "Dernières annonces publiées par l'école.",
    input_schema: { type: 'object', properties: {} }
  },
  {
    name: 'calendrier_ecole',
    description: "Prochains événements inscrits au calendrier de l'école.",
    input_schema: { type: 'object', properties: {} }
  }
];

const OUTILS_PERSONNEL = [
  {
    name: 'mes_cours_aujourdhui',
    description: "Cours que l'enseignant donne aujourd'hui, avec horaires et classes.",
    input_schema: { type: 'object', properties: {} }
  },
  {
    name: 'effectif_mes_classes',
    description: "Classes dont l'utilisateur est titulaire, avec leur effectif.",
    input_schema: { type: 'object', properties: {} }
  },
  {
    name: 'annonces_ecole',
    description: "Dernières annonces publiées par l'école.",
    input_schema: { type: 'object', properties: {} }
  },
  {
    name: 'calendrier_ecole',
    description: "Prochains événements inscrits au calendrier de l'école.",
    input_schema: { type: 'object', properties: {} }
  }
];

function nomComplet(e) {
  return [e.nom, e.postnom, e.prenom].filter(Boolean).join(' ');
}

/**
 * Fabrique l'exécuteur d'outils pour une identité donnée.
 * @param {object} identite { type:'parent'|'personnel', ecoleId, enfants[], utilisateurId }
 */
function creerExecuteur(identite) {
  const contexte = { ecoleId: identite.ecoleId, isSuperAdmin: false };

  /** Résout un numéro d'ordre en enfant réel. Refuse tout ce qui sort de la liste. */
  function enfantDeLaListe(numero) {
    const index = Number(numero) - 1;
    const enfant = identite.enfants && identite.enfants[index];
    if (!enfant) {
      throw new Error("Cet enfant ne figure pas dans la liste des enfants rattachés à ce numéro.");
    }
    return enfant;
  }

  return async function executer(nom, entree) {
    switch (nom) {

      case 'resultats_eleve': {
        const enfant = enfantDeLaListe(entree.numero_enfant);
        return runWithTenant(contexte, async (client) => {
          // Seuls les bulletins SIGNÉS sortent : un bulletin en cours de
          // calcul ne doit jamais parvenir à une famille.
          const r = await client.query(
            `SELECT p.libelle AS periode, p.numero, b.pourcentage, b.total,
                    b.classement, b.mention, b.conduite
             FROM bulletins b
             JOIN periodes p ON p.id = b.periode_id
             WHERE b.eleve_id = $1 AND b.signe_at IS NOT NULL
             ORDER BY p.numero`,
            [enfant.id]
          );
          const effectif = await client.query(
            `SELECT count(*) AS nb FROM eleves WHERE classe_id = $1 AND statut = 'actif'`,
            [enfant.classe_id]
          );
          return {
            eleve: enfant.nom_complet, classe: enfant.classe_nom,
            effectif_classe: Number(effectif.rows[0].nb),
            bulletins: r.rows.map((b) => ({
              periode: b.periode || `Période ${b.numero}`,
              pourcentage: b.pourcentage === null ? null : Number(b.pourcentage),
              total: b.total === null ? null : Number(b.total),
              place: b.classement, mention: b.mention, conduite: b.conduite
            })),
            note: r.rows.length === 0 ? "Aucun bulletin n'a encore été publié pour cet élève." : undefined
          };
        });
      }

      case 'assiduite_eleve': {
        const enfant = enfantDeLaListe(entree.numero_enfant);
        return runWithTenant(contexte, async (client) => {
          const r = await client.query(
            `SELECT count(*) FILTER (WHERE statut = 'present') AS present,
                    count(*) FILTER (WHERE statut = 'absent')  AS absent,
                    count(*) FILTER (WHERE statut = 'retard')  AS retard,
                    count(*) FILTER (WHERE statut = 'excuse')  AS excuse,
                    count(*) AS total
             FROM presences
             WHERE eleve_id = $1 AND date_jour >= current_date - 30`,
            [enfant.id]
          );
          const l = r.rows[0];
          if (Number(l.total) === 0) {
            return { eleve: enfant.nom_complet, note: "Aucun appel enregistré pour cet élève sur les 30 derniers jours." };
          }
          return {
            eleve: enfant.nom_complet, periode: '30 derniers jours',
            jours_appeles: Number(l.total), presences: Number(l.present),
            absences: Number(l.absent), retards: Number(l.retard), absences_excusees: Number(l.excuse)
          };
        });
      }

      case 'frais_eleve': {
        const enfant = enfantDeLaListe(entree.numero_enfant);
        return runWithTenant(contexte, async (client) => {
          // Ce chiffre part par WhatsApp à un parent : c'est la réponse la plus
          // engageante de tout l'assistant, et c'était la plus fausse. Trois
          // défauts cumulés, tous corrigés ici :
          //
          //   1. Une seule ligne de frais était retenue (LIMIT 1). Une école
          //      réclamant inscription + minerval + laboratoire n'en annonçait
          //      qu'une, et le parent se croyait quitte.
          //   2. Les versements étaient sommés sur TOUTE la scolarité, toutes
          //      années confondues : ce qui avait été payé l'an dernier venait
          //      éteindre la dette de cette année.
          //   3. Aucune conversion : des francs et des dollars étaient
          //      additionnés bruts, et le montant partait SANS devise. « Il
          //      vous reste 200 » ne veut rien dire à Kinshasa.
          const annee = await client.query(
            `SELECT id FROM annees_scolaires
              WHERE ecole_id = ${CURRENT_ECOLE} AND active = true AND cloturee = false
              ORDER BY date_debut DESC NULLS LAST LIMIT 1`
          );
          const anneeId = annee.rows[0]?.id || null;
          if (!anneeId) {
            return { eleve: enfant.nom_complet, note: "Aucune année scolaire n'est active." };
          }

          const { devise_principale: devise, taux_change_usd_fc: taux } =
            await lireConfigMonetaire(client);

          const r = await client.query(
            `SELECT ${sqlTotalFraisDus('$2', '$3', '$4', 5, CURRENT_ECOLE)} AS attendu,
                    COALESCE((
                      SELECT SUM(${sqlPaiementConverti('p', '$4', 5)})
                        FROM paiements_frais p
                       WHERE p.ecole_id = ${CURRENT_ECOLE}
                         AND p.eleve_id = $1 AND p.annee_scolaire_id = $3
                    ), 0) AS verse`,
            [enfant.id, enfant.classe_id, anneeId, devise, taux || null]
          );
          const attendu = Number(r.rows[0].attendu);
          const verse = Number(r.rows[0].verse);
          if (attendu === 0) {
            return { eleve: enfant.nom_complet, note: "Aucun frais n'est paramétré pour cette classe." };
          }
          return {
            eleve: enfant.nom_complet,
            devise,
            montant_attendu: Math.round(attendu * 100) / 100,
            montant_verse: Math.round(verse * 100) / 100,
            reste_du: Math.round(Math.max(attendu - verse, 0) * 100) / 100
          };
        });
      }

      case 'annonces_ecole':
        return runWithTenant(contexte, async (client) => {
          const r = await client.query(
            `SELECT titre, contenu, date_publication FROM annonces
             WHERE publiee = true ORDER BY date_publication DESC LIMIT 5`
          );
          return r.rows.length ? { annonces: r.rows } : { note: "Aucune annonce publiée pour le moment." };
        });

      case 'calendrier_ecole':
        return runWithTenant(contexte, async (client) => {
          const r = await client.query(
            `SELECT titre, type::text, date_debut, date_fin FROM evenements_calendrier
             WHERE date_debut >= now() - interval '1 day'
             ORDER BY date_debut LIMIT 8`
          );
          return r.rows.length ? { evenements: r.rows } : { note: "Aucun événement à venir n'est inscrit au calendrier." };
        });

      case 'mes_cours_aujourdhui':
        return runWithTenant(contexte, async (client) => {
          const jsJour = new Date().getDay();
          const jour = jsJour === 0 ? 7 : jsJour;
          const r = await client.query(
            `SELECT cr.libelle AS creneau, cr.heure_debut, cr.heure_fin,
                    c.nom AS classe, co.nom AS cours
             FROM emploi_du_temps edt
             JOIN creneaux cr ON cr.id = edt.creneau_id
             JOIN classe_cours cc ON cc.id = edt.classe_cours_id
             JOIN cours co ON co.id = cc.cours_id
             JOIN classes c ON c.id = edt.classe_id
             JOIN enseignant_cours ec ON ec.classe_cours_id = cc.id
             JOIN annees_scolaires a ON a.id = edt.annee_scolaire_id AND a.active = true
             WHERE ec.utilisateur_id = $1 AND edt.jour = $2
             ORDER BY cr.ordre`,
            [identite.utilisateurId, jour]
          );
          return r.rows.length ? { cours: r.rows } : { note: "Aucun cours n'est programmé pour vous aujourd'hui." };
        });

      case 'effectif_mes_classes':
        return runWithTenant(contexte, async (client) => {
          const r = await client.query(
            `SELECT c.nom AS classe,
                    (SELECT count(*) FROM eleves e WHERE e.classe_id = c.id AND e.statut = 'actif') AS effectif
             FROM classes c
             JOIN annees_scolaires a ON a.id = c.annee_scolaire_id AND a.active = true
             WHERE c.titulaire_id = $1
             ORDER BY c.nom`,
            [identite.utilisateurId]
          );
          return r.rows.length
            ? { classes: r.rows.map((c) => ({ classe: c.classe, effectif: Number(c.effectif) })) }
            : { note: "Vous n'êtes titulaire d'aucune classe cette année." };
        });

      default:
        throw new Error('Outil inconnu.');
    }
  };
}

module.exports = { OUTILS_PARENT, OUTILS_PERSONNEL, creerExecuteur, nomComplet };
