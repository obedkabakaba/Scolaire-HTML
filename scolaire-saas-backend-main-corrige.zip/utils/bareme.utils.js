/**
 * ============================================================================
 *  BARÈME D'UN COURS — règle unique du maximum applicable
 * ============================================================================
 *
 * LA RÈGLE, telle qu'elle est imprimée sur les bulletins officiels
 * -----------------------------------------------------------------
 *   période ordinaire  → maximum = classe_cours.maximum_points_override
 *                                  ?? cours.maximum_points
 *   période d'examen   → maximum = classe_cours.maximum_examen_override
 *                                  ?? cours.maximum_examen
 *                        et si cette valeur est NULL → 2 × le maximum de période
 *                        et si cette valeur vaut 0   → le cours n'est pas examiné
 *
 * `NULL` et `0` disent deux choses opposées, et c'est tout l'enjeu :
 *
 *   · `NULL` = « l'école n'a pas encore configuré le barème d'examen ». C'est
 *     la valeur PAR DÉFAUT à la création d'un cours, donc le cas le plus
 *     fréquent. Le barème vaut alors le double de la période, comme le veut
 *     l'usage congolais.
 *   · `0`    = « ce cours ne fait pas l'objet d'un examen ». La case est
 *     noircie sur le bulletin, et le cours ne compte ni au numérateur ni au
 *     dénominateur.
 *
 * POURQUOI CE FICHIER EXISTE
 * --------------------------
 * La règle était écrite correctement à deux endroits
 * (`bulletin-assemblage-officiel.js`, `moyennes.utils.js`) et fausse à trois
 * autres, chaque fois d'une manière différente :
 *
 *   · `notes.controller.js` ne connaissait pas du tout le maximum d'examen. Il
 *     validait la saisie ET calculait le pourcentage sur le maximum de PÉRIODE.
 *     Sur une session d'examen, un professeur saisissant 35 sur 40 se voyait
 *     répondre « la note doit être comprise entre 0 et 20 », et les
 *     pourcentages enregistrés pouvaient dépasser 100 %.
 *   · `repechage.controller.js` et `parcours.controller.js` repliaient un
 *     maximum d'examen non configuré sur `0`, c'est-à-dire sur « pas
 *     d'examen ». Le dénominateur s'effondrait, le pourcentage gonflait, et
 *     des élèves réellement en échec n'étaient plus proposés au repêchage.
 *
 * Trois écritures d'une même règle, trois résultats différents pour le même
 * élève. D'où une source unique, et des tests qui la verrouillent.
 */

/**
 * Maximum applicable à un cours pour une période donnée, en JavaScript.
 *
 * @param {number|string|null} maximumPeriode  maximum de période (après override)
 * @param {number|string|null|undefined} maximumExamen  maximum d'examen (après override)
 * @param {string} typePeriode  'examen' ou tout autre type
 * @returns {number} le maximum, 0 signifiant « ce cours n'est pas examiné »
 */
function maximumApplicable(maximumPeriode, maximumExamen, typePeriode) {
  const periode = Number(maximumPeriode || 0);
  if (String(typePeriode) !== 'examen') return periode;
  if (maximumExamen === null || maximumExamen === undefined || maximumExamen === '') {
    return periode * 2;
  }
  return Number(maximumExamen);
}

/**
 * Fragment SQL équivalent, pour les requêtes qui agrègent en base.
 *
 * `COALESCE` seul ne peut pas exprimer « NULL vaut le double » : il faut un
 * CASE explicite, sans quoi on retombe sur le repli à 0 qui a produit le bug
 * du repêchage.
 *
 * @param {string} aliasClasseCours  alias de classe_cours (ex. 'cc')
 * @param {string} aliasCours        alias de cours (ex. 'co')
 * @param {string} exprTypePeriode   expression SQL donnant le type de période,
 *                                   déjà en texte (ex. "p.type::text")
 */
function sqlMaximumApplicable(aliasClasseCours, aliasCours, exprTypePeriode) {
  const periode = `COALESCE(${aliasClasseCours}.maximum_points_override, ${aliasCours}.maximum_points, 0)`;
  const examen = `COALESCE(${aliasClasseCours}.maximum_examen_override, ${aliasCours}.maximum_examen)`;
  return `CASE
            WHEN ${exprTypePeriode} = 'examen'
              THEN CASE WHEN ${examen} IS NULL THEN ${periode} * 2 ELSE ${examen} END
            ELSE ${periode}
          END`;
}

module.exports = { maximumApplicable, sqlMaximumApplicable };
