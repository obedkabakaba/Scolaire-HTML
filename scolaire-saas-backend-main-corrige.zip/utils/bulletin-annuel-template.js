/**
 * Construit le HTML du bulletin annuel : A4 portrait, 1 page complète par élève,
 * récapitulant le résultat de chaque période/trimestre/semestre + la moyenne
 * annuelle, le classement annuel et la mention finale.
 * Modèle totalement indépendant du bulletin de période (4 colonnes paysage).
 */
/**
 * SIGNATURES — les deux cases portaient un libellé mais aucune image.
 *
 * « Signature du titulaire » et « Signature du directeur » étaient deux traits
 * vides à remplir à la main, alors que l'école a déposé ces images et que le
 * bulletin de période les imprime. Pire, le contrôleur allait chercher une
 * signature en base sans que ce gabarit ne l'utilise jamais. On imprime donc
 * chacune à sa place — et rien d'autre : une case reste un trait vide si la
 * personne concernée n'a pas déposé sa signature, plutôt que d'y mettre celle
 * de quelqu'un d'autre.
 */
function construireHtmlBulletinAnnuel({
  ecole, anneeLibelle, classe, eleves, mentionDuplicata,
  signatureTitulaireUrl, titulaireNom,
  signatureChefUrl, chefNom, cachetUrl
}) {
  const styles = `
    @page { size: A4 portrait; margin: 15mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 11px; margin: 0; }
    .page { page-break-after: always; }
    .page:last-child { page-break-after: auto; }
    .entete { text-align: center; margin-bottom: 6mm; }
    .entete img { max-height: 20mm; margin-bottom: 2mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 15px; }
    .entete .annee { font-size: 11px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; font-size: 14px; margin: 4mm 0; }
    /* Voir bulletin-template.js : un duplicata doit rester identifiable. */
    .mention-duplicata {
      text-align: center; font-size: 9px; letter-spacing: 0.06em;
      text-transform: uppercase; color: #8a2b2b;
      border: 0.5px solid #8a2b2b; border-radius: 1mm;
      padding: 1mm 2mm; margin: 0 auto 3mm auto; max-width: 90mm;
    }
    .identite { margin-bottom: 5mm; font-size: 11px; }
    .identite div { margin-bottom: 1mm; }
    table.periodes { width: 100%; border-collapse: collapse; font-size: 10.5px; margin-bottom: 5mm; }
    table.periodes th, table.periodes td { border: 0.5px solid #666; padding: 2mm; text-align: center; }
    table.periodes th { background: #eee; }
    .synthese-annuelle { border: 1px solid #333; padding: 4mm; font-size: 12px; margin-bottom: 6mm; }
    .synthese-annuelle div { display: flex; justify-content: space-between; padding: 1mm 0; border-bottom: 0.5px dotted #999; }
    .signatures { margin-top: 15mm; display: flex; justify-content: space-around; gap: 6mm; font-size: 10px; }
    .signatures .case { border-top: 0.5px solid #333; flex: 1; text-align: center; padding-top: 2mm; }
    .signatures .case img { max-height: 14mm; max-width: 100%; display: block; margin: 0 auto 1mm auto; }
    .signatures .case .espace { height: 14mm; }
    .signatures .nom-signataire { font-size: 8.5px; color: #444; margin-top: 0.5mm; }
  `;

  function pageEleve(eleve) {
    const lignesPeriodes = eleve.periodes.map((p) => `
      <tr>
        <td>${p.libelle}</td>
        <td>${p.total ?? '-'}</td>
        <td>${p.pourcentage ?? '-'}%</td>
        <td>${p.classement ?? '-'}</td>
        <td>${p.mention ?? '-'}</td>
      </tr>
    `).join('');

    return `
      <div class="page">
        <div class="entete">
          ${ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${ecole.nom}</div>
          <div class="annee">Année scolaire ${anneeLibelle || ''}</div>
        </div>
        <div class="titre-bulletin">Bulletin Annuel</div>
        ${mentionDuplicata ? `<div class="mention-duplicata">${mentionDuplicata}</div>` : ''}
        <div class="identite">
          <div><strong>Nom :</strong> ${eleve.nom} ${eleve.postnom || ''} ${eleve.prenom || ''}</div>
          <div><strong>Matricule :</strong> ${eleve.matricule}</div>
          <div><strong>Classe :</strong> ${classe.nom} ${classe.section_nom ? '— ' + classe.section_nom : ''} ${classe.option_nom ? '(' + classe.option_nom + ')' : ''}</div>
        </div>
        <table class="periodes">
          <thead>
            <tr><th>Période</th><th>Total</th><th>Pourcentage</th><th>Classement</th><th>Mention</th></tr>
          </thead>
          <tbody>${lignesPeriodes}</tbody>
        </table>
        <div class="synthese-annuelle">
          <div><span>Moyenne annuelle</span><span>${eleve.moyenne_annuelle ?? '-'}%</span></div>
          <div><span>Classement annuel</span><span>${eleve.classement_annuel ?? '-'} / ${eleves.length}</span></div>
          <div><span>Mention annuelle</span><span>${eleve.mention_annuelle ?? '-'}</span></div>
        </div>
        <div class="signatures">
          <div class="case">
            ${signatureTitulaireUrl ? `<img src="${signatureTitulaireUrl}" />` : '<div class="espace"></div>'}
            <div>Signature du titulaire</div>
            ${signatureTitulaireUrl && titulaireNom ? `<div class="nom-signataire">${titulaireNom}</div>` : ''}
          </div>
          <div class="case">
            ${signatureChefUrl ? `<img src="${signatureChefUrl}" />` : '<div class="espace"></div>'}
            <div>Le Chef d'Établissement</div>
            ${signatureChefUrl && chefNom ? `<div class="nom-signataire">${chefNom}</div>` : ''}
          </div>
          <div class="case">
            ${cachetUrl ? `<img src="${cachetUrl}" />` : '<div class="espace"></div>'}
            <div>Cachet de l'école</div>
          </div>
        </div>
      </div>
    `;
  }

  const pagesHtml = eleves.map(pageEleve).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletinAnnuel };
