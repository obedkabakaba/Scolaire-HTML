/**
 * Bloc « EXAMEN D'ÉTAT » — colonne de droite du bulletin de terminale.
 *
 * RÈGLE CENTRALE : ce bloc s'imprime VIERGE.
 *
 * Les points de l'examen d'État ne viennent pas de l'école : ils sont établis
 * par le centre d'examen, et transmis bien après l'édition du bulletin. La
 * plateforme n'a donc rien à y écrire — elle imprime le cadre, l'école le
 * remplit à la main.
 *
 * C'est la raison pour laquelle chaque champ est un espace réglé (case à
 * cocher, ligne pointillée, cases à chiffres) dimensionné pour l'écriture
 * manuscrite, et non un emplacement de donnée. Pré-remplir ces champs avec des
 * valeurs calculées par l'école produirait un document faux : un bulletin de
 * fin de cycle porte le résultat officiel de l'État, pas une estimation locale.
 *
 * Le bloc n'apparaît QUE sur les bulletins de terminale (classe de 4ᵉ des
 * humanités). Les autres classes portent à cet endroit la colonne « Examen de
 * repêchage ».
 */

/** Cases à chiffres vides, pour une saisie manuscrite chiffre par chiffre. */
function casesChiffres(nombre) {
  return `<div class="ee-cases">${'<span class="ee-case"></span>'.repeat(nombre)}</div>`;
}

const STYLE_EXAMEN_ETAT = `
  .examen-etat {
    border: 1px solid #000;
    display: flex; flex-direction: column;
    font-size: 7px; line-height: 1.5;
    padding: 0; height: 100%;
  }
  .ee-titre {
    text-align: center; font-weight: bold; font-size: 7.5px;
    letter-spacing: 0.04em; padding: 1mm 0.5mm;
    border-bottom: 1px solid #000;
  }
  .ee-corps { padding: 1mm 1.5mm; display: flex; flex-direction: column; gap: 1.6mm; flex: 1; }

  /* Tableau des points. Les deux cellules de valeur restent vides :
     elles sont remplies à la main depuis le relevé du centre. */
  .ee-points { border-collapse: collapse; width: 100%; }
  .ee-points td, .ee-points th {
    border: 1px solid #000; text-align: center;
    font-size: 6.2px; font-weight: normal; padding: 0.3mm 0.2mm;
  }
  .ee-points th { font-weight: bold; line-height: 1.15; }
  .ee-points td.saisie { height: 4.5mm; }
  .ee-points td.etiquette { font-weight: bold; width: 22%; }
  .ee-points td.ee-noir, .ee-points th.ee-noir { background: #000; }

  .ee-ligne { margin: 0; }
  .ee-libelle { font-weight: bold; }
  .ee-pointilles {
    border-bottom: 0.8px dotted #000;
    display: inline-block; min-width: 12mm; height: 2.6mm; vertical-align: bottom;
  }
  .ee-pointilles.large { display: block; width: 100%; margin-top: 0.8mm; }

  .ee-cases { display: flex; gap: 0.4mm; margin-top: 0.8mm; }
  .ee-case {
    border: 1px solid #000; width: 4mm; height: 4.5mm; display: block;
  }

  .ee-resultat { margin-top: 0.5mm; }
  .ee-resultat .ee-libelle { display: block; margin-bottom: 0.8mm; }
  .ee-option { display: block; margin-bottom: 0.6mm; }

  /* Zone de signature et de cachet : volontairement laissée creuse, le tampon
     de l'école a besoin de place (les sceaux ronds font 30 à 40 mm). */
  .ee-signature { margin-top: auto; text-align: center; }
  .ee-signature .ee-libelle { display: block; }
  .ee-espace-sceau { height: 16mm; }
`;

/**
 * @param {object} options.mentionLegale  numéro de renvoi utilisé par le
 *        modèle officiel pour « Biffer la mention inutile » (par défaut « 1 »)
 */
function construireBlocExamenEtat({ mentionLegale = '1' } = {}) {
  return `
  <div class="examen-etat">
    <div class="ee-titre">EXAMEN D'ÉTAT</div>
    <div class="ee-corps">

      <!-- Les cases noircies ne sont pas décoratives : la colonne d'étiquette
           n'a rien à recevoir en face de « Points Obtenus », et un MAX n'a pas
           de sens en face d'un pourcentage. Les laisser blanches donnerait à
           l'école des cases à remplir là où le centre d'examen n'attend rien. -->
      <table class="ee-points">
        <tr>
          <th class="ee-noir"></th>
          <th>Points<br/>Obtenus</th>
          <th>MAX</th>
        </tr>
        <tr>
          <td class="ee-noir"></td>
          <td class="saisie"></td>
          <td class="saisie"></td>
        </tr>
        <tr>
          <td class="etiquette">%</td>
          <td class="saisie"></td>
          <td class="ee-noir"></td>
        </tr>
      </table>

      <div class="ee-ligne">
        <span class="ee-libelle">Pour le contrôle</span><br/>
        Le <span class="ee-pointilles"></span>
      </div>

      <div class="ee-ligne">
        <span class="ee-libelle">Nom et signature<br/>du Chef de Centre</span>
        <span class="ee-pointilles large"></span>
        <span class="ee-pointilles large"></span>
      </div>

      <div class="ee-ligne">
        <span class="ee-libelle">Code du Centre</span>
        ${casesChiffres(5)}
      </div>

      <!-- Trois lignes SÉPARÉES, et « Diplôme » au substantif : c'est ainsi que
           le modèle officiel les imprime. Les fondre en « Diplômé (1) avec … % »
           ferait de la mention et du pourcentage une seule option à biffer,
           alors que le pourcentage se remplit quel que soit le résultat. -->
      <div class="ee-resultat">
        <span class="ee-libelle">RÉSULTAT FINAL</span>
        <span class="ee-option">Diplôme (${mentionLegale})</span>
        <span class="ee-option">Avec <span class="ee-pointilles"></span> %</span>
        <span class="ee-option">A échoué (${mentionLegale})</span>
      </div>

      <div class="ee-ligne">
        <span class="ee-libelle">Pour témoignage</span><br/>
        Le <span class="ee-pointilles"></span>
      </div>

      <div class="ee-signature">
        <span class="ee-libelle">Le Chef d'Établissement</span>
        <div class="ee-espace-sceau"></div>
        Sceau de l'école
      </div>

    </div>
  </div>`;
}

module.exports = { construireBlocExamenEtat, STYLE_EXAMEN_ETAT };
