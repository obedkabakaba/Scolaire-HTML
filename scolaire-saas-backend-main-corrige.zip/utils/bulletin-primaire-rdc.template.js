const { DRAPEAU_RDC_SVG } = require('./drapeau-rdc.svg');
const { ARMOIRIES_RDC_DATA_URI } = require('./armoiries-rdc.asset');

/**
 * Bulletin officiel du PRIMAIRE (degré élémentaire) — République Démocratique
 * du Congo.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * CE QUI LE DISTINGUE DU SECONDAIRE
 *
 * 1. TRIMESTRES, pas semestres. Trois trimestres, six périodes, un examen par
 *    trimestre. La colonne de droite « examen de repêchage » n'existe pas :
 *    au degré élémentaire on ne repêche pas, on passe ou on double.
 *
 * 2. LES MAXIMA SONT PORTÉS PAR CHAQUE LIGNE. Le secondaire insère une ligne
 *    MAXIMA avant chaque groupe de barème ; le primaire imprime le maximum sur
 *    la ligne de la branche elle-même, dans ses propres colonnes (MAX per,
 *    MAX EX., MAX TRIM.). C'est pour cela qu'il n'y a pas de ligne MAXIMA ici.
 *
 * 3. BRANCHES GROUPÉES EN DOMAINES, avec un sous-total par groupe. Un domaine
 *    peut contenir des groupes nommés (Langues congolaises, Français) ou des
 *    branches directement ; dans le second cas le sous-total clôt le domaine.
 *
 * 4. DEUX LIGNES DE SIGNATURE, instituteur et responsable. Au degré élémentaire
 *    un maître unique tient toute la classe : il n'y a pas de signature par
 *    cours, l'instituteur signe chaque trimestre et le parent contresigne.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * BARÈME, relevé sur la photo
 *
 *   examen    = 2 × maximum de période
 *   trimestre = période + période + examen  = 4 × maximum de période
 *   total     = 3 × trimestre               = 12 × maximum de période
 *
 * Vérifié sur la ligne « Maxima généraux » du bulletin photographié :
 * 300 de maximum par période → 600 à l'examen, 1200 au trimestre, 3600 au total.
 */

const ECHAPPEMENTS = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function echapper(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, (c) => ECHAPPEMENTS[c]);
}

function cote(v) {
  return v === null || v === undefined || v === '' ? '' : echapper(v);
}

function cases(n) {
  return `<span class="cases">${'<span class="case"></span>'.repeat(n)}</span>`;
}

/**
 * Métriques FIXES, comme au secondaire : toutes les lignes ont la même hauteur
 * quel qu'en soit le nombre, et le bulletin s'arrête où il s'arrête.
 *
 * La police est plus petite qu'au secondaire parce que le tableau compte 21
 * colonnes de chiffres contre 9 : à largeur de feuille égale, chaque colonne
 * dispose de deux fois moins de place.
 */
const METRIQUES = {
  hauteur: '3.4mm',
  police: '7.4px',
  policeTete: '6.2px',
  pad: '0.3mm',
};

function baremePrimaire(maxPeriode) {
  const p = Number(maxPeriode) || 0;
  const examen = p * 2;
  const trimestre = p + p + examen;
  return { periode: p, examen, trimestre, total: trimestre * 3 };
}

/**
 * Disposition des 21 colonnes de chiffres.
 *
 * `max: true` marque les colonnes de MAXIMUM. Elles sont noircies sur les
 * lignes de synthèse — un maximum n'a aucun sens en face d'un pourcentage,
 * d'une place ou d'une signature. C'est le peigne noir caractéristique du
 * modèle, relevé sur la photo cadrée du bas de tableau : sur la ligne
 * POURCENTAGE, les cases noires tombent exactement sous 300, 600 et 1200 de la
 * ligne « Maxima généraux », et les valeurs sous les colonnes de points obtenus.
 *
 * « MAX per » n'apparaît qu'une fois, dans le premier trimestre : le maximum
 * par période ne change pas d'un trimestre à l'autre.
 */
const COLONNES = [
  { cle: 'maxPeriode', max: true },
  { cle: 'p1' }, { cle: 'p2' },
  { cle: 'maxExamen', max: true }, { cle: 'ex1' },
  { cle: 'maxTrimestre', max: true }, { cle: 't1' },
  { cle: 'p3' }, { cle: 'p4' },
  { cle: 'maxExamen', max: true }, { cle: 'ex2' },
  { cle: 'maxTrimestre', max: true }, { cle: 't2' },
  { cle: 'p5' }, { cle: 'p6' },
  { cle: 'maxExamen', max: true }, { cle: 'ex3' },
  { cle: 'maxTrimestre', max: true }, { cle: 't3' },
  { cle: 'maxTotal', max: true }, { cle: 'total' },
];

const NB_COLONNES = COLONNES.length + 1; // + la colonne BRANCHES

function styles(m = METRIQUES) {
  return `
  @page { size: A4 portrait; margin: 6mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Times New Roman', Times, serif; font-size: 8px; color: #000; margin: 0; }
  .page { page-break-after: always; }
  .page:last-child { page-break-after: auto; }

  /* ---------- En-tête officiel ---------- */
  .entete { display: flex; align-items: center; border: 1.3px solid #000; }
  .entete .drapeau { width: 24mm; height: 17mm; flex: none; padding: 1mm; }
  .entete .armoiries {
    width: 17mm; height: 17mm; flex: none; margin: 1mm;
    background-image: url('${ARMOIRIES_RDC_DATA_URI}');
    background-size: contain; background-repeat: no-repeat; background-position: center;
  }
  .entete .titre { flex: 1; text-align: center; font-weight: bold; line-height: 1.4; padding: 0 2mm; }
  .entete .titre .pays { display: block; font-size: 12px; }
  .entete .titre .ministere { display: block; font-size: 8.5px; font-weight: normal; margin-top: 0.6mm; }

  .cases { display: inline-flex; gap: 0; vertical-align: middle; }
  .case { border: 0.6px solid #000; width: 3.4mm; height: 3.8mm; display: inline-block; }

  .bandeau-id { border: 1.3px solid #000; border-top: none; padding: 0.8mm 2mm; display: flex; align-items: center; gap: 2mm; }
  .bandeau-id .libelle { font-weight: bold; }

  /* PROVINCE et VILLE courent sur toute la largeur ; le filet vertical ne
     commence qu'à la ligne COMMUNE / TER. */
  .identite-large { border: 1.3px solid #000; border-top: none; padding: 0.9mm 2mm; }
  .identite-large .champ { white-space: nowrap; overflow: hidden; }
  .identite { display: flex; border: 1.3px solid #000; border-top: none; }
  .identite .colonne { width: 51%; flex: none; padding: 1mm 2mm; }
  .identite .colonne + .colonne { width: 49%; border-left: 1.3px solid #000; }
  .identite .champ { margin-bottom: 0.9mm; white-space: nowrap; overflow: hidden; }
  .identite .champ.duo { display: flex; justify-content: space-between; gap: 2mm; }
  .pointilles { border-bottom: 0.8px dotted #000; display: inline-block; min-width: 14mm; height: 2.6mm; vertical-align: bottom; }
  .pointilles.long { min-width: 32mm; }

  .ligne-bulletin {
    border: 1.3px solid #000; border-top: none; padding: 1mm 2mm;
    display: flex; justify-content: space-between; font-weight: bold; font-size: 9px;
  }

  /* ---------- Tableau des branches ---------- */
  table.cotes { border-collapse: collapse; width: 100%; table-layout: fixed; }
  table.cotes th, table.cotes td {
    border: 1px solid #000; text-align: center;
    padding: ${m.pad} 0.2mm; font-size: ${m.police};
  }
  table.cotes th { font-weight: bold; font-size: ${m.policeTete}; line-height: 1.2; }
  table.cotes tbody td { height: ${m.hauteur}; }
  table.cotes td.branche {
    text-align: left; padding-left: 1.2mm; font-size: ${m.police};
    white-space: nowrap; overflow: hidden;
  }

  /* Bandeau de domaine : une ligne pleine largeur, titre centré. */
  table.cotes tr.domaine td {
    font-weight: bold; text-align: center; letter-spacing: 0.04em;
    font-size: ${m.policeTete};
  }
  /* Nom de groupe (LANGUES CONGOLAISES, FRANÇAIS) : libellé seul, en gras. */
  table.cotes tr.groupe td.branche { font-weight: bold; }
  table.cotes tr.sous-total td { font-weight: bold; }
  table.cotes tr.synthese td { font-weight: bold; }
  table.cotes tr.synthese td.branche { text-transform: uppercase; }

  /* Aplats noirs. Le mot-clé important est nécessaire : les règles de ligne
     ci-dessus ont une spécificité supérieure et repeindraient par-dessus. */
  table.cotes td.noir { background: #000 !important; }

  /* ---------- Pied ---------- */
  .pied { border: 1px solid #000; border-top: none; padding: 2mm; font-size: 8px; }
  .pied .options { line-height: 1.8; }
  .pied .bas { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 2mm; }
  .pied .bas .case-sign { text-align: center; min-width: 45mm; }
  .pied .bas .case-sign img { max-height: 11mm; max-width: 100%; display: block; margin: 0 auto 0.6mm; }
  .pied .espace-sceau { height: 12mm; }
  .pied .legal { margin-top: 1.5mm; font-size: 6.8px; font-style: italic; line-height: 1.5; }
  .pied .reference { text-align: right; font-size: 6.8px; }

  .duplicata {
    text-align: center; font-size: 7.5px; letter-spacing: 0.06em; text-transform: uppercase;
    color: #8a2b2b; border: 0.6px solid #8a2b2b; border-radius: 1mm;
    padding: 0.6mm 1mm; margin: 1mm auto; max-width: 70mm;
  }
  `;
}

function enTeteTableau() {
  const trimestre = (n, cols) => `<th colspan="${cols}">${n}</th>`;
  // « MAX per » n'existe que dans le premier trimestre : 7 colonnes contre 6.
  return `
    <thead>
      <tr>
        <th rowspan="2" class="branche" style="width:20%">BRANCHES</th>
        ${trimestre('PREMIER TRIMESTRE', 7)}
        ${trimestre('DEUXIÈME TRIMESTRE', 6)}
        ${trimestre('TROISIÈME TRIMESTRE', 6)}
        ${trimestre('TOTAL', 2)}
      </tr>
      <tr>
        <th>MAX<br/>per</th><th>1<sup>ère</sup>P</th><th>2<sup>e</sup>P</th>
        <th>MAX<br/>EX.</th><th>PTS<br/>OBT.</th><th>MAX<br/>TRIM.</th><th>PTS<br/>OBT.</th>
        <th>3<sup>e</sup>P</th><th>4<sup>e</sup>P</th>
        <th>MAX<br/>EX.</th><th>PTS<br/>OBT.</th><th>MAX<br/>TRIM.</th><th>PTS<br/>OBT.</th>
        <th>5<sup>e</sup>P</th><th>6<sup>e</sup>P</th>
        <th>MAX<br/>EX.</th><th>PTS<br/>OBT.</th><th>MAX<br/>TRIM.</th><th>PTS<br/>OBT.</th>
        <th>MAX</th><th>PTS<br/>OBT.</th>
      </tr>
    </thead>`;
}

/** Bandeau de domaine, pleine largeur. */
function ligneDomaine(nom) {
  return `<tr class="domaine"><td colspan="${NB_COLONNES}">${echapper(nom)}</td></tr>`;
}

/** Ligne de titre d'un groupe (LANGUES CONGOLAISES, FRANÇAIS). */
function ligneGroupe(nom) {
  return `<tr class="groupe">
    <td class="branche">${echapper(nom)}</td>
    ${COLONNES.map(() => '<td></td>').join('')}
  </tr>`;
}

/**
 * Ligne de branche. Les maxima sont imprimés SUR la ligne, dans leurs colonnes
 * propres : c'est la particularité du modèle primaire.
 */
function ligneBranche(cours, cotes) {
  const c = cotes[cours.id] || {};
  const b = baremePrimaire(cours.maximum);
  const valeurs = {
    maxPeriode: b.periode, maxExamen: b.examen,
    maxTrimestre: b.trimestre, maxTotal: b.total,
    p1: c.p1, p2: c.p2, p3: c.p3, p4: c.p4, p5: c.p5, p6: c.p6,
    ex1: c.ex1, ex2: c.ex2, ex3: c.ex3,
    t1: c.t1, t2: c.t2, t3: c.t3, total: c.total,
  };
  return `<tr>
    <td class="branche">${echapper(cours.nom)}</td>
    ${COLONNES.map((col) => `<td>${cote(valeurs[col.cle])}</td>`).join('')}
  </tr>`;
}

/** Somme d'un ensemble de branches, maxima compris. */
function cumuler(liste, cotes) {
  const somme = {};
  const ajouter = (cle, v) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return;
    somme[cle] = (somme[cle] || 0) + n;
  };
  for (const cours of liste) {
    const c = cotes[cours.id] || {};
    const b = baremePrimaire(cours.maximum);
    ajouter('maxPeriode', b.periode); ajouter('maxExamen', b.examen);
    ajouter('maxTrimestre', b.trimestre); ajouter('maxTotal', b.total);
    for (const k of ['p1','p2','p3','p4','p5','p6','ex1','ex2','ex3','t1','t2','t3','total']) {
      ajouter(k, c[k]);
    }
  }
  return somme;
}

function ligneSousTotal(valeurs, libelle = 'Sous-total') {
  return `<tr class="sous-total">
    <td class="branche">${echapper(libelle)}</td>
    ${COLONNES.map((col) => `<td>${cote(valeurs[col.cle])}</td>`).join('')}
  </tr>`;
}

/**
 * Ligne de synthèse : les colonnes de MAXIMUM sont noircies, les colonnes de
 * points obtenus restent ouvertes. C'est le peigne noir du modèle.
 */
function ligneSynthese(libelle, valeurs = {}) {
  return `<tr class="synthese">
    <td class="branche">${echapper(libelle)}</td>
    ${COLONNES.map((col) =>
      col.max ? '<td class="noir"></td>' : `<td>${cote(valeurs[col.cle])}</td>`
    ).join('')}
  </tr>`;
}

/** Aplatit la liste des branches d'un domaine, groupes compris. */
function branchesDe(domaine) {
  if (domaine.groupes && domaine.groupes.length) {
    return domaine.groupes.reduce((t, g) => t.concat(g.cours || []), []);
  }
  return domaine.cours || [];
}

function corpsTableau(domaines, cotes) {
  return domaines.map((d) => {
    let html = ligneDomaine(d.nom);
    if (d.groupes && d.groupes.length) {
      // Domaine à groupes nommés : un sous-total par groupe.
      for (const g of d.groupes) {
        html += ligneGroupe(g.nom);
        html += (g.cours || []).map((c) => ligneBranche(c, cotes)).join('');
        html += ligneSousTotal(cumuler(g.cours || [], cotes));
      }
    } else {
      html += (d.cours || []).map((c) => ligneBranche(c, cotes)).join('');
      html += ligneSousTotal(cumuler(d.cours || [], cotes));
    }
    return html;
  }).join('');
}

function lignesSynthese(eleve, domaines) {
  const toutes = domaines.reduce((t, d) => t.concat(branchesDe(d)), []);
  const generaux = cumuler(toutes, eleve.cotes || {});

  // « Maxima généraux » est la seule ligne de bas de tableau qui garde ses
  // colonnes de maximum ouvertes : c'est précisément ce qu'elle totalise.
  const ligneMaximaGeneraux = `<tr class="synthese">
    <td class="branche">Maxima généraux</td>
    ${COLONNES.map((col) => `<td>${cote(generaux[col.cle])}</td>`).join('')}
  </tr>`;

  return [
    ligneMaximaGeneraux,
    ligneSynthese('POURCENTAGE', eleve.pourcentages),
    ligneSynthese('PLACE', eleve.places),
    ligneSynthese("NBRE D'ÉLÈVES", eleve.effectifs),
    ligneSynthese('APPLICATION', eleve.applications),
    ligneSynthese('CONDUITE', eleve.conduites),
    ligneSynthese("SIGNAT. DE L'INST."),
    ligneSynthese('SIGNAT. DU RESP.'),
  ].join('');
}

/**
 * Pied du bulletin primaire.
 *
 * Deux options seulement — passer ou doubler. Il n'y a ni examen de repêchage
 * ni réorientation au degré élémentaire, et pas de signature de l'élève : à cet
 * âge c'est le responsable qui signe, et il le fait déjà dans le tableau.
 */
function pied({ ecole, signatureUrl, cachetUrl, mentionDuplicata }) {
  const lieu = ecole && ecole.ville ? `Fait à ${echapper(ecole.ville)}, le` : 'Fait le';
  return `
  <div class="pied">
    ${mentionDuplicata ? `<div class="duplicata">${echapper(mentionDuplicata)}</div>` : ''}
    <div class="options">
      - L'élève passe dans la classe supérieure (1)<br/>
      - L'élève double la classe (1)
    </div>
    <div class="bas">
      <div class="case-sign">
        <div>${lieu} <span class="pointilles"></span></div>
      </div>
      <div class="case-sign">
        ${cachetUrl ? `<img src="${cachetUrl}" />` : '<div class="espace-sceau"></div>'}
        SCEAU DE L'ÉCOLE
      </div>
      <div class="case-sign">
        LE CHEF D'ÉTABLISSEMENT
        ${signatureUrl ? `<img src="${signatureUrl}" />` : '<div class="espace-sceau"></div>'}
        <span style="font-size:6.8px;">NOM &amp; SIGNAT.</span>
      </div>
    </div>
    <div class="legal">
      (1) Biffer la mention inutile.<br/>
      NOTE IMPORTANTE : Le bulletin est sans valeur s'il est raturé ou surchargé.
    </div>
    <div class="reference">IGE/P.S./045</div>
  </div>`;
}

/**
 * @param {object} options.ecole      { nom, ville, commune, province }
 * @param {string} options.anneeLibelle
 * @param {object} options.classe     { nom, libelleDegre }
 * @param {Array}  options.eleves
 * @param {Array}  options.domaines   [{ nom, groupes:[{nom, cours:[]}] }] ou
 *                                    [{ nom, cours:[{ id, nom, maximum }] }]
 */
function construireHtmlBulletinPrimaire({
  ecole, anneeLibelle, classe, eleves, domaines,
  signatureUrl, cachetUrl, mentionDuplicata,
}) {
  const listeDomaines = domaines || [];

  const pages = (eleves || []).map((eleve) => {
    const cotes = eleve.cotes || {};
    const degre = classe.libelleDegre || 'DEGRÉ ÉLÉMENTAIRE (1ère, 2e ANNÉE)';

    return `
    <div class="page">
      <div class="entete">
        <div class="drapeau">${DRAPEAU_RDC_SVG}</div>
        <div class="titre">
          <span class="pays">RÉPUBLIQUE DÉMOCRATIQUE DU CONGO</span>
          <span class="ministere">MINISTÈRE DE L'ÉDUCATION NATIONALE<br/>ET NOUVELLE CITOYENNETÉ</span>
        </div>
        <div class="armoiries"></div>
      </div>

      <div class="bandeau-id"><span class="libelle">N° ID.</span> ${cases(26)}</div>

      <div class="identite-large">
        <div class="champ">PROVINCE : ${echapper(ecole.province) || '<span class="pointilles long"></span>'}</div>
      </div>
      <div class="identite-large">
        <div class="champ">VILLE : ${echapper(ecole.ville) || '<span class="pointilles long"></span>'}</div>
      </div>

      <div class="identite">
        <div class="colonne">
          <div class="champ">COMMUNE / TER. (1) : ${echapper(ecole.commune) || '<span class="pointilles long"></span>'}</div>
          <div class="champ">ÉCOLE : ${echapper(ecole.nom)}</div>
          <div class="champ">CODE : ${cases(8)}</div>
        </div>
        <div class="colonne">
          <div class="champ duo">
            <span>ÉLÈVE : ${echapper([eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '))}</span>
            <span>SEXE : ${echapper(eleve.sexe) || '<span class="pointilles"></span>'}</span>
          </div>
          <div class="champ">NÉ(E) À : ${echapper(eleve.lieu_naissance) || '<span class="pointilles"></span>'}
               LE : ${echapper(eleve.date_naissance) || '<span class="pointilles"></span>'}</div>
          <div class="champ">CLASSE : ${echapper(classe.nom)}</div>
          <div class="champ">N° PERM. : ${cases(13)}</div>
        </div>
      </div>

      <div class="ligne-bulletin">
        <span>BULLETIN DE L'ÉLÈVE : ${echapper(degre)} (1)</span>
        <span>ANNÉE SCOLAIRE ${echapper(anneeLibelle)}</span>
      </div>

      <table class="cotes">
        ${enTeteTableau()}
        <tbody>
          ${corpsTableau(listeDomaines, cotes)}
          ${lignesSynthese(eleve, listeDomaines)}
        </tbody>
      </table>

      ${pied({ ecole, signatureUrl, cachetUrl, mentionDuplicata })}
    </div>`;
  }).join('');

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<style>${styles()}</style></head><body>${pages}</body></html>`;
}

module.exports = {
  construireHtmlBulletinPrimaire,
  baremePrimaire,
  COLONNES,
};
