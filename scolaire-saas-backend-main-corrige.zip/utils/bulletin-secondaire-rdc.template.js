const { DRAPEAU_RDC_SVG } = require('./drapeau-rdc.svg');
const { ARMOIRIES_RDC_DATA_URI } = require('./armoiries-rdc.asset');
const { construireBlocExamenEtat, STYLE_EXAMEN_ETAT } = require('./bulletin-examen-etat.template');

/**
 * Bulletin officiel du SECONDAIRE (humanités) — République Démocratique du Congo.
 *
 * Reconstitué d'après les modèles officiels fournis par l'école. Deux variantes :
 *   - 'ordinaire' : colonne de droite « EXAMEN DE REPÊCHAGE » (1ʳᵉ à 3ᵉ année)
 *   - 'terminale' : colonne de droite « EXAMEN D'ÉTAT » (4ᵉ année)
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * POURQUOI CE GABARIT EST ENTIÈREMENT PILOTÉ PAR LES DONNÉES
 *
 * Le modèle importé par une école ne sert que de maquette de référence : rien
 * n'y est repris comme image de fond. Sans quoi les libellés de cours imprimés
 * sur la maquette resteraient visibles pour un élève qui ne suit pas ces
 * cours-là, et on écrirait par-dessus. Ici, la liste des branches vient de la
 * base — elle correspond exactement aux cours de la classe.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * REGROUPEMENT DES BRANCHES PAR MAXIMUM
 *
 * Sur le modèle officiel, une ligne « MAXIMA » réapparaît plusieurs fois dans le
 * tableau. Ce n'est pas une décoration : les branches sont regroupées par
 * barème, et chaque groupe est précédé du sien. Relevé sur le modèle de 4ᵉ :
 *
 *     MAXIMA 10  →  Religion, Correspondance commerciale, Fiscalité…
 *     MAXIMA 20  →  Droit, Économie, Mathématiques générales…
 *     MAXIMA 30  →  Anglais
 *     MAXIMA 40  →  Comptabilité analytique, Français, Informatique
 *     MAXIMA 50  →  Comptabilité générale
 *     MAXIMA 100 →  Pratique professionnelle
 *
 * On reproduit donc ce regroupement en triant les cours par `maximum_points`.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * BARÈME
 *
 * Vérifié sur les photos : examen = 2 × maximum de période,
 * total semestre = P1 + P2 + examen, total général = 2 × total semestre.
 *   max 10 → examen 20 → semestre 40  → T.G. 80
 *   max 20 → examen 40 → semestre 80  → T.G. 160
 */

const ECHAPPEMENTS = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function echapper(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, (c) => ECHAPPEMENTS[c]);
}

/** Cellule de note : vide plutôt que « 0 » quand la cote n'a pas été saisie. */
function cote(valeur) {
  return valeur === null || valeur === undefined || valeur === '' ? '' : echapper(valeur);
}

/** Suite de cases à chiffres vides (N° ID, code de l'école, n° permanent). */
function cases(n) {
  return `<span class="cases">${'<span class="case"></span>'.repeat(n)}</span>`;
}

/**
 * Regroupe les cours par maximum de période, dans l'ordre croissant, en
 * conservant l'ordre alphabétique à l'intérieur de chaque groupe.
 */
/**
 * Maximum de l'examen pour un cours donné.
 *
 * Le doublement du maximum de période n'est qu'un DÉFAUT, pas une règle : toutes
 * les écoles ne cotent pas l'examen sur le double de la période. La valeur se
 * configure donc à la création du cours (`cours.maximum_examen`).
 *
 *   maximum_examen non renseigné → 2 × maximum de période (usage le plus courant)
 *   maximum_examen = 0           → branche non examinée (case noircie sur le modèle)
 */
function maximumExamenDe(cours) {
  if (cours.sans_examen === true) return 0;
  const configure = cours.maximum_examen;
  if (configure === null || configure === undefined || configure === '') {
    return Number(cours.maximum || 0) * 2;
  }
  return Number(configure);
}

function grouperParMaximum(cours) {
  // La clé de regroupement est le couple (maximum, examen ou non) et non le seul
  // maximum : sur le modèle officiel, « Pratique professionnelle » a un maximum
  // de 100 mais aucun examen, et sa ligne MAXIMA affiche 100 | 100 | ▉ | 200 | 400.
  // Regrouper ce cours avec d'autres cours à 100 qui, eux, sont examinés
  // produirait une ligne MAXIMA fausse pour l'un des deux.
  const groupes = new Map();
  for (const c of cours) {
    const max = Number(c.maximum || 0);
    const maxExamen = maximumExamenDe(c);
    // La clé est le COUPLE (maximum de période, maximum d'examen). Deux cours
    // cotés tous deux sur 20 en période mais l'un sur 40 et l'autre sur 20 à
    // l'examen n'ont pas le même barème : les réunir sous une seule ligne
    // MAXIMA en afficherait un faux pour l'un des deux.
    const cle = `${max}|${maxExamen}`;
    if (!groupes.has(cle)) groupes.set(cle, { maximum: max, maximumExamen: maxExamen, cours: [] });
    groupes.get(cle).cours.push(c);
  }
  return [...groupes.values()]
    .sort((a, b) => a.maximum - b.maximum || a.maximumExamen - b.maximumExamen)
    .map((g) => ({
      ...g,
      cours: g.cours.slice().sort((a, b) => String(a.nom).localeCompare(String(b.nom), 'fr'))
    }));
}

/**
 * Barème complet déduit du maximum de période.
 *
 * Vérifié sur les photos :
 *   examiné      max 20 -> examen 40 | semestre 80  | T.G. 160
 *   non examiné  max 100 -> pas d'examen | semestre 200 | T.G. 400
 *
 * Un cours non examiné n'a que ses deux périodes dans le semestre. C'est ce qui
 * explique qu'une branche à 100 points totalise 400 et non 800.
 */
function bareme(max, maximumExamen) {
  const examen = (maximumExamen === null || maximumExamen === undefined) ? max * 2 : Number(maximumExamen);
  const sansExamen = !examen;
  const semestre = max + max + (sansExamen ? 0 : examen);
  return { periode: max, examen: sansExamen ? null : examen, sansExamen, semestre, general: semestre * 2 };
}

/**
 * Métriques FIXES du tableau des cotes.
 *
 * Volontairement constantes, et non calculées d'après le nombre de branches.
 * Sur le modèle officiel, toutes les lignes ont la même hauteur quel que soit
 * leur nombre : un cours qui s'ajoute ajoute une ligne identique aux autres,
 * sous la ligne MAXIMA de son barème. Le bulletin s'arrête alors plus bas ou
 * plus haut sur la feuille, et le bas de page reste blanc — c'est exactement ce
 * que montrent les bulletins photographiés.
 *
 * Faire varier la hauteur avec le nombre de cours donnait deux bulletins
 * d'aspect différent pour deux classes de la même école, ce qu'aucun modèle
 * officiel ne fait.
 */
const METRIQUES = {
  hauteur: '3.4mm',   // valeur mesuree au rendu, pas une intention
  police: '8.8px',      // inchangée : c'est la hauteur qui se resserre, pas le texte
  policeTete: '7.6px',
  pad: '0.3mm',
  // SIGN. DU RESPONSABLE était figée à 7 mm, soit une fois et demie les autres
  // lignes. Sur le modèle officiel elle a la même hauteur que le reste.
  signature: '3.4mm',
};

function styles(m = METRIQUES) {
  return `
  @page { size: A4 portrait; margin: 6mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Times New Roman', Times, serif; font-size: 8px; color: #000; margin: 0; }
  /* Pas de min-height ni d'etirement : le bulletin s'arrete ou s'arrete son
     contenu. Sur le modele officiel le pied suit immediatement la ligne
     SIGN. DU RESPONSABLE, et le bas de page reste blanc. */
  .page { page-break-after: always; }
  .page:last-child { page-break-after: auto; }

  /* ---------- En-tête officiel ---------- */
  .entete { display: flex; align-items: center; border: 1.3px solid #000; }
  .entete .drapeau { width: 24mm; height: 17mm; flex: none; padding: 1mm; }
  .entete .armoiries {
    width: 17mm; height: 17mm; flex: none; margin: 1mm;
    background-image: url('${ARMOIRIES_RDC_DATA_URI}');
    background-size: contain; background-repeat: no-repeat; background-position: center;
  }
  .entete .titre { flex: 1; text-align: center; font-weight: bold; line-height: 1.4; padding: 0 2mm; }
  .entete .titre .pays { display: block; font-size: 12px; }
  .entete .titre .ministere { display: block; font-size: 8.5px; font-weight: normal; margin-top: 0.6mm; }

  .cases { display: inline-flex; gap: 0; vertical-align: middle; }
  .case { border: 1px solid #000; width: 3.4mm; height: 3.8mm; display: inline-block; }

  .bandeau-id { border: 1.3px solid #000; border-top: none; padding: 0.8mm 2mm; display: flex; align-items: center; gap: 2mm; }
  .bandeau-id .libelle { font-weight: bold; }

  /* PROVINCE et VILLE courent sur TOUTE la largeur : le filet vertical qui
     sépare les deux colonnes ne commence qu'à la ligne COMMUNE / TER.
     (relevé sur la photo cadrée de l'en-tête de terminale). */
  .identite-large { border: 1.3px solid #000; border-top: none; padding: 0.9mm 2mm; }
  .identite-large .champ { white-space: nowrap; overflow: hidden; }

  .identite { display: flex; border: 1.3px solid #000; border-top: none; }
  /* Le filet tombe à ~51 % de la largeur, pratiquement au milieu. */
  .identite .colonne { width: 51%; flex: none; padding: 1mm 2mm; }
  .identite .colonne + .colonne { width: 49%; border-left: 1.3px solid #000; }
  .identite .champ { margin-bottom: 0.9mm; white-space: nowrap; overflow: hidden; }
  /* ÉLÈVE et SEXE partagent une seule ligne, SEXE rejeté à droite. */
  .identite .champ.duo { display: flex; justify-content: space-between; gap: 2mm; }
  .pointilles { border-bottom: 0.8px dotted #000; display: inline-block; min-width: 14mm; height: 2.6mm; vertical-align: bottom; }
  .pointilles.long { min-width: 32mm; }

  .ligne-bulletin {
    border: 1.3px solid #000; border-top: none; padding: 1mm 2mm;
    display: flex; justify-content: space-between; font-weight: bold; font-size: 9px;
  }

  /* ---------- Tableau des branches ---------- */
  .corps { margin-top: 0; }
  /* Pas de gouttière : sur le modèle officiel le bloc de droite est accolé à
     la barre noire, il n'y a pas de blanc entre les deux. */
  .colonne-droite { width: 34mm; flex: none; margin-left: 0; }

  table.cotes { border-collapse: collapse; width: 100%; }
  table.cotes th, table.cotes td { border: 1px solid #000; text-align: center; padding: ${m.pad} 0.5mm; font-size: ${m.police}; }
  table.cotes th { font-weight: bold; font-size: ${m.policeTete}; line-height: 1.25; }
  table.cotes td.branche { text-align: left; padding-left: 1.2mm; font-size: ${m.police}; white-space: nowrap; overflow: hidden; max-width: 44mm; }
  table.cotes tr.maxima td { font-weight: bold; background: #f0f0f0; }
  table.cotes tr.synthese td { font-weight: bold; }
  table.cotes tr.synthese td.branche { text-transform: uppercase; }
  /* Aplats noirs du modèle officiel. Ils ne sont pas décoratifs : une case
     noire se lit « aucune cote n'est attendue ici », là où une case blanche
     vide se lit « cote manquante ». Confondre les deux fait croire à un oubli
     de saisie.

     Le mot-clé important est ici volontaire et nécessaire. La règle
     "tr.maxima td" ci-dessus a une spécificité de 0-2-3, supérieure à
     "td.noir" (0-2-2) : sans cela, le gris des lignes MAXIMA repeint par-dessus
     le noir et la barre séparatrice se retrouve trouée à chaque ligne de
     barème. Ces aplats portent du sens, aucune règle de fond ne doit pouvoir
     les effacer. */
  table.cotes td.noir, table.cotes th.noir,
  table.cotes td.separateur, table.cotes th.separateur { background: #000 !important; }

  /* Colonne séparatrice noire, entre le tableau des cotes et la colonne de
     droite. Avec la bande noire des lignes Application / Conduite, elle forme
     le L inversé caractéristique du modèle officiel. */
  table.cotes td.separateur, table.cotes th.separateur { width: 5mm; padding: 0; border-color: #000; }
  table.cotes tbody td { height: ${m.hauteur}; }
  table.cotes td.saisie { height: ${m.hauteur}; }
  table.cotes tr.signature-resp td { height: ${m.signature}; }

  /* ---------- Colonnes de droite, intégrées au tableau ---------- */
  table.cotes td.rep-saisie { height: ${m.hauteur}; }
  table.cotes th.rep-pct { width: 5%; }
  table.cotes td.rep-pied {
    vertical-align: top; text-align: left; padding: 0.8mm 1.2mm;
    font-size: 6.6px; line-height: 1.3;
  }
  table.cotes td.rep-pied .rep-option { display: block; }
  table.cotes td.rep-pied .rep-date { margin-top: 0.8mm; }
  table.cotes td.rep-pied .rep-sign { margin-top: 0.8mm; text-align: center; }
  table.cotes td.rep-pied .rep-sceau { height: 5mm; }

  /* Cellule fusionnée portant le bloc Examen d'État de la terminale. */
  table.cotes th.tete-etat { width: 34mm; }
  table.cotes td.cellule-etat { vertical-align: top; padding: 0; width: 34mm; }

  /* ---------- Pied ---------- */
  .pied { border: 1px solid #000; border-top: none; margin-top: 0; padding: 2mm; font-size: 8px; }
  .pied .mentions { margin-bottom: 1.5mm; line-height: 1.7; }
  .pied .options { line-height: 1.8; }
  .pied .signatures { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 2mm; }
  .pied .signatures .case-sign { text-align: center; min-width: 42mm; }
  .pied .signatures .case-sign img { max-height: 11mm; max-width: 100%; display: block; margin: 0 auto 0.6mm; }
  .pied .espace-sceau { height: 13mm; }
  .pied .legal { margin-top: 1.5mm; font-size: 6.5px; font-style: italic; line-height: 1.5; }
  .pied .interdiction { font-weight: bold; text-align: center; font-style: italic; }
  .pied .reference { text-align: right; font-size: 6.5px; }

  .duplicata {
    text-align: center; font-size: 7.5px; letter-spacing: 0.06em; text-transform: uppercase;
    color: #8a2b2b; border: 1px solid #8a2b2b; border-radius: 1mm;
    padding: 0.6mm 1mm; margin: 1mm auto; max-width: 70mm;
  }
  ${STYLE_EXAMEN_ETAT}
  `;
}

function enTeteTableau(variante) {
  const journal = variante === 'terminale' ? 'TRAVAUX<br/>JOURNAL.' : 'TR. JOURNAL';
  // La colonne de droite fait partie du MÊME tableau que les cotes. Elle était
  // auparavant un bloc posé à côté : ses lignes ne pouvaient alors pas tomber en
  // face des branches, alors que ce sont les notes de ces branches qui s'y
  // écrivent. Un décalage d'une ligne y attribue la note d'un cours à un autre.
  const droite = variante === 'terminale'
    ? `<th rowspan="3" class="tete-etat">EXAMEN D'ÉTAT</th>`
    : `<th colspan="2" rowspan="2">EXAMEN DE REPÊCHAGE</th>`;
  const sousDroite = variante === 'terminale'
    ? ''
    : `<th class="rep-pct">%</th><th>SIGN. PROF.</th>`;

  return `
    <thead>
      <tr>
        <th rowspan="3" class="branche" style="width:22%">BRANCHES</th>
        <th colspan="4">PREMIER SEMESTRE</th>
        <th colspan="4">SECOND SEMESTRE</th>
        <th rowspan="3">T.G.</th>
        <th rowspan="3" class="separateur"></th>
        ${droite}
      </tr>
      <tr>
        <th colspan="2">${journal}</th><th rowspan="2">EXAM.</th><th rowspan="2">TOT.</th>
        <th colspan="2">${journal}</th><th rowspan="2">EXAM.</th><th rowspan="2">TOT.</th>
      </tr>
      <tr>
        <th>1<sup>ère</sup> P.</th><th>2<sup>e</sup> P.</th>
        <th>3<sup>e</sup> P.</th><th>4<sup>e</sup> P.</th>
        ${sousDroite}
      </tr>
    </thead>`;
}

/** Ligne « MAXIMA » précédant chaque groupe de branches de même barème. */
/**
 * Cellules de droite d'une ligne du corps.
 *
 * @param variante   'ordinaire' | 'terminale'
 * @param maxima     true sur une ligne MAXIMA : le repêchage y est noirci, car
 *                   on ne repêche pas un barème mais une branche.
 * @param cellEtat   contenu à insérer une seule fois, sur la 1ʳᵉ ligne du corps
 *                   en variante terminale (bloc Examen d'État en rowspan).
 */
function cellulesDroite(variante, maxima, cellEtat) {
  if (variante === 'terminale') return cellEtat || '';
  return maxima
    ? '<td class="noir"></td><td class="noir"></td>'
    : '<td class="rep-saisie"></td><td class="rep-saisie"></td>';
}

function ligneMaxima(max, maximumExamen, variante, cellEtat) {
  const b = bareme(max, maximumExamen);
  const caseExamen = b.sansExamen ? '<td class="noir"></td>' : `<td>${b.examen}</td>`;
  return `<tr class="maxima">
    <td class="branche">MAXIMA</td>
    <td>${b.periode}</td><td>${b.periode}</td>${caseExamen}<td>${b.semestre}</td>
    <td>${b.periode}</td><td>${b.periode}</td>${caseExamen}<td>${b.semestre}</td>
    <td>${b.general}</td>
    <td class="separateur"></td>
    ${cellulesDroite(variante, true, cellEtat)}
  </tr>`;
}

function ligneBranche(cours, cotes, variante) {
  const c = cotes[cours.id] || {};
  // Un cours peut ne pas être examiné (visites guidées, pratique professionnelle
  // sur le modèle officiel) : la case d'examen est alors noircie, comme sur le
  // document d'origine, et non laissée vide — une case vide se lit comme une
  // cote manquante, une case noire comme « pas d'examen dans cette branche ».
  const sansExamen = maximumExamenDe(cours) === 0;
  const caseExamen = sansExamen ? '<td class="noir"></td>' : `<td>${cote(c.ex)}</td>`;
  return `<tr>
    <td class="branche">${echapper(cours.nom)}</td>
    <td>${cote(c.p1)}</td><td>${cote(c.p2)}</td>${caseExamen}<td>${cote(c.tot1)}</td>
    <td>${cote(c.p3)}</td><td>${cote(c.p4)}</td>${sansExamen ? '<td class="noir"></td>' : `<td>${cote(c.ex2)}</td>`}<td>${cote(c.tot2)}</td>
    <td>${cote(c.tg)}</td>
    <td class="separateur"></td>
    ${cellulesDroite(variante, false)}
  </tr>`;
}

/**
 * Lignes de synthèse du bas de tableau.
 *
 * Trois particularités du modèle officiel sont reproduites ici :
 *
 * 1. APPLICATION et CONDUITE ne sont notées QUE par période. Ce sont des
 *    appréciations (TB, B, E…), pas des points : elles ne s'additionnent pas et
 *    ne se compose pas d'examen. Les cases Examen, Total et T.G. sont donc
 *    noircies — c'est la barre horizontale du L inversé.
 *
 * 2. SIGN. DU RESPONSABLE fusionne ses cellules : le parent signe une fois par
 *    semestre, pas une fois par colonne. Trois cellules en tout, libellé compris.
 *
 * 3. La colonne séparatrice noire court sur toute la hauteur du tableau et
 *    rejoint la bande horizontale : ensemble, elles dessinent le L inversé.
 */
function lignesSynthese(eleve, groupes, variante) {
  const colonnes = ['p1', 'p2', 'ex1', 'tot1', 'p3', 'p4', 'ex2', 'tot2', 'tg'];

  // Sous les branches, la colonne de repêchage cesse d'être une grille de notes
  // et porte la décision de passage. Une seule cellule fusionnée sur les sept
  // lignes de synthèse : c'est la disposition du modèle officiel.
  const NB_SYNTHESE = 7;
  let pied = variante === 'terminale' ? '' : `
      <td colspan="2" rowspan="${NB_SYNTHESE}" class="rep-pied">
        <span class="rep-option">- Passe (1)</span>
        <span class="rep-option">- Double (1)</span>
        <span class="rep-option">- A échoué (1)</span>
        <div class="rep-date">Le <span class="pointilles"></span></div>
        <div class="rep-sign">
          Le Chef d'Étab.
          <div class="rep-sceau"></div>
          Sceau de l'école
        </div>
      </td>`;
  const consommerPied = () => { const p = pied; pied = ''; return p; };

  const cumul = groupes.reduce((acc, g) => {
    const b = bareme(g.maximum, g.maximumExamen);
    const n = g.cours.length;
    acc.p1 += b.periode * n; acc.p2 += b.periode * n; acc.ex1 += (b.examen || 0) * n;
    acc.tot1 += b.semestre * n; acc.p3 += b.periode * n; acc.p4 += b.periode * n;
    acc.ex2 += (b.examen || 0) * n; acc.tot2 += b.semestre * n; acc.tg += b.general * n;
    return acc;
  }, { p1: 0, p2: 0, ex1: 0, tot1: 0, p3: 0, p4: 0, ex2: 0, tot2: 0, tg: 0 });

  const depuis = (cle) => colonnes.reduce((o, c) => {
    o[c] = eleve[cle] ? eleve[cle][c] : null; return o;
  }, {});

  const ligne = (libelle, valeurs, classe = 'synthese') =>
    `<tr class="${classe}"><td class="branche">${libelle}</td>${
      colonnes.map((c) => `<td>${valeurs[c] === undefined || valeurs[c] === null ? '' : echapper(valeurs[c])}</td>`).join('')
    }<td class="separateur"></td>${consommerPied()}</tr>`;

  /** Application et conduite : seules les colonnes de période sont ouvertes. */
  const ligneAppreciation = (libelle, valeurs) =>
    `<tr class="synthese">
      <td class="branche">${libelle}</td>
      <td>${valeurs.p1 == null ? '' : echapper(valeurs.p1)}</td>
      <td>${valeurs.p2 == null ? '' : echapper(valeurs.p2)}</td>
      <td class="noir"></td><td class="noir"></td>
      <td>${valeurs.p3 == null ? '' : echapper(valeurs.p3)}</td>
      <td>${valeurs.p4 == null ? '' : echapper(valeurs.p4)}</td>
      <td class="noir"></td><td class="noir"></td>
      <td class="noir"></td>
      <td class="separateur"></td>
      ${consommerPied()}
    </tr>`;

  // Une seule case par semestre : 1ʳᵉ + 2ᵉ période d'un côté, 3ᵉ + 4ᵉ de l'autre,
  // T.G. compris dans la seconde. Trois cellules avec le libellé.
  const ligneSignature = () => `
    <tr class="synthese signature-resp">
      <td class="branche">SIGN. DU RESPONSABLE</td>
      <td colspan="4"></td>
      <td colspan="5"></td>
      <td class="separateur"></td>
      ${consommerPied()}
    </tr>`;

  return [
    ligne('MAXIMA GÉNÉRAUX', cumul, 'maxima'),
    ligne('TOTAUX', depuis('totaux')),
    ligne('POURCENTAGE', depuis('pourcentages')),
    ligne("PLACE / NBRE D'ÉLÈVES", depuis('places')),
    ligneAppreciation('APPLICATION', depuis('applications')),
    ligneAppreciation('CONDUITE', depuis('conduites')),
    ligneSignature()
  ].join('');
}

function pied({ variante, ecole, dateEdition, signatureUrl, cachetUrl, mentionDuplicata }) {
  const lieu = ecole && ecole.ville ? `Fait à ${echapper(ecole.ville)}, le` : 'Fait le';
  const interdiction = variante === 'terminale'
    ? `<div class="interdiction">Interdiction formelle de reproduire ce bulletin sous peine des sanctions prévues par la loi</div>`
    : '';
  const reference = variante === 'terminale' ? `<div class="reference">IGE/P.S./045</div>` : '';

  // Le pied de la TERMINALE ne porte NI la mention de repêchage NI les options
  // passe / double / réorienter : la décision de fin de cycle est portée par le
  // « RÉSULTAT FINAL » du bloc Examen d'État, pas par l'école. Les mettre ici
  // ferait signer à l'établissement une décision qui ne lui appartient pas.
  // Vérifié sur la photo pleine page du bulletin de 4ᵉ : le pied y enchaîne
  // directement signature de l'élève / sceau / chef d'établissement.
  const decision = variante === 'terminale' ? '' : `
    <div class="mentions">
      L'élève ne pourra passer dans la classe supérieure s'il n'a subi avec succès
      un examen de repêchage en <span class="pointilles long"></span>
      <span class="pointilles long"></span>
    </div>
    <div class="options">
      - L'élève passe dans la classe supérieure (1)<br/>
      - L'élève double sa classe (1)<br/>
      - L'élève a échoué et est à réorienter vers <span class="pointilles long"></span> (1)
    </div>`;

  return `
  <div class="pied">
    ${mentionDuplicata ? `<div class="duplicata">${echapper(mentionDuplicata)}</div>` : ''}
    ${decision}
    <div class="signatures">
      <div class="case-sign">
        <div class="espace-sceau"></div>
        Signature de l'élève
      </div>
      <div class="case-sign">
        ${cachetUrl ? `<img src="${cachetUrl}" />` : '<div class="espace-sceau"></div>'}
        Sceau de l'école
      </div>
      <div class="case-sign">
        <div>${lieu} <span class="pointilles"></span></div>
        ${signatureUrl ? `<img src="${signatureUrl}" />` : '<div class="espace-sceau"></div>'}
        Le Chef d'Établissement<br/><span style="font-size:6.5px;">Nom et Signature</span>
      </div>
    </div>
    <div class="legal">
      (1) Biffer la mention inutile.<br/>
      Note importante : le bulletin est sans valeur s'il est raturé ou surchargé.
    </div>
    ${interdiction}
    ${reference}
  </div>`;
}

/**
 * @param {object}   options.ecole      { nom, ville, commune, province, code, ... }
 * @param {string}   options.anneeLibelle
 * @param {object}   options.classe     { nom, section_nom, option_nom }
 * @param {Array}    options.eleves     élèves avec leurs cotes préparées
 * @param {Array}    options.cours      [{ id, nom, maximum, sans_examen }]
 * @param {string}   options.variante   'ordinaire' | 'terminale'
 */
function construireHtmlBulletinSecondaire({
  ecole, anneeLibelle, classe, eleves, cours,
  variante = 'ordinaire', signatureUrl, cachetUrl, mentionDuplicata
}) {
  const groupes = grouperParMaximum(cours || []);
  const maintenant = new Date();
  const dateEdition = maintenant.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

  const pages = (eleves || []).map((eleve) => {
    const cotes = eleve.cotes || {};
    const nbLignesCorps = groupes.reduce((n, g) => n + g.cours.length + 1, 0) + 7;

    // En terminale, le bloc Examen d'État est une CELLULE du tableau, fusionnée
    // sur toute la hauteur du corps. C'est ce qui rend sa bande noire continue
    // avec la barre séparatrice et avec les aplats des lignes MAXIMA : trois
    // éléments qui, sur le modèle officiel, ne font qu'un seul tenant.
    let cellEtat = variante === 'terminale'
      ? `<td rowspan="${nbLignesCorps}" class="cellule-etat">${construireBlocExamenEtat()}</td>`
      : '';

    const corpsTableau = groupes.map((g) => {
      const m = ligneMaxima(g.maximum, g.maximumExamen, variante, cellEtat);
      cellEtat = '';
      return m + g.cours.map((c) => ligneBranche(c, cotes, variante)).join('');
    }).join('');

    return `
    <div class="page">
      <div class="entete">
        <div class="drapeau">${DRAPEAU_RDC_SVG}</div>
        <div class="titre">
          <span class="pays">RÉPUBLIQUE DÉMOCRATIQUE DU CONGO</span>
          <span class="ministere">MINISTÈRE DE L'ÉDUCATION NATIONALE<br/>ET NOUVELLE CITOYENNETÉ</span>
        </div>
        <div class="armoiries"></div>
      </div>

      <div class="bandeau-id"><span class="libelle">N° ID.</span> ${cases(26)}</div>

      <!-- PROVINCE et VILLE occupent chacune une bande pleine largeur. Le
           découpage en deux colonnes ne commence qu'ensuite : c'est ce que
           montre la photo cadrée de l'en-tête, où le filet vertical part de la
           ligne COMMUNE / TER. et non du haut du bloc. -->
      <div class="identite-large">
        <div class="champ">PROVINCE : ${echapper(ecole.province) || '<span class="pointilles long"></span>'}</div>
      </div>
      <div class="identite-large">
        <div class="champ">VILLE : ${echapper(ecole.ville) || '<span class="pointilles long"></span>'}</div>
      </div>

      <div class="identite">
        <div class="colonne">
          <div class="champ">COMMUNE / TER. (1) : ${echapper(ecole.commune) || '<span class="pointilles long"></span>'}</div>
          <div class="champ">ÉCOLE : ${echapper(ecole.nom)}</div>
          <div class="champ">CODE : ${cases(8)}</div>
        </div>
        <div class="colonne">
          <div class="champ duo">
            <span>ÉLÈVE : ${echapper([eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' '))}</span>
            <span>SEXE : ${echapper(eleve.sexe) || '<span class="pointilles"></span>'}</span>
          </div>
          <div class="champ">NÉ(E) À : ${echapper(eleve.lieu_naissance) || '<span class="pointilles"></span>'}
               LE : ${echapper(eleve.date_naissance) || '<span class="pointilles"></span>'}</div>
          <div class="champ">CLASSE : ${echapper(classe.nom)}</div>
          <div class="champ">N° PERM. : ${cases(13)}</div>
        </div>
      </div>

      <div class="ligne-bulletin">
        <!-- Le blanc après « BULLETIN DE LA » porte la CLASSE, telle qu'elle
             est nommée par l'école (« 4ème ANNEE HUMANITE COMMERCIALE & GESTION »).
             Section et option ne sont pas recollées ici : le nom de la classe les
             contient déjà dans l'usage congolais, les répéter donnerait
             « 4ème HCG — Commerciale Gestion ». -->
        <span>BULLETIN DE LA ${echapper(classe.nom)}</span>
        <span>ANNÉE SCOLAIRE ${echapper(anneeLibelle)}</span>
      </div>

      <div class="corps">
        <table class="cotes">
          ${enTeteTableau(variante)}
          <tbody>
            ${corpsTableau}
            ${lignesSynthese(eleve, groupes, variante)}
          </tbody>
        </table>
      </div>

      ${pied({ variante, ecole, dateEdition, signatureUrl, cachetUrl, mentionDuplicata })}
    </div>`;
  }).join('');

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<style>${styles()}</style></head><body>${pages}</body></html>`;
}

module.exports = {
  construireHtmlBulletinSecondaire,
  grouperParMaximum,
  bareme,
};
