/**
 * Bulletin de SEMESTRE.
 * ===========================================================================
 * MISE EN PAGE — la même que le bulletin de période.
 *
 * Ce document n'est pas une pièce d'un genre différent : c'est le bulletin de
 * période, récapitulé sur tout le semestre. Il en reprend donc exactement la
 * mise en page — A4 paysage, plusieurs élèves côte à côte sur la même feuille —
 * et non une page entière par élève comme auparavant. Une classe de quarante
 * élèves occupait quarante feuilles ; elle en occupe maintenant quatorze, et
 * surtout le titulaire retrouve la présentation qu'il connaît.
 *
 * TROIS COLONNES PAR PAGE, et non quatre comme au bulletin de période. Ce
 * n'est pas une préférence : la grille du semestre porte sept colonnes
 * chiffrées (deux périodes, leur maximum, l'examen, son maximum, le total et
 * le sien) là où celle d'une période n'en porte que deux. À quatre élèves par
 * feuille, chaque colonne de cotes tombe sous les 6 mm et les nombres à trois
 * chiffres se coupent.
 *
 * ---------------------------------------------------------------------------
 * CONTENU — ce que le semestre ajoute à la période.
 *
 *   Cours | 1ère P. | 2ème P. | Max | Examen | Max | Total | Max
 *
 *  - Le « Max » qui suit les deux colonnes de période est le maximum d'UN cours
 *    POUR UNE période, jamais le cumul des deux. Il sert de repère de lecture
 *    aux deux colonnes à sa gauche, qui partagent le même barème.
 *  - Le « Max » qui suit l'examen est le maximum de l'EXAMEN, qui n'est pas
 *    toujours le double de la période : il se configure par cours.
 *  - Le « Total » est celui du SEMESTRE (P1 + P2 + examen), jamais de l'année.
 *  - Un cours sans examen a ses deux cases d'examen noircies : une case noire
 *    se lit « aucune cote n'est attendue », là où une case blanche vide se lit
 *    « cote manquante ».
 *
 * LA SYNTHÈSE EST COLONNE PAR COLONNE. Totaux, pourcentage et place existent
 * pour la 1ʳᵉ période, la 2ᵉ, l'examen ET le total. C'est tout l'intérêt d'un
 * récapitulatif : voir qu'un élève 4ᵉ en première période est 1ᵉʳ à l'examen.
 * Une place unique portée par le seul total faisait disparaître cette lecture.
 *
 * ---------------------------------------------------------------------------
 * SIGNATURES — deux images distinctes, jamais interchangeables.
 *
 * Le titulaire atteste des cotes qu'il a saisies ; le chef d'établissement
 * engage l'école. Ce gabarit reçoit donc `signatureTitulaireUrl` et
 * `signatureChefUrl` séparément (voir utils/signatures.utils.js) et n'écrit
 * « Signature du titulaire » sous une image que s'il imprime réellement celle
 * du titulaire. Auparavant il affichait sous ce libellé la signature la plus
 * récente de l'école — le plus souvent celle du directeur.
 */

const ECHAPPEMENTS = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function echapper(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, (c) => ECHAPPEMENTS[c]);
}

/**
 * Affiche une cote sans ses zéros décimaux inutiles : la base renvoie les
 * colonnes `numeric` avec une échelle fixe (« 18.00 »), ce qui donnerait
 * « 18.00 » pour la quasi-totalité des notes, qui sont entières.
 */
function cote(valeur) {
  if (valeur === null || valeur === undefined || valeur === '') return '';
  const n = Number(valeur);
  return Number.isFinite(n) ? String(n) : echapper(valeur);
}

function pourcent(valeur) {
  if (valeur === null || valeur === undefined || valeur === '') return '';
  return `${valeur}%`;
}

const COLONNES_PAR_PAGE = 3;

function construireHtmlBulletinSemestre({
  ecole, classe, semestreLibelle, anneeLibelle, cours, eleves, maxima,
  // `colonnes` et `groupes` viennent de assemblerDonneesRegroupement : ce sont
  // eux qui décident de la grille, et non ce gabarit. Un semestre du
  // secondaire, un trimestre du primaire et un semestre du primaire qui
  // englobe ses trimestres passent tous les trois par ici sans distinction.
  colonnes, groupes, domaines,
  // Seuil de réussite de l'école, en pourcentage du maximum. Une cote qui
  // tombe dessous est grisée. 50 par défaut, comme partout ailleurs dans
  // l'application (promotion, rapports, statistiques de classe).
  seuilReussite,
  signatureTitulaireUrl, titulaireNom,
  signatureChefUrl, chefNom, chefEstDirecteur,
  cachetUrl, mentionDuplicata,
  // Rétrocompatibilité : les appels antérieurs ne passaient qu'une signature.
  signatureUrl
}) {
  const listeColonnes = colonnes || [];
  const listeGroupes = (groupes && groupes.length)
    ? groupes
    // Sécurité : sans groupes fournis, chaque colonne porte son propre « Max ».
    // Le tableau reste juste, il est seulement plus large.
    : listeColonnes.map((c) => ({ colonnes: [c], cleMax: c.cle }));

  // Nombre total de cellules d'une ligne : le nom du cours, chaque colonne,
  // le « Max » de chaque groupe, puis Total et son Max.
  const nbColonnes = 1 + listeColonnes.length + listeGroupes.length + 2;
  // Le nom du cours occupe d'autant moins de place que la grille a de colonnes.
  const largeurNom = Math.max(18, 34 - 2 * listeColonnes.length);

  const seuil = Number(seuilReussite ?? 50);

  /**
   * Une cote est-elle en échec ?
   *
   * Comparaison en POURCENTAGE du maximum, et non en points bruts : une cote de
   * 8 est excellente sur 10 et catastrophique sur 100. Sans maximum connu, ou
   * sans cote saisie, on ne décide rien — une case vide n'est pas un échec,
   * c'est une absence de note.
   */
  function estEnEchec(valeur, maximum) {
    if (valeur === null || valeur === undefined || valeur === '') return false;
    const max = Number(maximum);
    if (!Number.isFinite(max) || max <= 0) return false;
    const n = Number(valeur);
    if (!Number.isFinite(n)) return false;
    return (n / max) * 100 < seuil;
  }

  const maintenant = new Date();
  const dateEdition = maintenant.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  const lieuEdition = (ecole && ecole.ville) ? `Fait à ${echapper(ecole.ville)}, le` : 'Fait le';

  // Si l'appelant n'a fourni qu'une seule signature (ancien contrat), elle est
  // traitée comme celle de l'école, pas comme celle du titulaire : attribuer
  // au titulaire une signature dont on ignore l'auteur est exactement l'erreur
  // que ce gabarit corrige.
  const imageTitulaire = signatureTitulaireUrl || null;
  const imageChef = signatureChefUrl || signatureUrl || null;
  const libelleChef = (!signatureChefUrl && signatureUrl) || chefEstDirecteur === false
    ? 'Signature autorisée'
    : "Le Chef d'Établissement";

  const pages = [];
  for (let i = 0; i < (eleves || []).length; i += COLONNES_PAR_PAGE) {
    pages.push(eleves.slice(i, i + COLONNES_PAR_PAGE));
  }

  const styles = `
    @page { size: A4 landscape; margin: 8mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000; margin: 0; }

    .page {
      display: grid;
      grid-template-columns: repeat(${COLONNES_PAR_PAGE}, 1fr);
      gap: 0;
      width: 100%;
      height: 190mm;
      page-break-after: always;
    }
    .page:last-child { page-break-after: auto; }

    .colonne {
      border-right: 1px dashed #999;
      padding: 3mm 2.5mm;
      display: flex;
      flex-direction: column;
    }
    .colonne:last-child { border-right: none; }
    /* Colonne de remplissage d'une page incomplète : elle tient la grille pour
       que le dernier bulletin garde la largeur des précédents. */
    .colonne.vide { border-right: none; }

    .entete { text-align: center; margin-bottom: 2mm; }
    .entete img { max-height: 12mm; margin-bottom: 1mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 9.5px; }
    .entete .annee { font-size: 7.5px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; margin: 1.5mm 0; font-size: 9px; }

    .identite { margin-bottom: 1.5mm; font-size: 8px; }
    .identite div { margin-bottom: 0.4mm; }

    table.notes { width: 100%; border-collapse: collapse; font-size: 7.2px; margin-bottom: 1.5mm; table-layout: fixed; }
    /* SANS QUADRILLAGE. Seule la ligne d'en-tête garde un trait, celui qui la
       sépare des cotes. Un quadrillage complet, à cette taille de police,
       ajoute plus de traits que de chiffres et rend la colonne difficile à
       suivre de l'œil ; les alignements et les aplats de fond suffisent à
       structurer la grille. */
    table.notes th, table.notes td { border: none; padding: 0.6mm 0.2mm; text-align: center; }
    table.notes thead th { background: #eee; font-size: 6.6px; line-height: 1.15; font-weight: bold; }
    table.notes thead tr:last-child th { border-bottom: 0.5px solid #333; }
    /* Le nom du cours revient à la ligne plutôt que d'être tronqué : deux
       branches coupées au même endroit deviendraient indiscernables. */
    table.notes td.cours-nom, table.notes th.cours-nom {
      text-align: left; padding-left: 0.8mm; font-size: 7px; word-break: break-word;
    }
    table.notes td.max { color: #555; background: #fafafa; }
    /* Aplat noir : « aucune cote n'est attendue ici ». À ne pas confondre avec
       une case blanche vide, qui se lit « cote manquante ». */
    table.notes td.noir { background: #000; }
    /* Bandeau de domaine : pleine largeur, comme sur le modèle officiel. */
    table.notes tr.domaine td {
      background: #ddd; font-weight: bold; text-align: center;
      font-size: 6.4px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    table.notes tr.groupe td { background: #efefef; font-weight: bold; font-size: 6.6px; }
    table.notes tr.sous-total td { font-weight: bold; background: #f4f4f4; }
    table.notes tr.synthese td { font-weight: bold; background: #f4f4f4; }
    table.notes tr.synthese td.cours-nom { text-transform: uppercase; font-size: 6.4px; }
    /* Cases sans objet sur une ligne de synthèse : un pourcentage n'a pas de
       maximum. Grisées et non noircies — rien n'y manque, rien n'y est attendu. */
    table.notes tr.synthese td.inerte { background: #e6e6e6; }

    /* ÉCHEC — la cote reste lisible, sur fond gris.
       On grise la case AVEC son point dedans plutôt que de la barrer ou de la
       colorer en rouge : le bulletin part en photocopie noir et blanc, où une
       couleur disparaît. Le seuil est celui de l'école (seuil_promotion_
       pourcentage, 50 % par défaut) — le même que la promotion et les rapports,
       pour qu'une branche marquée en échec ici le soit partout ailleurs. */
    table.notes td.echec { background: #cfcfcf; font-weight: bold; }

    .appreciations { font-size: 7.4px; margin-bottom: 1.5mm; flex-grow: 1; }
    .appreciations div { margin-bottom: 0.6mm; }

    .fait-le { font-size: 7.2px; text-align: right; font-style: italic; margin-top: 2mm; }
    .signatures { font-size: 7.2px; margin-top: auto; }
    .signatures .ligne { display: flex; justify-content: space-between; gap: 1.5mm; margin-top: 3mm; }
    .signatures .case { border-top: 0.3px solid #333; flex: 1; text-align: center; padding-top: 0.8mm; }
    .signatures .case img { max-height: 9mm; max-width: 100%; display: block; margin: 0 auto 0.6mm auto; }
    .signatures .case .espace { height: 9mm; }
    .signatures .nom-signataire { font-size: 6.4px; color: #444; }

    .mention-duplicata {
      text-align: center; font-size: 6.8px; letter-spacing: 0.05em;
      text-transform: uppercase; color: #8a2b2b;
      border: 0.4px solid #8a2b2b; border-radius: 1mm;
      padding: 0.5mm 1mm; margin-bottom: 1.5mm;
    }
  `;

  /**
   * En-tête, construit d'après les colonnes réellement présentes.
   *
   * Chaque groupe de colonnes de même barème est suivi de SON « Max », comme
   * sur le modèle : les deux périodes partagent le leur, l'examen a le sien.
   * Rien n'est écrit d'avance, si bien qu'un trimestre du primaire
   * (1ʳᵉ P. | 2ᵉ P. | Exam.) et un semestre du primaire (T1 | T2) sortent
   * l'un comme l'autre sans code particulier.
   */
  function enTete() {
    const cellules = listeGroupes.map((g) => {
      const titres = g.colonnes.map((c) => `<th>${c.libelle}</th>`).join('');
      return `${titres}<th>Max</th>`;
    }).join('');
    return `
    <thead>
      <tr>
        <th class="cours-nom" style="width:${largeurNom}%">Cours</th>
        ${cellules}
        <th>Total</th>
        <th>Max</th>
      </tr>
    </thead>`;
  }

  /**
   * Une ligne de cours.
   *
   * Une case noircie signifie « aucune cote n'est attendue ici » — un cours
   * non examiné sous la colonne Examen. À ne pas confondre avec une case
   * blanche vide, qui se lit « cote manquante ». La distinction est portée par
   * le maximum du cours pour cette colonne : `null` = rien n'est attendu.
   */
  function ligneCours(eleve, c) {
    const x = (eleve.cotes && eleve.cotes[c.id]) || {};
    const maxima = c.maxima || {};
    const cellules = listeGroupes.map((g) => {
      const notes = g.colonnes.map((col) => {
        if (maxima[col.cle] === null) return '<td class="noir"></td>';
        const classe = estEnEchec(x[col.cle], maxima[col.cle]) ? ' class="echec"' : '';
        return `<td${classe}>${cote(x[col.cle])}</td>`;
      }).join('');
      const max = maxima[g.cleMax] === null
        ? '<td class="noir"></td>'
        : `<td class="max">${cote(maxima[g.cleMax])}</td>`;
      return notes + max;
    }).join('');

    const classeTotal = estEnEchec(x.total, maxima.total) ? ' class="echec"' : '';
    return `<tr>
      <td class="cours-nom">${echapper(c.nom)}</td>
      ${cellules}
      <td${classeTotal}>${cote(x.total)}</td>
      <td class="max">${cote(maxima.total)}</td>
    </tr>`;
  }

  /* ---------- Bandeaux de domaine et sous-totaux (primaire) ----------
     Le bulletin du primaire range ses branches par domaine et clôt chaque
     groupe par un « Sous-total » — c'est ce que montre le document officiel.
     Le bulletin de trimestre reprend cette structure : c'est la vue rapprochée
     du même tableau, il serait déroutant qu'il présente les mêmes branches
     dans un autre ordre.

     Une classe dont les cours n'ont pas de domaine (le secondaire) reçoit
     `domaines: null` et retrouve exactement la liste plate d'avant. */

  function ligneBandeau(nom) {
    return `<tr class="domaine"><td colspan="${nbColonnes}">${echapper(nom)}</td></tr>`;
  }

  function ligneGroupe(nom) {
    return `<tr class="groupe"><td class="cours-nom">${echapper(nom)}</td>${
      '<td></td>'.repeat(nbColonnes - 1)
    }</tr>`;
  }

  function ligneSousTotal(valeurs, libelle) {
    if (!valeurs) return '';
    const m = valeurs.maxima || {};
    const cellules = listeGroupes.map((g) => {
      const notes = g.colonnes.map((col) => `<td>${cote(valeurs[col.cle])}</td>`).join('');
      return notes + `<td class="max">${cote(m[g.cleMax])}</td>`;
    }).join('');
    return `<tr class="sous-total">
      <td class="cours-nom">${echapper(libelle)}</td>
      ${cellules}
      <td>${cote(valeurs.total)}</td>
      <td class="max">${cote(m.total)}</td>
    </tr>`;
  }

  function corpsTableau(eleve) {
    if (!domaines || domaines.length === 0) {
      return (cours || []).map((c) => ligneCours(eleve, c)).join('');
    }
    const sousTotaux = eleve.sousTotaux || {};
    return domaines.map((d) => {
      let html = ligneBandeau(d.nom);
      if (d.groupes && d.groupes.length) {
        for (const g of d.groupes) {
          if (g.nom) html += ligneGroupe(g.nom);
          html += (g.cours || []).map((c) => ligneCours(eleve, c)).join('');
          html += ligneSousTotal(sousTotaux[`${d.nom}|${g.nom}`], 'Sous-total');
        }
      } else {
        html += (d.cours || []).map((c) => ligneCours(eleve, c)).join('');
        html += ligneSousTotal(sousTotaux[d.nom], 'Sous-total');
      }
      return html;
    }).join('');
  }

  /**
   * Synthèse du regroupement.
   *
   * Chaque ligne court sur TOUTES les colonnes chiffrées, et non sur le seul
   * total : c'est tout l'intérêt d'un récapitulatif que de montrer qu'un élève
   * 4ᵉ en première période est 1ᵉʳ à l'examen. Les cases de maximum sont
   * remplies pour les totaux (le maximum EST une information à cet endroit) et
   * grisées pour le pourcentage et la place, où elles n'ont pas d'objet.
   *
   * Application et conduite ne sont notées QUE sous une colonne qui est une
   * période de travail : ce sont des appréciations, pas des points. Elles ne
   * s'additionnent pas, ne se composent pas d'examen et n'ont pas de sens sous
   * une colonne « T1 » qui résume un trimestre entier — d'où les cases noircies.
   */
  function lignesSynthese(eleve) {
    const m = maxima || {};
    const t = eleve.totaux || {};
    const p = eleve.pourcentages || {};
    const pl = eleve.places || {};
    const app = eleve.applications || {};
    const cond = eleve.conduites || {};

    /** Parcourt les groupes en insérant leur case « Max » au bon endroit. */
    function parGroupe(valeurDe, caseMax) {
      return listeGroupes.map((g) => {
        const cellules = g.colonnes.map(valeurDe).join('');
        return cellules + caseMax(g);
      }).join('');
    }

    const ligneTotaux = `
      <tr class="synthese">
        <td class="cours-nom">Totaux</td>
        ${parGroupe(
          (col) => `<td>${cote(t[col.cle])}</td>`,
          (g) => `<td class="max">${cote(m[g.cleMax])}</td>`
        )}
        <td>${cote(t.total)}</td>
        <td class="max">${cote(m.total)}</td>
      </tr>`;

    const lignePourcentage = `
      <tr class="synthese">
        <td class="cours-nom">Pourcentage</td>
        ${parGroupe(
          (col) => `<td>${pourcent(p[col.cle])}</td>`,
          () => '<td class="inerte"></td>'
        )}
        <td>${pourcent(p.total)}</td>
        <td class="inerte"></td>
      </tr>`;

    const lignePlace = `
      <tr class="synthese">
        <td class="cours-nom">Place / nbre</td>
        ${parGroupe(
          (col) => `<td>${echapper(pl[col.cle] || '')}</td>`,
          () => '<td class="inerte"></td>'
        )}
        <td>${echapper(pl.total || '')}</td>
        <td class="inerte"></td>
      </tr>`;

    const ligneAppreciation = (libelle, valeurs) => `
      <tr class="synthese">
        <td class="cours-nom">${libelle}</td>
        ${parGroupe(
          (col) => col.type === 'periode'
            ? `<td>${echapper(valeurs[col.cle] || '')}</td>`
            : '<td class="noir"></td>',
          () => '<td class="noir"></td>'
        )}
        <td class="noir"></td>
        <td class="noir"></td>
      </tr>`;

    const ligneMention = `
      <tr class="synthese">
        <td class="cours-nom">Mention</td>
        <td colspan="${nbColonnes - 1}" style="text-align:left; padding-left:1mm;">${echapper(eleve.mention || '')}</td>
      </tr>`;

    return [
      ligneTotaux, lignePourcentage, lignePlace,
      ligneAppreciation('Application', app),
      ligneAppreciation('Conduite', cond),
      ligneMention
    ].join('');
  }

  function colonneEleve(eleve) {
    const nomComplet = [eleve.nom, eleve.postnom, eleve.prenom].filter(Boolean).join(' ');

    return `
      <div class="colonne">
        <div class="entete">
          ${ecole && ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${echapper(ecole.nom)}</div>
          ${anneeLibelle ? `<div class="annee">Année scolaire ${echapper(anneeLibelle)}</div>` : ''}
        </div>

        <div class="titre-bulletin">Bulletin — ${echapper(semestreLibelle)}</div>
        ${mentionDuplicata ? `<div class="mention-duplicata">${echapper(mentionDuplicata)}</div>` : ''}

        <div class="identite">
          <div><strong>Nom :</strong> ${echapper(nomComplet)}</div>
          <div><strong>Matricule :</strong> ${echapper(eleve.matricule)}</div>
          <div><strong>Classe :</strong> ${echapper(classe.nom)}${classe.option_nom ? ' (' + echapper(classe.option_nom) + ')' : ''}</div>
        </div>

        <table class="notes">
          ${enTete()}
          <tbody>
            ${corpsTableau(eleve)}
            ${lignesSynthese(eleve)}
          </tbody>
        </table>

        <div class="appreciations">
          <div><strong>Observation :</strong> ${echapper(eleve.observation || '')}</div>
        </div>

        <div class="signatures">
          <div class="fait-le">${lieuEdition} ${dateEdition}</div>
          <div class="ligne">
            <div class="case">
              ${imageTitulaire ? `<img src="${imageTitulaire}" />` : '<div class="espace"></div>'}
              <div>Signature du titulaire</div>
              ${imageTitulaire && titulaireNom ? `<div class="nom-signataire">${echapper(titulaireNom)}</div>` : ''}
            </div>
            <div class="case">
              ${imageChef ? `<img src="${imageChef}" />` : '<div class="espace"></div>'}
              <div>${libelleChef}</div>
              ${imageChef && chefNom ? `<div class="nom-signataire">${echapper(chefNom)}</div>` : ''}
            </div>
            <div class="case">
              ${cachetUrl ? `<img src="${cachetUrl}" />` : '<div class="espace"></div>'}
              <div>Cachet de l'école</div>
            </div>
          </div>
        </div>
      </div>`;
  }

  const pagesHtml = pages.map((groupe) => {
    const colonnes = groupe.map(colonneEleve).join('');
    // Sans colonnes de remplissage, deux élèves seuls sur la dernière feuille
    // s'étaleraient sur toute sa largeur et n'auraient plus le format des
    // bulletins précédents.
    const remplissage = '<div class="colonne vide"></div>'.repeat(COLONNES_PAR_PAGE - groupe.length);
    return `<div class="page">${colonnes}${remplissage}</div>`;
  }).join('');

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<style>${styles}</style></head><body>${pagesHtml || '<p>Aucun élève.</p>'}</body></html>`;
}

module.exports = { construireHtmlBulletinSemestre };
