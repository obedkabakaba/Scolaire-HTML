/**
 * Construit le HTML complet des bulletins d'une classe pour une période,
 * en respectant la mise en page officielle : A4 paysage, 4 colonnes par page,
 * une nouvelle page dès que 4 élèves ont été placés.
 */
/**
 * Formate une cote brute (Max, Points, Total) sans les zéros décimaux
 * inutiles : la base renvoie les colonnes `numeric` avec une échelle fixe
 * (ex. "40.00", "31.00"), ce qui affichait "40.00" au lieu de "40" pour
 * n'importe quelle note entière — la quasi-totalité d'entre elles.
 *
 * `Number(x).toString()` retire les zéros de fin sans arrondir une vraie
 * valeur décimale : "40.00" -> "40", mais "31.50" reste "31.5". Le pourcentage
 * n'est PAS concerné par cette fonction : lui doit garder ses décimales
 * (77.78 %), c'est une valeur calculée et arrondie à la volée, pas une cote
 * brute stockée avec une échelle fixe.
 */
function formaterCote(valeur) {
  if (valeur === null || valeur === undefined || valeur === '') return '-';
  const nombre = Number(valeur);
  return Number.isFinite(nombre) ? nombre.toString() : String(valeur);
}

function construireHtmlBulletins({
  ecole, anneeLibelle, periodeLibelle, classe, cours, eleves, signatureUrl, cachetUrl,
  mentionDuplicata, effectif, signatureEstTitulaire, signatureEstDirecteur, signatureNom,
  // Seuil de réussite de l'école, en pourcentage du maximum du cours. Une cote
  // en dessous est grisée. 50 par défaut, comme partout ailleurs.
  seuilReussite,
  // Primaire : branches rangées par domaine, avec un sous-total par groupe,
  // comme sur le bulletin officiel du degré élémentaire. Le secondaire n'en a
  // pas et reçoit `null` — il garde alors la liste plate d'origine.
  domaines
}) {
  // Le libellé imprimé doit refléter QUI a réellement signé, pas une supposition :
  // la signature affichée peut être celle du titulaire de la classe, mais à
  // défaut (titulaire n'ayant jamais déposé la sienne), c'est la première
  // signature disponible de l'école qui est utilisée — le plus souvent celle
  // du directeur. Écrire « Signature du titulaire » dans ce cas aurait attribué
  // à tort la signature du directeur à quelqu'un d'autre.
  const libelleSignature = signatureEstTitulaire
    ? 'Signature du titulaire'
    : (signatureEstDirecteur ? "Le Chef d'Établissement" : 'Signature autorisée');
  // Dénominateur du classement. Il vaut le nombre d'élèves imprimés dans le cas
  // courant (toute la classe), mais doit pouvoir être forcé : sur un duplicata
  // individuel, on imprime UN élève alors que son rang se lit sur l'effectif de
  // la classe à l'époque — sans quoi le bulletin afficherait « 3 / 1 ».
  const effectifClasse = effectif || eleves.length;

  // Date d'édition. Elle atteste du moment où la pièce a été délivrée : sans
  // elle, un bulletin réimprimé six mois plus tard ne se distingue pas de
  // l'original, et personne ne peut dire lequel fait foi.
  const maintenant = new Date();
  const dateEdition = maintenant.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  const lieuEdition = (ecole && ecole.ville) ? `Fait à ${ecole.ville}, le` : 'Fait le';
  const colonnesParPage = 4;
  const pages = [];
  for (let i = 0; i < eleves.length; i += colonnesParPage) {
    pages.push(eleves.slice(i, i + colonnesParPage));
  }

  const styles = `
    @page { size: A4 landscape; margin: 8mm; }
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 9px; margin: 0; }
    .page {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 0;
      width: 100%;
      height: 190mm;
      page-break-after: always;
    }
    .page:last-child { page-break-after: auto; }
    .colonne {
      border-right: 1px dashed #999;
      padding: 4mm 3mm;
      display: flex;
      flex-direction: column;
    }
    .colonne:last-child { border-right: none; }
    .entete { text-align: center; margin-bottom: 3mm; }
    .entete img { max-height: 14mm; margin-bottom: 1mm; }
    .entete .nom-ecole { font-weight: bold; font-size: 10px; }
    .entete .annee { font-size: 8px; color: #444; }
    .titre-bulletin { text-align: center; font-weight: bold; text-transform: uppercase; margin: 2mm 0; font-size: 9.5px; }
    .identite { margin-bottom: 2mm; font-size: 8.5px; }
    .identite div { margin-bottom: 0.5mm; }
    table.notes { width: 100%; border-collapse: collapse; font-size: 8px; margin-bottom: 2mm; }
    /* SANS QUADRILLAGE. Seule la ligne d'en-tête garde le trait qui la sépare
       des cotes : à cette taille, un quadrillage complet ajoute plus de traits
       que de chiffres. L'alignement des colonnes et les aplats de fond
       suffisent à tenir la lecture. */
    table.notes th, table.notes td { border: none; padding: 1mm; text-align: center; }
    table.notes thead th { background: #eee; border-bottom: 0.5px solid #333; }
    table.notes td.cours-nom { text-align: left; }
    /* ÉCHEC — cote conservée, sur fond gris. Ni barré ni coloré : le bulletin
       part en photocopie noir et blanc, où une couleur disparaît. Le seuil est
       celui de l'école, le même que la promotion et les rapports. */
    table.notes td.echec { background: #cfcfcf; font-weight: bold; }
    /* Bandeau de domaine : il court sur toute la largeur, comme sur le modèle
       officiel où le nom du domaine sépare visuellement deux blocs de branches. */
    table.notes tr.domaine td {
      background: #ddd; font-weight: bold; text-align: left;
      font-size: 7px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    table.notes tr.groupe td { font-weight: bold; text-align: left; font-size: 7.5px; }
    table.notes tr.sous-total td { font-weight: bold; background: #f4f4f4; }
    .synthese { font-size: 8.5px; margin-bottom: 2mm; }
    .synthese div { display: flex; justify-content: space-between; border-bottom: 0.3px dotted #999; }
    .appreciations { font-size: 8px; margin-bottom: 2mm; flex-grow: 1; }
    .appreciations div { margin-bottom: 1mm; }
    .signatures { font-size: 8px; margin-top: auto; }
    .fait-le { font-size: 8px; text-align: right; margin-top: 4mm; font-style: italic; }
    .signatures .ligne { display: flex; justify-content: space-between; margin-top: 6mm; }
    .signatures .case { border-top: 0.3px solid #333; width: 45%; text-align: center; padding-top: 1mm; }
    .signatures .case img { max-height: 10mm; max-width: 100%; display: block; margin: 0 auto 1mm auto; }
    .signatures .nom-signataire { font-size: 7px; color: #444; margin-top: 0.5mm; }

    /* Mention de réédition. Un duplicata doit être identifiable comme tel :
       sans elle, une réimpression tardive est indiscernable de l'original et
       peut être présentée comme une pièce délivrée à l'époque. */
    .mention-duplicata {
      text-align: center; font-size: 7.5px; letter-spacing: 0.06em;
      text-transform: uppercase; color: #8a2b2b;
      border: 0.4px solid #8a2b2b; border-radius: 1mm;
      padding: 0.6mm 1mm; margin-bottom: 2mm;
    }
  `;

  /** Points obtenus par un élève sur un cours, ou null si rien n'a été saisi. */
  function pointsDe(eleve, c) {
    const note = eleve.notes.find((n) => n.classe_cours_id === c.classe_cours_id);
    return note && note.points_obtenus !== null && note.points_obtenus !== undefined
      ? note.points_obtenus
      : null;
  }

  const seuil = Number(seuilReussite ?? 50);

  /**
   * Une cote est-elle en échec ?
   *
   * Comparaison en POURCENTAGE du maximum, jamais en points bruts : 8 est
   * excellent sur 10 et catastrophique sur 100. Une case vide n'est pas un
   * échec — c'est une absence de note, et la griser accuserait l'élève d'un
   * résultat qu'il n'a pas eu.
   */
  function estEnEchec(valeur, maximum) {
    if (valeur === null || valeur === undefined || valeur === '') return false;
    const max = Number(maximum);
    if (!Number.isFinite(max) || max <= 0) return false;
    const n = Number(valeur);
    if (!Number.isFinite(n)) return false;
    return (n / max) * 100 < seuil;
  }

  function ligneCours(eleve, c) {
    const points = pointsDe(eleve, c);
    const classe = estEnEchec(points, c.maximum) ? ' class="echec"' : '';
    return `<tr>
      <td class="cours-nom">${c.nom}</td>
      <td>${formaterCote(c.maximum)}</td>
      <td${classe}>${formaterCote(points)}</td>
    </tr>`;
  }

  /**
   * Sous-total d'un ensemble de branches.
   *
   * La somme des points reste VIDE tant qu'aucune note n'a été saisie dans le
   * groupe : afficher « 0 » ferait lire « l'élève a eu zéro » là où il faut
   * lire « rien n'a encore été coté ». Le maximum, lui, est toujours connu.
   */
  function ligneSousTotal(eleve, liste) {
    const points = liste.map((c) => pointsDe(eleve, c)).filter((v) => v !== null);
    const maximum = liste.reduce((t, c) => t + Number(c.maximum || 0), 0);
    const somme = points.length === 0 ? null : points.reduce((a, b) => a + Number(b), 0);
    const classe = estEnEchec(somme, maximum) ? ' class="echec"' : '';
    return `<tr class="sous-total">
      <td class="cours-nom">Sous-total</td>
      <td>${formaterCote(maximum)}</td>
      <td${classe}>${somme === null ? '-' : formaterCote(somme)}</td>
    </tr>`;
  }

  function corpsNotes(eleve) {
    if (!domaines || domaines.length === 0) {
      return cours.map((c) => ligneCours(eleve, c)).join('');
    }
    return domaines.map((d) => {
      let html = `<tr class="domaine"><td colspan="3">${d.nom}</td></tr>`;
      if (d.groupes && d.groupes.length) {
        for (const g of d.groupes) {
          if (g.nom) html += `<tr class="groupe"><td class="cours-nom">${g.nom}</td><td></td><td></td></tr>`;
          html += (g.cours || []).map((c) => ligneCours(eleve, c)).join('');
          html += ligneSousTotal(eleve, g.cours || []);
        }
      } else {
        html += (d.cours || []).map((c) => ligneCours(eleve, c)).join('');
        html += ligneSousTotal(eleve, d.cours || []);
      }
      return html;
    }).join('');
  }

  function colonneEleve(eleve) {
    const lignesNotes = corpsNotes(eleve);

    return `
      <div class="colonne">
        <div class="entete">
          ${ecole.logo_url ? `<img src="${ecole.logo_url}" />` : ''}
          <div class="nom-ecole">${ecole.nom}</div>
          <div class="annee">Année scolaire ${anneeLibelle || ''}</div>
        </div>
        <div class="titre-bulletin">Bulletin — ${periodeLibelle || ''}</div>
        ${mentionDuplicata ? `<div class="mention-duplicata">${mentionDuplicata}</div>` : ''}
        <div class="identite">
          <div><strong>Nom :</strong> ${eleve.nom} ${eleve.postnom || ''} ${eleve.prenom || ''}</div>
          <div><strong>Matricule :</strong> ${eleve.matricule}</div>
          <div><strong>Classe :</strong> ${classe.nom} ${classe.section_nom ? '— ' + classe.section_nom : ''} ${classe.option_nom ? '(' + classe.option_nom + ')' : ''}</div>
        </div>
        <table class="notes">
          <thead>
            <tr><th class="cours-nom">Cours</th><th>Max</th><th>Points</th></tr>
          </thead>
          <tbody>${lignesNotes}</tbody>
        </table>
        <div class="synthese">
          <div><span>Total</span><span>${formaterCote(eleve.total)} / ${formaterCote(eleve.total_maximum)}</span></div>
          <div><span>Pourcentage</span><span>${eleve.pourcentage ?? '-'}%</span></div>
          <div><span>Classement</span><span>${eleve.classement ?? '-'} / ${effectifClasse}</span></div>
          <div><span>Mention</span><span>${eleve.mention ?? '-'}</span></div>
        </div>
        <div class="appreciations">
          <div><strong>Conduite :</strong> ${eleve.conduite || ''}</div>
          <div><strong>Application :</strong> ${eleve.application || ''}</div>
          <div><strong>Observation :</strong> ${eleve.observation || ''}</div>
        </div>
        <div class="signatures">
          <div class="fait-le">${lieuEdition} ${dateEdition}</div>
          <div class="ligne">
            <div class="case">
              ${signatureUrl ? `<img src="${signatureUrl}" />` : ''}
              <div>${libelleSignature}</div>
              ${signatureNom ? `<div class="nom-signataire">${signatureNom}</div>` : ''}
            </div>
            <div class="case">${cachetUrl ? `<img src="${cachetUrl}" />` : ''}Cachet de l'école</div>
          </div>
        </div>
      </div>
    `;
  }

  const pagesHtml = pages.map((groupe) => {
    const colonnes = groupe.map(colonneEleve).join('');
    return `<div class="page">${colonnes}</div>`;
  }).join('');

  return `<!DOCTYPE html>
  <html>
    <head><meta charset="utf-8" /><style>${styles}</style></head>
    <body>${pagesHtml}</body>
  </html>`;
}

module.exports = { construireHtmlBulletins };
