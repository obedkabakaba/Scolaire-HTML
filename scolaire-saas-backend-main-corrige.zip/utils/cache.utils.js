/**
 * Cache mémoire à durée de vie — Ardoise.
 * ---------------------------------------------------------------------------
 * Le tableau de bord et la page Analyses agrègent des dizaines de milliers de
 * lignes sur toutes les écoles. Sans cache, un rafraîchissement toutes les
 * trente secondes suffirait à peser plus lourd que l'usage réel des écoles.
 *
 * Le cache est volontairement minimal : une Map, un TTL, une capacité maximale.
 * Pas de Redis — la plateforme tourne sur une instance unique, et une
 * dépendance externe pour cinq clés serait une complexité gratuite. Le jour où
 * plusieurs instances tourneront, seul ce fichier changera.
 *
 * `statistiques()` alimente la section « Cache » de la page Santé : ce n'est
 * pas un indicateur décoratif, c'est ce qui permet de voir qu'un cache ne sert
 * plus à rien (taux de succès effondré) avant que la base ne s'en plaigne.
 */

const CAPACITE_MAX = 200;

const entrees = new Map();
let succes = 0;
let echecs = 0;
let evictions = 0;

function maintenant() {
  return Date.now();
}

function purger() {
  const t = maintenant();
  for (const [cle, entree] of entrees) {
    if (entree.expire <= t) entrees.delete(cle);
  }
  // Capacité dépassée : on évince les plus anciennes entrées (Map conserve
  // l'ordre d'insertion, ce qui suffit ici).
  while (entrees.size > CAPACITE_MAX) {
    const premiere = entrees.keys().next().value;
    entrees.delete(premiere);
    evictions++;
  }
}

function lire(cle) {
  const entree = entrees.get(cle);
  if (!entree) { echecs++; return undefined; }
  if (entree.expire <= maintenant()) {
    entrees.delete(cle);
    echecs++;
    return undefined;
  }
  succes++;
  entree.lectures++;
  return entree.valeur;
}

function ecrire(cle, valeur, ttlSecondes = 60) {
  entrees.set(cle, {
    valeur,
    expire: maintenant() + ttlSecondes * 1000,
    ecrit: maintenant(),
    lectures: 0
  });
  purger();
  return valeur;
}

/**
 * Mémoïse une fonction asynchrone. Deux appels simultanés sur une clé froide
 * ne déclenchent qu'un seul calcul : sans cette mutualisation, cinq onglets
 * ouverts sur le tableau de bord lanceraient cinq agrégations identiques.
 */
const enVol = new Map();
async function memoiser(cle, ttlSecondes, producteur) {
  const dejaLa = lire(cle);
  if (dejaLa !== undefined) return dejaLa;

  if (enVol.has(cle)) return enVol.get(cle);

  const promesse = (async () => {
    try {
      const valeur = await producteur();
      ecrire(cle, valeur, ttlSecondes);
      return valeur;
    } finally {
      enVol.delete(cle);
    }
  })();

  enVol.set(cle, promesse);
  return promesse;
}

/** Invalide une clé exacte, ou toutes celles commençant par un préfixe. */
function invalider(prefixe) {
  if (!prefixe) {
    const n = entrees.size;
    entrees.clear();
    return n;
  }
  let n = 0;
  for (const cle of entrees.keys()) {
    if (cle === prefixe || cle.startsWith(prefixe)) { entrees.delete(cle); n++; }
  }
  return n;
}

function statistiques() {
  purger();
  const t = maintenant();
  const total = succes + echecs;
  return {
    etat: 'actif',
    type: 'memoire_processus',
    entrees: entrees.size,
    capacite: CAPACITE_MAX,
    taux_occupation: Math.round((entrees.size / CAPACITE_MAX) * 1000) / 10,
    succes,
    echecs,
    taux_succes: total ? Math.round((succes / total) * 1000) / 10 : 0,
    evictions,
    cles: [...entrees.entries()]
      .map(([cle, e]) => ({
        cle,
        lectures: e.lectures,
        expire_dans_s: Math.max(0, Math.round((e.expire - t) / 1000))
      }))
      .sort((a, b) => b.lectures - a.lectures)
      .slice(0, 20)
  };
}

function reinitialiserCompteurs() {
  succes = 0; echecs = 0; evictions = 0;
}

module.exports = { lire, ecrire, memoiser, invalider, statistiques, reinitialiserCompteurs };
