const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Le calendrier scolaire — brique dont dépendent les présences, le tableau de
 * bord et les rappels automatiques.
 *
 * Il répond à deux questions posées un peu partout dans la plateforme :
 *
 *   1. « Y a-t-il cours le JJ/MM ? »       → estJourOuvrable()
 *   2. « Quelle période est en cours ? »   → periodeCourante()
 *
 * Trois sources se combinent pour la première, et l'ordre compte :
 *   - `ecoles.jours_cours`      : les jours ouvrables de la SEMAINE (1 = lundi)
 *   - `jours_speciaux`          : les exceptions datées (fériés, vacances)
 *   - `annees_scolaires`        : les bornes de l'année elle-même
 *
 * Ces trois vérifications sont volontairement séparées et renvoient chacune
 * leur propre motif : dire « saisie impossible » sans expliquer pourquoi
 * laisserait l'utilisateur chercher une panne là où il n'y en a pas.
 */

const NOMS_JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];

/**
 * Convertit une date JS en numéro de jour de la semaine au format de
 * `ecoles.jours_cours` : 1 = lundi … 7 = dimanche.
 *
 * `Date.getDay()` renvoie 0 pour dimanche et 1 pour lundi : appliquer
 * directement cette valeur décalerait toute la semaine d'un cran, et un
 * dimanche passerait pour un jour ouvrable si lundi l'est.
 */
function numeroJourSemaine(date) {
  const jsJour = date.getDay();
  return jsJour === 0 ? 7 : jsJour;
}

/** Normalise en 'AAAA-MM-JJ', le format attendu par PostgreSQL pour un `date`. */
function versDateSql(valeur) {
  if (valeur instanceof Date) return valeur.toISOString().slice(0, 10);
  return String(valeur).slice(0, 10);
}

/**
 * Détermine si une date est un jour de classe pour l'école courante.
 *
 * @returns {Promise<{ouvrable: boolean, motif: string|null, detail: object|null}>}
 *
 * `ouvrable: false` s'accompagne TOUJOURS d'un motif exploitable en message :
 *   - 'hors_annee'      la date sort des bornes de l'année scolaire
 *   - 'jour_non_ouvre'  ce jour de la semaine n'est pas travaillé
 *   - 'jour_special'    férié, vacances ou congé (detail contient le libellé)
 */
async function estJourOuvrable(client, date, { cycle = null } = {}) {
  const dateSql = versDateSql(date);
  const objetDate = new Date(dateSql + 'T12:00:00');

  // ---- 1. Dans les bornes de l'année scolaire active ? ----
  const annee = await client.query(
    `SELECT id, libelle, date_debut, date_fin FROM annees_scolaires
      WHERE ecole_id = ${CURRENT_ECOLE} AND active = true AND cloturee = false
      LIMIT 1`
  );
  const anneeActive = annee.rows[0];
  if (anneeActive && anneeActive.date_debut && anneeActive.date_fin) {
    if (dateSql < versDateSql(anneeActive.date_debut) || dateSql > versDateSql(anneeActive.date_fin)) {
      return {
        ouvrable: false,
        motif: 'hors_annee',
        detail: { libelle: anneeActive.libelle },
        message: `Le ${formaterDateFr(dateSql)} est en dehors de l'année scolaire ${anneeActive.libelle}.`
      };
    }
  }

  // ---- 2. Jour ouvrable de la semaine ? ----
  const ecole = await client.query(
    `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5]) AS jours_cours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );
  const joursOuvrables = (ecole.rows[0]?.jours_cours || [1, 2, 3, 4, 5]).map(Number);
  const numeroJour = numeroJourSemaine(objetDate);
  if (!joursOuvrables.includes(numeroJour)) {
    return {
      ouvrable: false,
      motif: 'jour_non_ouvre',
      detail: { jour: NOMS_JOURS[objetDate.getDay()] },
      message: `Le ${NOMS_JOURS[objetDate.getDay()]} n'est pas un jour de classe dans cette école.`
    };
  }

  // ---- 3. Jour spécial (férié, vacances, congé) ? ----
  // Le filtre de cycle laisse passer les jours sans cycle (fériés nationaux,
  // qui concernent toute l'école) et ceux du cycle demandé.
  const special = await client.query(
    `SELECT libelle, type::text AS type, date_debut, date_fin
       FROM jours_speciaux
      WHERE ecole_id = ${CURRENT_ECOLE}
        AND $1::date BETWEEN date_debut AND date_fin
        AND (cycle IS NULL OR $2::text IS NULL OR cycle::text = $2)
      ORDER BY date_debut
      LIMIT 1`,
    [dateSql, cycle]
  );
  if (special.rows.length > 0) {
    const j = special.rows[0];
    // Chaque type a sa propre tournure : « est un vacances » serait fautif,
    // et un message mal écrit sur un écran vu tous les jours finit par décrédibiliser
    // l'ensemble de l'application.
    const tournures = {
      ferie: 'est un jour férié',
      vacances: 'tombe pendant les vacances',
      conge: 'est un jour de congé',
      greve: 'est un jour de grève',
      autre: 'est un jour non ouvré'
    };
    return {
      ouvrable: false,
      motif: 'jour_special',
      detail: j,
      message: `Le ${formaterDateFr(dateSql)} ${tournures[j.type] || 'est un jour non ouvré'} : ${j.libelle}.`
    };
  }

  return { ouvrable: true, motif: null, detail: null, message: null };
}

function formaterDateFr(dateSql) {
  const d = new Date(dateSql + 'T12:00:00');
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

/**
 * Retrouve la période EN COURS à une date donnée (aujourd'hui par défaut).
 *
 * Fondée sur `periodes.date_debut` / `date_fin`, déjà présents en base. Une
 * école qui ne renseigne pas ces dates n'obtiendra rien — c'est volontaire :
 * deviner la période courante à partir d'un simple numéro d'ordre donnerait un
 * résultat faux la moitié de l'année, et un tableau de bord qui affiche des
 * chiffres de la mauvaise période est pire qu'un tableau de bord qui dit
 * franchement qu'il ne sait pas.
 *
 * Les périodes de travail sont préférées aux semestres/trimestres qui les
 * contiennent : à une date donnée, on est dans la « 2ème période » ET dans le
 * « 1er semestre ». C'est la plus fine qui intéresse la saisie des notes.
 */
async function periodeCourante(client, { date = new Date(), cycle = null } = {}) {
  const dateSql = versDateSql(date);

  const r = await client.query(
    `SELECT p.id, p.libelle, p.type::text AS type, p.numero,
            p.date_debut, p.date_fin, p.semestre_id, p.cycle::text AS cycle,
            a.libelle AS annee_libelle
       FROM periodes p
       JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
      WHERE p.ecole_id = ${CURRENT_ECOLE}
        AND a.active = true AND a.cloturee = false
        AND p.date_debut IS NOT NULL AND p.date_fin IS NOT NULL
        AND $1::date BETWEEN p.date_debut AND p.date_fin
        AND ($2::text IS NULL OR p.cycle IS NULL OR p.cycle::text = $2)
      -- 'periode' et 'examen' avant 'semestre'/'trimestre' : à une même date,
      -- la période de travail est plus précise que le regroupement qui la contient.
      ORDER BY CASE p.type::text
                 WHEN 'periode' THEN 1
                 WHEN 'examen' THEN 2
                 ELSE 3
               END,
               p.numero
      LIMIT 1`,
    [dateSql, cycle]
  );

  return r.rows[0] || null;
}

/**
 * Périodes qui se terminent dans les `jours` prochains — support des rappels
 * « pensez à clôturer » et « déposez vos notes ».
 */
async function periodesQuiSeTerminent(client, { jours = 7 } = {}) {
  const r = await client.query(
    `SELECT p.id, p.libelle, p.type::text AS type, p.date_fin, p.cycle::text AS cycle,
            (p.date_fin - CURRENT_DATE) AS jours_restants
       FROM periodes p
       JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
      WHERE p.ecole_id = ${CURRENT_ECOLE}
        AND a.active = true AND a.cloturee = false
        AND p.date_fin IS NOT NULL
        AND p.date_fin BETWEEN CURRENT_DATE AND (CURRENT_DATE + $1::int)
      ORDER BY p.date_fin`,
    [jours]
  );
  return r.rows;
}

/**
 * Compte les jours ouvrables d'une plage — utile pour les statistiques
 * d'assiduité, où le dénominateur doit être le nombre de jours de classe et
 * non le nombre de jours calendaires.
 */
async function compterJoursOuvrables(client, debut, fin, { cycle = null } = {}) {
  const debutSql = versDateSql(debut);
  const finSql = versDateSql(fin);

  const ecole = await client.query(
    `SELECT COALESCE(jours_cours, ARRAY[1,2,3,4,5]) AS jours_cours FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );
  const joursOuvrables = (ecole.rows[0]?.jours_cours || [1, 2, 3, 4, 5]).map(Number);

  // EXTRACT(ISODOW) suit la même convention que jours_cours : 1 = lundi,
  // 7 = dimanche. Utiliser DOW (0 = dimanche) décalerait toute la semaine.
  const r = await client.query(
    `SELECT count(*)::int AS nb
       FROM generate_series($1::date, $2::date, '1 day') AS jour
      WHERE EXTRACT(ISODOW FROM jour)::int = ANY($3::int[])
        AND NOT EXISTS (
          SELECT 1 FROM jours_speciaux js
           WHERE js.ecole_id = ${CURRENT_ECOLE}
             AND jour::date BETWEEN js.date_debut AND js.date_fin
             AND (js.cycle IS NULL OR $4::text IS NULL OR js.cycle::text = $4)
        )`,
    [debutSql, finSql, joursOuvrables, cycle]
  );
  return r.rows[0].nb;
}

module.exports = {
  estJourOuvrable,
  periodeCourante,
  periodesQuiSeTerminent,
  compterJoursOuvrables,
  numeroJourSemaine,
  versDateSql,
  formaterDateFr,
  NOMS_JOURS,
};
