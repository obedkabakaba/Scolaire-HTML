/**
 * ARDOISE — CATALOGUE COMMERCIAL (source de vérité unique)
 * ===========================================================================
 *
 * CE QUE CE FICHIER EST
 * ---------------------
 * Le SEUL endroit du serveur où l'on répond aux questions suivantes :
 *
 *   · Quelle offre cette école a-t-elle ?
 *   · Combien d'élèves a-t-elle le droit d'avoir ?
 *   · A-t-elle accès à la comptabilité ? au WhatsApp ? aux concours ?
 *   · Combien coûte une campagne de capture pour 500 élèves ?
 *
 * CE QUE CE FICHIER N'EST PAS
 * ---------------------------
 * Il ne contient AUCUN prix, AUCUN nom d'offre, AUCUNE limite en dur. Tout
 * vient de `plans_abonnement` et `services_complementaires`. Changer le prix
 * de Prime, renommer Pilote ou relever le quota IA d'Infinite se fait en base
 * ou depuis l'espace Super Admin, jamais par un déploiement.
 *
 * La seule chose écrite en dur ici est la liste des CODES de fonctionnalités
 * et de limites — c'est-à-dire le vocabulaire, pas les valeurs. Le code doit
 * bien pouvoir écrire quelque part `exigeFonctionnalite('comptabilite')`.
 *
 * POURQUOI UN SEUL FICHIER
 * ------------------------
 * Parce que la version précédente lisait le quota IA dans `ia.utils.js`, les
 * limites nulle part, et les prix dans trois requêtes différentes selon le
 * contrôleur. Une école pouvait dépasser un plafond qu'aucun code ne
 * vérifiait, et une baisse de prix ne se voyait que sur deux écrans sur trois.
 */

const cache = require('./cache.utils');

/* =========================================================================
   VOCABULAIRE
   ========================================================================= */

/**
 * Fonctionnalités susceptibles d'être réservées à certaines offres.
 *
 * RÈGLE DE DÉCISION (celle qui a servi à établir cette liste) : n'apparaît
 * ici QUE ce dont l'absence n'empêche pas de faire tourner une école. Élèves,
 * notes, bulletins, présences et frais ne sont donc PAS dans cette liste, et
 * ne doivent jamais y entrer : les brider pour vendre l'offre supérieure
 * reviendrait à livrer un logiciel scolaire qui ne gère pas l'école.
 */
const FONCTIONNALITES = {
  // Organisation et vie scolaire
  emploi_du_temps:         'Emploi du temps, créneaux et exceptions',
  discipline:              'Incidents, règlement intérieur et capital conduite',
  communication_masse:     'Messages groupés aux parents et au personnel',
  site_public:             "Site public de l'école et résultats en ligne",
  modeles_personnalises:   'Éditeur de modèles de bulletins',

  // Pilotage
  comptabilite:            'Caisse, catégories et dépenses',
  paie:                    'Contrats et salaires du personnel',
  concours_admission:      "Sessions d'inscription et concours d'admission",
  orientation:             'Orientation des élèves au mérite',
  repechage:               'Session de repêchage de fin d\'année',
  rapports_avances:        'Rapports avancés et tableaux de bord analytiques',

  // Intelligence artificielle
  assistant_aide:          "Assistant d'aide contextuelle et didacticiel",
  ia_appreciations:        'Génération des appréciations et observations',
  ia_reglement_discipline: 'Lecture du règlement intérieur par l\'IA',
  ia_analyse_donnees:      'Questions sur les données en langage naturel',
  whatsapp:                'Assistant WhatsApp pour parents et personnel',

  // Exploitation
  support_prioritaire:      'Support prioritaire'
};

/*
 * TROIS DRAPEAUX ONT ÉTÉ RETIRÉS DE CETTE LISTE, ET IL FAUT SAVOIR POURQUOI.
 *
 *   ia_traitements_masse      · sauvegardes_a_la_demande · multi_etablissements
 *
 * Ils figuraient dans la première version de l'argumentaire d'Ardoise Infinite.
 * Aucun des trois ne correspond à quoi que ce soit dans le produit : il n'y a
 * ni route de traitement de masse, ni sauvegarde déclenchable par une école
 * (elles sont réservées au Super Admin), ni notion de réseau d'établissements
 * — un utilisateur appartient à une école et une seule, partout dans le code.
 *
 * Un drapeau qui ne verrouille rien ne fait pas qu'être inutile : il fait
 * croire à une fonctionnalité vendue. Le premier directeur qui souscrit
 * Infinite pour ses sauvegardes découvre le contraire, et ce qu'il en retient
 * ne concerne pas ce détail mais la confiance qu'il peut accorder au reste.
 *
 * Le jour où l'une des trois existe, la remettre ici, dans le semis SQL et
 * sur la page tient en trois lignes.
 */

/**
 * Limites quantitatives. `null` en base signifie « sans limite » — à ne pas
 * confondre avec `undefined`, qui signifie « la base ne dit rien », auquel
 * cas on applique le repli ci-dessous plutôt que d'ouvrir en grand.
 */
const LIMITES = {
  max_eleves:               { libelle: 'Élèves',                 repli: 250 },
  max_utilisateurs:         { libelle: 'Comptes utilisateurs',   repli: 15 },
  max_classes:              { libelle: 'Classes',                repli: 12 },
  ia_quota_mensuel:         { libelle: 'Générations IA par mois', repli: 100 },
  historique_annees:        { libelle: 'Années scolaires consultables', repli: 1 },
  stockage_mo:              { libelle: 'Stockage (Mo)',          repli: 500 },
  notifications_email_mois: { libelle: 'E-mails par mois',       repli: 500 }
};

/**
 * Nombre de jours facturés par périodicité.
 *
 * Ces valeurs ne sont pas des prix : ce sont des durées calendaires, et elles
 * n'ont donc rien à faire en base. Elles corrigent au passage un défaut réel :
 * `plans_abonnement.duree_jours` vaut 30 pour toutes les offres, si bien qu'un
 * abonnement réglé pour un AN n'était prolongé que d'un mois.
 */
const JOURS_PAR_PERIODICITE = {
  mensuel: 30,
  trimestriel: 91,
  semestriel: 182,
  annuel: 365
};

/** Les trois périodicités proposées commercialement, dans l'ordre d'affichage. */
const PERIODICITES = [
  { code: 'mensuel',    libelle: 'Mensuel',    mois: 1,  colonne: 'prix' },
  { code: 'semestriel', libelle: 'Semestriel', mois: 6,  colonne: 'prix_semestriel' },
  { code: 'annuel',     libelle: 'Annuel',     mois: 12, colonne: 'prix_annuel' }
];

/* =========================================================================
   LECTURE DU CATALOGUE
   ========================================================================= */

const DUREE_CACHE_S = 60;   // cache.utils attend des SECONDES, pas des millisecondes

/**
 * Les quatre offres publiables, prix des trois périodicités compris.
 *
 * L'économie affichée est CALCULÉE, jamais saisie : impossible d'annoncer
 * « −20 % » sur une grille qui n'en fait que 9. Un prix barré inventé est un
 * mensonge que le premier directeur qui sort sa calculette découvre.
 */
async function listerOffres(client, { inclureNonPubliques = false } = {}) {
  const resultat = await client.query(`
    SELECT id, code, nom, description, positionnement, cible,
           prix, prix_semestriel, prix_annuel, devise, duree_jours,
           limites, fonctionnalites, fonctionnalites_incluses, fonctionnalites_exclues,
           badge, couleur, texte_marketing, ordre_affichage, visible_public
      FROM plans_abonnement
     WHERE COALESCE(statut, 'actif') = 'actif'
       ${inclureNonPubliques ? '' : 'AND visible_public = true'}
     ORDER BY COALESCE(ordre_affichage, 0), prix NULLS LAST, nom`);

  return resultat.rows.map(enrichirOffre);
}

/** Ajoute à une ligne de plan tout ce qui se déduit d'elle, et rien de plus. */
function enrichirOffre(ligne) {
  const mensuel = nombreOuNull(ligne.prix);
  const tarifs = {};

  for (const p of PERIODICITES) {
    const total = nombreOuNull(ligne[p.colonne]);
    if (total === null) { tarifs[p.code] = null; continue; }

    const parMois = arrondir(total / p.mois);
    const referenceMensuelle = mensuel !== null ? mensuel * p.mois : null;
    const economie = (referenceMensuelle !== null && referenceMensuelle > total)
      ? arrondir(referenceMensuelle - total) : 0;

    tarifs[p.code] = {
      total,
      par_mois: parMois,
      mois: p.mois,
      jours: JOURS_PAR_PERIODICITE[p.code],
      // Ce qu'aurait coûté la même durée payée mois par mois.
      reference_mensuelle: referenceMensuelle,
      economie,
      economie_pourcentage: (referenceMensuelle && economie)
        ? Math.round((economie / referenceMensuelle) * 100) : 0
    };
  }

  return {
    id: ligne.id,
    code: ligne.code,
    nom: ligne.nom,
    description: ligne.description,
    positionnement: ligne.positionnement,
    cible: ligne.cible,
    devise: ligne.devise || 'USD',
    badge: ligne.badge,
    couleur: ligne.couleur,
    texte_marketing: ligne.texte_marketing,
    ordre: ligne.ordre_affichage,
    tarifs,
    limites: normaliserLimites(ligne.limites, ligne),
    fonctionnalites: normaliserFonctionnalites(ligne.fonctionnalites),
    points_forts: tableauOuVide(ligne.fonctionnalites_incluses),
    exclusions: tableauOuVide(ligne.fonctionnalites_exclues)
  };
}

/**
 * Limites d'un plan, toutes clés présentes.
 *
 * Ordre de résolution : `limites` (colonne dédiée, migration 028), puis les
 * anciennes colonnes `max_eleves` / `max_utilisateurs` pour une base pas
 * encore migrée, puis le repli. Une base non migrée continue donc de
 * fonctionner, avec des plafonds prudents plutôt qu'inexistants.
 */
function normaliserLimites(brut, ligne) {
  const source = (brut && typeof brut === 'object' && !Array.isArray(brut)) ? brut : {};
  const sortie = {};

  for (const [cle, def] of Object.entries(LIMITES)) {
    let valeur;
    if (Object.prototype.hasOwnProperty.call(source, cle)) {
      valeur = source[cle];                                   // y compris null = illimité
    } else if (cle === 'max_eleves' && ligne && ligne.max_eleves !== undefined) {
      valeur = ligne.max_eleves;
    } else if (cle === 'max_utilisateurs' && ligne && ligne.max_utilisateurs !== undefined) {
      valeur = ligne.max_utilisateurs;
    } else if (cle === 'ia_quota_mensuel' && ligne && ligne.fonctionnalites
               && ligne.fonctionnalites.ia_quota_mensuel !== undefined) {
      valeur = ligne.fonctionnalites.ia_quota_mensuel;         // compatibilité ia.utils.js
    } else {
      valeur = def.repli;
    }
    sortie[cle] = (valeur === null || valeur === '') ? null : nombreOuNull(valeur);
  }
  return sortie;
}

/** Drapeaux de fonctionnalités, toutes clés présentes, valeurs booléennes. */
function normaliserFonctionnalites(brut) {
  const source = (brut && typeof brut === 'object' && !Array.isArray(brut)) ? brut : {};
  const sortie = {};
  for (const cle of Object.keys(FONCTIONNALITES)) sortie[cle] = source[cle] === true;
  return sortie;
}

/* =========================================================================
   OFFRE D'UNE ÉCOLE DONNÉE
   ========================================================================= */

/**
 * L'offre effectivement en vigueur pour une école, ou `null`.
 *
 * On ne retient QUE les abonnements actifs. Une école suspendue pour impayé
 * n'a pas « l'offre Pilote sans y avoir droit » : elle n'a pas d'offre, et
 * l'appelant décide quoi en faire. Le comportement historique — laisser
 * passer faute de plan trouvé — est conservé par `plafondsParDefaut()`, pour
 * ne pas mettre une école dehors sur une régression de facturation.
 */
async function offreDeLEcole(client, ecoleId) {
  if (!ecoleId) return null;

  const cle = `catalogue:offre:${ecoleId}`;
  const enCache = lireCache(cle);
  if (enCache !== undefined) return enCache;

  const resultat = await client.query(`
    SELECT p.id, p.code, p.nom, p.description, p.positionnement, p.cible,
           p.prix, p.prix_semestriel, p.prix_annuel, p.devise, p.duree_jours,
           p.limites, p.fonctionnalites, p.fonctionnalites_incluses, p.fonctionnalites_exclues,
           p.badge, p.couleur, p.texte_marketing, p.ordre_affichage, p.visible_public,
           a.statut AS abonnement_statut, a.periodicite, a.date_expiration
      FROM abonnements a
      JOIN plans_abonnement p ON p.id = a.plan_id
     WHERE a.ecole_id = $1 AND a.statut = 'actif'
     ORDER BY a.created_at DESC
     LIMIT 1`, [ecoleId]);

  if (resultat.rows.length === 0) { ecrireCache(cle, null); return null; }

  const offre = enrichirOffre(resultat.rows[0]);
  offre.abonnement = {
    statut: resultat.rows[0].abonnement_statut,
    periodicite: resultat.rows[0].periodicite,
    date_expiration: resultat.rows[0].date_expiration
  };
  ecrireCache(cle, offre);
  return offre;
}

/**
 * Plafonds appliqués quand aucune offre active n'est trouvée.
 *
 * Volontairement PERMISSIFS : une panne de facturation ne doit pas bloquer la
 * saisie des notes la veille des bulletins. Le rappel de paiement et la
 * suspension d'école existent déjà pour cela, et eux le font explicitement.
 */
function plafondsParDefaut() {
  const limites = {};
  for (const [cle, def] of Object.entries(LIMITES)) limites[cle] = def.repli;
  const fonctionnalites = {};
  for (const cle of Object.keys(FONCTIONNALITES)) fonctionnalites[cle] = true;
  return { limites, fonctionnalites, sans_offre: true };
}

/** L'école a-t-elle droit à cette fonctionnalité ? */
async function aDroitA(client, ecoleId, codeFonctionnalite) {
  if (!Object.prototype.hasOwnProperty.call(FONCTIONNALITES, codeFonctionnalite)) {
    throw new Error(`Fonctionnalité inconnue : ${codeFonctionnalite}. `
                  + `Ajoutez-la dans utils/catalogue.utils.js.`);
  }
  const offre = await offreDeLEcole(client, ecoleId);
  if (!offre) return plafondsParDefaut().fonctionnalites[codeFonctionnalite] === true;
  return offre.fonctionnalites[codeFonctionnalite] === true;
}

/** Valeur d'une limite pour une école. `null` = sans limite. */
async function limiteDe(client, ecoleId, cleLimite) {
  if (!Object.prototype.hasOwnProperty.call(LIMITES, cleLimite)) {
    throw new Error(`Limite inconnue : ${cleLimite}.`);
  }
  const offre = await offreDeLEcole(client, ecoleId);
  if (!offre) return plafondsParDefaut().limites[cleLimite];
  return offre.limites[cleLimite];
}

/**
 * Vérifie qu'ajouter `ajout` élément(s) reste dans le plafond.
 * Renvoie `{ autorise, limite, utilise, restant }` — jamais d'exception :
 * l'appelant décide s'il refuse ou s'il avertit.
 */
async function verifierPlafond(client, ecoleId, cleLimite, requeteComptage, ajout = 1) {
  const limite = await limiteDe(client, ecoleId, cleLimite);
  if (limite === null) return { autorise: true, limite: null, utilise: null, restant: null };

  const compte = await client.query(requeteComptage, [ecoleId]);
  const utilise = Number(compte.rows[0] ? compte.rows[0].total : 0);

  return {
    autorise: utilise + ajout <= limite,
    limite,
    utilise,
    restant: Math.max(limite - utilise, 0)
  };
}

/* =========================================================================
   DROITS NORMALISÉS — CE QUE LE RESTE DU SERVEUR CONSOMME
   =========================================================================

   POURQUOI CETTE FONCTION EXISTE
   ------------------------------
   `aDroitA()` répond à UNE question à la fois, et refait une lecture par
   appel. Le moteur d'onboarding, lui, doit décider de vingt-cinq étapes d'un
   coup : il lui faut la table entière des droits, une fois, sous une forme
   dont il peut supposer que toutes les clés existent.

   Sans cet objet, `construireParcours()` aurait eu deux choix, tous deux
   mauvais : appeler la base vingt-cinq fois, ou recevoir un objet partiel où
   `droits.emploi_du_temps === undefined` se confondrait avec « refusé ». La
   confusion est loin d'être théorique : c'est exactement elle qui aurait
   retiré une étape à une école qui y a droit.

   `signature` sert à autre chose : c'est l'empreinte de l'offre effective.
   Le frontend la garde à côté de son cache `sessionStorage` et vide ce cache
   dès qu'elle change. C'est ce qui empêche une école montée en Prime le matin
   de voir encore le menu d'Ascension l'après-midi.
   ========================================================================= */

const crypto = require('crypto');

/**
 * Table complète des droits d'une école, toutes clés présentes.
 *
 * @returns {{fonctionnalites: object, limites: object, offre_code: ?string,
 *            offre_nom: ?string, sans_offre: boolean, signature: string}}
 */
async function droitsDeLEcole(client, ecoleId) {
  const offre = await offreDeLEcole(client, ecoleId);

  if (!offre) {
    // Même règle que partout : une panne de facturation n'enlève rien. Les
    // droits par défaut sont ouverts, les plafonds restent prudents.
    const repli = plafondsParDefaut();
    return {
      fonctionnalites: repli.fonctionnalites,
      limites: repli.limites,
      offre_code: null,
      offre_nom: null,
      sans_offre: true,
      signature: signatureDroits(null, repli.fonctionnalites)
    };
  }

  return {
    fonctionnalites: offre.fonctionnalites,
    limites: offre.limites,
    offre_code: offre.code || null,
    offre_nom: offre.nom || null,
    sans_offre: false,
    signature: signatureDroits(offre.code, offre.fonctionnalites)
  };
}

/**
 * Empreinte courte d'un jeu de droits.
 *
 * Elle ne porte QUE le code d'offre et les drapeaux : deux écoles en Prime
 * partagent la même signature, ce qui est voulu — c'est une clé de cache, pas
 * un identifiant d'école, et elle ne doit rien révéler.
 */
function signatureDroits(codeOffre, fonctionnalites) {
  const actives = Object.keys(fonctionnalites || {})
    .filter((c) => fonctionnalites[c] === true)
    .sort()
    .join(',');
  return crypto.createHash('sha256')
    .update(`${codeOffre || 'sans_offre'}|${actives}`)
    .digest('hex')
    .slice(0, 16);
}

/**
 * Droits « tout ouvert », pour les contextes hors école (tests, Super Admin
 * sans établissement). Déclaré ici pour que personne n'ait à recomposer la
 * liste des codes à la main — un oubli y passerait inaperçu.
 */
function droitsComplets() {
  const fonctionnalites = {};
  for (const cle of Object.keys(FONCTIONNALITES)) fonctionnalites[cle] = true;
  return {
    fonctionnalites,
    limites: plafondsParDefaut().limites,
    offre_code: null,
    offre_nom: null,
    sans_offre: true,
    signature: signatureDroits(null, fonctionnalites)
  };
}

/* =========================================================================
   SERVICES COMPLÉMENTAIRES
   ========================================================================= */

/**
 * Le catalogue des prestations.
 *
 * Aucun filtre par plan, et c'est le point : une école en Ascension voit
 * exactement la même liste qu'une école en Infinite. Un service ne se mérite
 * pas, il s'achète.
 */
async function listerServices(client, { inclureNonPublics = false } = {}) {
  const resultat = await client.query(`
    SELECT id, code, categorie, nom, accroche, description, mode_tarification,
           prix_unitaire, devise, unite, quantite_minimum, duree_indicative,
           inclus, exclus, prerequis, cible, ordre_affichage
      FROM services_complementaires
     WHERE statut = 'actif'
       ${inclureNonPublics ? '' : 'AND visible_public = true'}
     ORDER BY COALESCE(ordre_affichage, 0), nom`);

  return resultat.rows.map((s) => ({
    id: s.id,
    code: s.code,
    categorie: s.categorie,
    nom: s.nom,
    accroche: s.accroche,
    description: s.description,
    mode_tarification: s.mode_tarification,
    prix_unitaire: nombreOuNull(s.prix_unitaire),
    devise: s.devise || 'USD',
    unite: s.unite,
    quantite_minimum: nombreOuNull(s.quantite_minimum),
    duree_indicative: s.duree_indicative,
    inclus: tableauOuVide(s.inclus),
    exclus: tableauOuVide(s.exclus),
    prerequis: tableauOuVide(s.prerequis),
    cible: s.cible,
    ordre: s.ordre_affichage
  }));
}

/**
 * Montant d'une prestation. LE SEUL endroit où ce calcul existe.
 *
 * La page publique, le formulaire de commande et la facturation appellent
 * tous les trois cette fonction. C'est ce qui garantit qu'un directeur ne
 * verra jamais 250 $ sur le site et 260 $ sur sa facture pour 500 élèves.
 */
function calculerMontantService(service, quantiteDemandee) {
  if (!service) throw Object.assign(new Error('Service inconnu.'), { statusCode: 404 });

  if (service.mode_tarification === 'forfait') {
    return {
      quantite: 1,
      prix_unitaire: service.prix_unitaire,
      montant_total: arrondir(service.prix_unitaire),
      devise: service.devise
    };
  }

  const quantite = Math.floor(Number(quantiteDemandee));
  if (!Number.isFinite(quantite) || quantite <= 0) {
    throw Object.assign(
      new Error(`Indiquez un nombre d'${service.unite || 'unités'} supérieur à zéro.`),
      { statusCode: 400 });
  }

  const minimum = service.quantite_minimum || 0;
  const facturee = Math.max(quantite, minimum);

  return {
    quantite,
    quantite_facturee: facturee,
    prix_unitaire: service.prix_unitaire,
    montant_total: arrondir(facturee * service.prix_unitaire),
    devise: service.devise,
    minimum_applique: facturee > quantite ? minimum : null
  };
}

/** Durée en jours d'une périodicité, avec repli sur le plan. */
function joursDePeriodicite(periodicite, dureeJoursDuPlan) {
  return JOURS_PAR_PERIODICITE[periodicite] || Number(dureeJoursDuPlan) || 30;
}

/* =========================================================================
   PETITS OUTILS
   ========================================================================= */

function nombreOuNull(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function arrondir(n) { return Math.round(Number(n) * 100) / 100; }

function tableauOuVide(v) {
  if (Array.isArray(v)) return v.filter((x) => typeof x === 'string' && x.trim());
  return [];
}

function lireCache(cle) {
  try { return cache.lire ? cache.lire(cle) : undefined; } catch { return undefined; }
}
function ecrireCache(cle, valeur) {
  try { if (cache.ecrire) cache.ecrire(cle, valeur, DUREE_CACHE_S); } catch { /* sans effet */ }
}

/** À appeler après toute écriture commerciale (offre, abonnement, service). */
function invaliderCache() {
  try { if (cache.invalider) cache.invalider('catalogue:'); } catch { /* sans effet */ }
}

module.exports = {
  FONCTIONNALITES,
  LIMITES,
  PERIODICITES,
  JOURS_PAR_PERIODICITE,
  listerOffres,
  offreDeLEcole,
  aDroitA,
  droitsDeLEcole,
  droitsComplets,
  signatureDroits,
  limiteDe,
  verifierPlafond,
  plafondsParDefaut,
  listerServices,
  calculerMontantService,
  joursDePeriodicite,
  invaliderCache
};
