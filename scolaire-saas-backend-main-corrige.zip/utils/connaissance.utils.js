/**
 * ============================================================================
 *  BASE DE CONNAISSANCE — assistant d'aide à l'utilisation
 * ============================================================================
 *
 * Une seule source pour trois usages : la consigne de l'assistant IA, le
 * contenu des manuels de procédure distribués aux écoles qui n'ont pas l'offre
 * incluant l'IA, et le texte du didacticiel. Écrire trois fois la même chose
 * garantirait qu'elles divergent — et c'est l'écart entre ce que dit
 * l'assistant et ce que dit le manuel qui ferait perdre confiance dans les
 * deux.
 *
 * CE QUI A CHANGÉ, ET POURQUOI
 * ----------------------------
 * L'assistant décrivait des ÉCRANS : « allez dans Classes ». Une personne qui
 * ouvre l'écran Classes pour la première fois se retrouve devant une fenêtre
 * dont elle ne sait pas quoi remplir, et l'aide s'arrête exactement là où la
 * difficulté commence. Chaque étape porte désormais un champ `champs` : la
 * liste, dans l'ordre du formulaire, de ce qu'il y a DANS la fenêtre, avec ce
 * qu'il faut y mettre. C'est ce niveau de détail qui permet à l'assistant de
 * donner « exactement la bonne procédure » plutôt qu'une direction.
 *
 * Le catalogue des procédures a par ailleurs été aligné sur les commandes
 * réellement exposées par l'API : chaque route de `routes/` qui correspond à
 * un geste d'utilisateur a désormais sa procédure. L'assistant ne peut pas
 * expliquer ce qu'il ignore, et il inventait — ou renvoyait vers la direction —
 * pour tout ce qui manquait ici : repêchage, orientation, clôture de période,
 * comptabilité, paie, archives, emploi du temps, site public, modèles de
 * bulletins, travaux, import d'élèves.
 *
 * CE QUE L'ASSISTANT SAIT
 * -----------------------
 * Le fonctionnement de la plateforme : où se trouve quoi, dans quel ordre
 * faire les choses, ce que signifie tel réglage. C'est un manuel d'utilisation
 * qui répond aux questions.
 *
 * CE QU'IL NE SAIT PAS, ET NE DOIT PAS SAVOIR
 * -------------------------------------------
 * Les données de l'école. Il ne voit ni les élèves, ni les notes, ni les
 * paiements. C'est ce qui permet de l'ouvrir à TOUS les rôles — un professeur
 * peut lui demander comment saisir ses cotes sans qu'il puisse lui révéler les
 * cotes d'un collègue. Les questions portant sur des données réelles sont
 * renvoyées vers l'écran compétent, jamais devinées.
 */

/* ==========================================================================
   1. ORDRE DE CONFIGURATION
   ==========================================================================

   Chaque étape porte :
     etape    numéro historique — ne jamais renuméroter, `onboarding.utils.js`
              y renvoie par `etape_config`
     titre    libellé
     ecran    chemin lisible tel qu'il apparaît dans le menu
     roles    qui peut la faire
     quoi     ce qu'il faut faire, en une phrase
     champs   CE QU'IL Y A DANS LA FENÊTRE, dans l'ordre du formulaire
     pourquoi ce que l'étape commande ailleurs
     avant    ce qui doit être fait d'abord
     piege    l'erreur réellement observée
   ========================================================================== */

const ORDRE_CONFIGURATION = [
  {
    etape: 1,
    titre: "Identité et régime de l'école",
    ecran: 'Paramètres',
    roles: ['directeur'],
    quoi: "Renseigner l'identité de l'établissement, puis les trois réglages qui commandent tout le reste : le type d'enseignement, la devise principale et le taux de change.",
    champs: [
      "Bloc « Identité » — Nom de l'école : le nom complet, tel qu'il doit apparaître en tête des bulletins.",
      "Ville, Commune / Territoire, Province : l'adresse administrative ; elle est reprise sur les bulletins officiels RDC.",
      "Email, Téléphone, Adresse : les coordonnées de l'établissement, imprimées en pied de bulletin.",
      "Type d'enseignement : « Primaire », « Secondaire » ou « Les deux ». Ce choix filtre les vacations, les modèles de bulletins et la structure des périodes proposés partout ailleurs.",
      "Logo, Cachet de l'école, Ma signature (Directeur) : trois images séparées, chacune avec son bouton « Changer ». Le cachet et la signature sont apposés sur les bulletins signés — sans eux, le bulletin sort nu.",
      "Bouton « Enregistrer » du bloc Identité : chaque bloc de l'écran a son propre bouton. Enregistrer l'identité ne sauvegarde pas la devise.",
      "Bloc « Devise » — Devise principale : FC ou USD. C'est la devise dans laquelle les totaux sont présentés.",
      "Taux de change — FC pour 1 USD : obligatoire dès que l'école encaisse dans les deux devises. La date de la dernière mise à jour est affichée à côté.",
      "Bloc « Pédagogique » — Maximum par défaut (sur) : le maximum de points appliqué à un cours créé sans maximum propre.",
      "Nombre de trimestres / Nombre de périodes / Nombre de semestres : le découpage de l'année. Il sert de gabarit à l'écran Année scolaire.",
      "Passe en classe supérieure à partir de (%) et Redouble à partir de (%) : les deux seuils de la promotion de fin d'année. Entre les deux se trouve la zone de repêchage.",
      "Qui fait l'appel ? : « le titulaire », « le professeur de l'heure » ou « un chargé désigné ». Ce réglage décide à qui l'écran Présences est ouvert.",
      "Autoriser les titulaires à générer les bulletins de leur classe : si oui, un second réglage demande « Qui, précisément ? » — tous les titulaires, ou une liste nominative.",
      "Autoriser un même titulaire à gérer plusieurs classes : à activer dans les petites écoles où un enseignant est titulaire de deux classes.",
      "Autoriser les titulaires à modifier les observations même après signature."
    ],
    pourquoi: "Le type d'enseignement filtre ce que les autres écrans proposent : vacations, modèles de bulletins, structure des périodes. Le changer après coup laisse des éléments créés pour le mauvais cycle, invisibles mais bien présents.",
    avant: "Rien. C'est le premier écran à remplir.",
    piege: "Une école qui fait primaire ET secondaire doit choisir « les deux » dès le départ, même si elle ne saisit d'abord que le primaire. Autre piège : chaque bloc de l'écran Paramètres a SON bouton Enregistrer — remplir trois blocs et n'en enregistrer qu'un est l'erreur la plus fréquente de cet écran."
  },
  {
    etape: 2,
    titre: "Année scolaire",
    ecran: 'Année scolaire › onglet « Années »',
    roles: ['directeur', 'prefet'],
    quoi: "Créer l'année (par exemple 2025-2026), renseigner ses dates, puis l'ACTIVER.",
    champs: [
      "Onglet « Années » en haut de l'écran.",
      "Libellé : le nom de l'année, par exemple « 2025-2026 ».",
      "Date de début et Date de fin : les bornes de l'année scolaire.",
      "Bouton « Ajouter » : crée l'année. Elle apparaît alors dans la liste en dessous.",
      "Dans la liste, le bouton « Activer » de la ligne : c'est LUI qui rend l'année courante. Créer l'année ne suffit pas."
    ],
    pourquoi: "Presque tout est rattaché à une année : classes, élèves, notes, bulletins, frais. Sans année active, les rapports refusent de se calculer et les écrans restent vides.",
    avant: "L'étape 1.",
    piege: "Créer l'année sans cliquer sur « Activer » : tous les écrans continuent alors de travailler sur l'année précédente. Une seule année peut être active à la fois. Clôturer une année n'est pas la supprimer : les archives continuent de la lire."
  },
  {
    etape: 3,
    titre: "Périodes",
    ecran: 'Année scolaire › onglet « Périodes »',
    roles: ['directeur', 'prefet'],
    quoi: "Créer les périodes de l'année : trimestres ou semestres selon le cycle, les périodes de travail et les périodes d'examen, avec leurs dates.",
    champs: [
      "Onglet « Périodes », puis le sélecteur « Année » en haut : on crée toujours les périodes DANS une année.",
      "Type : « Trimestre », « Semestre », « Période » (période de travail) ou « Examen ». Le type décide du calcul : sur une période d'examen c'est le maximum d'examen du cours qui compte, pas le maximum ordinaire.",
      "Numéro : le rang de la période (1, 2, 3…).",
      "Libellé : le nom affiché sur les bulletins, par exemple « 1er trimestre ».",
      "Rattachement au semestre : ce champ n'apparaît que si des semestres existent ; il dit à quel semestre la période appartient.",
      "Date de début et Date de fin : elles servent à déterminer la période « en cours », qui pré-remplit les écrans de saisie.",
      "Bouton « Ajouter » : la période s'ajoute à la liste."
    ],
    pourquoi: "Une note se rattache toujours à une période. Les dates servent à déterminer la période « en cours », qui pré-remplit les écrans de saisie et les rapports.",
    avant: "L'étape 2.",
    piege: "Sans dates renseignées, la plateforme ne sait pas quelle période est en cours et retombe sur la dernière période créée. Renseignez-les. Second piège : oublier les périodes d'examen — les cotes d'examen n'auraient alors nulle part où se poser."
  },
  {
    etape: 4,
    titre: "Vacations et heures de cours",
    ecran: 'Emploi du temps › onglet « Configuration »',
    roles: ['directeur', 'prefet'],
    quoi: "Créer les vacations si l'école en a plusieurs, puis définir les heures de cours de la journée.",
    champs: [
      "Onglet « Configuration » de l'écran Emploi du temps.",
      "Bloc « Vacations » — Nom : « Matin », « Après-midi ». Cycle : à quel cycle la vacation appartient. Ordre : l'ordre d'affichage. Bouton « Ajouter une vacation ».",
      "Bloc « Heures de cours » — Grille de la vacation : à quelle vacation la grille appartient (une école mono-vacation laisse ce champ vide).",
      "Libellé : « 1ère heure », « 2e heure »…",
      "Heure de début et Heure de fin : au format 07:30.",
      "Ordre : le rang dans la journée.",
      "Bouton « Ajouter un créneau », puis « Enregistrer la configuration »."
    ],
    pourquoi: "Les heures de cours structurent l'emploi du temps et l'appel. Une école mono-vacation crée quand même ses heures, mais peut se passer de vacations.",
    avant: "L'étape 1 (le type d'enseignement filtre les vacations proposées).",
    piege: "Un mercredi écourté ou un samedi particulier ne se règle PAS en créant une seconde grille : utilisez « Horaires exceptionnels » sur ce même écran, qui prend le jour concerné, l'heure habituelle, la portée (toute l'école ou une classe) et la nouvelle heure."
  },
  {
    etape: 5,
    titre: "Sections et options",
    ecran: 'Classes › onglet « Structure »',
    roles: ['directeur', 'prefet'],
    quoi: "Au secondaire : créer les sections (Scientifique, Littéraire, Technique…) puis les options rattachées (Math-Physique, Biochimie, Commerciale, Pédagogie…).",
    champs: [
      "Onglet « Structure » de l'écran Classes.",
      "Bloc « Options » — Nom de l'option : par exemple « Biochimie ».",
      "Section de rattachement : la section à laquelle l'option appartient.",
      "Critère d'accès : « Moyenne globale » ou « Une branche précise ». Il sert à l'orientation de fin de cycle.",
      "Branche du critère (si « branche ») et Minimum requis (%) : le seuil qu'un élève doit atteindre pour prétendre à cette option.",
      "Bouton « Ajouter » : l'option s'ajoute à la liste en dessous."
    ],
    pourquoi: "Les options portent les classes du secondaire et servent à l'orientation de fin de cycle.",
    avant: "L'étape 1.",
    piege: "Le primaire n'a ni sections ni options : passez cette étape. Et une option sans critère ne pourra pas être attribuée automatiquement au mérite lors de l'orientation."
  },
  {
    etape: 6,
    titre: "Catalogue des cours",
    ecran: "Classes › ouvrir une classe › « Cours de cette classe » (l'écran Cours sert à relire, pas à créer)",
    roles: ['directeur', 'prefet'],
    quoi: "Créer chaque branche enseignée avec son maximum de points ordinaire ET son maximum d'examen.",
    champs: [
      "Un cours se crée en le rattachant directement à une classe : ouvrez Classes, cliquez sur une classe, puis descendez au bloc « Cours de cette classe ».",
      "Nom du cours : le nom de la branche.",
      "Code : abréviation facultative, utilisée quand la place manque sur le bulletin.",
      "Maximum de points : le dénominateur ordinaire de la branche (20, 50, 100…).",
      "Case « Ce cours n'a pas d'examen » : à cocher pour une branche non soumise à examen.",
      "Maximum de l'examen : le dénominateur des périodes d'examen. Laissé vide, il vaut par défaut le double du maximum de période.",
      "Bouton « Ajouter » : le cours est créé ET rattaché à la classe en un geste.",
      "L'écran « Cours » du menu sert ensuite à relire tout le catalogue, repérer les doublons, les cours non rattachés et les cours sans professeur, et à corriger les maximums."
    ],
    pourquoi: "Le maximum d'un cours est le dénominateur de toutes les moyennes. Le maximum d'EXAMEN est distinct : sur une période d'examen, c'est lui qui compte.",
    avant: "L'étape 7 (la classe doit exister pour y rattacher un cours).",
    piege: "Chercher un bouton « Ajouter un cours » sur l'écran Cours : il n'y en a pas, la création se fait depuis la classe. Autre piège : un cours sans maximum d'examen ne compte ni au numérateur ni au dénominateur des périodes d'examen. C'est correct si le cours n'a pas d'examen, faux si vous avez simplement oublié de le remplir — l'écran Cours signale ces cas."
  },
  {
    etape: 7,
    titre: "Classes",
    ecran: 'Classes › onglet « Classes » › bouton « Ajouter une classe »',
    roles: ['directeur', 'prefet'],
    quoi: "Créer chaque classe avec son nom, son niveau, sa division, son cycle, son option, sa vacation, sa capacité et sa classe suivante.",
    champs: [
      "Nom de la classe : par exemple « 3ème Scientifique A ».",
      "Niveau (1 à 8) : le RANG de l'année d'études dans le cycle — 1 pour la 1ère année, 6 pour la 6ème. C'est ce nombre, et non le nom, qui permet à la promotion de fin d'année de savoir quelle classe vient après.",
      "Division : la lettre qui distingue deux classes parallèles du même niveau (A, B, C). Laissez vide s'il n'y a qu'une classe par niveau.",
      "Cycle : Primaire ou Secondaire / Humanités.",
      "Case « Classe d'orientation » : à cocher sur la classe de fin de cycle où les élèves choisissent leur option pour l'année suivante.",
      "Case « Classe terminale » : à cocher sur la classe où les élèves terminent leur parcours et sortent diplômés. Sans elle, la promotion cherche une classe supérieure qui n'existe pas.",
      "Capacité (places) : sert à l'orientation et aux concours d'admission. Vide = sans limite.",
      "Vacation : matin ou après-midi, si l'école en a plusieurs.",
      "Option : l'option du secondaire portée par la classe.",
      "Titulaire : l'enseignant responsable de la classe. Le champ ne propose que des comptes existants, il faut donc avoir créé les utilisateurs.",
      "Année scolaire : pré-remplie avec l'année active.",
      "Classe suivante : la classe dans laquelle passent les élèves qui réussissent. C'est ce lien que suit la promotion.",
      "Bouton « Enregistrer ». En rouvrant la classe, un bloc « Cours de cette classe » apparaît en dessous du formulaire."
    ],
    pourquoi: "Le niveau et la division commandent la promotion automatique de fin d'année. La capacité sert à l'orientation et aux inscriptions.",
    avant: "Les étapes 2, 4 et 5.",
    piege: "Le niveau et la division sont souvent oubliés : sans eux, la promotion de fin d'année ne peut pas s'exécuter, et un concours d'admission ne trouvera aucune classe d'accueil pour l'année suivante. Le tableau des classes affiche « niveau manquant » en rouge tant que le champ Niveau est vide : rouvrez la classe et remplissez-le."
  },
  {
    etape: 8,
    titre: "Attribution des cours aux classes",
    ecran: 'Classes › ouvrir une classe › « Cours de cette classe »',
    roles: ['directeur', 'prefet'],
    quoi: "Pour chaque classe, rattacher les cours réellement enseignés, et ajuster au besoin le maximum propre à cette classe.",
    champs: [
      "Ouvrez la classe : le bloc « Cours de cette classe » apparaît sous le formulaire.",
      "La liste montre les cours déjà rattachés, avec pour chacun un sélecteur de professeur et un bouton « Retirer ».",
      "Maximum propre à cette classe : facultatif — il ne sert qu'à surcharger le maximum du catalogue pour cette classe précise.",
      "En bas du bloc, « + Ajouter un nouveau cours à cette classe » permet de créer et rattacher une branche en un geste.",
      "Une classe de primaire reçoit automatiquement le socle officiel des branches à sa création : il n'y a rien à cocher, seulement à vérifier."
    ],
    pourquoi: "C'est ce qui définit le total sur lequel chaque élève est noté. Un cours attribué mais jamais noté compte pour zéro dans la moyenne — c'est voulu.",
    avant: "Les étapes 6 et 7.",
    piege: "Attribuer un cours « au cas où » fait baisser toutes les moyennes de la classe. N'attribuez que ce qui est réellement enseigné."
  },
  {
    etape: 9,
    titre: "Personnel et rôles",
    ecran: 'Utilisateurs',
    roles: ['directeur'],
    quoi: "Créer les comptes du personnel, attribuer les rôles, puis affecter les cours aux enseignants et désigner les titulaires.",
    champs: [
      "Bouton « Ajouter » en haut de l'écran Utilisateurs.",
      "Nom, Prénom : tels qu'ils doivent apparaître sur les documents signés.",
      "Email : c'est l'identifiant de connexion. Il doit être unique dans l'école.",
      "Téléphone : sert aux notifications et à l'accès WhatsApp.",
      "Mot de passe provisoire : la personne devra le changer à sa première connexion.",
      "Rôles : Directeur, Préfet des études, Directeur de discipline, Secrétaire, Comptable, Professeur, Titulaire, Chargé des présences. Une personne n'a qu'un seul rôle, sauf deux combinaisons autorisées : Professeur + Titulaire, et Préfet + Directeur.",
      "Statut : actif ou suspendu. Un compte suspendu ne peut plus se connecter mais reste attaché à son historique.",
      "Bouton « Importer » : création en masse depuis un fichier.",
      "L'affectation des cours ne se fait PAS ici : elle se fait dans Classes › ouvrir la classe › « Cours de cette classe », en choisissant le professeur sur la ligne du cours.",
      "La désignation du titulaire ne se fait pas ici non plus : c'est le champ « Titulaire » du formulaire de la classe."
    ],
    pourquoi: "Un enseignant ne voit que les classes et les cours qui lui sont attribués. Un titulaire voit toute sa classe.",
    avant: "L'étape 8.",
    piege: "Un professeur sans cours attribué voit un écran vide et croit à une panne. Attribuez les cours dans la foulée de la création du compte — depuis la classe, pas depuis la fiche de l'utilisateur."
  },
  {
    etape: 10,
    titre: "Élèves",
    ecran: 'Élèves',
    roles: ['directeur', 'prefet', 'secretaire'],
    quoi: "Créer ou importer les élèves, les affecter à leur classe, renseigner le responsable.",
    champs: [
      "Bouton « Ajouter » pour une inscription unitaire, « Importer » pour un fichier.",
      "Matricule : laissez vide pour une génération automatique. Il doit rester unique dans l'école.",
      "Classe : l'affectation. Un élève sans classe n'apparaît ni dans les listes, ni dans les bulletins.",
      "Nom, Postnom, Prénom : les trois champs de l'état civil congolais, séparés.",
      "Sexe, Date de naissance, Lieu de naissance.",
      "Adresse de l'élève, Téléphone de l'élève.",
      "Responsable, Téléphone responsable, Email du responsable, Adresse du responsable : le téléphone sert au suivi des paiements, l'email aux messages envoyés aux parents.",
      "Statut : actif, ou sorti via le bouton « Départ de l'élève ».",
      "L'import se fait en trois temps : choix du fichier, « Correspondance des colonnes » où l'on associe chaque colonne du fichier à un champ, puis « Aperçu des cinq premières lignes » avant de valider."
    ],
    pourquoi: "Le téléphone du responsable sert aux notifications et au suivi des paiements ; son email est la seule adresse par laquelle les parents reçoivent les messages de l'école.",
    avant: "L'étape 7.",
    piege: "Le matricule doit être unique dans l'école. Un import massif sans matricules cohérents est très pénible à rattraper. Contrôlez l'aperçu des cinq premières lignes avant de valider : c'est le seul moment où l'erreur de correspondance de colonnes se voit."
  },
  {
    etape: 11,
    titre: "Règles de notation et bulletins",
    ecran: 'Paramètres (notation, mentions) puis Modèles de bulletins',
    roles: ['directeur'],
    quoi: "Fixer le seuil de promotion et les mentions, puis choisir ou téléverser le modèle de bulletin et l'activer.",
    champs: [
      "Dans Paramètres, bloc « Pédagogique » : seuil de passage, seuil de redoublement, maximum par défaut.",
      "Dans Paramètres, bloc « Mentions » : pour chaque mention, un seuil minimum, un seuil maximum et un libellé (Échec, Satisfaction, Distinction, Grande distinction…).",
      "Écran « Modèles de bulletins » : bouton « Nouveau modèle ».",
      "Nom du modèle, puis le type (période, semestre, annuel) et la variante (primaire, secondaire, terminale).",
      "Bouton « Choisir un fichier » pour téléverser un modèle existant, ou partir d'un modèle officiel fourni.",
      "« Suggérer les zones » place automatiquement les zones de texte sur le document ; chaque zone se corrige ensuite à la main (clé, position, police, taille, alignement).",
      "Bouton « Activer » : un modèle non activé ne sera jamais utilisé.",
      "L'affectation du modèle aux classes se fait ensuite dans la fiche de chaque classe."
    ],
    pourquoi: "Sans modèle actif affecté, un bulletin ne peut pas être généré.",
    avant: "L'étape 7.",
    piege: "Vérifiez le rendu d'UN bulletin réel avant de lancer une génération de masse. Un modèle créé mais jamais activé est la cause la plus fréquente de « la génération ne fait rien »."
  },
  {
    etape: 12,
    titre: "Discipline",
    ecran: 'Discipline › onglet « Paramètres »',
    roles: ['directeur'],
    quoi: "Importer le règlement intérieur ou en faire rédiger un, relire le barème proposé, le corriger, le valider, puis fixer le capital de conduite.",
    champs: [
      "Onglet « Paramètres » de l'écran Discipline.",
      "Capital de conduite / Capital par période : le nombre de points dont chaque élève dispose au début de chaque période. Bouton « Enregistrer » propre à ce champ.",
      "Bloc « Règlement » — bouton « Fichier » pour téléverser le règlement, ou la zone « …ou collez le texte du règlement ».",
      "Nom du document : comment ce règlement s'appellera dans la liste.",
      "Bouton « Analyser » : la plateforme propose un barème ligne par ligne (code, libellé, sens positif ou négatif, points, mesure, catégorie).",
      "Bouton « Générer » : rédige un règlement type quand l'école n'en a pas de formalisé.",
      "Chaque ligne du barème proposé se corrige avant validation.",
      "Bouton « Valider » : c'est LUI qui met le barème en service. Tant qu'il n'est pas cliqué, le barème n'existe pas."
    ],
    pourquoi: "Sans règlement validé, la plateforme applique un barème générique qui n'est pas celui de votre école.",
    avant: "L'étape 1.",
    piege: "Le barème proposé par l'assistant n'a AUCUNE valeur tant que vous ne l'avez pas validé. Relisez chaque ligne : ce sont des sanctions réelles pour des enfants réels."
  },
  {
    etape: 13,
    titre: "Frais scolaires",
    ecran: 'Frais scolaires › onglet « Configuration »',
    roles: ['directeur', 'comptable'],
    quoi: "Définir les frais par classe et par année, dans la devise choisie, puis décider du blocage des bulletins en cas d'impayé.",
    champs: [
      "Onglet « Configuration ».",
      "Année scolaire : les frais sont toujours rattachés à une année.",
      "Classe : laissez vide pour appliquer le montant à TOUTES les classes.",
      "Libellé : le texte qui apparaîtra sur les reçus (« Frais scolaires », « Frais d'examen »…).",
      "Montant et Devise (FC ou USD).",
      "Bouton « Ajouter » : la ligne s'ajoute au tableau de configuration.",
      "Bloc « Taux de change » : le taux appliqué aux paiements faits dans la devise secondaire, avec son bouton « Enregistrer » propre.",
      "Bloc « Contrôle » : bloquer ou non le bulletin en cas d'impayé, et la tolérance en pourcentage. Bouton « Enregistrer le contrôle ».",
      "Bouton « Dérogation » sur la fiche d'un élève : l'exempte individuellement du blocage."
    ],
    pourquoi: "C'est la base du suivi des paiements, des reçus et des relances.",
    avant: "Les étapes 1, 2 et 7.",
    piege: "Le blocage des bulletins pour impayé est une décision lourde. La dérogation individuelle existe pour les cas sociaux : utilisez-la plutôt que de désactiver le blocage pour tous."
  },
  {
    etape: 14,
    titre: "Emploi du temps et calendrier",
    ecran: 'Emploi du temps › onglet « Classe », puis Calendrier',
    roles: ['directeur', 'prefet'],
    quoi: "Placer les séances dans la grille hebdomadaire, puis déclarer les jours fériés, congés et journées particulières.",
    champs: [
      "Onglet « Classe » de l'écran Emploi du temps, puis le sélecteur « Classe ».",
      "La grille croise les jours et les heures de cours. Un clic dans une case propose les cours de la classe et leur professeur.",
      "Onglet « Horaires exceptionnels » : Jour concerné, Heure habituelle, Portée (toute l'école ou une classe), Nouvelle heure de début, Nouvelle heure de fin, Motif.",
      "Écran Calendrier : Libellé, Type (férié, congé, examen, événement), Date de début, Date de fin, Cycle concerné.",
      "L'onglet « Mon emploi du temps » montre à chaque enseignant ses propres heures."
    ],
    pourquoi: "L'emploi du temps alimente l'espace du professeur et l'appel. Les jours spéciaux évitent de compter des absences un jour sans cours.",
    avant: "Les étapes 4, 8 et 9.",
    piege: "Déclarez les fériés AVANT la rentrée : les absences déjà saisies sur un jour requalifié férié ne se corrigent pas toutes seules."
  }
];

/* ==========================================================================
   2. PROCÉDURES

   Une procédure = un geste que quelqu'un vient chercher. Elle nomme l'écran,
   énumère les clics dans l'ordre, et signale ce qui bloque.

   Les codes sont stables : `onboarding.utils.js` et le centre d'apprentissage
   y renvoient.
   ========================================================================== */

const PROCEDURES = {
  /* ---------- Vie quotidienne : enseignement ---------- */
  saisir_notes: {
    titre: 'Saisir des cotes',
    ecran: 'Notes',
    roles: ['professeur', 'titulaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Notes ».",
      "Choisir la classe, puis le cours, puis la période dans les trois sélecteurs du haut. La grille ne s'affiche qu'une fois les trois choisis.",
      "Saisir les points de chaque élève. Le maximum applicable est rappelé en haut de colonne — c'est le maximum d'examen si la période est une période d'examen.",
      "Laisser vide ce qui n'a pas été composé : zéro et vide ne veulent pas dire la même chose. Un vide est ignoré, un zéro compte.",
      "Cliquer sur « Enregistrer »."
    ],
    remarque: "Les notes restent modifiables tant qu'elles ne sont pas validées. Une fois VALIDÉES par la direction (bouton « Valider »), elles se verrouillent ; seule la direction peut les déverrouiller par « Dévalider », et l'opération est tracée dans le journal."
  },
  travaux_interrogations: {
    titre: 'Noter par interrogations et travaux',
    ecran: 'Notes › « Ajouter un travail »',
    roles: ['professeur', 'titulaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Notes » et choisir la classe, le cours et la période.",
      "Cliquer sur « Ajouter un travail » : renseigner son nom (« Interro 1 », « Devoir »), son maximum de points et son ordre.",
      "Saisir les points de chaque élève pour ce travail.",
      "Enregistrer. La cote de période se recompose à partir des travaux."
    ],
    remarque: "Les travaux sont facultatifs : un enseignant qui préfère saisir directement la cote de période peut ignorer ce bloc entièrement."
  },
  valider_notes: {
    titre: 'Valider ou dévalider les cotes',
    ecran: 'Notes',
    roles: ['directeur', 'prefet'],
    etapes: [
      "Ouvrir « Notes », choisir la classe, le cours et la période.",
      "Contrôler la grille : c'est le dernier moment où une erreur se corrige sans trace.",
      "Cliquer sur « Valider » : la grille se verrouille pour l'enseignant.",
      "Pour rouvrir, cliquer sur « Dévalider »."
    ],
    remarque: "La validation est ce qui autorise la génération des bulletins. Chaque dévalidation est enregistrée dans le journal d'activité, avec l'auteur et l'horodatage."
  },
  faire_appel: {
    titre: "Faire l'appel",
    ecran: 'Présences',
    roles: ['titulaire', 'professeur', 'charge_presences', 'directeur_discipline', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Présences ».",
      "Choisir la classe et le jour. Le jour du jour est proposé par défaut.",
      "Tout le monde est présent par défaut : ne marquer que les absents et les retardataires. Le bouton « Tous présents » remet la liste à zéro.",
      "Indiquer un motif quand il est connu — c'est ce qui distingue une absence justifiée.",
      "Cliquer sur « Enregistrer »."
    ],
    remarque: "Qui a le droit de faire l'appel dépend du réglage « Qui fait l'appel ? » dans Paramètres : le titulaire, le professeur de l'heure, ou un chargé désigné. Si l'écran Présences n'apparaît pas dans votre menu, c'est ce réglage qu'il faut regarder. Une modification postérieure demande un motif et reste tracée."
  },
  consulter_assiduite: {
    titre: "Suivre l'assiduité d'un élève ou d'une classe",
    ecran: 'Présences, puis Rapports › Assiduité',
    roles: ['titulaire', 'directeur_discipline', 'prefet', 'directeur', 'charge_presences'],
    etapes: [
      "Sur « Présences », le résumé du jour donne l'état de la classe.",
      "Pour l'historique d'un élève, ouvrir sa fiche depuis « Élèves ».",
      "Pour une vue d'ensemble, ouvrir « Rapports » puis le bloc « Assiduité »."
    ],
    remarque: "Les jours déclarés fériés dans le Calendrier sont exclus des taux : c'est pourquoi il faut les déclarer avant la rentrée."
  },

  /* ---------- Bulletins ---------- */
  generer_bulletins: {
    titre: 'Générer les bulletins de période',
    ecran: 'Bulletins',
    roles: ['directeur', 'prefet', 'titulaire', 'secretaire'],
    etapes: [
      "Vérifier que toutes les cotes de la période sont saisies et validées.",
      "Ouvrir « Bulletins », choisir la classe et la période.",
      "Cliquer sur « Générer » ; la liste des élèves se remplit avec leur total, leur pourcentage, leur rang et leur mention.",
      "Ouvrir UN bulletin (« Aperçu d'impression ») pour vérifier le rendu avant d'imprimer la classe entière.",
      "Signer : « Signer tout » pour la classe, ou la signature individuelle depuis la fiche de l'élève.",
      "Imprimer."
    ],
    remarque: "Un bulletin signé ne se modifie plus, sauf si l'école a coché « Autoriser la modification après signature » dans Paramètres. Si la génération refuse de se lancer, la cause la plus fréquente est un modèle de bulletin non activé ou non affecté à la classe."
  },
  appreciations_bulletin: {
    titre: 'Renseigner conduite, application et observation',
    ecran: 'Bulletins',
    roles: ['titulaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Bulletins », choisir la classe et la période.",
      "Cliquer sur « Appréciations » : la colonne devient saisissable pour toute la classe.",
      "Renseigner conduite, application et observation, puis « Valider les appréciations »."
    ],
    remarque: "La conduite peut être reprise automatiquement du capital de discipline restant : voir la procédure « Reporter la conduite sur les bulletins »."
  },
  bulletin_annuel: {
    titre: 'Éditer le bulletin annuel',
    ecran: 'Bulletin annuel',
    roles: ['directeur', 'prefet', 'titulaire', 'secretaire'],
    etapes: [
      "Vérifier que toutes les périodes de l'année sont saisies et validées.",
      "Ouvrir « Bulletin annuel » et choisir la classe.",
      "Générer, vérifier un exemplaire, signer, imprimer."
    ],
    remarque: "Le bulletin annuel utilise le modèle de type « annuel » affecté à la classe, distinct du modèle de période."
  },

  /* ---------- Discipline ---------- */
  signaler_discipline: {
    titre: 'Signaler un fait de discipline',
    ecran: 'Discipline › onglet « Incidents »',
    roles: ['titulaire', 'directeur_discipline', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Discipline », onglet « Incidents ».",
      "Choisir la classe, la période, puis l'élève.",
      "Choisir le type de fait : les fautes retirent des points du capital de conduite, les faits à valoriser en rendent.",
      "Les points et la mesure sont pré-remplis d'après le règlement validé de l'école ; ajustez si le contexte le justifie.",
      "Renseigner la date et une description, puis cliquer sur « Signaler »."
    ],
    remarque: "Un incident supprimé rend les points. L'historique complet d'un élève est consultable depuis sa fiche."
  },
  reporter_conduite: {
    titre: 'Reporter la conduite sur les bulletins',
    ecran: 'Discipline › onglet « Conduite »',
    roles: ['directeur_discipline', 'prefet', 'directeur'],
    etapes: [
      "En fin de période, ouvrir « Discipline », onglet « Conduite ».",
      "Choisir la classe et la période : la liste montre le capital restant de chaque élève et l'appréciation correspondante.",
      "Cliquer sur « Appliquer » : les appréciations sont écrites sur les bulletins de la période."
    ],
    remarque: "À faire AVANT la signature des bulletins : un bulletin signé ne se laisse plus modifier."
  },
  importer_reglement: {
    titre: 'Importer ou faire rédiger le règlement intérieur',
    ecran: 'Discipline › onglet « Paramètres »',
    roles: ['directeur'],
    etapes: [
      "Ouvrir « Discipline », onglet « Paramètres ».",
      "Téléverser le fichier du règlement, ou coller son texte, ou cliquer sur « Générer » pour partir d'un règlement type.",
      "Cliquer sur « Analyser » : un barème est proposé, ligne par ligne.",
      "Corriger chaque ligne : libellé, sens (positif ou négatif), points, mesure.",
      "Cliquer sur « Valider » : le barème entre en service."
    ],
    remarque: "Tant que « Valider » n'a pas été cliqué, la plateforme continue d'appliquer le barème générique."
  },

  /* ---------- Finances ---------- */
  encaisser_paiement: {
    titre: 'Encaisser un paiement et délivrer un reçu',
    ecran: 'Frais scolaires › onglet « Paiements »',
    roles: ['comptable', 'secretaire', 'directeur'],
    etapes: [
      "Ouvrir « Frais scolaires », onglet « Paiements ».",
      "Choisir la classe, puis l'élève dans la liste. Le solde dû s'affiche.",
      "Renseigner le frais réglé, le montant, la devise, la méthode et une note facultative.",
      "Enregistrer : le reçu numéroté est délivré automatiquement.",
      "Imprimer le reçu depuis la ligne du paiement."
    ],
    remarque: "Un paiement en devise secondaire est converti au taux enregistré dans les paramètres. Vérifiez que ce taux est à jour avant une journée d'encaissement. Le numéro de reçu est attribué par la plateforme : ne le recréez jamais à la main."
  },
  suivre_impayes: {
    titre: 'Suivre les impayés et les dettes antérieures',
    ecran: 'Frais scolaires › onglet « Dettes »',
    roles: ['comptable', 'directeur'],
    etapes: [
      "Ouvrir « Frais scolaires », onglet « Dettes ».",
      "La liste donne, par classe et par élève, le dû, le réglé et le solde.",
      "Les dettes des années antérieures apparaissent dans un bloc distinct de celles de l'année en cours.",
      "Pour un cas social, ouvrir la fiche de l'élève et poser une « Dérogation » avec son motif."
    ],
    remarque: "Le blocage des bulletins pour impayé se règle dans le bloc « Contrôle » du même écran, avec un pourcentage de tolérance."
  },
  mouvements_caisse: {
    titre: 'Enregistrer une dépense ou une entrée de caisse',
    ecran: 'Comptabilité',
    roles: ['comptable', 'directeur'],
    etapes: [
      "Ouvrir « Comptabilité ».",
      "Créer d'abord les catégories si elles n'existent pas : nom et sens (entrée ou sortie).",
      "Ajouter un mouvement : sens, catégorie, libellé, montant, devise, date, mode de paiement, bénéficiaire, référence, pièce justificative.",
      "Enregistrer. Le bloc « Trésorerie » se met à jour."
    ],
    remarque: "Les frais scolaires encaissés remontent automatiquement en entrée : ne les ressaisissez pas ici, vous les compteriez deux fois."
  },
  paie_personnel: {
    titre: 'Préparer et payer les salaires',
    ecran: 'Comptabilité › Contrats et Paie',
    roles: ['comptable', 'directeur'],
    etapes: [
      "Créer le contrat de chaque membre du personnel : poste, salaire de base, devise, date de début.",
      "Ouvrir le bloc « Paie » et cliquer sur « Préparer » pour le mois voulu : une ligne est créée par contrat actif.",
      "Ajuster primes et retenues ligne par ligne ; le net se recalcule.",
      "Cliquer sur « Payer » : le mouvement de caisse correspondant est créé automatiquement.",
      "« Annuler le paiement » revient en arrière et annule le mouvement."
    ],
    remarque: "Un contrat clôturé ne génère plus de ligne de paie, mais son historique reste consultable."
  },

  /* ---------- Inscriptions, orientation, promotion ---------- */
  ouvrir_concours: {
    titre: "Ouvrir un concours d'admission",
    ecran: 'Inscriptions › onglet « Sessions »',
    roles: ['directeur', 'prefet', 'secretaire'],
    etapes: [
      "Vérifier que l'ANNÉE SUIVANTE existe (Année scolaire) et que ses classes sont créées.",
      "Ouvrir « Inscriptions », onglet « Sessions », puis créer une session.",
      "Renseigner le libellé, l'année d'entrée des admis (celle où ils entreront, PAS celle du test), la promotion qui recrute, les dates d'ouverture et de clôture, le nombre de places et le mode d'admission.",
      "Cocher les classes d'accueil : le compteur indique les places RESTANTES, après la promotion interne.",
      "Déclarer les épreuves : nom, maximum, ordre, puis leur correcteur."
    ],
    remarque: "Choisir une classe de l'année en cours est refusé : un admis entrerait au milieu d'une année déjà commencée."
  },
  corriger_concours: {
    titre: "Corriger les copies d'un concours",
    ecran: 'Inscriptions › onglet « Correction »',
    roles: ['professeur', 'titulaire', 'prefet', 'directeur', 'secretaire'],
    etapes: [
      "Ouvrir « Inscriptions », onglet « Correction ».",
      "Choisir l'épreuve qui vous a été confiée : seules les vôtres apparaissent.",
      "Saisir les points de chaque candidat, puis enregistrer."
    ],
    remarque: "Un correcteur ne voit que ses épreuves. C'est le préfet ou le directeur qui les attribue depuis l'onglet Sessions."
  },
  publier_resultats_concours: {
    titre: "Publier les résultats et admettre les candidats",
    ecran: 'Inscriptions › onglet « Résultats »',
    roles: ['directeur', 'prefet'],
    etapes: [
      "Ouvrir « Inscriptions », onglet « Résultats » : les candidats sont classés par total.",
      "Prononcer les décisions : admis, en attente, refusé. Une recommandation peut être motivée.",
      "Cliquer sur « Publier » : les résultats deviennent consultables publiquement avec le numéro de candidat.",
      "Cliquer sur « Convertir » : les admis deviennent des élèves de la classe cible pour l'année d'entrée."
    ],
    remarque: "La conversion peut être automatique si l'école a activé ce réglage. Un candidat qui se désiste libère sa place."
  },
  orientation_eleves: {
    titre: "Orienter les élèves de fin de cycle",
    ecran: 'Orientation',
    roles: ['directeur', 'prefet', 'titulaire'],
    etapes: [
      "Vérifier que les classes de fin de cycle portent la case « Classe d'orientation », et que les options ont un critère.",
      "Ouvrir « Orientation » : saisir pour chaque élève son vœu et son option de repli.",
      "Cliquer sur « Répartir » : la plateforme attribue les options au mérite, dans la limite des capacités.",
      "Corriger les cas particuliers un par un, avec un motif."
    ],
    remarque: "À traiter AVANT la promotion : promouvoir d'abord ferait entrer des élèves dans des classes qui ne correspondent pas à leur option."
  },
  promouvoir: {
    titre: 'Passer les élèves à la classe supérieure',
    ecran: 'Année scolaire › onglet « Promotion »',
    roles: ['directeur'],
    etapes: [
      "Vérifier que chaque classe a un NIVEAU, une DIVISION et une CLASSE SUIVANTE, et que les classes de fin de parcours portent la case « Classe terminale ».",
      "Traiter les orientations de fin de cycle et la session de repêchage si l'école en organise une.",
      "Ouvrir « Année scolaire », onglet « Promotion », puis « Calculer l'aperçu ».",
      "Relire la liste proposée et les cas limites, corriger les décisions individuelles.",
      "Cliquer sur « Exécuter la promotion », puis clôturer l'année."
    ],
    remarque: "La promotion s'appuie sur les seuils de passage et de redoublement définis dans Paramètres. Le message « niveau manquant » sur l'écran Classes signale exactement ce qui l'empêchera de s'exécuter."
  },
  reporter_structure: {
    titre: "Reporter la structure vers une nouvelle année",
    ecran: 'Année scolaire › onglet « Promotion » › Étape 1',
    roles: ['directeur', 'prefet'],
    etapes: [
      "Créer l'année suivante dans l'onglet « Années ».",
      "Onglet « Promotion », Étape 1 : choisir l'année source et l'année cible.",
      "Cliquer sur « Reporter la structure » : classes, cours et attributions sont recopiés dans la nouvelle année.",
      "Relire le bilan du report avant de passer à l'étape 2."
    ],
    remarque: "Le report copie la structure, pas les élèves : ce sont la promotion et les inscriptions qui les placent."
  },
  repechage: {
    titre: 'Organiser une session de repêchage',
    ecran: 'Repêchage',
    roles: ['directeur', 'prefet'],
    etapes: [
      "Ouvrir « Repêchage » et créer une session : libellé, dates, seuil d'échec par cours, nombre maximum de cours repêchables, moyenne minimale et maximale d'éligibilité, politique de note (plafonnée, remplacement ou moyenne).",
      "Consulter la liste des élèves éligibles ; retirer ceux qui ne doivent pas composer, avec un motif.",
      "Cliquer sur « Ouvrir la session ».",
      "Saisir les points de repêchage cours par cours.",
      "Cliquer sur « Clôturer » : les décisions sont prononcées et les moyennes recalculées."
    ],
    remarque: "La politique de note décide de ce qui est retenu : plafonnée au seuil de réussite, remplacement pur, ou moyenne des deux tentatives. Elle se choisit à la création de la session et ne se change plus ensuite."
  },
  cloturer_periode: {
    titre: 'Clôturer une période',
    ecran: 'Année scolaire › « Clôturer la période »',
    roles: ['directeur', 'prefet'],
    etapes: [
      "Ouvrir « Année scolaire » et lancer la clôture de la période concernée.",
      "Lire l'état de clôture : il liste les cotes manquantes et les grilles non validées, classe par classe et cours par cours.",
      "Relancer les enseignants en retard depuis le bouton « Relancer » — un message nominatif leur est envoyé.",
      "Confirmer la clôture, en levant explicitement les réserves qui subsistent."
    ],
    remarque: "Une période clôturée n'accepte plus de saisie. « Rouvrir » existe et reste tracé dans le journal d'activité."
  },
  cloturer_annee: {
    titre: "Clôturer l'année scolaire",
    ecran: 'Année scolaire › onglet « Années »',
    roles: ['directeur'],
    etapes: [
      "Terminer les bulletins annuels, le repêchage et la promotion.",
      "Ouvrir « Année scolaire », onglet « Années ».",
      "Cliquer sur « Clôturer » sur la ligne de l'année.",
      "Activer la nouvelle année."
    ],
    remarque: "Clôturer n'efface rien : l'année reste consultable et imprimable depuis « Archives »."
  },

  /* ---------- Élèves ---------- */
  inscrire_eleve: {
    titre: 'Inscrire un élève',
    ecran: 'Élèves › « Ajouter »',
    roles: ['secretaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Élèves » et cliquer sur « Ajouter ».",
      "Laisser le matricule vide pour une génération automatique.",
      "Renseigner la classe, le nom, le postnom, le prénom, le sexe, la date et le lieu de naissance.",
      "Renseigner le responsable, son téléphone, son email et son adresse.",
      "Enregistrer."
    ],
    remarque: "L'email du responsable est la seule adresse par laquelle les parents recevront les messages de l'école. Le laisser vide, c'est renoncer à les joindre."
  },
  importer_eleves: {
    titre: 'Importer une liste d\'élèves',
    ecran: 'Élèves › « Importer »',
    roles: ['secretaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Élèves » et cliquer sur « Importer ».",
      "Choisir le fichier.",
      "Écran « Correspondance des colonnes » : associer chaque colonne du fichier au champ correspondant.",
      "Contrôler l'« Aperçu des cinq premières lignes ».",
      "Valider l'import."
    ],
    remarque: "L'aperçu est le seul moment où une erreur de correspondance se voit. Un import massif de matricules incohérents est très pénible à rattraper."
  },
  sortie_eleve: {
    titre: "Enregistrer le départ d'un élève",
    ecran: 'Élèves › fiche de l\'élève › « Départ de l\'élève »',
    roles: ['secretaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir la fiche de l'élève depuis « Élèves ».",
      "Cliquer sur « Départ de l'élève ».",
      "Choisir le motif : diplômé, échec répété, départ volontaire, transfert, exclusion, abandon, sans notes, autre.",
      "Renseigner la date du départ et une précision facultative, puis confirmer."
    ],
    remarque: "Un élève sorti disparaît des listes de classe mais conserve tout son historique, consultable dans les archives et dans son parcours."
  },
  parcours_eleve: {
    titre: "Consulter le parcours complet d'un élève",
    ecran: 'Élèves › fiche de l\'élève',
    roles: ['secretaire', 'titulaire', 'prefet', 'directeur'],
    etapes: [
      "Ouvrir « Élèves » et cliquer sur le nom de l'élève.",
      "La fiche donne l'identité, la classe, les résultats de l'année et l'historique des années précédentes.",
      "Le bloc « Historique scolaire » retrace les classes successives et les décisions de fin d'année."
    ],
    remarque: "Les années clôturées restent lisibles ici, sans avoir à passer par les archives."
  },

  /* ---------- Communication ---------- */
  ecrire_collegue: {
    titre: 'Écrire à un collègue',
    ecran: 'Messages › « Écrire à un collègue »',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'directeur_discipline', 'charge_presences'],
    etapes: [
      "Ouvrir « Messages » et choisir l'onglet d'envoi.",
      "Dans « Envoyer à », laisser « Une ou plusieurs personnes ».",
      "Rechercher la personne par son nom, puis cocher son nom dans la liste. Plusieurs personnes peuvent être cochées.",
      "Renseigner l'objet et le contenu, choisir le canal (message interne, courriel, ou les deux).",
      "Cliquer sur « Envoyer »."
    ],
    remarque: "Écrire à une personne précise est ouvert à tout le personnel. C'est la DIFFUSION à un groupe entier — un rôle, une classe, tous les parents — qui reste réservée à la direction et au secrétariat."
  },
  diffuser_message: {
    titre: 'Diffuser un message à un groupe',
    ecran: 'Messages › « Nouveau message »',
    roles: ['directeur', 'prefet', 'secretaire'],
    etapes: [
      "Ouvrir « Messages », onglet « Nouveau message ».",
      "Dans « Envoyer à », choisir : des rôles, l'équipe pédagogique d'une classe, les parents d'une classe, ou les parents de toute l'école.",
      "Le nombre exact de destinataires touchés s'affiche sous la sélection.",
      "Renseigner l'objet et le contenu, choisir les canaux.",
      "Envoyer. L'onglet « Envois » conserve la trace de chaque diffusion."
    ],
    remarque: "Les parents n'ont pas de compte : seul le courriel les atteint, et seulement si l'adresse du responsable est renseignée sur la fiche de l'élève."
  },
  ecrire_parents_classe: {
    titre: "Écrire aux parents de sa classe",
    ecran: 'Messages › « Les parents d\'une classe »',
    roles: ['titulaire', 'professeur', 'directeur', 'prefet', 'secretaire'],
    etapes: [
      "Ouvrir « Messages » et choisir l'onglet d'envoi.",
      "Dans « Envoyer à », choisir « Les parents d'une classe ».",
      "Choisir la classe : un titulaire ne voit que ses classes, un professeur que celles où il enseigne.",
      "Renseigner l'objet et le contenu. Le canal bascule automatiquement sur le courriel.",
      "Envoyer."
    ],
    remarque: "Un enseignant peut écrire aux parents des classes dont il a la charge, mais pas aux parents de toute l'école : cette diffusion-là engage l'établissement et reste à la direction."
  },

  /* ---------- Pilotage ---------- */
  lire_rapports: {
    titre: 'Lire les rapports et exporter',
    ecran: 'Rapports',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable'],
    etapes: [
      "Ouvrir « Rapports ».",
      "Choisir le bloc voulu : effectifs, réussite, palmarès, moyennes, portées, finances, assiduité.",
      "Le bouton « Exporter » en haut à droite du bloc produit le fichier."
    ],
    remarque: "Les chiffres portent sur l'année ACTIVE. Pour une année clôturée, passez par « Archives »."
  },
  consulter_journal: {
    titre: "Consulter le journal d'activité",
    ecran: "Journal d'activité",
    roles: ['directeur', 'prefet'],
    etapes: [
      "Ouvrir « Journal d'activité ».",
      "Filtrer par utilisateur, par type d'action ou par période.",
      "Chaque ligne dit qui a fait quoi, sur quoi, et quand."
    ],
    remarque: "C'est l'écran à ouvrir le jour où une note change sans explication : les validations, dévalidations et réouvertures y sont toutes tracées."
  },
  consulter_archives: {
    titre: 'Consulter et imprimer une année clôturée',
    ecran: 'Archives',
    roles: ['directeur', 'prefet', 'secretaire'],
    etapes: [
      "Ouvrir « Archives » et choisir l'année.",
      "Descendre à la classe, puis à l'élève.",
      "Les bulletins et documents de l'époque se réimpriment tels qu'ils étaient.",
      "L'export d'une année ou d'une classe entière est proposé en haut de l'écran."
    ],
    remarque: "Une année clôturée n'est jamais supprimée : elle change simplement d'écran."
  },
  site_public: {
    titre: 'Publier une annonce sur le site public',
    ecran: 'Site public',
    roles: ['directeur', 'secretaire'],
    etapes: [
      "Ouvrir « Site public » et activer le site dans les paramètres si ce n'est pas déjà fait.",
      "Renseigner la description et le message d'accueil de l'établissement.",
      "Créer une annonce : titre, contenu, puis la publier.",
      "Le bloc « Codes d'accès » génère les codes qui permettent aux familles de consulter les résultats publiés."
    ],
    remarque: "Seuls les résultats explicitement publiés sont visibles publiquement : rien ne sort par défaut."
  },

  /* ---------- Compte personnel ---------- */
  mon_profil: {
    titre: 'Compléter mon profil et changer mon mot de passe',
    ecran: 'Mon profil',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'directeur_discipline', 'charge_presences'],
    etapes: [
      "Ouvrir « Mon profil ».",
      "Cliquer sur « Modifier » pour déverrouiller les champs.",
      "Renseigner nom, prénom, téléphone, et changer la photo si besoin.",
      "Enregistrer.",
      "Le bloc « Mot de passe » plus bas permet de le changer ; il demande l'ancien."
    ],
    remarque: "Le nom et le prénom apparaissent sur les documents que vous signez : un compte incomplet produit des bulletins signés par personne."
  },
  organiser_menu: {
    titre: 'Organiser mon menu',
    ecran: 'Mon profil',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'directeur_discipline', 'charge_presences'],
    etapes: [
      "Ouvrir « Mon profil ».",
      "Le bloc des menus permet d'épingler les écrans utilisés tous les jours.",
      "Le bouton « Tous les menus » réaffiche la liste complète."
    ],
    remarque: "Un écran absent de votre menu peut être simplement rangé, et non interdit : vérifiez ici avant de conclure à un problème de droits."
  }
};

/* ==========================================================================
   3. MANUELS DE RÔLE

   POURQUOI CE BLOC EXISTE
   -----------------------
   Le manuel se construisait par filtrage : on gardait les étapes et les
   procédures dont la liste `roles` mentionnait le rôle demandé. Un rôle absent
   de toutes ces listes recevait donc un manuel VIDE, sans que rien ne le
   signale. C'était le cas du Chargé des présences : le rôle existe en base,
   il a son parcours d'onboarding, ses droits sur l'écran Présences — mais
   aucune procédure ne le mentionnait, et il n'apparaissait ni dans les
   libellés ni dans les périmètres. Son manuel affichait le code brut
   « charge_presences » suivi de rien.

   Le tableau ci-dessous donne à chaque rôle, y compris ceux qui ne configurent
   rien, un manuel qui tient debout tout seul : ce qu'il fait, ce qu'il ne peut
   pas faire, ses écrans, et par quoi commencer.
   ========================================================================== */

const MANUELS_ROLE = {
  directeur: {
    libelle: "Directeur / Chef d'établissement",
    perimetre: "Accès complet : configuration de l'établissement, structure pédagogique, utilisateurs, notes, bulletins, discipline, finances, rapports, promotion et clôture.",
    ne_peut_pas: "Rien au sein de son école. L'administration de la plateforme elle-même (abonnements, autres écoles) relève du Super Administrateur.",
    ecrans: ['Tableau de bord', 'Paramètres', 'Année scolaire', 'Classes', 'Cours', 'Utilisateurs',
             'Élèves', 'Notes', 'Bulletins', 'Bulletin annuel', 'Discipline', 'Frais scolaires',
             'Comptabilité', 'Emploi du temps', 'Calendrier', 'Inscriptions', 'Orientation',
             'Repêchage', 'Modèles de bulletins', 'Rapports', 'Archives', "Journal d'activité",
             'Site public', 'Messages'],
    premiers_pas: [
      "Compléter votre profil : votre nom signe les bulletins.",
      "Remplir Paramètres — identité, type d'enseignement, devise.",
      "Créer et ACTIVER l'année scolaire, puis ses périodes.",
      "Créer les classes avec leur niveau et leur division.",
      "Créer les comptes du personnel, puis attribuer les cours depuis chaque classe.",
      "Inscrire ou importer les élèves."
    ],
    procedures: ['promouvoir', 'cloturer_periode', 'cloturer_annee', 'valider_notes',
                 'generer_bulletins', 'lire_rapports', 'consulter_journal', 'diffuser_message']
  },
  prefet: {
    libelle: 'Préfet des études',
    perimetre: "Pédagogie et structure : années et périodes, classes, cours, attribution des enseignants, notes et validation, bulletins, emploi du temps, discipline, orientation, repêchage, rapports.",
    ne_peut_pas: "Créer des comptes utilisateurs, toucher aux finances, modifier les paramètres généraux de l'établissement.",
    ecrans: ['Tableau de bord', 'Année scolaire', 'Classes', 'Cours', 'Élèves', 'Notes',
             'Bulletins', 'Discipline', 'Emploi du temps', 'Calendrier', 'Inscriptions',
             'Orientation', 'Repêchage', 'Rapports', "Journal d'activité", 'Messages'],
    premiers_pas: [
      "Compléter votre profil.",
      "Vérifier que l'année active a bien toutes ses périodes, avec leurs dates.",
      "Vérifier que chaque classe a un niveau, une division et une classe suivante.",
      "Vérifier que chaque cours a un maximum ordinaire et un maximum d'examen.",
      "Contrôler que chaque enseignant a bien ses cours attribués."
    ],
    procedures: ['valider_notes', 'cloturer_periode', 'generer_bulletins', 'orientation_eleves',
                 'repechage', 'lire_rapports', 'reporter_structure']
  },
  directeur_discipline: {
    libelle: 'Directeur de discipline',
    perimetre: "Discipline et assiduité : signalement des faits, suivi du capital de conduite par classe, historique disciplinaire des élèves, report de la conduite sur les bulletins, consultation des présences.",
    ne_peut_pas: "Fixer le capital de conduite ni valider le règlement — ce sont des décisions du directeur. Ne saisit pas de cotes et n'accède pas aux finances.",
    ecrans: ['Discipline', 'Présences', 'Élèves (consultation)', 'Calendrier', 'Messages'],
    premiers_pas: [
      "Compléter votre profil.",
      "Ouvrir Discipline et vérifier que le barème de l'école est bien celui qui s'applique.",
      "Prendre l'habitude de l'onglet Conduite en fin de période, avant la signature des bulletins."
    ],
    procedures: ['signaler_discipline', 'reporter_conduite', 'consulter_assiduite', 'ecrire_collegue']
  },
  secretaire: {
    libelle: 'Secrétaire',
    perimetre: "Élèves et dossiers : inscriptions, import, fiches, départs, concours d'admission, consultation des résultats publiés, archives, diffusion de messages. Encaissement selon l'organisation de l'école.",
    ne_peut_pas: "Saisir ou valider des cotes, modifier la structure pédagogique, créer des comptes utilisateurs.",
    ecrans: ['Accueil Secrétariat', 'Élèves', 'Inscriptions', 'Frais scolaires', 'Bulletins',
             'Archives', 'Calendrier', 'Site public', 'Messages'],
    premiers_pas: [
      "Compléter votre profil.",
      "Ouvrir Accueil Secrétariat : les tâches du jour y sont regroupées.",
      "Vérifier que les fiches élèves portent bien l'email du responsable — sans lui, les parents ne reçoivent rien."
    ],
    procedures: ['inscrire_eleve', 'importer_eleves', 'sortie_eleve', 'ouvrir_concours',
                 'publier_resultats_concours', 'encaisser_paiement', 'consulter_archives',
                 'diffuser_message']
  },
  comptable: {
    libelle: 'Comptable',
    perimetre: "Finances : configuration des frais, encaissements, reçus numérotés, suivi des impayés et des dettes antérieures, caisse et charges, contrats et paie, rapports financiers.",
    ne_peut_pas: "Accéder aux notes, aux bulletins et à la discipline. Ne modifie pas la structure pédagogique.",
    ecrans: ['Frais scolaires', 'Comptabilité', 'Rapports (bloc finances)', 'Messages'],
    premiers_pas: [
      "Compléter votre profil.",
      "Vérifier le taux de change du jour avant toute journée d'encaissement.",
      "Vérifier que les frais de l'année en cours sont configurés pour chaque classe.",
      "Créer les catégories de caisse (entrées et sorties) avant le premier mouvement."
    ],
    procedures: ['encaisser_paiement', 'suivre_impayes', 'mouvements_caisse', 'paie_personnel',
                 'lire_rapports']
  },
  titulaire: {
    libelle: 'Titulaire de classe',
    perimetre: "Sa ou ses classes : cotes de ses propres cours, état de saisie de toutes les branches de la classe, appel, discipline, vœux d'orientation, appréciations, et bulletins si l'école l'autorise.",
    ne_peut_pas: "Valider les cotes d'un collègue, modifier la structure de l'école, accéder aux finances. La génération des bulletins dépend d'un réglage de l'école, et peut être limitée à certains titulaires.",
    ecrans: ['Ma classe', 'Cours de la classe', 'Notes', 'Présences', 'Bulletins', 'Discipline',
             'Emploi du temps', 'Orientation', 'Messages'],
    premiers_pas: [
      "Compléter votre profil : votre nom apparaît sur les bulletins de votre classe.",
      "Ouvrir « Ma classe » pour vérifier l'effectif.",
      "Ouvrir « Cours de la classe » : cet écran dit quelle branche a rendu ses cotes et laquelle non.",
      "Faire l'appel du jour."
    ],
    procedures: ['saisir_notes', 'faire_appel', 'signaler_discipline', 'appreciations_bulletin',
                 'generer_bulletins', 'ecrire_parents_classe', 'ecrire_collegue']
  },
  professeur: {
    libelle: 'Enseignant',
    perimetre: "Ses cours dans les classes qui lui sont attribuées : saisie des cotes, travaux et interrogations, appel de ses heures, consultation de son emploi du temps, correction des épreuves de concours qui lui sont confiées.",
    ne_peut_pas: "Voir les cotes d'un collègue, valider ses propres cotes, générer des bulletins, accéder aux finances ni à la structure.",
    ecrans: ['Mes cours', 'Notes', 'Présences', 'Emploi du temps', 'Messages'],
    premiers_pas: [
      "Compléter votre profil.",
      "Ouvrir « Mes cours » : c'est la liste de ce qui vous est attribué. Si elle est vide, la direction n'a pas encore fait l'attribution — signalez-le, ce n'est pas une panne.",
      "Ouvrir « Mon emploi du temps ».",
      "Saisir vos premières cotes depuis « Notes »."
    ],
    procedures: ['saisir_notes', 'travaux_interrogations', 'faire_appel', 'corriger_concours',
                 'ecrire_parents_classe', 'ecrire_collegue', 'mon_profil']
  },
  charge_presences: {
    libelle: 'Chargé des présences',
    perimetre: "L'appel, pour toutes les classes de l'établissement. C'est un rôle d'exécution quotidienne : relever les absences et les retards, indiquer les motifs, et consulter le résumé du jour ainsi que les statistiques d'assiduité.",
    ne_peut_pas: "Saisir ou consulter des cotes, générer des bulletins, signaler un fait de discipline, accéder aux finances, aux élèves en modification ou à la structure. Ce rôle ne configure rien.",
    ecrans: ['Présences', 'Calendrier (consultation)', 'Messages', 'Mon profil'],
    premiers_pas: [
      "Compléter votre profil.",
      "Ouvrir « Présences » : si l'écran n'apparaît pas dans votre menu, c'est que l'école n'a pas choisi le mode « un chargé désigné » dans Paramètres › Qui fait l'appel ? Signalez-le à la direction.",
      "Faire l'appel de la première classe : tout le monde est présent par défaut, vous ne marquez que les absents et les retardataires.",
      "Prendre l'habitude d'indiquer un motif : c'est ce qui distingue une absence justifiée d'une absence sèche, et c'est cette distinction qui compte au bulletin."
    ],
    procedures: ['faire_appel', 'consulter_assiduite', 'ecrire_collegue', 'mon_profil',
                 'organiser_menu']
  },
  parent: {
    libelle: 'Parent / Responsable',
    perimetre: "Consultation de la scolarité de son enfant : résultats publiés, messages de l'école, situation des paiements.",
    ne_peut_pas: "Saisir quoi que ce soit. Les parents n'ont pas de compte de travail sur la plateforme : ils sont joints par courriel et par le site public de l'école, avec le code d'accès qu'elle leur communique.",
    ecrans: ["Site public de l'école", 'Messages reçus par courriel'],
    premiers_pas: [
      "Demander à l'école son code d'accès aux résultats.",
      "Vérifier auprès du secrétariat que votre adresse électronique est bien enregistrée sur la fiche de votre enfant."
    ],
    procedures: []
  },
  eleve: {
    libelle: 'Élève',
    perimetre: "Consultation de ses propres résultats publiés.",
    ne_peut_pas: "Saisir quoi que ce soit sur la plateforme.",
    ecrans: ["Site public de l'école"],
    premiers_pas: [
      "Demander à l'école le code d'accès aux résultats publiés."
    ],
    procedures: []
  },
  super_admin: {
    libelle: 'Administrateur de la plateforme',
    perimetre: "Administration de la plateforme : écoles, abonnements, plans, supervision technique, support.",
    ne_peut_pas: "Il n'appartient à aucune école et n'a pas de parcours de configuration d'établissement.",
    ecrans: ['Super Admin'],
    premiers_pas: [],
    procedures: []
  }
};

/** Ce que chaque rôle peut faire — dérivé des manuels, pour ne pas l'écrire deux fois. */
const LIBELLES_ROLE = Object.keys(MANUELS_ROLE).reduce((acc, code) => {
  acc[code] = MANUELS_ROLE[code].libelle;
  return acc;
}, {});

const PERIMETRE_ROLE = Object.keys(MANUELS_ROLE).reduce((acc, code) => {
  acc[code] = MANUELS_ROLE[code].perimetre;
  return acc;
}, {});

/* ==========================================================================
   4. LEXIQUE
   ========================================================================== */

const LEXIQUE = {
  'capital de conduite': "Points dont chaque élève dispose au début d'une période. Les fautes en retirent, les faits à valoriser en rendent. Le solde devient l'appréciation de conduite du bulletin.",
  'période': "Unité de temps à laquelle une note se rattache : trimestre, semestre, période de travail ou examen.",
  "période d'examen": "Période dont le type est « Examen ». Sur ce type de période, c'est le maximum d'EXAMEN du cours qui sert de dénominateur, pas son maximum ordinaire.",
  'vacation': "Demi-journée de fonctionnement d'une école qui accueille deux groupes d'élèves (matin / après-midi).",
  'créneau': "Une heure de cours de la journée : un libellé, une heure de début, une heure de fin. Les créneaux forment la grille de l'emploi du temps et de l'appel.",
  'horaire exceptionnel': "Modification ponctuelle d'un créneau pour un jour donné, éventuellement limitée à une classe. C'est la bonne façon de gérer un mercredi écourté — pas une seconde grille.",
  'titulaire': "Enseignant responsable d'une classe entière, au-delà de ses propres cours.",
  'chargé des présences': "Membre du personnel désigné pour faire l'appel dans toutes les classes. Son écran n'apparaît que si l'école a choisi le mode « un chargé désigné » dans Paramètres › Qui fait l'appel ?",
  "maximum d'examen": "Total de points d'un cours lors d'une période d'examen. Distinct du maximum ordinaire. Vide, il vaut par défaut le double du maximum de période.",
  'niveau': "Rang de l'année d'études dans le cycle, de 1 à 8. C'est ce nombre qui permet à la promotion de savoir quelle classe vient après. Il se saisit dans le formulaire de la classe, écran Classes.",
  'division': "Lettre qui distingue deux classes parallèles de même niveau et même option (A, B, C).",
  'classe terminale': "Classe où les élèves achèvent leur parcours et sortent diplômés. Sans ce réglage, la promotion cherche une classe supérieure qui n'existe pas.",
  "classe d'orientation": "Classe de fin de cycle depuis laquelle les élèves sont orientés vers une option.",
  'classe suivante': "Classe dans laquelle passent les élèves qui réussissent. C'est ce lien que suit la promotion de fin d'année.",
  'seuil de promotion': "Pourcentage minimum pour passer en classe supérieure.",
  'seuil de redoublement': "Pourcentage en dessous duquel l'élève redouble sans repêchage possible. Entre ce seuil et celui de promotion se trouve la zone de repêchage.",
  'repêchage': "Session de rattrapage organisée après les examens, pour les élèves dont la moyenne se situe dans la zone définie par l'école.",
  "année d'entrée": "Année scolaire pendant laquelle les candidats admis à un concours entreront réellement. Distincte de l'année pendant laquelle le concours est organisé : on recrute pour la rentrée suivante.",
  'places restantes': "Capacité d'une classe moins les élèves déjà inscrits. Pour un concours, ce sont les élèves que la promotion interne y a fait monter : les candidats extérieurs se placent après eux.",
  'dérogation financière': "Exemption accordée à un élève, qui l'exclut du blocage de bulletin pour impayé.",
  'report de structure': "Recopie des classes, des cours et des attributions d'une année vers la suivante. Il ne déplace aucun élève.",
  'clôture de période': "Verrouillage d'une période : plus aucune cote ne peut y être saisie. Réversible par « Rouvrir », qui reste tracé.",
  'validation des cotes': "Geste de la direction qui verrouille une grille de notes et autorise la génération des bulletins."
};

module.exports = {
  ORDRE_CONFIGURATION,
  PROCEDURES,
  LEXIQUE,
  MANUELS_ROLE,
  LIBELLES_ROLE,
  PERIMETRE_ROLE
};
