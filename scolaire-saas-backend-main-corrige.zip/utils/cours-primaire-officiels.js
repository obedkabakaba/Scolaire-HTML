/**
 * Socle officiel des branches du primaire — degré élémentaire, RDC.
 *
 * Au primaire, le programme est national : de la 1ʳᵉ à la 6ᵉ année, ce sont les
 * mêmes branches, avec les mêmes maxima. Contrairement au secondaire où chaque
 * option a sa grille, il n'y a rien à inventer école par école — d'où ce socle
 * appliqué automatiquement à la création d'une classe de primaire.
 *
 * VÉRIFICATION DES MAXIMA : la somme des maxima de ce socle vaut exactement
 * 300, ce qui correspond à la ligne « Maxima généraux » relevée sur le bulletin
 * officiel fourni par l'école. Le test unitaire en fin de fichier le contrôle à
 * chaque démarrage — une modification de la liste qui casserait ce total serait
 * signalée immédiatement plutôt que découverte sur un bulletin imprimé.
 *
 * RIEN N'EST FIGÉ : ces cours sont créés comme des cours ordinaires de l'école.
 * Le directeur peut ensuite en ajouter, en retirer, renommer, changer un
 * maximum — exactement comme pour n'importe quel cours qu'il aurait créé
 * lui-même. Le socle n'est qu'un point de départ, pas une contrainte.
 */

const DOMAINE_LANGUES = 'DOMAINE DES LANGUES';
const DOMAINE_MATHS = 'DOMAINE DES MATHÉMATIQUES, SCIENCES ET TECHNOLOGIE';
const DOMAINE_UNIVERS = "DOMAINE DE L'UNIVERS SOCIAL ET ENVIRONNEMENT";
const DOMAINE_ARTS = 'DOMAINE DES ARTS';
const DOMAINE_PERSONNEL = 'DOMAINE DU DÉVELOPPEMENT PERSONNEL';

const COURS_PRIMAIRE_OFFICIELS = [
  // ---- Domaine des langues : deux groupes, chacun avec son sous-total ----
  { nom: 'Écriture',            maximum: 10, domaine: DOMAINE_LANGUES, groupe: 'LANGUES CONGOLAISES' },
  { nom: 'Lecture',             maximum: 10, domaine: DOMAINE_LANGUES, groupe: 'LANGUES CONGOLAISES' },
  { nom: 'Expression orale',    maximum: 20, domaine: DOMAINE_LANGUES, groupe: 'LANGUES CONGOLAISES' },
  { nom: 'Expression écrite',   maximum: 20, domaine: DOMAINE_LANGUES, groupe: 'LANGUES CONGOLAISES' },

  { nom: 'Vocabulaire',              maximum: 10, domaine: DOMAINE_LANGUES, groupe: 'FRANÇAIS' },
  { nom: 'Écriture & lecture',       maximum: 10, domaine: DOMAINE_LANGUES, groupe: 'FRANÇAIS' },
  { nom: 'Expression orale (fr.)',   maximum: 20, domaine: DOMAINE_LANGUES, groupe: 'FRANÇAIS' },
  { nom: 'Expression écrite (fr.)',  maximum: 20, domaine: DOMAINE_LANGUES, groupe: 'FRANÇAIS' },

  // ---- Mathématiques, sciences et technologie ----
  { nom: 'Formes géométriques',    maximum: 10, domaine: DOMAINE_MATHS, groupe: null },
  { nom: 'Mesures des grandeurs',  maximum: 10, domaine: DOMAINE_MATHS, groupe: null },
  { nom: 'Problèmes',              maximum: 10, domaine: DOMAINE_MATHS, groupe: null },
  { nom: 'Technologie',            maximum: 10, domaine: DOMAINE_MATHS, groupe: null },
  { nom: 'Numération',             maximum: 20, domaine: DOMAINE_MATHS, groupe: null },
  { nom: 'Opérations',             maximum: 20, domaine: DOMAINE_MATHS, groupe: null },
  { nom: "Sciences d'éveil",       maximum: 20, domaine: DOMAINE_MATHS, groupe: null },

  // ---- Univers social et environnement ----
  { nom: 'Éducation à la vie',              maximum: 10, domaine: DOMAINE_UNIVERS, groupe: null },
  { nom: 'Éducation civique & morale',      maximum: 10, domaine: DOMAINE_UNIVERS, groupe: null },
  { nom: 'Éducation à la santé & environnement', maximum: 10, domaine: DOMAINE_UNIVERS, groupe: null },

  // ---- Arts ----
  { nom: 'Art plastique',   maximum: 10, domaine: DOMAINE_ARTS, groupe: null },
  { nom: 'Art dramatique',  maximum: 10, domaine: DOMAINE_ARTS, groupe: null },

  // ---- Développement personnel ----
  { nom: 'Éducation physique & sportive',   maximum: 10, domaine: DOMAINE_PERSONNEL, groupe: null },
  { nom: 'Initiation au travail productif', maximum: 10, domaine: DOMAINE_PERSONNEL, groupe: null },
  { nom: 'Religion',                        maximum: 10, domaine: DOMAINE_PERSONNEL, groupe: null },
];

/** Total des maxima du socle — doit valoir 300 (ligne « Maxima généraux »). */
const TOTAL_MAXIMA_ATTENDU = 300;

const totalReel = COURS_PRIMAIRE_OFFICIELS.reduce((t, c) => t + c.maximum, 0);
if (totalReel !== TOTAL_MAXIMA_ATTENDU) {
  // Erreur au chargement du module, volontairement bruyante : un socle dont la
  // somme ne tombe plus juste produirait des pourcentages faux sur TOUS les
  // bulletins du primaire, ce qui ne se remarquerait qu'après impression.
  throw new Error(
    `Socle du primaire incohérent : la somme des maxima vaut ${totalReel} au lieu de ${TOTAL_MAXIMA_ATTENDU}. ` +
    `Vérifiez la liste des branches — ce total correspond à la ligne « Maxima généraux » du bulletin officiel.`
  );
}

module.exports = {
  COURS_PRIMAIRE_OFFICIELS,
  TOTAL_MAXIMA_ATTENDU,
  DOMAINES: {
    LANGUES: DOMAINE_LANGUES,
    MATHS: DOMAINE_MATHS,
    UNIVERS: DOMAINE_UNIVERS,
    ARTS: DOMAINE_ARTS,
    PERSONNEL: DOMAINE_PERSONNEL,
  },
};
