/*
 * ===========================================================================
 *  FILTRE DE CYCLE — primaire / secondaire / les deux
 * ===========================================================================
 *
 * POURQUOI CE FILTRE EST CÔTÉ SERVEUR
 * -----------------------------------
 * Dans une école qui tient le primaire ET les humanités, chaque écran mélange
 * deux mondes qui n'ont ni le même programme, ni le même découpage de l'année,
 * ni les mêmes bulletins. Filtrer dans le navigateur ne suffirait pas : il
 * resterait toujours une liste déroulante remplie avant l'application du
 * filtre, et l'utilisateur qui a choisi « primaire » y verrait passer une
 * classe de 4e humanités. La règle est donc appliquée à la source : ce qui ne
 * relève pas du cycle demandé n'est jamais envoyé.
 *
 * COMMENT L'UTILISER
 * ------------------
 *   const cycle = cycleDemande(req);          // 'primaire' | 'secondaire' | null
 *   if (cycle) { params.push(cycle); conditions.push(conditionCycle('c', params.length)); }
 *
 * `null` veut dire « les deux » : aucune condition n'est ajoutée. C'est aussi
 * ce que renvoie un paramètre absent ou inconnu — un filtre qu'on ne comprend
 * pas ne doit jamais masquer des données en silence.
 *
 * LA TOLÉRANCE AU CYCLE NULL
 * --------------------------
 * `cycle IS NULL` est toujours accepté. Les lignes créées avant la migration
 * 003, ou dans une école mono-cycle où la colonne ne servait à rien, n'ont pas
 * de cycle renseigné. Les exclure ferait disparaître des classes et des
 * périodes bien réelles, que l'école ne pourrait plus corriger puisqu'elle ne
 * les verrait plus. Mieux vaut en montrer une de trop qu'en cacher une.
 */

const CYCLES = ['primaire', 'secondaire'];

/** Cycle demandé par l'appelant, ou null si le filtre ne s'applique pas. */
function cycleDemande(req) {
  const brut = String((req.query && req.query.cycle) || '').trim().toLowerCase();
  // 'les_deux' et 'tous' sont les valeurs que l'écran envoie pour dire
  // « ne filtre pas » : elles sont volontairement traitées comme l'absence.
  return CYCLES.includes(brut) ? brut : null;
}

/**
 * Condition SQL sur une table portant une colonne `cycle`
 * (`classes`, `periodes`).
 */
function conditionCycle(alias, indexParam) {
  return `(${alias}.cycle IS NULL OR ${alias}.cycle::text = $${indexParam})`;
}

module.exports = { CYCLES, cycleDemande, conditionCycle };
