const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Les deux seules devises en circulation dans les écoles de RDC. La liste est
 * volontairement fermée (et la même contrainte existe en base) : accepter une
 * devise libre rendrait tout calcul de solde impossible dès qu'une faute de
 * frappe passerait — « USd », « $ », « FC ». mélangés dans la même colonne.
 */
const DEVISES = ['FC', 'USD'];
const DEVISE_PAR_DEFAUT = 'FC';

/** Normalise et valide une devise reçue du client. */
function normaliserDevise(valeur, { defaut = DEVISE_PAR_DEFAUT } = {}) {
  if (valeur === undefined || valeur === null || String(valeur).trim() === '') return defaut;
  const devise = String(valeur).trim().toUpperCase();
  if (!DEVISES.includes(devise)) {
    throw Object.assign(
      new Error(`Devise inconnue : « ${valeur} ». Devises acceptées : ${DEVISES.join(', ')}.`),
      { statusCode: 400 }
    );
  }
  return devise;
}

/**
 * Lit la configuration monétaire de l'école : devise d'affichage et taux de
 * change USD → FC (combien de francs congolais pour 1 dollar).
 */
async function lireConfigMonetaire(client) {
  const r = await client.query(
    `SELECT COALESCE(devise_principale, '${DEVISE_PAR_DEFAUT}') AS devise_principale,
            taux_change_usd_fc, taux_change_maj_at
       FROM ecoles WHERE id = ${CURRENT_ECOLE}`
  );
  const ligne = r.rows[0] || {};
  return {
    devise_principale: ligne.devise_principale || DEVISE_PAR_DEFAUT,
    taux_change_usd_fc: ligne.taux_change_usd_fc === null || ligne.taux_change_usd_fc === undefined
      ? null
      : Number(ligne.taux_change_usd_fc),
    taux_change_maj_at: ligne.taux_change_maj_at || null
  };
}

/**
 * Exige un taux de change utilisable.
 *
 * Il n'y a délibérément AUCUNE valeur par défaut : un taux inventé par la
 * plateforme produirait des soldes faux que personne ne remarquerait avant la
 * fin de l'année. Tant que le comptable n'a pas saisi le taux de son école,
 * toute opération qui mélange les devises est refusée avec un message qui dit
 * quoi faire.
 */
function exigerTaux(taux) {
  const valeur = Number(taux);
  if (!valeur || Number.isNaN(valeur) || valeur <= 0) {
    throw Object.assign(
      new Error("Aucun taux de change n'est configuré : le comptable doit d'abord le renseigner dans Frais scolaires > Taux de change avant de mélanger francs congolais et dollars."),
      { statusCode: 409 }
    );
  }
  return valeur;
}

/**
 * Convertit un montant d'une devise vers une autre.
 * `taux` = nombre de FC pour 1 USD (ex. 2800).
 *
 * Le taux n'est exigé que si une conversion est réellement nécessaire : une
 * école qui travaille exclusivement en FC n'a jamais à en configurer un.
 */
function convertir(montant, deviseSource, deviseCible, taux) {
  const valeur = Number(montant || 0);
  const source = normaliserDevise(deviseSource);
  const cible = normaliserDevise(deviseCible);
  if (source === cible) return valeur;

  const t = exigerTaux(taux);
  const converti = source === 'USD' ? valeur * t : valeur / t;

  // Arrondi à 2 décimales : au-delà, les centimes de FC n'ont pas de sens et
  // les écarts de virgule flottante finissent par créer des soldes de 0,0001.
  return Math.round(converti * 100) / 100;
}

/**
 * Somme une liste de montants hétérogènes dans une devise cible.
 * Chaque ligne peut porter son propre taux (celui appliqué au moment de
 * l'encaissement) : c'est ce qui permet à un reçu émis il y a six mois de
 * rester exact même si le taux de l'école a changé depuis.
 */
function sommerDans(lignes, deviseCible, tauxCourant) {
  return lignes.reduce((total, ligne) => {
    const taux = ligne.taux_change ? Number(ligne.taux_change) : tauxCourant;
    return total + convertir(ligne.montant, ligne.devise, deviseCible, taux);
  }, 0);
}

/** Formatage lisible pour les PDF et les écrans : « 1 250 000 FC », « 300 USD ». */
function formaterMontant(valeur, devise) {
  const nombre = Number(valeur || 0);
  const decimales = normaliserDevise(devise) === 'USD' ? 2 : 0;
  return new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: decimales,
    maximumFractionDigits: decimales
  }).format(nombre) + ' ' + normaliserDevise(devise);
}


/**
 * Expression SQL qui ramène un paiement dans une devise cible.
 *
 * Mutualisée ici parce que le solde d'un élève est calculé dans CINQ modules
 * différents (frais, contrôle financier, rapports, tableau de bord, site public).
 * Tant que chacun avait sa propre version, la même dette pouvait s'afficher
 * différemment selon l'écran — et quatre d'entre eux additionnaient encore les
 * paiements de toutes les années confondues, en mélangeant francs et dollars.
 *
 * @param aliasPaiement   alias de la table paiements_frais (ex. 'p')
 * @param deviseCible     expression SQL de la devise cible (ex. "'FC'", '$2', 'a.devise')
 * @param indexTaux       index du paramètre portant le taux courant (ex. 3 pour $3)
 */
function sqlPaiementConverti(aliasPaiement, deviseCible, indexTaux) {
  return `CASE
            WHEN ${aliasPaiement}.devise = ${deviseCible} THEN ${aliasPaiement}.montant
            WHEN ${aliasPaiement}.devise = 'USD'
              THEN ${aliasPaiement}.montant * COALESCE(${aliasPaiement}.taux_change, $${indexTaux})
            ELSE ${aliasPaiement}.montant / NULLIF(COALESCE(${aliasPaiement}.taux_change, $${indexTaux}), 0)
          END`;
}

/**
 * Même principe pour un montant attendu (frais_scolaires), qui porte lui aussi
 * sa devise et le taux figé au moment où il a été configuré.
 */
function sqlFraisConverti(aliasFrais, deviseCible, indexTaux) {
  return `CASE
            WHEN ${aliasFrais}.devise = ${deviseCible} THEN ${aliasFrais}.montant
            WHEN ${aliasFrais}.devise = 'USD'
              THEN ${aliasFrais}.montant * COALESCE(${aliasFrais}.taux_change, $${indexTaux})
            ELSE ${aliasFrais}.montant / NULLIF(COALESCE(${aliasFrais}.taux_change, $${indexTaux}), 0)
          END`;
}

module.exports = {
  DEVISES,
  DEVISE_PAR_DEFAUT,
  normaliserDevise,
  lireConfigMonetaire,
  exigerTaux,
  convertir,
  sommerDans,
  formaterMontant,
  sqlPaiementConverti,
  sqlFraisConverti,
};
