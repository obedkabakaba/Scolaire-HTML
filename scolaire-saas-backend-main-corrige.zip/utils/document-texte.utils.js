const zlib = require('zlib');

/**
 * ============================================================================
 *  EXTRACTION DE TEXTE DEPUIS UN DOCUMENT IMPORTÉ
 * ============================================================================
 *
 * La demande était que l'école puisse importer son règlement « en tout ce
 * qu'elle veut ». Dans la réalité des écoles congolaises, cela signifie
 * principalement : un fichier Word, un PDF scanné ou exporté, un texte tapé
 * dans un email, parfois un tableau Excel.
 *
 * CHOIX : aucune dépendance npm nouvelle
 * --------------------------------------
 * Ajouter `mammoth` (Word) et `pdf-parse` (PDF) aurait été plus simple à
 * écrire. C'est refusé pour deux raisons concrètes :
 *   · le déploiement se fait à la main sur Render, et chaque dépendance
 *     ajoutée est une étape de plus qui peut échouer sans que personne le
 *     remarque avant qu'un directeur clique sur « Importer » ;
 *   · `pdf-parse` embarque une copie de pdf.js, soit plusieurs mégaoctets pour
 *     une fonctionnalité utilisée quelques fois par an et par école.
 *
 * CE QUI EST DONC SUPPORTÉ, ET COMMENT
 * ------------------------------------
 *   · .txt, .md, .csv, .json  → lecture directe (avec détection d'encodage)
 *   · .docx                   → décompression ZIP + extraction du XML, écrites
 *                               ici à la main avec le module `zlib` de Node
 *   · .xlsx                   → délégué à `xlsx`, DÉJÀ présent dans le projet
 *   · copier-coller           → chemin toujours disponible, quel que soit le
 *                               format d'origine
 *
 * CE QUI NE L'EST PAS, ET POURQUOI C'EST DIT FRANCHEMENT
 * ------------------------------------------------------
 * Le PDF. Extraire du texte d'un PDF sans bibliothèque demande de décoder les
 * flux compressés, les tables d'encodage de polices et les positions
 * absolues — et un PDF scanné ne contient de toute façon aucun texte, seulement
 * une image. Plutôt que de renvoyer un charabia silencieux que l'assistant
 * analyserait sérieusement, la fonction refuse explicitement et invite au
 * copier-coller. Un refus clair vaut mieux qu'un résultat faux.
 */

const TAILLE_MAX = 2 * 1024 * 1024;   // 2 Mo de texte utile

/** Retire les caractères de contrôle et normalise les espaces. */
function nettoyer(texte) {
  return String(texte)
    .replace(/\r\n?/g, '\n')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    // Un règlement exporté depuis Word arrive souvent avec des dizaines de
    // lignes vides entre les articles : elles n'apportent rien à l'analyse et
    // gonflent inutilement ce qu'on envoie à l'assistant.
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

/**
 * Décode des octets en texte. UTF-8 par défaut ; repli sur latin-1 si le
 * résultat contient le caractère de remplacement, signe d'un fichier produit
 * par un vieux Word francophone.
 */
function decoder(octets) {
  const utf8 = octets.toString('utf8');
  if (!utf8.includes('\uFFFD')) return utf8;
  return octets.toString('latin1');
}

// ---------------------------------------------------------------------------
//  DOCX — lecture d'une archive ZIP sans dépendance
// ---------------------------------------------------------------------------

/**
 * Un .docx est une archive ZIP contenant `word/document.xml`. On lit le
 * « répertoire central » placé en fin d'archive, qui liste les fichiers et
 * leur position — plutôt que de parcourir l'archive depuis le début, ce qui
 * échoue dès qu'un descripteur de données est présent (cas fréquent des
 * fichiers produits par Word en ligne).
 */
function lireEntreeZip(tampon, nomCherche) {
  // Signature de fin de répertoire central : PK\5\6
  let finRepertoire = -1;
  for (let i = tampon.length - 22; i >= 0 && i > tampon.length - 65558; i--) {
    if (tampon.readUInt32LE(i) === 0x06054b50) { finRepertoire = i; break; }
  }
  if (finRepertoire === -1) return null;

  const nbEntrees = tampon.readUInt16LE(finRepertoire + 10);
  let position = tampon.readUInt32LE(finRepertoire + 16);

  for (let n = 0; n < nbEntrees; n++) {
    if (position + 46 > tampon.length) return null;
    if (tampon.readUInt32LE(position) !== 0x02014b50) return null;   // PK\1\2

    const methode = tampon.readUInt16LE(position + 10);
    const tailleCompressee = tampon.readUInt32LE(position + 20);
    const longueurNom = tampon.readUInt16LE(position + 28);
    const longueurExtra = tampon.readUInt16LE(position + 30);
    const longueurCommentaire = tampon.readUInt16LE(position + 32);
    const debutLocal = tampon.readUInt32LE(position + 42);
    const nom = tampon.toString('utf8', position + 46, position + 46 + longueurNom);

    if (nom === nomCherche) {
      // L'en-tête local redonne les longueurs de nom et d'extra, qui peuvent
      // différer de celles du répertoire central : on relit sur place.
      const longueurNomLocal = tampon.readUInt16LE(debutLocal + 26);
      const longueurExtraLocal = tampon.readUInt16LE(debutLocal + 28);
      const debutDonnees = debutLocal + 30 + longueurNomLocal + longueurExtraLocal;
      const donnees = tampon.subarray(debutDonnees, debutDonnees + tailleCompressee);
      // Méthode 0 = stocké sans compression, 8 = dégonflage brut.
      if (methode === 0) return donnees;
      if (methode === 8) return zlib.inflateRawSync(donnees);
      return null;
    }

    position += 46 + longueurNom + longueurExtra + longueurCommentaire;
  }
  return null;
}

/** Transforme le XML d'un document Word en texte lisible. */
function texteDepuisXmlWord(xml) {
  return xml
    // Un saut de paragraphe ou de ligne devient un vrai retour : sans cela,
    // tous les articles du règlement se retrouveraient collés sur une ligne,
    // et l'assistant ne pourrait plus les séparer.
    .replace(/<\/w:p>/g, '\n')
    .replace(/<w:br\s*\/?>/g, '\n')
    .replace(/<w:tab\s*\/?>/g, '\t')
    .replace(/<[^>]+>/g, '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

function texteDepuisDocx(tampon) {
  const xml = lireEntreeZip(tampon, 'word/document.xml');
  if (!xml) {
    throw Object.assign(
      new Error("Ce fichier Word n'a pas pu être lu. Réenregistrez-le au format .docx, ou copiez-collez son contenu."),
      { statusCode: 400 }
    );
  }
  return texteDepuisXmlWord(xml.toString('utf8'));
}

// ---------------------------------------------------------------------------
//  XLSX — via la bibliothèque déjà présente dans le projet
// ---------------------------------------------------------------------------

function texteDepuisXlsx(tampon) {
  const XLSX = require('xlsx');
  const classeur = XLSX.read(tampon, { type: 'buffer' });
  // Toutes les feuilles : un règlement en tableau met souvent les faits
  // positifs sur un onglet séparé, qu'il serait dommage d'ignorer.
  return classeur.SheetNames
    .map((nom) => `--- ${nom} ---\n` + XLSX.utils.sheet_to_csv(classeur.Sheets[nom]))
    .join('\n\n');
}

// ---------------------------------------------------------------------------
//  Point d'entrée
// ---------------------------------------------------------------------------

const EXTENSIONS_TEXTE = ['.txt', '.md', '.markdown', '.csv', '.tsv', '.json', '.htm', '.html', '.rtf'];

/**
 * @param {Buffer} tampon  contenu brut du fichier
 * @param {string} nomFichier  nom d'origine, pour reconnaître le format
 * @returns {string} texte exploitable
 */
function extraireTexte(tampon, nomFichier) {
  if (!tampon || tampon.length === 0) {
    throw Object.assign(new Error('Le fichier est vide.'), { statusCode: 400 });
  }

  const nom = String(nomFichier || '').toLowerCase();
  const extension = nom.includes('.') ? nom.slice(nom.lastIndexOf('.')) : '';

  // Le PDF se reconnaît à ses premiers octets, pas seulement à son extension :
  // un PDF renommé en .txt doit être refusé avec le même message clair.
  if (extension === '.pdf' || tampon.subarray(0, 5).toString('latin1') === '%PDF-') {
    throw Object.assign(
      new Error(
        "Les fichiers PDF ne peuvent pas être lus directement. Ouvrez le document, "
        + "copiez son texte et collez-le dans la zone prévue — ou enregistrez-le au format Word."
      ),
      { statusCode: 400 }
    );
  }

  let texte;
  if (extension === '.docx') {
    texte = texteDepuisDocx(tampon);
  } else if (extension === '.xlsx' || extension === '.xls') {
    texte = texteDepuisXlsx(tampon);
  } else if (extension === '.doc') {
    throw Object.assign(
      new Error(
        "L'ancien format Word (.doc) n'est pas lisible. Ouvrez le fichier et "
        + "enregistrez-le en .docx, ou copiez-collez son contenu."
      ),
      { statusCode: 400 }
    );
  } else if (EXTENSIONS_TEXTE.includes(extension) || extension === '') {
    texte = decoder(tampon);
    // Un HTML exporté depuis un traitement de texte : on retire le balisage,
    // sinon l'assistant analyserait des attributs de style.
    if (extension === '.htm' || extension === '.html') {
      texte = texte.replace(/<(script|style)[\s\S]*?<\/\1>/gi, '')
                   .replace(/<\/(p|div|br|tr|li|h[1-6])>/gi, '\n')
                   .replace(/<[^>]+>/g, '');
    }
    if (extension === '.rtf') {
      texte = texte.replace(/\\'([0-9a-f]{2})/gi, (m, h) => String.fromCharCode(parseInt(h, 16)))
                   .replace(/\\par[d]?\s?/g, '\n')
                   .replace(/\{\\[^{}]*\}/g, '')
                   .replace(/\\[a-z]+-?\d*\s?/gi, '');
    }
  } else {
    throw Object.assign(
      new Error(
        `Format « ${extension} » non reconnu. Formats acceptés : Word (.docx), texte, Markdown, CSV, Excel. `
        + "Pour tout autre format, copiez-collez le contenu."
      ),
      { statusCode: 400 }
    );
  }

  const propre = nettoyer(texte);
  if (propre.length < 40) {
    throw Object.assign(
      new Error(
        "Le document ne contient pas assez de texte lisible. S'il s'agit d'un scan ou d'une photo, "
        + "il faudra saisir ou copier le règlement à la main."
      ),
      { statusCode: 400 }
    );
  }
  if (propre.length > TAILLE_MAX) {
    throw Object.assign(
      new Error('Le document dépasse 2 Mo de texte. Importez uniquement la partie disciplinaire.'),
      { statusCode: 400 }
    );
  }
  return propre;
}

/**
 * Le texte contient-il déjà un barème chiffré ?
 *
 * C'est LA question qui décide du comportement de l'assistant : s'il y a des
 * points dans le règlement, il doit les REPRENDRE ; s'il n'y en a pas, il doit
 * les PROPOSER. Se tromper de branche, c'est soit écraser le barème d'une
 * école, soit lui rendre un règlement sans chiffres.
 *
 * La détection est volontairement exigeante : on cherche des chiffres associés
 * au vocabulaire des points, pas de simples nombres — un règlement mentionne
 * des articles numérotés, des horaires et des dates un peu partout.
 */
function contientBareme(texte) {
  const motifs = [
    /[-−–]\s*\d+(?:[.,]\d+)?\s*(?:points?|pts?\b)/i,
    /\d+(?:[.,]\d+)?\s*points?\s+(?:de\s+)?(?:retrait|retranch|déduit|perdus|en moins|de pénalité)/i,
    /(?:retrait|retranche[rz]?|déduction|pénalité|sanction)\s*(?:de\s*)?:?\s*\d+(?:[.,]\d+)?\s*(?:points?|pts?)/i,
    /(?:points?|pts?)\s*(?:retirés?|retranchés?|perdus?|déduits?)\s*:?\s*\d+/i
  ];
  const nbOccurrences = motifs.reduce(
    (total, motif) => total + (texte.match(new RegExp(motif.source, 'gi')) || []).length, 0
  );
  // Une seule occurrence peut être une phrase d'exemple (« par exemple 2
  // points »). Deux ou plus indiquent un vrai barème article par article.
  return nbOccurrences >= 2;
}

module.exports = { extraireTexte, contientBareme, nettoyer, lireEntreeZip, texteDepuisXmlWord };
