/**
 * Drapeau de la République Démocratique du Congo, en SVG vectoriel.
 *
 * Dessiné plutôt que téléchargé : une image binaire dépendrait d'un hébergement
 * externe — lien mort = bulletin sans drapeau — alors que la géométrie du
 * drapeau se décrit exactement. Le rendu reste net à toute taille d'impression,
 * ce qu'un PNG basse définition ne permettrait pas.
 *
 * Description officielle : champ bleu ciel, bande diagonale rouge bordée de
 * jaune allant du bas-gauche vers le haut-droit, étoile jaune à cinq branches
 * dans le canton supérieur gauche.
 *
 * La bande est tracée en deux traits superposés (jaune large, rouge plus fin)
 * plutôt qu'en polygones calculés : la géométrie est ainsi triviale à vérifier
 * et ne peut pas se déformer si le ratio change.
 */
const DRAPEAU_RDC_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 90" preserveAspectRatio="xMidYMid meet">
  <rect width="120" height="90" fill="#007FFF"/>
  <line x1="-6" y1="96" x2="126" y2="-6" stroke="#F7D618" stroke-width="26"/>
  <line x1="-6" y1="96" x2="126" y2="-6" stroke="#CE1021" stroke-width="16"/>
  <path fill="#F7D618" transform="translate(20,21)"
        d="M0,-13 L3.06,-4.02 L12.36,-4.02 L4.83,1.53 L7.64,10.52 L0,5 L-7.64,10.52 L-4.83,1.53 L-12.36,-4.02 L-3.06,-4.02 Z"/>
</svg>`;

module.exports = { DRAPEAU_RDC_SVG };
