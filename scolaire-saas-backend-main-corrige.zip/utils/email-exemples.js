/**
 * utils/email-exemples.js
 * -----------------------------------------------------------------------------
 * Contenu prêt à l'emploi pour les 15 types d'email Ardoise.
 * Chaque fonction renvoie l'objet à passer directement à emailWrapper()
 * (ou son HTML final). Adaptez les variables (prénom, montants, dates, URLs).
 *
 *   const { emailBienvenue } = require('./email-exemples');
 *   const { envoyerEmail } = require('./email.utils');
 *   await envoyerEmail({ to, subject: 'Bienvenue sur Ardoise', html: emailBienvenue({ prenom:'Jean', ecole:'Institut Lumière', url:'https://ardoise.app' }) });
 */
const { emailWrapper, carte, boiteCode, echapper } = require('./email-template');

const S = (v) => echapper(v == null ? '' : v);

// 1. Bienvenue
function emailBienvenue({ prenom, ecole, url }) {
  return emailWrapper({
    type: 'bienvenue',
    titre: 'Bienvenue sur Ardoise !',
    preheader: `Votre établissement ${ecole} est prêt.`,
    contenuHtml: `<p>Votre établissement <strong>"${S(ecole)}"</strong> est maintenant prêt à être utilisé.</p>
      <p>Connectez-vous pour commencer à gérer vos élèves, enseignants et toutes vos activités scolaires.</p>`,
    boutonPrincipal: { libelle: 'Accéder à mon compte', url },
  });
}

// 2. Nouveau compte créé
function emailNouveauCompte({ prenom, identifiant, motDePasseTemp, url }) {
  return emailWrapper({
    type: 'nouveau_compte',
    titre: 'Nouveau compte créé',
    preheader: 'Votre compte Ardoise est prêt.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p>Un compte a été créé pour vous sur la plateforme Ardoise.</p>`
      + boiteCode(`Identifiant : <strong>${S(identifiant)}</strong><br>Mot de passe temporaire : <strong style="color:#DD7C11;">${S(motDePasseTemp)}</strong>`)
      + carte({ type: 'warning', titre: 'Pensez-y', texteHtml: 'Changez ce mot de passe à votre première connexion.' }),
    boutonPrincipal: { libelle: 'Se connecter', url },
  });
}

// 3. Réinitialisation de mot de passe
function emailResetMdp({ prenom, url }) {
  return emailWrapper({
    type: 'reset_mdp',
    titre: 'Réinitialisation de votre mot de passe',
    preheader: 'Lien valable 1 heure.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p>Vous avez demandé la réinitialisation de votre mot de passe. Cliquez sur le bouton ci-dessous pour en choisir un nouveau.</p>
      <p style="font-size:13px;color:#5B6560;">Ce lien expire dans 60 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>`,
    boutonPrincipal: { libelle: 'Réinitialiser mon mot de passe', url },
  });
}

// 4. Vérification de votre email
function emailVerifEmail({ prenom, url }) {
  return emailWrapper({
    type: 'verif_email',
    titre: 'Vérifiez votre adresse email',
    preheader: 'Confirmez votre adresse pour activer votre compte.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p>Merci de confirmer votre adresse email pour activer votre compte Ardoise.</p>`,
    boutonPrincipal: { libelle: 'Vérifier mon email', url },
  });
}

// 5. Nouveau professeur ajouté
function emailProfAjoute({ prenom, nomProf, url }) {
  return emailWrapper({
    type: 'prof_ajoute',
    titre: 'Nouveau professeur ajouté',
    preheader: `${nomProf} a rejoint votre établissement.`,
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p><strong>${S(nomProf)}</strong> a été ajouté(e) comme professeur dans votre établissement.</p>`,
    boutonPrincipal: { libelle: 'Voir l\'équipe', url },
  });
}

// 6. Nouvel élève ajouté
function emailEleveAjoute({ prenom, nomEleve, classe, url }) {
  return emailWrapper({
    type: 'eleve_ajoute',
    titre: 'Nouvel élève ajouté',
    preheader: `${nomEleve} a été inscrit(e).`,
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p><strong>${S(nomEleve)}</strong> a été inscrit(e)${classe ? ` en <strong>${S(classe)}</strong>` : ''}.</p>`,
    boutonPrincipal: { libelle: 'Voir la fiche élève', url },
  });
}

// 7. Mot de passe changé
function emailMdpChange({ prenom, url }) {
  return emailWrapper({
    type: 'mdp_change',
    titre: 'Mot de passe modifié',
    preheader: 'Votre mot de passe a bien été changé.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>`
      + carte({ type: 'succes', titre: 'C\'est fait', texteHtml: 'Votre mot de passe a été modifié avec succès.' })
      + `<p style="font-size:13px;color:#5B6560;">Si vous n'êtes pas à l'origine de ce changement, contactez immédiatement le support.</p>`,
    boutonSecondaire: { libelle: 'Contacter le support', url },
  });
}

// 8. Paiement réussi
function emailPaiementReussi({ prenom, montant, date, urlRecu }) {
  return emailWrapper({
    type: 'paiement_reussi',
    titre: 'Paiement reçu',
    preheader: `Paiement de ${montant} confirmé.`,
    contenuHtml: `<p>Bonjour ${S(prenom)},</p><p>Nous avons bien reçu votre paiement.</p>`
      + boiteCode(`Montant : <strong>${S(montant)}</strong><br>Date : <strong>${S(date)}</strong>`)
      + `<p>Merci pour votre confiance.</p>`,
    boutonPrincipal: { libelle: 'Télécharger le reçu', url: urlRecu },
  });
}

// 9. Paiement échoué
function emailPaiementEchoue({ prenom, montant, url }) {
  return emailWrapper({
    type: 'paiement_echoue',
    titre: 'Échec du paiement',
    preheader: 'Votre paiement n\'a pas pu être traité.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>`
      + carte({ type: 'danger', titre: 'Paiement non abouti', texteHtml: `Le paiement de <strong>${S(montant)}</strong> n'a pas pu être traité. Veuillez réessayer ou mettre à jour votre moyen de paiement.` }),
    boutonPrincipal: { libelle: 'Réessayer le paiement', url },
  });
}

// 10. Abonnement activé
function emailAboActive({ prenom, formule, url }) {
  return emailWrapper({
    type: 'abo_active',
    titre: 'Abonnement activé',
    preheader: 'Votre abonnement Ardoise est actif.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>`
      + carte({ type: 'succes', titre: 'Abonnement actif', texteHtml: `Votre formule <strong>${S(formule)}</strong> est maintenant active. Profitez de toutes les fonctionnalités d'Ardoise.` }),
    boutonPrincipal: { libelle: 'Découvrir mon espace', url },
  });
}

// 11. Abonnement expiré / bientôt expiré
function emailAboExpire({ prenom, date, url }) {
  return emailWrapper({
    type: 'abo_expire',
    titre: 'Votre abonnement expire bientôt',
    preheader: `Expiration le ${date}.`,
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>
      <p>Votre abonnement expirera le <strong>${S(date)}</strong>. Renouvelez-le pour continuer à profiter d'Ardoise sans interruption.</p>`,
    boutonPrincipal: { libelle: 'Renouveler maintenant', url },
  });
}

// 12. Abonnement renouvelé
function emailAboRenouvele({ prenom, prochaineEcheance, url }) {
  return emailWrapper({
    type: 'abo_renouvele',
    titre: 'Abonnement renouvelé',
    preheader: 'Merci, votre abonnement est renouvelé.',
    contenuHtml: `<p>Bonjour ${S(prenom)},</p>`
      + carte({ type: 'succes', titre: 'Renouvellement confirmé', texteHtml: `Votre abonnement a été renouvelé.${prochaineEcheance ? ` Prochaine échéance : <strong>${S(prochaineEcheance)}</strong>.` : ''}` }),
    boutonSecondaire: { libelle: 'Voir ma facturation', url },
  });
}

// 13. Maintenance prévue
function emailMaintenance({ date, heure, duree, url }) {
  return emailWrapper({
    type: 'maintenance',
    titre: 'Maintenance prévue',
    preheader: `Maintenance le ${date}.`,
    contenuHtml: `<p>Bonjour,</p><p>Une maintenance est prévue sur Ardoise.</p>`
      + boiteCode(`Date : <strong>${S(date)}</strong><br>Heure : <strong>${S(heure)}</strong><br>Durée estimée : <strong>${S(duree)}</strong>`)
      + `<p>Merci de votre compréhension.</p>`,
    boutonSecondaire: url ? { libelle: 'Plus d\'informations', url } : undefined,
  });
}

// 14. Nouvelle fonctionnalité
function emailNouvelleFonction({ titreFonction, description, url }) {
  return emailWrapper({
    type: 'nouvelle_fonction',
    titre: 'Nouvelle fonctionnalité',
    preheader: titreFonction,
    contenuHtml: `<p>Bonjour,</p>
      <p>Nous sommes ravis de vous annoncer la disponibilité d'une nouvelle fonctionnalité.</p>`
      + carte({ type: 'info', titre: S(titreFonction), texteHtml: S(description) }),
    boutonPrincipal: { libelle: 'Découvrir maintenant', url },
  });
}

// 15. Bulletin disponible
function emailBulletin({ prenomEleve, periode, url }) {
  return emailWrapper({
    type: 'bulletin',
    titre: 'Le bulletin est disponible',
    preheader: `Bulletin de ${prenomEleve} disponible.`,
    contenuHtml: `<p>Bonjour,</p>
      <p>Le bulletin de <strong>${S(prenomEleve)}</strong> pour le <strong>${S(periode)}</strong> est maintenant disponible.</p>`,
    boutonPrincipal: { libelle: 'Voir le bulletin', url },
  });
}

module.exports = {
  emailBienvenue, emailNouveauCompte, emailResetMdp, emailVerifEmail, emailProfAjoute,
  emailEleveAjoute, emailMdpChange, emailPaiementReussi, emailPaiementEchoue, emailAboActive,
  emailAboExpire, emailAboRenouvele, emailMaintenance, emailNouvelleFonction, emailBulletin,
};
