/**
 * utils/email-template.js
 * ---------------------------------------------------------------------------
 * Gabarit email — clair/sombre, conçu pour survivre à l'inversion forcée.
 *
 * Historique du problème : un premier essai gardait un logo PNG avec le mot
 * « Ardoise » ET un fond opaque peint dans l'image. Résultat : dès qu'un
 * client applique SA PROPRE bascule de couleurs (ce que fait l'appli Gmail,
 * entre autres — elle inverse même les emails déjà sombres, voir plus bas),
 * le fond de la carte changeait mais le fond de l'image restait figé →
 * collision visuelle.
 *
 * La vraie parade n'est pas de verrouiller un thème unique (Gmail l'ignore
 * de toute façon), mais de ne plus avoir AUCUN élément que l'inversion ne
 * puisse pas suivre :
 *   - Le logo est réduit à une icône SANS fond peint (fond transparent,
 *     fournie recadrée par l'équipe design). Sans fond en dur, rien à faire
 *     clasher.
 *   - Le mot « Ardoise » n'est plus dans l'image : c'est du texte HTML,
 *     donc sa couleur suit le thème comme n'importe quel autre texte —
 *     et suit aussi l'inversion forcée d'un client, puisque du texte (au
 *     contraire d'un pixel peint) est un élément que ces clients savent
 *     recolorer.
 *   - Le point du « i » reste dans l'orange de marque, indépendamment du
 *     thème : ce orange (#DD7C11) garde un contraste correct aussi bien sur
 *     fond très clair que très sombre.
 *
 * Limite honnête, qui reste vraie même avec ce changement : Gmail (app
 * mobile) et certains clients Outlook appliquent une « inversion complète »
 * qui ne respecte ni `prefers-color-scheme` ni nos balises `color-scheme` —
 * documenté par Microsoft lui-même comme non contournable à 100 %. Ce qu'on
 * peut faire, et qu'on fait ici, c'est s'assurer que MÊME inversé par un
 * client tiers, le rendu reste cohérent (rien ne se fige d'un côté pendant
 * que le reste bascule de l'autre).
 */

const ASSET_BASE_URL = (
  process.env.EMAIL_ASSET_BASE_URL || 'https://myardoise.com/public/email'
).replace(/\/+$/, '');

const MARQUE   = process.env.RESEND_FROM_NAME || 'Ardoise';
const SITE_URL = process.env.FRONTEND_URL     || 'https://ardoise.com';
const SLOGAN   = 'La gestion scolaire simplifiée';

// Icône seule, fond transparent — plus de mot « Ardoise » peint dedans.
// Même fichier qu'avant (logo-dark.png) : il suffit de recadrer/remplacer
// son contenu, aucun changement de chemin nécessaire côté déploiement.
const ICONE_URL = `${ASSET_BASE_URL}/logo/logo-dark.png`;

const LIENS_LEGAUX = [
  { libelle: 'À propos',         url: `${SITE_URL}/a-propos` },
  { libelle: 'Support',          url: `${SITE_URL}/support` },
  { libelle: 'Mentions légales', url: `${SITE_URL}/mentions-legales` },
  { libelle: 'Confidentialité',  url: `${SITE_URL}/confidentialite` },
];
const RESEAUX = [
  { libelle: 'Facebook',  url: 'https://facebook.com/ardoise',          icone: 'facebook'  },
  { libelle: 'LinkedIn',  url: 'https://linkedin.com/company/ardoise',  icone: 'linkedin'  },
  { libelle: 'Instagram', url: 'https://instagram.com/ardoise',         icone: 'instagram' },
  { libelle: 'YouTube',   url: 'https://youtube.com/@ardoise',          icone: 'youtube'   },
];

/* ===========================================================================
   PALETTE — clair et sombre, tous deux réellement conçus (pas un fallback
   au rabais). Le sombre reste le rendu de base pour les clients qui
   n'interprètent pas prefers-color-scheme.
   ===========================================================================
*/
const C = {
  orange: '#DD7C11', // point du « i » et accents — fixe, ne change pas avec le thème

  clairFond:       '#FEFEFE',
  clairCarte:      '#FEFEFE',
  clairTexte:      '#263238',
  clairTexteDoux:  '#667176',
  clairBordure:    '#D7DEE1',

  sombreFond:      '#131B1D',
  sombreCarte:     '#131B1D',
  sombreTexte:     '#EAF0F2',
  sombreTexteDoux: '#9AA7AE',
  sombreBordure:   '#243038',
};

const THEME = {
  clair:  { fond: C.clairFond,  carte: C.clairCarte,  texte: C.clairTexte,  texteDoux: C.clairTexteDoux,  bordure: C.clairBordure  },
  sombre: { fond: C.sombreFond, carte: C.sombreCarte, texte: C.sombreTexte, texteDoux: C.sombreTexteDoux, bordure: C.sombreBordure },
};

const TYPES = {
  bienvenue:         { accent: C.orange },
  nouveau_compte:    { accent: C.orange },
  reset_mdp:         { accent: C.orange },
  verif_email:       { accent: C.orange },
  prof_ajoute:       { accent: C.orange },
  eleve_ajoute:      { accent: C.orange },
  mdp_change:        { accent: C.orange },
  paiement_reussi:   { accent: C.orange },
  paiement_echoue:   { accent: C.orange },
  abo_active:        { accent: C.orange },
  abo_expire:        { accent: C.orange },
  abo_renouvele:     { accent: C.orange },
  maintenance:       { accent: C.orange },
  nouvelle_fonction: { accent: C.orange },
  bulletin:          { accent: C.orange },
  message:           { accent: C.orange },
};

function echapper(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function bouton({ libelle, url, variante = 'principal' }) {
  const principal = variante === 'principal';
  const styleLien = principal
    ? `background:${C.orange};color:#FFFFFF;border:2px solid ${C.orange};border-radius:8px;`
    : `background:transparent;color:${C.orange};border:2px solid ${C.orange};border-radius:8px;`;
  return `
  <table cellpadding="0" cellspacing="0" border="0" style="margin:8px auto;">
    <tr><td align="center" style="${styleLien}">
      <a href="${echapper(url)}" target="_blank"
         style="display:inline-block;padding:14px 36px;font-size:16px;font-weight:700;
                line-height:1;text-decoration:none;color:${principal ? '#FFFFFF' : C.orange};
                font-family:sans-serif;">
        ${echapper(libelle)}
      </a>
    </td></tr>
  </table>`;
}

function carte({ type = 'info', titre, texteHtml }) {
  const classe = ['succes', 'warning', 'danger', 'info'].includes(type) ? type : 'info';
  return `
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="inner-card inner-card-${classe}" bgcolor="${C.sombreCarte}" style="margin:14px 0;border:1px solid ${C.sombreBordure};border-radius:10px;background-color:${C.sombreCarte};">
      <tr><td bgcolor="${C.sombreCarte}" style="padding:14px 16px;text-align:left;font-family:sans-serif;font-size:14px;line-height:1.55;color:${C.sombreTexte};background-color:${C.sombreCarte};">
        ${titre ? `<div style="font-weight:700;color:${C.orange};margin-bottom:4px;">${titre}</div>` : ''}
        <div>${texteHtml || ''}</div>
      </td></tr>
    </table>`;
}

function boiteCode(texteHtml) {
  return `
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="code-box" bgcolor="${C.sombreCarte}" style="margin:18px 0;border:1px solid ${C.sombreBordure};border-radius:10px;background-color:${C.sombreCarte};">
      <tr><td bgcolor="${C.sombreCarte}" style="padding:14px 16px;text-align:center;font-family:sans-serif;font-size:14px;line-height:1.7;color:${C.sombreTexte};background-color:${C.sombreCarte};">
        ${texteHtml || ''}
      </td></tr>
    </table>`;
}

function iconeReseau(nom) {
  const paths = {
    facebook:  'M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.2c-1.2 0-1.6.8-1.6 1.6V12h2.7l-.4 2.9h-2.3v7A10 10 0 0 0 22 12z',
    linkedin:  'M20.5 2h-17A1.5 1.5 0 0 0 2 3.5v17A1.5 1.5 0 0 0 3.5 22h17a1.5 1.5 0 0 0 1.5-1.5v-17A1.5 1.5 0 0 0 20.5 2zM8 19H5V9h3v10zM6.5 7.7a1.7 1.7 0 1 1 0-3.4 1.7 1.7 0 0 1 0 3.4zM19 19h-3v-5.3c0-1.3-.5-2.1-1.6-2.1-.9 0-1.4.6-1.6 1.2-.1.2-.1.5-.1.8V19h-3V9h3v1.3c.4-.6 1.1-1.5 2.8-1.5 2 0 3.5 1.3 3.5 4.2V19z',
    instagram: 'M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4a3.9 3.9 0 0 1-1.4-.9 3.9 3.9 0 0 1-.9-1.4c-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 3.2A6.6 6.6 0 1 0 12 18.6 6.6 6.6 0 0 0 12 5.4zm0 10.9A4.3 4.3 0 1 1 12 7.7a4.3 4.3 0 0 1 0 8.6zm6.8-11.2a1.5 1.5 0 1 1-3.1 0 1.5 1.5 0 0 1 3.1 0z',
    youtube:   'M23 7.5s-.2-1.6-.9-2.3c-.9-.9-1.8-.9-2.3-1C16.6 4 12 4 12 4s-4.6 0-7.8.2c-.5.1-1.4.1-2.3 1-.7.7-.9 2.3-.9 2.3S.8 9.4.8 11.3v1.4c0 1.9.2 3.8.2 3.8s.2 1.6.9 2.3c.9.9 2 .9 2.5 1C6 20 12 20 12 20s4.6 0 7.8-.2c.5-.1 1.4-.1 2.3-1 .7-.7.9-2.3.9-2.3s.2-1.9.2-3.8v-1.4c0-1.9-.2-3.8-.2-3.8zM9.8 15.1V8.9l6 3.1-6 3.1z',
  };
  const d = paths[nom] || paths.facebook;
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:middle;"><path d="${d}"/></svg>`;
}

/**
 * Le mot « Ardoise », en texte réel (plus une image) — sa couleur suit
 * `.marque-texte` comme tout le reste, et le point du « i » reste orange
 * de marque en toute circonstance.
 *
 * Détail technique sur ce point orange : on ne peut pas recolorer
 * séparément le point d'un vrai glyphe « i » (dot + hampe ne font qu'un
 * caractère). On utilise donc un « i » sans point (ı) suivi d'un petit
 * disque positionné par-dessus en CSS. Ça fonctionne dans la quasi-totalité
 * des clients ; le seul cas dégradé connu est Outlook desktop (moteur Word),
 * où le disque peut apparaître légèrement décalé au lieu d'être pile
 * au-dessus — jamais cassé, juste moins précis.
 */
function motArdoise() {
  return `<span class="marque-texte" style="font-family:sans-serif;font-weight:800;font-size:23px;letter-spacing:-0.2px;color:${C.sombreTexte};">Ard` +
    `<span style="position:relative;display:inline-block;">` +
      `<span style="display:inline-block;">\u0131</span>` +
      `<span style="position:absolute;top:1px;left:5px;width:5px;height:5px;border-radius:50%;background:${C.orange};"></span>` +
    `</span>` +
    `se</span>`;
}

/* ===========================================================================
   GABARIT PRINCIPAL
   ===========================================================================
*/
function emailWrapper({ type, titre, contenuHtml, boutonPrincipal, boutonSecondaire, preheader }) {
  const t = TYPES[type] || TYPES.message;
  const accent = t.accent;
  const annee = new Date().getFullYear();
  // Le sombre est le rendu de base. Le clair est appliqué uniquement si
  // le client déclare explicitement prefers-color-scheme: light.
  const light = THEME.clair;
  const dark = THEME.sombre;

  const boutonsHtml = (boutonPrincipal || boutonSecondaire) ? `
    <tr><td align="center" style="padding:16px 40px 8px;">
      ${boutonPrincipal  ? bouton({ ...boutonPrincipal,  variante: 'principal'  }) : ''}
      ${boutonSecondaire ? bouton({ ...boutonSecondaire, variante: 'secondaire' }) : ''}
    </td></tr>` : '';

  const pre = preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${echapper(preheader)}</div>` : '';

  const liensPied = LIENS_LEGAUX
    .map((l) => `<a class="txt-doux" href="${echapper(l.url)}" target="_blank" style="color:${dark.texteDoux};text-decoration:none;font-size:12px;padding:0 8px;">${echapper(l.libelle)}</a>`)
    .join(`<span class="separator" style="color:${dark.bordure};">·</span>`);

  const reseaux = RESEAUX
    .map((r) => `<a class="txt-doux" href="${echapper(r.url)}" target="_blank" style="color:${dark.texteDoux};text-decoration:none;padding:0 7px;display:inline-block;">${iconeReseau(r.icone)}</a>`)
    .join('');

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="color-scheme" content="dark light">
  <meta name="supported-color-schemes" content="dark light">
  <style>
    /* Sombre par défaut : c'est le rendu envoyé sans préférence interprétée. */
    body, .email-wrapper, .bg-table, .outer-bg,
    .email-container, .carte-bg, .inner-card, .code-box,
    .inner-card td, .code-box td {
      background-color:${C.sombreFond} !important;
    }
    .txt-main, .titre, .inner-card td, .code-box td,
    .inner-card strong, .code-box strong,
    .marque-texte { color:${C.sombreTexte} !important; }
    .txt-doux { color:${C.sombreTexteDoux} !important; }
    .separator { color:${C.sombreBordure} !important; }
    .inner-card, .code-box { border-color:${C.sombreBordure} !important; }
    .inner-card-warning { border-left:4px solid ${C.orange} !important; }
    .inner-card-danger { border-left:4px solid #B63A32 !important; }
    .inner-card-succes { border-left:4px solid #2E8B57 !important; }
    .inner-card-info { border-left:4px solid #4D7EA8 !important; }

    /* Le mode clair est activé uniquement lorsque le client le demande. */
    @media (prefers-color-scheme: light) {
      body, .email-wrapper, .bg-table, .outer-bg,
      .email-container, .carte-bg, .inner-card, .code-box,
      .inner-card td, .code-box td { background-color:${C.clairFond} !important; }
      .txt-main, .titre, .inner-card td, .code-box td,
      .inner-card strong, .code-box strong,
      .marque-texte { color:${C.clairTexte} !important; }
      .txt-doux { color:${C.clairTexteDoux} !important; }
      .separator { color:${C.clairBordure} !important; }
      .inner-card, .code-box { border-color:${C.clairBordure} !important; }
    }

    /* Clients qui utilisent les attributs de thème d'Outlook/Office. */
    [data-ogsc] body, [data-ogsc] .email-wrapper, [data-ogsc] .bg-table, [data-ogsc] .outer-bg,
    [data-ogac] body, [data-ogac] .email-wrapper, [data-ogac] .bg-table, [data-ogac] .outer-bg,
    [data-ogsc] .email-container, [data-ogsc] .carte-bg, [data-ogsc] .inner-card, [data-ogsc] .code-box,
    [data-ogac] .email-container, [data-ogac] .carte-bg, [data-ogac] .inner-card, [data-ogac] .code-box {
      background-color:${C.sombreFond} !important;
    }
    [data-ogsc] .txt-main, [data-ogsc] .titre, [data-ogsc] .txt-doux, [data-ogsc] .marque-texte,
    [data-ogac] .txt-main, [data-ogac] .titre, [data-ogac] .txt-doux, [data-ogac] .marque-texte { color:${C.sombreTexte} !important; }

    @media only screen and (max-width:620px) {
      .email-container { width:100% !important; border-radius:12px !important; }
      .content-pad { padding-left:24px !important; padding-right:24px !important; }
    }
  </style>
</head>
<body class="email-wrapper" bgcolor="${C.sombreFond}" style="margin:0;padding:0;background-color:${C.sombreFond};color:${C.sombreTexte};">
  ${pre}
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="bg-table outer-bg" bgcolor="${C.sombreFond}" style="background-color:${C.sombreFond};">
    <tr><td align="center" class="outer-bg" bgcolor="${C.sombreFond}" style="padding:28px 12px;background-color:${C.sombreFond};">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" class="email-container" bgcolor="${C.sombreFond}"
             style="width:600px;max-width:600px;background-color:${C.sombreFond};border:1px solid ${C.sombreBordure};border-radius:16px;overflow:hidden;">

        <!-- Icône (fond transparent) + mot « Ardoise » en texte réel. -->
        <tr><td align="center" class="carte-bg content-pad" bgcolor="${C.sombreFond}" style="padding:34px 40px 20px;background-color:${C.sombreFond};">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
            <tr>
              <td style="padding-right:10px;vertical-align:middle;">
                <img src="${ICONE_URL}" width="36" height="36" alt="" style="display:block;width:36px;height:36px;border:0;">
              </td>
              <td style="vertical-align:middle;">${motArdoise()}</td>
            </tr>
          </table>
        </td></tr>

        <tr><td align="center" class="titre content-pad" bgcolor="${C.sombreFond}" style="padding:0 40px 8px;font-family:sans-serif;font-size:22px;font-weight:700;color:${C.sombreTexte};line-height:1.3;background-color:${C.sombreFond};">
          ${echapper(titre)}
        </td></tr>

        <tr><td align="center" class="txt-main content-pad" bgcolor="${C.sombreFond}" style="padding:8px 40px 4px;font-family:sans-serif;font-size:15px;line-height:1.7;color:${C.sombreTexte};text-align:center;background-color:${C.sombreFond};">
          ${contenuHtml}
        </td></tr>

        ${boutonsHtml}

        <tr><td align="center" class="txt-doux content-pad" bgcolor="${C.sombreFond}" style="padding:22px 40px 6px;font-family:sans-serif;font-size:13px;color:${C.sombreTexteDoux};background-color:${C.sombreFond};">
          <div style="font-weight:700;color:${accent};">${echapper(MARQUE)} Team</div>
          <div>${echapper(SLOGAN)}</div>
        </td></tr>

        <tr><td class="carte-bg content-pad" bgcolor="${C.sombreFond}" style="padding:14px 40px 0;background-color:${C.sombreFond};">
          <div class="separator" style="border-top:1px solid ${C.sombreBordure};font-size:0;line-height:0;">&nbsp;</div>
        </td></tr>

        <tr><td align="center" class="txt-doux content-pad" bgcolor="${C.sombreFond}" style="padding:16px 40px 26px;font-family:sans-serif;font-size:11px;color:${C.sombreTexteDoux};background-color:${C.sombreFond};">
          <div style="margin:0 0 10px;">${reseaux}</div>
          <div style="margin:0 0 10px;">${liensPied}</div>
          <div>© ${annee} ${echapper(MARQUE)}. Tous droits réservés.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

module.exports = { emailWrapper, bouton, carte, boiteCode, echapper, TYPES };
