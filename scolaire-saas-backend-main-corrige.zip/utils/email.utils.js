/**
 * Envoie un email via Resend.
 *
 * Les notifications automatiques utilisent Ardoise comme expéditeur.
 * Un email envoyé par le super-admin doit également utiliser Ardoise.
 */
function nettoyerEntete(valeur) {
  return String(valeur || '')
    .replace(/[\r\n]/g, '')
    .trim();
}

/**
 * Retourne l'identité email selon la requête authentifiée.
 */
function identiteEmailDepuisRequete(req, expediteur = null) {
  if (req?.auth?.isSuperAdmin) {
    return {
      fromName: 'Ardoise',
      replyTo: process.env.SUPPORT_EMAIL || null,
      estSuperAdmin: true
    };
  }

  const fromName = expediteur
    ? [expediteur.prenom, expediteur.nom]
        .filter(Boolean)
        .join(' ')
        .trim()
    : null;

  return {
    fromName: fromName || null,
    fromEmail: expediteur?.email || null,
    replyTo: expediteur?.email || null,
    estSuperAdmin: false
  };
}

/**
 * Envoie un email via Resend.
 *
 * estSuperAdmin=true force le nom d'expéditeur à Ardoise, même si un nom
 * personnel a été fourni par erreur.
 */
async function envoyerEmail({
  to,
  subject,
  html,
  fromName = null,
  fromEmail = null,
  replyTo = null,
  estSuperAdmin = false
}) {
  if (!process.env.RESEND_API_KEY) {
    console.warn(
      'RESEND_API_KEY non configuré — email non envoyé (juste journalisé en base).'
    );
    return {
      envoye: false,
      raison: 'cle_api_absente'
    };
  }

  const nomExpediteur = nettoyerEntete(
    estSuperAdmin
      ? 'Ardoise'
      : (fromName || process.env.RESEND_FROM_NAME || 'Ardoise')
  );

  const adresseExpediteur = nettoyerEntete(
    fromEmail ||
      process.env.RESEND_FROM_EMAIL ||
      'onboarding@resend.dev'
  );

  const payload = {
    from: `${nomExpediteur} <${adresseExpediteur}>`,
    to,
    subject,
    html
  };

  const replyToNettoye = nettoyerEntete(replyTo);

  if (replyToNettoye && !estSuperAdmin) {
    payload.reply_to = replyToNettoye;
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const erreur = await response.text();
      console.error('Erreur Resend:', erreur);
      return {
        envoye: false,
        raison: erreur
      };
    }

    return { envoye: true };
  } catch (err) {
    console.error('Erreur envoi email:', err);
    return {
      envoye: false,
      raison: err.message
    };
  }
}

module.exports = {
  envoyerEmail,
  identiteEmailDepuisRequete,
  nettoyerEntete
};
