/**
 * Outils financiers partagés — espace Super Administrateur.
 * ---------------------------------------------------------------------------
 * Trois problèmes reviennent dans les trois contrôleurs du centre Finance, et
 * sont résolus une seule fois ici.
 *
 * 1. LES DEVISES NE S'ADDITIONNENT PAS.
 *    Ardoise encaisse en USD et en FC. Sommer `paiements.montant` sans
 *    conversion produit un chiffre d'affaires qui ne veut rien dire — et qui,
 *    pire, a l'air juste. `convertisseur()` charge les taux saisis dans
 *    `finance_taux_change` et signale explicitement les devises pour
 *    lesquelles aucun taux n'existe, plutôt que d'en inventer un à 1.
 *
 * 2. UN PRIX N'EST PAS UN MRR.
 *    Un plan à 300 $ pour 365 jours ne pèse pas 300 $ de revenu mensuel.
 *    `mensualiser()` ramène tout à une base mensuelle de 30,44 jours
 *    (365,25 / 12), une fois pour toutes.
 *
 * 3. TOUTE ÉCRITURE SENSIBLE DOIT LAISSER UNE TRACE.
 *    `journaliser()` écrit dans `journal_financier` ET dans `journal_activite`
 *    (qui reste la trace transversale du produit). Un appel, deux journaux,
 *    aucun oubli possible.
 */

const JOURS_PAR_MOIS = 365.25 / 12;   // 30,4375

/* ==========================================================================
   1. Devises
   ========================================================================== */

/**
 * Construit un convertisseur vers la devise de référence.
 *
 * Le taux retenu pour une devise est le plus récent dont `date_effet` est
 * passée. C'est volontairement un taux courant et non un taux historique par
 * transaction : Ardoise ne tient pas de comptabilité multidevise, et fournir
 * un taux « au jour de l'encaissement » supposerait une saisie quotidienne
 * qui n'existe pas. Le convertisseur le dit lui-même via `approximatif`.
 *
 * @returns {{
 *   reference: string,
 *   convertir: (montant:number, devise:string) => number,
 *   devisesInconnues: Set<string>,
 *   taux: object,
 *   approximatif: boolean
 * }}
 */
async function convertisseur(client, deviseReference = 'USD') {
  const reference = String(deviseReference || 'USD').toUpperCase();
  const taux = {};

  try {
    const r = await client.query(
      `SELECT DISTINCT ON (upper(devise)) upper(devise) AS devise, taux_vers_reference
         FROM finance_taux_change
        WHERE upper(devise_reference) = $1 AND date_effet <= current_date
        ORDER BY upper(devise), date_effet DESC`,
      [reference]
    );
    for (const ligne of r.rows) taux[ligne.devise] = Number(ligne.taux_vers_reference);
  } catch (err) {
    // Table absente (migration 027 non jouée) : on continue en mono-devise
    // plutôt que de faire tomber tout le centre Finance.
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[finance] taux de change indisponibles :', err.message);
    }
  }

  taux[reference] = 1;
  const devisesInconnues = new Set();

  function convertir(montant, devise) {
    const n = Number(montant);
    if (!Number.isFinite(n) || n === 0) return 0;
    const d = String(devise || reference).toUpperCase();
    if (taux[d] !== undefined) return n * taux[d];
    // Aucun taux : on NE convertit PAS et on le signale. Le montant est
    // conservé tel quel — le masquer serait pire — mais l'interface affiche
    // un avertissement nommant la devise manquante.
    devisesInconnues.add(d);
    return n;
  }

  return {
    reference,
    convertir,
    devisesInconnues,
    taux,
    get approximatif() { return devisesInconnues.size > 0; }
  };
}

/* ==========================================================================
   2. Normalisation des montants périodiques
   ========================================================================== */

/** Ramène un montant facturé sur `dureeJours` à son équivalent mensuel. */
function mensualiser(montant, dureeJours) {
  const m = Number(montant);
  const d = Number(dureeJours);
  if (!Number.isFinite(m)) return 0;
  if (!Number.isFinite(d) || d <= 0) return m;      // durée inconnue : on suppose mensuel
  return m * (JOURS_PAR_MOIS / d);
}

/** Ramène un montant selon sa périodicité déclarée. */
function mensualiserPeriodicite(montant, periodicite) {
  const m = Number(montant) || 0;
  switch (String(periodicite || 'mensuel')) {
    case 'annuel': return m / 12;
    case 'trimestriel': return m / 3;
    default: return m;
  }
}

/** Coût mensuel équivalent d'un service, quelle que soit sa fréquence. */
function coutMensuelService(service) {
  const frequence = String(service.frequence_facturation || 'mensuelle');
  if (frequence === 'annuelle') {
    const annuel = Number(service.cout_annuel);
    if (Number.isFinite(annuel) && annuel > 0) return annuel / 12;
    return Number(service.cout_mensuel) || 0;
  }
  // Facturation trimestrielle : `cout_mensuel` porte alors le montant du
  // trimestre (c'est ce que l'exploitant lit sur sa facture), ramené au mois.
  if (frequence === 'trimestrielle') return (Number(service.cout_mensuel) || 0) / 3;
  if (frequence === 'ponctuelle' || frequence === 'a_l_usage') return 0;  // porté par les dépenses / consommations
  return Number(service.cout_mensuel) || 0;
}

/* ==========================================================================
   3. Périodes
   ========================================================================== */

/** 'YYYY-MM' du mois courant. */
function moisCourant(decalage = 0) {
  const d = new Date();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + decalage);
  return d.toISOString().slice(0, 7);
}

/** Liste des N derniers mois, du plus ancien au plus récent. */
function derniersMois(n = 12) {
  const liste = [];
  for (let i = n - 1; i >= 0; i--) liste.push(moisCourant(-i));
  return liste;
}

/** Valide une période 'YYYY-MM' ou 'YYYY'. */
function periodeValide(texte, annuelAutorise = false) {
  const t = String(texte || '');
  if (/^\d{4}-\d{2}$/.test(t)) return true;
  return annuelAutorise && /^\d{4}$/.test(t);
}

/* ==========================================================================
   4. Journal financier
   ========================================================================== */

/**
 * Enregistre une action financière sensible.
 *
 * Écrit dans les DEUX journaux, volontairement :
 *   · `journal_financier` porte l'ancienne et la nouvelle valeur, le motif et
 *     le montant — ce que la mission demande de conserver ;
 *   · `journal_activite` reste le fil unique où l'exploitant retrouve « tout
 *     ce qui s'est passé », finance comprise, sans avoir à consulter deux
 *     écrans.
 *
 * Ne lève jamais : une écriture d'audit qui échoue ne doit pas annuler
 * l'opération métier déjà validée. En revanche l'échec est signalé dans les
 * journaux serveur — un audit muet qui reste muet est un audit inutile.
 */
async function journaliser(client, req, {
  action, entite, entiteId = null, libelle = null,
  ancienneValeur = null, nouvelleValeur = null,
  montant = null, devise = null, raison = null, ecoleId = null
}) {
  const utilisateurId = req && req.auth ? req.auth.userId : null;
  const ip = req ? (req.headers['x-forwarded-for'] || req.ip || null) : null;

  try {
    await client.query(
      `INSERT INTO journal_financier
         (action, entite, entite_id, libelle, ancienne_valeur, nouvelle_valeur,
          montant, devise, raison, ecole_id, utilisateur_id, adresse_ip)
       VALUES ($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,$8,$9,$10,$11,$12)`,
      [action, entite, entiteId, libelle,
       ancienneValeur === null ? null : JSON.stringify(ancienneValeur),
       nouvelleValeur === null ? null : JSON.stringify(nouvelleValeur),
       montant, devise, raison, ecoleId, utilisateurId,
       ip ? String(ip).slice(0, 90) : null]
    );
  } catch (err) {
    console.error('[finance] journal financier non écrit :', err.message);
  }

  try {
    await client.query(
      `INSERT INTO journal_activite (ecole_id, utilisateur_id, action, cible_type, cible_id, metadata)
       VALUES ($1,$2,$3,$4,$5,$6::jsonb)`,
      [ecoleId, utilisateurId, `finance.${action}`, entite, entiteId,
       JSON.stringify({ libelle, raison, montant, devise, source: 'super_admin_finance' })]
    );
  } catch (err) {
    console.error('[finance] journal d\'activité non écrit :', err.message);
  }
}

/* ==========================================================================
   5. Validation d'entrée
   ========================================================================== */

/** Nombre strictement positif, ou `null`. */
function nombrePositif(valeur, { zeroAutorise = true } = {}) {
  if (valeur === undefined || valeur === null || valeur === '') return null;
  const n = Number(valeur);
  if (!Number.isFinite(n)) return null;
  if (n < 0) return null;
  if (!zeroAutorise && n === 0) return null;
  return n;
}

/** Entier borné, ou `null`. */
function entier(valeur, min = null, max = null) {
  if (valeur === undefined || valeur === null || valeur === '') return null;
  const n = parseInt(valeur, 10);
  if (!Number.isFinite(n)) return null;
  if (min !== null && n < min) return null;
  if (max !== null && n > max) return null;
  return n;
}

/** Texte nettoyé et borné. */
function texte(valeur, longueurMax = 500) {
  if (valeur === undefined || valeur === null) return null;
  const t = String(valeur).trim();
  return t ? t.slice(0, longueurMax) : null;
}

/** Date ISO 'YYYY-MM-DD', ou `null`. */
function dateIso(valeur) {
  if (!valeur) return null;
  const t = String(valeur).slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(t) ? t : null;
}

/** Liste d'UUID valides (les entrées invalides sont écartées, pas devinées). */
function listeUuid(valeur) {
  if (!Array.isArray(valeur)) return [];
  const motif = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return valeur.map((v) => String(v || '')).filter((v) => motif.test(v));
}

/**
 * Masque un secret. Reprise du principe déjà appliqué dans
 * `super-admin.utils.js` : on montre assez pour reconnaître la clé, jamais
 * assez pour s'en servir.
 *   sk-proj-abcdef…1234  →  sk-•••••••••••1234
 */
function masquerSecret(valeur) {
  if (!valeur) return null;
  const t = String(valeur);
  if (t.length <= 8) return '••••••••';
  return `${t.slice(0, 3)}${'•'.repeat(Math.min(12, Math.max(4, t.length - 7)))}${t.slice(-4)}`;
}

/** Arrondi monétaire — évite les 0.30000000000000004 dans les réponses JSON. */
function arrondi(valeur, decimales = 2) {
  const n = Number(valeur);
  if (!Number.isFinite(n)) return 0;
  const f = Math.pow(10, decimales);
  return Math.round(n * f) / f;
}

/** Division protégée : renvoie `null` plutôt que Infinity ou NaN. */
function ratio(numerateur, denominateur) {
  const a = Number(numerateur);
  const b = Number(denominateur);
  if (!Number.isFinite(a) || !Number.isFinite(b) || b === 0) return null;
  return a / b;
}

module.exports = {
  JOURS_PAR_MOIS,
  convertisseur,
  mensualiser, mensualiserPeriodicite, coutMensuelService,
  moisCourant, derniersMois, periodeValide,
  journaliser,
  nombrePositif, entier, texte, dateIso, listeUuid,
  masquerSecret, arrondi, ratio
};
