/**
 * ============================================================================
 *  FRAIS DUS PAR UN ÉLÈVE — règle de calcul unique
 * ============================================================================
 *
 * LE DÉFAUT CORRIGÉ
 * -----------------
 * Le montant attendu était obtenu par un `SELECT … FROM frais_scolaires …
 * LIMIT 1`, à trois endroits différents (contrôle du blocage de bulletin,
 * dettes antérieures, situation financière).
 *
 * Or `frais_scolaires` porte une colonne `libelle` : une école déclare
 * plusieurs lignes — inscription, minerval, frais de laboratoire, uniforme.
 * Avec `LIMIT 1`, une seule était comptée. Une école réclamant 150 $ en quatre
 * lignes voyait la plateforme n'en attendre que 40, déclarer les familles à
 * jour, et délivrer tous les bulletins malgré le blocage activé.
 *
 * LA RÈGLE APPLIQUÉE
 * ------------------
 * On additionne TOUTES les lignes applicables, mais une seule par LIBELLÉ.
 * Une ligne propre à la classe REMPLACE la ligne générale du même libellé —
 * elle ne s'y ajoute pas.
 *
 *   Général  : « Minerval » 100 · « Inscription » 50
 *   6e A     : « Minerval » 120
 *   → dû par un élève de 6e A : 120 + 50 = 170, et non 270.
 *
 * C'est l'usage : une école fixe un minerval général puis l'ajuste pour
 * certaines classes. Additionner les deux doublerait la réclamation.
 *
 * `DISTINCT ON (f.libelle)` avec `ORDER BY f.libelle, f.classe_id NULLS LAST`
 * retient la ligne la plus spécifique de chaque libellé : les lignes nommées
 * passent avant les lignes générales.
 */

const { sqlFraisConverti } = require('./devise.utils');

/**
 * Fragment SQL renvoyant le TOTAL dû, converti dans la devise voulue.
 *
 * @param {string} alias        colonne portant l'identifiant de classe (ex. 'e.classe_id')
 * @param {string} anneeParam   placeholder de l'année scolaire (ex. '$2')
 * @param {string} deviseParam  placeholder de la devise cible (ex. '$3')
 * @param {number} tauxIndex    numéro du placeholder du taux (ex. 4)
 * @param {string} ecoleSql     expression donnant l'école courante
 */
function sqlTotalFraisDus(alias, anneeParam, deviseParam, tauxIndex, ecoleSql) {
  return `COALESCE((
    SELECT SUM(t.montant) FROM (
      SELECT DISTINCT ON (f.libelle)
             ${sqlFraisConverti('f', deviseParam, tauxIndex)} AS montant
        FROM frais_scolaires f
       WHERE f.ecole_id = ${ecoleSql}
         AND f.annee_scolaire_id = ${anneeParam}
         AND (f.classe_id = ${alias} OR f.classe_id IS NULL)
       ORDER BY f.libelle, f.classe_id NULLS LAST
    ) t
  ), 0)`;
}

/**
 * Détail ligne par ligne des frais dus. Sert à l'affichage et au choix du frais
 * réglé lors d'un encaissement : « il a payé quoi » est une question à laquelle
 * un montant global ne répond pas.
 */
async function detailFraisDus(client, { classeId, anneeScolaireId, devise, taux, ecoleSql }) {
  const r = await client.query(
    `SELECT DISTINCT ON (f.libelle)
            f.id, f.libelle, f.montant, f.devise, f.taux_change,
            f.classe_id IS NOT NULL AS propre_a_la_classe,
            ${sqlFraisConverti('f', '$3', 4)} AS montant_converti
       FROM frais_scolaires f
      WHERE f.ecole_id = ${ecoleSql}
        AND f.annee_scolaire_id = $2
        AND (f.classe_id = $1 OR f.classe_id IS NULL)
      ORDER BY f.libelle, f.classe_id NULLS LAST`,
    [classeId, anneeScolaireId, devise, taux || null]
  );

  return r.rows.map((l) => ({
    id: l.id,
    libelle: l.libelle,
    montant: Number(l.montant),
    devise: l.devise,
    montant_converti: Math.round(Number(l.montant_converti) * 100) / 100,
    // Dit à l'écran pourquoi ce montant-là s'applique : une ligne propre à la
    // classe remplace la ligne générale du même nom, et un directeur qui voit
    // deux montants différents doit comprendre lequel fait foi.
    propre_a_la_classe: l.propre_a_la_classe === true
  }));
}

module.exports = { sqlTotalFraisDus, detailFraisDus };
