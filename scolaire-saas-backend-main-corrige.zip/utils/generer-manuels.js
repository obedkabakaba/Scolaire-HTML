/**
 * ============================================================================
 *  GÉNÉRATEUR DES MANUELS PAPIER — Ardoise
 * ============================================================================
 *
 *  POURQUOI LES MANUELS SONT GÉNÉRÉS, ET NON RÉDIGÉS
 *  -------------------------------------------------
 *  Un manuel écrit à la main diverge de l'assistant dès la première évolution
 *  de la plateforme, et c'est précisément l'écart entre les deux qui fait
 *  perdre confiance dans les deux. Ces documents sont donc produits à partir de
 *  `connaissance.utils.js` — la même source que la consigne de l'IA et que le
 *  didacticiel. Ce que le directeur lit sur papier est mot pour mot ce que
 *  l'assistant répondra à l'écran.
 *
 *  RELANCER APRÈS CHAQUE ÉVOLUTION
 *  -------------------------------
 *      node generer-manuels.js
 *
 *  Les fichiers sont réécrits. Il n'y a jamais à corriger un document à la
 *  main : on corrige la base de connaissance, et on régénère.
 * ============================================================================
 */

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  PageBreak, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  LevelFormat, Footer, PageNumber, convertInchesToTwip
} = require('docx');

const {
  ORDRE_CONFIGURATION, PROCEDURES, LEXIQUE, MANUELS_ROLE
} = require('./connaissance.utils.js');

/* ==========================================================================
   Charte
   ========================================================================== */

const ENCRE = '23281F';
const OCRE = 'C98A3E';
const GRIS = '6B7269';
const ROUGE = 'B23A2E';
const CRAIE = 'FBFAF6';

const SORTIE = process.argv[2] || '.';

/* ==========================================================================
   Briques
   ========================================================================== */

const NUMEROTATION = {
  config: [
    {
      reference: 'puces',
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: '\u2022',
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 360, hanging: 240 } } }
      }]
    },
    {
      reference: 'puces-creuses',
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: '\u25E6',
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 620, hanging: 240 } } }
      }]
    }
  ]
};

function txt(contenu, opts = {}) {
  return new TextRun({
    text: contenu,
    bold: opts.bold, italics: opts.italics,
    color: opts.color || ENCRE,
    size: opts.size || 21,
    font: 'Calibri'
  });
}

/** Paragraphe courant. */
function p(contenu, opts = {}) {
  return new Paragraph({
    children: Array.isArray(contenu) ? contenu : [txt(contenu, opts)],
    spacing: { after: opts.after === undefined ? 110 : opts.after, line: 264 },
    alignment: opts.alignment,
    indent: opts.indent
  });
}

function titre1(t) {
  return new Paragraph({
    children: [new TextRun({ text: t, bold: true, size: 30, color: ENCRE, font: 'Calibri' })],
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: OCRE, space: 6 } }
  });
}

function titre2(t) {
  return new Paragraph({
    children: [new TextRun({ text: t, bold: true, size: 25, color: ENCRE, font: 'Calibri' })],
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 100 }
  });
}

function titre3(t) {
  return new Paragraph({
    children: [new TextRun({ text: t, bold: true, size: 22, color: OCRE, font: 'Calibri' })],
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 150, after: 70 }
  });
}

function puce(t, creuse) {
  return new Paragraph({
    children: [txt(t)],
    numbering: { reference: creuse ? 'puces-creuses' : 'puces', level: 0 },
    spacing: { after: 45, line: 252 }
  });
}

/**
 * Étape numérotée.
 *
 * Le numéro est écrit dans le texte plutôt que confié à une liste numérotée :
 * les compteurs de docx-js se poursuivent d'une liste à l'autre dans un même
 * document, et un manuel qui enchaîne quinze procédures verrait sa dernière
 * commencer à « 62. ».
 */
function etape(n, t) {
  return new Paragraph({
    children: [
      new TextRun({ text: String(n) + '.', bold: true, color: OCRE, size: 21, font: 'Calibri' }),
      new TextRun({ text: '\t' + t, size: 21, color: ENCRE, font: 'Calibri' })
    ],
    indent: { left: 400, hanging: 400 },
    spacing: { after: 80, line: 268 }
  });
}

/** Encadré : piège, avertissement, remarque. */
function encadre(etiquette, contenu, couleur) {
  const c = couleur || OCRE;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: c },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: c },
      left: { style: BorderStyle.SINGLE, size: 24, color: c },
      right: { style: BorderStyle.SINGLE, size: 4, color: c },
      insideHorizontal: { style: BorderStyle.NONE },
      insideVertical: { style: BorderStyle.NONE }
    },
    rows: [new TableRow({
      children: [new TableCell({
        width: { size: 9360, type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: CRAIE },
        margins: { top: 130, bottom: 130, left: 180, right: 160 },
        children: [
          new Paragraph({
            children: [new TextRun({
              text: etiquette.toUpperCase(), bold: true, size: 17,
              color: c, font: 'Calibri', characterSpacing: 20
            })],
            spacing: { after: 60 }
          }),
          new Paragraph({
            children: [txt(contenu, { size: 20 })],
            spacing: { line: 264 }
          })
        ]
      })]
    })]
  });
}

/** Ligne « Écran : … » sous un titre de procédure. */
function ligneEcran(valeur, etiquette) {
  return new Paragraph({
    children: [
      new TextRun({ text: (etiquette || 'Écran') + ' : ', bold: true, size: 19, color: GRIS, font: 'Calibri' }),
      new TextRun({ text: valeur, size: 19, color: GRIS, italics: true, font: 'Calibri' })
    ],
    spacing: { after: 110 }
  });
}

function saut() {
  return new Paragraph({ children: [new PageBreak()] });
}

/* --------------------------------------------------------------------------
   Page de couverture
   -------------------------------------------------------------------------- */
function couverture(surtitre, titre, sousTitre) {
  return [
    new Paragraph({ text: '', spacing: { after: 2400 } }),
    new Paragraph({
      children: [new TextRun({
        text: 'ARDOISE', bold: true, size: 26, color: OCRE,
        font: 'Calibri', characterSpacing: 90
      })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 80 }
    }),
    new Paragraph({
      children: [new TextRun({
        text: 'Plateforme de gestion scolaire', size: 19, color: GRIS, font: 'Calibri'
      })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 900 }
    }),
    new Paragraph({
      children: [new TextRun({
        text: surtitre.toUpperCase(), size: 19, color: GRIS,
        font: 'Calibri', characterSpacing: 50
      })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 140 }
    }),
    new Paragraph({
      children: [new TextRun({
        text: titre, bold: true, size: 48, color: ENCRE, font: 'Calibri'
      })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: OCRE, space: 14 } }
    }),
    new Paragraph({
      children: [new TextRun({ text: sousTitre, size: 21, color: GRIS, italics: true, font: 'Calibri' })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 260, after: 2600 }
    }),
    new Paragraph({
      children: [new TextRun({
        text: 'Document de référence — à conserver près du poste de travail',
        size: 17, color: GRIS, font: 'Calibri'
      })],
      alignment: AlignmentType.CENTER
    }),
    saut()
  ];
}

function piedDePage(mention) {
  return new Footer({
    children: [new Paragraph({
      children: [
        new TextRun({ text: mention + '   ', size: 16, color: GRIS, font: 'Calibri' }),
        new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GRIS, font: 'Calibri' })
      ],
      alignment: AlignmentType.RIGHT,
      border: { top: { style: BorderStyle.SINGLE, size: 4, color: 'DCDACE', space: 6 } }
    })]
  });
}

function document(mention, enfants) {
  return new Document({
    numbering: NUMEROTATION,
    styles: {
      default: {
        document: { run: { font: 'Calibri', size: 21, color: ENCRE } }
      }
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },          // A4
          margin: {
            top: convertInchesToTwip(0.9), bottom: convertInchesToTwip(0.85),
            left: convertInchesToTwip(0.95), right: convertInchesToTwip(0.95)
          }
        }
      },
      footers: { default: piedDePage(mention) },
      children: enfants
    }]
  });
}

async function ecrire(nom, doc) {
  const buffer = await Packer.toBuffer(doc);
  const chemin = path.join(SORTIE, nom);
  fs.writeFileSync(chemin, buffer);
  console.log('  ✓ ' + nom + '  (' + Math.round(buffer.length / 1024) + ' Ko)');
}

/* ==========================================================================
   1. GUIDE D'INSTALLATION
   ========================================================================== */

async function guideInstallation() {
  const c = [];

  c.push(...couverture(
    'Guide de configuration',
    "Installer votre\nétablissement",
    "Les quatorze étapes, écran par écran et champ par champ"
  ));

  /* ---- Avant de commencer ---- */
  c.push(titre1('Avant de commencer'));
  c.push(p("Ce guide décrit la mise en service complète d'un établissement sur Ardoise. Il suit l'ordre dans lequel les étapes doivent être faites — cet ordre n'est pas arbitraire : chaque étape a besoin des précédentes. Créer les classes avant l'année scolaire, par exemple, oblige à tout reprendre."));
  c.push(p("Chaque étape indique quatre choses : ce qu'il faut faire, le contenu exact de l'écran champ par champ, ce que l'étape commande ailleurs dans la plateforme, et le piège dans lequel les écoles tombent le plus souvent."));

  c.push(titre2('Combien de temps cela prend'));
  c.push(p("Comptez une demi-journée pour les étapes 1 à 9, qui posent la structure. L'inscription des élèves (étape 10) dépend de vos effectifs : quelques minutes par élève à la main, quelques minutes pour toute une classe si vous importez un fichier."));
  c.push(p("Les étapes 12, 13 et 14 — discipline, frais, emploi du temps — peuvent attendre la rentrée sans bloquer le reste. Les onze premières, non."));

  c.push(titre2('Qui fait quoi'));
  c.push(p("La plupart des étapes sont réservées au Directeur. Le Préfet des études peut prendre en charge la structure pédagogique — années, périodes, classes, cours — mais pas la création des comptes ni les paramètres généraux."));
  c.push(encadre(
    'À savoir avant de saisir quoi que ce soit',
    "Sur l'écran Paramètres, chaque bloc possède SON PROPRE bouton Enregistrer. Remplir trois blocs et n'en enregistrer qu'un est l'erreur la plus fréquente de toute l'installation, et elle ne laisse aucune trace visible : l'écran se recharge simplement avec les anciennes valeurs."
  ));

  /* ---- Vue d'ensemble ---- */
  c.push(saut());
  c.push(titre1("Les quatorze étapes en un coup d'œil"));
  c.push(p("Cochez au fur et à mesure. Une étape sautée se paie toujours plus tard, et rarement là où on l'attend.", { italics: true, color: GRIS }));

  const lignes = [new TableRow({
    tableHeader: true,
    children: [
      celluleEntete('', 500), celluleEntete('Étape', 3000),
      celluleEntete('Écran', 3800), celluleEntete('Qui', 2060)
    ]
  })];

  ORDRE_CONFIGURATION.forEach((e) => {
    lignes.push(new TableRow({
      children: [
        cellule('\u2610', 500, { alignment: AlignmentType.CENTER, size: 24 }),
        cellule(e.etape + '. ' + e.titre, 3000, { bold: true }),
        cellule(e.ecran, 3800, { size: 18 }),
        cellule(e.roles.map(r => (MANUELS_ROLE[r] ? MANUELS_ROLE[r].libelle : r)).join(', '), 2060, { size: 18, color: GRIS })
      ]
    }));
  });

  c.push(new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [500, 3000, 3800, 2060],
    rows: lignes
  }));

  /* ---- Le détail ---- */
  ORDRE_CONFIGURATION.forEach((e) => {
    c.push(saut());
    c.push(new Paragraph({
      children: [new TextRun({
        text: 'ÉTAPE ' + e.etape, bold: true, size: 18, color: OCRE,
        font: 'Calibri', characterSpacing: 60
      })],
      spacing: { after: 40 }
    }));
    c.push(titre1(e.titre));

    c.push(ligneEcran(e.ecran));
    c.push(ligneEcran(e.roles.map(r => (MANUELS_ROLE[r] ? MANUELS_ROLE[r].libelle : r)).join(', '), 'Qui peut le faire'));
    c.push(ligneEcran(e.avant, 'À faire avant'));

    c.push(titre3("Ce qu'il faut faire"));
    c.push(p(e.quoi));

    if (e.champs && e.champs.length) {
      c.push(titre3("Ce que contient l'écran"));
      e.champs.forEach((ch) => c.push(puce(ch)));
    }

    c.push(titre3('Pourquoi cette étape compte'));
    c.push(p(e.pourquoi));

    c.push(new Paragraph({ text: '', spacing: { after: 100 } }));
    c.push(encadre('Le piège', e.piege, ROUGE));
  });

  /* ---- Après l'installation ---- */
  c.push(saut());
  c.push(titre1("Une fois l'installation terminée"));

  c.push(titre2('Vérifiez avant la rentrée'));
  [
    "Ouvrez l'écran Classes : plus aucune classe ne doit afficher « niveau manquant ». Sans niveau, la promotion de fin d'année ne pourra pas s'exécuter.",
    "Ouvrez l'écran Cours : aucun cours ne doit être signalé sans maximum d'examen, sauf ceux qui n'ont réellement pas d'examen.",
    "Ouvrez l'écran Année scolaire : chaque période doit avoir une date de début et une date de fin.",
    "Vérifiez qu'aucun élève actif n'est sans classe : il n'apparaîtrait ni dans les listes, ni dans les bulletins.",
    "Demandez à un enseignant de se connecter et d'ouvrir « Mes cours ». Un écran vide signifie que l'attribution n'a pas été faite.",
    "Générez UN bulletin réel et regardez-le avant toute génération de masse.",
    "Déclarez les jours fériés au Calendrier AVANT la rentrée : les absences saisies sur un jour requalifié férié ne se corrigent pas toutes seules."
  ].forEach((v) => c.push(puce(v)));

  c.push(titre2("Le guide reste disponible à l'écran"));
  c.push(p("Le bouton d'aide, en bas de chaque écran, et l'entrée « Aide & Tutoriels » du menu ouvrent le même parcours, mis à jour en temps réel d'après l'état réel de votre établissement. Il sait dire ce qui reste à faire, et vous montrer où cliquer."));
  c.push(p("L'onglet « Apprendre Ardoise » de ce même panneau regroupe les modes d'emploi correspondant à votre rôle."));

  c.push(titre2('Distribuez les manuels'));
  c.push(p("Chaque rôle dispose d'un manuel distinct, qui ne décrit que ses écrans et ses gestes. Remettez à chacun le sien : un professeur à qui l'on donne le manuel du directeur ne lira ni l'un ni l'autre."));
  Object.keys(MANUELS_ROLE)
    .filter((r) => r !== 'super_admin' && r !== 'parent' && r !== 'eleve')
    .forEach((r) => c.push(puce('Manuel — ' + MANUELS_ROLE[r].libelle)));
  c.push(puce('Fiche — Parents et élèves'));

  await ecrire('Ardoise - Guide d\'installation.docx',
    document("Ardoise — Guide d'installation", c));
}

function celluleEntete(t, largeur) {
  return new TableCell({
    width: { size: largeur, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill: ENCRE },
    margins: { top: 90, bottom: 90, left: 120, right: 100 },
    children: [new Paragraph({
      children: [new TextRun({ text: t, bold: true, size: 18, color: 'FFFFFF', font: 'Calibri' })]
    })]
  });
}

function cellule(t, largeur, opts = {}) {
  return new TableCell({
    width: { size: largeur, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 120, right: 100 },
    children: [new Paragraph({
      children: [new TextRun({
        text: t, bold: opts.bold, size: opts.size || 19,
        color: opts.color || ENCRE, font: 'Calibri'
      })],
      alignment: opts.alignment
    })]
  });
}

/* ==========================================================================
   2. MANUELS DE RÔLE
   ========================================================================== */

/** Les procédures d'un rôle, dans l'ordre d'utilité puis par rattrapage. */
function proceduresDuRole(code) {
  const m = MANUELS_ROLE[code];
  const prioritaires = (m.procedures || []).filter((x) => PROCEDURES[x]);
  const restantes = Object.keys(PROCEDURES).filter((x) =>
    !prioritaires.includes(x) && PROCEDURES[x].roles.includes(code));
  return prioritaires.concat(restantes);
}

async function manuelRole(code) {
  const m = MANUELS_ROLE[code];
  const c = [];

  c.push(...couverture("Manuel d'utilisation", m.libelle, "Ce que vous faites, et comment le faire"));

  /* ---- Votre rôle ---- */
  c.push(titre1('Votre rôle'));
  c.push(p(m.perimetre));

  c.push(titre2('Ce qui ne relève pas de vous'));
  c.push(p(m.ne_peut_pas));
  c.push(p("Ce n'est pas une limite technique mais une répartition des responsabilités. Si vous avez besoin d'une de ces actions, adressez-vous à la personne concernée plutôt que de chercher un réglage : il n'y en a pas.", { italics: true, color: GRIS, size: 19 }));

  c.push(titre2('Vos écrans'));
  m.ecrans.forEach((e) => c.push(puce(e)));
  c.push(p("Un écran absent de votre menu peut être simplement rangé, et non interdit. Ouvrez « Mon profil » puis « Tous les menus » pour vérifier avant de conclure à un problème de droits.", { italics: true, color: GRIS, size: 19 }));

  /* ---- Premiers pas ---- */
  if (m.premiers_pas && m.premiers_pas.length) {
    c.push(titre1('Vos premiers pas'));
    c.push(p("À faire dans l'ordre, une seule fois, le jour où vous prenez la plateforme en main."));
    m.premiers_pas.forEach((v, i) => c.push(etape(i + 1, v)));
  }

  /* ---- Configuration, pour les rôles concernés ---- */
  const etapesConfig = ORDRE_CONFIGURATION.filter((e) => e.roles.includes(code));
  if (etapesConfig.length) {
    c.push(saut());
    c.push(titre1("Les étapes de configuration qui vous incombent"));
    c.push(p("Le détail complet — champ par champ — se trouve dans le Guide d'installation. Ce rappel sert à savoir ce qui vous revient et dans quel ordre."));

    etapesConfig.forEach((e) => {
      c.push(titre3('Étape ' + e.etape + ' — ' + e.titre));
      c.push(ligneEcran(e.ecran));
      c.push(p(e.quoi));
      c.push(p([
        new TextRun({ text: 'Piège : ', bold: true, size: 19, color: ROUGE, font: 'Calibri' }),
        new TextRun({ text: e.piege, size: 19, color: ENCRE, font: 'Calibri' })
      ], { after: 160 }));
    });
  }

  /* ---- Procédures ---- */
  const codes = proceduresDuRole(code);
  if (codes.length) {
    c.push(saut());
    c.push(titre1('Vos procédures'));
    c.push(p("Chaque procédure décrit un geste complet, du premier clic au dernier. Les écrans et les boutons sont nommés exactement comme ils apparaissent à l'écran."));

    codes.forEach((cle) => {
      const proc = PROCEDURES[cle];
      c.push(titre2(proc.titre));
      c.push(ligneEcran(proc.ecran));
      proc.etapes.forEach((v, i) => c.push(etape(i + 1, v)));
      if (proc.remarque) {
        c.push(new Paragraph({ text: '', spacing: { after: 60 } }));
        c.push(encadre('À retenir', proc.remarque));
        c.push(new Paragraph({ text: '', spacing: { after: 140 } }));
      }
    });
  }

  /* ---- Lexique ---- */
  c.push(saut());
  c.push(titre1('Vocabulaire de la plateforme'));
  c.push(p("Les mots ci-dessous ont un sens précis dans Ardoise, parfois différent de l'usage courant. C'est la source de malentendus la plus fréquente."));
  Object.keys(LEXIQUE).forEach((mot) => {
    c.push(new Paragraph({
      children: [
        new TextRun({ text: mot.charAt(0).toUpperCase() + mot.slice(1) + ' — ', bold: true, size: 20, color: ENCRE, font: 'Calibri' }),
        new TextRun({ text: LEXIQUE[mot], size: 20, color: ENCRE, font: 'Calibri' })
      ],
      spacing: { after: 110, line: 268 },
      indent: { left: 280, hanging: 280 }
    }));
  });

  /* ---- Aide ---- */
  c.push(titre1('En cas de doute'));
  c.push(p("Le bouton d'aide, en bas à droite de chaque écran, et l'entrée « Aide & Tutoriels » du menu ouvrent un guide qui connaît votre rôle et l'état réel de votre établissement. Il répond aux questions et peut vous montrer où cliquer, directement sur l'écran."));
  c.push(p("L'onglet « Apprendre Ardoise » de ce panneau reprend le contenu de ce manuel, tenu à jour."));
  c.push(p("Ce document et l'assistant sont produits à partir de la même source : ils ne peuvent pas se contredire."));

  const nom = 'Ardoise - Manuel ' + m.libelle.replace(/[\/:]/g, '-') + '.docx';
  await ecrire(nom, document('Ardoise — Manuel ' + m.libelle, c));
}

/* ==========================================================================
   3. FICHE PARENTS ET ÉLÈVES
   ========================================================================== */

async function ficheParents() {
  const c = [];
  c.push(...couverture('Fiche d\'information', 'Parents et élèves',
    "Suivre la scolarité de votre enfant"));

  c.push(titre1('Ce que vous pouvez consulter'));
  c.push(p(MANUELS_ROLE.parent.perimetre));

  c.push(titre2("Comment accéder aux résultats"));
  [
    "Demandez à l'école son adresse de site public et votre code d'accès.",
    "Ouvrez le site, saisissez le code d'accès de votre enfant.",
    "Seuls les résultats que l'école a explicitement publiés sont visibles : rien ne sort automatiquement."
  ].forEach((v, i) => c.push(etape(i + 1, v)));

  c.push(titre2("Recevoir les messages de l'école"));
  c.push(p("Les parents n'ont pas de compte de travail sur la plateforme. L'école vous joint par courriel, à l'adresse enregistrée sur la fiche de votre enfant."));
  c.push(encadre(
    'Vérifiez votre adresse électronique',
    "Si vous ne recevez rien, c'est presque toujours que l'adresse manque ou comporte une erreur sur la fiche de votre enfant. Demandez au secrétariat de la vérifier : c'est la seule adresse par laquelle l'école peut vous écrire."
  ));

  c.push(titre1('Ce que vous devez signaler'));
  [
    "Tout changement d'adresse électronique ou de numéro de téléphone.",
    "Un changement de responsable légal.",
    "Une absence prévue, afin qu'elle soit enregistrée comme justifiée.",
    "Une erreur sur l'identité de votre enfant — nom, postnom, date de naissance — car elle se retrouvera sur ses bulletins et documents officiels."
  ].forEach((v) => c.push(puce(v)));

  c.push(titre1("Comprendre le bulletin"));
  const mots = ['capital de conduite', 'période', "période d'examen", "maximum d'examen",
                'seuil de promotion', 'seuil de redoublement', 'repêchage'];
  mots.forEach((mot) => {
    if (!LEXIQUE[mot]) return;
    c.push(new Paragraph({
      children: [
        new TextRun({ text: mot.charAt(0).toUpperCase() + mot.slice(1) + ' — ', bold: true, size: 20, color: ENCRE, font: 'Calibri' }),
        new TextRun({ text: LEXIQUE[mot], size: 20, color: ENCRE, font: 'Calibri' })
      ],
      spacing: { after: 110, line: 268 },
      indent: { left: 280, hanging: 280 }
    }));
  });

  await ecrire('Ardoise - Fiche Parents et eleves.docx',
    document('Ardoise — Parents et élèves', c));
}

/* ==========================================================================
   Exécution
   ========================================================================== */

(async function () {
  console.log('\nGénération des manuels Ardoise\n');

  console.log('Guide :');
  await guideInstallation();

  console.log('\nManuels de rôle :');
  const roles = Object.keys(MANUELS_ROLE)
    .filter((r) => !['super_admin', 'parent', 'eleve'].includes(r));
  for (const r of roles) await manuelRole(r);

  console.log('\nFiche :');
  await ficheParents();

  console.log('\n' + (roles.length + 2) + ' documents générés.\n');
})();
