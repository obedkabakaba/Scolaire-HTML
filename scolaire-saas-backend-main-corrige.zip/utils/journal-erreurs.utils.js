/**
 * ARDOISE — JOURNAL D'ERREURS PERSISTANT
 * ===========================================================================
 *
 * LE PROBLÈME QU'IL RÉSOUT
 * ------------------------
 * Deux trous, refermés ici par le même mécanisme.
 *
 * 1. CÔTÉ NAVIGATEUR. Seuls `super-admin-noyau.js` et l'espace Super Admin
 *    posaient des capteurs d'erreurs globaux. Une exception JavaScript chez un
 *    directeur, un préfet, un professeur ou un comptable ne laissait
 *    strictement aucune trace : l'écran restait blanc, la personne appelait au
 *    téléphone, et il n'y avait rien à regarder.
 *
 * 2. CÔTÉ SERVEUR. `metriques.middleware.js` garde route, statut et durée —
 *    en mémoire. Un redéploiement Render efface tout, et la CAUSE de l'erreur
 *    n'y a jamais figuré. Les dizaines de `catch` qui répondent
 *    `{ message: "Erreur serveur." }` jetaient la pile d'appels.
 *
 * CE QU'IL NE STOCKE JAMAIS
 * -------------------------
 * Mot de passe, jeton JWT, clé d'API, secret cron, en-tête Authorization,
 * contenu d'une requête SQL sensible, donnée pédagogique ou personnelle
 * inutile. Le masquage est appliqué à TOUT ce qui entre — message, pile,
 * métadonnées — et non aux seuls champs qu'on a pensé à nommer. La liste des
 * motifs est en un seul endroit, ci-dessous, et le test la vérifie.
 *
 * REGROUPEMENT
 * ------------
 * Une empreinte par défaut, pas par occurrence. « Élève 8c1f-… introuvable »
 * et « Élève 4b2a-… introuvable » sont le même défaut : les identifiants et
 * les nombres sont neutralisés avant hachage. Un défaut qui revient incrémente
 * un compteur ; un défaut marqué résolu qui réapparaît ROUVRE.
 */

const crypto = require('crypto');
const { runWithTenant } = require('../config/db');

const SUPER = { isSuperAdmin: true };

/* =========================================================================
   1. MASQUAGE DES SECRETS
   ========================================================================= */

/**
 * Motifs neutralisés dans tout texte enregistré.
 *
 * ORDRE IMPORTANT : les motifs les plus spécifiques d'abord. `Bearer eyJ…`
 * doit être attrapé par la règle « Authorization » avant que la règle « jeton
 * JWT nu » ne le voie, sinon le mot « Bearer » resterait en clair devant un
 * masque — inoffensif, mais suffisant pour faire croire à une fuite lors d'une
 * relecture.
 *
 * Chaque motif remplace par une ÉTIQUETTE plutôt que par des astérisques : le
 * Super Admin doit pouvoir lire « il y avait un jeton ici » sans avoir le
 * jeton. C'est ce qui distingue un journal exploitable d'un journal caviardé.
 */
const MOTIFS_SECRETS = [
  /* VALEURS ENTRE GUILLEMETS : LE PIÈGE À NE PAS REFAIRE

     La première version de ces motifs finissait par `["']?[^\s"',;}]+` —
     guillemet ouvrant facultatif, puis « tout sauf un guillemet ». Sur du texte
     brut (`mot_de_passe=Secret`) elle fonctionnait. Sur du JSON, qui est la
     forme dans laquelle 90 % des corps de requête arrivent ici, elle échouait
     de la pire façon possible :

         {"password":"MonMotDePasse2026!"}
          ^^^^^^^^^^^^^  capturé          ^^^^^^^^^^^^^^^^^^ laissé EN CLAIR

     La classe s'arrêtait au guillemet OUVRANT de la valeur. Le résultat
     ressemblait à `password: [masqué]MonMotDePasse2026!"` — un texte qui a
     toutes les apparences d'un masquage réussi, et qui publie le secret juste
     derrière l'étiquette. C'est exactement le genre de défaut qu'une relecture
     rapide valide.

     La correction consomme la valeur ENTIÈRE, guillemets compris, en traitant
     les trois formes possibles : "…", '…', ou nue. */
  // En-têtes d'authentification, sous toutes leurs formes d'écriture.
  [/["']?\b(authorization|x-api-key|x-auth-token|x-audit-secret|cookie|set-cookie)\b["']?\s*[:=]\s*(?:"[^"]*"|'[^']*'|[^\s"',;}]+)/gi,
   '$1: [masqué]'],
  [/\bBearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, 'Bearer [jeton masqué]'],

  // Jetons JWT nus : trois segments base64url séparés par des points.
  [/\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}/g, '[jwt masqué]'],

  // Champs nommés dans un corps JSON ou une chaîne de requête.
  [/["']?\b(mot_de_passe|mot_de_passe_hash|motdepasse|password|pwd|passe|secret|api_key|apikey|cle_api|token|refresh_token|access_token|cron_secret|secret_cron)\b["']?\s*[:=]\s*(?:"[^"]*"|'[^']*'|[^\s"',;}&]+)/gi,
   '$1: [masqué]'],

  // Chaînes de connexion : postgres://user:motdepasse@hote/base
  [/\b([a-z+]{3,12}):\/\/[^\s:@/]+:[^\s@/]+@/gi, '$1://[identifiants masqués]@'],

  // Clés d'API des fournisseurs employés par la plateforme.
  [/\bsk-[A-Za-z0-9_-]{16,}/g, '[clé api masquée]'],
  [/\bsk_(live|test)_[A-Za-z0-9]{10,}/gi, '[clé api masquée]'],

  // Adresses électroniques : donnée personnelle, sans valeur de diagnostic.
  // On conserve le domaine, qui aide parfois (« tous les cas viennent de
  // gmail »), et on retire l'identité.
  [/\b[A-Za-z0-9._%+-]{1,64}@([A-Za-z0-9.-]+\.[A-Za-z]{2,})/g, '[email]@$1'],

  // Numéros de téléphone congolais et internationaux longs.
  [/\+?\d[\d\s.-]{9,17}\d/g, '[téléphone]']
];

/**
 * Neutralise tout secret d'un texte, et le borne.
 *
 * `limite` est un plafond de STOCKAGE, pas de lisibilité : une pile d'appels
 * de huit kilo-octets contient tout ce qui sert dans ses vingt premières
 * lignes, et le reste ne ferait que grossir la table.
 */
function masquer(texte, limite = 2000) {
  if (texte === null || texte === undefined) return null;
  let sortie = String(texte);
  for (const [motif, remplacement] of MOTIFS_SECRETS) {
    sortie = sortie.replace(motif, remplacement);
  }
  return sortie.slice(0, limite);
}

/**
 * Masque récursivement un objet de métadonnées.
 *
 * Les CLÉS sensibles sont retirées entièrement, en plus du masquage des
 * valeurs : une clé nommée `mot_de_passe` dont la valeur ne ressemble à rien
 * de reconnaissable passerait tous les motifs ci-dessus. Le nom de la clé est
 * ici l'indice le plus fiable.
 */
const CLES_INTERDITES = /^(mot_de_passe|mot_de_passe_hash|password|pwd|passe|secret|token|access_token|refresh_token|api_key|apikey|cle_api|authorization|cookie|cron_secret|jwt)$/i;

function masquerObjet(valeur, profondeur = 0) {
  if (profondeur > 4) return '[trop profond]';
  if (valeur === null || valeur === undefined) return null;
  if (typeof valeur === 'number' || typeof valeur === 'boolean') return valeur;
  if (typeof valeur === 'string') return masquer(valeur, 500);
  if (Array.isArray(valeur)) return valeur.slice(0, 20).map((v) => masquerObjet(v, profondeur + 1));
  if (typeof valeur !== 'object') return null;

  const sortie = {};
  let n = 0;
  for (const [cle, v] of Object.entries(valeur)) {
    if (n++ >= 30) break;                       // borne dure : pas de corps entier
    if (CLES_INTERDITES.test(cle)) { sortie[cle] = '[masqué]'; continue; }
    sortie[cle] = masquerObjet(v, profondeur + 1);
  }
  return sortie;
}

/* =========================================================================
   2. EMPREINTE DE REGROUPEMENT
   ========================================================================= */

const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;

/**
 * Empreinte stable d'un défaut.
 *
 * Volontairement calculée sur le MESSAGE NORMALISÉ et le CONTEXTE, jamais sur
 * la pile complète : une pile change au moindre déploiement (numéros de ligne),
 * et le même défaut se dédoublerait à chaque mise en production. On perdrait
 * exactement l'information que le compteur d'occurrences apporte.
 */
function empreinte({ message, page, chemin, origine, methode }) {
  const normalise = String(message || '')
    .replace(UUID, ':id')
    .replace(/\d+/g, ':n')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 300)
    .toLowerCase();

  const contexte = String(chemin || page || '')
    .split('?')[0]
    .replace(UUID, ':id')
    .replace(/\/\d+/g, '/:n')
    .toLowerCase();

  return crypto.createHash('sha256')
    .update(`${origine || 'backend'}|${methode || ''}|${contexte}|${normalise}`)
    .digest('hex')
    .slice(0, 40);
}

/* =========================================================================
   3. CE QUI N'EST PAS UN BUG
   ========================================================================= */

/**
 * Refus métier ATTENDUS. Les enregistrer comme défauts noierait le centre de
 * bugs sous le bruit normal de la plateforme et, plus grave, rendrait invisible
 * le vrai défaut au milieu de dix mille 401.
 *
 *   401  jeton expiré — arrive à chaque session qui dure
 *   402  offre insuffisante — c'est une INVITATION commerciale, pas une panne
 *   403  rôle insuffisant — le contrôle d'accès fait son travail
 *   404  ressource absente — souvent une URL tapée à la main
 *   409  conflit — doublon refusé, c'est une règle métier
 *   422  validation — l'utilisateur a mal rempli un champ
 *   429  limitation de débit — la protection fonctionne
 */
const STATUTS_ATTENDUS = new Set([400, 401, 402, 403, 404, 405, 409, 410, 422, 429]);

function estRefusAttendu(codeHttp) {
  const n = Number(codeHttp);
  if (!Number.isFinite(n)) return false;
  return STATUTS_ATTENDUS.has(n);
}

/* =========================================================================
   4. ANTI-BOUCLE
   ========================================================================= */

/**
 * Fenêtre de garde par empreinte.
 *
 * Une page qui plante dans son gestionnaire d'erreur peut signaler la même
 * erreur des milliers de fois par minute. Sans garde, le premier défaut de ce
 * type remplit la table et fait tomber la base — l'outil de diagnostic devient
 * la panne. On accepte le premier signalement, puis on compte en mémoire et on
 * n'écrit qu'une fois par fenêtre.
 *
 * Conséquence assumée : le compteur d'occurrences sous-estime les rafales. Il
 * dit « ce défaut est revenu », ce qui est l'information utile ; il ne prétend
 * pas être un compteur exact.
 */
const FENETRE_ANTI_BOUCLE_MS = 30 * 1000;
const MAX_PAR_FENETRE = 3;
const vues = new Map();

function tropFrequent(cle) {
  const maintenant = Date.now();
  const e = vues.get(cle);
  if (!e || maintenant - e.debut > FENETRE_ANTI_BOUCLE_MS) {
    vues.set(cle, { debut: maintenant, nb: 1 });
    return false;
  }
  e.nb++;
  return e.nb > MAX_PAR_FENETRE;
}

// Purge : sans elle, la table grossirait indéfiniment sur un serveur qui ne
// redémarre pas.
setInterval(() => {
  const maintenant = Date.now();
  for (const [cle, v] of vues) {
    if (maintenant - v.debut > FENETRE_ANTI_BOUCLE_MS * 4) vues.delete(cle);
  }
}, FENETRE_ANTI_BOUCLE_MS * 4).unref();

/* =========================================================================
   5. ENREGISTREMENT
   ========================================================================= */

const GRAVITES = ['basse', 'moyenne', 'haute', 'critique'];

/**
 * Enregistre un défaut, ou incrémente celui qui existe déjà.
 *
 * NE LÈVE JAMAIS. C'est la propriété la plus importante de cette fonction :
 * elle est appelée depuis des gestionnaires d'erreurs et des blocs `catch`.
 * Une exception ici transformerait une erreur en deux, dont la seconde
 * n'aurait plus de gestionnaire.
 *
 * @param {object} entree
 * @param {string} entree.message      obligatoire
 * @param {string} [entree.origine]    'frontend' | 'backend' | 'tache' | 'audit'
 * @param {string} [entree.ecoleId]    TOUJOURS issu du jeton, jamais du corps
 * @param {string} [entree.utilisateurId]
 * @returns {Promise<{id, occurrences, statut}|null>} `null` si non enregistré
 */
async function enregistrer(entree = {}) {
  try {
    const message = masquer(entree.message, 2000);
    if (!message || !message.trim()) return null;

    // Un refus métier attendu n'est pas un défaut. On sort AVANT toute
    // écriture, et sans bruit : ce n'est pas une anomalie.
    if (estRefusAttendu(entree.codeHttp)) return null;

    const origine = ['frontend', 'backend', 'tache', 'service_externe', 'audit']
      .includes(entree.origine) ? entree.origine : 'backend';

    const cle = empreinte({
      message, page: entree.page, chemin: entree.chemin, origine, methode: entree.methode
    });

    if (tropFrequent(cle)) return null;

    const gravite = GRAVITES.includes(entree.gravite) ? entree.gravite : 'moyenne';

    return await runWithTenant(SUPER, async (client) => {
      const r = await client.query(`
        INSERT INTO bugs_plateforme
          (ecole_id, utilisateur_id, empreinte, origine, page, methode, chemin, code_http,
           navigateur, systeme, message, stack, gravite, metadata)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14::jsonb)
        ON CONFLICT (empreinte) DO UPDATE SET
          occurrences = bugs_plateforme.occurrences + 1,
          derniere_occurrence = now(),
          -- Un défaut marqué résolu qui réapparaît ROUVRE. Le masquer
          -- reviendrait à perdre l'information la plus utile du centre :
          -- « le correctif n'a pas tenu ».
          statut = CASE WHEN bugs_plateforme.statut IN ('resolu','ignore')
                        THEN 'ouvert' ELSE bugs_plateforme.statut END,
          resolu_par = CASE WHEN bugs_plateforme.statut IN ('resolu','ignore')
                            THEN NULL ELSE bugs_plateforme.resolu_par END,
          resolu_at = CASE WHEN bugs_plateforme.statut IN ('resolu','ignore')
                           THEN NULL ELSE bugs_plateforme.resolu_at END
        RETURNING id, occurrences, statut`,
        [
          entree.ecoleId || null,
          entree.utilisateurId || null,
          cle,
          origine,
          masquer(entree.page, 200),
          entree.methode ? String(entree.methode).slice(0, 10).toUpperCase() : null,
          masquer(entree.chemin, 300),
          Number.isFinite(Number(entree.codeHttp)) ? Number(entree.codeHttp) : null,
          masquer(entree.navigateur, 300),
          masquer(entree.systeme, 120),
          message,
          masquer(entree.stack, 8000),
          gravite,
          JSON.stringify(masquerObjet(entree.metadata || {}) || {})
        ]);
      return r.rows[0] || null;
    });
  } catch (err) {
    // Dernier recours. On ne relance pas, on ne casse rien, et on n'écrit pas
    // le contenu de l'entrée dans les journaux — il pourrait contenir ce que
    // cette fonction avait justement pour rôle de masquer.
    console.error('[journal-erreurs] Enregistrement impossible :', err.message);
    return null;
  }
}

/**
 * Gravité déduite d'un statut HTTP. Utilisée par le capteur automatique, pour
 * que le centre de bugs se trie tout seul plutôt que d'afficher mille défauts
 * « moyens ».
 */
function graviteDepuisStatut(statut) {
  const n = Number(statut);
  if (n >= 500 && n < 502) return 'haute';       // 500 : notre code a lâché
  if (n === 502 || n === 503 || n === 504) return 'moyenne';  // dépendance externe
  return 'moyenne';
}

module.exports = {
  enregistrer,
  masquer,
  masquerObjet,
  empreinte,
  estRefusAttendu,
  graviteDepuisStatut,
  STATUTS_ATTENDUS,
  MOTIFS_SECRETS
};
