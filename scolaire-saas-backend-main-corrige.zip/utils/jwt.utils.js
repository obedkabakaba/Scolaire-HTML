const jwt = require('jsonwebtoken');
const crypto = require('crypto');

function generateAccessToken(user) {
  // user = { id, ecole_id, roles: [...] }
  return jwt.sign(
    {
      sub: user.id,
      ecole_id: user.ecole_id,
      roles: user.roles,
      is_superadmin: user.roles.includes('super_admin')
    },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );
}

/**
 * Jeton du mode « Voir comme » (espace Super Administrateur).
 * ---------------------------------------------------------------------------
 * Signé avec le même secret que les jetons ordinaires, et pour cause : il doit
 * traverser exactement la même chaîne d'authentification. Toute la subtilité
 * tient dans son contenu.
 *
 *   · `sub` reste l'identifiant du Super Admin. Le journal d'audit continue
 *     donc de nommer la personne réelle, jamais l'identité empruntée. C'est
 *     non négociable : une trace d'audit qui désigne le mauvais acteur est
 *     pire qu'une absence de trace.
 *   · `ecole_id` est celui de l'école observée, et `is_superadmin` vaut false.
 *     Les policies RLS retombent alors sur cette seule école : l'observateur
 *     voit ce que voit un directeur de l'établissement, pas davantage.
 *   · `observation: true` est lu par `verrouObservation` et interdit toute
 *     méthode d'écriture, sur n'importe quelle route.
 *
 * Durée courte, et aucun refresh token associé : il n'existe pas de session en
 * base pour ce jeton, donc /auth/refresh n'a rien à quoi le rattacher. Une
 * observation oubliée s'éteint toute seule.
 */
function generateObservationToken({ observateurId, ecoleId, role, dureeMinutes = 30 }) {
  return jwt.sign(
    {
      sub: observateurId,
      ecole_id: ecoleId,
      roles: [role],
      is_superadmin: false,
      observation: true,
      observateur: observateurId
    },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: `${Math.min(120, Math.max(5, dureeMinutes))}m` }
  );
}

function verifyAccessToken(token) {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET);
}

function generateRefreshTokenRaw() {
  // Token opaque aléatoire (pas un JWT) — on ne stocke que son hash en base
  return crypto.randomBytes(48).toString('hex');
}

function hashRefreshToken(rawToken) {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

module.exports = {
  generateAccessToken,
  generateObservationToken,
  verifyAccessToken,
  generateRefreshTokenRaw,
  hashRefreshToken
};
