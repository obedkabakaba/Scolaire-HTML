const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/*
 * ===========================================================================
 *  CALCUL DES MOYENNES — depuis les NOTES, jamais depuis `bulletins.pourcentage`
 * ===========================================================================
 *
 * POURQUOI CE CHANGEMENT
 * ----------------------
 * Les rapports lisaient `bulletins.pourcentage`, une valeur MATÉRIALISÉE. Deux
 * conséquences, toutes deux constatées comme des « chiffres bizarres » :
 *
 *   1. Cette valeur n'existe que si un bulletin a été généré. Une classe notée
 *      mais dont les bulletins n'ont pas encore été produits sortait des
 *      rapports sans laisser de trace — la moyenne d'école portait alors sur
 *      un sous-ensemble arbitraire d'élèves.
 *   2. Les bulletins produits AVANT le correctif du dénominateur portent
 *      encore un pourcentage calculé sur les seuls cours notés. Tant que
 *      `POST /notes/recalculer` n'a pas été passé sur chacun, ils restent faux
 *      — et les rapports propageaient cette erreur.
 *
 * LA RÈGLE MÉTIER, APPLIQUÉE ICI SANS INTERMÉDIAIRE
 * -------------------------------------------------
 *   pourcentage = total obtenu / total des maxima × 100
 *
 * Le dénominateur est le total des maxima de TOUS LES COURS DE LA CLASSE pour
 * la période, pas seulement de ceux où une cote a été saisie. Un cours non noté
 * compte pour zéro : c'est ce qui distingue « l'élève n'a pas composé » de
 * « le cours n'existe pas ».
 *
 * DEUX PRÉCISIONS QUI CHANGENT TOUT
 * ---------------------------------
 * · Sur une période d'EXAMEN, le maximum d'un cours suit EXACTEMENT la même
 *   règle que sur les bulletins officiels (voir `bulletin-secondaire-rdc.
 *   template.js` et `bulletin-assemblage-officiel.js`) :
 *     maximum_examen NON RENSEIGNÉ (NULL) → 2 × le maximum de période
 *     maximum_examen = 0                  → pas d'examen dans ce cours
 *   Confondre les deux traite un barème simplement pas encore configuré comme
 *   une absence d'examen : la classe entière disparaissait alors du rapport
 *   (dénominateur nul), avec le message trompeur « aucune classe d'élèves
 *   actifs », alors que la vraie cause était un cours dont personne n'avait
 *   encore renseigné le maximum d'examen — le cas le plus courant, puisque
 *   `NULL` est la valeur par défaut à la création d'un cours.
 *
 * · Sur PLUSIEURS périodes — et donc sur l'année entière — on additionne les
 *   totaux et on additionne les maxima. On ne fait JAMAIS la moyenne des
 *   pourcentages de chaque période : deux périodes de barèmes différents n'ont
 *   pas le même poids, et les moyenner revient à décider qu'elles en ont un.
 *
 * LE CAS DE L'ÉLÈVE ARRIVÉ EN COURS D'ANNÉE
 * -----------------------------------------
 * Une période n'entre dans le dénominateur d'un élève que s'il y a AU MOINS UNE
 * note à son nom sur cette période. Sans cette règle, un élève inscrit en
 * février serait noté sur toute l'année, périodes d'avant comprises, et
 * apparaîtrait catastrophique sans avoir rien manqué. La règle vaut aussi pour
 * les périodes futures : en octobre, l'année entière ne se calcule que sur ce
 * qui a réellement été enseigné.
 */

/*
 * L'ÉLÈVE QUE PERSONNE N'A ENCORE COTÉ
 * ------------------------------------
 * Un rapport qui ne renvoie AUCUNE ligne tant qu'aucune note n'est saisie est
 * illisible : l'écran affiche « aucun bulletin calculé », ce qui se lit comme
 * une panne alors que la réponse juste est « rien n'est encore coté, tout le
 * monde est à zéro ». C'est exactement la même règle que pour le dénominateur :
 * ce qui n'a pas été coté vaut zéro, il ne disparaît pas.
 *
 * `inclureNonNotes` fait donc entrer les élèves sans aucune note de la portée,
 * avec un total obtenu de 0 et, au dénominateur, la totalité des maxima de leur
 * classe sur la portée. Ils sont marqués `sans_note` pour que l'écran puisse
 * dire pourquoi ils sont à zéro.
 *
 * IL EST DÉSACTIVÉ PAR DÉFAUT, et n'est demandé que par les écrans de rapport,
 * seuls capables d'expliquer ce zéro à celui qui le lit. Ailleurs il ferait des
 * dégâts silencieux :
 *   · au repêchage, un élève non encore coté serait déclaré à 0 % et proposé
 *     au jury comme un élève en échec ;
 *   · dans le parcours d'un élève, la courbe plongerait à zéro sur chaque
 *     période pas encore corrigée, comme s'il s'était effondré ;
 *   · sur le tableau de bord, la moyenne d'école s'écroulerait chaque début de
 *     période, sans une ligne pour dire pourquoi.
 *
 * L'exception de l'élève arrivé en cours d'année tient toujours : elle ne
 * concerne que les élèves ayant DES notes, dont on ne compte que les périodes
 * réellement suivies. Un élève sans aucune note ne peut pas, lui, être départagé
 * — il est à zéro sur toute la portée.
 */

/**
 * Pourcentage par élève sur la portée demandée, calculé depuis les notes.
 *
 * @param {object} options
 * @param {boolean} options.inclureNonNotes  fait apparaître à 0 les élèves sans
 *        aucune note dans la portée (défaut : true).
 */
async function pourcentagesParEleve(client, anneeId, portee, options = {}) {
  const ids = portee.periodeIds || [];
  if (portee.type === 'aucune' || ids.length === 0) return [];
  const inclureNonNotes = options.inclureNonNotes === true;
  // Filtre de cycle : une école qui tient primaire et humanités ne doit pas
  // voir une moyenne d'établissement où les deux se mélangent — les barèmes
  // et les programmes n'ont rien de comparable.
  const cycle = options.cycle || null;

  const r = await client.query(
    `WITH periodes_portee AS (
       SELECT p.id, p.type::text AS type, p.cycle::text AS cycle
         FROM periodes p
        WHERE p.id = ANY($2::uuid[]) AND p.ecole_id = ${CURRENT_ECOLE}
     ),
     -- Maxima de TOUS les cours de la classe, pour chaque période retenue.
     -- C'est le dénominateur : il ne dépend pas de ce qui a été saisi.
     --
     -- Une période n'est retenue pour une classe que si elle relève du MÊME
     -- cycle : dans une école qui tient primaire et humanités, une portée
     -- large (« tous les examens », « année complète ») ramène les périodes
     -- des deux côtés, et sans cette condition une classe du secondaire se
     -- verrait attribuer le barème des sessions du primaire par-dessus le
     -- sien. Un cycle non renseigné vaut « les deux », comme partout ailleurs.
     maxima AS (
       SELECT cc.classe_id, pp.id AS periode_id,
              SUM(
                CASE WHEN pp.type = 'examen'
                     -- NULL = pas encore configuré → 2x la période (même règle
                     -- que les bulletins officiels) ; 0 = volontairement sans
                     -- examen pour ce cours ; toute autre valeur = le barème
                     -- choisi par l'école. COALESCE seul ne peut pas exprimer
                     -- « NULL vaut le double », d'où le CASE explicite.
                     THEN CASE
                            WHEN COALESCE(cc.maximum_examen_override, co.maximum_examen) IS NULL
                              THEN COALESCE(cc.maximum_points_override, co.maximum_points, 0) * 2
                            ELSE COALESCE(cc.maximum_examen_override, co.maximum_examen)
                          END
                     ELSE COALESCE(cc.maximum_points_override, co.maximum_points, 0)
                END
              ) AS maxima
         FROM classe_cours cc
         JOIN cours co ON co.id = cc.cours_id
         JOIN classes cl ON cl.id = cc.classe_id
        CROSS JOIN periodes_portee pp
        WHERE cc.ecole_id = ${CURRENT_ECOLE}
          AND (pp.cycle IS NULL OR cl.cycle IS NULL OR pp.cycle = cl.cycle::text)
        GROUP BY cc.classe_id, pp.id
     ),
     -- Points réellement obtenus, par élève et par période.
     obtenus AS (
       SELECT n.eleve_id, n.periode_id, cc.classe_id,
              SUM(n.points_obtenus) AS points
         FROM notes n
         JOIN classe_cours cc ON cc.id = n.classe_cours_id
        WHERE n.ecole_id = ${CURRENT_ECOLE}
          AND n.periode_id = ANY($2::uuid[])
          AND n.points_obtenus IS NOT NULL
        GROUP BY n.eleve_id, n.periode_id, cc.classe_id
     ),
     -- Ce que chaque élève a obtenu, et sur combien, en ne retenant que les
     -- périodes où il a effectivement été coté.
     -- La jointure sur (classe, période) est ce qui fait entrer la période
     -- dans le dénominateur : une période sans note pour cet élève n'a pas
     -- de ligne dans la CTE des points obtenus, donc n'y entre pas.
     par_eleve AS (
       SELECT o.eleve_id,
              SUM(o.points) AS total_obtenu,
              SUM(m.maxima) AS total_maxima,
              count(DISTINCT o.periode_id)::int AS nb_periodes
         FROM obtenus o
         JOIN maxima m ON m.classe_id = o.classe_id AND m.periode_id = o.periode_id
        GROUP BY o.eleve_id
     ),
     -- Dénominateur COMPLET de la portée, classe par classe : c'est lui qui
     -- s'applique à l'élève dont aucune cote n'a encore été saisie.
     maxima_portee AS (
       SELECT classe_id, SUM(maxima) AS maxima FROM maxima GROUP BY classe_id
     )
     SELECT e.id AS eleve_id,
            c.id AS classe_id, c.nom AS classe_nom, c.cycle::text AS classe_cycle,
            e.nom, e.postnom, e.prenom, e.matricule,
            COALESCE(pe.total_obtenu, 0) AS total_obtenu,
            COALESCE(pe.total_maxima, mp.maxima) AS total_maxima,
            COALESCE(pe.nb_periodes, 0) AS nb_periodes,
            (pe.eleve_id IS NULL) AS sans_note
       FROM eleves e
       JOIN classes c ON c.id = e.classe_id
       LEFT JOIN par_eleve pe ON pe.eleve_id = e.id
       LEFT JOIN maxima_portee mp ON mp.classe_id = c.id
      WHERE e.statut = 'actif'
        AND c.annee_scolaire_id = $1
        AND ($3::boolean OR pe.eleve_id IS NOT NULL)
        AND ($4::text IS NULL OR c.cycle IS NULL OR c.cycle::text = $4)
        AND COALESCE(pe.total_maxima, mp.maxima) > 0`,
    [anneeId, ids, inclureNonNotes, cycle]
  );

  return r.rows.map((l) => {
    const obtenu = Number(l.total_obtenu);
    const maxima = Number(l.total_maxima);
    return {
      eleve_id: l.eleve_id,
      classe_id: l.classe_id,
      classe_nom: l.classe_nom,
      classe_cycle: l.classe_cycle,
      matricule: l.matricule,
      // Les trois champs séparés sont conservés EN PLUS de `nom_complet` :
      // plusieurs écrans les affichent colonne par colonne, et un appelant qui
      // n'aurait que la chaîne assemblée ne pourrait plus trier sur le nom de
      // famille seul.
      nom: l.nom,
      postnom: l.postnom,
      prenom: l.prenom,
      nom_complet: [l.nom, l.postnom, l.prenom].filter(Boolean).join(' '),
      total_obtenu: obtenu,
      total_maxima: maxima,
      nb_periodes: l.nb_periodes,
      sans_note: l.sans_note === true,
      pourcentage: Math.round((obtenu / maxima) * 1000) / 10
    };
  });
}

/** Agrège des pourcentages d'élèves en moyenne, sans perdre le compte. */
function agreger(lignes) {
  if (lignes.length === 0) return { moyenne: null, nb_eleves: 0, nb_sans_note: 0 };
  const somme = lignes.reduce((total, l) => total + l.pourcentage, 0);
  return {
    // Combien de ces élèves sont à zéro faute de cote saisie, et non faute de
    // résultat : sans ce compte, une moyenne écrasée par des classes non
    // encore corrigées se lit comme un effondrement scolaire.
    nb_sans_note: lignes.filter((l) => l.sans_note).length,
    // Moyenne des pourcentages PAR ÉLÈVE : chaque élève pèse pareil, quel que
    // soit le nombre de périodes qu'il a suivies. C'est la moyenne d'une
    // population d'élèves, pas d'une population de bulletins.
    moyenne: Math.round((somme / lignes.length) * 10) / 10,
    nb_eleves: lignes.length
  };
}


module.exports = { pourcentagesParEleve, agreger };
