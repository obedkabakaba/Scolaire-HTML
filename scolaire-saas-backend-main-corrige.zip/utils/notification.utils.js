const { envoyerEmail } = require('./email.utils');
const { emailWrapper } = require('./email-template');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

/**
 * Crée une notification automatique envoyée au directeur.
 *
 * Cette notification représente Ardoise et n'a donc pas d'expéditeur humain.
 */
async function creerEtEnvoyerNotification(
  client,
  { ecoleId, sujet, titre, contenu }
) {
  const dejaEnvoyeeAujourdhui = await client.query(
    `
    SELECT 1
    FROM notifications
    WHERE ecole_id = $1
      AND sujet = $2
      AND created_at::date = now()::date
    LIMIT 1
    `,
    [ecoleId, sujet]
  );

  if (dejaEnvoyeeAujourdhui.rows.length > 0) {
    return false;
  }

  const notifResult = await client.query(
    `
    INSERT INTO notifications (
      ecole_id,
      utilisateur_id,
      expediteur_id,
      canal,
      sujet,
      contenu,
      statut,
      lu
    )
    VALUES ($1, NULL, NULL, 'email', $2, $3, 'en_attente', false)
    RETURNING id
    `,
    [ecoleId, sujet, contenu]
  );

  const notificationId = notifResult.rows[0].id;

  const directeurResult = await client.query(
    `
    SELECT u.email
    FROM utilisateurs u
    JOIN utilisateur_roles ur
      ON ur.utilisateur_id = u.id
    WHERE u.ecole_id = $1
      AND ur.role = 'directeur'
      AND u.statut = 'actif'
    LIMIT 1
    `,
    [ecoleId]
  );

  let destinataire = directeurResult.rows[0]?.email;

  if (!destinataire) {
    const ecoleResult = await client.query(
      'SELECT email FROM ecoles WHERE id = $1',
      [ecoleId]
    );
    destinataire = ecoleResult.rows[0]?.email;
  }

  if (!destinataire) {
    await client.query(
      'UPDATE notifications SET statut = \'echoue\' WHERE id = $1',
      [notificationId]
    );
    return true;
  }

  const resultatEnvoi = await envoyerEmail({
    to: destinataire,
    subject: titre,
    html: emailWrapper({
      type: sujet,
      titre,
      preheader: contenu,
      contenuHtml: `<p>${contenu}</p>`
    })
  });

  await client.query(
    'UPDATE notifications SET statut = $1 WHERE id = $2',
    [resultatEnvoi.envoye ? 'envoye' : 'echoue', notificationId]
  );

  return true;
}

/**
 * Retourne l'identifiant d'un expéditeur humain.
 *
 * Le super-admin représente Ardoise : son expediteur_id doit être NULL.
 */
function expediteurIdPourRequete(req) {
  if (!req || !req.auth || req.auth.isSuperAdmin) {
    return null;
  }

  return req.auth.userId || null;
}

/**
 * Crée une notification interne ciblée.
 *
 * Pour un super-admin, appeler avec estSuperAdmin: true ou utiliser
 * notifierDepuisRequete(). Dans les deux cas, expediteur_id sera NULL.
 */
async function notifier(
  client,
  {
    utilisateurId,
    expediteurId = null,
    estSuperAdmin = false,
    sujet,
    contenu,
    lien = null,
    canal = 'interne',
    cleUnicite = null
  }
) {
  if (!utilisateurId || !sujet) {
    return false;
  }

  const expediteurFinalId = estSuperAdmin ? null : expediteurId;

  const result = await client.query(
    `
    INSERT INTO notifications (
      ecole_id,
      utilisateur_id,
      expediteur_id,
      canal,
      sujet,
      contenu,
      lien,
      cle_unicite,
      statut,
      lu
    )
    VALUES (
      ${CURRENT_ECOLE},
      $1,
      $2,
      $3::canal_notification,
      $4,
      $5,
      $6,
      $7,
      'envoye',
      false
    )
    ON CONFLICT (ecole_id, utilisateur_id, cle_unicite)
      WHERE cle_unicite IS NOT NULL
    DO NOTHING
    RETURNING id
    `,
    [
      utilisateurId,
      expediteurFinalId,
      canal,
      sujet,
      contenu || null,
      lien,
      cleUnicite
    ]
  );

  return result.rows.length > 0;
}

/**
 * Variante à utiliser dans un contrôleur qui possède req.
 * Elle applique automatiquement la règle :
 * super-admin = Plateforme Ardoise.
 */
async function notifierDepuisRequete(client, req, options) {
  return notifier(client, {
    ...options,
    expediteurId: expediteurIdPourRequete(req),
    estSuperAdmin: Boolean(req?.auth?.isSuperAdmin)
  });
}

/** Envoie la même notification à plusieurs destinataires. */
async function notifierPlusieurs(client, utilisateurIds, contenuNotification) {
  let crees = 0;

  for (const utilisateurId of utilisateurIds) {
    if (await notifier(client, {
      ...contenuNotification,
      utilisateurId
    })) {
      crees++;
    }
  }

  return crees;
}

/** Utilisateurs actifs de l'école portant l'un des rôles demandés. */
async function utilisateursAvecRole(client, roles) {
  const result = await client.query(
    `
    SELECT DISTINCT u.id
    FROM utilisateurs u
    JOIN utilisateur_roles ur
      ON ur.utilisateur_id = u.id
    WHERE u.ecole_id = ${CURRENT_ECOLE}
      AND u.statut = 'actif'
      AND ur.role::text = ANY($1::text[])
    `,
    [roles]
  );

  return result.rows.map((utilisateur) => utilisateur.id);
}

module.exports = {
  creerEtEnvoyerNotification,
  expediteurIdPourRequete,
  notifier,
  notifierDepuisRequete,
  notifierPlusieurs,
  utilisateursAvecRole
};
