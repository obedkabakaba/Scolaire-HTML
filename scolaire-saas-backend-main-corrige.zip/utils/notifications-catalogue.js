/**
 * utils/notifications-catalogue.js
 * ---------------------------------------------------------------------------
 * LE CATALOGUE DES ÉVÉNEMENTS NOTIFIABLES
 *
 * Un seul endroit décrit ce que chaque événement dit, à qui, et par quel
 * canal. Les contrôleurs ne rédigent plus de texte : ils déclarent qu'un fait
 * s'est produit et passent les données brutes. `notifications.service.js`
 * fait le reste.
 *
 * POURQUOI SÉPARER LE TEXTE DU CONTRÔLEUR
 * ---------------------------------------
 * Sans ce fichier, corriger une faute d'orthographe dans un e-mail obligerait
 * à retrouver la ligne dans un contrôleur de 1 000 lignes ; changer le ton de
 * TOUS les messages aux parents obligerait à visiter huit fichiers. Et surtout
 * personne ne pourrait répondre à la question « qu'est-ce que la plateforme
 * envoie, au juste ? » autrement qu'en relisant tout le code.
 *
 * LE RENDU A LIEU À L'ENVOI, PAS À L'ÉCRITURE
 * ------------------------------------------
 * La file stocke `evenement` + `donnees` (JSON), jamais le HTML final. Un
 * gabarit corrigé s'applique donc aussi aux e-mails encore en attente, et une
 * ligne de file pèse 200 octets au lieu de 15 Ko.
 *
 * FORME D'UNE ENTRÉE
 * ------------------
 *   canalDefaut       'interne' (plateforme seule) | 'email' (plateforme + mail)
 *   lien              page ouverte au clic dans la plateforme
 *   titre(d)          titre court, affiché dans la boîte de réception
 *   contenu(d)        corps du message dans la plateforme
 *   objet(d)          objet de l'e-mail (défaut : titre)
 *   html(d)           corps de l'e-mail (défaut : gabarit générique)
 *   effacerDonnees    true → `donnees` est vidé après envoi réussi
 *                     (voir 'compte.cree' : on n'archive pas un mot de passe)
 *
 * `d` est toujours du JSON issu de la base : traiter chaque champ comme
 * potentiellement absent. Les gabarits ne doivent jamais lever d'exception —
 * une notification qui plante à l'envoi bloque la file entière.
 */

const {
  emailWrapper, carte, boiteCode, echapper
} = require('./email-template');

const S = (v) => echapper(v == null ? '' : v);

const SITE_URL = (process.env.FRONTEND_URL || 'https://myardoise.com').replace(/\/+$/, '');

/** URL absolue vers une page de la plateforme. */
function url(chemin) {
  if (!chemin) return SITE_URL;
  return /^https?:\/\//i.test(chemin) ? chemin : `${SITE_URL}/${String(chemin).replace(/^\/+/, '')}`;
}

/** Montant lisible : « 125 000 FC », jamais « 125000.00 ». */
function montant(valeur, devise) {
  const n = Number(valeur);
  if (!Number.isFinite(n)) return '—';

  const formate = n.toLocaleString('fr-FR', {
    // Deux décimales dès qu'il y en a : sur un bulletin de paie ou un reçu,
    // « 12,5 USD » se lit mal et invite à se demander s'il manque un chiffre.
    minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
    maximumFractionDigits: 2
  })
    // `toLocaleString('fr-FR')` sépare les milliers par U+202F (espace fine
    // insécable) et, selon la version d'ICU, par U+00A0. C'est la typographie
    // française correcte — et un piège en e-mail : plusieurs clients Outlook
    // et des webmails africains en encodage hérité affichent ces caractères
    // en carré vide ou en « ? ». Un net à payer rendu « 265?000 FC » sur un
    // bulletin de paie n'est pas un détail cosmétique.
    //
    // L'espace ordinaire s'affiche partout. La seule perte est le risque d'un
    // retour à la ligne au milieu d'un nombre ; les cellules qui portent des
    // montants sont déjà en `white-space:nowrap` (voir tableauRecap).
    .replace(/[\u202F\u00A0]/g, ' ');

  return `${formate}${devise ? ` ${devise}` : ''}`;
}

/** Date lisible en français, tolérante aux formats et aux valeurs absentes. */
function dateFr(valeur) {
  if (!valeur) return '';
  const d = new Date(valeur);
  if (Number.isNaN(d.getTime())) return String(valeur);
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

/** Mois « 2026-03 » → « mars 2026 ». */
function moisFr(valeur) {
  const m = /^(\d{4})-(\d{2})$/.exec(String(valeur || ''));
  if (!m) return String(valeur || '');
  const noms = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  return `${noms[Number(m[2]) - 1] || ''} ${m[1]}`.trim();
}

/**
 * Petit tableau à deux colonnes, pour les récapitulatifs chiffrés
 * (bulletin de paie, reçu de frais). Les styles sont en ligne : les clients
 * e-mail ignorent les feuilles de style externes, et Outlook ignore même
 * une partie des règles `<style>` embarquées.
 *
 * @param {Array<[string, string, {fort?: boolean}]>} lignes
 */
function tableauRecap(lignes) {
  const corps = (lignes || []).map(([libelle, valeur, opt]) => {
    const fort = opt && opt.fort;
    const poids = fort ? 'font-weight:700;' : '';
    const bord = fort ? 'border-top:2px solid #243038;' : 'border-top:1px solid #243038;';
    return `<tr>
      <td style="padding:9px 4px;text-align:left;font-family:sans-serif;font-size:14px;color:#9AA7AE;${bord}${poids}">${libelle}</td>
      <td style="padding:9px 4px;text-align:right;font-family:sans-serif;font-size:14px;color:#EAF0F2;${bord}${poids}white-space:nowrap;">${valeur}</td>
    </tr>`;
  }).join('');

  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
    style="margin:16px 0;border-collapse:collapse;">${corps}</table>`;
}

/* =========================================================================
   LE CATALOGUE
   ========================================================================= */

const CATALOGUE = {

  /* -----------------------------------------------------------------------
     COMPTES ET ACCÈS
     ----------------------------------------------------------------------- */

  'compte.cree': {
    canalDefaut: 'email',
    lien: '/connexion.html',
    // Le mot de passe provisoire ne doit pas dormir en base une fois l'e-mail
    // parti. Il y reste le temps de la file (quelques secondes), pas
    // indéfiniment dans un historique que trente personnes peuvent lire.
    effacerDonnees: true,
    titre: () => 'Votre compte Ardoise est prêt',
    contenu: (d) => `Un compte ${d.roles || 'utilisateur'} a été créé pour vous sur ${d.ecole || 'la plateforme'}.`,
    objet: (d) => `Votre accès à ${d.ecole || 'Ardoise'}`,
    html: (d) => emailWrapper({
      type: 'nouveau_compte',
      titre: 'Votre compte est prêt',
      preheader: `Vos identifiants pour ${d.ecole || 'Ardoise'}.`,
      contenuHtml: `<p>Bonjour ${S(d.prenom || d.nom)},</p>
        <p>Un compte vous a été créé sur <strong>${S(d.ecole)}</strong>${d.roles ? ` avec le rôle <strong>${S(d.roles)}</strong>` : ''}.</p>`
        + boiteCode(
          `Identifiant : <strong>${S(d.email)}</strong>`
          + (d.motDePasse
            ? `<br>Mot de passe provisoire : <strong style="color:#DD7C11;">${S(d.motDePasse)}</strong>`
            : '<br>Utilisez le mot de passe qui vous a été communiqué.')
        )
        + carte({
          type: 'warning',
          titre: 'À faire à la première connexion',
          texteHtml: 'La plateforme vous demandera de choisir votre propre mot de passe. Ne communiquez celui-ci à personne.'
        }),
      boutonPrincipal: { libelle: 'Me connecter', url: url('/connexion.html') }
    })
  },

  'compte.mot_de_passe_reinitialise': {
    canalDefaut: 'email',
    lien: '/connexion.html',
    effacerDonnees: true,
    titre: () => 'Votre mot de passe a été réinitialisé',
    contenu: () => "Un administrateur de votre école a réinitialisé votre mot de passe. Vous devrez en choisir un nouveau à la prochaine connexion.",
    objet: () => 'Votre mot de passe a été réinitialisé',
    html: (d) => emailWrapper({
      type: 'reset_mdp',
      titre: 'Mot de passe réinitialisé',
      preheader: 'Un nouveau mot de passe provisoire vous a été attribué.',
      contenuHtml: `<p>Bonjour ${S(d.prenom || d.nom)},</p>
        <p>${S(d.auteur) || 'Un administrateur'} a réinitialisé votre mot de passe sur <strong>${S(d.ecole)}</strong>.</p>`
        + (d.motDePasse
          ? boiteCode(`Mot de passe provisoire : <strong style="color:#DD7C11;">${S(d.motDePasse)}</strong>`)
          : '')
        + carte({
          type: 'danger',
          titre: "Vous n'avez rien demandé ?",
          texteHtml: "Prévenez immédiatement la direction de votre école : quelqu'un a agi sur votre compte."
        }),
      boutonPrincipal: { libelle: 'Me connecter', url: url('/connexion.html') }
    })
  },

  /* -----------------------------------------------------------------------
     PAIE — la demande explicite : « si on a payé quelqu'un, ça le signale
     et ça envoie le bulletin de paie »
     ----------------------------------------------------------------------- */

  'paie.salaire_paye': {
    canalDefaut: 'email',
    lien: '/comptabilite.html',
    titre: (d) => `Salaire de ${moisFr(d.mois)} payé`,
    contenu: (d) => `Votre salaire de ${moisFr(d.mois)} a été payé : ${montant(d.net, d.devise)}${d.datePaiement ? ` le ${dateFr(d.datePaiement)}` : ''}.`,
    objet: (d) => `Bulletin de paie — ${moisFr(d.mois)}`,
    // Le bulletin de paie EST l'e-mail. Générer un PDF supposerait de lancer
    // Puppeteer (~300 Mo de Chromium) et de stocker un fichier pour chaque
    // employé chaque mois. Un tableau HTML dit exactement la même chose, se
    // lit sur un téléphone bas de gamme, s'imprime, et ne coûte rien.
    html: (d) => emailWrapper({
      type: 'paiement_reussi',
      titre: `Bulletin de paie — ${moisFr(d.mois)}`,
      preheader: `Net perçu : ${montant(d.net, d.devise)}`,
      contenuHtml: `<p>Bonjour ${S(d.prenom || d.personne)},</p>
        <p>Votre salaire du mois de <strong>${moisFr(d.mois)}</strong> a été payé par <strong>${S(d.ecole)}</strong>.</p>`
        + tableauRecap([
          ...(d.poste ? [['Poste', S(d.poste)]] : []),
          ['Salaire de base', montant(d.base, d.devise)],
          ...(Number(d.primes) > 0 ? [['Primes', `+ ${montant(d.primes, d.devise)}`]] : []),
          ...(Number(d.retenues) > 0 ? [['Retenues', `− ${montant(d.retenues, d.devise)}`]] : []),
          ['Net perçu', montant(d.net, d.devise), { fort: true }]
        ])
        + tableauRecap([
          ['Date de paiement', dateFr(d.datePaiement) || '—'],
          ...(d.modePaiement ? [['Mode de paiement', S(d.modePaiement)]] : []),
          ...(d.note ? [['Note', S(d.note)]] : [])
        ])
        + carte({
          type: 'info',
          titre: 'Ce message fait office de bulletin de paie',
          texteHtml: "Conservez-le. En cas de désaccord sur un montant, adressez-vous à la comptabilité de l'école — la plateforme ne fait que reproduire ce qui a été enregistré."
        }),
      boutonPrincipal: { libelle: 'Voir mes bulletins de paie', url: url('/comptabilite.html') }
    })
  },

  'paie.preparee': {
    canalDefaut: 'interne',
    lien: '/comptabilite.html',
    titre: (d) => `Paie de ${moisFr(d.mois)} préparée`,
    contenu: (d) => `${d.crees || 0} bulletin(s) de paie ont été préparés pour ${moisFr(d.mois)}. Ils restent à vérifier puis à payer.`
  },

  /* -----------------------------------------------------------------------
     NOTES ET BULLETINS — « si les points sont disponibles, ça envoie des mails »
     ----------------------------------------------------------------------- */

  'notes.soumises': {
    canalDefaut: 'interne',
    lien: '/notes.html',
    titre: (d) => `Notes soumises — ${d.cours} (${d.classe})`,
    contenu: (d) => `${d.professeur || 'Le professeur'} a soumis et verrouillé les notes de ${d.cours} en ${d.classe} pour « ${d.periode} ».`
  },

  // Ce qui déclenche l'e-mail aux familles n'est pas la saisie des notes,
  // c'est la SIGNATURE du bulletin. Une note saisie peut encore être corrigée ;
  // un bulletin signé est définitif. Prévenir plus tôt ferait venir les
  // parents pour des chiffres qui vont changer.
  'bulletin.disponible': {
    canalDefaut: 'email',
    lien: '/bulletins.html',
    titre: (d) => `Bulletin disponible — ${d.periode}`,
    contenu: (d) => `Le bulletin de ${d.eleve} pour « ${d.periode} » est disponible.`,
    objet: (d) => `Bulletin de ${d.eleve} — ${d.periode}`,
    html: (d) => emailWrapper({
      type: 'bulletin',
      titre: 'Le bulletin est disponible',
      preheader: `${d.eleve} — ${d.periode}`,
      contenuHtml: `<p>Bonjour,</p>
        <p>Le bulletin de <strong>${S(d.eleve)}</strong> (${S(d.classe)}) pour la période
        <strong>${S(d.periode)}</strong> vient d'être signé par la direction de
        <strong>${S(d.ecole)}</strong>.</p>`
        + (d.pourcentage != null || d.classement != null
          ? tableauRecap([
            ...(d.pourcentage != null ? [['Pourcentage', `${Number(d.pourcentage).toFixed(1)} %`]] : []),
            ...(d.classement != null ? [['Place', `${d.classement}${d.effectif ? ` sur ${d.effectif}` : ''}`]] : []),
            ...(d.mention ? [['Mention', S(d.mention)]] : [])
          ])
          : '')
        + carte({
          type: 'info',
          titre: 'Retrait du bulletin',
          texteHtml: "Le bulletin papier se retire auprès du titulaire de classe. Ce message vous informe qu'il est prêt, il ne le remplace pas."
        }),
      boutonPrincipal: { libelle: "Voir l'école en ligne", url: url('/connexion.html') }
    })
  },

  'periode.cloturee': {
    canalDefaut: 'interne',
    lien: '/annee-scolaire.html',
    titre: (d) => `Période « ${d.periode} » clôturée`,
    contenu: (d) => `${d.auteur || 'La direction'} a clôturé « ${d.periode} ». Les notes de cette période ne sont plus modifiables.`
  },

  /* -----------------------------------------------------------------------
     FRAIS SCOLAIRES
     ----------------------------------------------------------------------- */

  'frais.paiement_recu': {
    canalDefaut: 'email',
    lien: '/frais-scolaires.html',
    titre: (d) => `Paiement enregistré — ${montant(d.montant, d.devise)}`,
    contenu: (d) => `Un versement de ${montant(d.montant, d.devise)} a été enregistré pour ${d.eleve} (réf. ${d.reference}).`,
    objet: (d) => `Reçu de paiement — ${d.eleve}`,
    html: (d) => emailWrapper({
      type: 'paiement_reussi',
      titre: 'Paiement bien reçu',
      preheader: `${montant(d.montant, d.devise)} pour ${d.eleve}`,
      contenuHtml: `<p>Bonjour,</p>
        <p><strong>${S(d.ecole)}</strong> confirme avoir reçu votre versement pour
        <strong>${S(d.eleve)}</strong>${d.classe ? ` (${S(d.classe)})` : ''}.</p>`
        + tableauRecap([
          ['Référence', S(d.reference)],
          ['Objet', S(d.libelle) || 'Frais scolaires'],
          ['Date', dateFr(d.date)],
          ...(d.methode ? [['Mode', S(d.methode)]] : []),
          ['Montant versé', montant(d.montant, d.devise), { fort: true }],
          ...(d.resteAPayer != null
            ? [['Reste à payer', montant(d.resteAPayer, d.deviseReste || d.devise)]]
            : [])
        ])
        + carte({
          type: Number(d.resteAPayer) > 0 ? 'warning' : 'succes',
          titre: Number(d.resteAPayer) > 0 ? 'Solde restant' : 'Compte à jour',
          texteHtml: Number(d.resteAPayer) > 0
            ? `Il reste <strong>${montant(d.resteAPayer, d.deviseReste || d.devise)}</strong> à régler pour cette année scolaire.`
            : "Aucun montant n'est dû pour cette année scolaire."
        })
        + `<p style="font-size:13px;color:#9AA7AE;">Ce message accompagne le reçu officiel remis par l'école ; il ne le remplace pas.</p>`
    })
  },

  'frais.rappel_impaye': {
    canalDefaut: 'email',
    lien: '/frais-scolaires.html',
    titre: (d) => `Frais en attente — ${d.eleve}`,
    contenu: (d) => `Il reste ${montant(d.reste, d.devise)} à régler pour ${d.eleve}.`,
    objet: (d) => `Rappel : frais scolaires de ${d.eleve}`,
    html: (d) => emailWrapper({
      type: 'message',
      titre: 'Frais scolaires en attente',
      preheader: `${montant(d.reste, d.devise)} restant pour ${d.eleve}`,
      contenuHtml: `<p>Bonjour,</p>
        <p>À ce jour, il reste <strong>${montant(d.reste, d.devise)}</strong> à régler pour
        <strong>${S(d.eleve)}</strong>${d.classe ? ` (${S(d.classe)})` : ''} au titre de l'année ${S(d.annee)}.</p>`
        + carte({
          type: 'info',
          titre: 'Déjà réglé ?',
          texteHtml: "Si vous avez versé récemment, ce rappel a pu partir avant l'enregistrement. Présentez votre reçu au secrétariat, il n'y a rien d'autre à faire."
        })
        + `<p style="font-size:13px;color:#9AA7AE;">Pour toute difficulté de paiement, prenez contact avec la direction : un arrangement est souvent possible.</p>`
    })
  },

  /* -----------------------------------------------------------------------
     VIE SCOLAIRE
     ----------------------------------------------------------------------- */

  // Une absence prévient la famille le jour même, tant que la journée peut
  // encore s'expliquer. Prévenir au bulletin, trois mois plus tard, ne sert
  // plus à rien : personne ne se souvient du 14 octobre.
  'presence.absence': {
    canalDefaut: 'email',
    lien: '/presences.html',
    titre: (d) => `Absence de ${d.eleve}`,
    contenu: (d) => `${d.eleve} a été porté(e) absent(e) le ${dateFr(d.date)}.`,
    objet: (d) => `${d.eleve} absent(e) aujourd'hui`,
    html: (d) => emailWrapper({
      type: 'message',
      titre: 'Absence signalée',
      preheader: `${d.eleve} — ${dateFr(d.date)}`,
      contenuHtml: `<p>Bonjour,</p>
        <p><strong>${S(d.eleve)}</strong> (${S(d.classe)}) a été porté(e)
        <strong>absent(e)</strong> le <strong>${dateFr(d.date)}</strong> à ${S(d.ecole)}.</p>`
        + carte({
          type: 'info',
          titre: "S'il s'agit d'une erreur",
          texteHtml: "Signalez-le au titulaire de classe : l'appel peut être corrigé le jour même. Si l'absence est justifiée, transmettez le justificatif au secrétariat."
        })
    })
  },

  'discipline.incident': {
    canalDefaut: 'email',
    lien: '/discipline.html',
    titre: (d) => `Fait disciplinaire — ${d.eleve}`,
    contenu: (d) => `${d.type} signalé pour ${d.eleve} le ${dateFr(d.date)} (−${d.points} point(s)).`,
    objet: (d) => `Fait disciplinaire concernant ${d.eleve}`,
    html: (d) => emailWrapper({
      type: 'message',
      titre: 'Fait disciplinaire signalé',
      preheader: `${d.eleve} — ${d.type}`,
      contenuHtml: `<p>Bonjour,</p>
        <p>Un fait a été consigné au dossier de <strong>${S(d.eleve)}</strong> (${S(d.classe)}) à ${S(d.ecole)}.</p>`
        + tableauRecap([
          ['Fait', S(d.type)],
          ['Date', dateFr(d.date)],
          ['Points retirés', `− ${S(d.points)}`],
          ...(d.mesure && d.mesure !== 'aucune' ? [['Mesure', S(d.mesure)]] : []),
          ...(d.capitalRestant != null
            ? [['Conduite restante', `${S(d.capitalRestant)} / ${S(d.capital)}`, { fort: true }]]
            : [])
        ])
        + (d.description ? carte({ type: 'info', titre: 'Circonstances', texteHtml: S(d.description) }) : '')
        + carte({
          type: 'warning',
          titre: 'Vous en parler tôt est volontaire',
          texteHtml: "Ce message n'est pas une convocation. Il vous informe pendant qu'il est encore temps d'en discuter avec votre enfant. Le titulaire reste disponible."
        })
    })
  },

  'discipline.conduite_critique': {
    canalDefaut: 'interne',
    lien: '/discipline.html',
    titre: (d) => `Conduite critique — ${d.eleve}`,
    contenu: (d) => `${d.eleve} (${d.classe}) n'a plus que ${d.restant} point(s) de conduite sur ${d.capital}.`
  },

  /* -----------------------------------------------------------------------
     CALENDRIER — « en fonction des événements configurés dans le calendrier,
     ça doit envoyer des rappels »
     ----------------------------------------------------------------------- */

  'calendrier.evenement_ajoute': {
    canalDefaut: 'interne',
    lien: '/calendrier.html',
    titre: (d) => `Au calendrier : ${d.titre}`,
    contenu: (d) => `${d.titre} — ${dateFr(d.dateDebut)}${d.dateFin && d.dateFin !== d.dateDebut ? ` au ${dateFr(d.dateFin)}` : ''}.`
  },

  'calendrier.rappel': {
    canalDefaut: 'email',
    lien: '/calendrier.html',
    titre: (d) => `${d.quand === 'aujourdhui' ? "Aujourd'hui" : d.quand === 'demain' ? 'Demain' : `Dans ${d.jours} jours`} : ${d.titre}`,
    contenu: (d) => `${d.titre} — ${dateFr(d.dateDebut)}.${d.details ? ` ${d.details}` : ''}`,
    objet: (d) => `Rappel : ${d.titre} — ${d.quand === 'aujourdhui' ? "aujourd'hui" : d.quand === 'demain' ? 'demain' : `dans ${d.jours} jours`}`,
    html: (d) => emailWrapper({
      type: 'message',
      titre: d.quand === 'aujourdhui' ? "C'est aujourd'hui" : d.quand === 'demain' ? "C'est demain" : `Dans ${d.jours} jours`,
      preheader: `${d.titre} — ${dateFr(d.dateDebut)}`,
      contenuHtml: `<p>Bonjour ${S(d.prenom || '')},</p>
        <p>Rappel de l'agenda de <strong>${S(d.ecole)}</strong> :</p>`
        + tableauRecap([
          ['Événement', S(d.titre)],
          ...(d.typeLisible ? [['Nature', S(d.typeLisible)]] : []),
          ['Date', dateFr(d.dateDebut), { fort: true }],
          ...(d.dateFin && d.dateFin !== d.dateDebut ? [['Jusqu\'au', dateFr(d.dateFin)]] : [])
        ])
        + (d.consigne ? carte({ type: 'warning', titre: 'À préparer', texteHtml: S(d.consigne) }) : ''),
      boutonPrincipal: { libelle: 'Ouvrir le calendrier', url: url('/calendrier.html') }
    })
  },

  /* -----------------------------------------------------------------------
     ADMISSIONS
     ----------------------------------------------------------------------- */

  'inscription.resultat': {
    canalDefaut: 'email',
    lien: '/inscriptions.html',
    titre: (d) => `Résultat d'admission — ${d.candidat}`,
    contenu: (d) => `${d.candidat} : ${d.admis ? 'admis(e)' : 'non retenu(e)'} à l'issue de ${d.session}.`,
    objet: (d) => `Résultat d'admission — ${d.ecole}`,
    html: (d) => emailWrapper({
      type: 'message',
      titre: d.admis ? 'Candidature retenue' : "Résultat d'admission",
      preheader: `${d.candidat} — ${d.session}`,
      contenuHtml: `<p>Bonjour,</p>
        <p>À l'issue de <strong>${S(d.session)}</strong> à <strong>${S(d.ecole)}</strong>,
        la candidature de <strong>${S(d.candidat)}</strong> ${d.admis ? 'a été retenue' : "n'a pas été retenue"}.</p>`
        + (d.rang != null || d.total != null
          ? tableauRecap([
            ...(d.total != null ? [['Total obtenu', String(d.total)]] : []),
            ...(d.rang != null ? [['Rang', `${d.rang}${d.nbCandidats ? ` sur ${d.nbCandidats}` : ''}`]] : [])
          ])
          : '')
        + carte({
          type: d.admis ? 'succes' : 'info',
          titre: d.admis ? 'Prochaine étape' : 'Et ensuite',
          texteHtml: d.admis
            ? `Présentez-vous au secrétariat pour finaliser l'inscription${d.classe ? ` en <strong>${S(d.classe)}</strong>` : ''}.`
            : "Le secrétariat peut vous renseigner sur les places encore disponibles dans d'autres classes ou sessions."
        })
    })
  },

  /* -----------------------------------------------------------------------
     ABONNEMENT (déjà couvert par le job existant, repris ici pour que TOUT
     passe par le même catalogue)
     ----------------------------------------------------------------------- */

  'abonnement.rappel_expiration': {
    canalDefaut: 'email',
    lien: '/parametres.html',
    titre: (d) => `Abonnement : expiration ${d.jours === 1 ? 'demain' : `dans ${d.jours} jours`}`,
    contenu: (d) => `L'abonnement de ${d.ecole} expire le ${dateFr(d.dateExpiration)}. Pensez à le renouveler.`,
    objet: (d) => `${d.ecole} — abonnement à renouveler`,
    html: (d) => emailWrapper({
      type: 'abo_expire',
      titre: 'Abonnement à renouveler',
      preheader: `Expiration le ${dateFr(d.dateExpiration)}.`,
      contenuHtml: `<p>Bonjour,</p>
        <p>L'abonnement de <strong>${S(d.ecole)}</strong> expire le
        <strong>${dateFr(d.dateExpiration)}</strong>.</p>`
        + carte({
          type: 'warning',
          titre: 'Ce qui se passe sans renouvellement',
          texteHtml: `Après expiration, un délai de grâce de ${S(d.delaiGrace || 5)} jours s'applique. Passé ce délai, l'accès est suspendu — les données restent intactes et reviennent au renouvellement.`
        })
    })
  }
};

/* =========================================================================
   RENDU
   ========================================================================= */

/** Gabarit de repli : jamais joli, mais jamais vide. */
function htmlGenerique({ titre, contenu, lien }) {
  return emailWrapper({
    type: 'message',
    titre: titre || 'Notification',
    preheader: contenu || '',
    contenuHtml: `<p>${S(contenu)}</p>`,
    boutonPrincipal: lien ? { libelle: 'Ouvrir Ardoise', url: url(lien) } : undefined
  });
}

/**
 * Texte affiché dans la plateforme.
 * Renvoie toujours quelque chose, même si l'événement est inconnu : une
 * notification muette dans la boîte de réception est pire qu'un texte
 * approximatif.
 */
function rendreInterne(evenement, donnees = {}) {
  const entree = CATALOGUE[evenement];
  if (!entree) {
    return { titre: donnees.titre || 'Notification', contenu: donnees.contenu || '', lien: donnees.lien || null };
  }
  try {
    return {
      titre: entree.titre ? entree.titre(donnees) : 'Notification',
      contenu: entree.contenu ? entree.contenu(donnees) : '',
      lien: donnees.lien || entree.lien || null
    };
  } catch (err) {
    console.error(`[notifications] gabarit interne « ${evenement} » en échec :`, err.message);
    return { titre: 'Notification', contenu: '', lien: entree.lien || null };
  }
}

/**
 * Objet + HTML de l'e-mail, rendus au moment de l'envoi.
 * `secours` reprend ce qui a été figé en base à la création : si le gabarit
 * lève une exception, l'e-mail part quand même, en version dépouillée.
 */
function rendreEmail(evenement, donnees = {}, secours = {}) {
  const entree = CATALOGUE[evenement];
  const interne = rendreInterne(evenement, donnees);
  const titre = secours.sujet || interne.titre;
  const contenu = secours.contenu || interne.contenu;

  if (!entree) {
    return { objet: titre, html: htmlGenerique({ titre, contenu, lien: secours.lien }) };
  }

  try {
    return {
      objet: entree.objet ? entree.objet(donnees) : titre,
      html: entree.html
        ? entree.html(donnees)
        : htmlGenerique({ titre, contenu, lien: secours.lien || entree.lien })
    };
  } catch (err) {
    console.error(`[notifications] gabarit e-mail « ${evenement} » en échec :`, err.message);
    return { objet: titre, html: htmlGenerique({ titre, contenu, lien: secours.lien }) };
  }
}

/** Canal prévu au catalogue pour cet événement. */
function canalDefaut(evenement) {
  return CATALOGUE[evenement]?.canalDefaut || 'interne';
}

/** Faut-il purger `donnees` après envoi ? (mots de passe provisoires) */
function doitEffacerDonnees(evenement) {
  return Boolean(CATALOGUE[evenement]?.effacerDonnees);
}

/** Lien par défaut de l'événement. */
function lienDefaut(evenement) {
  return CATALOGUE[evenement]?.lien || null;
}

module.exports = {
  CATALOGUE,
  rendreInterne,
  rendreEmail,
  canalDefaut,
  doitEffacerDonnees,
  lienDefaut,
  // exportés pour les tests et pour d'éventuels gabarits ad hoc
  montant,
  dateFr,
  moisFr,
  tableauRecap
};
