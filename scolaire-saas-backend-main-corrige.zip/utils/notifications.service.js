/**
 * utils/notifications.service.js
 * ---------------------------------------------------------------------------
 * LE SERVICE DE NOTIFICATIONS
 *
 * Deux moitiés qui ne se touchent jamais :
 *
 *   ÉCRITURE  — `notifierEvenement()` insère des lignes. Rien d'autre. Appelée
 *               DANS la transaction du contrôleur, elle est annulée avec elle
 *               si le reste échoue. Coût : une requête, quelques millisecondes.
 *
 *   ENVOI     — `viderFile()` lit la file, appelle Resend, écrit le résultat.
 *               Appelée APRÈS le commit, hors de toute transaction du métier.
 *
 * CETTE SÉPARATION N'EST PAS UN RAFFINEMENT
 * -----------------------------------------
 * Sans elle, trois choses cassent en production, et une seule se voit tout de
 * suite :
 *
 *   • L'e-mail annoncé part alors que la transaction est annulée ensuite.
 *     Un parent reçoit « paiement enregistré » pour un paiement inexistant.
 *   • Un appel réseau de 2 s dans une transaction, c'est 2 s de verrous tenus.
 *     `payerSalaire` verrouille la ligne de paie : la file d'attente se forme
 *     derrière une requête HTTP.
 *   • Signer les bulletins d'une classe de 300 élèves = 300 appels HTTP dans
 *     UNE transaction. Elle expire avant la fin, et tout est annulé — y compris
 *     les signatures.
 *
 * LA FILE EST DANS `notifications`, PAS DANS UNE TABLE À PART
 * ----------------------------------------------------------
 * La table existe déjà, le frontend la lit déjà (voir la cloche dans `ui.js`
 * et l'écran `messages.html`). Une seconde table imposerait de tenir deux
 * historiques cohérents pour un seul fait. La convention, déjà présente dans
 * le code, est conservée :
 *   canal = 'interne' → plateforme seule
 *   canal = 'email'   → plateforme ET e-mail
 *
 * RÉESSAIS
 * --------
 * Un e-mail qui échoue n'est pas perdu : il est réessayé, avec un délai qui
 * croît (5, 10, 15... minutes), jusqu'à MAX_ESSAIS. Au-delà, statut
 * 'abandonne' — visible en base, donc diagnosticable, plutôt que réessayé
 * indéfiniment contre une adresse qui n'existe pas.
 */

const { pool, runWithTenant } = require('../config/db');
const { envoyerEmail } = require('./email.utils');
const {
  rendreInterne, rendreEmail, canalDefaut, doitEffacerDonnees, lienDefaut
} = require('./notifications-catalogue');

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

const MAX_ESSAIS = Number(process.env.NOTIFICATIONS_MAX_ESSAIS || 5);

// Resend limite à 2 requêtes/seconde sur les formules d'entrée. Dépasser cette
// cadence ne fait pas patienter : la requête est rejetée en 429, et l'e-mail
// repart pour un tour de réessai. Une pause volontaire coûte moins cher qu'un
// échec à rattraper.
const PAUSE_ENTRE_ENVOIS_MS = Number(process.env.NOTIFICATIONS_PAUSE_MS || 600);

// Un lot borné : le vidage doit finir en quelques dizaines de secondes, pas
// monopoliser le processus. Ce qui reste part au tour suivant.
const TAILLE_LOT = Number(process.env.NOTIFICATIONS_TAILLE_LOT || 40);

const attendre = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* =========================================================================
   1. ÉCRITURE — appelée dans la transaction du contrôleur
   ========================================================================= */

/**
 * Normalise la liste des destinataires.
 * Accepte des UUID nus (`['abc-...']`) ou des objets
 * (`[{ utilisateurId, email, nom }]`), et écarte les doublons : le titulaire
 * d'une classe est souvent aussi professeur d'un de ses cours, il ne doit pas
 * recevoir deux fois le même message.
 */
function normaliserDestinataires(destinataires) {
  const vus = new Set();
  const liste = [];

  for (const brut of (destinataires || [])) {
    if (!brut) continue;
    const d = typeof brut === 'string' ? { utilisateurId: brut } : brut;
    const email = d.email ? String(d.email).trim().toLowerCase() : null;
    if (!d.utilisateurId && !email) continue;

    const cle = d.utilisateurId || `email:${email}`;
    if (vus.has(cle)) continue;
    vus.add(cle);
    liste.push({ utilisateurId: d.utilisateurId || null, email, nom: d.nom || null });
  }

  return liste;
}

/** Adresses e-mail des utilisateurs visés, en une seule requête. */
async function resoudreEmails(client, utilisateurIds) {
  if (utilisateurIds.length === 0) return new Map();
  const r = await client.query(
    `SELECT id, email, prenom, nom FROM utilisateurs
      WHERE id = ANY($1::uuid[]) AND statut = 'actif' AND email IS NOT NULL`,
    [utilisateurIds]
  );
  return new Map(r.rows.map((u) => [u.id, u]));
}

/**
 * Enregistre une notification pour un ou plusieurs destinataires.
 *
 * @param {object} client            client pg DANS la transaction en cours
 * @param {object} options
 * @param {string} options.evenement clé du catalogue
 * @param {Array}  options.destinataires  UUID ou { utilisateurId, email, nom }
 * @param {object} options.donnees   variables de rendu (JSON sérialisable)
 * @param {string} [options.canal]   'interne' | 'email' (défaut : catalogue)
 * @param {string} [options.cleUnicite]  empêche le doublon (rappels récurrents)
 * @param {string} [options.expediteurId]  auteur humain, ou null = Ardoise
 * @param {string} [options.ecoleId] force l'école (jobs multi-écoles)
 * @param {boolean} [options.visibleInterface]  false pour les envois aux
 *        familles : elles n'ont pas de compte, et sans ce drapeau leurs
 *        notifications atterriraient dans la boîte du directeur.
 * @returns {Promise<number>} nombre de lignes réellement créées
 */
async function notifierEvenement(client, {
  evenement,
  destinataires = [],
  donnees = {},
  canal = null,
  cleUnicite = null,
  expediteurId = null,
  ecoleId = null,
  visibleInterface = true,
  lien = null
}) {
  if (!evenement) return 0;

  const liste = normaliserDestinataires(destinataires);
  if (liste.length === 0) return 0;

  const canalRetenu = canal || canalDefaut(evenement);
  const lienRetenu = lien || lienDefaut(evenement);

  // Les adresses ne sont résolues que si un e-mail doit partir : une
  // notification purement interne n'a aucune raison d'interroger la table
  // des utilisateurs.
  const carnet = canalRetenu === 'email'
    ? await resoudreEmails(client, liste.filter((d) => d.utilisateurId).map((d) => d.utilisateurId))
    : new Map();

  let crees = 0;

  for (const destinataire of liste) {
    const compte = destinataire.utilisateurId ? carnet.get(destinataire.utilisateurId) : null;
    const adresse = canalRetenu === 'email'
      ? (destinataire.email || compte?.email || null)
      : null;

    // Un e-mail sans adresse serait une ligne condamnée à échouer en boucle.
    // On la crée quand même, en 'interne' : le message reste consultable dans
    // la plateforme, ce qui vaut mieux que de le perdre.
    const canalLigne = (canalRetenu === 'email' && !adresse) ? 'interne' : canalRetenu;

    // Les données de rendu peuvent être enrichies par destinataire (prénom).
    const donneesLigne = compte
      ? { ...donnees, prenom: donnees.prenom || compte.prenom, nom: donnees.nom || compte.nom }
      : (destinataire.nom ? { ...donnees, nom: donnees.nom || destinataire.nom } : donnees);

    const { titre, contenu } = rendreInterne(evenement, donneesLigne);

    // `ON CONFLICT DO NOTHING` sur (ecole, destinataire, cleUnicite) : un job
    // qui tourne chaque jour ne republie pas le même rappel. Sans cette clé,
    // l'utilisateur recevrait le même message quotidiennement jusqu'à ce qu'il
    // agisse — et finirait par tout ignorer, y compris l'important.
    const r = await client.query(
      `INSERT INTO notifications (
         ecole_id, utilisateur_id, expediteur_id, canal, sujet, contenu, lien,
         cle_unicite, statut, lu, evenement, donnees, destinataire_email,
         visible_interface
       )
       VALUES (
         COALESCE($1::uuid, ${CURRENT_ECOLE}), $2, $3, $4::canal_notification,
         $5, $6, $7, $8,
         CASE WHEN $4 = 'email' THEN 'en_attente' ELSE 'envoye' END,
         false, $9, $10::jsonb, $11, $12
       )
       ON CONFLICT DO NOTHING
       RETURNING id`,
      [
        ecoleId, destinataire.utilisateurId, expediteurId, canalLigne,
        titre, contenu || null, lienRetenu, cleUnicite,
        evenement, JSON.stringify(donneesLigne || {}), adresse, visibleInterface
      ]
    );

    if (r.rows.length > 0) crees++;
  }

  return crees;
}

/** Utilisateurs actifs de l'école courante portant l'un des rôles demandés. */
async function destinatairesParRole(client, roles, { ecoleId = null } = {}) {
  const r = await client.query(
    `SELECT DISTINCT u.id
       FROM utilisateurs u
       JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
      WHERE u.ecole_id = COALESCE($2::uuid, ${CURRENT_ECOLE})
        AND u.statut = 'actif'
        AND ur.role::text = ANY($1::text[])`,
    [roles, ecoleId]
  );
  return r.rows.map((l) => l.id);
}

/**
 * Le responsable d'un élève, sous forme de destinataire.
 *
 * Une famille n'a pas de compte sur la plateforme : son seul point de contact
 * est `eleves.responsable_email`. Renvoie un tableau vide si l'adresse manque,
 * ce qui est fréquent et parfaitement normal — l'appelant ne doit jamais
 * traiter ce cas comme une erreur.
 */
async function destinataireResponsable(client, eleveId) {
  const r = await client.query(
    `SELECT responsable_email, responsable_nom FROM eleves WHERE id = $1`,
    [eleveId]
  );
  const eleve = r.rows[0];
  if (!eleve || !eleve.responsable_email) return [];
  return [{ email: eleve.responsable_email, nom: eleve.responsable_nom }];
}

/* =========================================================================
   2. ENVOI — hors transaction, après le commit
   ========================================================================= */

// Un seul vidage à la fois dans ce processus. Deux vidages concurrents ne
// doubleraient pas les e-mails (`SKIP LOCKED` s'en charge), mais doubleraient
// la cadence d'appel à Resend — et donc les rejets en 429.
let vidageEnCours = false;

/**
 * Réclame un lot d'e-mails à envoyer.
 *
 * `FOR UPDATE SKIP LOCKED` : deux instances du serveur peuvent vider la file
 * en parallèle sans jamais se disputer une ligne, et sans qu'un e-mail parte
 * deux fois. C'est le mécanisme de file d'attente natif de PostgreSQL ; il
 * évite d'ajouter Redis pour un besoin que la base couvre déjà.
 *
 * Le passage en 'en_cours' vaut réservation, et `essais` est incrémenté ICI,
 * avant l'envoi : si le processus meurt en plein appel réseau, la tentative
 * est comptée. Sans cela, un e-mail qui fait planter le worker le ferait
 * planter indéfiniment.
 */
async function reclamerLot(limite) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL app.is_superadmin = 'true'");

    // Filet de récupération : une ligne 'en_cours' depuis plus de 15 minutes
    // vient d'un processus mort en cours d'envoi. On la remet en file.
    await client.query(
      `UPDATE notifications
          SET statut = 'en_attente'
        WHERE canal = 'email' AND statut = 'en_cours'
          AND derniere_tentative_at < now() - interval '15 minutes'`
    );

    const r = await client.query(
      `UPDATE notifications n
          SET statut = 'en_cours',
              essais = n.essais + 1,
              derniere_tentative_at = now()
        WHERE n.id IN (
          SELECT id FROM notifications
           WHERE canal = 'email'
             AND statut IN ('en_attente', 'echoue')
             AND destinataire_email IS NOT NULL
             AND essais < $1
             -- Réessai différé et croissant : 5 min après le 1er échec,
             -- 10 après le 2e, etc. Rappeler aussitôt un serveur qui vient
             -- de refuser ne fait que consommer le quota de réessais.
             AND (derniere_tentative_at IS NULL
                  OR derniere_tentative_at < now() - (interval '5 minutes' * essais))
           ORDER BY created_at
           LIMIT $2
           FOR UPDATE SKIP LOCKED
        )
       RETURNING n.id, n.evenement, n.donnees, n.sujet, n.contenu, n.lien,
                 n.destinataire_email, n.essais`,
      [MAX_ESSAIS, limite]
    );

    await client.query('COMMIT');
    return r.rows;
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (e) { /* connexion perdue */ }
    throw err;
  } finally {
    client.release();
  }
}

/** Consigne le sort d'un e-mail. Chaque ligne dans sa propre transaction. */
async function consignerResultat(id, { envoye, raison, effacerDonnees, essais }) {
  const abandon = !envoye && essais >= MAX_ESSAIS;
  const statut = envoye ? 'envoye' : (abandon ? 'abandonne' : 'echoue');

  await pool.query(
    `UPDATE notifications
        SET statut = $2,
            envoye_at = CASE WHEN $2 = 'envoye' THEN now() ELSE envoye_at END,
            derniere_erreur = $3,
            donnees = CASE WHEN $4 THEN '{}'::jsonb ELSE donnees END
      WHERE id = $1`,
    [id, statut, envoye ? null : String(raison || '').slice(0, 500), Boolean(effacerDonnees && envoye)]
  );
}

/**
 * Vide la file d'attente des e-mails.
 *
 * Ne lève jamais : appelée en arrière-plan après une réponse HTTP déjà
 * envoyée, une exception ici n'aurait personne pour l'attraper et ferait
 * tomber le processus (`unhandledRejection`).
 *
 * @returns {Promise<{envoyes:number, echecs:number, traites:number}>}
 */
async function viderFile({ limite = TAILLE_LOT } = {}) {
  if (vidageEnCours) return { envoyes: 0, echecs: 0, traites: 0, ignore: 'vidage_deja_en_cours' };
  vidageEnCours = true;

  const bilan = { envoyes: 0, echecs: 0, traites: 0 };

  try {
    const lot = await reclamerLot(limite);

    for (const ligne of lot) {
      bilan.traites++;

      const donnees = ligne.donnees || {};
      const { objet, html } = rendreEmail(ligne.evenement, donnees, {
        sujet: ligne.sujet, contenu: ligne.contenu, lien: ligne.lien
      });

      let resultat;
      try {
        resultat = await envoyerEmail({
          to: ligne.destinataire_email,
          subject: objet,
          html,
          // Une notification automatique vient de la plateforme, jamais d'une
          // personne : répondre à l'expéditeur doit aboutir au support, pas
          // dans la boîte du comptable qui a cliqué sur « payer ».
          estSuperAdmin: true
        });
      } catch (err) {
        resultat = { envoye: false, raison: err.message };
      }

      if (resultat.envoye) bilan.envoyes++; else bilan.echecs++;

      // Clé d'API absente : ce n'est pas un incident réseau, c'est une
      // configuration manquante. Réessayer cinq fois n'y changera rien —
      // on abandonne tout de suite pour ne pas saturer la file de lignes
      // qui ne partiront jamais.
      const essaisRetenus = resultat.raison === 'cle_api_absente' ? MAX_ESSAIS : ligne.essais;

      try {
        await consignerResultat(ligne.id, {
          envoye: resultat.envoye,
          raison: resultat.raison,
          effacerDonnees: doitEffacerDonnees(ligne.evenement),
          essais: essaisRetenus
        });
      } catch (err) {
        console.error('[notifications] résultat non consigné pour', ligne.id, err.message);
      }

      if (PAUSE_ENTRE_ENVOIS_MS > 0) await attendre(PAUSE_ENTRE_ENVOIS_MS);
    }
  } catch (err) {
    console.error('[notifications] vidage de file interrompu :', err.message);
  } finally {
    vidageEnCours = false;
  }

  return bilan;
}

/**
 * Déclenche un vidage APRÈS la réponse HTTP.
 *
 * `setImmediate` rend la main à la boucle d'événements : la réponse part
 * d'abord, l'utilisateur n'attend pas Resend. À appeler après `runWithTenant`,
 * jamais dedans — l'intérêt est précisément d'être hors transaction.
 *
 * Volontairement sans `await` et sans valeur de retour : un contrôleur ne doit
 * pas pouvoir faire dépendre sa réponse de l'état de la file. Si l'envoi
 * échoue, le job de reprise le rattrapera.
 */
function planifierVidage() {
  setImmediate(() => {
    viderFile().catch((err) => {
      console.error('[notifications] vidage planifié en échec :', err.message);
    });
  });
}

/* =========================================================================
   3. RACCOURCI
   ========================================================================= */

/**
 * Notifier puis planifier l'envoi, quand on n'est PAS déjà dans une
 * transaction du métier. Ouvre la sienne, la ferme, puis vide la file.
 */
async function notifierHorsTransaction(tenantContext, options) {
  const crees = await runWithTenant(tenantContext, (client) => notifierEvenement(client, options));
  if (crees > 0) planifierVidage();
  return crees;
}

module.exports = {
  notifierEvenement,
  destinatairesParRole,
  destinataireResponsable,
  notifierHorsTransaction,
  viderFile,
  planifierVidage,
  MAX_ESSAIS
};
