/**
 * ============================================================================
 *  MOTEUR D'ONBOARDING — le didacticiel, en version graphe
 * ============================================================================
 *
 *  CE QUE CE FICHIER N'EST PAS
 *  ---------------------------
 *  Ce n'est pas un second système d'aide. `connaissance.utils.js` reste la
 *  source de vérité sur le FOND — ce qu'il faut faire, pourquoi, quel piège
 *  éviter. Ce fichier ne réécrit rien de tout cela : chaque étape de
 *  configuration porte un champ `etape_config` qui pointe vers son numéro dans
 *  `ORDRE_CONFIGURATION`, et le texte est lu là-bas au moment de répondre.
 *  Écrire les explications deux fois garantirait qu'elles divergent.
 *
 *  CE QUE CE FICHIER AJOUTE
 *  ------------------------
 *  Trois choses que `ORDRE_CONFIGURATION` ne pouvait pas porter, parce qu'elle
 *  décrit une PROCÉDURE et non un PARCOURS :
 *
 *    1. Des DÉPENDANCES explicites. L'ancienne liste était linéaire : 1, 2, 3…
 *       Un ordre linéaire ne sait pas dire « les élèves attendent les classes,
 *       mais pas les frais ». Avec un graphe, une école qui a déjà ses classes
 *       saute directement aux élèves sans repasser par les créneaux.
 *
 *    2. Des étapes de DÉCOUVERTE. Un professeur ne configure rien. Son parcours
 *       n'est pas « créez ceci » mais « voici où se trouve votre travail ».
 *       Ces étapes n'ont aucune trace en base — les mémoriser est le seul rôle
 *       de la colonne `utilisateurs.onboarding`.
 *
 *    3. Des ANCRAGES d'interface. `selecteurs` liste, par ordre de préférence,
 *       où poser le projecteur sur l'écran d'arrivée. Le premier sélecteur
 *       présent gagne ; si aucun ne l'est, le didacticiel retombe sur l'entrée
 *       de menu, qui existe toujours. Un guidage qui rate sa cible et ne dit
 *       rien est pire qu'un guidage absent.
 *
 *  POURQUOI DES CODES ET NON DES NUMÉROS
 *  -------------------------------------
 *  Les étapes sont identifiées par un code stable (`classes`, `eleves`) et non
 *  par un rang. Insérer une étape au milieu d'une numérotation décale tout ce
 *  qui suit — y compris les progressions déjà enregistrées chez les
 *  utilisateurs, qui se mettraient à désigner la mauvaise étape.
 * ============================================================================
 */

const { ORDRE_CONFIGURATION } = require('./connaissance.utils');

/* ==========================================================================
   1. CATALOGUE DES ÉTAPES
   ==========================================================================

   Chaque étape porte :

     code          identifiant stable, jamais renuméroté
     type          'profil' | 'configuration' | 'decouverte'
     titre         libellé court affiché dans la checklist
     resume        une phrase — ce que la personne doit faire MAINTENANT
     ecran         page HTML de destination
     ancre         libellé du menu, pour le repli du projecteur
     selecteurs    cibles du projecteur, par ordre de préférence
     roles         qui voit cette étape
     obligatoire   false = l'étape n'empêche pas de déclarer le parcours fini
     depend        codes INDISPENSABLES, faits AVANT de la proposer
     depend_souple codes recommandés mais non indispensables (voir plus bas)
     detection     clé du dictionnaire de faits qui dit si elle est faite
     etape_config  numéro dans ORDRE_CONFIGURATION, si applicable
     cycle         'secondaire' pour les étapes que le primaire ne voit pas
     fonctionnalite code d'offre EXIGÉ (utils/catalogue.utils.js) ou absent
     categorie     'prerequis' | 'recommande' | 'facultatif' | 'decouverte'
     applicable_si (faits, contexte) => bool — configuration réelle de l'école
     details       LES GESTES, dans l'ordre, à l'intérieur de l'écran

   L'APPLICABILITÉ, ET POURQUOI ELLE NE SE CONFOND PAS AVEC LE BLOCAGE
   ------------------------------------------------------------------
   Le moteur d'origine ne connaissait que le rôle et le cycle. Une école en
   Ardoise Ascension recevait donc l'étape « Emploi du temps » alors que son
   menu la masque et que la route répond 402 : le parcours envoyait la personne
   contre un mur, et le compteur restait bloqué sous 100 % pour toujours.

   `fonctionnalite` corrige cela à la racine. Une étape dont la fonctionnalité
   n'est pas comprise dans l'offre active n'est pas AFFICHÉE COMME BLOQUÉE :
   elle est ÉCARTÉE. Elle disparaît de la checklist, de la prochaine étape, du
   calcul de progression, des dépendances et des alertes. Elle est renvoyée à
   part, dans `etapes_ecartees`, avec sa raison — pour que l'interface puisse
   dire honnêtement « comprise dans Prime » sur un écran de découverte des
   offres, jamais dans la liste des choses à faire.

   `categorie` sépare enfin ce qui était confondu sous `obligatoire` :

     prerequis   sans quoi l'école ne peut pas fonctionner (année, classes,
                 élèves). Ne peut jamais être passé.
     recommande  fortement conseillé, mais l'école tourne sans (titulaires).
                 Passable, réactivable.
     facultatif  dépend de l'organisation de l'école (frais, discipline).
     decouverte  un écran à visiter, jamais un prérequis.

   `depend` contre `depend_souple` : la distinction décide de ce qui se passe
   quand la dépendance est passée ou écartée.

     · `depend`        indispensable. Si elle est écartée ou passée, l'étape
                       enfant devient elle-même non applicable — il n'y a
                       matériellement rien à y faire. Placer des séances sans
                       heures de cours n'a pas de sens.
     · `depend_souple` recommandée. Si elle manque, l'étape enfant reste
                       proposable : on perd un confort, pas une possibilité.

   Ce qu'aucune des deux ne produit : une branche définitivement bloquée sans
   action possible. C'était le défaut à corriger.

   POURQUOI `details` A ÉTÉ AJOUTÉ
   -------------------------------
   Le guidage disait où aller — « ouvrez Classes » — et s'arrêtait là. La
   personne arrivait devant une fenêtre de quinze champs sans savoir lequel
   compte, et le didacticiel n'avait plus rien à dire. `details` porte la suite :
   les trois à six gestes concrets à faire DANS l'écran, dans l'ordre où on les
   fait. C'est ce que la bulle affiche désormais, et ce que l'assistant récite
   quand on lui demande la procédure exacte.

   Le fond long (pourquoi, pièges, description champ par champ) reste dans
   `connaissance.utils.js` — `details` en est le mode d'emploi court, pas un
   doublon.

   POURQUOI LES SÉLECTEURS ONT ÉTÉ CORRIGÉS
   ----------------------------------------
   Plusieurs pointaient vers des identifiants qui n'existent dans aucune page :
   `#bouton-ajouter-annee`, `#bouton-ajouter-periode`, `#bouton-ajouter-section`,
   `#bouton-ajouter-cours`, `#bouton-generer`, `#bouton-ajouter-modele`,
   `#bouton-importer-reglement`, `#tableau-notes`… Le projecteur ne les trouvait
   jamais, observait le DOM pendant dix secondes, puis retombait sur l'entrée de
   menu. D'où l'impression que « le guide s'ouvre mais ne montre rien ». Les
   sélecteurs ci-dessous ont été relevés dans les pages elles-mêmes.
   ========================================================================== */

const ETAPES = [
  /* ---------- Commun à tous les rôles ---------- */
  {
    code: 'profil',
    categorie: 'prerequis',
    type: 'profil',
    titre: 'Votre profil',
    resume: "Complétez votre nom et votre téléphone : ils apparaissent sur les documents que vous signez.",
    ecran: 'mon-profil.html',
    ancre: 'Mon profil',
    selecteurs: ['#bouton-activer-modif-profil', '#formulaire-profil', '.nav-item[href="mon-profil.html"]'],
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline', 'parent'],
    obligatoire: true,
    depend: [],
    details: [
      "Cliquez sur « Modifier » : les champs sont verrouillés tant que vous ne l'avez pas fait.",
      "Renseignez votre nom, votre prénom et votre téléphone.",
      "Changez votre photo si vous le souhaitez.",
      "Cliquez sur « Enregistrer ».",
      "Le bloc « Mot de passe », plus bas, est indépendant : il a son propre bouton."
    ],
    detection: 'profil_complet',
  },

  /* ---------- Configuration de l'établissement ---------- */
  {
    code: 'identite_ecole',
    categorie: 'prerequis',
    type: 'configuration',
    titre: "Identité de l'établissement",
    resume: "Renseignez le nom, la commune, le type d'enseignement et la devise.",
    ecran: 'parametres.html',
    ancre: 'Paramètres',
    selecteurs: ['#formulaire-ecole', '#bouton-enregistrer-ecole', '.nav-item[href="parametres.html"]'],
    roles: ['directeur'],
    obligatoire: true,
    depend: [],
    details: [
      "Bloc « Identité » : nom de l'école, ville, commune, province, email, téléphone, adresse.",
      "Choisissez le type d'enseignement — primaire, secondaire, ou les deux. Ce choix commande ce que tous les autres écrans proposeront.",
      "Téléversez le logo, le cachet et votre signature : sans eux, les bulletins signés sortent nus.",
      "Cliquez sur « Enregistrer » DE CE BLOC.",
      "Descendez au bloc « Devise » : devise principale, puis le taux de change si l'école travaille en FC et en USD. Enregistrez ce bloc à son tour.",
      "Descendez au bloc « Pédagogique » : maximum par défaut, découpage de l'année, seuils de passage et de redoublement, qui fait l'appel. Enregistrez.",
      "Chaque bloc a SON bouton Enregistrer : en remplir trois et n'en enregistrer qu'un est l'erreur la plus courante de cet écran."
    ],
    detection: 'identite_ecole',
    etape_config: 1,
  },
  {
    code: 'annee_scolaire',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Année scolaire',
    resume: "Créez l'année en cours et activez-la.",
    ecran: 'annee-scolaire.html',
    ancre: 'Année scolaire',
    selecteurs: ['#form-annee', '#champ-annee-libelle', '#onglet-annees', '.nav-item[href="annee-scolaire.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    depend: ['identite_ecole'],
    details: [
      "Restez sur l'onglet « Années ».",
      "Renseignez le libellé (par exemple « 2025-2026 »), la date de début et la date de fin.",
      "Cliquez sur « Ajouter » : l'année apparaît dans la liste en dessous.",
      "Sur la ligne de l'année, cliquez sur « Activer ». C'est ce clic — et lui seul — qui rend l'année courante.",
      "Une année créée mais non activée laisse tous les écrans travailler sur l'année précédente."
    ],
    detection: 'annee_active',
    etape_config: 2,
  },
  {
    code: 'periodes',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Périodes',
    resume: "Créez les trimestres ou semestres, et leurs périodes d'examen.",
    ecran: 'annee-scolaire.html',
    ancre: 'Année scolaire',
    selecteurs: ['#onglet-periodes', '#form-periode', '#champ-periode-type', '.nav-item[href="annee-scolaire.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    depend: ['annee_scolaire'],
    details: [
      "Ouvrez l'onglet « Périodes », puis choisissez l'année dans le sélecteur du haut.",
      "Pour chaque période : le type (trimestre, semestre, période de travail, examen), le numéro, le libellé.",
      "Renseignez la date de début et la date de fin. Sans elles, la plateforme ne sait pas quelle période est en cours.",
      "Le champ de rattachement au semestre n'apparaît que si des semestres existent déjà.",
      "Cliquez sur « Ajouter », puis recommencez pour chaque période.",
      "N'oubliez pas les périodes d'EXAMEN : sans elles, les cotes d'examen n'ont nulle part où se poser."
    ],
    detection: 'periodes',
    etape_config: 3,
  },
  {
    code: 'sections_options',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Sections et options',
    resume: "Créez les sections du secondaire, puis les options qui s'y rattachent.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#onglet-structure', '#form-option', '#champ-option-nom', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    // Le primaire n'a ni sections ni options. La proposer là serait une étape
    // qu'on ne peut pas terminer : elle resterait éternellement en attente et
    // bloquerait le compteur à 90 %.
    cycle: 'secondaire',
    depend: ['identite_ecole'],
    details: [
      "Ouvrez l'onglet « Structure » de l'écran Classes.",
      "Dans le bloc « Options », saisissez le nom de l'option (Biochimie, Math-Physique, Commerciale…).",
      "Choisissez sa section de rattachement.",
      "Renseignez le critère d'accès : moyenne globale, ou une branche précise avec son minimum en pourcentage.",
      "Cliquez sur « Ajouter ». Recommencez pour chaque option.",
      "Une option sans critère ne pourra pas être attribuée au mérite lors de l'orientation."
    ],
    detection: 'sections_options',
    etape_config: 5,
  },
  {
    code: 'cours',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Catalogue des cours',
    resume: "Créez chaque branche depuis une classe, avec son maximum ordinaire ET son maximum d'examen.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#champ-nouveau-cours-nom', '#bouton-ajouter-cours-classe', '#bouton-ajouter-classe', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    // La création d'une branche se fait DEPUIS une classe (bloc « Cours de cette
    // classe ») : sans classe, l'étape n'a pas d'écran où se jouer. La
    // dépendance disait « identite_ecole », héritage de l'époque où l'on
    // croyait que l'écran Cours portait un bouton d'ajout.
    depend: ['classes'],
    details: [
      "Les cours ne se créent PAS depuis l'écran « Cours » : il n'y a pas de bouton d'ajout là-bas. On les crée depuis la classe.",
      "Ouvrez « Classes », cliquez sur une classe existante : un bloc « Cours de cette classe » apparaît sous le formulaire.",
      "En bas de ce bloc, utilisez « + Ajouter un nouveau cours à cette classe ».",
      "Renseignez le nom, le code, et le maximum de points de la branche.",
      "Cochez « Ce cours n'a pas d'examen » si la branche n'en a pas ; sinon renseignez le maximum de l'examen (vide = le double du maximum de période).",
      "Cliquez sur « Ajouter » : le cours est créé et rattaché en un geste.",
      "L'écran « Cours » du menu sert ensuite à relire le catalogue et à repérer les doublons, les cours orphelins et ceux sans maximum d'examen."
    ],
    detection: 'cours',
    etape_config: 6,
  },
  {
    code: 'classes',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Classes',
    resume: "Créez vos classes en renseignant le NIVEAU et la DIVISION, sans lesquels la promotion ne pourra pas s'exécuter.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#bouton-ajouter-classe', '#champ-classe-niveau', '#corps-tableau-classes', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    depend: ['annee_scolaire'],
    details: [
      "Cliquez sur « Ajouter une classe ».",
      "Nom de la classe, puis le NIVEAU (1 à 8 — le rang de l'année d'études) et la DIVISION (A, B, C — la lettre qui distingue deux classes parallèles).",
      "Cycle, option et vacation selon l'organisation de l'école.",
      "Cochez « Classe d'orientation » sur la classe de fin de cycle, et « Classe terminale » sur celle où les élèves sortent diplômés.",
      "Capacité (places) : sert à l'orientation et aux concours. Vide = sans limite.",
      "Titulaire : le champ ne propose que des comptes déjà créés.",
      "Classe suivante : la classe où passent ceux qui réussissent. C'est ce lien que suit la promotion.",
      "Enregistrez. Le tableau affiche « niveau manquant » en rouge tant que le champ Niveau est vide — rouvrez la classe et remplissez-le."
    ],
    detection: 'classes',
    etape_config: 7,
  },
  {
    code: 'classe_cours',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Cours de chaque classe',
    resume: "Cochez, pour chaque classe, les cours réellement enseignés.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#bouton-ajouter-cours-classe', '#liste-cours-classe', '#corps-tableau-classes', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    depend: ['cours', 'classes'],
    details: [
      "Cliquez sur une classe pour l'ouvrir : le bloc « Cours de cette classe » apparaît sous le formulaire.",
      "La liste montre les branches déjà rattachées, chacune avec son sélecteur de professeur et un bouton « Retirer ».",
      "Ajoutez les branches manquantes via « + Ajouter un nouveau cours à cette classe ».",
      "N'attribuez que ce qui est réellement enseigné : un cours attribué mais jamais noté compte pour zéro et fait baisser toutes les moyennes.",
      "Une classe de primaire reçoit automatiquement le socle officiel des branches : il n'y a qu'à vérifier."
    ],
    detection: 'classe_cours',
    etape_config: 8,
  },
  {
    code: 'personnel',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Enseignants et personnel',
    resume: "Créez les comptes de vos enseignants et attribuez-leur leur rôle.",
    ecran: 'utilisateurs.html',
    ancre: 'Utilisateurs',
    selecteurs: ['#bouton-ajouter', '#bouton-importer', '.nav-item[href="utilisateurs.html"]'],
    roles: ['directeur'],
    obligatoire: true,
    depend: ['identite_ecole'],
    details: [
      "Cliquez sur « Ajouter » (ou « Importer » pour créer plusieurs comptes d'un coup).",
      "Nom, prénom, email — l'email est l'identifiant de connexion et doit être unique dans l'école.",
      "Téléphone, puis un mot de passe provisoire : la personne devra le changer à sa première connexion.",
      "Rôle : une personne n'en a qu'un, sauf deux combinaisons autorisées — Professeur + Titulaire, et Préfet + Directeur.",
      "Enregistrez.",
      "L'attribution des cours ne se fait pas ici : elle se fait depuis chaque classe, écran Classes."
    ],
    detection: 'enseignants',
    etape_config: 9,
  },
  {
    code: 'attribution_cours',
    categorie: 'recommande',
    type: 'configuration',
    titre: 'Attribution des cours aux enseignants',
    resume: "Attribuez ses cours à chaque enseignant, sinon il ouvrira un écran vide.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#liste-cours-classe', '#bouton-ajouter-cours-classe', '#corps-tableau-classes', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: true,
    depend: ['personnel', 'classe_cours'],
    details: [
      "Ouvrez « Classes » et cliquez sur une classe.",
      "Dans le bloc « Cours de cette classe », chaque ligne porte un sélecteur de professeur.",
      "Choisissez l'enseignant pour chaque branche : le choix s'enregistre immédiatement.",
      "Recommencez pour chaque classe.",
      "Un professeur sans cours attribué ouvre un écran vide et croit à une panne : faites-le dans la foulée de la création des comptes."
    ],
    detection: 'attribution_cours',
    etape_config: 9,
  },
  {
    code: 'titulaires',
    categorie: 'recommande',
    type: 'configuration',
    titre: 'Titulaires de classe',
    resume: "Désignez le titulaire de chaque classe.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#champ-classe-titulaire', '#bouton-ajouter-classe', '#corps-tableau-classes', '.nav-item[href="classes.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: ['personnel', 'classes'],
    details: [
      "Ouvrez la classe, puis le champ « Titulaire » du formulaire.",
      "Choisissez l'enseignant. Seuls les comptes existants sont proposés.",
      "Enregistrez.",
      "Pour qu'un même enseignant soit titulaire de deux classes, activez d'abord le réglage correspondant dans Paramètres."
    ],
    detection: 'titulaires',
    etape_config: 9,
  },
  {
    code: 'eleves',
    categorie: 'prerequis',
    type: 'configuration',
    titre: 'Élèves',
    resume: "Inscrivez vos élèves et affectez-les à leur classe.",
    ecran: 'eleves.html',
    ancre: 'Élèves',
    selecteurs: ['#bouton-ajouter', '#bouton-importer', '.nav-item[href="eleves.html"]'],
    roles: ['directeur', 'prefet', 'secretaire'],
    obligatoire: true,
    depend: ['classes'],
    details: [
      "« Ajouter » pour une inscription unitaire, « Importer » pour une liste entière.",
      "Laissez le matricule vide : il est généré automatiquement et reste unique dans l'école.",
      "Affectez la classe : un élève sans classe n'apparaît ni dans les listes, ni dans les bulletins.",
      "Nom, postnom, prénom, sexe, date et lieu de naissance.",
      "Responsable, téléphone, EMAIL et adresse : l'email du responsable est la seule adresse par laquelle les parents recevront les messages de l'école.",
      "En import : associez chaque colonne du fichier au bon champ, puis contrôlez l'aperçu des cinq premières lignes avant de valider."
    ],
    detection: 'eleves',
    etape_config: 10,
  },
  {
    code: 'creneaux',
    categorie: 'facultatif',
    fonctionnalite: 'emploi_du_temps',
    type: 'configuration',
    titre: 'Heures de cours',
    resume: "Définissez les heures de cours de la journée.",
    ecran: 'emploi-du-temps.html',
    ancre: 'Emploi du temps',
    selecteurs: ['#bouton-ajouter-creneau', '#onglet-config', '#bouton-enregistrer-config', '.nav-item[href="emploi-du-temps.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: ['identite_ecole'],
    details: [
      "Ouvrez l'onglet « Configuration ».",
      "Si l'école fonctionne en plusieurs vacations, créez-les d'abord : nom, cycle, ordre.",
      "Puis, pour chaque heure de la journée : libellé, heure de début, heure de fin, ordre.",
      "Cliquez sur « Ajouter un créneau », puis sur « Enregistrer la configuration ».",
      "Un mercredi écourté ne se règle pas en créant une seconde grille : utilisez « Horaires exceptionnels » sur ce même écran."
    ],
    detection: 'creneaux',
    etape_config: 4,
  },
  {
    /* ------------------------------------------------------------------
       CE QUI A CHANGÉ ICI, ET POURQUOI C'ÉTAIT UN BLOCAGE

       L'étape était obligatoire, pointait vers `generateur-modeles.html` et
       demandait « Cliquez sur Nouveau modèle ». Trois problèmes cumulés :

         · l'écran du générateur est verrouillé par `modeles_personnalises`,
           que l'offre Ascension ne comprend pas. Le didacticiel envoyait donc
           l'école contre un 402 qu'elle n'avait aucun moyen de franchir ;
         · aucune école n'a l'OBLIGATION de dessiner son propre bulletin. Les
           gabarits officiels RDC sont livrés avec Ardoise, et le générateur
           de bulletins retombe dessus quand aucun modèle personnalisé n'est
           actif (voir `bulletins.controller.js`, sélection `modeleActif`) ;
         · tant que l'étape restait « à faire », la progression plafonnait, et
           l'école croyait son installation incomplète alors qu'elle pouvait
           imprimer ses bulletins depuis le premier jour.

       L'étape devient donc : VÉRIFIER quel modèle s'applique. Elle est
       satisfaite dès qu'un modèle utilisable existe — officiel ou propre à
       l'école. La CRÉATION d'un modèle personnalisé devient une étape
       distincte, facultative, et conditionnée à l'offre qui l'ouvre.
       ------------------------------------------------------------------ */
    code: 'modeles_bulletins',
    categorie: 'recommande',
    type: 'configuration',
    titre: 'Modèle de bulletin des classes',
    resume: "Vérifiez le modèle appliqué à chaque classe. Les modèles officiels RDC sont fournis : rien à créer.",
    ecran: 'classes.html',
    ancre: 'Classes',
    selecteurs: ['#corps-tableau-classes', '#bouton-ajouter-classe', '.nav-item[href="classes.html"]'],
    roles: ['directeur'],
    obligatoire: true,
    depend: ['classes'],
    details: [
      "Ardoise fournit les modèles officiels de la RDC — primaire, secondaire, terminale. Ils sont utilisables tels quels : vous n'avez AUCUN modèle à créer pour imprimer un bulletin conforme.",
      "Ouvrez « Classes » et cliquez sur une classe.",
      "Vérifiez le cycle et la variante : c'est ce couple qui décide du gabarit officiel appliqué.",
      "Renseignez les champs « Modèle de période » et « Modèle annuel » UNIQUEMENT si votre école utilise un modèle qui lui est propre. Laissés vides, les gabarits officiels s'appliquent.",
      "Imprimez un bulletin d'essai depuis « Bulletins » pour contrôler le rendu avant la fin de période."
    ],
    detection: 'modeles_bulletins',
    etape_config: 11,
  },
  {
    /* La création d'un modèle propre à l'école. Facultative par nature, et
       verrouillée par l'offre : `modeles_personnalises` ouvre l'éditeur.
       Une école Ascension ne verra jamais cette étape — ni dans la checklist,
       ni dans le centre d'apprentissage. */
    code: 'modeles_personnalises',
    categorie: 'facultatif',
    fonctionnalite: 'modeles_personnalises',
    type: 'configuration',
    titre: 'Modèle de bulletin personnalisé',
    resume: "Facultatif : dessinez le bulletin propre à votre école plutôt que d'utiliser le gabarit officiel.",
    ecran: 'generateur-modeles.html',
    ancre: 'Modèles de bulletins',
    selecteurs: ['#bouton-nouveau-modele', '#grille-modeles', '.nav-item[href="generateur-modeles.html"]'],
    roles: ['directeur'],
    obligatoire: false,
    depend: ['classes'],
    depend_souple: ['modeles_bulletins'],
    details: [
      "N'entreprenez cette étape que si le gabarit officiel ne convient pas : il est conforme et déjà en service.",
      "Cliquez sur « Nouveau modèle ».",
      "Donnez-lui un nom, puis choisissez son type (période, semestre, annuel) et sa variante (primaire, secondaire, terminale).",
      "Téléversez votre modèle avec « Choisir un fichier ».",
      "« Suggérer les zones » place automatiquement les zones de texte ; corrigez ensuite chacune (clé, position, police, taille, alignement).",
      "Cliquez sur « Activer » : un modèle non activé ne sera JAMAIS utilisé, et la génération semblera ne rien faire.",
      "Affectez enfin le modèle aux classes concernées."
    ],
    detection: 'modele_personnalise',
    etape_config: 11,
  },
  {
    code: 'discipline_bareme',
    categorie: 'facultatif',
    fonctionnalite: 'discipline',
    type: 'configuration',
    titre: 'Barème de discipline',
    resume: "Importez votre règlement intérieur et validez le barème.",
    ecran: 'discipline.html',
    ancre: 'Discipline',
    selecteurs: ['#onglet-parametres', '#bouton-analyser-reglement', '#champ-nom-reglement', '.nav-item[href="discipline.html"]'],
    roles: ['directeur'],
    obligatoire: false,
    depend: ['identite_ecole'],
    details: [
      "Ouvrez l'onglet « Paramètres » de l'écran Discipline.",
      "Fixez le capital de conduite par période, et enregistrez ce champ.",
      "Téléversez le règlement intérieur, ou collez son texte, ou cliquez sur « Générer » pour partir d'un règlement type.",
      "Cliquez sur « Analyser » : un barème est proposé ligne par ligne — code, libellé, sens positif ou négatif, points, mesure.",
      "Relisez et corrigez CHAQUE ligne : ce sont des sanctions réelles pour des enfants réels.",
      "Cliquez sur « Valider ». Tant que ce bouton n'a pas été cliqué, la plateforme continue d'appliquer un barème générique."
    ],
    detection: 'discipline_bareme',
    etape_config: 12,
  },
  {
    code: 'frais',
    categorie: 'facultatif',
    type: 'configuration',
    titre: 'Frais scolaires',
    resume: "Définissez les frais par classe, dans votre devise.",
    ecran: 'frais-scolaires.html',
    ancre: 'Frais scolaires',
    selecteurs: ['#bouton-ajouter-config', '#onglet-config', '#formulaire-config', '.nav-item[href="frais-scolaires.html"]'],
    roles: ['directeur', 'comptable'],
    obligatoire: false,
    depend: ['classes'],
    details: [
      "Ouvrez l'onglet « Configuration ».",
      "Choisissez l'année scolaire, puis la classe — laissez le champ classe vide pour appliquer le montant à TOUTES les classes.",
      "Renseignez le libellé (il apparaîtra sur les reçus), le montant et la devise.",
      "Cliquez sur « Ajouter ».",
      "Vérifiez le taux de change dans son bloc dédié, avec son propre bouton Enregistrer.",
      "Dans le bloc « Contrôle », décidez si un bulletin peut être bloqué pour impayé, et avec quelle tolérance."
    ],
    detection: 'frais',
    etape_config: 13,
  },
  {
    code: 'emploi_du_temps',
    categorie: 'facultatif',
    fonctionnalite: 'emploi_du_temps',
    type: 'configuration',
    titre: 'Emploi du temps',
    resume: "Placez les séances dans la grille hebdomadaire.",
    ecran: 'emploi-du-temps.html',
    ancre: 'Emploi du temps',
    selecteurs: ['#grille-classe', '#onglets', '.nav-item[href="emploi-du-temps.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    // `creneaux` est indispensable : sans heure de cours, il n'y a pas de
    // grille où poser quoi que ce soit. `attribution_cours` ne l'est pas —
    // on peut placer la séance d'une branche avant de savoir qui l'assurera,
    // et c'est même l'ordre habituel dans une école qui recrute en septembre.
    // Le classer en dépendance dure laissait l'emploi du temps bloqué pour
    // une raison qui n'en était pas une.
    depend: ['creneaux'],
    depend_souple: ['attribution_cours'],
    details: [
      "Ouvrez l'onglet « Classe » et choisissez la classe.",
      "La grille croise les jours et les heures de cours définies en configuration.",
      "Cliquez dans une case : les cours de la classe et leur professeur sont proposés.",
      "Placez chaque séance. L'onglet « Mon emploi du temps » montrera ensuite à chaque enseignant ses propres heures.",
      "Pour un jour particulier, passez par « Horaires exceptionnels » plutôt que de modifier la grille de toute la semaine."
    ],
    detection: 'emploi_du_temps',
    etape_config: 14,
  },

  /* ---------- Découverte : direction ---------- */
  {
    code: 'decouverte_tableau_bord',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Votre tableau de bord',
    resume: "Effectifs, moyennes, impayés, alertes : la santé de l'école en un écran.",
    ecran: 'dashboard-directeur.html',
    ancre: 'Tableau de bord',
    // `.cartes-indicateurs` n'existe dans aucune page : les cartes du haut
    // portent chacune leur propre identifiant (`#carte-eleves`,
    // `#carte-classes`…) et n'ont pas de conteneur nommé. Le projecteur
    // cherchait donc dix secondes, puis retombait sur l'entrée de menu.
    // `#lanceur` est écarté du premier rang : c'est un `<div>` vide au
    // chargement, et éclairer un rectangle de zéro pixel de haut ne montre
    // rien.
    selecteurs: ['#carte-eleves', '#lanceur', '.nav-item[href="dashboard-directeur.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: [],
    details: [
      "Les cartes du haut donnent l'effectif, la moyenne d'établissement, les impayés et les alertes du moment.",
      "Chaque carte est cliquable : elle mène à l'écran qui détaille le chiffre.",
      "Le bloc des alertes signale ce qui est commencé mais incomplet — cotes manquantes, classes sans niveau, périodes sans dates.",
      "C'est l'écran à ouvrir en premier chaque matin."
    ],
    detection: null,
  },
  {
    code: 'decouverte_rapports',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Rapports et statistiques',
    resume: "Palmarès, taux de réussite, exports : tout ce qui se présente en réunion.",
    ecran: 'rapports.html',
    ancre: 'Rapports',
    selecteurs: ['#onglets', '#bouton-exporter', '.nav-item[href="rapports.html"]'],
    roles: ['directeur', 'prefet', 'secretaire', 'comptable'],
    obligatoire: false,
    depend: [],
    details: [
      "Choisissez le bloc : effectifs, réussite, palmarès, moyennes, portées, finances, assiduité.",
      "Le bouton « Exporter », en haut à droite du bloc, produit le fichier.",
      "Les chiffres portent sur l'année ACTIVE : pour une année clôturée, passez par Archives."
    ],
    detection: null,
  },
  {
    code: 'decouverte_journal',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: "Journal d'activité",
    resume: "Qui a modifié quoi, et quand. Utile le jour où une note change sans explication.",
    ecran: 'journal.html',
    ancre: "Journal d'activité",
    // La barre de filtres du journal n'a pas d'identifiant de conteneur : ses
    // champs en portent un chacun (`#filtre-action`, `#filtre-auteur`…).
    // `#filtres-journal` ne désignait rien.
    selecteurs: ['#filtre-action', '#bouton-filtrer', '.nav-item[href="journal.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: [],
    details: [
      "Filtrez par utilisateur, par type d'action ou par période.",
      "Chaque ligne dit qui a fait quoi, sur quoi, et quand.",
      "Les validations, dévalidations et réouvertures de période y sont toutes tracées.",
      "C'est l'écran à ouvrir le jour où une note change sans explication."
    ],
    detection: null,
  },

  /* ---------- Découverte : modules d'offre supérieure ----------
     Ces trois écrans existent réellement dans le produit (orientation.html,
     repechage.html, site-public.html) et leurs routes sont verrouillées par
     l'offre. Ils sont donc déclarés ici avec leur `fonctionnalite` : une école
     qui ne les a pas ne les verra JAMAIS, et une école qui monte en gamme les
     découvre comme des étapes facultatives — sans que son parcours reparte à
     zéro. C'est le seul mécanisme du fichier qui fasse apparaître une étape
     après coup, et il est volontairement limité aux découvertes. */
  {
    code: 'decouverte_orientation',
    categorie: 'decouverte',
    fonctionnalite: 'orientation',
    type: 'decouverte',
    titre: "Orientation des élèves",
    resume: "Vœux, critères par option, répartition au mérite en fin de cycle.",
    ecran: 'orientation.html',
    ancre: 'Orientation',
    selecteurs: ['.nav-item[href="orientation.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: [],
    details: [
      "L'orientation se traite AVANT la promotion de fin d'année.",
      "Chaque option porte un critère d'accès : moyenne globale, ou une branche précise avec son minimum.",
      "Le titulaire saisit les vœux de sa classe ; la direction répartit.",
      "« Répartir » propose une attribution au mérite ; les cas particuliers se corrigent ensuite un par un, avec un motif."
    ],
    detection: null,
  },
  {
    code: 'decouverte_repechage',
    categorie: 'decouverte',
    fonctionnalite: 'repechage',
    type: 'decouverte',
    titre: "Session de repêchage",
    resume: "Seconde chance de fin d'année, avec ses seuils et sa politique de note.",
    ecran: 'repechage.html',
    ancre: 'Repêchage',
    selecteurs: ['.nav-item[href="repechage.html"]'],
    roles: ['directeur', 'prefet'],
    obligatoire: false,
    depend: [],
    details: [
      "Les critères d'éligibilité et la politique de note se fixent à la CRÉATION de la session et ne se changent plus ensuite.",
      "La liste des éligibles se calcule à partir des seuils de l'école ; on peut en retirer quelqu'un, avec un motif.",
      "La saisie des copies est ouverte aux enseignants, comme les cotes ordinaires.",
      "La clôture prononce les décisions et recalcule les moyennes : elle se fait après la saisie de toutes les copies."
    ],
    detection: null,
  },
  {
    code: 'decouverte_site_public',
    categorie: 'decouverte',
    fonctionnalite: 'site_public',
    type: 'decouverte',
    titre: "Site public de l'école",
    resume: "Vitrine, annonces et consultation des résultats par les familles.",
    ecran: 'site-public.html',
    ancre: 'Site public',
    selecteurs: ['.nav-item[href="site-public.html"]'],
    roles: ['directeur', 'secretaire'],
    obligatoire: false,
    depend: [],
    details: [
      "Rien n'est visible publiquement tant que le site n'est pas activé.",
      "Seuls les résultats explicitement publiés sortent : aucune donnée ne s'échappe par défaut.",
      "Les annonces se rédigent et se dépublient depuis le même écran.",
      "Les codes d'accès permettent aux familles de consulter les résultats de leur enfant, et se régénèrent individuellement."
    ],
    detection: null,
  },

  /* ---------- Découverte : enseignant ---------- */
  {
    code: 'decouverte_mes_cours',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Mes cours',
    resume: "Les classes et les branches qui vous sont attribuées.",
    ecran: 'espace-professeur.html',
    ancre: 'Mes cours',
    selecteurs: ['.nav-item[href="espace-professeur.html"]'],
    roles: ['professeur'],
    obligatoire: true,
    depend: [],
    details: [
      "La liste montre les classes et les branches qui vous sont attribuées.",
      "Chaque ligne mène directement à la saisie des cotes de ce cours.",
      "Si la liste est vide, la direction n'a pas encore fait l'attribution : signalez-le, ce n'est pas une panne de votre côté."
    ],
    detection: null,
  },
  {
    code: 'decouverte_notes',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Saisir les cotes',
    resume: "Choisissez la classe, le cours et la période, puis saisissez.",
    ecran: 'notes.html',
    ancre: 'Notes',
    selecteurs: ['#entete-grille', '#corps-grille', '#bouton-enregistrer-notes', '.nav-item[href="notes.html"]'],
    roles: ['professeur', 'titulaire', 'prefet', 'directeur'],
    obligatoire: true,
    depend: [],
    details: [
      "Choisissez la classe, puis le cours, puis la période : la grille ne s'affiche qu'une fois les trois choisis.",
      "Saisissez les points. Le maximum applicable est rappelé en haut de colonne.",
      "Laissez vide ce qui n'a pas été composé : un vide est ignoré, un zéro compte.",
      "Cliquez sur « Enregistrer ».",
      "« Ajouter un travail » permet de noter par interrogations et devoirs plutôt qu'en une seule cote."
    ],
    detection: null,
  },
  {
    code: 'decouverte_presences',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: "Faire l'appel",
    resume: "Marquez les absents ; le reste est présent par défaut.",
    ecran: 'presences.html',
    ancre: 'Présences',
    selecteurs: ['#bouton-tout-present', '#bouton-enregistrer', '.nav-item[href="presences.html"]'],
    roles: ['professeur', 'titulaire', 'charge_presences', 'directeur_discipline'],
    obligatoire: true,
    depend: [],
    details: [
      "Choisissez la classe et le jour ; le jour du jour est proposé par défaut.",
      "Tout le monde est présent par défaut : ne marquez que les absents et les retardataires.",
      "Indiquez un motif quand il est connu — c'est ce qui distingue une absence justifiée.",
      "Cliquez sur « Enregistrer »."
    ],
    detection: null,
  },
  {
    code: 'decouverte_emploi_du_temps',
    categorie: 'decouverte',
    fonctionnalite: 'emploi_du_temps',
    type: 'decouverte',
    titre: 'Mon emploi du temps',
    resume: "Vos heures de la semaine, telles que la direction les a placées.",
    ecran: 'emploi-du-temps.html',
    ancre: 'Emploi du temps',
    selecteurs: ['.nav-item[href="emploi-du-temps.html"]'],
    roles: ['professeur', 'titulaire'],
    obligatoire: false,
    depend: [],
    details: [
      "L'onglet « Mon emploi du temps » montre vos heures de la semaine, telles que la direction les a placées.",
      "Une case vide signifie qu'aucune séance n'a été placée, pas que vous êtes libre.",
      "Les jours fériés déclarés au Calendrier apparaissent grisés."
    ],
    detection: null,
  },

  /* ---------- Découverte : titulaire ---------- */
  {
    code: 'decouverte_ma_classe',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Ma classe',
    resume: "L'effectif, les résultats et le suivi de votre classe.",
    ecran: 'espace-titulaire.html',
    ancre: 'Ma classe',
    selecteurs: ['.nav-item[href="espace-titulaire.html"]'],
    roles: ['titulaire'],
    obligatoire: true,
    depend: [],
    details: [
      "L'effectif de votre classe, avec la fiche de chaque élève à un clic.",
      "Les résultats de la classe pour la période en cours.",
      "Le suivi de l'assiduité et de la discipline.",
      "C'est le point de départ de tout ce que vous faites comme titulaire."
    ],
    detection: null,
  },
  {
    code: 'decouverte_cours_classe',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Cours de la classe',
    resume: "L'état de saisie de chaque branche : qui a rendu ses cotes, qui non.",
    ecran: 'cours-classe-titulaire.html',
    ancre: 'Cours de la classe',
    selecteurs: ['.nav-item[href="cours-classe-titulaire.html"]'],
    roles: ['titulaire'],
    obligatoire: true,
    depend: [],
    details: [
      "La liste de toutes les branches de votre classe, avec l'état de saisie de chacune.",
      "Une branche en attente signale un collègue qui n'a pas encore rendu ses cotes.",
      "C'est cet écran qui vous dit si les bulletins peuvent être générés — avant même de les lancer."
    ],
    detection: null,
  },
  {
    code: 'decouverte_bulletins',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Bulletins',
    resume: "Générez, vérifiez un bulletin réel, puis signez.",
    ecran: 'bulletins.html',
    ancre: 'Bulletins',
    selecteurs: ['#bouton-generer-pdf', '#corps-tableau', '#bouton-signer-tout', '.nav-item[href="bulletins.html"]'],
    roles: ['titulaire', 'directeur', 'prefet', 'secretaire'],
    obligatoire: true,
    depend: [],
    details: [
      "Choisissez la classe et la période.",
      "Vérifiez d'abord que les cotes sont saisies et validées.",
      "Générez, puis ouvrez UN bulletin en aperçu avant d'imprimer toute la classe.",
      "Renseignez conduite, application et observation via « Appréciations ».",
      "Signez, puis imprimez. Un bulletin signé ne se modifie plus, sauf réglage contraire de l'école."
    ],
    detection: null,
  },
  {
    code: 'decouverte_discipline',
    categorie: 'decouverte',
    fonctionnalite: 'discipline',
    type: 'decouverte',
    titre: 'Discipline',
    resume: "Signalez un fait ; les points et la mesure sont pré-remplis d'après le règlement.",
    ecran: 'discipline.html',
    ancre: 'Discipline',
    selecteurs: ['#bouton-signaler', '.nav-item[href="discipline.html"]'],
    roles: ['titulaire', 'directeur_discipline'],
    obligatoire: false,
    depend: [],
    details: [
      "Onglet « Incidents » : choisissez la classe, la période, puis l'élève.",
      "Choisissez le type de fait — les fautes retirent des points, les faits à valoriser en rendent.",
      "Points et mesure sont pré-remplis d'après le règlement validé ; ajustez si le contexte le justifie.",
      "Cliquez sur « Signaler ».",
      "En fin de période, l'onglet « Conduite » reporte le capital restant sur les bulletins."
    ],
    detection: null,
  },

  /* ---------- Découverte : secrétariat ---------- */
  {
    code: 'decouverte_secretariat',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Accueil Secrétariat',
    resume: "Les tâches du jour : inscriptions en attente, dossiers incomplets.",
    ecran: 'espace-secretaire.html',
    ancre: 'Accueil Secrétariat',
    selecteurs: ['.nav-item[href="espace-secretaire.html"]'],
    roles: ['secretaire'],
    obligatoire: true,
    depend: [],
    details: [
      "Les tâches du jour : inscriptions en attente, dossiers incomplets, paiements récents.",
      "Chaque bloc mène à l'écran qui permet de traiter le point.",
      "Les dossiers signalés incomplets sont ceux dont il manque la classe, le responsable ou son adresse électronique."
    ],
    detection: null,
  },
  {
    code: 'decouverte_eleves',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Registre des élèves',
    resume: "Recherche, fiche complète, affectation de classe, sortie d'élève.",
    ecran: 'eleves.html',
    ancre: 'Élèves',
    selecteurs: ['#bouton-ajouter', '.nav-item[href="eleves.html"]'],
    roles: ['secretaire'],
    obligatoire: true,
    depend: [],
    details: [
      "La recherche porte sur le nom, le postnom et le matricule.",
      "Un clic sur le nom ouvre la fiche complète : identité, classe, résultats, historique des années précédentes.",
      "« Ajouter » inscrit un élève, « Importer » en crée une liste entière.",
      "« Départ de l'élève » enregistre une sortie avec son motif, sans rien effacer de son historique."
    ],
    detection: null,
  },
  {
    code: 'decouverte_inscriptions',
    categorie: 'decouverte',
    fonctionnalite: 'concours_admission',
    type: 'decouverte',
    titre: 'Inscriptions et concours',
    resume: "Ouvrez une session pour l'année d'entrée, pas pour l'année en cours.",
    ecran: 'inscriptions.html',
    ancre: 'Inscriptions',
    selecteurs: ['.nav-item[href="inscriptions.html"]'],
    roles: ['secretaire', 'directeur', 'prefet'],
    obligatoire: false,
    depend: [],
    details: [
      "Vérifiez d'abord que l'année SUIVANTE existe et que ses classes sont créées.",
      "Créez la session : libellé, année d'entrée des admis, dates, places, mode d'admission.",
      "Cochez les classes d'accueil ; le compteur donne les places RESTANTES après la promotion interne.",
      "Déclarez les épreuves et leur correcteur.",
      "Après correction, publiez les résultats puis convertissez les admis en élèves."
    ],
    detection: null,
  },
  {
    code: 'decouverte_archives',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Archives',
    resume: "Les années clôturées restent consultables et imprimables.",
    ecran: 'archives.html',
    ancre: 'Archives',
    selecteurs: ['.nav-item[href="archives.html"]'],
    roles: ['secretaire', 'directeur'],
    obligatoire: false,
    depend: [],
    details: [
      "Choisissez l'année clôturée, puis la classe, puis l'élève.",
      "Les bulletins se réimpriment avec la mise en page de l'époque.",
      "L'export d'une année ou d'une classe entière est proposé en haut de l'écran.",
      "Une année clôturée n'est jamais supprimée : elle change simplement d'écran."
    ],
    detection: null,
  },

  /* ---------- Découverte : comptabilité ---------- */
  {
    code: 'decouverte_paiements',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Encaisser un paiement',
    resume: "Recherchez l'élève, saisissez le montant, délivrez le reçu numéroté.",
    ecran: 'frais-scolaires.html',
    ancre: 'Frais scolaires',
    selecteurs: ['#onglet-paiements', '#bouton-afficher', '#corps-tableau', '.nav-item[href="frais-scolaires.html"]'],
    roles: ['comptable', 'secretaire'],
    obligatoire: true,
    depend: [],
    details: [
      "Onglet « Paiements » : choisissez la classe, puis l'élève. Le solde dû s'affiche.",
      "Renseignez le frais réglé, le montant, la devise et la méthode.",
      "Enregistrez : le reçu numéroté est délivré automatiquement — ne le recréez jamais à la main.",
      "Vérifiez le taux de change avant une journée d'encaissement en devise secondaire."
    ],
    detection: null,
  },
  {
    code: 'decouverte_dettes',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Impayés et dettes',
    resume: "Qui doit quoi, y compris les dettes reportées des années antérieures.",
    ecran: 'frais-scolaires.html',
    ancre: 'Frais scolaires',
    selecteurs: ['#onglet-dettes', '#corps-tableau-dettes', '.nav-item[href="frais-scolaires.html"]'],
    roles: ['comptable'],
    obligatoire: true,
    depend: [],
    details: [
      "Onglet « Dettes » : le dû, le réglé et le solde, par classe et par élève.",
      "Les dettes des années antérieures apparaissent dans un bloc distinct.",
      "Pour un cas social, posez une « Dérogation » sur la fiche de l'élève plutôt que de désactiver le blocage pour tous."
    ],
    detection: null,
  },
  {
    code: 'decouverte_comptabilite',
    categorie: 'decouverte',
    fonctionnalite: 'comptabilite',
    type: 'decouverte',
    titre: 'Caisse et charges',
    resume: "Dépenses, rémunérations, mouvements de caisse.",
    ecran: 'comptabilite.html',
    ancre: 'Comptabilité',
    selecteurs: ['.nav-item[href="comptabilite.html"]'],
    roles: ['comptable', 'directeur'],
    obligatoire: false,
    depend: [],
    details: [
      "Créez d'abord vos catégories : un nom, et un sens (entrée ou sortie).",
      "Ajoutez un mouvement : sens, catégorie, libellé, montant, devise, date, bénéficiaire, pièce justificative.",
      "Les frais scolaires encaissés remontent automatiquement : ne les ressaisissez pas, vous les compteriez deux fois.",
      "Les blocs « Contrats » et « Paie » gèrent les rémunérations : préparer le mois, ajuster primes et retenues, puis payer."
    ],
    detection: null,
  },

  /* ---------- Découverte : commun ---------- */
  {
    code: 'decouverte_messages',
    categorie: 'decouverte',
    type: 'decouverte',
    titre: 'Messagerie et assistant',
    resume: "Vos messages, et l'assistant qui répond à vos questions sur la plateforme.",
    ecran: 'messages.html',
    ancre: 'Messages',
    selecteurs: ['#onglet-envoyer', '#onglet-assistant', '.nav-item[href="messages.html"]'],
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    obligatoire: false,
    depend: [],
    details: [
      "L'onglet « Réception » regroupe les messages qui vous sont adressés.",
      "L'onglet d'envoi permet d'écrire à une ou plusieurs personnes : recherchez le nom, cochez-le, rédigez, envoyez.",
      "La direction et le secrétariat disposent en plus de la diffusion à un rôle, à une classe ou aux parents.",
      "L'onglet « Assistant » répond à vos questions sur l'utilisation de la plateforme."
    ],
    detection: null,
  }
];

/* ==========================================================================
   2. PARCOURS PAR RÔLE

   L'ORDRE de cette liste est l'ordre de PRÉFÉRENCE, pas l'ordre imposé : les
   dépendances peuvent encore repousser une étape plus loin. Une étape absente
   de la liste d'un rôle ne lui est jamais proposée, même si `ETAPES.roles` la
   mentionne — c'est ce qui permet de donner à un préfet la configuration
   pédagogique sans le tableau de bord du directeur.

   Le SUPER ADMIN n'a volontairement pas de parcours : il n'appartient à aucune
   école, et l'accompagner à configurer un établissement qui n'est pas le sien
   n'aurait aucun sens.
   ========================================================================== */

const PARCOURS_ROLE = {
  directeur: [
    'profil', 'identite_ecole', 'annee_scolaire', 'periodes', 'sections_options',
    'classes', 'cours', 'classe_cours', 'personnel', 'attribution_cours', 'titulaires',
    'eleves', 'modeles_bulletins', 'creneaux', 'emploi_du_temps',
    'discipline_bareme', 'frais', 'modeles_personnalises',
    'decouverte_tableau_bord', 'decouverte_rapports', 'decouverte_bulletins',
    'decouverte_journal', 'decouverte_orientation', 'decouverte_repechage',
    'decouverte_site_public', 'decouverte_messages'
  ],
  prefet: [
    'profil', 'annee_scolaire', 'periodes', 'sections_options', 'classes',
    'cours', 'classe_cours', 'attribution_cours', 'titulaires', 'eleves',
    'creneaux', 'emploi_du_temps',
    'decouverte_tableau_bord', 'decouverte_notes', 'decouverte_bulletins',
    'decouverte_rapports', 'decouverte_orientation', 'decouverte_repechage',
    'decouverte_messages'
  ],
  secretaire: [
    'profil',
    'decouverte_secretariat', 'decouverte_eleves', 'eleves',
    'decouverte_inscriptions', 'decouverte_paiements', 'decouverte_bulletins',
    'decouverte_archives', 'decouverte_site_public', 'decouverte_messages'
  ],
  comptable: [
    'profil', 'frais',
    'decouverte_paiements', 'decouverte_dettes', 'decouverte_comptabilite',
    'decouverte_rapports', 'decouverte_messages'
  ],
  professeur: [
    'profil',
    'decouverte_mes_cours', 'decouverte_notes', 'decouverte_presences',
    'decouverte_emploi_du_temps', 'decouverte_messages'
  ],
  titulaire: [
    'profil',
    'decouverte_ma_classe', 'decouverte_cours_classe', 'decouverte_notes',
    'decouverte_presences', 'decouverte_bulletins', 'decouverte_discipline',
    'decouverte_messages'
  ],
  charge_presences: [
    'profil', 'decouverte_presences', 'decouverte_messages'
  ],
  directeur_discipline: [
    'profil', 'decouverte_discipline', 'decouverte_presences', 'decouverte_messages'
  ],
  // Les espaces parent et élève n'existent pas encore comme pages dédiées dans
  // Ardoise. Le parcours reste donc volontairement minimal : compléter son
  // profil, savoir où lire les messages de l'école. Le jour où ces espaces
  // existent, il suffit d'ajouter deux codes ici.
  parent: ['profil', 'decouverte_messages'],
  eleve: ['profil', 'decouverte_messages']
};

/* ==========================================================================
   3. MINI-TUTORIELS CONTEXTUELS

   Affichés UNE FOIS, à la première ouverture d'un écran, après l'onboarding
   initial. Clé = nom du fichier HTML.

   `apres_onboarding: false` signale les écrans dont l'explication est utile
   même pendant le parcours guidé — typiquement ceux où l'on arrive en suivant
   une étape.
   ========================================================================== */

const TUTORIELS_CONTEXTUELS = {
  'notes.html': {
    titre: 'Encoder une cote',
    roles: ['professeur', 'titulaire', 'prefet', 'directeur'],
    points: [
      "Choisissez d'abord la classe, le cours et la période : la grille ne s'affiche qu'ensuite.",
      "Le maximum du cours est rappelé en haut de colonne.",
      "Laissez vide ce qui n'a pas été composé. Zéro et vide ne veulent pas dire la même chose : un vide est ignoré, un zéro compte.",
      "Une fois les cotes validées par la direction, elles se verrouillent."
    ],
    apres_onboarding: false,
  },
  'bulletins.html': {
    titre: 'Générer les bulletins',
    roles: ['directeur', 'prefet', 'titulaire', 'secretaire'],
    points: [
      "Vérifiez que toutes les cotes de la période sont saisies et validées.",
      "Lancez la génération, puis ouvrez UN bulletin pour contrôler le rendu avant d'imprimer la classe entière.",
      "Un bulletin signé ne se modifie plus, sauf si l'école a autorisé la modification après signature."
    ],
    apres_onboarding: false,
  },
  'frais-scolaires.html': {
    titre: 'Paiements et reçus',
    roles: ['comptable', 'secretaire', 'directeur'],
    points: [
      "Un paiement en devise secondaire est converti au taux enregistré dans les paramètres. Vérifiez qu'il est à jour.",
      "Le reçu est numéroté automatiquement : ne le recréez pas à la main.",
      "Les dettes des années antérieures apparaissent séparément des frais de l'année en cours."
    ],
    apres_onboarding: false,
  },
  'presences.html': {
    titre: "Faire l'appel",
    roles: ['professeur', 'titulaire', 'charge_presences', 'directeur_discipline', 'prefet', 'directeur'],
    points: [
      "Tout le monde est présent par défaut : vous ne marquez que les absents et les retardataires.",
      "Indiquez un motif quand il est connu — c'est ce qui distingue une absence justifiée.",
      "Qui fait l'appel dépend du réglage de l'école (Paramètres › Qui fait l'appel)."
    ],
    apres_onboarding: false,
  },
  'discipline.html': {
    titre: 'Signaler un fait',
    roles: ['titulaire', 'directeur_discipline', 'prefet', 'directeur'],
    points: [
      "Les fautes retirent des points du capital de conduite ; les faits à valoriser en rendent.",
      "Points et mesure sont pré-remplis d'après le règlement de l'école ; ajustez si le contexte le justifie.",
      "En fin de période, « Reporter sur les bulletins » convertit le capital restant en appréciation."
    ],
    apres_onboarding: true,
  },
  'rapports.html': {
    titre: 'Lire les rapports',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable'],
    points: [
      "Les chiffres portent sur l'année ACTIVE. Pour une année clôturée, passez par Archives.",
      "Chaque tableau s'exporte : le bouton d'export se trouve en haut à droite du bloc."
    ],
    apres_onboarding: true,
  },
  'emploi-du-temps.html': {
    titre: "L'emploi du temps",
    roles: ['directeur', 'prefet', 'professeur', 'titulaire'],
    points: [
      "Les heures de cours doivent exister avant de pouvoir placer une séance.",
      "Un mercredi écourté ne se règle pas en créant une seconde grille : utilisez « Horaires exceptionnels »."
    ],
    apres_onboarding: true,
  },
  'inscriptions.html': {
    titre: "Ouvrir un concours",
    roles: ['directeur', 'prefet', 'secretaire'],
    points: [
      "L'année d'entrée est celle où les admis entreront — pas celle du test.",
      "Le compteur affiche les places RESTANTES, après la promotion interne."
    ],
    apres_onboarding: true,
  },
  'classes.html': {
    titre: 'Classes, options et cours',
    roles: ['directeur', 'prefet'],
    points: [
      "Le NIVEAU (1 à 8) et la DIVISION se saisissent dans le formulaire de la classe. Sans eux, la promotion de fin d'année ne peut pas s'exécuter — c'est ce que signale la mention « niveau manquant » dans le tableau.",
      "Les cours ne se créent pas depuis l'écran « Cours » : ouvrez une classe, puis le bloc « Cours de cette classe ».",
      "L'onglet « Structure » porte les sections et les options du secondaire.",
      "Cochez « Classe terminale » sur la classe où les élèves sortent diplômés, sinon la promotion cherchera une classe supérieure inexistante."
    ],
    apres_onboarding: false
  },
  'utilisateurs.html': {
    titre: 'Créer un compte',
    roles: ['directeur'],
    points: [
      "L'email est l'identifiant de connexion : il doit être unique dans l'école.",
      "Une personne n'a qu'un seul rôle, sauf deux combinaisons autorisées : Professeur + Titulaire, et Préfet + Directeur.",
      "L'attribution des cours ne se fait pas ici mais depuis chaque classe. Un professeur sans cours attribué ouvre un écran vide."
    ],
    apres_onboarding: false
  },
  'annee-scolaire.html': {
    titre: "L'année et ses périodes",
    roles: ['directeur', 'prefet'],
    points: [
      "Créer l'année ne suffit pas : il faut cliquer sur « Activer » sur sa ligne.",
      "Chaque période a besoin de ses DATES, sinon la plateforme ne sait pas laquelle est en cours.",
      "N'oubliez pas les périodes de type « Examen » : c'est le maximum d'examen des cours qui s'y applique.",
      "L'onglet « Promotion » sert en fin d'année : reporter la structure, puis faire monter les élèves."
    ],
    apres_onboarding: false
  },
  'parametres.html': {
    titre: "Les réglages de l'établissement",
    roles: ['directeur'],
    points: [
      "Chaque bloc de cet écran a SON bouton Enregistrer : en remplir trois et n'en enregistrer qu'un est l'erreur la plus fréquente ici.",
      "Le type d'enseignement commande ce que tous les autres écrans proposent : choisissez-le bien dès le départ.",
      "« Qui fait l'appel ? » décide à quel rôle l'écran Présences est ouvert.",
      "Le cachet et la signature du directeur sont apposés sur les bulletins signés : sans eux, le bulletin sort nu."
    ],
    apres_onboarding: false
  },
  'comptabilite.html': {
    titre: 'Caisse, charges et paie',
    roles: ['comptable', 'directeur'],
    points: [
      "Créez vos catégories (entrées et sorties) avant le premier mouvement.",
      "Les frais scolaires encaissés remontent automatiquement : ne les ressaisissez pas ici, vous les compteriez deux fois.",
      "La paie se prépare par mois à partir des contrats actifs, puis se paie ligne par ligne — le mouvement de caisse est créé tout seul."
    ],
    apres_onboarding: true
  },
  'repechage.html': {
    titre: 'Une session de repêchage',
    roles: ['directeur', 'prefet'],
    points: [
      "Les critères d'éligibilité et la politique de note se fixent à la CRÉATION de la session et ne se changent plus ensuite.",
      "Retirez explicitement les élèves qui ne doivent pas composer, avec un motif.",
      "La clôture prononce les décisions et recalcule les moyennes : elle se fait après la saisie de toutes les copies."
    ],
    apres_onboarding: true
  },
  'orientation.html': {
    titre: "Orienter les élèves",
    roles: ['directeur', 'prefet', 'titulaire'],
    points: [
      "L'orientation se traite AVANT la promotion : sinon les élèves montent dans des classes qui ne correspondent pas à leur option.",
      "Chaque option a un critère — moyenne globale ou branche précise — sans lequel la répartition au mérite ne peut pas se faire.",
      "« Répartir » propose une attribution ; les cas particuliers se corrigent ensuite un par un, avec un motif."
    ],
    apres_onboarding: true
  },
  'mon-profil.html': {
    titre: 'Votre compte',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    points: [
      "Les champs sont verrouillés : cliquez sur « Modifier » avant de saisir.",
      "Votre nom et votre prénom apparaissent sur les documents que vous signez.",
      "Le bloc « Mot de passe » est indépendant et a son propre bouton.",
      "Le bloc des menus permet d'épingler les écrans que vous utilisez tous les jours."
    ],
    apres_onboarding: true
  },
  'archives.html': {
    titre: 'Les archives',
    roles: ['directeur', 'prefet', 'secretaire'],
    points: [
      "Une année clôturée n'est pas supprimée : elle reste consultable et imprimable ici.",
      "Les documents archivés conservent la mise en page de l'époque."
    ],
    apres_onboarding: true
  },

  /* ---------- Écrans qui n'avaient aucun tutoriel ----------
     Seize des écrans de la plateforme arrivaient nus : la personne y débarquait
     sans une phrase pour dire ce qu'on y fait. Les plus coûteux sont ceux dont
     un réglage manquant casse quelque chose trois écrans plus loin — Classes,
     Année scolaire, Modèles de bulletins — et ceux qui n'existent que pour un
     seul rôle, qui n'a donc personne à qui demander. */

  'classes.html': {
    titre: 'Classes, structure et cours',
    roles: ['directeur', 'prefet'],
    points: [
      "Le NIVEAU (1 à 8) et la DIVISION sont les deux champs les plus souvent oubliés. Sans eux, la promotion de fin d'année ne peut pas s'exécuter, et le tableau affiche « niveau manquant ».",
      "Les cours ne se créent pas depuis l'écran Cours : ouvrez une classe, le bloc « Cours de cette classe » apparaît sous le formulaire.",
      "Cochez « Classe terminale » sur la classe où les élèves sortent diplômés : sinon la promotion cherche une classe supérieure qui n'existe pas.",
      "L'onglet « Structure » porte les sections et les options du secondaire."
    ],
    apres_onboarding: false
  },
  'annee-scolaire.html': {
    titre: "L'année, les périodes et la promotion",
    roles: ['directeur', 'prefet'],
    points: [
      "Créer une année ne suffit pas : il faut cliquer sur « Activer » sur sa ligne. Sans cela, tous les écrans continuent de travailler sur l'année précédente.",
      "L'onglet « Périodes » réclame des DATES : sans elles, la plateforme ne sait pas quelle période est en cours.",
      "N'oubliez pas les périodes de type « Examen » : c'est le maximum d'examen des cours qui y sert de dénominateur.",
      "L'onglet « Promotion » enchaîne report de structure, aperçu, puis exécution."
    ],
    apres_onboarding: false
  },
  'utilisateurs.html': {
    titre: 'Comptes et rôles',
    roles: ['directeur'],
    points: [
      "L'email sert d'identifiant de connexion : il doit être unique dans l'école.",
      "Une personne n'a qu'un seul rôle, sauf deux combinaisons autorisées : Professeur + Titulaire, et Préfet + Directeur.",
      "L'attribution des cours ne se fait PAS ici : elle se fait depuis chaque classe, écran Classes.",
      "Un professeur sans cours attribué ouvre un écran vide et croit à une panne."
    ],
    apres_onboarding: false
  },
  'eleves.html': {
    titre: 'Le registre des élèves',
    roles: ['directeur', 'prefet', 'secretaire'],
    points: [
      "Laissez le matricule vide : il est généré automatiquement et reste unique dans l'école.",
      "L'email du responsable est la seule adresse par laquelle les parents recevront les messages de l'école.",
      "À l'import, contrôlez l'aperçu des cinq premières lignes : c'est le seul moment où une erreur de correspondance de colonnes se voit.",
      "Un départ d'élève se déclare avec un motif ; l'historique, lui, est conservé."
    ],
    apres_onboarding: false
  },
  'generateur-modeles.html': {
    titre: 'Modèles de bulletins',
    roles: ['directeur'],
    points: [
      "Un modèle créé mais non ACTIVÉ ne sera jamais utilisé : c'est la première cause de « la génération ne fait rien ».",
      "Le type (période, semestre, annuel) et la variante (primaire, secondaire, terminale) décident de quand le modèle s'applique.",
      "« Suggérer les zones » place les champs automatiquement ; relisez-les avant d'activer.",
      "Le modèle doit ensuite être affecté aux classes concernées."
    ],
    apres_onboarding: true
  },
  'comptabilite.html': {
    titre: 'Caisse, contrats et paie',
    roles: ['comptable', 'directeur'],
    points: [
      "Créez vos catégories (entrée / sortie) avant le premier mouvement.",
      "Les frais scolaires encaissés remontent automatiquement en entrée : ne les ressaisissez pas ici, vous les compteriez deux fois.",
      "La paie se prépare par mois à partir des contrats actifs, puis se paie ligne par ligne ; le mouvement de caisse est créé pour vous."
    ],
    apres_onboarding: true
  },
  'orientation.html': {
    titre: "Orienter les élèves de fin de cycle",
    roles: ['directeur', 'prefet', 'titulaire'],
    points: [
      "L'orientation se traite AVANT la promotion : l'inverse ferait entrer des élèves dans des classes qui ne correspondent pas à leur option.",
      "Chaque élève exprime un vœu et une option de repli.",
      "« Répartir » attribue au mérite dans la limite des capacités ; les cas particuliers se corrigent ensuite un par un, avec un motif."
    ],
    apres_onboarding: true
  },
  'repechage.html': {
    titre: 'Session de repêchage',
    roles: ['directeur', 'prefet'],
    points: [
      "La politique de note — plafonnée, remplacement ou moyenne — se choisit à la création de la session et ne se change plus ensuite.",
      "La liste des éligibles se calcule à partir des seuils de l'école ; on peut en retirer quelqu'un, avec un motif.",
      "La clôture prononce les décisions et recalcule les moyennes."
    ],
    apres_onboarding: true
  },
  'bulletin-annuel.html': {
    titre: 'Le bulletin annuel',
    roles: ['directeur', 'prefet', 'titulaire', 'secretaire'],
    points: [
      "Toutes les périodes de l'année doivent être saisies et validées avant de générer.",
      "Le bulletin annuel utilise le modèle de type « annuel », distinct de celui des périodes.",
      "Le repêchage, s'il a lieu, doit être clôturé avant : il modifie les moyennes."
    ],
    apres_onboarding: true
  },
  'calendrier.html': {
    titre: 'Jours fériés et journées particulières',
    roles: ['directeur', 'prefet', 'secretaire', 'charge_presences', 'directeur_discipline'],
    points: [
      "Déclarez les fériés AVANT la rentrée : les absences déjà saisies sur un jour requalifié férié ne se corrigent pas toutes seules.",
      "Un jour déclaré férié est exclu des taux d'assiduité.",
      "Un congé peut ne concerner qu'un cycle : le champ « Cycle » sert exactement à cela."
    ],
    apres_onboarding: true
  },
  'messages.html': {
    titre: 'Écrire et diffuser',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    points: [
      "Écrire à une ou plusieurs personnes est ouvert à tout le personnel : cherchez le nom, cochez-le, rédigez, envoyez.",
      "La diffusion à un rôle entier ou aux parents de toute l'école reste réservée à la direction et au secrétariat.",
      "Un titulaire ou un professeur peut écrire aux parents des classes dont il a la charge.",
      "Les parents n'ont pas de compte : seul le courriel les atteint, et seulement si l'adresse du responsable est renseignée."
    ],
    apres_onboarding: true
  },
  'espace-professeur.html': {
    titre: 'Mes cours',
    roles: ['professeur', 'titulaire'],
    points: [
      "Cet écran liste les classes et les branches qui vous sont attribuées.",
      "S'il est vide, la direction n'a pas encore fait l'attribution : ce n'est pas une panne, signalez-le.",
      "De là, un clic mène directement à la saisie des cotes de chaque cours."
    ],
    apres_onboarding: false
  },
  'espace-titulaire.html': {
    titre: 'Ma classe',
    roles: ['titulaire'],
    points: [
      "L'effectif, les résultats et le suivi de votre classe en un écran.",
      "« Cours de la classe » dit quelle branche a rendu ses cotes et laquelle non — c'est l'écran à ouvrir avant une fin de période.",
      "La génération des bulletins par le titulaire dépend d'un réglage de l'école : si le bouton manque, c'est là qu'il faut regarder."
    ],
    apres_onboarding: false
  },
  'espace-secretaire.html': {
    titre: 'Accueil Secrétariat',
    roles: ['secretaire'],
    points: [
      "Les tâches du jour sont regroupées ici : inscriptions en attente, dossiers incomplets.",
      "Un dossier incomplet est le plus souvent un email de responsable manquant — sans lui, la famille ne reçoit rien.",
      "Les concours d'admission se pilotent depuis « Inscriptions »."
    ],
    apres_onboarding: false
  },
  'journal.html': {
    titre: "Le journal d'activité",
    roles: ['directeur', 'prefet'],
    points: [
      "Qui a modifié quoi, et quand. C'est l'écran du jour où une note change sans explication.",
      "Les validations, dévalidations et réouvertures de période y sont toutes tracées.",
      "Les filtres portent sur l'utilisateur, le type d'action et la période."
    ],
    apres_onboarding: true
  },
  'site-public.html': {
    titre: "Le site public de l'école",
    roles: ['directeur', 'secretaire'],
    points: [
      "Rien n'est visible publiquement tant que le site n'est pas activé.",
      "Seuls les résultats explicitement publiés sortent : aucune donnée ne s'échappe par défaut.",
      "Les codes d'accès permettent aux familles de consulter les résultats de leur enfant."
    ],
    apres_onboarding: true
  },
  'mon-profil.html': {
    titre: 'Votre compte',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    points: [
      "Les champs sont verrouillés : cliquez d'abord sur « Modifier ».",
      "Votre nom et votre prénom apparaissent sur les documents que vous signez.",
      "Le bloc « Mot de passe » est indépendant et a son propre bouton.",
      "Vous pouvez épingler ici les écrans que vous utilisez tous les jours : un menu absent est parfois simplement rangé, pas interdit."
    ],
    apres_onboarding: true
  }
};

/* ==========================================================================
   4. CENTRE « APPRENDRE ARDOISE »

   Le manuel existait déjà (`GET /assistant/manuel`) mais n'était atteignable
   que depuis un onglet de la messagerie. Ce catalogue lui donne une table des
   matières, filtrée par rôle, ouvrable depuis n'importe quel écran.

   `etape` renvoie vers un code du catalogue ci-dessus : ouvrir un article peut
   donc relancer le guidage interactif correspondant, plutôt que de se contenter
   d'un texte.
   ========================================================================== */

const CENTRE_APPRENTISSAGE = [
  {
    code: 'demarrer',
    titre: 'Démarrer avec Ardoise',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    articles: [
      { titre: 'Le parcours de prise en main', etape: null, description: "Reprendre l'accompagnement là où vous l'aviez laissé." },
      { titre: 'Compléter mon profil', etape: 'profil' },
      { titre: 'Messagerie et assistant', etape: 'decouverte_messages' }
    ]
  },
  {
    code: 'etablissement',
    titre: 'Configurer mon établissement',
    roles: ['directeur', 'prefet'],
    articles: [
      { titre: "Identité et régime de l'école", etape: 'identite_ecole' },
      { titre: "Année scolaire et périodes", etape: 'annee_scolaire' },
      { titre: "Sections et options", etape: 'sections_options' },
      { titre: "Heures de cours", etape: 'creneaux' },
      { titre: "Modèle de bulletin des classes", etape: 'modeles_bulletins' },
      { titre: "Créer un modèle personnalisé", etape: 'modeles_personnalises' }
    ]
  },
  {
    code: 'classes',
    titre: 'Gérer les classes',
    roles: ['directeur', 'prefet', 'secretaire'],
    articles: [
      { titre: 'Créer une classe', etape: 'classes' },
      { titre: 'Attribuer les cours à une classe', etape: 'classe_cours' },
      { titre: 'Désigner un titulaire', etape: 'titulaires' }
    ]
  },
  {
    code: 'eleves',
    titre: 'Gérer les élèves',
    roles: ['directeur', 'prefet', 'secretaire', 'titulaire'],
    articles: [
      { titre: 'Inscrire ou importer des élèves', etape: 'eleves' },
      { titre: 'Inscriptions et concours', etape: 'decouverte_inscriptions' },
      { titre: 'Archives des années clôturées', etape: 'decouverte_archives' }
    ]
  },
  {
    code: 'enseignants',
    titre: 'Gérer les enseignants',
    roles: ['directeur', 'prefet'],
    articles: [
      { titre: 'Créer un compte enseignant', etape: 'personnel' },
      { titre: 'Attribuer les cours à un enseignant', etape: 'attribution_cours' }
    ]
  },
  {
    code: 'matieres',
    titre: 'Gérer les matières',
    roles: ['directeur', 'prefet'],
    articles: [
      { titre: 'Créer une branche', etape: 'cours' },
      { titre: "Maximum ordinaire et maximum d'examen", etape: 'cours' }
    ]
  },
  {
    code: 'notes',
    titre: 'Encoder les notes',
    roles: ['professeur', 'titulaire', 'prefet', 'directeur'],
    articles: [
      { titre: 'Saisir des cotes', etape: 'decouverte_notes' },
      { titre: 'Validation et verrouillage', etape: 'decouverte_notes' }
    ]
  },
  {
    code: 'presences',
    titre: 'Gérer les présences',
    roles: ['professeur', 'titulaire', 'charge_presences', 'directeur_discipline', 'prefet', 'directeur'],
    articles: [
      { titre: "Faire l'appel", etape: 'decouverte_presences' },
      { titre: "Jours fériés et journées particulières", etape: null }
    ]
  },
  {
    code: 'communication',
    titre: 'Écrire et diffuser',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable', 'professeur', 'titulaire',
            'charge_presences', 'directeur_discipline'],
    articles: [
      { titre: 'Écrire à un collègue', etape: 'decouverte_messages', description: "Chercher la personne, cocher son nom, envoyer." },
      { titre: 'Diffuser à un groupe', etape: 'decouverte_messages', description: "Un rôle, une classe, les parents — réservé à la direction et au secrétariat." },
      { titre: 'Écrire aux parents de sa classe', etape: 'decouverte_messages', description: "Ouvert au titulaire et au professeur, pour les classes dont ils ont la charge." }
    ]
  },
  {
    code: 'bulletins',
    titre: 'Générer les bulletins',
    roles: ['directeur', 'prefet', 'titulaire', 'secretaire'],
    articles: [
      { titre: 'Générer et vérifier', etape: 'decouverte_bulletins' },
      { titre: 'Signature et impression', etape: 'decouverte_bulletins' }
    ]
  },
  {
    code: 'paiements',
    titre: 'Gérer les paiements',
    roles: ['comptable', 'secretaire', 'directeur'],
    articles: [
      { titre: 'Définir les frais', etape: 'frais' },
      { titre: 'Encaisser et délivrer un reçu', etape: 'decouverte_paiements' },
      { titre: 'Suivre les impayés', etape: 'decouverte_dettes' }
    ]
  },
  {
    code: 'rapports',
    titre: 'Utiliser les rapports',
    roles: ['directeur', 'prefet', 'secretaire', 'comptable'],
    articles: [
      { titre: 'Tableau de bord', etape: 'decouverte_tableau_bord' },
      { titre: 'Statistiques et exports', etape: 'decouverte_rapports' },
      { titre: "Journal d'activité", etape: 'decouverte_journal' }
    ]
  },
  {
    code: 'parametres',
    titre: 'Utiliser les paramètres',
    roles: ['directeur'],
    articles: [
      { titre: "Réglages de l'établissement", etape: 'identite_ecole' },
      { titre: 'Notation, mentions, seuil de promotion', etape: 'modeles_bulletins' },
      { titre: 'Barème de discipline', etape: 'discipline_bareme' }
    ]
  }
];

/* ==========================================================================
   5. FONCTIONS DU MOTEUR
   ========================================================================== */

/** Index par code, construit une fois. */
const PAR_CODE = ETAPES.reduce((acc, e) => { acc[e.code] = e; return acc; }, {});

/**
 * Normalise le document de progression.
 *
 * Une colonne JSONB peut contenir `{}` (compte jamais connecté), un document
 * d'une version antérieure, ou des clés absentes. Toutes les lectures passent
 * ici : le reste du code peut alors supposer que chaque champ existe et a le
 * bon type, sans garde à chaque accès.
 */
function lireProgression(brut) {
  const p = (brut && typeof brut === 'object' && !Array.isArray(brut)) ? brut : {};
  const liste = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []);
  return {
    version: 2,
    vu_bienvenue: p.vu_bienvenue === true,
    statut: ['en_cours', 'reporte', 'termine'].includes(p.statut) ? p.statut : 'en_cours',
    // « Passer pour l'instant » : décision temporaire, on repropose l'étape
    // dans le centre d'apprentissage et elle se réactive d'un clic.
    etapes_ignorees: liste(p.etapes_ignorees),
    // « Nous n'utilisons pas cette fonctionnalité » : décision durable. Deux
    // listes plutôt qu'une parce que les deux phrases ne veulent pas dire la
    // même chose, et que les confondre revenait à harceler avec une étape
    // qu'une école avait déjà écartée en connaissance de cause.
    etapes_non_utilisees: liste(p.etapes_non_utilisees),
    tutoriels_vus: liste(p.tutoriels_vus),
    ecrans_visites: liste(p.ecrans_visites),
    demarre_at: p.demarre_at || null,
    termine_at: p.termine_at || null,
    maj_at: p.maj_at || null,
    // Signature de l'offre au moment du dernier calcul. Sert uniquement à
    // détecter un CHANGEMENT d'offre pour vider les caches côté client ; elle
    // ne conditionne aucun droit, qui restent lus en base à chaque requête.
    signature_offre: typeof p.signature_offre === 'string' ? p.signature_offre : null
  };
}

/**
 * Rôles retenus pour le parcours, par ordre de priorité.
 *
 * Un même compte cumule souvent plusieurs rôles (directeur ET titulaire, très
 * courant dans les petites écoles). Additionner les parcours donnerait une
 * liste de trente étapes qui décourage. On prend le rôle le PLUS LARGE comme
 * parcours principal, et on complète par les étapes de découverte propres aux
 * autres rôles — c'est la partie qui apporte de l'information nouvelle sans
 * rallonger la configuration.
 */
const PRIORITE_ROLES = [
  'directeur', 'prefet', 'secretaire', 'comptable', 'titulaire', 'professeur',
  'directeur_discipline', 'charge_presences', 'parent', 'eleve'
];

function roleDominant(roles) {
  for (const r of PRIORITE_ROLES) {
    if (roles.includes(r)) return r;
  }
  return null;
}

/* ==========================================================================
   APPLICABILITÉ — LA QUESTION POSÉE AVANT TOUTES LES AUTRES
   ==========================================================================

   Une étape traverse quatre filtres, dans cet ordre. Le premier qui la
   recale l'ÉCARTE du parcours ; elle n'est jamais « affichée bloquée ».

     1. le RÔLE           — elle figure dans le parcours de ce rôle
     2. le CYCLE          — une école primaire n'a ni sections ni options
     3. l'OFFRE           — la fonctionnalité exigée est-elle souscrite
     4. la CONFIGURATION  — l'école a-t-elle de quoi la faire (dépendances)

   Le quatrième filtre est le seul qui puisse changer d'un jour à l'autre sans
   décision commerciale : c'est lui qui propage l'écartement le long du graphe.
   ========================================================================== */

/** Raisons d'écartement, dans l'ordre de priorité d'affichage. */
const RAISONS = {
  hors_offre: "Cette fonctionnalité n'est pas comprise dans votre offre actuelle.",
  hors_cycle: "Cette étape ne concerne pas le type d'enseignement de votre école.",
  hors_produit: "Cette étape ne correspond à aucune fonctionnalité disponible.",
  dependance_ecartee: "L'étape dont celle-ci dépend n'est pas applicable à votre établissement.",
  dependance_non_utilisee: "Vous avez indiqué ne pas utiliser l'étape dont celle-ci dépend."
};

/**
 * L'étape est-elle recevable au vu du cycle et de l'offre ?
 * Renvoie `null` si elle l'est, sinon la raison de l'écartement.
 */
function raisonEcartement(etape, contexte) {
  const cycle = (contexte && contexte.cycle) || null;
  const droits = (contexte && contexte.droits) || null;

  // 2. CYCLE. Une étape sans `cycle` concerne tout le monde. Un cycle inconnu
  //    (école pas encore paramétrée) ne recale rien : on ne veut pas amputer
  //    le parcours d'une école qui n'a pas encore choisi son régime.
  if (etape.cycle && cycle && cycle !== 'les_deux' && cycle !== etape.cycle) {
    return 'hors_cycle';
  }

  // 3. OFFRE. `droits` absent signifie « on n'a pas pu lire l'offre » : on ne
  //    retire rien. Fermer le parcours sur une panne de facturation
  //    reproduirait, dans le didacticiel, exactement le défaut que le
  //    middleware d'offre évite déjà côté routes.
  if (etape.fonctionnalite && droits) {
    if (droits[etape.fonctionnalite] !== true) return 'hors_offre';
  }

  return null;
}

/**
 * Construit le parcours d'une personne.
 *
 * @param {string[]} roles       rôles du compte
 * @param {object}   faits       dictionnaire { cle: booleen } produit par la
 *                               collecte en base (voir assistant.controller.js)
 * @param {object}   progression document normalisé
 * @param {object}   contexte    { cycle, droits }
 *                               `droits` = table des drapeaux de l'offre
 *                               effective, telle que la renvoie
 *                               `catalogue.droitsDeLEcole()`. Absente, aucune
 *                               étape n'est retirée pour raison d'offre.
 *
 * @returns {object} { etapes, etapes_ecartees, prochaine, progression_pct,
 *                     progression_config_pct, termine, mode, role_dominant }
 */
function construireParcours(roles, faits, progression, contexte) {
  const dominant = roleDominant(roles);
  if (!dominant) {
    return {
      etapes: [], etapes_ecartees: [], prochaine: null, progression_pct: 100,
      progression_config_pct: null, termine: true, mode: 'aucun', role_dominant: null
    };
  }

  // Parcours du rôle dominant, complété par les DÉCOUVERTES des rôles cumulés.
  const codes = [...(PARCOURS_ROLE[dominant] || [])];
  roles.forEach((r) => {
    if (r === dominant) return;
    (PARCOURS_ROLE[r] || []).forEach((code) => {
      const e = PAR_CODE[code];
      if (e && e.type === 'decouverte' && !codes.includes(code)) codes.push(code);
    });
  });

  const retenues = codes.map((code) => PAR_CODE[code]).filter(Boolean);

  /* ---- Premier passage : cycle et offre --------------------------------- */
  const ecartees = new Map();          // code -> raison
  retenues.forEach((e) => {
    const raison = raisonEcartement(e, contexte);
    if (raison) ecartees.set(e.code, raison);
  });

  const ignorees = new Set(progression.etapes_ignorees || []);
  const nonUtilisees = new Set(progression.etapes_non_utilisees || []);

  /* ---- Second passage : propagation le long des dépendances DURES -------
     Une étape dont une dépendance indispensable est écartée, ou déclarée
     « non utilisée » par l'école, n'a plus de sens. On l'écarte à son tour
     PLUTÔT QUE DE LA LAISSER BLOQUÉE — c'est précisément la branche morte
     que le moteur précédent produisait.

     « Passer pour l'instant » (etapes_ignorees) ne propage RIEN : c'est une
     remise à plus tard, pas un renoncement. L'étape enfant reste proposable
     et se débloquera quand la parente sera faite.

     La boucle est bornée par le nombre d'étapes : un graphe de dépendances
     circulaire ne peut donc pas la faire tourner indéfiniment.            */
  const presentes = new Set(retenues.map((e) => e.code));
  for (let passe = 0; passe < retenues.length + 1; passe++) {
    let changement = false;
    for (const e of retenues) {
      if (ecartees.has(e.code)) continue;
      for (const d of (e.depend || [])) {
        // Une dépendance absente du parcours de CE rôle n'est pas une
        // dépendance écartée : c'est le travail de quelqu'un d'autre.
        if (!presentes.has(d)) continue;
        if (ecartees.has(d)) {
          ecartees.set(e.code, 'dependance_ecartee');
          changement = true;
          break;
        }
        if (nonUtilisees.has(d)) {
          ecartees.set(e.code, 'dependance_non_utilisee');
          changement = true;
          break;
        }
      }
    }
    if (!changement) break;
  }

  /* ---- Construction des étapes retenues --------------------------------- */
  const etapes = retenues
    .filter((e) => !ecartees.has(e.code))
    .map((e) => {
      const ignoree = ignorees.has(e.code);
      const nonUtilisee = nonUtilisees.has(e.code);
      // Deux sources de vérité, dans cet ordre :
      //   · pour une étape de CONFIGURATION, la base de données. Elle seule
      //     dit si la classe existe vraiment. Un clic ne suffit pas.
      //   · pour une étape de DÉCOUVERTE, la visite de l'écran. Ouvrir
      //     « Rapports » ne laisse aucune trace en base ; il n'y a rien d'autre
      //     à observer.
      const fait = e.detection
        ? faits[e.detection] === true
        : progression.ecrans_visites.includes(e.ecran);

      const categorie = e.categorie
        || (e.type === 'decouverte' ? 'decouverte'
                                    : (e.obligatoire === false ? 'facultatif' : 'prerequis'));

      return {
        code: e.code,
        type: e.type,
        categorie,
        titre: e.titre,
        resume: e.resume,
        ecran: e.ecran,
        ancre: e.ancre,
        selecteurs: e.selecteurs || [],
        details: e.details || [],
        obligatoire: e.obligatoire !== false,
        // Un PRÉREQUIS ne se passe pas : une école sans année scolaire active
        // ne fonctionne pas, et lui proposer « je m'en passe » serait mentir.
        // Tout le reste est passable, et réactivable.
        passable: categorie !== 'prerequis',
        fonctionnalite: e.fonctionnalite || null,
        depend: (e.depend || []).filter((d) => presentes.has(d) && !ecartees.has(d)),
        depend_souple: e.depend_souple || [],
        etape_config: e.etape_config || null,
        fait,
        ignoree,
        non_utilisee: nonUtilisee,
        alerte: faits[`alerte_${e.code}`] || null
      };
    });

  const parCode = new Map(etapes.map((e) => [e.code, e]));

  const estFait = (code) => {
    const e = parCode.get(code);
    // Une dépendance absente du parcours de CE rôle est réputée satisfaite :
    // un préfet n'a pas l'étape « identite_ecole », mais ses classes ne doivent
    // pas rester bloquées pour autant. Ce n'est pas son travail, et le
    // directeur le verra de son côté.
    if (!e) return true;
    // Une dépendance PASSÉE pour l'instant ne bloque pas éternellement :
    // l'étape enfant reste proposable. Sans cette règle, un report devenait
    // un verrou définitif sur toute une branche.
    if (e.ignoree) return true;
    return e.fait;
  };

  etapes.forEach((e) => {
    e.bloquee_par = e.depend.filter((d) => !estFait(d));
    e.bloquee = e.bloquee_par.length > 0;
  });

  /* ---- Filet de sécurité : aucune branche morte -------------------------
     Invariant vérifié à chaque construction : une étape bloquée l'est
     forcément par une étape PRÉSENTE, non écartée et sur laquelle une action
     est possible. Si l'invariant tombe, on préfère débloquer l'étape plutôt
     que de laisser quelqu'un devant une checklist sans issue — et le signaler
     une fois dans les journaux, parce que c'est un défaut de déclaration.  */
  etapes.forEach((e) => {
    const impasse = e.bloquee_par.filter((d) => !parCode.has(d));
    if (impasse.length === 0) return;
    e.bloquee_par = e.bloquee_par.filter((d) => parCode.has(d));
    e.bloquee = e.bloquee_par.length > 0;
    if (!impasseSignalee) {
      impasseSignalee = true;
      console.warn(
        `[onboarding] L'étape « ${e.code} » dépendait de « ${impasse.join(', ')} », `
        + 'absente du parcours après écartement. Dépendance ignorée pour ne pas '
        + 'laisser la branche sans issue — à corriger dans ETAPES.'
      );
    }
  });

  // La prochaine étape : la première non faite, non passée, non bloquée.
  //
  // Une configuration obligatoire passe TOUJOURS avant une découverte, quelle
  // que soit sa place dans la liste : proposer « découvrez les rapports » à
  // quelqu'un qui n'a pas encore d'élèves produit des rapports vides, et donc
  // l'impression que la plateforme ne marche pas.
  const candidates = etapes.filter(
    (e) => !e.fait && !e.ignoree && !e.non_utilisee && !e.bloquee);
  const prochaine =
    candidates.find((e) => e.obligatoire && e.type !== 'decouverte')
    || candidates[0]
    || null;

  /* ---- Progression -----------------------------------------------------
     Ce qui compte : les étapes OBLIGATOIRES, APPLICABLES, ni passées ni
     déclarées inutilisées. Une fonctionnalité exclue par l'offre a déjà
     disparu du tableau `etapes` : elle ne peut plus empêcher d'atteindre
     100 %, ce qui était l'anomalie de fond.                              */
  const comptees = etapes.filter((e) => e.obligatoire && !e.ignoree && !e.non_utilisee);
  const progressionPct = comptees.length === 0
    ? 100
    : Math.round((comptees.filter((e) => e.fait).length / comptees.length) * 100);

  const configs = etapes.filter(
    (e) => e.type === 'configuration' && !e.ignoree && !e.non_utilisee);
  const progressionConfigPct = configs.length === 0
    ? null
    : Math.round((configs.filter((e) => e.fait).length / configs.length) * 100);

  const restantesObligatoires = comptees.filter((e) => !e.fait);

  // MODE : ce qui décide du ton du message d'accueil.
  const restentDesConfigs = restantesObligatoires.some((e) => e.type === 'configuration');
  let mode = 'termine';
  if (restentDesConfigs) mode = 'configuration';
  else if (restantesObligatoires.length > 0) mode = 'decouverte';

  return {
    etapes,
    // Les étapes écartées, avec leur raison. Volontairement SÉPARÉES de la
    // checklist : l'interface peut en faire un encart « compris dans une
    // offre supérieure », jamais une ligne « à faire » que personne ne peut
    // faire. Aucune n'entre dans les compteurs ni dans les alertes.
    etapes_ecartees: retenues
      .filter((e) => ecartees.has(e.code))
      .map((e) => ({
        code: e.code,
        titre: e.titre,
        type: e.type,
        raison: ecartees.get(e.code),
        message: RAISONS[ecartees.get(e.code)] || null,
        fonctionnalite: e.fonctionnalite || null
      })),
    prochaine,
    progression_pct: progressionPct,
    progression_config_pct: progressionConfigPct,
    termine: restantesObligatoires.length === 0,
    mode,
    role_dominant: dominant
  };
}

// Journalisé une seule fois : un défaut de déclaration ne doit pas remplir les
// journaux à chaque chargement de page de chaque utilisateur.
let impasseSignalee = false;

/**
 * Le mini-tutoriel à montrer sur un écran, ou null.
 *
 * Trois conditions cumulatives : l'écran en a un, le rôle est concerné, et la
 * personne ne l'a pas déjà vu. La troisième est celle qui compte : un tutoriel
 * qui réapparaît à chaque visite cesse d'être lu au bout de deux fois, et rend
 * suspect tout ce que le didacticiel affichera ensuite.
 */
function tutorielContextuel(ecran, roles, progression, parcoursTermine) {
  const t = TUTORIELS_CONTEXTUELS[ecran];
  if (!t) return null;
  if (progression.tutoriels_vus.includes(ecran)) return null;
  if (!t.roles.some((r) => roles.includes(r))) return null;
  // Certains tutoriels attendent la fin de l'onboarding pour ne pas parler
  // par-dessus le guidage en cours.
  if (t.apres_onboarding && !parcoursTermine) return null;
  return { ecran, titre: t.titre, points: t.points };
}

/**
 * Le centre d'apprentissage, filtré sur les rôles ET sur l'offre.
 *
 * POURQUOI L'OFFRE ENTRE ICI AUSSI
 * --------------------------------
 * Le centre était filtré par rôle seulement. Une école Ascension y trouvait
 * donc « Créer un modèle de bulletin personnalisé » : l'article s'ouvrait, le
 * guidage démarrait, l'écran répondait 402. Un mode d'emploi qui mène à une
 * porte fermée est pire qu'un mode d'emploi absent — il fait croire à une
 * panne plutôt qu'à une limite d'offre.
 *
 * Une rubrique dont tous les articles sont retirés disparaît entièrement :
 * un titre de section vide n'apprend rien à personne.
 *
 * @param {string[]} roles
 * @param {object}  [droits] table des drapeaux de l'offre. Absente, rien
 *                           n'est retiré (même règle que le parcours).
 */
function centreApprentissage(roles, droits) {
  const accessible = (codeEtape) => {
    if (!codeEtape) return true;
    const e = PAR_CODE[codeEtape];
    if (!e) return true;
    if (!e.fonctionnalite || !droits) return true;
    return droits[e.fonctionnalite] === true;
  };

  return CENTRE_APPRENTISSAGE
    .filter((c) => c.roles.some((r) => roles.includes(r)))
    .map((c) => ({
      code: c.code,
      titre: c.titre,
      articles: c.articles.filter((a) => accessible(a.etape)).map((a) => {
        const e = a.etape ? PAR_CODE[a.etape] : null;
        return {
          titre: a.titre,
          etape: a.etape || null,
          ecran: e ? e.ecran : null,
          description: a.description || (e ? e.resume : null)
        };
      })
    }))
    .filter((c) => c.articles.length > 0);
}

/** Le détail complet d'une étape, texte de `connaissance.utils` compris. */
function detailEtape(code) {
  const e = PAR_CODE[code];
  if (!e) return null;
  const conf = e.etape_config
    ? ORDRE_CONFIGURATION.find((c) => c.etape === e.etape_config)
    : null;
  return {
    code: e.code,
    type: e.type,
    titre: e.titre,
    resume: e.resume,
    ecran: e.ecran,
    ancre: e.ancre,
    selecteurs: e.selecteurs || [],
    // Les GESTES à faire dans l'écran. C'est ce que la bulle de guidage
    // affiche : sans eux, elle nommait l'écran et s'arrêtait là.
    details: e.details || [],
    // Le fond vient de la base de connaissance partagée, jamais recopié ici.
    quoi: conf ? conf.quoi : null,
    // La description CHAMP PAR CHAMP du formulaire. Elle n'existait pas :
    // l'assistant ne pouvait donc pas répondre « que dois-je mettre dans ce
    // champ ? », qui est pourtant la question réellement posée.
    champs: conf ? (conf.champs || []) : [],
    pourquoi: conf ? conf.pourquoi : null,
    piege: conf ? conf.piege : null,
    ecran_officiel: conf ? conf.ecran : null
  };
}

module.exports = {
  ETAPES,
  RAISONS,
  PARCOURS_ROLE,
  TUTORIELS_CONTEXTUELS,
  CENTRE_APPRENTISSAGE,
  PAR_CODE,
  lireProgression,
  roleDominant,
  construireParcours,
  tutorielContextuel,
  centreApprentissage,
  detailEtape
};
