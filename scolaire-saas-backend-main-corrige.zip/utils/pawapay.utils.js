/**
 * Intégration PawaPay (Mobile Money) — API v2.
 * Documentation de référence : https://docs.pawapay.io/v2/api-reference/deposits
 *
 * ⚠️ À VÉRIFIER TOI-MÊME avant d'utiliser en production :
 * - Le code exact du "provider" pour la RDC (Orange/Airtel/Vodacom-M-Pesa) dépend de
 *   ta configuration de compte PawaPay. Récupère les codes exacts via l'endpoint
 *   "Active Configuration" de ton tableau de bord PawaPay (Settings > Active configuration),
 *   je ne peux pas les garantir ici car ils dépendent de ton contrat avec PawaPay.
 * - Vérifie aussi que PawaPay supporte la collecte en CDF (franc congolais) pour ces
 *   opérateurs — si seule une devise étrangère est supportée pour la RDC, tes plans
 *   d'abonnement devront peut-être être tarifés dans cette devise pour le paiement
 *   Mobile Money (indépendamment de l'affichage en USD ailleurs).
 */

const BASE_URL = process.env.PAWAPAY_BASE_URL || 'https://api.sandbox.pawapay.io/v2';

/**
 * Initie un dépôt (le client va recevoir une demande de confirmation sur son téléphone).
 * @param {object} params
 * @param {string} params.depositId - UUIDv4 généré par nous, unique, sert de clé d'idempotence
 * @param {string} params.montant - montant en string (ex: "30", "29.99") — pas de zéro inutile
 * @param {string} params.devise - code devise ISO 4217 en majuscules (ex: "USD", "CDF")
 * @param {string} params.telephone - numéro au format international sans "+" (ex: "243812345678")
 * @param {string} params.provider - code du correspondant PawaPay (à vérifier dans ton dashboard)
 * @param {string} params.reference - référence interne (ex: numéro de facture)
 * @param {string} params.message - message court (4-22 caractères) visible par le client
 */
async function initierDepot({ depositId, montant, devise, telephone, provider, reference, message }) {
  const reponse = await fetch(`${BASE_URL}/deposits`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.PAWAPAY_API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      depositId,
      payer: {
        type: 'MMO',
        accountDetails: {
          phoneNumber: telephone,
          provider
        }
      },
      amount: montant,
      currency: devise,
      clientReferenceId: reference,
      customerMessage: message.slice(0, 22)
    })
  });

  const donnees = await reponse.json();
  if (!reponse.ok) {
    throw new Error(donnees.message || `Erreur PawaPay (${reponse.status})`);
  }
  return donnees; // { depositId, status: 'ACCEPTED' | 'REJECTED' | 'DUPLICATE_IGNORED', created }
}

/**
 * Vérifie le statut réel d'un dépôt directement auprès de PawaPay (server-to-server),
 * plutôt que de faire confiance aveuglément à un callback reçu — se protège contre
 * un callback falsifié puisqu'un attaquant ne peut pas faire répondre PawaPay à sa place.
 */
async function verifierStatutDepot(depositId) {
  const reponse = await fetch(`${BASE_URL}/deposits/${depositId}`, {
    headers: { Authorization: `Bearer ${process.env.PAWAPAY_API_TOKEN}` }
  });
  const donnees = await reponse.json();
  if (!reponse.ok || donnees.status !== 'FOUND') {
    return null;
  }
  return donnees.data; // { depositId, status: 'COMPLETED' | 'FAILED' | ..., amount, currency, ... }
}

module.exports = { initierDepot, verifierStatutDepot };
