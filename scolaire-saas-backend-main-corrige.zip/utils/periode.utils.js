/**
 * ============================================================================
 *  VERROU D'UNE PÉRIODE — règle unique d'écriture
 * ============================================================================
 *
 * POURQUOI CE FICHIER EXISTE
 * --------------------------
 * `verifierPeriodeModifiable` vivait dans `notes.controller.js`, en fonction
 * locale non exportée. Elle y protégeait parfaitement ses huit chemins
 * d'écriture — et rien d'autre.
 *
 * Or `notes.controller.js` n'est pas le seul module à écrire dans la table
 * `bulletins`. `discipline.controller.js` y reporte l'appréciation de conduite,
 * sans passer par ce contrôle. Conséquence : un Préfet clôture une période,
 * les notes se verrouillent comme prévu — et le module Discipline continue
 * d'écrire sur les bulletins de cette même période clôturée.
 *
 * La clôture d'une période est une promesse faite à l'école : « à partir de
 * maintenant, plus rien ne bouge ». Une promesse qui ne tient que sur un
 * module sur deux n'est pas une promesse.
 *
 * TROIS VERROUS, DANS CET ORDRE
 * -----------------------------
 *   1. période clôturée  — survient tôt dans la vie de l'école, donc vérifiée
 *                          en premier ;
 *   2. année clôturée    — verrou de fin d'année ;
 *   3. année non active  — une ancienne année techniquement « ouverte » ne
 *                          doit pas réapparaître dans les écrans courants.
 *
 * Chacun renvoie un message DISTINCT : « c'est refusé » sans dire lequel des
 * trois a parlé oblige l'utilisateur à deviner, et la direction ne sait pas
 * s'il faut rouvrir la période ou réactiver l'année.
 *
 * Les trois valent pour TOUT LE MONDE, direction comprise — c'est justement
 * elle qui a prononcé la clôture. Une réouverture explicite (module Année
 * scolaire) ou une consultation via Archives (lecture seule) sont les deux
 * seules issues.
 */

/**
 * Lève une erreur HTTP si la période n'accepte plus d'écriture.
 *
 * @param {object} client  client PostgreSQL de la transaction en cours
 * @param {string} periodeId
 * @param {string} [quoi]  ce qui est refusé, pour le message ('note' par
 *                         défaut). Le module Discipline y met 'conduite' :
 *                         « plus aucune note ne peut y être saisie » serait
 *                         incompréhensible devant un report de conduite.
 */
async function verifierPeriodeModifiable(client, periodeId, quoi = 'note') {
  const result = await client.query(
    `SELECT a.cloturee, a.active, a.libelle,
            p.cloturee AS periode_cloturee, p.libelle AS periode_libelle,
            p.cloturee_at
       FROM periodes p
       JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
      WHERE p.id = $1`,
    [periodeId]
  );
  const periode = result.rows[0];
  if (!periode) {
    throw Object.assign(new Error('Période introuvable.'), { statusCode: 404 });
  }

  if (periode.periode_cloturee) {
    const quand = periode.cloturee_at
      ? new Date(periode.cloturee_at).toLocaleDateString('fr-FR')
      : null;
    throw Object.assign(
      new Error(
        `La période « ${periode.periode_libelle} » a été clôturée`
        + (quand ? ` le ${quand}` : '')
        + `. Plus aucune ${quoi} ne peut y être saisie. `
        + `Seule la direction peut la rouvrir.`
      ),
      { statusCode: 403 }
    );
  }
  if (periode.cloturee) {
    throw Object.assign(
      new Error(`L'année scolaire "${periode.libelle}" est clôturée : plus aucune ${quoi} ne peut être modifiée.`),
      { statusCode: 403 }
    );
  }
  if (!periode.active) {
    throw Object.assign(
      new Error(`"${periode.libelle}" n'est plus l'année scolaire active : ces données sont verrouillées ici. Consultez le module Archives pour les années antérieures.`),
      { statusCode: 403 }
    );
  }
}

module.exports = { verifierPeriodeModifiable };
