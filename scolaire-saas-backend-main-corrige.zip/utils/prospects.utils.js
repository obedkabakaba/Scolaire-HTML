// utils/prospects.utils.js

/**
 * ALERTE COMMERCIALE — une demande d'accompagnement vient d'arriver.
 *
 * POURQUOI UN FICHIER À PART
 * --------------------------
 * `notifications.service.js` s'adresse aux utilisateurs D'UNE ÉCOLE : il
 * résout des destinataires par rôle dans un établissement, écrit dans
 * `notifications` avec un `ecole_id`, et repose sur le contexte tenant. Un
 * prospect n'a pas d'école — il n'en a même pas encore l'intention. Le faire
 * passer par ce service supposerait d'inventer un établissement fictif, ou de
 * rendre `ecole_id` optionnel dans un chemin qui suppose partout le
 * contraire.
 *
 * L'alerte est donc directe, et volontairement minuscule.
 *
 * ELLE NE DOIT JAMAIS FAIRE ÉCHOUER L'ENREGISTREMENT
 * --------------------------------------------------
 * Une demande enregistrée mais non notifiée est un problème d'exploitation :
 * elle est dans la base, elle apparaît dans l'espace Super Admin, quelqu'un
 * la verra. Une demande perdue parce que le fournisseur d'e-mail était en
 * panne est un prospect perdu. L'appelant ignore donc le résultat, et toute
 * erreur est journalisée sans être propagée.
 */

const { pool } = require('../config/db');
const { envoyerEmail } = require('./email.utils');
const { emailWrapper, carte, echapper } = require('./email-template');

const URL_SUPER_ADMIN = (process.env.URL_SITE || 'https://myardoise.com')
  .replace(/\/+$/, '') + '/super-admin.html#/prospects';

/**
 * Adresses des Super Administrateurs actifs.
 *
 * Lues à chaque envoi plutôt que mises en cache : le volume est de quelques
 * demandes par jour, et une adresse périmée dans un cache est exactement le
 * genre de panne qu'on ne remarque qu'en cherchant pourquoi personne n'a
 * rappelé un prospect.
 *
 * `ALERTE_COMMERCIALE_EMAIL` permet de router les alertes vers une adresse
 * partagée (commercial@…) sans toucher aux comptes.
 */
async function destinataires() {
  const forcees = (process.env.ALERTE_COMMERCIALE_EMAIL || '')
    .split(',').map((s) => s.trim()).filter(Boolean);
  if (forcees.length) return forcees;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL app.is_superadmin = 'true'");
    const { rows } = await client.query(`
      SELECT DISTINCT u.email
        FROM utilisateurs u
        JOIN utilisateur_roles ur ON ur.utilisateur_id = u.id
       WHERE ur.role::text = 'super_admin'
         AND u.statut::text = 'actif'
         AND u.email IS NOT NULL`);
    await client.query('COMMIT');
    return rows.map((r) => r.email);
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

function ligne(libelle, valeur) {
  if (valeur === null || valeur === undefined || valeur === '') return '';
  return `<div style="margin:3px 0"><strong>${echapper(libelle)} :</strong> ${echapper(valeur)}</div>`;
}

/**
 * @param {object} demande - la ligne insérée, augmentée des libellés lisibles
 *   (`offre_libelle`, `services_libelles`) résolus par l'appelant : le
 *   commercial lit « Ardoise Prime », pas « prime ».
 */
async function alerterNouvelleDemande(demande) {
  try {
    const cibles = await destinataires();
    if (!cibles.length) {
      console.warn('Demande d\'accompagnement reçue, mais aucun Super Administrateur '
                 + 'actif avec adresse e-mail : alerte non envoyée.');
      return { envoye: false, raison: 'aucun_destinataire' };
    }

    const contact = [
      ligne('Nom', demande.contact_nom),
      ligne('École', demande.ecole_nom),
      ligne('Téléphone', demande.contact_telephone),
      ligne('E-mail', demande.contact_email),
      ligne('Ville', demande.ville),
      ligne('Élèves (estimation)', demande.nb_eleves_estime)
    ].join('');

    const interet = [
      ligne('Offre envisagée', demande.offre_libelle),
      ligne('Services souhaités', (demande.services_libelles || []).join(', '))
    ].join('');

    const contenu = `
      <p>Une nouvelle demande d'accompagnement vient d'être déposée depuis le site public.</p>
      ${carte({ type: 'info', titre: 'Contact', texteHtml: contact })}
      ${interet ? carte({ type: 'info', titre: 'Ce qui l\'intéresse', texteHtml: interet }) : ''}
      ${demande.message
        ? carte({ type: 'info', titre: 'Sa situation',
                  texteHtml: echapper(demande.message).replace(/\n/g, '<br />') })
        : ''}
      <p style="font-size:13px;opacity:.75">
        Engagement affiché sur le site : rappel sous 48 heures ouvrées.
      </p>`;

    return await envoyerEmail({
      to: cibles,
      subject: `Nouvelle demande — ${demande.contact_nom}`
             + (demande.ecole_nom ? ` (${demande.ecole_nom})` : ''),
      html: emailWrapper({
        type: 'message',
        titre: 'Nouvelle demande d\'accompagnement',
        preheader: `${demande.contact_nom}${demande.ville ? ' — ' + demande.ville : ''}`,
        contenuHtml: contenu,
        boutonPrincipal: { libelle: 'Ouvrir dans l\'espace Super Admin', url: URL_SUPER_ADMIN }
      }),
      fromName: 'Ardoise',
      // `estSuperAdmin: false` est délibéré, malgré un destinataire interne :
      // `envoyerEmail` ignore `reply_to` en mode super admin. Or répondre à
      // cette alerte doit écrire AU PROSPECT — c'est le geste naturel du
      // commercial qui la lit sur son téléphone, et sans cet en-tête il
      // répondrait à un expéditeur automatique.
      estSuperAdmin: false,
      replyTo: demande.contact_email || null
    });
  } catch (err) {
    console.error('Alerte demande d\'accompagnement non envoyée :', err.message);
    return { envoye: false, raison: err.message };
  }
}

module.exports = { alerterNouvelleDemande };
