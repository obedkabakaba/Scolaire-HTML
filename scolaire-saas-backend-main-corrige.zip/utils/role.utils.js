// utils/role.utils.js

/**
 * Une personne ne peut avoir qu'un seul rôle, sauf deux combinaisons précises
 * et volontaires : Professeur + Titulaire, et Préfet + Directeur.
 * Retourne un message d'erreur si la combinaison n'est pas autorisée, sinon null.
 */
function validerCombinaisonRoles(roles) {
  const uniques = [...new Set(roles)];
  if (uniques.length <= 1) return null;
  if (uniques.length === 2) {
    const [a, b] = uniques;
    const combosAutorisees = [['professeur', 'titulaire'], ['prefet', 'directeur']];
    const estAutorisee = combosAutorisees.some(([x, y]) => (a === x && b === y) || (a === y && b === x));
    if (estAutorisee) return null;
  }
  return "Combinaison de rôles non autorisée. Une personne ne peut avoir qu'un seul rôle, sauf Professeur+Titulaire ou Préfet+Directeur.";
}

/**
 * Ajoute le rôle 'titulaire' à un utilisateur si ce rôle n'est pas déjà présent
 * et si la combinaison résultante est autorisée.
 * Lève une erreur si la combinaison est interdite.
 */
async function ajouterRoleTitulaireSiAutorise(client, userId) {
  // Récupérer les rôles actuels
  const res = await client.query(
    `SELECT array_agg(role::text) AS roles FROM utilisateur_roles WHERE utilisateur_id = $1`,
    [userId]
  );
  const rolesActuels = res.rows[0]?.roles || [];
  // Si déjà titulaire, on ne fait rien
  if (rolesActuels.includes('titulaire')) return;
  // Vérifier la combinaison
  const combinaisonTestee = [...rolesActuels, 'titulaire'];
  const erreur = validerCombinaisonRoles(combinaisonTestee);
  if (erreur) {
    throw new Error(`Impossible d'ajouter le rôle titulaire à cet utilisateur : ${erreur}`);
  }
  // Ajouter le rôle
  await client.query(
    `INSERT INTO utilisateur_roles (utilisateur_id, role) VALUES ($1, 'titulaire')`,
    [userId]
  );
}

module.exports = {
  validerCombinaisonRoles,
  ajouterRoleTitulaireSiAutorise
};
