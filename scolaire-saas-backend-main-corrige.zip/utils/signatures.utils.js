/**
 * Résolution des signatures d'un document scolaire.
 * ---------------------------------------------------------------------------
 * Un bulletin porte DEUX signatures qui n'ont ni le même auteur ni la même
 * portée :
 *
 *   · celle du TITULAIRE de la classe, qui atteste des cotes et des
 *     appréciations qu'il a lui-même saisies ;
 *   · celle du CHEF D'ÉTABLISSEMENT, qui engage l'école.
 *
 * Les confondre n'est pas un détail de mise en page : imprimer la signature du
 * directeur sous la mention « Signature du titulaire » attribue à une personne
 * un acte qu'elle n'a pas posé. C'est précisément ce que faisaient les
 * bulletins de semestre et le bulletin annuel, qui prenaient la signature la
 * plus récente de l'école quel qu'en soit l'auteur.
 *
 * Ce module est la SEULE source de vérité pour ces deux images. Tout générateur
 * de document doit passer par lui plutôt que d'écrire sa propre requête, sans
 * quoi la règle se remet à diverger d'un document à l'autre — ce qui est
 * exactement l'état dont on sort.
 *
 * Chaque enseignant dépose sa propre signature depuis « Ma classe »
 * (espace-titulaire.html) ; le directeur depuis Paramètres. Elles se
 * distinguent en base par `documents.uploaded_by`.
 */

const CURRENT_ECOLE = "NULLIF(current_setting('app.current_ecole_id', true), '')::uuid";

function nomComplet(ligne) {
  if (!ligne) return null;
  return [ligne.prenom, ligne.nom].filter(Boolean).join(' ') || null;
}

/**
 * @param {object} client   client PG déjà placé dans le contexte du tenant
 * @param {string} classeId classe concernée (facultatif : sans elle, seule la
 *                          signature du chef d'établissement est résolue)
 *
 * @returns {{
 *   signatureTitulaireUrl: string|null, titulaireNom: string|null,
 *   signatureChefUrl: string|null,      chefNom: string|null,
 *   chefEstDirecteur: boolean,
 *   cachetUrl: string|null,
 *   signatureUrl: string|null, signatureNom: string|null,
 *   signatureEstTitulaire: boolean, signatureEstDirecteur: boolean
 * }}
 *
 * Les trois derniers champs sont la vue « une seule signature » attendue par
 * les gabarits qui n'en impriment qu'une (bulletin de période, bulletin
 * personnalisé) : le titulaire s'il a déposé la sienne, sinon le chef.
 */
async function resoudreSignatures(client, { classeId } = {}) {
  /* ---------- Titulaire de la classe ---------- */
  let titulaireId = null;
  let titulaireNom = null;

  if (classeId) {
    const r = await client.query(
      `SELECT c.titulaire_id, u.nom, u.prenom
         FROM classes c
         LEFT JOIN utilisateurs u ON u.id = c.titulaire_id
        WHERE c.id = $1`,
      [classeId]
    );
    titulaireId = r.rows[0]?.titulaire_id || null;
    titulaireNom = nomComplet(r.rows[0]);
  }

  let signatureTitulaireUrl = null;
  if (titulaireId) {
    const r = await client.query(
      `SELECT url FROM documents
        WHERE ecole_id = ${CURRENT_ECOLE} AND type = 'signature' AND uploaded_by = $1
        ORDER BY created_at DESC LIMIT 1`,
      [titulaireId]
    );
    signatureTitulaireUrl = r.rows[0]?.url || null;
  }

  /* ---------- Chef d'établissement ----------
     On cherche d'abord une signature déposée par quelqu'un qui porte
     effectivement le rôle, directeur avant préfet. À défaut seulement, on
     retombe sur la signature la plus récente de l'école : mieux vaut une
     signature générique qu'une case vide, mais on retient qui l'a déposée
     pour que le gabarit n'affirme rien de faux sur son auteur. */
  let chef = (await client.query(
    `SELECT d.url, u.nom, u.prenom,
            EXISTS (
              SELECT 1 FROM utilisateur_roles ur
               WHERE ur.utilisateur_id = d.uploaded_by AND ur.role::text = 'directeur'
            ) AS est_directeur
       FROM documents d
       JOIN utilisateurs u ON u.id = d.uploaded_by
      WHERE d.ecole_id = ${CURRENT_ECOLE} AND d.type = 'signature'
        AND EXISTS (
          SELECT 1 FROM utilisateur_roles ur
           WHERE ur.utilisateur_id = d.uploaded_by AND ur.role::text IN ('directeur', 'prefet')
        )
      ORDER BY est_directeur DESC, d.created_at DESC
      LIMIT 1`
  )).rows[0] || null;

  let chefEstDirecteur = chef?.est_directeur === true;

  if (!chef) {
    const r = await client.query(
      `SELECT d.url, u.nom, u.prenom
         FROM documents d
         LEFT JOIN utilisateurs u ON u.id = d.uploaded_by
        WHERE d.ecole_id = ${CURRENT_ECOLE} AND d.type = 'signature'
        ORDER BY d.created_at DESC LIMIT 1`
    );
    chef = r.rows[0] || null;
    chefEstDirecteur = false;
  }

  /* ---------- Cachet ---------- */
  const cachet = await client.query(
    `SELECT url FROM documents WHERE ecole_id = ${CURRENT_ECOLE} AND type = 'cachet'
      ORDER BY created_at DESC LIMIT 1`
  );

  const signatureEstTitulaire = Boolean(signatureTitulaireUrl);

  return {
    signatureTitulaireUrl,
    titulaireNom,
    signatureChefUrl: chef?.url || null,
    chefNom: nomComplet(chef),
    chefEstDirecteur,
    cachetUrl: cachet.rows[0]?.url || null,

    // Vue « signature unique », pour les gabarits qui n'en portent qu'une.
    signatureUrl: signatureTitulaireUrl || chef?.url || null,
    signatureNom: signatureEstTitulaire ? titulaireNom : nomComplet(chef),
    signatureEstTitulaire,
    signatureEstDirecteur: !signatureEstTitulaire && chefEstDirecteur
  };
}

module.exports = { resoudreSignatures };
