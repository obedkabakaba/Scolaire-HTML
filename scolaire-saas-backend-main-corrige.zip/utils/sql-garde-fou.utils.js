/**
 * Validation du SQL produit par l'assistant — Ardoise
 * --------------------------------------------------------------------------
 * Cette couche est la DEUXIÈME ligne de défense, jamais la première.
 * La première, c'est PostgreSQL : rôle en lecture seule, RLS, colonnes
 * sensibles non lisibles, transaction en lecture seule, délai maximal.
 *
 * Si cette validation laissait passer quelque chose, la base refuserait
 * quand même d'écrire et de sortir de l'école. L'inverse n'est pas vrai :
 * une validation seule, sans les verrous de la base, ne protégerait rien.
 */

// Seules ces relations peuvent être citées. Ce sont des vues qui n'exposent
// que des colonnes inoffensives — jamais les tables brutes.
const VUES_AUTORISEES = [
  'ia_eleves',
  'ia_classes',
  'ia_bulletins',
  'ia_notes',
  'ia_presences',
  'ia_discipline',
  'ia_paiements',
  'ia_historique',
  'ia_annees',
  'ia_periodes',
  'ia_cours'
];

// Tout mot-clé capable de modifier, de sortir du périmètre ou de faire durer.
const MOTS_INTERDITS = [
  'insert', 'update', 'delete', 'truncate', 'drop', 'alter', 'create',
  'grant', 'revoke', 'copy', 'vacuum', 'analyze', 'reindex', 'cluster',
  'comment', 'call', 'do', 'execute', 'prepare', 'listen', 'notify',
  'lock', 'set', 'reset', 'begin', 'commit', 'rollback', 'savepoint',
  'pg_sleep', 'pg_read_file', 'pg_read_binary_file', 'pg_ls_dir',
  'lo_import', 'lo_export', 'dblink', 'dblink_connect', 'pg_terminate_backend',
  'current_setting', 'set_config', 'pg_catalog', 'information_schema',
  'pg_shadow', 'pg_authid', 'pg_user', 'into'
];

const LIGNES_MAX = 300;

function echec(message, detail) {
  const e = new Error(message);
  e.statusCode = 400;
  e.detailValidation = detail || message;
  return e;
}

/**
 * Vérifie et normalise une requête. Renvoie le SQL prêt à exécuter,
 * ou lève une erreur explicite.
 */
function validerRequete(sqlBrut) {
  if (!sqlBrut || typeof sqlBrut !== 'string') {
    throw echec("L'assistant n'a produit aucune requête.");
  }

  let sql = sqlBrut.trim();

  // Les modèles encadrent souvent leur réponse de balises Markdown.
  sql = sql.replace(/^```(?:sql)?\s*/i, '').replace(/```\s*$/, '').trim();

  // Un point-virgule final est toléré, jamais au milieu : c'est ainsi qu'on
  // empile une seconde instruction derrière une première inoffensive.
  sql = sql.replace(/;\s*$/, '').trim();
  if (sql.includes(';')) {
    throw echec('Requête refusée : elle contient plusieurs instructions.', 'point-virgule interne');
  }

  // Les commentaires servent à masquer la fin d'une requête légitime.
  if (sql.includes('--') || sql.includes('/*') || sql.includes('*/')) {
    throw echec('Requête refusée : elle contient des commentaires.', 'commentaire SQL');
  }

  // Le signe deux-points ouvre la porte aux paramètres liés côté client.
  if (sql.includes('$') || /(^|[^:]):[a-z_]/i.test(sql)) {
    throw echec('Requête refusée : elle contient des paramètres.', 'paramètre non attendu');
  }

  const minuscule = sql.toLowerCase();

  if (!/^(select|with)\b/.test(minuscule)) {
    throw echec('Requête refusée : seules les lectures sont autorisées.', 'ne commence pas par SELECT');
  }

  // Recherche par mot entier : « created_at » ne doit pas déclencher « create ».
  for (const mot of MOTS_INTERDITS) {
    const motif = new RegExp(`(^|[^a-z0-9_])${mot}([^a-z0-9_]|$)`, 'i');
    if (motif.test(minuscule)) {
      throw echec(`Requête refusée : elle emploie « ${mot} ».`, `mot interdit : ${mot}`);
    }
  }

  // Toute relation citée après FROM ou JOIN doit faire partie des vues.
  const relations = [...minuscule.matchAll(/\b(?:from|join)\s+([a-z_][a-z0-9_."]*)/g)]
    .map((m) => m[1].replace(/"/g, ''));

  for (const relation of relations) {
    // Une sous-requête ou une expression de table nommée en CTE est légitime :
    // on ne retient que ce qui ressemble à un nom de table.
    if (relation.includes('(')) continue;
    const nom = relation.split('.').pop();
    if (!VUES_AUTORISEES.includes(nom) && !estAliasCte(minuscule, nom)) {
      throw echec(
        `Requête refusée : elle interroge « ${nom} », qui n'est pas accessible à l'assistant.`,
        `relation non autorisée : ${nom}`
      );
    }
  }

  if (relations.length === 0) {
    throw echec('Requête refusée : aucune source de données identifiée.', 'aucune clause FROM');
  }

  // Un plafond de lignes est ajouté s'il n'y en a pas.
  if (!/\blimit\s+\d+/.test(minuscule)) {
    sql += ` LIMIT ${LIGNES_MAX}`;
  } else {
    const limite = Number(minuscule.match(/\blimit\s+(\d+)/)[1]);
    if (limite > LIGNES_MAX) {
      sql = sql.replace(/\blimit\s+\d+/i, `LIMIT ${LIGNES_MAX}`);
    }
  }

  if (sql.length > 4000) {
    throw echec('Requête refusée : elle est anormalement longue.', 'longueur excessive');
  }

  return sql;
}

/** Un nom déclaré dans un WITH … AS ( … ) est une source légitime. */
function estAliasCte(sqlMinuscule, nom) {
  const motif = new RegExp(`\\b(?:with|,)\\s+${nom}\\s+as\\s*\\(`, 'i');
  return motif.test(sqlMinuscule);
}

module.exports = { validerRequete, VUES_AUTORISEES, LIGNES_MAX };
