const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
const NOM_BUCKET = 'uploads';

/**
 * Upload un fichier (buffer) vers Supabase Storage et renvoie son URL publique.
 * Nécessite qu'un bucket PUBLIC nommé "uploads" existe déjà dans le projet Supabase
 * (Storage > New bucket > "uploads" > Public bucket activé).
 *
 * @param {Buffer} buffer
 * @param {string} chemin - ex: "ecoles/<id>/logos/1234-logo.png"
 * @param {string} mimetype
 */
async function uploaderVersStorage(buffer, chemin, mimetype) {
  const { error } = await supabase.storage.from(NOM_BUCKET).upload(chemin, buffer, {
    contentType: mimetype,
    upsert: true
  });

  if (error) {
    console.error(`Échec upload Supabase Storage — chemin tenté: "${chemin}"`, error);
    throw new Error(`Échec upload Supabase Storage: ${error.message}`);
  }

  const { data } = supabase.storage.from(NOM_BUCKET).getPublicUrl(chemin);
  return data.publicUrl;
}

module.exports = { uploaderVersStorage };
