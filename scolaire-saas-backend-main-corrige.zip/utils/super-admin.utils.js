/**
 * Outils partagés de l'espace Super Administrateur.
 * ---------------------------------------------------------------------------
 * Deux problèmes reviennent dans toutes les pages de supervision, et sont
 * résolus une seule fois ici.
 *
 * 1. LE SCHÉMA N'EST PAS CERTAIN.
 *    Le HANDOVER l'annonce sans détour (§ 3) : des migrations ont été écrites
 *    sans jamais tourner contre une base réelle, et l'état exact de la base de
 *    production n'est pas connu du code. Un tableau de bord qui agrège vingt
 *    tables ne peut pas se permettre de renvoyer une erreur 500 entière parce
 *    qu'une seule colonne manque. `mesurer()` isole chaque indicateur : celui
 *    qui échoue vaut `null` et s'affiche « — », les dix-neuf autres restent
 *    justes.
 *
 * 2. LE TRI ET LA PAGINATION VIENNENT DE L'URL.
 *    Une colonne de tri ne peut pas être un paramètre lié — elle fait partie
 *    de la structure de la requête. Elle doit donc être choisie dans une liste
 *    fermée, jamais concaténée depuis l'entrée utilisateur. `trierParmi()`
 *    rend cette règle difficile à contourner par distraction.
 */

/**
 * Exécute une requête d'indicateur en isolant son échec.
 * Renvoie la première colonne de la première ligne, ou `defaut`.
 */
async function mesurer(client, sql, params = [], defaut = null) {
  try {
    const r = await client.query(sql, params);
    if (!r.rows.length) return defaut;
    const premiere = Object.values(r.rows[0])[0];
    if (premiere === null || premiere === undefined) return defaut;
    const n = Number(premiere);
    return Number.isFinite(n) && /^-?\d+(\.\d+)?$/.test(String(premiere)) ? n : premiere;
  } catch (err) {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[super-admin] indicateur indisponible :', err.message);
    }
    return defaut;
  }
}

/** Même principe, mais pour un ensemble de lignes. */
async function lignes(client, sql, params = [], defaut = []) {
  try {
    const r = await client.query(sql, params);
    return r.rows;
  } catch (err) {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[super-admin] jeu de lignes indisponible :', err.message);
    }
    return defaut;
  }
}

/** Vérifie l'existence d'une table avant de l'interroger. */
async function tableExiste(client, nom) {
  try {
    const r = await client.query('SELECT to_regclass($1) AS t', [`public.${nom}`]);
    return r.rows[0].t !== null;
  } catch {
    return false;
  }
}

/**
 * Pagination normalisée. Plafonnée : une page de 10 000 lignes n'aide personne
 * et immobilise le navigateur autant que la base.
 */
function pagination(req, tailleDefaut = 25, tailleMax = 200) {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const taille = Math.min(tailleMax, Math.max(1, parseInt(req.query.taille, 10) || tailleDefaut));
  return { page, taille, decalage: (page - 1) * taille };
}

/**
 * Choisit une expression de tri dans une liste fermée.
 * @param {object} colonnes - { cleUrl: 'expression SQL' }
 */
function trierParmi(req, colonnes, defaut) {
  const demande = String(req.query.tri || '').trim();
  const expression = colonnes[demande] || colonnes[defaut];
  const sens = String(req.query.sens || '').toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  return { expression, sens, cle: colonnes[demande] ? demande : defaut };
}

/** Enveloppe de réponse paginée, identique partout dans l'espace. */
function reponsePaginee({ page, taille }, total, donnees, extra = {}) {
  const totalNombre = Number(total) || 0;
  return {
    donnees,
    pagination: {
      page,
      taille,
      total: totalNombre,
      pages: Math.max(1, Math.ceil(totalNombre / taille)),
      a_precedent: page > 1,
      a_suivant: page * taille < totalNombre
    },
    ...extra
  };
}

/** Bornes de période, avec valeurs par défaut raisonnables. */
function periode(req, joursDefaut = 30) {
  const jours = Math.min(730, Math.max(1, parseInt(req.query.jours, 10) || joursDefaut));
  const depuis = req.query.depuis || null;
  const jusqu = req.query.jusqu || null;
  return { jours, depuis, jusqu };
}

/** Échappe les caractères actifs d'un motif ILIKE saisi par l'utilisateur. */
function motifRecherche(texte) {
  const propre = String(texte || '').trim().replace(/[%_\\]/g, (c) => `\\${c}`);
  return `%${propre}%`;
}

/**
 * Masque une valeur sensible. Le principe de la mission est net : les secrets
 * ne s'affichent jamais en clair. On ne renvoie donc ni la valeur, ni sa
 * longueur exacte — seulement sa présence et une empreinte courte permettant
 * de vérifier qu'on parle bien de la même clé qu'en production.
 */
function etatSecret(valeur) {
  if (!valeur) return { defini: false, apercu: null };
  const texte = String(valeur);
  return {
    defini: true,
    apercu: `${texte.slice(0, 3)}…${texte.slice(-2)}`,
    longueur_approx: texte.length < 20 ? 'courte' : texte.length < 60 ? 'standard' : 'longue'
  };
}

module.exports = {
  mesurer, lignes, tableExiste, pagination, trierParmi,
  reponsePaginee, periode, motifRecherche, etatSecret
};
