/**
 * Construit le contexte tenant attendu par runWithTenant() à partir
 * du token décodé par authMiddleware (req.auth).
 */
function tenantContextFromReq(req) {
  return {
    ecoleId: req.auth.ecoleId,
    isSuperAdmin: req.auth.isSuperAdmin
  };
}

module.exports = { tenantContextFromReq };
