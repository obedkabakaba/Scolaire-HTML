const crypto = require('crypto');

/**
 * WhatsApp Cloud API — Ardoise
 * --------------------------------------------------------------------------
 * Variables d'environnement attendues :
 *   WHATSAPP_TOKEN              jeton d'accès Meta
 *   WHATSAPP_PHONE_NUMBER_ID    identifiant du numéro émetteur
 *   WHATSAPP_VERIFY_TOKEN       chaîne libre, à recopier dans Meta
 *   WHATSAPP_APP_SECRET         secret de l'application, pour la signature
 */

/**
 * Normalise un numéro congolais vers le format international sans « + ».
 *
 * Les numéros arrivent sous toutes les formes : 0812345678, +243812345678,
 * 243 81 234 56 78, (0)81… Sans normalisation, un parent enregistré avec le
 * zéro initial ne serait jamais reconnu par WhatsApp, qui envoie toujours
 * l'international. C'est le premier motif d'échec d'un assistant de ce type.
 */
function normaliserNumero(brut) {
  if (!brut) return null;
  let n = String(brut).replace(/[^0-9]/g, '');
  if (!n) return null;

  // Préfixe international composé : 00243… → 243…
  if (n.startsWith('00')) n = n.slice(2);
  // Double indicatif ou zéro parasite après l'indicatif : 2430812345678
  if (n.startsWith('2430')) n = '243' + n.slice(4);
  // Forme locale : 0812345678 → 243812345678
  if (n.startsWith('0')) n = '243' + n.slice(1);
  // Numéro à 9 chiffres sans indicatif : 812345678
  if (n.length === 9) n = '243' + n;

  return n.length >= 11 && n.length <= 15 ? n : null;
}

/**
 * Vérifie la signature Meta d'un appel entrant.
 *
 * Sans ce contrôle, n'importe qui connaissant l'adresse du webhook pourrait
 * se faire passer pour un parent et lire les notes d'un élève. C'est la seule
 * chose qui distingue un vrai message WhatsApp d'une requête forgée.
 */
function signatureValide(corpsBrut, entete) {
  const secret = process.env.WHATSAPP_APP_SECRET;
  if (!secret) return false;
  if (!entete || !entete.startsWith('sha256=')) return false;

  const attendue = 'sha256=' + crypto
    .createHmac('sha256', secret)
    .update(corpsBrut)
    .digest('hex');

  const a = Buffer.from(attendue);
  const b = Buffer.from(entete);
  // Comparaison à temps constant : une comparaison naïve laisserait fuiter
  // la signature attendue, caractère par caractère, par mesure du délai.
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** Envoie un message texte. Échec silencieux journalisé : jamais bloquant. */
async function envoyerMessage(destinataire, texte) {
  const jeton = process.env.WHATSAPP_TOKEN;
  const numeroId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!jeton || !numeroId) {
    console.error('WhatsApp non configuré : message non envoyé.');
    return false;
  }

  // WhatsApp refuse au-delà de 4096 caractères ; on coupe proprement.
  const corps = String(texte || '').slice(0, 3900);

  try {
    const reponse = await fetch(`https://graph.facebook.com/v21.0/${numeroId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jeton}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: destinataire,
        type: 'text',
        text: { preview_url: false, body: corps }
      })
    });

    if (!reponse.ok) {
      const detail = await reponse.text();
      console.error('Envoi WhatsApp refusé:', reponse.status, detail.slice(0, 300));
      return false;
    }
    return true;
  } catch (err) {
    console.error('Envoi WhatsApp impossible:', err.message);
    return false;
  }
}

/** Marque un message comme lu — la coche bleue rassure l'expéditeur. */
async function marquerLu(messageId) {
  const jeton = process.env.WHATSAPP_TOKEN;
  const numeroId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!jeton || !numeroId || !messageId) return;

  try {
    await fetch(`https://graph.facebook.com/v21.0/${numeroId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jeton}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', status: 'read', message_id: messageId })
    });
  } catch (e) { /* sans conséquence */ }
}

module.exports = { normaliserNumero, signatureValide, envoyerMessage, marquerLu };
